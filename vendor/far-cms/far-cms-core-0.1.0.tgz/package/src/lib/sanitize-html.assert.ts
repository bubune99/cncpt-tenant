/**
 * Run: npx -y tsx@4.23.15 src/lib/sanitize-html.assert.ts
 */
import assert from 'node:assert/strict'
import { decodeEntities, safeStyle, safeUrl, sanitizeHtml, sanitizeRichHtml } from './sanitize-html'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const noScript = (out: string) => {
  assert.ok(!/javascript\s*:/i.test(decodeEntities(out).replace(/\s+/g, '')), out)
  assert.ok(!/<script|on\w+\s*=|url\s*\(/i.test(out), out)
}

check('the four reported bypasses are neutralised (H-1)', () => {
  const cases = [
    '<a href=javascript:alert(1)>x</a>',
    '<a href="java&#115;cript:alert(1)">x</a>',
    '<a href=" javascript:alert(1)">x</a>',
    '<span style="background:url(javascript:alert(1))">x</span>',
  ]
  for (const c of cases) {
    const out = sanitizeHtml(c)
    noScript(out)
    assert.match(out, />x</, c)
  }
  assert.equal(sanitizeHtml('<a href=javascript:alert(1)>x</a>'), '<a>x</a>')
  assert.equal(sanitizeHtml('<span style="background:url(javascript:alert(1))">x</span>'), '<span>x</span>')
})

check('other shapes of the same attack are dropped too', () => {
  for (const c of [
    '<a href="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)">x</a>',
    '<a href="javascript&#58alert(1)">x</a>',
    '<a href="jav\tascript:alert(1)">x</a>',
    '<a href="javascript&colon;alert(1)">x</a>',
    '<a href="JaVaScRiPt:alert(1)">x</a>',
    '<a href="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">x</a>',
    '<a href="vbscript:msgbox(1)">x</a>',
    '<img src=x onerror=alert(1)>',
    '<img/src=x/onerror=alert(1)>',
    '<p onclick="alert(1)">x</p>',
    '<svg><script>alert(1)</script></svg>',
    '<scr<script>ipt>alert(1)</script>',
    '<iframe src="https://evil.example"></iframe>',
    '<span style="width: expression(alert(1))">x</span>',
    '<span style="color: red; background: u\\72 l(javascript:alert(1))">x</span>',
    '<!-- <script>alert(1)</script> -->',
    '<a href="x" style="-moz-binding: url(evil.xml)">x</a>',
  ]) noScript(sanitizeRichHtml(c))
  assert.equal(sanitizeHtml('<scr<script>ipt>alert(1)</script>'), 'ipt&gt;alert(1)')
  assert.equal(sanitizeRichHtml('<img src=x onerror=alert(1)>'), '<img src="x">')
})

check('normal content still renders', () => {
  assert.equal(sanitizeHtml('<p>Hello <strong>world</strong> &amp; friends</p>'), '<p>Hello <strong>world</strong> &amp; friends</p>')
  assert.equal(sanitizeHtml('<a href="https://projectdzidzor.org/give" target="_blank">Give</a>'), '<a href="https://projectdzidzor.org/give" target="_blank" rel="noopener noreferrer">Give</a>')
  assert.equal(sanitizeHtml('<a href="/initiatives#akuse">Read</a> <a href="mailto:hi@example.org">Mail</a> <a href="tel:+233200000000">Call</a>'), '<a href="/initiatives#akuse">Read</a> <a href="mailto:hi@example.org">Mail</a> <a href="tel:+233200000000">Call</a>')
  assert.equal(sanitizeHtml('<span class="text-primary font-bold md:text-lg" style="color: #088cbc; text-align: center">Hi</span>'), '<span class="text-primary font-bold md:text-lg" style="color: #088cbc; text-align: center">Hi</span>')
  assert.equal(sanitizeRichHtml('<figure><img src="https://media.projectdzidzor.org/a.jpg" alt="Nurses at Akuse" width="800"><figcaption>Akuse</figcaption></figure>'), '<figure><img src="https://media.projectdzidzor.org/a.jpg" alt="Nurses at Akuse" width="800"><figcaption>Akuse</figcaption></figure>')
  assert.equal(sanitizeRichHtml('<table><tbody><tr><td>1</td></tr></tbody></table><hr>'), '<table><tbody><tr><td>1</td></tr></tbody></table><hr>')
  assert.equal(sanitizeHtml('1 < 2 and 3 > 2'), '1 &lt; 2 and 3 &gt; 2')
  // Disallowed tags keep their text; img isn't allowed in inline text.
  assert.equal(sanitizeHtml('<div>a<img src="https://x.y/z.png">b</div>'), 'ab')
  // Attribute values are re-escaped, so a quote can't break out.
  assert.equal(sanitizeRichHtml('<img alt=\'a"><script>alert(1)</script>\'>'), '<img alt="a&quot;&gt;&lt;script&gt;alert(1)&lt;/script&gt;">')
})

check('building blocks: safeUrl and safeStyle', () => {
  assert.equal(safeUrl(' javascript:alert(1)'), null)
  assert.equal(safeUrl('https://a.b/c?d=1&amp;e=2'), 'https://a.b/c?d=1&e=2')
  assert.equal(safeUrl('#top'), '#top')
  assert.equal(safeUrl(''), null)
  assert.equal(safeStyle('color: red; position: fixed; z-index: 9999'), 'color: red')
  assert.equal(safeStyle('color: red; background: url(x)'), '')
})

console.log(`\n${n} checks passed`)
