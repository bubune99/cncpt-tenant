/**
 * Which admin nav items a viewer sees — pure, no React, asserted by
 * admin-nav-access.assert.ts.
 *
 * Nav visibility is a convenience, not security: every admin page/API checks
 * its own permission server-side. This keeps an editor's sidebar to the
 * screens they can actually use, and drops commerce screens while
 * commerce.enabled is off.
 */

import { isCommerceAdminPath } from './commerce-paths'

/**
 * Permissions that unlock a nav item (any one is enough). [] = any staff
 * member. An href that is NOT listed is shown to super admins only.
 */
export const NAV_PERMISSIONS: Record<string, string[]> = {
  '/admin': [],
  '/admin/todo': [],
  '/admin/records': ['pages.view', 'pages.edit'],
  '/admin/analytics': ['analytics.view'],
  '/admin/products': ['products.view'],
  '/admin/orders': ['orders.view'],
  '/admin/order-workflows': ['orders.edit'],
  '/admin/shipping': ['settings.shipping', 'orders.fulfill'],
  '/admin/customers': ['customers.view'],
  '/admin/inventory': ['inventory.view'],
  '/admin/discounts': ['products.edit'],
  '/admin/reviews': ['products.edit'],
  '/admin/pages': ['pages.view', 'pages.edit'],
  '/admin/blog': ['blog.view', 'blog.edit'],
  '/admin/forms': ['forms.view', 'forms.submissions'],
  '/admin/media': ['media.view', 'media.upload'],
  '/admin/email-marketing': ['email.view'],
  '/admin/users': ['users.view'],
  '/admin/roles': ['roles.view'],
  '/admin/audit-log': ['audit.view'],
  '/admin/plugins': ['plugins.view'],
  '/admin/workflows': ['workflows.view'],
  '/admin/tours': ['tours.view'],
  '/admin/settings': ['settings.view'],
}

/**
 * Screens that are not finished, so they stay out of the sidebar for
 * everyone (still reachable by URL for the developer):
 *   plugins (+ primitives / plugin workflows) — mock data
 *   workflows — builder not production-ready
 *   tours — library falls back to mock tours
 *   email-marketing — subscriber management "coming soon"
 */
export const UNFINISHED_ADMIN_HREFS = [
  '/admin/plugins',
  '/admin/workflows',
  '/admin/tours',
  '/admin/email-marketing',
] as const

export interface NavAccessOptions {
  commerceEnabled: boolean
  isSuperAdmin: boolean
  can: (permission: string) => boolean
  /** hrefs never shown in the sidebar (e.g. unfinished screens) */
  hiddenHrefs?: readonly string[]
}

export function canSeeNavItem(href: string, opts: NavAccessOptions): boolean {
  if (!opts.commerceEnabled && isCommerceAdminPath(href)) return false
  if (opts.hiddenHrefs?.includes(href)) return false
  if (opts.isSuperAdmin) return true
  const required = NAV_PERMISSIONS[href]
  if (!required) return false
  return required.length === 0 || required.some((p) => opts.can(p))
}

export function filterNavGroups<G extends { items: { href: string }[] }>(
  groups: G[],
  opts: NavAccessOptions
): G[] {
  return groups
    .map((group) => ({ ...group, items: group.items.filter((item) => canSeeNavItem(item.href, opts)) }))
    .filter((group) => group.items.length > 0)
}

/** Core screens every deployment gets, whatever its module rows say. */
export const CORE_NAV_HREFS = ['/admin/todo', '/admin/records'] as const

/**
 * Module-driven nav comes from cms_modules.manifest (DB rows seeded before
 * a screen existed). Make sure the core items from the code manifest are
 * present in their group, right after that group's first item, without
 * duplicating them.
 */
export function withCoreNavItems<I extends { href: string }, G extends { name: string; items: I[] }>(
  groups: G[],
  manifest: ReadonlyArray<G>,
  coreHrefs: readonly string[] = CORE_NAV_HREFS
): G[] {
  const present = new Set(groups.flatMap((g) => g.items.map((i) => i.href)))
  let result = groups
  for (const mg of manifest) {
    const missing = mg.items.filter((i) => coreHrefs.includes(i.href) && !present.has(i.href))
    if (missing.length === 0) continue
    const idx = result.findIndex((g) => g.name === mg.name)
    result =
      idx === -1
        ? [...result, { ...mg, items: missing }]
        : result.map((g, i) => (i === idx ? { ...g, items: [...g.items.slice(0, 1), ...missing, ...g.items.slice(1)] } : g))
  }
  return result
}

/**
 * Apply per-deployment label/icon overrides, then make labels unique: when
 * a relabel collides with another item's own name (e.g. Blog relabelled
 * "Initiatives" before initiatives became records), the RELABELLED item
 * falls back to its own name so the sidebar never shows the same label twice.
 */
export function applyNavOverrides<I extends { href: string; name: string; icon?: unknown }, G extends { name: string; items: I[] }>(
  groups: G[],
  overrides: Record<string, { label?: string; icon?: string; hidden?: boolean } | undefined>
): G[] {
  const ownNames = new Set(groups.flatMap((g) => g.items.filter((i) => !overrides[i.href]?.label).map((i) => i.name)))
  const seen = new Set<string>()
  return groups.map((g) => ({
    ...g,
    items: g.items
      .filter((i) => !overrides[i.href]?.hidden)
      .map((i) => {
        const o = overrides[i.href]
        if (!o) return i
        const relabel = o.label && !ownNames.has(o.label) ? o.label : i.name
        return { ...i, name: relabel, icon: o.icon || i.icon }
      })
      .filter((i) => {
        const key = i.name.toLowerCase()
        if (seen.has(key)) return false
        seen.add(key)
        return true
      }),
  }))
}

/**
 * What the action bar's breadcrumb may match: every screen the CODE manifest
 * knows, plus anything the module rows add (in their group). Module rows
 * (cms_modules, seeded per deployment) can leave real screens out — a
 * disabled module (Events), or screens added after seeding (Tours,
 * Workflows, Plugins) — and the breadcrumb must still name them. Access is
 * applied afterwards by the caller (filterNavGroups without hiddenHrefs).
 * Pure; never mutates its inputs.
 */
export function crumbNavSource<I extends { href: string }, G extends { name: string; items: I[] }>(
  moduleGroups: ReadonlyArray<G> | null | undefined,
  manifest: ReadonlyArray<G>
): G[] {
  const result: G[] = manifest.map((g) => ({ ...g, items: [...g.items] }))
  const present = new Set(result.flatMap((g) => g.items.map((i) => i.href)))
  for (const mg of moduleGroups ?? []) {
    const extra = mg.items.filter((i) => !present.has(i.href))
    if (!extra.length) continue
    extra.forEach((i) => present.add(i.href))
    const idx = result.findIndex((g) => g.name === mg.name)
    if (idx === -1) result.push({ ...mg, items: extra })
    else result[idx] = { ...result[idx], items: [...result[idx].items, ...extra] }
  }
  return result
}
