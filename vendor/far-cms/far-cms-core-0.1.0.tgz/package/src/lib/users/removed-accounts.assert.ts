/**
 * Owner, 2026-11-22 (question 38f48754): "Access removed but we delete according to regulations".
 * Remove takes access away at once and marks the account; the nightly purge deletes it once the retention time
 * has passed. An account that authored something (posts, media, comments, templates, order updates, a customer)
 * is anonymised instead, so their work stays. Run: node_modules/.bin/tsx src/lib/users/removed-accounts.assert.ts
 */
import assert from 'node:assert/strict'
import { REMOVED_ACCOUNT_MONTHS, removedAccountCutoff, planRemovedAccounts, anonymisedFields, accountStatus } from './removed-accounts'

const now = new Date('2026-11-22T03:30:00Z')
const cutoff = removedAccountCutoff(now, 12)
assert.equal(cutoff.toISOString(), '2025-11-22T03:30:00.000Z', 'the cutoff is the retention time before now')
assert.ok(REMOVED_ACCOUNT_MONTHS > 0)

const plan = planRemovedAccounts([
  { id: 'old-none', accessRemovedAt: new Date('2025-10-01'), authored: 0 },
  { id: 'old-author', accessRemovedAt: new Date('2025-01-01'), authored: 3 },
  { id: 'recent', accessRemovedAt: new Date('2026-11-01'), authored: 0 },
  { id: 'active', accessRemovedAt: null, authored: 0 },
], cutoff)
assert.deepEqual(plan, { remove: ['old-none'], anonymise: ['old-author'] }, 'past the cutoff: delete, or anonymise if they authored work; recent and active accounts are left')

const a = anonymisedFields('ab12')
assert.equal(a.name, 'Former member')
assert.equal(a.phone, null)
assert.equal(a.avatar, null)
assert.equal(a.stackAuthId, null, 'the sign-in link is cut, so signing in again starts a new account')
assert.match(a.email, /^removed-ab12@invalid$/, 'the address is replaced, unique per account, and cannot receive mail')

assert.equal(accountStatus(null), 'active')
assert.equal(accountStatus(new Date('2026-11-01')), 'access-removed')
console.log('removed-accounts: 5 checks passed')
