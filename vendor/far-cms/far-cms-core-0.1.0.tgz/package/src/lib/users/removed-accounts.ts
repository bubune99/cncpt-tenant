/**
 * Accounts whose access was removed (Users › Remove user). Access goes at once; the account itself is kept for
 * as long as the audit log is (so the log can still say who did what), then the nightly purge deletes it, or
 * anonymises it when the person authored work that stays (posts, media, comments, templates, order updates,
 * a customer record). Owner, 2026-11-22 (question 38f48754): "Access removed but we delete according to
 * regulations". Pure; checked by removed-accounts.assert.ts.
 */
import { AUDIT_MONTHS } from '../privacy/inventory'

export const REMOVED_ACCOUNT_MONTHS = AUDIT_MONTHS

export interface RemovedAccount {
  id: string
  accessRemovedAt: Date | null
  /** How many records this person authored that must stay. */
  authored: number
}

export function removedAccountCutoff(now: Date, months: number = REMOVED_ACCOUNT_MONTHS): Date {
  const d = new Date(now)
  d.setUTCMonth(d.getUTCMonth() - months)
  return d
}

export function planRemovedAccounts(accounts: ReadonlyArray<RemovedAccount>, cutoff: Date): { remove: string[]; anonymise: string[] } {
  const due = accounts.filter((a) => a.accessRemovedAt && a.accessRemovedAt < cutoff)
  return {
    remove: due.filter((a) => a.authored === 0).map((a) => a.id),
    anonymise: due.filter((a) => a.authored > 0).map((a) => a.id),
  }
}

/** Personal fields blanked on an anonymised account; the sign-in link and picture go too, so a later sign-in
 *  starts a new account instead of reattaching to this one. */
export function anonymisedFields(id: string): { name: string; email: string; phone: null; avatar: null; stackAuthId: null } {
  return { name: 'Former member', email: `removed-${id}@invalid`, phone: null, avatar: null, stackAuthId: null }
}

export function accountStatus(accessRemovedAt: Date | null): 'active' | 'access-removed' {
  return accessRemovedAt ? 'access-removed' : 'active'
}
