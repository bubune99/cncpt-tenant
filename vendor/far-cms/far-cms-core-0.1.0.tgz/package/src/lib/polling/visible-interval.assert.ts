/**
 * Run: npx -y tsx@4.23.15 src/lib/polling/visible-interval.assert.ts
 * The idle-friendly poller with a fake clock: nothing while hidden or offline,
 * one run on return, backoff, stop after long idle, resume on activity.
 */
import assert from 'node:assert/strict'
import { createVisiblePoller, type VisiblePollOptions } from './visible-interval'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}

const MIN = 60_000

function rig(opts?: VisiblePollOptions, result: () => unknown = () => false) {
  let t = 0
  let seq = 0
  let visible = true
  let online = true
  const timers = new Map<number, { at: number; fn: () => void }>()
  const env = {
    now: () => t,
    setTimer: (fn: () => void, ms: number) => {
      timers.set(++seq, { at: t + ms, fn })
      return seq
    },
    clearTimer: (h: unknown) => void timers.delete(h as number),
    visible: () => visible,
    online: () => online,
  }
  let calls = 0
  const stamps: number[] = []
  const poller = createVisiblePoller(() => { calls++; stamps.push(t); return result() }, env, opts)
  // Advance the clock, firing due timers in order (and any they schedule).
  const advance = async (ms: number) => {
    const end = t + ms
    await Promise.resolve(); await Promise.resolve(); await Promise.resolve()
    for (;;) {
      const due = [...timers.entries()].filter(([, v]) => v.at <= end).sort((a, b) => a[1].at - b[1].at)[0]
      if (!due) break
      timers.delete(due[0])
      t = due[1].at
      due[1].fn()
      await Promise.resolve(); await Promise.resolve(); await Promise.resolve()
    }
    t = end
  }
  return {
    poller, advance, stamps,
    calls: () => calls,
    setVisible: (v: boolean) => { visible = v },
    setOnline: (v: boolean) => { online = v },
    pending: () => timers.size,
  }
}

async function main() {
  // Runs once on start, then on the backoff schedule while nothing changes: 30 s, 2 min, 5 min.
  {
    const r = rig()
    await r.advance(0)
    eq(r.calls(), 1, 'immediate run')
    await r.advance(29_999); eq(r.calls(), 1)
    await r.advance(1); eq(r.calls(), 2)
    // The person is clicking around: the window stays active, backoff still steps because nothing changed.
    r.poller.activity()
    await r.advance(2 * MIN); eq(r.stamps.slice(0, 3), [0, 30_000, 150_000])
    await r.advance(5 * MIN - 1); eq(r.calls(), 3)
    await r.advance(1); eq(r.calls(), 4)
    r.poller.stop()
  }

  // A change resets the backoff.
  {
    let changed = false
    const r = rig(undefined, () => changed)
    await r.advance(0)
    await r.advance(30_000)            // run 2 (unchanged) -> next delay 2 min
    changed = true
    r.poller.activity()
    await r.advance(2 * MIN)           // run 3 sees a change
    eq(r.calls(), 3)
    await r.advance(30_000)            // back to 30 s
    eq(r.calls(), 4)
    r.poller.stop()
  }

  // Hidden: nothing at all; back to visible: one run straight away, then the schedule resumes.
  {
    const r = rig()
    await r.advance(0)
    r.setVisible(false)
    r.poller.recheck()
    await r.advance(20 * MIN)
    eq(r.calls(), 1, 'no calls while hidden')
    eq(r.pending(), 0, 'no timer parked while hidden')
    r.setVisible(true)
    r.poller.activity()
    r.poller.recheck()
    await r.advance(0)
    eq(r.calls(), 2, 'one call on return')
    eq(r.stamps[1], 20 * MIN)
    await r.advance(10)
    eq(r.calls(), 2, 'no burst on return')
    r.poller.stop()
  }

  // Offline pauses; coming online runs once.
  {
    const r = rig()
    await r.advance(0)
    r.setOnline(false)
    await r.advance(10 * MIN)
    const before = r.calls()
    await r.advance(10 * MIN)
    eq(r.calls(), before, 'nothing while offline')
    r.setOnline(true)
    r.poller.recheck()
    await r.advance(0)
    eq(r.calls(), before + 1, 'one call when back online')
    r.poller.stop()
  }

  // Past the active window with no input the poll sits at the slowest step, then stops after 30 min idle.
  {
    const r = rig()
    await r.advance(0)
    await r.advance(30 * MIN + 1)
    const stampsAfterIdle = r.stamps.filter((s) => s > 5 * MIN)
    assert.ok(stampsAfterIdle.every((s, i, a) => i === 0 || s - a[i - 1] >= 5 * MIN), 'slowest step once nobody is steering')
    n++
    eq(r.stamps.every((s) => s <= 30 * MIN), true, 'nothing after the idle stop')
    const stopped = r.calls()
    eq(r.pending(), 0, 'no timer once stopped')
    await r.advance(3 * 60 * MIN)
    eq(r.calls(), stopped, 'stays stopped with no activity')
    // Activity resumes it and runs straight away.
    r.poller.activity()
    await r.advance(0)
    eq(r.calls(), stopped + 1, 'resume on activity')
    await r.advance(30_000)
    eq(r.calls(), stopped + 2, 'back at the base interval')
    r.poller.stop()
  }

  // A failing callback never kills the loop; stop() really stops.
  {
    const r = rig(undefined, () => { throw new Error('boom') })
    await r.advance(0)
    await r.advance(30_000)
    assert.ok(r.calls() >= 2); n++
    r.poller.stop()
    const c = r.calls()
    r.poller.activity()
    await r.advance(10 * MIN)
    eq(r.calls(), c, 'no calls after stop')
  }

  // immediate:false waits for the first interval.
  {
    const r = rig({ immediate: false, intervals: [60_000, 120_000] })
    await r.advance(59_999); eq(r.calls(), 0)
    await r.advance(1); eq(r.calls(), 1)
    r.poller.stop()
  }

  console.log(`visible-interval.assert: ${n} assertions passed`)
}

main().catch((e) => { console.error(e); process.exit(1) })
