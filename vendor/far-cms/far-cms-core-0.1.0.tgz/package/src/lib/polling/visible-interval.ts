/**
 * Polling that lets the database sleep (Neon autosuspends after 5 idle minutes,
 * and a hidden or abandoned admin tab polling every 30 s never lets it).
 *
 * The callback runs only while the tab is visible, online, and the person has
 * touched the page recently. It runs once straight away when the tab becomes
 * visible / the person comes back, backs off while nothing changes, and stops
 * for good after a long idle until the next activity.
 *
 * `createVisiblePoller` is pure (clock, timers and page state are injected) so
 * it is asserted with a fake clock; `startVisibleInterval` binds it to the
 * browser. Pollers that fetch an API must use this (or carry a
 * `// poll-ok: <reason>` comment): see poll-guard.assert.ts.
 */

export interface VisiblePollOptions {
  /** Delay after a run, by how many runs in a row found nothing new. Last step repeats. */
  intervals?: readonly number[]
  /** Activity within this window counts as "using the page". Default 5 min. */
  activeWindowMs?: number
  /** No activity for this long stops polling until the next activity. Default 30 min. */
  idleStopMs?: number
  /** Gap below which a wake-up does not run again straight away. Default 5 s. */
  minGapMs?: number
  /** Run once on start (when eligible). Default true. */
  immediate?: boolean
}

/** Return true when the data changed (resets the backoff). Anything else counts as unchanged. */
export type PollCallback = () => unknown | Promise<unknown>

export interface PollEnv {
  now(): number
  setTimer(fn: () => void, ms: number): unknown
  clearTimer(handle: unknown): void
  visible(): boolean
  online(): boolean
}

export interface VisiblePoller {
  /** Any pointer / key / scroll / focus event. */
  activity(): void
  /** Visibility or connectivity changed: re-evaluate. */
  recheck(): void
  stop(): void
}

export const DEFAULT_INTERVALS = [30_000, 120_000, 300_000] as const
export const DEFAULT_ACTIVE_WINDOW_MS = 5 * 60_000
export const DEFAULT_IDLE_STOP_MS = 30 * 60_000
const DEFAULT_MIN_GAP_MS = 5_000

export function createVisiblePoller(cb: PollCallback, env: PollEnv, opts: VisiblePollOptions = {}): VisiblePoller {
  const intervals = opts.intervals?.length ? opts.intervals : DEFAULT_INTERVALS
  const activeWindowMs = opts.activeWindowMs ?? DEFAULT_ACTIVE_WINDOW_MS
  const idleStopMs = opts.idleStopMs ?? DEFAULT_IDLE_STOP_MS
  const minGapMs = opts.minGapMs ?? DEFAULT_MIN_GAP_MS

  let lastActivity = env.now()
  let lastRun = -Infinity
  let unchanged = 0
  let timer: unknown = null
  let running = false
  let stopped = false

  const eligible = () => env.visible() && env.online() && env.now() - lastActivity < idleStopMs

  const clear = () => {
    if (timer !== null) env.clearTimer(timer)
    timer = null
  }

  const nextDelay = () => {
    // Past the active window nobody is steering: sit at the slowest step.
    if (env.now() - lastActivity >= activeWindowMs) return intervals[intervals.length - 1]
    return intervals[Math.min(unchanged, intervals.length - 1)]
  }

  const schedule = () => {
    clear()
    if (stopped || !eligible()) return
    const delay = nextDelay()
    // Would land past the idle stop: don't park a timer, wait for activity instead.
    if (env.now() + delay - lastActivity >= idleStopMs) return
    timer = env.setTimer(() => {
      timer = null
      void run(true)
    }, delay)
  }

  // Only timer-driven runs count toward the backoff: the first look (start, or a return) is free.
  const run = async (fromTimer = false) => {
    if (stopped || running) return
    if (!eligible()) return schedule()
    running = true
    lastRun = env.now()
    try {
      const changed = await cb()
      unchanged = changed === true ? 0 : fromTimer ? unchanged + 1 : unchanged
    } catch {
      if (fromTimer) unchanged += 1
    } finally {
      running = false
      schedule()
    }
  }

  /** Wake-up: run now unless we just did, otherwise just make sure a timer is set. */
  const wake = () => {
    if (stopped) return
    if (!eligible()) return clear()
    if (env.now() - lastRun >= minGapMs) {
      clear()
      unchanged = 0
      void run()
    } else if (timer === null && !running) schedule()
  }

  if (opts.immediate !== false) void run()
  else schedule()

  return {
    activity() {
      if (stopped) return
      const wasQuiet = env.now() - lastActivity >= activeWindowMs
      lastActivity = env.now()
      if (wasQuiet) {
        unchanged = 0
        wake()
      } else if (timer === null && !running) {
        schedule()
      }
    },
    recheck: wake,
    stop() {
      stopped = true
      clear()
    },
  }
}

const ACTIVITY_EVENTS = ['pointerdown', 'keydown', 'wheel', 'scroll', 'touchstart', 'focus'] as const

/** Browser binding. Returns a stop function. Does nothing on the server. */
export function startVisibleInterval(cb: PollCallback, opts?: VisiblePollOptions): () => void {
  if (typeof window === 'undefined' || typeof document === 'undefined') return () => {}
  const poller = createVisiblePoller(
    cb,
    {
      now: () => Date.now(),
      setTimer: (fn, ms) => window.setTimeout(fn, ms),
      clearTimer: (h) => window.clearTimeout(h as number),
      visible: () => document.visibilityState === 'visible',
      online: () => navigator.onLine !== false,
    },
    opts,
  )
  const onActivity = () => poller.activity()
  const onRecheck = () => {
    if (document.visibilityState === 'visible') poller.activity()
    poller.recheck()
  }
  ACTIVITY_EVENTS.forEach((e) => window.addEventListener(e, onActivity, { passive: true, capture: true }))
  document.addEventListener('visibilitychange', onRecheck)
  window.addEventListener('online', onRecheck)
  window.addEventListener('offline', onRecheck)
  return () => {
    poller.stop()
    ACTIVITY_EVENTS.forEach((e) => window.removeEventListener(e, onActivity, { capture: true }))
    document.removeEventListener('visibilitychange', onRecheck)
    window.removeEventListener('online', onRecheck)
    window.removeEventListener('offline', onRecheck)
  }
}
