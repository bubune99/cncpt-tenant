/**
 * The public site is always light; only the admin follows the person's own theme.
 * Owner, 2026-11-22 (question c51a9e63): "Make the public site always light (recommended)". Found because the
 * Akuse Hospital initiative page's button row sat on near-black for dark-mode visitors.
 * Run: node_modules/.bin/tsx src/lib/theme/forced-theme.assert.ts
 */
import assert from 'node:assert/strict'
import { forcedThemeFor } from './forced-theme'

for (const p of ['/', '/initiatives/akuse-hospital', '/legal/privacy', '/account', '/account/profile', '/donate', '/handler/sign-in', '/ade-preview/about', '/administer-x'])
  assert.equal(forcedThemeFor(p), 'light', `${p} is a public page: always light`)
for (const p of ['/admin', '/admin/', '/admin/pages/abc/editor', '/admin/viewport-harness'])
  assert.equal(forcedThemeFor(p), undefined, `${p} follows the person's theme`)
assert.equal(forcedThemeFor(null), 'light', 'no path known: light')
console.log('forced-theme: 3 checks passed')
