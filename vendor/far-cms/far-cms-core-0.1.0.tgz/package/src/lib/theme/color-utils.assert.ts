/**
 * The site's brand colors as theme tokens: every pair they make can be read.
 * Found 2026-11-15/16 on the admin with the client's colors (#022b39, #088cbc):
 * the menu highlight was white on #088cbc (3.8 to 1), and in the dark theme the
 * brand navy was used unchanged on a near-black page, so brand-colored text and
 * buttons could not be seen. Run: node_modules/.bin/tsx src/lib/theme/color-utils.assert.ts
 */
import assert from 'node:assert/strict'
import { contrast } from '../ade/ui/color'
import { generateThemeCss } from './color-utils'

let n = 0
const check = (name: string, fn: () => void): void => { fn(); n++; console.log(`ok ${name}`) }
const DARK_PAGE = 'oklch(0.145 0 0)'

function tokens(css: string, selector: ':root' | '.dark'): Record<string, string> {
  const start = css.indexOf(`${selector} {`)
  assert.ok(start >= 0, `${selector} block present`)
  const body = css.slice(css.indexOf('{', start) + 1, css.indexOf('}', start))
  return Object.fromEntries(body.split(';').map((d) => d.trim()).filter(Boolean).map((d) => { const i = d.indexOf(':'); return [d.slice(0, i).trim(), d.slice(i + 1).trim()] }))
}

const css = generateThemeCss('#022b39', '#088cbc')

check('nothing is generated without colors', () => assert.equal(generateThemeCss(), ''))
check('light theme keeps the brand colors as they are', () => {
  const t = tokens(css, ':root')
  assert.equal(t['--primary'], '#022b39')
  assert.equal(t['--accent'], '#088cbc')
})
check('the words on each brand color can be read, in both themes', () => {
  for (const sel of [':root', '.dark'] as const) {
    const t = tokens(css, sel)
    for (const base of ['--primary', '--accent', '--sidebar-primary', '--sidebar-accent']) {
      const ratio = contrast(t[`${base}-foreground`], t[base])
      assert.ok(ratio >= 4.5, `${sel} ${base}: ${ratio.toFixed(2)} to 1`)
    }
  }
})
check('in the dark theme the brand color is lifted until it shows on the dark page, keeping its hue', () => {
  const t = tokens(css, '.dark')
  assert.ok(contrast(t['--primary'], DARK_PAGE) >= 4.5, `primary on the dark page: ${contrast(t['--primary'], DARK_PAGE).toFixed(2)}`)
  assert.ok(contrast(t['--ring'], DARK_PAGE) >= 3)
  assert.notEqual(t['--primary'], '#022b39')
})
check('a brand color that already shows on the dark page is left alone there', () => {
  const t = tokens(generateThemeCss('#7dd3fc', undefined), '.dark')
  assert.equal(t['--primary'], '#7dd3fc')
})
check('only validated hex colors reach the style text', () => {
  assert.equal(generateThemeCss('red; } body { display:none', undefined), '')
})
console.log(`\n${n} checks passed`)
