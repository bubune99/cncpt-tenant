/**
 * Which theme a path is held to: the public site (everything outside /admin) is always light, because its
 * pages are designed light; the admin follows the person's choice. Pure; checked by forced-theme.assert.ts.
 */
export function forcedThemeFor(pathname: string | null): 'light' | undefined {
  if (pathname && (pathname === '/admin' || pathname.startsWith('/admin/'))) return undefined
  return 'light'
}
