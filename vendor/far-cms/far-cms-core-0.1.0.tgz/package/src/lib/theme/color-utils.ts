/**
 * Theme Color Utilities
 *
 * Converts hex colors from branding settings into CSS variable overrides.
 * The site's globals.css uses OKLch color space, but we inject hex colors
 * directly as CSS custom property overrides since they take precedence
 * in the cascade.
 */

import { contrast, formatOklch, hexToRgb, rgbToOklch } from '../ade/ui/color'


/**
 * Convert a hex color string to HSL components.
 * Used to determine lightness for automatic foreground color selection.
 */
export function hexToHsl(hex: string): { h: number; s: number; l: number } {
  // Remove # prefix
  hex = hex.replace('#', '')

  // Handle shorthand hex (e.g., #fff)
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2]
  }

  const r = parseInt(hex.slice(0, 2), 16) / 255
  const g = parseInt(hex.slice(2, 4), 16) / 255
  const b = parseInt(hex.slice(4, 6), 16) / 255

  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  let h = 0
  let s = 0
  const l = (max + min) / 2

  if (max !== min) {
    const d = max - min
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6
        break
      case g:
        h = ((b - r) / d + 2) / 6
        break
      case b:
        h = ((r - g) / d + 4) / 6
        break
    }
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  }
}

const HEX = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/
const ON_LIGHT = '#171717'
const ON_DARK = '#ffffff'
/** The dark theme's page color (globals.css `.dark --background`). */
const DARK_PAGE = 'oklch(0.145 0 0)'
const READS = 4.5

/**
 * The words on a brand color: white or near-black, whichever reads better,
 * measured (the old rule went by HSL lightness and put white on #088cbc at
 * 3.8 to 1).
 */
function contrastForeground(color: string): string {
  return contrast(ON_DARK, color) >= contrast(ON_LIGHT, color) ? ON_DARK : ON_LIGHT
}

/**
 * A brand color for the dark theme: left alone when it already shows on the
 * dark page, otherwise lifted in lightness (same hue and chroma) until it does.
 */
function forDarkPage(hex: string): string {
  if (contrast(hex, DARK_PAGE) >= READS) return hex
  const rgb = hexToRgb(hex)
  if (!rgb) return hex
  let o = rgbToOklch(rgb)
  // Lifted until it shows on the page AND some text can be read on it (a mid tone passes the first and fails the second).
  const reads = (c: string): boolean => contrast(c, DARK_PAGE) >= READS && Math.max(contrast(ON_DARK, c), contrast(ON_LIGHT, c)) >= READS
  for (let i = 0; i < 90 && !reads(formatOklch(o)); i++) o = { ...o, l: Math.min(0.98, o.l + 0.01) }
  return formatOklch(o)
}

/**
 * Generate CSS variable overrides from branding settings.
 *
 * Returns a CSS string to inject into a <style> tag. The overrides
 * apply to both :root (light mode) and .dark (dark mode) so the
 * branding colors are consistent regardless of theme.
 *
 * Variables overridden:
 *   --primary, --primary-foreground
 *   --accent, --accent-foreground
 *   --sidebar-primary, --sidebar-primary-foreground
 *   --ring (set to primary for focus rings)
 */
export function generateThemeCss(
  primaryColor?: string,
  accentColor?: string
): string {
  // Only validated hex colors reach the style text.
  if (primaryColor && !HEX.test(primaryColor)) primaryColor = undefined
  if (accentColor && !HEX.test(accentColor)) accentColor = undefined
  if (!primaryColor && !accentColor) return ''

  const lightRules: string[] = []
  const darkRules: string[] = []

  if (primaryColor) {
    const fg = contrastForeground(primaryColor)

    // Light mode: primary is the brand color
    lightRules.push(`--primary: ${primaryColor}`)
    lightRules.push(`--primary-foreground: ${fg}`)
    lightRules.push(`--sidebar-primary: ${primaryColor}`)
    lightRules.push(`--sidebar-primary-foreground: ${fg}`)
    lightRules.push(`--ring: ${primaryColor}`)

    // Dark mode: the brand color, lifted when it would not show on the dark page.
    const dark = forDarkPage(primaryColor)
    const darkFg = contrastForeground(dark)
    darkRules.push(`--primary: ${dark}`)
    darkRules.push(`--primary-foreground: ${darkFg}`)
    darkRules.push(`--sidebar-primary: ${dark}`)
    darkRules.push(`--sidebar-primary-foreground: ${darkFg}`)
    darkRules.push(`--ring: ${dark}`)
  }

  if (accentColor) {
    const fg = contrastForeground(accentColor)

    lightRules.push(`--accent: ${accentColor}`)
    lightRules.push(`--accent-foreground: ${fg}`)
    lightRules.push(`--sidebar-accent: ${accentColor}`)
    lightRules.push(`--sidebar-accent-foreground: ${fg}`)

    darkRules.push(`--accent: ${accentColor}`)
    darkRules.push(`--accent-foreground: ${fg}`)
    darkRules.push(`--sidebar-accent: ${accentColor}`)
    darkRules.push(`--sidebar-accent-foreground: ${fg}`)
  }

  const parts: string[] = []

  if (lightRules.length > 0) {
    parts.push(`:root { ${lightRules.join('; ')} }`)
  }

  if (darkRules.length > 0) {
    parts.push(`.dark { ${darkRules.join('; ')} }`)
  }

  return parts.join('\n')
}
