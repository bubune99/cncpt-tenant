/**
 * Run: npx -y tsx@4.23.15 src/lib/auth/return-path.assert.ts
 */
import assert from 'node:assert/strict'
import { RETURN_PATH_MAX, signInReturnPath } from './return-path'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the query survives sign-in (a link to a tab, a To-do item or a settings section)', () => {
  assert.equal(signInReturnPath('/admin/forms/f1', '?tab=submissions'), '/admin/forms/f1?tab=submissions')
  assert.equal(signInReturnPath('/admin/todo', '?set=abc'), '/admin/todo?set=abc')
  assert.equal(signInReturnPath('/admin', ''), '/admin')
  assert.equal(signInReturnPath('/admin', '?'), '/admin')
})

check('same-site paths only; an oversized query is dropped, not cut mid-way', () => {
  assert.equal(signInReturnPath('//evil.example/x', ''), '/admin')
  assert.equal(signInReturnPath('https://evil.example', ''), '/admin')
  assert.equal(signInReturnPath('/\\evil.example/x', ''), '/admin')
  assert.equal(signInReturnPath('/%5Cevil.example', ''), '/admin')
  assert.equal(signInReturnPath('/admin/pages', `?q=${'x'.repeat(RETURN_PATH_MAX)}`), '/admin/pages')
})

console.log(`\n${n} checks passed`)
