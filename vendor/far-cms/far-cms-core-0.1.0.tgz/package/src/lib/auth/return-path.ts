/**
 * Where sign-in sends someone back to: the page they asked for, including
 * its query (?tab=submissions, ?set=…, ?section=…), so a link opened on a
 * phone lands on the right view after signing in. Same-site paths only.
 */
export const RETURN_PATH_MAX = 512

export function signInReturnPath(pathname: string, search: string): string {
  // '//' and '/\' are protocol-relative to browsers (another site): never a return path.
  if (!pathname.startsWith('/') || pathname.startsWith('//') || pathname.startsWith('/\\') || /%5c/i.test(pathname.slice(0, 4))) return '/admin'
  const full = `${pathname}${search.startsWith('?') && search.length > 1 ? search : ''}`
  return full.length <= RETURN_PATH_MAX ? full : pathname.slice(0, RETURN_PATH_MAX)
}
