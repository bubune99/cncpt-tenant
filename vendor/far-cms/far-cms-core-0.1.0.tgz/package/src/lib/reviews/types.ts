/**
 * Review filter and sort shapes, moved from Dzidzor's src/lib/reviews/index.ts (which queries the database and stays
 * in the app) so the pure rules in public.ts need no database code. Dzidzor's index.ts re-exports these.
 * ReviewStatus mirrors the Prisma enum of the same name (PENDING, APPROVED, REJECTED, FLAGGED).
 */
export type ReviewStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'FLAGGED';

export interface ReviewFilters {
  productId?: string;
  status?: ReviewStatus;
  rating?: number;
  minRating?: number;
  maxRating?: number;
  isVerifiedPurchase?: boolean;
  search?: string;
}

export interface ReviewSort {
  field: 'createdAt' | 'rating' | 'helpfulCount';
  direction: 'asc' | 'desc';
}
