/**
 * Run: npx -y tsx@4.23.15 src/lib/reviews/public.assert.ts
 */
import assert from 'node:assert/strict'
import { PUBLIC_REVIEW_FIELDS, reviewListQuery, safeReviewSort, toPublicReview } from './public'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const q = (s: string) => new URLSearchParams(s)

check('public listing: APPROVED only, whatever ?status= says (H-3)', () => {
  for (const status of ['PENDING', 'REJECTED', 'FLAGGED', 'APPROVED', '']) {
    assert.equal(reviewListQuery(q(`status=${status}`), false).filters.status, 'APPROVED', status)
  }
  // Staff keep the moderation filter (valid values only).
  assert.equal(reviewListQuery(q('status=PENDING'), true).filters.status, 'PENDING')
  assert.equal(reviewListQuery(q('status=anything'), true).filters.status, undefined)
})

check('sortBy only from the allow-list; direction only asc/desc (H-3 sort oracle)', () => {
  assert.deepEqual(reviewListQuery(q('sortBy=reviewerEmail&sortDir=asc'), false).sort, { field: 'createdAt', direction: 'asc' })
  assert.deepEqual(reviewListQuery(q('sortBy=ipAddress'), true).sort, { field: 'createdAt', direction: 'desc' })
  assert.deepEqual(safeReviewSort('rating', 'up'), { field: 'rating', direction: 'desc' })
  assert.deepEqual(safeReviewSort('constructor', 'asc', 'helpfulCount'), { field: 'helpfulCount', direction: 'asc' })
  assert.deepEqual(safeReviewSort('helpfulCount', 'asc'), { field: 'helpfulCount', direction: 'asc' })
})

check('public fields only: never email, IP address or browser (H-3)', () => {
  const row = {
    id: 'r1', productId: 'p1', customerId: 'c1', orderId: 'o1', reviewerName: 'Ama', reviewerEmail: 'ama@example.org', rating: 5, title: 'Great', content: 'Lovely',
    status: 'APPROVED', ipAddress: '203.0.113.7', userAgent: 'Mozilla/5.0', respondedById: 'u1', createdAt: '2026-10-01', helpfulCount: 2,
    product: { id: 'p1', title: 'Tee', slug: 'tee', images: [{ media: { url: 'x' } }] },
    customer: { id: 'c1', firstName: 'Ama', lastName: 'Mensah' },
  }
  const pub = toPublicReview(row)
  for (const secret of ['reviewerEmail', 'ipAddress', 'userAgent', 'customerId', 'orderId', 'respondedById', 'status', 'customer']) assert.ok(!(secret in pub), secret)
  assert.ok(!/ama@example|203\.0\.113|Mozilla|Mensah/.test(JSON.stringify(pub)))
  assert.deepEqual(pub.product, { id: 'p1', title: 'Tee', slug: 'tee' })
  assert.equal(pub.reviewerName, 'Ama')
  assert.ok(!(PUBLIC_REVIEW_FIELDS as readonly string[]).some((f) => /email|ip|agent/i.test(f)))
})

check('paging is bounded', () => {
  assert.deepEqual([reviewListQuery(q('page=-5&pageSize=999'), false).page, reviewListQuery(q('page=-5&pageSize=999'), false).pageSize], [1, 100])
  assert.deepEqual([reviewListQuery(q('page=abc&pageSize=x'), false).page, reviewListQuery(q(''), false).pageSize], [1, 10])
})

console.log(`\n${n} checks passed`)
