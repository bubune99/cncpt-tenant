/**
 * What anyone on the internet may see of product reviews: approved reviews
 * only, and only the fields a review shows on the shop (never the reviewer's
 * email, IP address or browser). Staff with the reviews permission keep the
 * full moderation view. Pure; asserted by public.assert.ts.
 */

import type { ReviewFilters, ReviewSort } from './types'

/** Sort fields a caller may ask for (anything else sorts by date). */
export const REVIEW_SORT_FIELDS: ReadonlyArray<ReviewSort['field']> = ['createdAt', 'rating', 'helpfulCount']

export function safeReviewSort(field: string | null | undefined, direction: string | null | undefined, fallback: ReviewSort['field'] = 'createdAt'): ReviewSort {
  return {
    field: (REVIEW_SORT_FIELDS as readonly string[]).includes(field ?? '') ? (field as ReviewSort['field']) : fallback,
    direction: direction === 'asc' ? 'asc' : 'desc',
  }
}

const int = (v: string | null, fallback: number, min: number, max: number) => {
  const n = v == null ? NaN : parseInt(v, 10)
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback
}

/**
 * The listing a GET /api/reviews asks for. `staff` (holds the reviews
 * permission) may filter by status; everyone else sees APPROVED only.
 */
export function reviewListQuery(params: { get(name: string): string | null }, staff: boolean): { filters: ReviewFilters; sort: ReviewSort; page: number; pageSize: number } {
  const filters: ReviewFilters = {}
  const productId = params.get('productId')
  if (productId) filters.productId = productId
  if (staff) {
    const status = params.get('status')
    if (status && ['PENDING', 'APPROVED', 'REJECTED', 'FLAGGED'].includes(status)) filters.status = status as ReviewFilters['status']
  } else {
    filters.status = 'APPROVED'
  }
  const rating = params.get('rating')
  if (rating) filters.rating = int(rating, 0, 1, 5)
  const minRating = params.get('minRating')
  if (minRating) filters.minRating = int(minRating, 1, 1, 5)
  const maxRating = params.get('maxRating')
  if (maxRating) filters.maxRating = int(maxRating, 5, 1, 5)
  const verified = params.get('verified')
  if (verified !== null) filters.isVerifiedPurchase = verified === 'true'
  const search = params.get('search')
  if (search) filters.search = search.slice(0, 200)
  return {
    filters,
    sort: safeReviewSort(params.get('sortBy'), params.get('sortDir')),
    page: int(params.get('page'), 1, 1, 10_000),
    pageSize: int(params.get('pageSize'), 10, 1, 100),
  }
}

/** The fields of a review the public may see. */
export const PUBLIC_REVIEW_FIELDS = [
  'id', 'productId', 'reviewerName', 'rating', 'title', 'content', 'pros', 'cons', 'images',
  'isVerifiedPurchase', 'helpfulCount', 'unhelpfulCount', 'responseContent', 'responseAt', 'createdAt', 'publishedAt',
] as const

export type PublicReview = { [K in (typeof PUBLIC_REVIEW_FIELDS)[number]]?: unknown } & { product?: { id: unknown; title: unknown; slug: unknown } }

/** A review as the public sees it: allow-listed fields only (plus the product's id, title and slug). */
export function toPublicReview(r: Record<string, unknown>): PublicReview {
  const out: Record<string, unknown> = {}
  for (const k of PUBLIC_REVIEW_FIELDS) if (k in r) out[k] = r[k]
  const p = r.product as Record<string, unknown> | undefined
  if (p && typeof p === 'object') out.product = { id: p.id, title: p.title, slug: p.slug }
  return out as PublicReview
}

/**
 * Whose review eligibility a product-reviews request may see. It says
 * whether that person already reviewed or bought the product, so it is
 * only ever for the signed-in person's own address: anonymous callers get
 * none, another address is refused, and a customer id from the address bar
 * is never trusted.
 */
export function eligibilityRequest(params: { get(name: string): string | null }, sessionEmail: string | null | undefined): { kind: 'none' } | { kind: 'forbidden' } | { kind: 'own'; email: string } {
  const asked = (params.get('email') ?? '').trim().toLowerCase()
  const wants = !!asked || params.get('userId') !== null || params.get('eligibility') === '1'
  if (!wants || !sessionEmail) return { kind: 'none' }
  const own = sessionEmail.trim().toLowerCase()
  if (asked && asked !== own) return { kind: 'forbidden' }
  return { kind: 'own', email: own }
}

/**
 * Who is voting on a review: the signed-in person, never an id or email the
 * request claims (anyone could invent emails to stuff votes). Null → refuse.
 */
export function voteIdentity(sessionUserId: string | null | undefined): { userId: string } | null {
  return sessionUserId ? { userId: sessionUserId } : null
}
