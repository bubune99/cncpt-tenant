/**
 * What a visitor's privacy choice allows us to record. Pure (no React, no
 * storage, no DB); asserted by consent-decision.assert.ts.
 *
 * Owner rule (2026-11-05): "if they say decline, we do not track anything".
 * Counting how many people pressed Decline is fine, as long as that count
 * carries nothing that identifies them.
 *
 * Where the choice lives:
 *  - the browser keeps the full record in localStorage (`cookie-consent`,
 *    lib/cookie-consent-store) — the banner reads that;
 *  - a small mirror cookie, CONSENT_COOKIE, tells the SERVER the same thing,
 *    so a beacon from a browser that declined is dropped even if something
 *    (an old tab, a forged request) still sends it. The mirror is part of
 *    remembering the choice, so it is an essential cookie.
 *
 * Global Privacy Control (`Sec-GPC: 1` / navigator.globalPrivacyControl) is
 * a decline, whatever the stored choice says. California treats it as a
 * valid opt-out; honouring it everywhere is the simple, safe reading.
 */

export type ConsentState = 'accepted' | 'declined' | 'undecided'

/** The mirror cookie's name. Values: CONSENT_COOKIE_VALUES. */
export const CONSENT_COOKIE = 'dz_consent'
export const CONSENT_COOKIE_VALUES = { accepted: 'a1', declined: 'a0' } as const
/** One year, like the stored choice; the banner asks again on a policy change anyway. */
export const CONSENT_COOKIE_MAX_AGE = 365 * 24 * 60 * 60

/** The mirror cookie's value for a choice. Only the Analytics switch matters here. */
export function consentCookieValue(choice: { analytics: boolean }): string {
  return choice.analytics ? CONSENT_COOKIE_VALUES.accepted : CONSENT_COOKIE_VALUES.declined
}

/** Read one cookie from a Cookie header ("a=1; b=2"). */
export function readCookie(header: string | null | undefined, name: string): string | null {
  if (!header) return null
  for (const part of header.split(';')) {
    const eq = part.indexOf('=')
    if (eq < 0) continue
    if (part.slice(0, eq).trim() === name) return part.slice(eq + 1).trim()
  }
  return null
}

/** The mirror cookie → the visitor's choice. Anything unknown is "no choice yet". */
export function consentFromCookie(value: string | null | undefined): ConsentState {
  if (value === CONSENT_COOKIE_VALUES.accepted) return 'accepted'
  if (value === CONSENT_COOKIE_VALUES.declined) return 'declined'
  return 'undecided'
}

/** The browser's stored record → the visitor's choice. */
export function consentFromStored(stored: { consent?: { analytics?: boolean } } | null | undefined): ConsentState {
  if (!stored || !stored.consent) return 'undecided'
  return stored.consent.analytics === true ? 'accepted' : 'declined'
}

/** `Sec-GPC: 1` (the header is exactly "1" when the signal is on). */
export function gpcFromHeader(value: string | null | undefined): boolean {
  return (value ?? '').trim() === '1'
}

export interface DecisionInput {
  consent: ConsentState
  /** Global Privacy Control is on. */
  gpc: boolean
  /** Settings › Cookie & privacy banner: record nothing until someone presses Accept. */
  trackOnlyAfterAccept: boolean
}

export type DecisionReason = 'gpc' | 'declined' | 'accepted' | 'undecided-anonymous' | 'undecided-wait'

export interface AnalyticsDecision {
  /** First-party page views (PageViewBeacon → AnalyticsEvent) and Vercel Web Analytics. */
  record: boolean
  /** A per-tab session id may be kept (device storage) — only with consent. */
  sessionId: boolean
  /** Third-party scripts (Google Analytics, Matomo, Plausible) — only with consent. */
  thirdParty: boolean
  reason: DecisionReason
}

const NOTHING = { record: false, sessionId: false, thirdParty: false } as const

/**
 * The one rule both the browser and the server follow.
 *
 *  - GPC on → nothing.
 *  - Declined → nothing.
 *  - Accepted → page views with a per-tab session id; third-party tools may load.
 *  - No choice yet → an anonymous page view (no session id, nothing on the
 *    device, no third-party tools), unless the site chose "track only after
 *    Accept", in which case nothing.
 */
export function analyticsDecision(input: DecisionInput): AnalyticsDecision {
  if (input.gpc) return { ...NOTHING, reason: 'gpc' }
  if (input.consent === 'declined') return { ...NOTHING, reason: 'declined' }
  if (input.consent === 'accepted') return { record: true, sessionId: true, thirdParty: true, reason: 'accepted' }
  if (input.trackOnlyAfterAccept) return { ...NOTHING, reason: 'undecided-wait' }
  return { record: true, sessionId: false, thirdParty: false, reason: 'undecided-anonymous' }
}

/** What the server does with an incoming beacon, decided from the request alone. */
export interface BeaconRequestFacts {
  cookieHeader: string | null | undefined
  secGpc: string | null | undefined
  trackOnlyAfterAccept: boolean
}

export interface BeaconVerdict {
  /** Write the event at all. */
  write: boolean
  /** Keep the session id / user id the body claims (only with consent). */
  keepIds: boolean
  reason: DecisionReason
}

/**
 * Server side of the rule. It trusts the request's cookie and GPC header,
 * never the body: a body that sends a session id from a browser that hasn't
 * accepted has the id dropped, and a declined browser writes nothing at all.
 */
export function beaconVerdict(facts: BeaconRequestFacts): BeaconVerdict {
  const d = analyticsDecision({
    consent: consentFromCookie(readCookie(facts.cookieHeader, CONSENT_COOKIE)),
    gpc: gpcFromHeader(facts.secGpc),
    trackOnlyAfterAccept: facts.trackOnlyAfterAccept,
  })
  return { write: d.record, keepIds: d.sessionId, reason: d.reason }
}

// ---------------------------------------------------------------------------
// The "declined tracking" counter
// ---------------------------------------------------------------------------

/** usage_counters kind for the Decline count (never pruned, never reset with AI limits). */
export const DECLINE_COUNTER_KIND = 'consent-declined'
/** A window so long the row never rolls over: one row per day, kept. */
export const DECLINE_COUNTER_WINDOW_MS = 100 * 365 * 24 * 60 * 60 * 1000

/** The UTC day a click falls on: "2026-11-05". */
export function dayKey(nowMs: number): string {
  return new Date(nowMs).toISOString().slice(0, 10)
}

/**
 * The whole of what one Decline click stores: which counter and which day.
 * There is deliberately no parameter for the request — no id, address,
 * hash, user agent or page can reach the row.
 */
export function declineCounterBump(nowMs: number): { kind: string; identity: string; windowMs: number; add: 1 } {
  return { kind: DECLINE_COUNTER_KIND, identity: `day:${dayKey(nowMs)}`, windowMs: DECLINE_COUNTER_WINDOW_MS, add: 1 }
}

/** The day rows to read for a date range (inclusive, UTC days), capped at ~13 months. */
export function declineDayIdentities(startMs: number, endMs: number, maxDays = 400): string[] {
  const out: string[] = []
  const day = 86_400_000
  const first = Date.UTC(new Date(startMs).getUTCFullYear(), new Date(startMs).getUTCMonth(), new Date(startMs).getUTCDate())
  for (let t = first; t <= endMs && out.length < maxDays; t += day) out.push(`day:${dayKey(t)}`)
  return out
}

/** Does this choice count as declining tracking? (Reject, or Choose with Analytics off.) */
export function isDecline(choice: { analytics: boolean }): boolean {
  return !choice.analytics
}

// ---------------------------------------------------------------------------
// Clearing analytics storage on decline
// ---------------------------------------------------------------------------

/** Our own per-tab analytics id (PageViewBeacon). */
export const SESSION_ID_KEY = 'ft-session-id'

/** Cookies analytics tools set: Google Analytics, Matomo, Hotjar, Meta, Google Ads. */
const ANALYTICS_COOKIE_RE = /^(_ga|_gid|_gat|_pk_|_hj|_fbp|_fbc|_gcl_|__utm|mtm_)/

/** Which of these cookie names are analytics cookies to delete on decline. */
export function analyticsCookiesToClear(names: ReadonlyArray<string>): string[] {
  return names.filter((n) => ANALYTICS_COOKIE_RE.test(n))
}
