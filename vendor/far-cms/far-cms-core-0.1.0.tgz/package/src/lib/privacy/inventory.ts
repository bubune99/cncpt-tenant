/**
 * Dzidzor's personal-data inventory — every table that holds something about
 * a person, why, for how long, who sees it, and what a "delete my data"
 * request does to it. The purge job, the subject export/delete and the
 * privacy-policy "What we collect" draft all read from here.
 *
 * Completeness is asserted (inventory.assert.ts): every personal-looking
 * field in prisma/schema.prisma is either listed here or in NOT_PERSONAL
 * with a reason.
 */

import type { InventoryEntry } from '../ade/privacy/inventory'

export const SUBMISSION_MONTHS = 24
export const AUDIT_MONTHS = 12
export const CHAT_DAYS = 90
export const ANALYTICS_MONTHS = 24
export const EMAIL_TRACKING_MONTHS = 24
/** Version history (lib/ade/history): long enough to undo last year's edits. */
export const HISTORY_MONTHS = 24

const ADMINS = 'Site admins'
const FORM_STAFF = 'Staff who handle form submissions'
const SHOP_STAFF = 'Staff who handle orders and customers'
const OWNER = 'The site owner (audit access)'

export const INVENTORY: readonly InventoryEntry[] = [
  // ── Forms ────────────────────────────────────────────────────────────
  {
    model: 'FormSubmission',
    fields: ['data', 'ipAddress', 'userAgent', 'notes'],
    category: 'Messages you send us through forms',
    kinds: ['answers to a form', 'name', 'email', 'phone', 'free text', 'IP address (hashed)', 'browser (family only)'],
    purpose: 'To answer you and do what you asked (volunteering, contact, sign-ups); the hashed address and browser help us stop spam.',
    retention: { kind: 'months', months: SUBMISSION_MONTHS, configurable: 'each form can set its own' },
    visibleTo: FORM_STAFF,
    onSubjectDelete: 'delete',
  },
  // ── Newsletter & email ───────────────────────────────────────────────
  {
    model: 'EmailSubscriber',
    fields: ['email', 'name', 'firstName', 'lastName', 'consentIp'],
    category: 'Newsletter sign-ups',
    kinds: ['email', 'name', 'IP address (hashed)'],
    purpose: 'To send the newsletter you asked for, and to show when and how you agreed.',
    retention: { kind: 'until-removed', note: 'until you unsubscribe or ask us to delete it' },
    visibleTo: 'Staff who send email',
    subjectEmailField: 'email',
    onSubjectDelete: 'delete',
    basis: 'Consent (double opt-in).',
  },
  {
    model: 'EmailSuppression',
    fields: ['emailHash'],
    category: 'Newsletter sign-ups',
    kinds: ['email (hashed)'],
    purpose: 'To make sure we never send marketing email to an address that unsubscribed, bounced, complained, or asked us to erase their data.',
    retention: { kind: 'until-removed', note: 'kept so an opt-out lasts — it holds only a keyed hash of the address, never the address itself' },
    visibleTo: 'Nobody (checked automatically before each marketing email)',
    onSubjectDelete: 'keep',
    basis: 'Legitimate interest / legal obligation: honouring “never email me again” after the rest of your data is erased. An erasure request adds the hash (source "erasure").',
  },
  {
    model: 'EmailRecipient',
    fields: ['email', 'name', 'data'],
    category: 'Emails we send you',
    kinds: ['email', 'name'],
    purpose: 'To deliver campaign emails and know which were delivered.',
    retention: { kind: 'months', months: EMAIL_TRACKING_MONTHS },
    visibleTo: 'Staff who send email',
    subjectEmailField: 'email',
    onSubjectDelete: 'delete',
  },
  {
    model: 'EmailLinkClick',
    fields: ['ipAddress', 'userAgent'],
    category: 'Emails we send you',
    kinds: ['IP address (hashed)', 'browser (family only)'],
    purpose: 'To count clicks on links in our emails.',
    retention: { kind: 'months', months: EMAIL_TRACKING_MONTHS },
    visibleTo: 'Staff who send email',
    onSubjectDelete: 'delete',
  },
  // ── Visits & consent ─────────────────────────────────────────────────
  {
    model: 'AnalyticsEvent',
    fields: ['userAgent', 'ipAddress', 'city'],
    category: 'Visits to the site',
    kinds: ['page visited', 'browser (family only)', 'IP address (hashed)', 'approximate location'],
    purpose: 'To see which pages are useful (only with your analytics consent), and to keep an anonymous record of each cookie choice.',
    retention: { kind: 'months', months: ANALYTICS_MONTHS, configurable: 'cookie choices are kept as the consent record' },
    visibleTo: ADMINS,
    onSubjectDelete: 'not-linkable',
    basis: 'Consent for analytics; cookie-choice records are kept to show consent was asked (no name or email in them).',
  },
  // ── Accounts & staff ─────────────────────────────────────────────────
  {
    model: 'User',
    fields: ['email', 'name', 'phone'],
    category: 'Accounts',
    kinds: ['name', 'email', 'phone', 'account id'],
    purpose: 'To let you sign in and know who made which change.',
    // Users › Remove user: access goes at once; the account is kept as long as the audit log (so it can still say
    // who did what), then deleted, or anonymised where their work stays (src/lib/users/removed-accounts.ts).
    retention: { kind: 'account', note: `access removed at once when someone is removed; the account is deleted ${AUDIT_MONTHS} months later (anonymised instead if their posts or files stay)` },
    visibleTo: ADMINS,
    subjectEmailField: 'email',
    onSubjectDelete: 'keep',
    basis: 'Close the account itself from Users (sign-in is handled by the sign-in provider).',
  },
  {
    model: 'AuditLog',
    fields: ['userEmail', 'ipAddress', 'userAgent'],
    category: 'Security records',
    kinds: ['email', 'IP address (hashed)', 'browser (family only)'],
    purpose: 'To keep the admin secure: who changed what, and when.',
    retention: { kind: 'months', months: AUDIT_MONTHS },
    visibleTo: OWNER,
    subjectEmailField: 'userEmail',
    onSubjectDelete: 'keep',
    basis: 'Legitimate interest in security; deleted after 12 months.',
  },
  { model: 'AdminUser', fields: ['email'], category: 'Accounts', kinds: ['email'], purpose: 'Platform admin sign-in.', retention: { kind: 'account', note: 'removed with the admin' }, visibleTo: ADMINS, subjectEmailField: 'email', onSubjectDelete: 'keep' },
  { model: 'SuperAdmin', fields: ['email'], category: 'Accounts', kinds: ['email'], purpose: 'Platform owner sign-in.', retention: { kind: 'account', note: 'removed with the owner' }, visibleTo: ADMINS, subjectEmailField: 'email', onSubjectDelete: 'keep' },
  { model: 'TeamInvitation', fields: ['email'], category: 'Accounts', kinds: ['email'], purpose: 'To invite someone to the admin.', retention: { kind: 'until-removed', note: 'until accepted or withdrawn' }, visibleTo: ADMINS, subjectEmailField: 'email', onSubjectDelete: 'delete' },
  { model: 'Team', fields: ['name', 'billingEmail'], category: 'Accounts', kinds: ['email'], purpose: 'Billing contact for a team workspace.', retention: { kind: 'account', note: 'removed with the team' }, visibleTo: ADMINS, onSubjectDelete: 'keep' },
  { model: 'PlatformActivityLog', fields: ['actorEmail', 'ipAddress', 'userAgent'], category: 'Security records', kinds: ['email', 'IP address (hashed)', 'browser (family only)'], purpose: 'Platform-level security record.', retention: { kind: 'months', months: AUDIT_MONTHS }, visibleTo: OWNER, subjectEmailField: 'actorEmail', onSubjectDelete: 'keep' },
  { model: 'PageRevision', fields: ['createdByEmail'], category: 'Security records', kinds: ['email'], purpose: 'Who saved each version of a page.', retention: { kind: 'until-removed', note: 'kept with the page history' }, visibleTo: ADMINS, onSubjectDelete: 'keep' },
  { model: 'AdeChangeComment', fields: ['authorEmail'], category: 'Security records', kinds: ['email'], purpose: 'Who commented on a change waiting for review.', retention: { kind: 'until-removed', note: 'kept with the change' }, visibleTo: ADMINS, onSubjectDelete: 'keep' },
  // ── The assistant ────────────────────────────────────────────────────
  {
    model: 'AiMessage',
    fields: ['content', 'parts'],
    category: 'Conversations with the site assistant (staff)',
    kinds: ['chat messages'],
    purpose: 'So staff can continue a conversation with the assistant.',
    retention: { kind: 'days', days: CHAT_DAYS },
    visibleTo: 'The staff member who had the conversation',
    onSubjectDelete: 'delete',
  },
  // ── Feedback to the site owner (staff) ────────────────────────────────
  {
    model: 'ClientFeedback',
    fields: ['note', 'senderName', 'route', 'screen', 'unitRef'],
    category: 'Feedback you send the site owner from the admin (staff)',
    kinds: ['free text', 'name', 'page visited'],
    purpose: 'So the site owner can fix what you reported. A copy goes to the owner’s project planner and email inbox (note, screen, your display name — never your email address).',
    retention: { kind: 'until-removed', note: 'until the owner deletes it, or you ask us to delete your data (copies already sent to the owner’s planner and inbox are theirs to delete)' },
    visibleTo: 'The site owner and admins with General settings; you',
    onSubjectDelete: 'delete',
  },
  {
    model: 'FeedbackScreenshot',
    fields: ['bytes'],
    category: 'Feedback you send the site owner from the admin (staff)',
    kinds: ['screenshot'],
    purpose: 'A picture of the part of the screen your feedback is about. Stored privately — never in the public media library.',
    retention: { kind: 'until-removed', note: 'deleted with the feedback, or when you ask us to delete your data' },
    visibleTo: 'The site owner and admins with General settings; you',
    onSubjectDelete: 'delete',
  },
  {
    model: 'AgentRun',
    fields: ['request', 'error'],
    category: 'Conversations with the site assistant (staff)',
    kinds: ['free text'],
    purpose: 'Agent activity: what the assistant did on each request (steps, tools, cost), so staff can check and trust its work.',
    retention: { kind: 'days', days: CHAT_DAYS },
    visibleTo: 'Staff who can read the audit log',
    onSubjectDelete: 'delete',
    basis: 'Requests are stored redacted (emails, phone numbers and long numbers masked) and capped at 200 characters.',
  },
  {
    model: 'AgentSpan',
    fields: ['inputRedacted', 'outputSummary', 'detail'],
    category: 'Conversations with the site assistant (staff)',
    kinds: ['free text'],
    purpose: 'The steps of one assistant run — tool inputs redacted like the audit log, outputs as one line.',
    retention: { kind: 'until-removed', note: `deleted with its run (${CHAT_DAYS} days)` },
    visibleTo: 'Staff who can read the audit log',
    onSubjectDelete: 'delete',
  },
  {
    model: 'AdeWait',
    fields: ['step', 'output'],
    category: 'Conversations with the site assistant (staff)',
    kinds: ['free text'],
    purpose: 'A walk-through step or question waiting on you, so the assistant continues only when you answer. Stores what the step showed and what you pressed (Got it, Next, Skip…), never a password or token.',
    retention: { kind: 'days', days: CHAT_DAYS },
    visibleTo: 'You',
    onSubjectDelete: 'delete',
    basis: 'Only a one-way hash of the one-time token is kept; a step expires after 24 hours.',
  },
  {
    model: 'AdeRevision',
    fields: ['before', 'after'],
    category: 'Version history (staff edits)',
    kinds: ['free text'],
    purpose: 'Earlier versions of what staff and the assistant changed (forms, settings, pages…), so a change can be seen and undone.',
    retention: { kind: 'months', months: HISTORY_MONTHS },
    visibleTo: 'Staff who can edit the item (personal details masked unless they may see them)',
    onSubjectDelete: 'keep',
    basis: 'Only the fields that changed are kept; secrets (passwords, keys) are never stored, only that they changed. A person\'s access history (their roles and exceptions) stays after their account is closed until this period ends: it holds role ids and permission names only, no personal details.',
  },
  { model: 'AiDocument', fields: ['content'], category: 'Conversations with the site assistant (staff)', kinds: ['free text'], purpose: 'Documents a staff member drafted with the assistant.', retention: { kind: 'until-removed', note: 'until its author deletes it' }, visibleTo: 'The staff member who wrote it', onSubjectDelete: 'delete' },
  // ── Shop (only while the shop is on) ─────────────────────────────────
  { model: 'Customer', fields: ['email', 'firstName', 'lastName', 'phone', 'notes'], category: 'Shop customers', kinds: ['name', 'email', 'phone'], purpose: 'To handle your orders.', retention: { kind: 'account', note: 'while you are a customer' }, visibleTo: SHOP_STAFF, subjectEmailField: 'email', onSubjectDelete: 'anonymise' },
  { model: 'CustomerAddress', fields: ['firstName', 'lastName', 'street1', 'street2', 'city', 'postalCode', 'phone'], category: 'Shop customers', kinds: ['name', 'postal address', 'phone'], purpose: 'Saved delivery addresses.', retention: { kind: 'account', note: 'while you are a customer' }, visibleTo: SHOP_STAFF, onSubjectDelete: 'delete' },
  { model: 'Order', fields: ['email', 'customerNotes'], category: 'Orders and payments', kinds: ['email', 'free text', 'payment reference'], purpose: 'To fulfil orders and keep the accounts.', retention: { kind: 'legal', note: 'tax and accounting records' }, visibleTo: SHOP_STAFF, subjectEmailField: 'email', onSubjectDelete: 'keep' },
  { model: 'Address', fields: ['firstName', 'lastName', 'street1', 'street2', 'city', 'zip', 'phone'], category: 'Orders and payments', kinds: ['name', 'postal address', 'phone'], purpose: 'Shipping and billing addresses on orders.', retention: { kind: 'legal', note: 'kept with the order' }, visibleTo: SHOP_STAFF, onSubjectDelete: 'keep' },
  { model: 'Payment', fields: ['customerEmail'], category: 'Orders and payments', kinds: ['email', 'payment reference'], purpose: 'Payment records (card details stay with the payment provider).', retention: { kind: 'legal', note: 'tax and accounting records' }, visibleTo: SHOP_STAFF, subjectEmailField: 'customerEmail', onSubjectDelete: 'keep' },
  { model: 'GiftCard', fields: ['purchaserEmail', 'recipientEmail', 'recipientName', 'personalMessage'], category: 'Orders and payments', kinds: ['name', 'email', 'free text'], purpose: 'Gift cards and store credit (a balance is money).', retention: { kind: 'legal', note: 'while the balance can be used' }, visibleTo: SHOP_STAFF, subjectEmailField: 'recipientEmail', onSubjectDelete: 'keep' },
  { model: 'LicenseKey', fields: ['assignedEmail'], category: 'Orders and payments', kinds: ['email'], purpose: 'Who a purchased licence belongs to.', retention: { kind: 'legal', note: 'kept with the purchase' }, visibleTo: SHOP_STAFF, subjectEmailField: 'assignedEmail', onSubjectDelete: 'keep' },
  { model: 'DigitalDownload', fields: ['customerEmail'], category: 'Orders and payments', kinds: ['email'], purpose: 'Download links for purchases.', retention: { kind: 'legal', note: 'kept with the purchase' }, visibleTo: SHOP_STAFF, subjectEmailField: 'customerEmail', onSubjectDelete: 'keep' },
  { model: 'DiscountUsage', fields: ['email'], category: 'Orders and payments', kinds: ['email'], purpose: 'To enforce one-per-person discount codes.', retention: { kind: 'legal', note: 'kept with the order' }, visibleTo: SHOP_STAFF, subjectEmailField: 'email', onSubjectDelete: 'keep' },
  { model: 'Cart', fields: ['email'], category: 'Shop customers', kinds: ['email'], purpose: 'To keep your basket while you shop.', retention: { kind: 'until-removed', note: 'until checkout or it expires' }, visibleTo: SHOP_STAFF, subjectEmailField: 'email', onSubjectDelete: 'delete' },
  { model: 'BackInStockSubscription', fields: ['email'], category: 'Shop customers', kinds: ['email'], purpose: 'To tell you when an item is back.', retention: { kind: 'until-removed', note: 'until we email you' }, visibleTo: SHOP_STAFF, subjectEmailField: 'email', onSubjectDelete: 'delete' },
  // ── Comments, reviews, events ────────────────────────────────────────
  { model: 'BlogComment', fields: ['guestEmail', 'content', 'ipAddress', 'userAgent'], category: 'Comments and reviews', kinds: ['email', 'free text', 'IP address (hashed)', 'browser (family only)'], purpose: 'To show your comment and stop spam.', retention: { kind: 'until-removed', note: 'until removed' }, visibleTo: ADMINS, subjectEmailField: 'guestEmail', onSubjectDelete: 'delete' },
  { model: 'ProductReview', fields: ['reviewerEmail', 'content', 'ipAddress', 'userAgent'], category: 'Comments and reviews', kinds: ['email', 'free text', 'IP address (hashed)', 'browser (family only)'], purpose: 'To show your review and stop spam.', retention: { kind: 'until-removed', note: 'until removed' }, visibleTo: SHOP_STAFF, subjectEmailField: 'reviewerEmail', onSubjectDelete: 'delete' },
  { model: 'ReviewVote', fields: ['email'], category: 'Comments and reviews', kinds: ['email'], purpose: 'One "helpful" vote per person.', retention: { kind: 'until-removed', note: 'kept with the review' }, visibleTo: SHOP_STAFF, subjectEmailField: 'email', onSubjectDelete: 'delete' },
  { model: 'EventRegistration', fields: ['attendeeEmail', 'attendeePhone', 'notes'], category: 'Event registrations', kinds: ['name', 'email', 'phone', 'free text'], purpose: 'To manage your place at an event.', retention: { kind: 'until-removed', note: 'until removed after the event' }, visibleTo: ADMINS, subjectEmailField: 'attendeeEmail', onSubjectDelete: 'delete' },
  { model: 'OrderProgress', fields: ['notes'], category: 'Orders and payments', kinds: ['free text'], purpose: 'Staff notes on an order’s progress.', retention: { kind: 'legal', note: 'kept with the order' }, visibleTo: SHOP_STAFF, onSubjectDelete: 'keep' },
]

/**
 * Personal-looking fields that are NOT about a member of the public — site
 * content, product/category names, the organisation's own contact details.
 */
export const NOT_PERSONAL: ReadonlySet<string> = new Set([
  // Names of things, not people.
  ...['Role', 'ApiKey', 'McpServer', 'ProductOption', 'CustomField', 'Category', 'DigitalAsset', 'OrderWorkflow', 'OrderWorkflowStage', 'MediaFolder', 'MediaTag', 'Primitive', 'Plugin', 'Workflow', 'WorkflowTemplate', 'WorkflowStep', 'EmailAutomation', 'EmailSegment', 'Form', 'BlogCategory', 'BlogTag', 'Wishlist', 'PageBundle', 'CustomAnimation', 'CustomComponent', 'SubscriptionTier', 'EventTicketType', 'CmsModule'].map((m) => `${m}.name`),
  // Published site content and templates.
  'Page.content', 'PageRevision.content', 'Partial.name', 'Partial.content', 'BlogPost.content', 'TenantPost.content', 'TenantPage.content', 'EmailTemplate.name', 'EmailTemplate.content', 'PuckTemplate.name', 'PuckTemplate.content', 'EmailCampaign.name', 'EmailCampaign.content', 'AdeRecord.data',
  // Public speaker names shown on an event page (published content).
  'EventSpeaker.name',
  // The organisation's own contact details and senders.
  'SiteSettings.contactEmail', 'SiteSettings.contactPhone', 'EmailCampaign.fromEmail', 'Event.organizerEmail',
])

export function entryFor(model: string): InventoryEntry | undefined {
  return INVENTORY.find((e) => e.model === model)
}
