/**
 * Run: npx -y tsx@4.23.15 src/lib/privacy/consent-decision.assert.ts
 */
import assert from 'node:assert/strict'
import {
  CONSENT_COOKIE,
  DECLINE_COUNTER_KIND,
  analyticsCookiesToClear,
  analyticsDecision,
  beaconVerdict,
  consentCookieValue,
  consentFromCookie,
  consentFromStored,
  declineCounterBump,
  declineDayIdentities,
  gpcFromHeader,
  isDecline,
  readCookie,
} from './consent-decision'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const declinedCookie = `theme=dark; ${CONSENT_COOKIE}=${consentCookieValue({ analytics: false })}; other=1`
const acceptedCookie = `${CONSENT_COOKIE}=${consentCookieValue({ analytics: true })}`

check('declined: nothing is recorded, no session id, no third-party tools', () => {
  const d = analyticsDecision({ consent: 'declined', gpc: false, trackOnlyAfterAccept: false })
  assert.deepEqual(d, { record: false, sessionId: false, thirdParty: false, reason: 'declined' })
})

check('GPC on: nothing is recorded, even if the visitor once pressed Accept', () => {
  for (const consent of ['accepted', 'declined', 'undecided'] as const) {
    const d = analyticsDecision({ consent, gpc: true, trackOnlyAfterAccept: false })
    assert.equal(d.record, false)
    assert.equal(d.sessionId, false)
    assert.equal(d.thirdParty, false)
    assert.equal(d.reason, 'gpc')
  }
  assert.equal(gpcFromHeader('1'), true)
  assert.equal(gpcFromHeader(' 1 '), true)
  assert.equal(gpcFromHeader('0'), false)
  assert.equal(gpcFromHeader(null), false)
})

check('undecided (default setting): an anonymous page view only — no session id, no third-party tools', () => {
  const d = analyticsDecision({ consent: 'undecided', gpc: false, trackOnlyAfterAccept: false })
  assert.deepEqual(d, { record: true, sessionId: false, thirdParty: false, reason: 'undecided-anonymous' })
})

check('undecided with "track only after Accept": nothing', () => {
  const d = analyticsDecision({ consent: 'undecided', gpc: false, trackOnlyAfterAccept: true })
  assert.equal(d.record, false)
  assert.equal(d.reason, 'undecided-wait')
})

check('accepted: page views with a session id; third-party tools may load', () => {
  const d = analyticsDecision({ consent: 'accepted', gpc: false, trackOnlyAfterAccept: true })
  assert.deepEqual(d, { record: true, sessionId: true, thirdParty: true, reason: 'accepted' })
})

check('server: a forged beacon from a declined browser writes nothing (the cookie wins, not the body)', () => {
  const v = beaconVerdict({ cookieHeader: declinedCookie, secGpc: null, trackOnlyAfterAccept: false })
  assert.equal(v.write, false)
  assert.equal(v.keepIds, false)
})

check('server: GPC header alone stops the write, with or without a cookie', () => {
  assert.equal(beaconVerdict({ cookieHeader: acceptedCookie, secGpc: '1', trackOnlyAfterAccept: false }).write, false)
  assert.equal(beaconVerdict({ cookieHeader: null, secGpc: '1', trackOnlyAfterAccept: false }).write, false)
})

check('server: no cookie = undecided: written without ids (a body session id is dropped)', () => {
  assert.deepEqual(beaconVerdict({ cookieHeader: 'theme=dark', secGpc: null, trackOnlyAfterAccept: false }), { write: true, keepIds: false, reason: 'undecided-anonymous' })
  assert.equal(beaconVerdict({ cookieHeader: null, secGpc: null, trackOnlyAfterAccept: true }).write, false)
})

check('server: accepted cookie keeps the session id', () => {
  assert.deepEqual(beaconVerdict({ cookieHeader: acceptedCookie, secGpc: null, trackOnlyAfterAccept: false }), { write: true, keepIds: true, reason: 'accepted' })
})

check('cookie parsing: exact name only; unknown values are "no choice yet"', () => {
  assert.equal(readCookie(declinedCookie, CONSENT_COOKIE), 'a0')
  assert.equal(readCookie(`x${CONSENT_COOKIE}=a1`, CONSENT_COOKIE), null)
  assert.equal(consentFromCookie('a1'), 'accepted')
  assert.equal(consentFromCookie('a0'), 'declined')
  assert.equal(consentFromCookie('yes'), 'undecided')
  assert.equal(consentFromCookie(null), 'undecided')
})

check('stored record → state (what the browser decides with)', () => {
  assert.equal(consentFromStored(null), 'undecided')
  assert.equal(consentFromStored({ consent: { analytics: true } }), 'accepted')
  assert.equal(consentFromStored({ consent: { analytics: false } }), 'declined')
  assert.equal(consentFromStored({ consent: {} }), 'declined')
})

check('decline counter stores nothing identifying: only a counter name and a UTC day', () => {
  const bump = declineCounterBump(Date.UTC(2026, 10, 5, 23, 59))
  assert.deepEqual(Object.keys(bump).sort(), ['add', 'identity', 'kind', 'windowMs'])
  assert.equal(bump.kind, DECLINE_COUNTER_KIND)
  assert.equal(bump.identity, 'day:2026-11-05')
  assert.equal(bump.add, 1)
  // The function takes only a time: there is no way to pass a request, id, IP, hash, UA or URL in.
  assert.equal(declineCounterBump.length, 1)
  assert.ok(/^day:\d{4}-\d{2}-\d{2}$/.test(bump.identity))
})

check('decline counter: two people on the same day share one row', () => {
  const a = declineCounterBump(Date.UTC(2026, 10, 5, 1))
  const b = declineCounterBump(Date.UTC(2026, 10, 5, 22))
  assert.equal(a.identity, b.identity)
})

check('decline days for a range: inclusive, capped', () => {
  assert.deepEqual(declineDayIdentities(Date.UTC(2026, 10, 3, 15), Date.UTC(2026, 10, 5, 9)), ['day:2026-11-03', 'day:2026-11-04', 'day:2026-11-05'])
  assert.equal(declineDayIdentities(0, Date.UTC(2030, 0, 1)).length, 400)
})

check('what counts as declining: Reject, or Choose with Analytics off', () => {
  assert.equal(isDecline({ analytics: false }), true)
  assert.equal(isDecline({ analytics: true }), false)
})

check('on decline, analytics cookies are cleared — not the consent cookie or sign-in', () => {
  const names = ['_ga', '_ga_ABC123', '_gid', '_pk_id.1.abcd', '_fbp', CONSENT_COOKIE, 'stack-refresh-x', 'theme']
  assert.deepEqual(analyticsCookiesToClear(names), ['_ga', '_ga_ABC123', '_gid', '_pk_id.1.abcd', '_fbp'])
})

console.log(`\n${n} checks passed`)
