/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/inbox.assert.ts
 */
import assert from 'node:assert/strict'
import { actionKey } from './automations'
import { csvCell, inTab, inboxStatus, matchesAnswer, matchesSearch, messageOf, planBulk, stepDelayMs, submissionsCsv, tabCounts } from './inbox'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const FIELDS = [
  { id: 'name', type: 'text', label: 'Name' },
  { id: 'email', type: 'email', label: 'Email' },
  { id: 'message', type: 'textarea', label: 'Message' },
  { id: 'news', type: 'checkbox', label: 'Keep me posted' },
]
const row = (id: string, x: Record<string, unknown> = {}) => ({ id, data: {}, status: 'new', read: false, starred: false, createdAt: '2026-10-09T09:14:00.000Z', ...x })

check('status: legacy read flag understood; archived only under Archived', () => {
  assert.equal(inboxStatus({ status: 'new', read: true }), 'read')
  assert.equal(inboxStatus({ status: 'replied', read: true }), 'replied')
  const rows = [row('a'), row('b', { read: true, starred: true }), row('c', { status: 'replied' }), row('d', { status: 'archived', starred: true })]
  assert.deepEqual(tabCounts(rows), { all: 3, new: 1, starred: 1, replied: 1, archived: 1 })
  assert.equal(inTab(rows[3], 'starred'), false)
})

check('search and filter by answer', () => {
  const r = row('a', { data: { name: 'Kwame Owusu', message: 'Interested in the next trip' } })
  assert.equal(matchesSearch(r, 'kwame'), true)
  assert.equal(matchesSearch(r, 'TRIP'), true)
  assert.equal(matchesSearch(r, 'zzz'), false)
  assert.equal(matchesAnswer(r, { fieldId: 'message', op: 'contains', value: 'trip' }), true)
  assert.equal(matchesAnswer(r, { fieldId: 'message', op: 'contains', value: 'sponsor' }), false)
  assert.equal(messageOf(FIELDS, r.data), 'Interested in the next trip')
})

check('CSV: quoted, formulas neutralised, one row per submission', () => {
  assert.equal(csvCell('=HYPERLINK("x")'), `"'=HYPERLINK(""x"")"`)
  assert.equal(csvCell('a,b'), '"a,b"')
  assert.equal(csvCell('-5'), "'-5")
  const csv = submissionsCsv(FIELDS, [row('a', { data: { name: 'Ama', email: 'ama@example.com', message: 'Hi\nthere', news: true }, starred: true })])
  const lines = csv.trim().split('\r\n')
  assert.equal(lines[0], 'Received,Status,Starred,Name,Email,Message,Keep me posted')
  assert.equal(lines[1], '2026-10-09T09:14:00.000Z,new,yes,Ama,ama@example.com,"Hi\nthere",true')
})

check('bulk plan: per-row outcome — will run / skipped (no consent) / already got it', () => {
  const promo = { type: 'promo_email' as const, params: { template: 'spring' } }
  const subs = [
    { id: 'ama', data: { name: 'Ama Mensah', email: 'ama@example.com', news: true }, done: new Set<string>() },
    { id: 'kwame', data: { name: 'Kwame', email: 'kwame@example.com', news: true }, done: new Set([actionKey(promo)]) },
    { id: 'sarah', data: { name: 'Sarah Lee', email: 'sarah@example.com', news: false }, done: new Set<string>() },
  ]
  const plan = planBulk(FIELDS, subs, [promo], { commerceEnabled: false, sendsEmail: (t) => t.includes('email') })
  assert.deepEqual(plan.rows.map((r) => r.verdict.label), ['Will run', 'Already got it — skipped', 'Skipped — didn’t agree to marketing'])
  assert.deepEqual([plan.willRun, plan.skipped, plan.approvals, plan.emails], [1, 2, 0, 1])
  const money = planBulk(FIELDS, subs.slice(0, 1), [{ type: 'store_credit', params: { amount: '5' } }], { commerceEnabled: true, sendsEmail: () => false })
  assert.equal(money.rows[0].verdict.kind, 'approval')
  assert.equal(stepDelayMs(10), 12_000)
  assert.equal(stepDelayMs(0), 300)
})

console.log(`\n${n} checks passed`)
