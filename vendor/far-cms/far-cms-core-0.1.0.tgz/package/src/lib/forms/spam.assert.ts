/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/spam.assert.ts
 */
import assert from 'node:assert/strict'
import {
  HONEYPOT_FIELD,
  MIN_FILL_MS,
  RATE_MAX_PER_WINDOW,
  captchaDecision,
  checkFormToken,
  hashIp,
  isProductionEnv,
  issueFormToken,
  rateDecision,
  rateKey,
  spamGate,
  spamStatus,
  stripSpamFields,
} from './spam'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const KEYS = { siteKey: 'site', secretKey: 'secret' }
const NONE = { siteKey: '', secretKey: '' }
const SECRET = 'test-secret'
const T0 = 1_760_000_000_000
const goodToken = () => checkFormToken(issueFormToken('f1', T0, SECRET), 'f1', T0 + 10_000, SECRET)
const gate = (x: Partial<Parameters<typeof spamGate>[0]>) =>
  spamGate({ rateCount: 1, now: T0 + 10_000, body: {}, token: goodToken(), captcha: { kind: 'verify' }, ...x })

check('production is Vercel production (or a non-Vercel production build), never a preview', () => {
  assert.equal(isProductionEnv({ VERCEL_ENV: 'production', NODE_ENV: 'production' }), true)
  assert.equal(isProductionEnv({ VERCEL_ENV: 'preview', NODE_ENV: 'production' }), false)
  assert.equal(isProductionEnv({ NODE_ENV: 'production' }), true)
  assert.equal(isProductionEnv({ NODE_ENV: 'development' }), false)
})

check('missing keys in production → closed (with the owner alerted); in dev → allowed with a warning', () => {
  const prod = captchaDecision({ formWantsCaptcha: true, config: { siteKey: 'site', secretKey: '' }, production: true })
  assert.deepEqual(prod, { kind: 'closed', missing: ['secret key'] })
  const r = gate({ captcha: prod })
  assert.ok(r.action === 'reject' && r.status === 503 && r.alertOwner && /site owner has been told/.test(r.message))
  const dev = captchaDecision({ formWantsCaptcha: true, config: NONE, production: false })
  assert.deepEqual(dev, { kind: 'skip', reason: 'not-configured-dev' })
  const d = gate({ captcha: dev })
  assert.ok(d.action === 'continue' && !d.verifyCaptcha && d.warn)
  assert.deepEqual(captchaDecision({ formWantsCaptcha: true, config: KEYS, production: true }), { kind: 'verify' })
  assert.equal(spamStatus(NONE, true).state, 'missing')
  assert.deepEqual(spamStatus({ siteKey: 'x', secretKey: '' }, false).missing, ['secret key'])
})

check('per-form toggle off → Turnstile skipped, but honeypot and rate limit still apply', () => {
  const off = captchaDecision({ formWantsCaptcha: false, config: NONE, production: true })
  assert.deepEqual(off, { kind: 'skip', reason: 'form-off' })
  const ok = gate({ captcha: off })
  assert.ok(ok.action === 'continue' && !ok.verifyCaptcha && !ok.warn)
  assert.equal(gate({ captcha: off, body: { [HONEYPOT_FIELD]: 'http://spam.example' } }).action, 'silent-accept')
  const limited = gate({ captcha: off, rateCount: RATE_MAX_PER_WINDOW + 1 })
  assert.ok(limited.action === 'reject' && limited.status === 429)
})

check('honeypot filled → silent accept (nothing stored), and the hidden fields are never stored', () => {
  assert.equal(gate({ body: { [HONEYPOT_FIELD]: 'x' } }).action, 'silent-accept')
  assert.equal(gate({ body: { [HONEYPOT_FIELD]: '' } }).action, 'continue')
  assert.deepEqual(stripSpamFields({ email: 'a@example.com', [HONEYPOT_FIELD]: '', _ft: 't', captchaToken: 'c', 'cf-turnstile-response': 'c' }), { email: 'a@example.com' })
})

check('time token: too fast, tampered, other form, missing, expired', () => {
  const tok = issueFormToken('f1', T0, SECRET)
  assert.deepEqual(checkFormToken(tok, 'f1', T0 + MIN_FILL_MS - 1, SECRET), { ok: false, reason: 'too_fast' })
  assert.deepEqual(checkFormToken(tok, 'f1', T0 + MIN_FILL_MS + 1, SECRET), { ok: true })
  assert.deepEqual(checkFormToken(tok, 'f2', T0 + 10_000, SECRET), { ok: false, reason: 'bad' })
  assert.deepEqual(checkFormToken(`${T0 - 60_000}.${tok.split('.')[1]}`, 'f1', T0 + 10_000, SECRET), { ok: false, reason: 'bad' })
  assert.deepEqual(checkFormToken(undefined, 'f1', T0, SECRET), { ok: false, reason: 'missing' })
  assert.deepEqual(checkFormToken(tok, 'f1', T0 + 2 * 86_400_000, SECRET), { ok: false, reason: 'expired' })
  const fast = gate({ token: checkFormToken(tok, 'f1', T0 + 500, SECRET) })
  assert.ok(fast.action === 'reject' && fast.status === 400)
})

check('rate limit: the 6th in a window → 429 with Retry-After; IPs are hashed', () => {
  assert.deepEqual(rateDecision(RATE_MAX_PER_WINDOW, T0), { allowed: true })
  const r = rateDecision(RATE_MAX_PER_WINDOW + 1, T0)
  assert.ok(!r.allowed && r.retryAfterSeconds > 0 && r.retryAfterSeconds <= 600)
  const h = hashIp('203.0.113.7', SECRET)
  assert.equal(h.length, 32)
  assert.ok(!h.includes('203'))
  assert.equal(hashIp(' 203.0.113.7 ', SECRET), h)
  assert.notEqual(rateKey(h, 'f1', T0), rateKey(h, 'f2', T0))
  // The limit is checked before anything else (a flood can't probe the honeypot).
  assert.equal(gate({ rateCount: 99, body: { [HONEYPOT_FIELD]: 'x' } }).action, 'reject')
})

console.log(`\n${n} checks passed`)
