/**
 * A form as one editable document — what the builder edits and what a
 * draft stores (before/after) for review. Pure; asserted by doc.assert.ts.
 */

import { normalizeRules, ruleChanges, type FormRule } from './automations'
import { validMonths } from '../ade/privacy/retention'
import { stableJson } from '../ade/history/revisions'
import { sameValue } from '../ade/history/revisions'

export type FieldWidth = 'full' | 'half'
export type ShowAs = 'page' | 'popup' | 'slidein'
export type OpensOn = 'click' | 'delay' | 'scroll' | 'exit'

export interface FormDocField {
  id: string
  /** The key the site sends this answer under, when it differs from the id (forms started from a kind). */
  name?: string
  type: string
  label: string
  placeholder?: string
  /** Help text under the field. */
  description?: string
  required: boolean
  width: FieldWidth
  options?: string[]
}

export interface FormPlacement {
  showAs: ShowAs
  opens: OpensOn
  /** For opens = delay: seconds. */
  delaySeconds: number
  /** Once closed, stay closed this many days. */
  rememberClosedDays: number
}

export interface FormDoc {
  name: string
  description: string
  status: 'DRAFT' | 'ACTIVE' | 'ARCHIVED'
  submitButtonText: string
  successMessage: string
  notifyEmails: string[]
  fields: FormDocField[]
  placement: FormPlacement
  /** What happens after someone submits (lib/forms/automations). */
  automations: FormRule[]
  /** Check visitors with Cloudflare Turnstile (lib/forms/spam). On by default. */
  spamProtection: boolean
  /** Keep submissions this many months; null = the site default (24). */
  retentionMonths: number | null
}

export const FIELD_TYPES: ReadonlyArray<{ type: string; label: string; hasOptions?: boolean }> = [
  { type: 'text', label: 'Short text' },
  { type: 'email', label: 'Email' },
  { type: 'phone', label: 'Phone' },
  { type: 'textarea', label: 'Long text' },
  { type: 'select', label: 'Dropdown', hasOptions: true },
  { type: 'multiselect', label: 'Checkboxes', hasOptions: true },
  { type: 'radio', label: 'Choice', hasOptions: true },
  { type: 'date', label: 'Date' },
  { type: 'number', label: 'Number' },
  { type: 'checkbox', label: 'Yes / No' },
]

const DEFAULT_PLACEMENT: FormPlacement = { showAs: 'page', opens: 'delay', delaySeconds: 5, rememberClosedDays: 7 }

const str = (v: unknown, max = 500) => (typeof v === 'string' ? v.slice(0, max) : '')
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** The stored `display` JSON ↔ placement (legacy inline|popup + new slide-in/opens). */
export function placementFrom(display: unknown): FormPlacement {
  const d = (display && typeof display === 'object' ? display : {}) as Record<string, unknown>
  const showAs: ShowAs = d.showAs === 'popup' || d.showAs === 'slidein' ? d.showAs : d.mode === 'popup' ? 'popup' : 'page'
  const opens: OpensOn = d.opens === 'click' || d.opens === 'scroll' || d.opens === 'exit' ? d.opens : 'delay'
  const delay = Number(d.delaySeconds ?? d.popupDelay)
  const days = Number(d.rememberClosedDays)
  return {
    showAs,
    opens,
    delaySeconds: Number.isFinite(delay) && delay >= 0 && delay <= 600 ? Math.round(delay) : DEFAULT_PLACEMENT.delaySeconds,
    rememberClosedDays: Number.isFinite(days) && days >= 0 && days <= 365 ? Math.round(days) : DEFAULT_PLACEMENT.rememberClosedDays,
  }
}

/** Keep the legacy keys the storefront reads today (mode/popupDelay) next to the new ones. */
export function displayFrom(p: FormPlacement): Record<string, unknown> {
  return {
    ...p,
    mode: p.showAs === 'page' ? 'inline' : 'popup',
    popupDelay: p.delaySeconds,
    popupFrequency: p.rememberClosedDays > 0 ? 'visitor' : 'always',
  }
}

export function normalizeField(raw: unknown, i: number): FormDocField | null {
  if (!raw || typeof raw !== 'object') return null
  const f = raw as Record<string, unknown>
  const type = FIELD_TYPES.some((t) => t.type === f.type) ? String(f.type) : f.type === 'toggle' ? 'checkbox' : 'text'
  const required = f.required === true || (Array.isArray(f.validation) && f.validation.some((v) => (v as { type?: string })?.type === 'required'))
  const options = Array.isArray(f.options)
    ? f.options.map((o) => (typeof o === 'string' ? o : str((o as { label?: unknown })?.label, 120))).filter(Boolean).slice(0, 50)
    : undefined
  return {
    id: str(f.id, 80) || `field_${i + 1}`,
    ...(str(f.name, 80) && str(f.name, 80) !== str(f.id, 80) ? { name: str(f.name, 80) } : {}),
    type,
    label: str(f.label, 200) || 'Untitled question',
    ...(str(f.placeholder, 200) ? { placeholder: str(f.placeholder, 200) } : {}),
    ...(str(f.description, 500) ? { description: str(f.description, 500) } : {}),
    required,
    width: f.width === 'half' ? 'half' : 'full',
    ...(FIELD_TYPES.find((t) => t.type === type)?.hasOptions ? { options: options?.length ? options : ['Option 1'] } : {}),
  }
}

/** A safe document from anything (a stored row or an edited one). */
export function normalizeFormDoc(raw: Record<string, unknown>): FormDoc {
  const fields = (Array.isArray(raw.fields) ? raw.fields : []).map(normalizeField).filter((f): f is FormDocField => !!f).slice(0, 100)
  // Field ids must be unique (they key the answers).
  const seen = new Set<string>()
  for (const f of fields) {
    let id = f.id
    for (let n = 2; seen.has(id); n++) id = `${f.id}_${n}`
    f.id = id
    seen.add(id)
  }
  const status = raw.status === 'DRAFT' || raw.status === 'ARCHIVED' ? raw.status : 'ACTIVE'
  return {
    name: str(raw.name, 200) || 'Untitled form',
    description: str(raw.description, 1000),
    status,
    submitButtonText: str(raw.submitButtonText, 60) || 'Submit',
    successMessage: str(raw.successMessage, 1000) || 'Thank you — we got your message.',
    notifyEmails: (Array.isArray(raw.notifyEmails) ? raw.notifyEmails : []).map((e) => str(e, 200).trim()).filter((e) => EMAIL.test(e)).slice(0, 20),
    fields,
    placement: raw.placement ? placementFrom(raw.placement) : placementFrom(raw.display),
    automations: normalizeRules(raw.automations),
    spamProtection: typeof raw.spamProtection === 'boolean' ? raw.spamProtection : raw.captchaEnabled !== false,
    retentionMonths: validMonths(raw.retentionMonths),
  }
}

/** The friendly name of a field type ("Short text", never "text"). */
export function fieldTypeLabel(type: string): string {
  return FIELD_TYPES.find((t) => t.type === type)?.label ?? 'Short text'
}

/** Plain-words list of what changed between two documents. */
export function formDocChanges(before: FormDoc, after: FormDoc): string[] {
  const out: string[] = []
  const b = new Map(before.fields.map((f) => [f.id, f]))
  const a = new Map(after.fields.map((f) => [f.id, f]))
  for (const f of after.fields) if (!b.has(f.id)) out.push(`adds “${f.label}”`)
  for (const f of before.fields) if (!a.has(f.id)) out.push(`removes “${f.label}”`)
  for (const f of after.fields) {
    const old = b.get(f.id)
    if (old && !sameValue(old, f)) out.push(`edits “${f.label}”`)
  }
  const kept = after.fields.filter((f) => b.has(f.id)).map((f) => f.id)
  const was = before.fields.filter((f) => a.has(f.id)).map((f) => f.id)
  if (kept.join() !== was.join()) out.push('reorders the questions')
  const labels: Array<[keyof FormDoc, string]> = [
    ['name', 'the name'],
    ['description', 'the description'],
    ['status', 'whether it is on'],
    ['submitButtonText', 'the button text'],
    ['successMessage', 'the message after sending'],
    ['notifyEmails', 'who gets emailed'],
    ['placement', 'where it appears'],
    ['spamProtection', 'spam protection'],
    ['retentionMonths', 'how long submissions are kept'],
  ]
  for (const [k, label] of labels) if (!sameValue(before[k], after[k])) out.push(`changes ${label}`)
  out.push(...ruleChanges(before.automations ?? [], after.automations ?? []))
  return out
}

/** The columns a document writes (the adapter's apply; never the slug or counters). */
export function docToRow(doc: FormDoc) {
  return {
    name: doc.name,
    description: doc.description || null,
    status: doc.status,
    submitButtonText: doc.submitButtonText,
    successMessage: doc.successMessage,
    notifyEmails: doc.notifyEmails,
    fields: doc.fields.map((f) => ({ ...f })),
    display: displayFrom(doc.placement),
    automations: doc.automations.map((r) => ({ ...r })),
    captchaEnabled: doc.spamProtection,
    retentionMonths: doc.retentionMonths,
  }
}

/**
 * Did the person change anything that saves? Key order and undefined keys
 * don't count (the editor and the database order keys differently), and
 * neither does touching a control without changing its value. Opening an
 * editor must never write.
 */
export function formDocChanged(base: FormDoc | null, next: FormDoc | null): boolean {
  if (!base || !next) return base !== next
  return !sameValue(docToRow(base), docToRow(next))
}

/**
 * Only the columns a document actually changes, both sides normalized the same
 * way — so filling in defaults (e.g. display's popupDelay) is never a change.
 * No live doc → every column.
 */
export function docRowPatch(live: FormDoc | null, next: FormDoc): Partial<ReturnType<typeof docToRow>> {
  const after = docToRow(next)
  if (!live) return after
  const before = docToRow(live)
  return Object.fromEntries(
    (Object.keys(after) as (keyof typeof after)[]).filter((k) => stableJson(before[k]) !== stableJson(after[k])).map((k) => [k, after[k]])
  ) as Partial<typeof after>
}

// ---------------------------------------------------------------------------
// Edits (pure; the builder and the assistant use the same ones)
// ---------------------------------------------------------------------------

function uniqueId(base: string, taken: ReadonlySet<string>): string {
  const clean = base.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40) || 'question'
  let id = clean
  for (let n = 2; taken.has(id); n++) id = `${clean}_${n}`
  return id
}

/** A new question of `type`, with a friendly default label and a unique id. */
export function newField(type: string, doc: FormDoc): FormDocField {
  const def = FIELD_TYPES.find((t) => t.type === type) ?? FIELD_TYPES[0]
  const label = def.label === 'Yes / No' ? 'I agree' : def.label
  return {
    id: uniqueId(label, new Set(doc.fields.map((f) => f.id))),
    type: def.type,
    label,
    required: false,
    width: 'full',
    ...(def.hasOptions ? { options: ['Option 1', 'Option 2'] } : {}),
  }
}

/** Insert after `afterId` (or at the end). */
export function insertField(doc: FormDoc, field: FormDocField, afterId?: string | null): FormDoc {
  const at = afterId ? doc.fields.findIndex((f) => f.id === afterId) : -1
  const fields = [...doc.fields]
  fields.splice(at >= 0 ? at + 1 : fields.length, 0, field)
  return { ...doc, fields }
}

export function patchField(doc: FormDoc, id: string, patch: Partial<Omit<FormDocField, 'id'>>): FormDoc {
  return {
    ...doc,
    fields: doc.fields.map((f) => {
      if (f.id !== id) return f
      const next = { ...f, ...patch }
      // Changing the type keeps options only where they mean something.
      const hasOptions = FIELD_TYPES.find((t) => t.type === next.type)?.hasOptions
      if (hasOptions && !next.options?.length) next.options = ['Option 1', 'Option 2']
      if (!hasOptions) delete next.options
      return next
    }),
  }
}

export function duplicateField(doc: FormDoc, id: string): { doc: FormDoc; newId: string | null } {
  const f = doc.fields.find((x) => x.id === id)
  if (!f) return { doc, newId: null }
  const copy = { ...f, id: uniqueId(`${f.id}_copy`, new Set(doc.fields.map((x) => x.id))), label: `${f.label} (copy)` }
  return { doc: insertField(doc, copy, id), newId: copy.id }
}

export function removeField(doc: FormDoc, id: string): FormDoc {
  return { ...doc, fields: doc.fields.filter((f) => f.id !== id) }
}

/** Move `fromId` into `toId`'s place (dnd-kit arrayMove semantics). */
export function moveField(doc: FormDoc, fromId: string, toId: string): FormDoc {
  const from = doc.fields.findIndex((f) => f.id === fromId)
  const to = doc.fields.findIndex((f) => f.id === toId)
  if (from < 0 || to < 0 || from === to) return doc
  const fields = [...doc.fields]
  const [moved] = fields.splice(from, 1)
  fields.splice(to, 0, moved)
  return { ...doc, fields }
}

/** One place up (-1) or down (1), for the visible Move buttons; unchanged at either end. */
export function stepField(doc: FormDoc, id: string, by: -1 | 1): FormDoc {
  const from = doc.fields.findIndex((f) => f.id === id)
  const to = from + by
  if (from < 0 || to < 0 || to >= doc.fields.length) return doc
  return moveField(doc, id, doc.fields[to].id)
}
