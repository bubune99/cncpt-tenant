/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/placement.assert.ts
 */
import assert from 'node:assert/strict'
import { leavingThroughTop, opensForm, placementForBlock, scrolledHalfway, staysClosed } from './placement'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const DAY = 86_400_000

check('the form’s setting wins unless the block on the page says otherwise', () => {
  assert.equal(placementForBlock({ showAs: 'slidein', opens: 'scroll' }, undefined).showAs, 'slidein')
  assert.equal(placementForBlock({ showAs: 'slidein' }, 'inline').showAs, 'page')
  assert.equal(placementForBlock({ showAs: 'page' }, 'popup').showAs, 'popup')
  assert.equal(placementForBlock({ showAs: 'slidein' }, 'popup').showAs, 'slidein')
  assert.equal(placementForBlock({ mode: 'popup', popupDelay: 3 }, undefined).delaySeconds, 3)
  assert.equal(placementForBlock(null, undefined).showAs, 'page')
})

check('remembered closed for N days; 0 = this visit only', () => {
  const now = 100 * DAY
  assert.equal(staysClosed(null, 7, now), false)
  assert.equal(staysClosed(now - 6 * DAY, 7, now), true)
  assert.equal(staysClosed(now - 8 * DAY, 7, now), false)
  assert.equal(staysClosed(now - 30 * DAY, 0, now), true)
})

check('scroll halfway, leaving through the top, click-to-open links', () => {
  assert.equal(scrolledHalfway(0, 800, 4000), false)
  assert.equal(scrolledHalfway(1200, 800, 4000), true)
  assert.equal(scrolledHalfway(0, 800, 600), true)
  assert.equal(leavingThroughTop(-2, true), true)
  assert.equal(leavingThroughTop(300, true), false)
  assert.equal(leavingThroughTop(-2, false), false)
  assert.equal(opensForm('#form-volunteer', null, 'volunteer'), true)
  assert.equal(opensForm('/get-involved#form-volunteer', null, 'volunteer'), true)
  assert.equal(opensForm(null, 'volunteer', 'volunteer'), true)
  assert.equal(opensForm('#form-volunteer-2', null, 'volunteer'), false)
})

console.log(`\n${n} checks passed`)
