/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/open-no-write.assert.ts
 * Opening a form must never write: an untouched document is "unchanged"
 * however its keys are ordered, and the server agrees.
 */
import assert from 'node:assert/strict'
import { sameValue } from '../ade/history/revisions'
import { formDocChanged, formDocChanges, normalizeFormDoc } from './doc'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const row = {
  name: 'Volunteer',
  fields: [{ id: 'a', type: 'text', label: 'First Name', required: true }, { id: 'b', type: 'email', label: 'Email' }],
  display: { mode: 'popup' },
  automations: [{ id: 'r1', name: 'Every volunteer', enabled: true, trigger: 'form.submitted', actions: [{ type: 'tag', tag: 'v' }] }],
}

check('key order and undefined keys are not changes', () => {
  assert.equal(sameValue({ a: 1, b: { c: 2, d: undefined } }, { b: { c: 2 }, a: 1 }), true)
  assert.equal(sameValue({ a: [1, 2] }, { a: [2, 1] }), false)
})

check('a form as the editor holds it vs as the database returns it (jsonb sorts keys) = no change', () => {
  const live = normalizeFormDoc(row as never)
  // What the editor sends back untouched: same values, keys in another order, optional keys undefined.
  const reorder = (v: unknown): unknown => (Array.isArray(v) ? v.map(reorder) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v as object).reverse().map(([k, x]) => [k, reorder(x)])) : v)
  const editor = reorder({ ...live, fields: live.fields.map((f) => ({ ...f, placeholder: undefined })) }) as typeof live
  assert.equal(formDocChanged(live, editor), false)
  assert.deepEqual(formDocChanges(live, editor), [], 'the server sees no change either, so no draft is made')
})

check('a real edit is a change', () => {
  const live = normalizeFormDoc(row as never)
  const edited = { ...live, fields: live.fields.map((f, i) => (i === 0 ? { ...f, label: 'Given name' } : f)) }
  assert.equal(formDocChanged(live, edited), true)
  assert.deepEqual(formDocChanges(live, edited), ['edits “Given name”'])
})

check('page blocks re-set unchanged (keys reordered) are not an edit; email starter only on create', () => {
  const blocks = [{ id: 'a', tag: 'p', className: 'x', textContent: 'Hi', attrs: { href: '/', target: undefined } }]
  const again = [{ textContent: 'Hi', attrs: { href: '/' }, className: 'x', tag: 'p', id: 'a' }]
  assert.equal(sameValue(blocks, again), true)
  assert.equal(sameValue(blocks, [{ ...again[0], textContent: 'Hello' }]), false)
})

console.log(`\n${n} checks passed`)
