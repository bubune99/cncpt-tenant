/**
 * Form automations — "what happens after someone submits this form".
 *
 * A rule is DATA: WHEN someone submits [and every condition matches] THEN
 * run its actions in order. Actions come only from the registered catalog
 * below (no code, no free-form URLs except the clearly-labelled webhook).
 *
 * The decisions that keep runs safe live here, pure, so they are asserted
 * (automations.assert.ts) rather than trusted:
 *   - idempotency: an action has a stable key; the same key never reaches
 *     the same submission twice (re-runs say "Already got it");
 *   - consent: promotional email only with marketing consent;
 *   - money: store credit never runs on its own — it waits for approval each
 *     time, and is unavailable while the shop is off.
 */
import { sameValue } from '../ade/history/revisions'

export type ActionType = 'newsletter' | 'tag' | 'email' | 'promo_email' | 'alert_owner' | 'todo' | 'store_credit' | 'webhook'
export type ActionGroup = 'Contacts' | 'Email' | 'Alerts' | 'Store' | 'Developer'

export interface ActionParamSpec {
  key: string
  label: string
  kind: 'text' | 'number' | 'url' | 'emails'
  placeholder?: string
  required?: boolean
}

export interface ActionSpec {
  type: ActionType
  group: ActionGroup
  label: string
  /** One plain sentence under the label in the picker. */
  hint: string
  params: ReadonlyArray<ActionParamSpec>
  /** Needs the person's email address. */
  needsEmail?: boolean
  /** Only with marketing consent. */
  needsConsent?: boolean
  /** Money: waits for approval every time. */
  money?: boolean
  /** Sends data off-site. */
  external?: boolean
  /** Only while the shop is on. */
  needsShop?: boolean
  /** Sends an email (bulk runs batch these). */
  sendsEmail?: boolean
}

export const ACTIONS: ReadonlyArray<ActionSpec> = [
  { type: 'newsletter', group: 'Contacts', label: 'Add to newsletter', hint: 'They confirm by email first (double opt-in).', params: [{ key: 'list', label: 'List', kind: 'text', placeholder: 'Newsletter' }], needsEmail: true, sendsEmail: true },
  { type: 'tag', group: 'Contacts', label: 'Tag the contact', hint: 'A label you can filter by later.', params: [{ key: 'tag', label: 'Tag', kind: 'text', placeholder: 'mission-trip', required: true }] },
  { type: 'email', group: 'Email', label: 'Send an email to them', hint: 'From one of your email templates.', params: [{ key: 'template', label: 'Template', kind: 'text', placeholder: 'thanks-for-volunteering', required: true }], needsEmail: true, sendsEmail: true },
  { type: 'promo_email', group: 'Email', label: 'Send a promotional email', hint: 'Only if they agreed to marketing.', params: [{ key: 'template', label: 'Template', kind: 'text', placeholder: 'spring-appeal', required: true }], needsEmail: true, needsConsent: true, sendsEmail: true },
  { type: 'alert_owner', group: 'Alerts', label: 'Alert the owner', hint: 'An email to you (or the addresses you list).', params: [{ key: 'to', label: 'Send to', kind: 'emails', placeholder: 'Leave empty to use the form’s email settings' }], sendsEmail: true },
  { type: 'todo', group: 'Alerts', label: 'Add a To-do item', hint: 'Shows up in To-do for someone to follow up.', params: [{ key: 'title', label: 'What to do', kind: 'text', placeholder: 'Follow up about the next trip', required: true }, { key: 'for', label: 'For', kind: 'text', placeholder: 'Trip coordinator' }] },
  { type: 'store_credit', group: 'Store', label: 'Give store credit', hint: 'Money — needs your approval each time.', params: [{ key: 'amount', label: 'Amount (dollars)', kind: 'number', placeholder: '10', required: true }], needsEmail: true, money: true, needsShop: true },
  { type: 'webhook', group: 'Developer', label: 'Send to a webhook', hint: 'Sends the answers off-site to another service.', params: [{ key: 'url', label: 'Web address (https)', kind: 'url', placeholder: 'https://example.com/hook', required: true }], external: true },
]

export function actionSpec(type: string): ActionSpec | undefined {
  return ACTIONS.find((a) => a.type === type)
}

export type ConditionOp = 'contains' | 'is' | 'checked' | 'not_checked'

export interface RuleCondition {
  fieldId: string
  op: ConditionOp
  /** contains/is: alternatives separated by commas or " or " — any one matches. */
  value?: string
}

export interface RuleAction {
  id: string
  type: ActionType
  params: Record<string, string>
}

export interface FormRule {
  id: string
  name: string
  enabled: boolean
  conditions: RuleCondition[]
  actions: RuleAction[]
}

const MAX_RULES = 20
const MAX_ACTIONS = 10
const MAX_CONDITIONS = 5
const str = (v: unknown, max = 300) => (typeof v === 'string' ? v.trim().slice(0, max) : typeof v === 'number' && Number.isFinite(v) ? String(v) : '')
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** IPv6 text → its eight 16-bit groups (handles "::", embedded IPv4 and zone ids); null if it isn't IPv6. */
function v6Groups(v: string): number[] | null {
  let s = v.split('%')[0]
  const v4 = /(\d+\.\d+\.\d+\.\d+)$/.exec(s)
  if (v4) {
    const p = v4[1].split('.').map(Number)
    if (p.some((n) => n > 255)) return null
    s = s.slice(0, -v4[1].length) + `${((p[0] << 8) | p[1]).toString(16)}:${((p[2] << 8) | p[3]).toString(16)}`
  }
  const halves = s.split('::')
  if (halves.length > 2) return null
  const head = halves[0] ? halves[0].split(':') : []
  const tail = halves.length === 2 && halves[1] ? halves[1].split(':') : []
  const fill = halves.length === 2 ? 8 - head.length - tail.length : 0
  const parts = [...head, ...Array(Math.max(0, fill)).fill('0'), ...tail]
  if (parts.length !== 8 || parts.some((x) => !/^[0-9a-f]{1,4}$/.test(x))) return null
  return parts.map((x) => parseInt(x, 16))
}

const v4From = (hi: number, lo: number) => `${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`

/**
 * A literal IPv4/IPv6 address on a private, loopback, link-local, CGNAT,
 * benchmark or reserved range — including IPv4 hidden inside IPv6
 * (mapped ::ffff:, in either dotted or hex form; IPv4-compatible ::a.b.c.d;
 * NAT64 64:ff9b::/96; 6to4 2002::/16) and Teredo, multicast and site-local.
 */
export function isPrivateAddress(ip: string): boolean {
  const v = ip.toLowerCase().replace(/^\[|\]$/g, '')
  if (v.includes(':')) {
    const g = v6Groups(v)
    if (!g) return true // unreadable: never call it
    const zeroTo = (n: number) => g.slice(0, n).every((x) => x === 0)
    if (zeroTo(8)) return true // ::
    if (zeroTo(7) && g[7] === 1) return true // ::1
    if (zeroTo(5) && g[5] === 0xffff) return isPrivateAddress(v4From(g[6], g[7])) // ::ffff:a.b.c.d / ::ffff:7f00:1
    if (zeroTo(6)) return isPrivateAddress(v4From(g[6], g[7])) // ::a.b.c.d (IPv4-compatible)
    if (g[0] === 0x64 && g[1] === 0xff9b && g.slice(2, 6).every((x) => x === 0)) return isPrivateAddress(v4From(g[6], g[7])) // NAT64
    if (g[0] === 0x2002) return isPrivateAddress(v4From(g[1], g[2])) // 6to4
    if (g[0] === 0x2001 && g[1] === 0) return true // Teredo: tunnels to anywhere
    const top = g[0] >> 8
    if (top === 0xff) return true // multicast
    if ((g[0] & 0xfe00) === 0xfc00) return true // unique-local fc00::/7
    if ((g[0] & 0xffc0) === 0xfe80 || (g[0] & 0xffc0) === 0xfec0) return true // link-local, site-local
    return false
  }
  const m = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(v)
  if (!m) return false
  const [a, b] = [Number(m[1]), Number(m[2])]
  return (
    a === 0 || a === 10 || a === 127 || a >= 224 ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19))
  )
}

/**
 * https only, and never a private/loopback host by name or literal address.
 * The runner ALSO checks what the name resolves to right before calling.
 */
export function safeWebhookUrl(raw: string): string | null {
  let u: URL
  try {
    u = new URL(raw)
  } catch {
    return null
  }
  if (u.protocol !== 'https:' || u.username || u.password) return null
  const h = u.hostname.toLowerCase().replace(/\.+$/, '')
  if (!h || h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal') || h.endsWith('.home.arpa') || !h.includes('.') && !h.startsWith('[')) return null
  if (h.startsWith('[') || /^\d+\.\d+\.\d+\.\d+$/.test(h)) {
    if (h.startsWith('[') || isPrivateAddress(h)) return null
  }
  return u.toString()
}

function cleanParams(type: ActionType, raw: unknown): Record<string, string> | null {
  const spec = actionSpec(type)!
  const src = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const out: Record<string, string> = {}
  for (const p of spec.params) {
    let v = str(src[p.key], p.kind === 'url' ? 500 : 200)
    if (p.kind === 'number' && v) {
      const n = Number(v)
      if (!Number.isFinite(n) || n <= 0 || n > 500) return null
      v = String(Math.round(n * 100) / 100)
    }
    if (p.kind === 'url' && v) {
      const safe = safeWebhookUrl(v)
      if (!safe) return null
      v = safe
    }
    if (p.kind === 'emails' && v) {
      const list = v.split(/[\s,;]+/).filter(Boolean)
      if (!list.every((e) => EMAIL.test(e))) return null
      v = list.slice(0, 10).join(', ')
    }
    if (p.key === 'tag' && v) v = v.toLowerCase().replace(/[^a-z0-9-_ ]/g, '').replace(/\s+/g, '-').slice(0, 40)
    if (p.required && !v) return null
    if (v) out[p.key] = v
  }
  return out
}

function slugId(prefix: string, i: number): string {
  return `${prefix}_${i + 1}`
}

/** Safe rules from anything (stored JSON, a draft, the assistant). Invalid actions are dropped. */
export function normalizeRules(raw: unknown): FormRule[] {
  const list = Array.isArray(raw) ? raw.slice(0, MAX_RULES) : []
  const seen = new Set<string>()
  const out: FormRule[] = []
  list.forEach((r, i) => {
    if (!r || typeof r !== 'object') return
    const o = r as Record<string, unknown>
    let id = str(o.id, 60).replace(/[^A-Za-z0-9_-]/g, '') || slugId('rule', i)
    while (seen.has(id)) id = `${id}_x`
    seen.add(id)
    const conditions = (Array.isArray(o.conditions) ? o.conditions : [])
      .slice(0, MAX_CONDITIONS)
      .map((c): RuleCondition | null => {
        const cc = (c && typeof c === 'object' ? c : {}) as Record<string, unknown>
        const op = (['contains', 'is', 'checked', 'not_checked'] as const).find((x) => x === cc.op)
        const fieldId = str(cc.fieldId, 80)
        if (!op || !fieldId) return null
        const value = str(cc.value, 200)
        if ((op === 'contains' || op === 'is') && !value) return null
        return op === 'contains' || op === 'is' ? { fieldId, op, value } : { fieldId, op }
      })
      .filter((c): c is RuleCondition => !!c)
    const actionIds = new Set<string>()
    const actions = (Array.isArray(o.actions) ? o.actions : [])
      .slice(0, MAX_ACTIONS)
      .map((a, j): RuleAction | null => {
        const aa = (a && typeof a === 'object' ? a : {}) as Record<string, unknown>
        const spec = actionSpec(String(aa.type))
        if (!spec) return null
        const params = cleanParams(spec.type, aa.params)
        if (!params) return null
        let aid = str(aa.id, 60).replace(/[^A-Za-z0-9_-]/g, '') || slugId('action', j)
        while (actionIds.has(aid)) aid = `${aid}_x`
        actionIds.add(aid)
        return { id: aid, type: spec.type, params }
      })
      .filter((a): a is RuleAction => !!a)
    out.push({ id, name: str(o.name, 80) || `Rule ${i + 1}`, enabled: o.enabled !== false, conditions, actions })
  })
  return out
}

// ---------------------------------------------------------------------------
// Matching
// ---------------------------------------------------------------------------

export type Answers = Record<string, unknown>

function answerText(v: unknown): string {
  if (v === null || v === undefined) return ''
  if (Array.isArray(v)) return v.map(answerText).join(', ')
  if (typeof v === 'object') return ''
  return String(v)
}

function truthy(v: unknown): boolean {
  if (Array.isArray(v)) return v.length > 0
  return v === true || v === 'true' || v === 'on' || v === 'yes' || v === 'Yes' || v === 1 || v === '1'
}

function alternatives(value: string): string[] {
  return value
    .split(/,|\bor\b/i)
    .map((s) => s.trim().replace(/^["“”']+|["“”']+$/g, '').toLowerCase())
    .filter(Boolean)
}

export function conditionMatches(c: RuleCondition, answers: Answers): boolean {
  const v = answers[c.fieldId]
  switch (c.op) {
    case 'checked':
      return truthy(v)
    case 'not_checked':
      return !truthy(v)
    case 'contains': {
      const text = answerText(v).toLowerCase()
      return alternatives(c.value ?? '').some((a) => text.includes(a))
    }
    case 'is': {
      const text = answerText(v).trim().toLowerCase()
      return alternatives(c.value ?? '').some((a) => text === a)
    }
  }
}

/** A rule fires when it is on and every condition matches. */
export function ruleMatches(rule: FormRule, answers: Answers): boolean {
  return rule.enabled && rule.actions.length > 0 && rule.conditions.every((c) => conditionMatches(c, answers))
}

// ---------------------------------------------------------------------------
// The person behind a submission
// ---------------------------------------------------------------------------

export interface FieldLike {
  id: string
  type: string
  label: string
}

const CONSENT = /market|newsletter|promot|updates|offers|news\b|email me|keep me|subscribe|consent/i

/** Marketing consent = a ticked consent-style checkbox (never assumed). */
export function marketingConsent(fields: ReadonlyArray<FieldLike>, answers: Answers): boolean {
  return fields.some((f) => f.type === 'checkbox' && (CONSENT.test(f.label) || CONSENT.test(f.id)) && truthy(answers[f.id]))
}

export interface Contact {
  name: string
  email: string | null
}

export function contactOf(fields: ReadonlyArray<FieldLike>, answers: Answers): Contact {
  const emailField = fields.find((f) => f.type === 'email') ?? fields.find((f) => /e-?mail/i.test(f.label))
  const rawEmail = emailField ? answerText(answers[emailField.id]).trim() : answerText(answers.email).trim()
  const email = EMAIL.test(rawEmail) ? rawEmail.toLowerCase() : null
  const byLabel = (re: RegExp) => {
    const f = fields.find((x) => x.type !== 'email' && re.test(x.label))
    return f ? answerText(answers[f.id]).trim() : ''
  }
  const first = byLabel(/^first/i)
  const last = byLabel(/^(last|sur)/i)
  const full = byLabel(/^(full\s+)?name$|your name/i)
  const name = full || [first, last].filter(Boolean).join(' ') || (email ? email.split('@')[0] : '')
  return { name: name.slice(0, 120), email }
}

// ---------------------------------------------------------------------------
// Decisions (idempotency, consent, money)
// ---------------------------------------------------------------------------

/** Stable identity of an action for "never twice to the same submission". */
export function actionKey(a: Pick<RuleAction, 'type' | 'params'>): string {
  const p = a.params
  const main = a.type === 'newsletter' ? (p.list || 'newsletter') : a.type === 'tag' ? p.tag : a.type === 'email' || a.type === 'promo_email' ? p.template : a.type === 'todo' ? p.title : a.type === 'store_credit' ? p.amount : a.type === 'webhook' ? p.url : ''
  return `${a.type}:${String(main ?? '').toLowerCase().trim()}`
}

export function dedupeKeyFor(submissionId: string, a: Pick<RuleAction, 'type' | 'params'>): string {
  return `${submissionId}|${actionKey(a)}`.slice(0, 600)
}

export type Outcome =
  | { kind: 'run' }
  | { kind: 'approval'; reason: string }
  | { kind: 'skip'; code: 'already' | 'no_email' | 'no_consent' | 'shop_off'; reason: string }

export interface PlanContext {
  email: string | null
  consent: boolean
  commerceEnabled: boolean
  /** actionKeys this submission already got (done or waiting for approval). */
  done: ReadonlySet<string>
}

export function planAction(a: Pick<RuleAction, 'type' | 'params'>, ctx: PlanContext): Outcome {
  const spec = actionSpec(a.type)
  if (!spec) return { kind: 'skip', code: 'already', reason: 'Unknown action' }
  if (ctx.done.has(actionKey(a))) return { kind: 'skip', code: 'already', reason: 'Already got it' }
  if (spec.needsShop && !ctx.commerceEnabled) return { kind: 'skip', code: 'shop_off', reason: 'The shop is off' }
  if (spec.needsEmail && !ctx.email) return { kind: 'skip', code: 'no_email', reason: 'No email address' }
  if (spec.needsConsent && !ctx.consent) return { kind: 'skip', code: 'no_consent', reason: 'Didn’t agree to marketing' }
  if (spec.money) return { kind: 'approval', reason: 'Needs your approval' }
  return { kind: 'run' }
}

// ---------------------------------------------------------------------------
// Words
// ---------------------------------------------------------------------------

export function describeAction(a: Pick<RuleAction, 'type' | 'params'>): { title: string; detail: string } {
  const spec = actionSpec(a.type)
  const p = a.params
  if (!spec) return { title: 'Unknown action', detail: '' }
  switch (a.type) {
    case 'newsletter':
      return { title: spec.label, detail: `List: ${p.list || 'Newsletter'} · they confirm by email first` }
    case 'tag':
      return { title: spec.label, detail: `Tag: ${p.tag}` }
    case 'email':
      return { title: spec.label, detail: `Template: “${p.template}”` }
    case 'promo_email':
      return { title: spec.label, detail: `Template: “${p.template}” · only if they agreed to marketing` }
    case 'alert_owner':
      return { title: spec.label, detail: p.to ? `Email to ${p.to}` : 'Email to the form’s notification addresses' }
    case 'todo':
      return { title: spec.label, detail: `${p.for ? `For: ${p.for} — ` : ''}“${p.title}”` }
    case 'store_credit':
      return { title: spec.label, detail: `$${p.amount} gift-card balance · needs your approval each time` }
    case 'webhook':
      return { title: spec.label, detail: `Sends the answers to ${hostOf(p.url)}` }
  }
}

function hostOf(url: string | undefined): string {
  try {
    return new URL(url ?? '').hostname
  } catch {
    return 'another service'
  }
}

/** The "When" line: Someone submits <form> · When “Message” contains “travel” or “trip”. */
export function describeWhen(rule: FormRule, formName: string, fields: ReadonlyArray<FieldLike>): string {
  const label = (id: string) => fields.find((f) => f.id === id)?.label ?? 'an answer'
  const conds = rule.conditions.map((c) => {
    const alts = alternatives(c.value ?? '').map((x) => `“${x}”`).join(' or ')
    if (c.op === 'checked') return `“${label(c.fieldId)}” is ticked`
    if (c.op === 'not_checked') return `“${label(c.fieldId)}” is not ticked`
    return `“${label(c.fieldId)}” ${c.op === 'is' ? 'is' : 'contains'} ${alts}`
  })
  return `Someone submits ${formName}${conds.length ? ` · When ${conds.join(' and ')}` : ''}`
}

/** One line of a submission's "What happened" timeline. */
export function timelineText(type: string, status: string, params: Record<string, string> = {}): string {
  const done = status === 'done' || status === 'approved'
  if (status === 'needs_approval') return type === 'store_credit' ? `Store credit of $${params.amount ?? '?'} is waiting for your approval` : 'Waiting for your approval'
  if (status === 'declined') return 'Store credit declined'
  if (status === 'failed') return `${actionSpec(type)?.label ?? 'An action'} didn’t work`
  if (!done) return `${actionSpec(type)?.label ?? 'An action'} skipped`
  switch (type) {
    case 'newsletter':
      return 'Added to newsletter (waiting for them to confirm)'
    case 'tag':
      return `Tagged ${params.tag ?? ''}`.trim()
    case 'email':
      return 'Email sent to them'
    case 'promo_email':
      return 'Promotional email sent'
    case 'alert_owner':
      return 'You were alerted'
    case 'todo':
      return `To-do created${params.for ? ` for ${params.for.toLowerCase()}` : ''}`
    case 'store_credit':
      return `Store credit of $${params.amount ?? '?'} given`
    case 'webhook':
      return `Sent to ${hostOf(params.url)}`
    default:
      return 'Done'
  }
}

/** Plain-words differences between two rule lists (for review descriptions). */
export function ruleChanges(before: ReadonlyArray<FormRule>, after: ReadonlyArray<FormRule>): string[] {
  const out: string[] = []
  const b = new Map(before.map((r) => [r.id, r]))
  const a = new Map(after.map((r) => [r.id, r]))
  for (const r of after) {
    const old = b.get(r.id)
    if (!old) out.push(`adds the automation “${r.name}”`)
    else if (old.enabled !== r.enabled && sameValue({ ...old, enabled: r.enabled }, r)) out.push(`turns ${r.enabled ? 'on' : 'off'} “${r.name}”`)
    else if (!sameValue(old, r)) out.push(`changes the automation “${r.name}”`)
  }
  for (const r of before) if (!a.has(r.id)) out.push(`removes the automation “${r.name}”`)
  return out
}
