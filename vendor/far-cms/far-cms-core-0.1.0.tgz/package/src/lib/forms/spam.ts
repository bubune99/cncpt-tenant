/**
 * Form spam protection — the decisions, pure (asserted by spam.assert.ts).
 *
 * Three layers on every submission:
 *   1. Cloudflare Turnstile, per form (Settings → "Spam protection", on by
 *      default). In PRODUCTION a form that wants it but has no keys is
 *      refused — never silently accepted — and the owner is told. Outside
 *      production it is allowed with a warning, so development still works.
 *   2. A hidden honeypot field (bots fill it; people can't see it) — refused
 *      SILENTLY: the normal "thank you", nothing stored, nothing run.
 *   3. A signed time-to-submit token (too fast = a script) and a per-IP,
 *      per-form rate limit (IPs are hashed, never stored raw).
 * Layers 2 and 3 apply whether or not the form uses Turnstile.
 */

import { createHash, createHmac, timingSafeEqual } from 'node:crypto'
import { HONEYPOT_FIELD, TOKEN_FIELD } from './spam-fields'

export { HONEYPOT_FIELD, TOKEN_FIELD }

// ---------------------------------------------------------------------------
// 1. Turnstile
// ---------------------------------------------------------------------------

export interface CaptchaConfig {
  siteKey: string
  secretKey: string
}

export type CaptchaDecision =
  | { kind: 'verify' }
  | { kind: 'skip'; reason: 'form-off' | 'not-configured-dev' }
  | { kind: 'closed'; missing: Array<'site key' | 'secret key'> }

/** Production = the live site (Vercel production, or a non-Vercel production build). */
export function isProductionEnv(env: { NODE_ENV?: string; VERCEL_ENV?: string }): boolean {
  if (env.VERCEL_ENV) return env.VERCEL_ENV === 'production'
  return env.NODE_ENV === 'production'
}

export function missingKeys(c: CaptchaConfig): Array<'site key' | 'secret key'> {
  const out: Array<'site key' | 'secret key'> = []
  if (!c.siteKey.trim()) out.push('site key')
  if (!c.secretKey.trim()) out.push('secret key')
  return out
}

export function captchaDecision(input: { formWantsCaptcha: boolean; config: CaptchaConfig; production: boolean }): CaptchaDecision {
  if (!input.formWantsCaptcha) return { kind: 'skip', reason: 'form-off' }
  const missing = missingKeys(input.config)
  if (!missing.length) return { kind: 'verify' }
  return input.production ? { kind: 'closed', missing } : { kind: 'skip', reason: 'not-configured-dev' }
}

export const CLOSED_MESSAGE = 'Spam protection isn’t set up yet — the site owner has been told. Please try again later.'

/** Status for the Settings screen, in plain words. */
export function spamStatus(config: CaptchaConfig, production: boolean): { state: 'configured' | 'missing'; missing: Array<'site key' | 'secret key'>; effect: string } {
  const missing = missingKeys(config)
  if (!missing.length) return { state: 'configured', missing, effect: 'Forms check every visitor with Cloudflare Turnstile before accepting a submission.' }
  return {
    state: 'missing',
    missing,
    effect: production
      ? 'Forms with spam protection on are refusing submissions until the keys are added.'
      : 'This is not the live site, so forms still accept submissions without the check.',
  }
}

// ---------------------------------------------------------------------------
// 2. Honeypot
// ---------------------------------------------------------------------------


export function honeypotTripped(body: Record<string, unknown>): boolean {
  const v = body[HONEYPOT_FIELD]
  return typeof v === 'string' ? v.trim().length > 0 : v !== undefined && v !== null && v !== false
}

/** The answers to store: no honeypot, token or CAPTCHA response. */
export function stripSpamFields(body: Record<string, unknown>): Record<string, unknown> {
  const drop = new Set([HONEYPOT_FIELD, TOKEN_FIELD, 'captchaToken', 'cf-turnstile-response'])
  return Object.fromEntries(Object.entries(body).filter(([k]) => !drop.has(k)))
}

// ---------------------------------------------------------------------------
// 3a. Time-to-submit token
// ---------------------------------------------------------------------------

/** Faster than this from showing the form to sending it = a script. */
export const MIN_FILL_MS = 3_000
/** Older than this = reload the page. */
export const MAX_TOKEN_AGE_MS = 24 * 60 * 60_000

function sign(formId: string, issuedAt: number, secret: string): string {
  return createHmac('sha256', secret).update(`form-time:${formId}:${issuedAt}`).digest('base64url').slice(0, 32)
}

export function issueFormToken(formId: string, now: number, secret: string): string {
  return `${now}.${sign(formId, now, secret)}`
}

export type TokenCheck = { ok: true } | { ok: false; reason: 'missing' | 'bad' | 'too_fast' | 'expired' }

export function checkFormToken(token: unknown, formId: string, now: number, secret: string): TokenCheck {
  if (typeof token !== 'string' || !token) return { ok: false, reason: 'missing' }
  const [ts, sig] = token.split('.')
  const issuedAt = Number(ts)
  if (!Number.isFinite(issuedAt) || !sig) return { ok: false, reason: 'bad' }
  const want = Buffer.from(sign(formId, issuedAt, secret))
  const got = Buffer.from(sig)
  if (want.length !== got.length || !timingSafeEqual(want, got)) return { ok: false, reason: 'bad' }
  if (now - issuedAt < MIN_FILL_MS) return { ok: false, reason: 'too_fast' }
  if (now - issuedAt > MAX_TOKEN_AGE_MS) return { ok: false, reason: 'expired' }
  return { ok: true }
}

export function tokenMessage(reason: Exclude<TokenCheck, { ok: true }>['reason']): string {
  return reason === 'too_fast' ? 'That was very quick — please wait a moment and send it again.' : 'This form has expired. Please reload the page and try again.'
}

// ---------------------------------------------------------------------------
// 3b. Per-IP, per-form rate limit
// ---------------------------------------------------------------------------

export const RATE_WINDOW_MS = 10 * 60_000
export const RATE_MAX_PER_WINDOW = 5

/** A one-way hash — the raw address is never stored. */
export function hashIp(ip: string, secret: string): string {
  return createHash('sha256').update(`${secret}:ip:${ip.trim().toLowerCase()}`).digest('hex').slice(0, 32)
}

export function windowStart(now: number, windowMs = RATE_WINDOW_MS): number {
  return Math.floor(now / windowMs) * windowMs
}

export function rateKey(ipHash: string, formId: string, now: number): string {
  return `${ipHash}:${formId}:${windowStart(now)}`
}

/** count = submissions in this window INCLUDING this one. */
export function rateDecision(count: number, now: number, max = RATE_MAX_PER_WINDOW): { allowed: true } | { allowed: false; retryAfterSeconds: number } {
  if (count <= max) return { allowed: true }
  return { allowed: false, retryAfterSeconds: Math.max(1, Math.ceil((windowStart(now) + RATE_WINDOW_MS - now) / 1000)) }
}

// ---------------------------------------------------------------------------
// The whole gate, in order (the route performs the I/O between steps)
// ---------------------------------------------------------------------------

export type GateResult =
  | { action: 'continue'; verifyCaptcha: boolean; warn?: string }
  | { action: 'silent-accept' }
  | { action: 'reject'; status: 400 | 403 | 429 | 503; message: string; retryAfterSeconds?: number; alertOwner?: boolean }

export function spamGate(input: {
  rateCount: number
  now: number
  body: Record<string, unknown>
  token: TokenCheck
  captcha: CaptchaDecision
}): GateResult {
  const rate = rateDecision(input.rateCount, input.now)
  if (!rate.allowed) return { action: 'reject', status: 429, message: 'Too many submissions — please try again in a few minutes.', retryAfterSeconds: rate.retryAfterSeconds }
  if (honeypotTripped(input.body)) return { action: 'silent-accept' }
  if (!input.token.ok) return { action: 'reject', status: 400, message: tokenMessage(input.token.reason) }
  if (input.captcha.kind === 'closed') return { action: 'reject', status: 503, message: CLOSED_MESSAGE, alertOwner: true }
  if (input.captcha.kind === 'skip' && input.captcha.reason === 'not-configured-dev') {
    return { action: 'continue', verifyCaptcha: false, warn: 'Spam protection keys are missing — allowed because this is not production.' }
  }
  return { action: 'continue', verifyCaptcha: input.captcha.kind === 'verify' }
}
