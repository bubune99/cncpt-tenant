/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/answers.assert.ts
 * Audit run-2 R2-14: public form submissions store only declared answers; patterns can't hang.
 */
import assert from 'node:assert/strict'
import { declaredAnswers, fieldsPatternError, matchesPattern, MAX_ANSWER_CHARS, patternProblem } from './answers'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('only the form’s own questions are stored; extra keys are dropped', () => {
  const fields = [{ id: 'f1', name: 'email' }, { id: 'f2' }, { id: 'f3', name: 'topics' }]
  const out = declaredAnswers(fields, { email: 'a@b.org', f2: 'Hi', topics: ['x', 'y'], admin: true, __proto__x: 1, big: 'x'.repeat(10) })
  assert.deepEqual(out, { email: 'a@b.org', f2: 'Hi', topics: ['x', 'y'] })
})

check('answers are capped (text, and lists of choices)', () => {
  const out = declaredAnswers([{ id: 'a' }, { id: 'b' }, { id: 'c' }], { a: 'x'.repeat(MAX_ANSWER_CHARS + 50), b: Array.from({ length: 80 }, (_, i) => `o${i}`), c: { nested: 'object' } })
  assert.equal((out.a as string).length, MAX_ANSWER_CHARS)
  assert.equal((out.b as string[]).length, 50)
  assert.equal('c' in out, false, 'objects are not answers')
})

check('patterns: short, valid and without nested repetition', () => {
  assert.equal(patternProblem('^[0-9]{5}$'), null)
  assert.match(patternProblem('(a+)+$')!, /hang/)
  assert.match(patternProblem('(\\w*)*x')!, /hang/)
  assert.match(patternProblem('([a-z]{1,9}){2,}')!, /hang/)
  assert.match(patternProblem('[unclosed')!, /valid/)
  assert.match(patternProblem('a'.repeat(300))!, /longer/)
})

check('a refused pattern never runs; a fine one still checks', () => {
  assert.equal(matchesPattern('(a+)+$', 'a'.repeat(50) + '!'), true, 'not run (would hang)')
  assert.equal(matchesPattern('^[0-9]{5}$', '12345'), true)
  assert.equal(matchesPattern('^[0-9]{5}$', 'abcde'), false)
})

check('the save routes name the field with a bad pattern', () => {
  assert.equal(fieldsPatternError([{ label: 'Zip', validation: { pattern: '^\\d{5}$' } }]), null)
  assert.match(fieldsPatternError([{ label: 'Code', validation: { pattern: '(x+)+' } }])!, /“Code”/)
  assert.equal(fieldsPatternError([{ label: 'Rules', validation: [{ type: 'required' }] }]), null)
})

console.log(`\n${n} checks passed`)
