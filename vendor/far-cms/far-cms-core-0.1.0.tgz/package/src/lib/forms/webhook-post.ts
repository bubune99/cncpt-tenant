/**
 * POST to a form automation's webhook with the address PINNED (audit run-2
 * R2-13): the name is resolved once, every answer must be public, and the
 * connection goes to that checked address — the request can't resolve the
 * name again and land somewhere private (DNS rebinding). No redirects are
 * followed. Server-only (node:https).
 */

import https from 'node:https'
import { lookup as dnsLookup, type LookupAddress } from 'node:dns'
import { isIP } from 'node:net'
import { isPrivateAddress } from './automations'

/** The address to connect to: null when any answer is private (or there is none). */
export function pickPublicAddress(addrs: readonly LookupAddress[]): LookupAddress | null {
  if (!addrs.length || addrs.some((a) => isPrivateAddress(a.address))) return null
  return addrs[0]
}

export async function postJsonPinned(url: string, payload: unknown, opts: { timeoutMs: number; headers?: Record<string, string> }): Promise<{ status: number }> {
  const u = new URL(url)
  if (u.protocol !== 'https:') throw new Error('That web address isn’t allowed')
  const host = u.hostname.replace(/^\[|\]$/g, '')
  if (isIP(host) && isPrivateAddress(host)) throw new Error('That web address isn’t allowed')
  const body = JSON.stringify(payload)
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        protocol: 'https:',
        hostname: host,
        port: u.port || 443,
        path: `${u.pathname}${u.search}`,
        method: 'POST',
        headers: { ...(opts.headers ?? {}), 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
        ...(isIP(host) ? {} : { servername: host }),
        timeout: opts.timeoutMs,
        // One resolution, checked, used for the connection.
        lookup: (hostname: string, options: { all?: boolean }, cb: (err: Error | null, address: string | LookupAddress[], family?: number) => void) => {
          dnsLookup(hostname, { all: true }, (err, addrs) => {
            if (err) return cb(err, '')
            const pick = pickPublicAddress(addrs)
            if (!pick) return cb(new Error('That web address isn’t allowed'), '')
            return options?.all ? cb(null, [pick]) : cb(null, pick.address, pick.family)
          })
        },
      },
      (res) => {
        res.resume()
        resolve({ status: res.statusCode ?? 0 })
      }
    )
    req.on('timeout', () => req.destroy(new Error('The other service didn’t answer in time')))
    req.on('error', reject)
    req.end(body)
  })
}
