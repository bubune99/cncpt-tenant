/**
 * Where a form appears on the site, and when a pop-up / slide-in opens.
 * Pure; asserted by placement.assert.ts. Used by the storefront
 * (FormBlock / FormPopup) and by the builder's preview.
 */

import { placementFrom, type FormPlacement } from './doc'

const DAY_MS = 86_400_000

/**
 * The placement to use for one block: the form's own setting, unless the
 * block on that page says otherwise (data-display="inline" | "popup").
 */
export function placementForBlock(formDisplay: unknown, attrDisplay: string | undefined): FormPlacement {
  const p = placementFrom(formDisplay)
  if (attrDisplay === 'inline') return { ...p, showAs: 'page' }
  if (attrDisplay === 'popup' && p.showAs === 'page') return { ...p, showAs: 'popup' }
  return p
}

export function closedKey(slug: string): string {
  return `form-closed:${slug}`
}

/**
 * Was it closed recently enough to stay closed? `closedAt` is the stored
 * timestamp (ms) or null. 0 days = closed for this visit only (the caller
 * keeps that one in sessionStorage).
 */
export function staysClosed(closedAt: number | null, rememberDays: number, now: number): boolean {
  if (closedAt === null || !Number.isFinite(closedAt)) return false
  if (rememberDays <= 0) return true
  return now - closedAt < rememberDays * DAY_MS
}

/** "Scrolled halfway": the bottom of the screen has passed the middle of the page. */
export function scrolledHalfway(scrollY: number, viewportHeight: number, documentHeight: number): boolean {
  if (documentHeight <= viewportHeight) return true
  return scrollY + viewportHeight >= documentHeight / 2
}

/** "About to leave": the pointer left through the top edge of the window. */
export function leavingThroughTop(clientY: number, leftWindow: boolean): boolean {
  return leftWindow && clientY <= 0
}

/** The links that open a click-to-open form: <a href="#form-<slug>"> or data-open-form="<slug>". */
export function opensForm(href: string | null, dataOpenForm: string | null, slug: string): boolean {
  return dataOpenForm === slug || href === `#form-${slug}` || (!!href && href.endsWith(`#form-${slug}`))
}
