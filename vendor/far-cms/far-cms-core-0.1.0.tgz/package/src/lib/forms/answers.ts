/**
 * What a public form submission may store and how its patterns run — pure,
 * asserted by answers.assert.ts (audit run-2 R2-14).
 *
 * - Only the form's own questions are kept (by name or id), never extra
 *   keys a client adds; each answer is capped, and lists of choices too.
 * - A custom pattern is used only when it is short, compiles, and has no
 *   nested repetition (the classic catastrophic-backtracking shape); it is
 *   checked when the form is saved and again when it runs.
 */

export const MAX_ANSWER_CHARS = 5000
export const MAX_CHOICES = 50
const MAX_PATTERN = 200
const MAX_TESTED = 1000

export interface AnswerField {
  id: string
  name?: string
}

function capValue(v: unknown): unknown {
  if (typeof v === 'string') return v.slice(0, MAX_ANSWER_CHARS)
  if (typeof v === 'number' || typeof v === 'boolean') return v
  if (Array.isArray(v)) return v.filter((x) => typeof x === 'string' || typeof x === 'number').slice(0, MAX_CHOICES).map((x) => (typeof x === 'string' ? x.slice(0, 500) : x))
  return undefined
}

/** The answers to the form's own questions only, each capped; the key is the one the storefront used (name, else id). */
export function declaredAnswers(fields: readonly AnswerField[], body: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const f of fields) {
    for (const key of [f.name, f.id]) {
      if (!key || !(key in body)) continue
      const v = capValue(body[key])
      if (v !== undefined) out[key] = v
      break
    }
  }
  return out
}

/** Nested repetition like (a+)+, (a*)*, (a|aa)+ … — refused. */
const NESTED = /\((?:[^()\\]|\\.)*[+*}](?:[^()\\]|\\.)*\)\s*[+*{]/

export function patternProblem(p: unknown): string | null {
  if (p === undefined || p === null || p === '') return null
  if (typeof p !== 'string') return 'must be text'
  if (p.length > MAX_PATTERN) return `is longer than ${MAX_PATTERN} characters`
  if (NESTED.test(p)) return 'repeats a repeated group (it could hang the form)'
  try {
    new RegExp(p)
  } catch {
    return 'isn’t a valid pattern'
  }
  return null
}

/** Does the value match? Unsafe or broken patterns are not run (treated as no pattern). */
export function matchesPattern(p: unknown, value: string): boolean {
  if (patternProblem(p) !== null || typeof p !== 'string' || !p) return true
  return new RegExp(p).test(value.slice(0, MAX_TESTED))
}

/** For the save routes: the first field whose pattern is unsafe, in words; null when all are fine. */
export function fieldsPatternError(fields: unknown): string | null {
  if (!Array.isArray(fields)) return null
  for (const f of fields) {
    const v = (f as { validation?: { pattern?: unknown }; label?: unknown })?.validation
    const p = v && !Array.isArray(v) ? v.pattern : undefined
    const problem = patternProblem(p)
    if (problem) return `The pattern on “${String((f as { label?: unknown }).label ?? 'a question')}” ${problem}.`
  }
  return null
}

/**
 * Answers keyed by question id for reading. A form started from a kind stores answers under the
 * question's name ('email'); the admin reads by id ('contact-email'). An id already present wins;
 * other keys are kept. Walk 2026-11-19. Asserted by answer-keys.assert.ts.
 */
export function answersById(fields: ReadonlyArray<{ id: string; name?: string }>, data: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...data }
  for (const f of fields) {
    if (f.name && f.name !== f.id && out[f.id] === undefined && data[f.name] !== undefined) out[f.id] = data[f.name]
  }
  return out
}
