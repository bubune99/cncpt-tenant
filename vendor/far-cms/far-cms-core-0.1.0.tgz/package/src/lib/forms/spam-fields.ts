/**
 * Names of the spam-protection fields a form sends (browser-safe; the
 * decisions that use them live in ./spam, which is server-only).
 */

/** The hidden honeypot field. A plausible name so form-filling bots fill it. */
export const HONEYPOT_FIELD = 'company_website'
/** The signed time token's field. */
export const TOKEN_FIELD = '_ft'
