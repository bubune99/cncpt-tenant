/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/automations.assert.ts
 */
import assert from 'node:assert/strict'
import { actionKey, contactOf, isPrivateAddress, dedupeKeyFor, describeWhen, marketingConsent, normalizeRules, planAction, ruleChanges, ruleMatches, safeWebhookUrl, timelineText } from './automations'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const FIELDS = [
  { id: 'first', type: 'text', label: 'First Name' },
  { id: 'last', type: 'text', label: 'Last Name' },
  { id: 'email', type: 'email', label: 'Email' },
  { id: 'message', type: 'textarea', label: 'Message' },
  { id: 'updates', type: 'checkbox', label: 'Send me news and updates' },
]

check('rules are data: invalid actions, unsafe webhooks and junk are dropped', () => {
  const rules = normalizeRules([
    {
      id: 'every', name: 'Every volunteer', actions: [
        { type: 'newsletter', params: { list: 'Volunteers' } },
        { type: 'run_code', params: { js: 'process.exit()' } },
        { type: 'webhook', params: { url: 'http://example.com/hook' } },
        { type: 'webhook', params: { url: 'https://10.0.0.5/hook' } },
        { type: 'webhook', params: { url: 'https://hooks.example.com/x' } },
        { type: 'tag', params: { tag: 'Mission Trip!' } },
        { type: 'store_credit', params: { amount: '100000' } },
        { type: 'todo', params: {} },
      ],
    },
    { id: 'every', name: '', enabled: false, conditions: [{ fieldId: 'message', op: 'contains', value: '' }, { fieldId: 'message', op: 'contains', value: 'travel or trip' }], actions: [{ type: 'tag', params: { tag: 'trip' } }] },
    'junk',
  ])
  assert.equal(rules.length, 2)
  assert.deepEqual(rules[0].actions.map((a) => a.type), ['newsletter', 'webhook', 'tag'])
  assert.equal(rules[0].actions[2].params.tag, 'mission-trip')
  assert.equal(rules[1].id, 'every_x')
  assert.equal(rules[1].name, 'Rule 2')
  assert.equal(rules[1].enabled, false)
  assert.equal(rules[1].conditions.length, 1)
  assert.equal(safeWebhookUrl('https://localhost/x'), null)
  assert.equal(safeWebhookUrl('https://192.168.1.1/x'), null)
  assert.equal(safeWebhookUrl('https://user:pw@example.com/x'), null)
  assert.equal(safeWebhookUrl('https://localhost./x'), null)
  assert.equal(safeWebhookUrl('https://printer.local./x'), null)
  assert.equal(safeWebhookUrl('https://100.64.0.1/x'), null)
  assert.equal(safeWebhookUrl('https://[::1]/x'), null)
  assert.ok(safeWebhookUrl('https://hooks.example.com/x'))
  assert.equal(isPrivateAddress('198.18.0.1'), true)
  assert.equal(isPrivateAddress('::ffff:10.0.0.1'), true)
  assert.equal(isPrivateAddress('fd00::1'), true)
  assert.equal(isPrivateAddress('93.184.216.34'), false)
  // R2-13: IPv4 hidden in IPv6 — hex-mapped, IPv4-compatible, NAT64, 6to4 — plus Teredo, multicast, site-local.
  for (const ip of ['::ffff:7f00:1', '::ffff:a00:1', '::127.0.0.1', '64:ff9b::a9fe:a9fe', '64:ff9b::169.254.169.254', '2002:7f00:0001::', '2002:a00:1::1', '2001:0:4136:e378::1', 'ff02::1', 'fec0::1', '0:0:0:0:0:0:0:1', 'fe80::1%eth0', 'not:an:ip']) {
    assert.equal(isPrivateAddress(ip), true, ip)
  }
  for (const ip of ['2606:4700:4700::1111', '64:ff9b::808:808', '2002:808:808::1', '::ffff:8.8.8.8']) assert.equal(isPrivateAddress(ip), false, ip)
})

check('matching: contains any alternative, ticked boxes, all conditions, off rules never fire', () => {
  const [rule] = normalizeRules([{ id: 'r', name: 'Wants to travel', conditions: [{ fieldId: 'message', op: 'contains', value: '“travel” or “trip”' }], actions: [{ type: 'tag', params: { tag: 'trip' } }] }])
  assert.equal(ruleMatches(rule, { message: 'Interested in the next TRIP to Akuse' }), true)
  assert.equal(ruleMatches(rule, { message: 'I can help with packing' }), false)
  assert.equal(ruleMatches({ ...rule, enabled: false }, { message: 'trip' }), false)
  const [both] = normalizeRules([{ name: 'x', conditions: [{ fieldId: 'message', op: 'contains', value: 'trip' }, { fieldId: 'updates', op: 'checked' }], actions: [{ type: 'tag', params: { tag: 't' } }] }])
  assert.equal(ruleMatches(both, { message: 'trip', updates: true }), true)
  assert.equal(ruleMatches(both, { message: 'trip', updates: false }), false)
  assert.equal(describeWhen(rule, 'Volunteer With Us', FIELDS), 'Someone submits Volunteer With Us · When “Message” contains “travel” or “trip”')
})

check('the person: name from first/last, email validated, consent only when ticked', () => {
  assert.deepEqual(contactOf(FIELDS, { first: 'Ama', last: 'Mensah', email: 'AMA@example.com ' }), { name: 'Ama Mensah', email: 'ama@example.com' })
  assert.deepEqual(contactOf(FIELDS, { email: 'nope' }), { name: '', email: null })
  assert.equal(marketingConsent(FIELDS, { updates: true }), true)
  assert.equal(marketingConsent(FIELDS, { updates: false }), false)
  assert.equal(marketingConsent(FIELDS, {}), false)
  assert.equal(marketingConsent([{ id: 'agree', type: 'checkbox', label: 'I agree to the terms' }], { agree: true }), false)
})

check('decisions: idempotent per (submission, action), consent, money, shop off', () => {
  const promo = { type: 'promo_email' as const, params: { template: 'Spring' } }
  const credit = { type: 'store_credit' as const, params: { amount: '10' } }
  const base = { email: 'a@example.com', consent: true, commerceEnabled: true, done: new Set<string>() }
  assert.deepEqual(planAction(promo, base), { kind: 'run' })
  assert.equal(planAction(promo, { ...base, consent: false }).kind, 'skip')
  assert.equal((planAction(promo, { ...base, consent: false }) as { reason: string }).reason, 'Didn’t agree to marketing')
  assert.equal((planAction(promo, { ...base, done: new Set([actionKey(promo)]) }) as { code: string }).code, 'already')
  assert.equal(actionKey(promo), actionKey({ type: 'promo_email', params: { template: 'spring ' } }))
  assert.equal(planAction(credit, base).kind, 'approval')
  assert.equal((planAction(credit, { ...base, commerceEnabled: false }) as { code: string }).code, 'shop_off')
  assert.equal((planAction({ type: 'email', params: { template: 't' } }, { ...base, email: null }) as { code: string }).code, 'no_email')
  assert.equal(planAction({ type: 'tag', params: { tag: 't' } }, { ...base, email: null }).kind, 'run')
  assert.notEqual(dedupeKeyFor('s1', promo), dedupeKeyFor('s2', promo))
})

check('words: timeline lines and rule changes', () => {
  assert.equal(timelineText('newsletter', 'done', { list: 'Volunteers' }), 'Added to newsletter (waiting for them to confirm)')
  assert.equal(timelineText('todo', 'done', { title: 'x', for: 'Trip coordinator' }), 'To-do created for trip coordinator')
  assert.equal(timelineText('store_credit', 'needs_approval', { amount: '10' }), 'Store credit of $10 is waiting for your approval')
  const a = normalizeRules([{ id: 'r', name: 'Every volunteer', actions: [{ type: 'tag', params: { tag: 'v' } }] }])
  const b = normalizeRules([{ id: 'r', name: 'Every volunteer', enabled: false, actions: [{ type: 'tag', params: { tag: 'v' } }] }, { id: 'n', name: 'New', actions: [{ type: 'tag', params: { tag: 'n' } }] }])
  assert.deepEqual(ruleChanges(a, b), ['turns off “Every volunteer”', 'adds the automation “New”'])
  assert.deepEqual(ruleChanges(b, []), ['removes the automation “Every volunteer”', 'removes the automation “New”'])
})

console.log(`\n${n} checks passed`)
