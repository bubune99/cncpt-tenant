/**
 * The submissions inbox: status, tabs, search, "filter by answer", CSV
 * export and bulk planning. Pure; asserted by inbox.assert.ts.
 */

import { contactOf, conditionMatches, marketingConsent, planAction, type Answers, type FieldLike, type Outcome, type RuleAction, type RuleCondition } from './automations'

export type InboxStatus = 'new' | 'read' | 'replied' | 'archived'
export type InboxTab = 'all' | 'new' | 'starred' | 'replied' | 'archived'
export const INBOX_TABS: ReadonlyArray<{ id: InboxTab; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'new', label: 'New' },
  { id: 'starred', label: 'Starred' },
  { id: 'replied', label: 'Replied' },
  { id: 'archived', label: 'Archived' },
]

export interface InboxRow {
  id: string
  data: Answers
  status: string
  read: boolean
  starred: boolean
  createdAt: string | Date
}

/** Older rows only have `read`; a stored status always wins once set past "new". */
export function inboxStatus(row: Pick<InboxRow, 'status' | 'read'>): InboxStatus {
  if (row.status === 'read' || row.status === 'replied' || row.status === 'archived') return row.status
  return row.read ? 'read' : 'new'
}

/** Archived rows only show under Archived. */
export function inTab(row: Pick<InboxRow, 'status' | 'read' | 'starred'>, tab: InboxTab): boolean {
  const s = inboxStatus(row)
  if (tab === 'archived') return s === 'archived'
  if (s === 'archived') return false
  if (tab === 'all') return true
  if (tab === 'starred') return row.starred
  return s === tab
}

export function tabCounts(rows: ReadonlyArray<Pick<InboxRow, 'status' | 'read' | 'starred'>>): Record<InboxTab, number> {
  const out: Record<InboxTab, number> = { all: 0, new: 0, starred: 0, replied: 0, archived: 0 }
  for (const r of rows) for (const t of INBOX_TABS) if (inTab(r, t.id)) out[t.id]++
  return out
}

function text(v: unknown): string {
  if (v === null || v === undefined || typeof v === 'object') return Array.isArray(v) ? v.join(', ') : ''
  return String(v)
}

/** Search names, emails and every answer (case-insensitive). */
export function matchesSearch(row: Pick<InboxRow, 'data'>, q: string): boolean {
  const needle = q.trim().toLowerCase()
  if (!needle) return true
  return Object.values(row.data ?? {}).some((v) => text(v).toLowerCase().includes(needle))
}

export function matchesAnswer(row: Pick<InboxRow, 'data'>, filter: RuleCondition | null): boolean {
  return !filter || conditionMatches(filter, row.data ?? {})
}

/** A message-like preview: the longest free-text answer. */
export function messageOf(fields: ReadonlyArray<FieldLike>, data: Answers): string {
  const long = fields.find((f) => f.type === 'textarea')
  if (long) return text(data[long.id]).replace(/\s+/g, ' ').trim()
  const skip = new Set(['email', 'phone', 'checkbox', 'date', 'number'])
  return (
    fields
      .filter((f) => !skip.has(f.type) && !/name/i.test(f.label))
      .map((f) => text(data[f.id]))
      .sort((a, b) => b.length - a.length)[0] ?? ''
  ).replace(/\s+/g, ' ').trim()
}

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------

/** Quote a cell; neutralise spreadsheet formulas (=, +, -, @, tab, CR). */
export function csvCell(v: unknown): string {
  let s = text(v)
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

export function submissionsCsv(fields: ReadonlyArray<FieldLike>, rows: ReadonlyArray<InboxRow>): string {
  const head = ['Received', 'Status', 'Starred', ...fields.map((f) => f.label)]
  const lines = [head.map(csvCell).join(',')]
  for (const r of rows) {
    const when = typeof r.createdAt === 'string' ? r.createdAt : r.createdAt.toISOString()
    lines.push([when, inboxStatus(r), r.starred ? 'yes' : '', ...fields.map((f) => r.data?.[f.id])].map(csvCell).join(','))
  }
  return lines.join('\r\n') + '\r\n'
}

// ---------------------------------------------------------------------------
// Bulk planning — one engine for "run this rule for past ones" and
// "select submissions → Run an action…". Always previewed first.
// ---------------------------------------------------------------------------

export interface BulkSubmission {
  id: string
  data: Answers
  /** actionKeys this submission already got. */
  done: ReadonlySet<string>
}

export interface BulkRowPlan {
  id: string
  name: string
  email: string | null
  outcomes: Outcome[]
  /** The row in one phrase: Will run / Skipped — … / Already got it / Needs approval. */
  verdict: { kind: 'run' | 'approval' | 'skip'; label: string }
}

export interface BulkPlan {
  rows: BulkRowPlan[]
  willRun: number
  approvals: number
  skipped: number
  emails: number
}

export function planBulk(
  fields: ReadonlyArray<FieldLike>,
  subs: ReadonlyArray<BulkSubmission>,
  actions: ReadonlyArray<Pick<RuleAction, 'type' | 'params'>>,
  opts: { commerceEnabled: boolean; sendsEmail: (type: string) => boolean }
): BulkPlan {
  let willRun = 0
  let approvals = 0
  let skipped = 0
  let emails = 0
  const rows = subs.map((s): BulkRowPlan => {
    const c = contactOf(fields, s.data)
    const ctx = { email: c.email, consent: marketingConsent(fields, s.data), commerceEnabled: opts.commerceEnabled, done: s.done }
    const outcomes = actions.map((a) => planAction(a, ctx))
    for (let i = 0; i < actions.length; i++) if (outcomes[i].kind === 'run' && opts.sendsEmail(actions[i].type)) emails++
    const anyRun = outcomes.some((o) => o.kind === 'run')
    const anyApproval = outcomes.some((o) => o.kind === 'approval')
    const firstSkip = outcomes.find((o) => o.kind === 'skip') as Extract<Outcome, { kind: 'skip' }> | undefined
    let verdict: BulkRowPlan['verdict']
    if (anyRun) verdict = { kind: 'run', label: 'Will run' }
    else if (anyApproval) verdict = { kind: 'approval', label: 'Goes to To-do for approval' }
    else verdict = { kind: 'skip', label: firstSkip?.code === 'already' ? 'Already got it — skipped' : `Skipped — ${(firstSkip?.reason ?? 'nothing to do').replace(/^./, (x) => x.toLowerCase())}` }
    if (verdict.kind === 'run') willRun++
    else if (verdict.kind === 'approval') approvals++
    else skipped++
    return { id: s.id, name: c.name, email: c.email, outcomes, verdict }
  })
  return { rows, willRun, approvals, skipped, emails }
}

/** Emails go out in batches of this many per minute. */
export const EMAILS_PER_MINUTE = 50
/** Submissions handled per bulk step (one request). */
export const BULK_STEP = 10

/** How long to wait before the next step so emails stay under the per-minute cap. */
export function stepDelayMs(emailsThisStep: number): number {
  return emailsThisStep <= 0 ? 300 : Math.ceil((emailsThisStep / EMAILS_PER_MINUTE) * 60_000)
}

/** The confirm shown before submissions are deleted for good (owner, inbox 6c572b78: "Add Delete, with a confirm"). */
export function deleteConfirm(count: number): { title: string; body: string; confirmLabel: string; destructive: true } {
  const what = count === 1 ? 'this submission' : `${count} submissions`
  return {
    title: `Delete ${what}?`,
    body: `${count === 1 ? 'It is' : 'They are'} removed for good and can't be undone. To keep ${count === 1 ? 'it' : 'them'} out of the inbox instead, use Archive.`,
    confirmLabel: 'Delete',
    destructive: true,
  }
}
