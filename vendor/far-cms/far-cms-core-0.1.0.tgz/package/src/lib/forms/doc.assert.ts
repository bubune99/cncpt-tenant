/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/doc.assert.ts
 */
import assert from 'node:assert/strict'
import { displayFrom, docRowPatch, docToRow, duplicateField, formDocChanges, insertField, moveField, newField, stepField, normalizeFormDoc, patchField, placementFrom, removeField } from './doc'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('a stored row becomes a safe document (legacy shapes understood)', () => {
  const d = normalizeFormDoc({
    name: 'Contact', fields: [
      { id: 'name', type: 'text', label: 'Name', required: true },
      { id: 'name', type: 'toggle', label: 'Subscribe' },
      { id: 'topic', type: 'select', label: 'Topic', options: [{ value: 'a', label: 'Volunteering' }] },
      { id: 'x', type: 'weird', label: '' },
      null,
    ],
    notifyEmails: ['owner@example.com', 'not-an-email'], display: { mode: 'popup', popupDelay: 8 },
  })
  assert.deepEqual(d.fields.map((f) => [f.id, f.type, f.required]), [['name', 'text', true], ['name_2', 'checkbox', false], ['topic', 'select', false], ['x', 'text', false]])
  assert.deepEqual(d.fields[2].options, ['Volunteering'])
  assert.equal(d.fields[3].label, 'Untitled question')
  assert.deepEqual(d.notifyEmails, ['owner@example.com'])
  assert.deepEqual(d.placement, { showAs: 'popup', opens: 'delay', delaySeconds: 8, rememberClosedDays: 7 })
  assert.equal(d.submitButtonText, 'Submit')
})

check('placement round-trips and keeps the storefront’s legacy keys', () => {
  const p = placementFrom({ showAs: 'slidein', opens: 'scroll', delaySeconds: 3, rememberClosedDays: 30 })
  const disp = displayFrom(p)
  assert.equal(disp.mode, 'popup')
  assert.deepEqual(placementFrom(disp), p)
  assert.equal(placementFrom({ delaySeconds: 99999 }).delaySeconds, 5)
})

check('changes are listed in plain words', () => {
  const a = normalizeFormDoc({ name: 'Contact', fields: [{ id: 'a', type: 'text', label: 'Name' }, { id: 'b', type: 'email', label: 'Email' }] })
  const b = normalizeFormDoc({ name: 'Contact us', fields: [{ id: 'b', type: 'email', label: 'Email', required: true }, { id: 'a', type: 'text', label: 'Name' }, { id: 'c', type: 'textarea', label: 'Message' }] })
  assert.deepEqual(formDocChanges(a, b), ['adds “Message”', 'edits “Email”', 'reorders the questions', 'changes the name'])
  assert.deepEqual(formDocChanges(a, a), [])
})

check('edits: add, duplicate, retype, move, remove — ids stay unique', () => {
  let d = normalizeFormDoc({ name: 'Volunteer', fields: [{ id: 'email', type: 'email', label: 'Email' }, { id: 'message', type: 'textarea', label: 'Message' }] })
  const f = newField('email', d)
  assert.equal(f.id, 'email_2')
  assert.equal(newField('checkbox', d).label, 'I agree')
  d = insertField(d, f, 'email')
  assert.deepEqual(d.fields.map((x) => x.id), ['email', 'email_2', 'message'])
  const dup = duplicateField(d, 'message')
  assert.equal(dup.newId, 'message_copy')
  d = patchField(dup.doc, 'message_copy', { type: 'select' })
  assert.deepEqual(d.fields[3].options, ['Option 1', 'Option 2'])
  d = patchField(d, 'message_copy', { type: 'text' })
  assert.equal('options' in d.fields[3], false)
  d = moveField(d, 'message', 'email')
  assert.deepEqual(d.fields.map((x) => x.id), ['message', 'email', 'email_2', 'message_copy'])
  d = removeField(d, 'email_2')
  assert.equal(d.fields.length, 3)
  assert.deepEqual(normalizeFormDoc(docToRow(d) as unknown as Record<string, unknown>), d)
  // Spam protection: on unless the row says otherwise; round-trips via captchaEnabled.
  assert.equal(d.spamProtection, true)
  const off = { ...d, spamProtection: false }
  assert.equal(docToRow(off).captchaEnabled, false)
  assert.equal(normalizeFormDoc({ ...docToRow(off) } as unknown as Record<string, unknown>).spamProtection, false)
  assert.deepEqual(formDocChanges(d, off), ['changes spam protection'])
})

check('a field steps up or down one place from a button; the ends stay put', () => {
  const base = normalizeFormDoc({ name: 'F', fields: [{ name: 'a', label: 'A', type: 'text' }, { name: 'b', label: 'B', type: 'text' }, { name: 'c', label: 'C', type: 'text' }] })
  const ids = (d: typeof base) => d.fields.map((f) => f.id).join(',')
  const [a, b, c] = base.fields.map((f) => f.id)
  assert.equal(ids(stepField(base, c, -1)), [a, c, b].join(','))
  assert.equal(ids(stepField(base, a, 1)), [b, a, c].join(','))
  assert.equal(stepField(base, a, -1), base)
  assert.equal(stepField(base, c, 1), base)
  assert.equal(stepField(base, 'nope', 1), base)
  assert.equal(ids(base), [a, b, c].join(','), 'the document given is not changed')
})

check('an automation-only change writes only automations (defaults filled in are not a change)', () => {
  // A stored form whose display is sparse ({ mode: 'popup' }) — the draft normalizes it.
  const live = normalizeFormDoc({ name: 'F', fields: [{ id: 'a', type: 'text', label: 'A' }], display: { mode: 'popup' }, automations: [] })
  const next = normalizeFormDoc({ ...(docToRow(live) as unknown as Record<string, unknown>), automations: [{ id: 'r1', trigger: 'form.submitted', actions: [] }] })
  const patch = docRowPatch(live, next)
  assert.deepEqual(Object.keys(patch), ['automations'])
  assert.deepEqual(docRowPatch(live, live), {})
  assert.deepEqual(Object.keys(docRowPatch(null, live)).sort(), Object.keys(docToRow(live)).sort())
})

console.log(`\n${n} checks passed`)
