/**
 * Where a form may send someone after they submit: an http(s) address or a
 * path on this site ("/thanks"). Never javascript:, data:, or "//host"
 * tricks — the browser navigates to it. Checked when it's saved and again
 * before navigating. Pure; asserted by src/lib/security/form-redirect.assert.ts.
 */

/** The address to navigate to, or null when it isn't one we allow. */
export function safeRedirectUrl(value: unknown): string | null {
  if (typeof value !== 'string') return null
  const v = value.trim()
  if (!v || /[\u0000-\u001f\u007f\\]/.test(v)) return null
  if (v.startsWith('/')) return v.startsWith('//') ? null : v
  try {
    const u = new URL(v)
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.toString() : null
  } catch {
    return null
  }
}

/** Why a redirect can't be saved (null/empty clears it and is fine), or null when it can. */
export function redirectUrlProblem(value: unknown): string | null {
  if (value === undefined || value === null || (typeof value === 'string' && !value.trim())) return null
  return safeRedirectUrl(value) ? null : 'The page to go to after sending must be a web address (https://…) or a page on this site (/…).'
}
