/**
 * Run: npx -y tsx@4.23.15 src/lib/forms/webhook-post.assert.ts
 * R2-13: the webhook connects only to a checked public address, resolved once.
 */
import assert from 'node:assert/strict'
import { pickPublicAddress, postJsonPinned } from './webhook-post'

let n = 0
const check = async (name: string, fn: () => Promise<void> | void) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }

async function main() {
  await check('one private answer blocks the name (a rebinding host can’t slip one in)', () => {
    assert.equal(pickPublicAddress([{ address: '93.184.216.34', family: 4 }, { address: '10.0.0.5', family: 4 }]), null)
    assert.equal(pickPublicAddress([]), null)
    assert.deepEqual(pickPublicAddress([{ address: '93.184.216.34', family: 4 }]), { address: '93.184.216.34', family: 4 })
  })
  await check('literal private addresses and plain http are refused before any connection', async () => {
    await assert.rejects(postJsonPinned('https://127.0.0.1/hook', {}, { timeoutMs: 2000 }), /isn’t allowed/)
    await assert.rejects(postJsonPinned('https://[::ffff:7f00:1]/hook', {}, { timeoutMs: 2000 }), /isn’t allowed/)
    await assert.rejects(postJsonPinned('http://example.com/hook', {}, { timeoutMs: 2000 }), /isn’t allowed/)
  })
  await check('a name that resolves to a private address is refused at connect (localhost)', async () => {
    await assert.rejects(postJsonPinned('https://localhost/hook', {}, { timeoutMs: 2000 }), /isn’t allowed/)
  })
  console.log(`\n${n} checks passed`)
}
void main()
