/**
 * "1 permission", "3 permissions", "No users". Pure; asserted by plural.assert.ts.
 */
export function plural(n: number, one: string, many = `${one}s`, opts: { zero?: string } = {}): string {
  if (n === 0 && opts.zero) return opts.zero
  return `${n.toLocaleString('en-US')} ${n === 1 ? one : many}`
}
