/**
 * Agent Navigation Registry
 *
 * Canonical list of admin destinations the AI agent can navigate to. Rendered
 * as an invisible, always-present "nav rail" of buttons (see AgentNavRail) so
 * the agent has a reliable, in-context click target for full-site navigation on
 * every page — independent of the visible UI chrome (which can be reworked
 * freely without breaking agent navigation).
 *
 * Keep roughly in sync with the admin sidebar nav in AdminShell. Entries here
 * are navigation *destinations*; the visible sidebar may group/label them
 * differently.
 */

export interface AgentNavRoute {
  /** Stable, agent-facing id (kebab-case). */
  key: string;
  /** Human label (used as the hidden button's text / accessible name). */
  label: string;
  /** App path the button navigates to. */
  path: string;
}

export const AGENT_NAV_ROUTES: AgentNavRoute[] = [
  { key: 'dashboard', label: 'Dashboard', path: '/admin' },
  { key: 'analytics', label: 'Analytics', path: '/admin/analytics' },
  { key: 'products', label: 'Products', path: '/admin/products' },
  { key: 'product-new', label: 'New Product', path: '/admin/products/new' },
  { key: 'orders', label: 'Orders', path: '/admin/orders' },
  { key: 'order-new', label: 'New Order', path: '/admin/orders/new' },
  { key: 'order-workflows', label: 'Order Workflows', path: '/admin/order-workflows' },
  { key: 'shipping', label: 'Shipping', path: '/admin/shipping' },
  { key: 'customers', label: 'Customers', path: '/admin/customers' },
  { key: 'pages', label: 'Pages', path: '/admin/pages' },
  { key: 'page-new', label: 'New Page', path: '/admin/pages/new' },
  { key: 'blog', label: 'Blog', path: '/admin/blog' },
  { key: 'blog-new', label: 'New Blog Post', path: '/admin/blog/new' },
  { key: 'events', label: 'Events', path: '/admin/events' },
  { key: 'forms', label: 'Forms', path: '/admin/forms' },
  { key: 'media', label: 'Media', path: '/admin/media' },
  { key: 'email-marketing', label: 'Email Marketing', path: '/admin/email-marketing' },
  { key: 'users', label: 'Users', path: '/admin/users' },
  { key: 'roles', label: 'Roles & Permissions', path: '/admin/roles' },
  { key: 'audit-log', label: 'Audit Log', path: '/admin/audit-log' },
  { key: 'plugins', label: 'Plugins', path: '/admin/plugins' },
  { key: 'workflows', label: 'Workflows', path: '/admin/workflows' },
  { key: 'tours', label: 'Tours', path: '/admin/tours' },
  { key: 'settings', label: 'Settings', path: '/admin/settings' },
  { key: 'discounts', label: 'Discounts', path: '/admin/discounts' },
  { key: 'reviews', label: 'Reviews', path: '/admin/reviews' },
  { key: 'partials', label: 'Partials', path: '/admin/partials' },
  { key: 'todo', label: 'To-do', path: '/admin/todo' },
  { key: 'initiatives', label: 'Initiatives', path: '/admin/records/initiative' },
];

/** Normalize a path for comparison (drop trailing slashes; '' -> '/'). */
export function normalizeNavPath(path: string): string {
  return path.replace(/\/+$/, '') || '/';
}

/** Find the registry entry whose path matches `path` (trailing-slash tolerant). */
export function findAgentNavByPath(path: string): AgentNavRoute | undefined {
  const target = normalizeNavPath(path);
  return AGENT_NAV_ROUTES.find((r) => normalizeNavPath(r.path) === target);
}
