/**
 * What the assistant did, in plain words — "Opened the media library",
 * never "Navigated to /admin/media". Pure; asserted by nav-phrases.assert.ts.
 */

import { AGENT_NAV_ROUTES } from './agent-nav-registry'
import { RECORD_TYPES } from '../ade-bindings/record-types'
import { navPhrasesFor } from '../ade/records/type-config'

const NICE: Array<[RegExp, string]> = [
  [/^\/admin$/, 'the dashboard'],
  [/^\/admin\/todo$/, 'your To-do list'],
  [/^\/admin\/todo\/review\/[^/]+$/, 'the change to review'],
  [/^\/admin\/media$/, 'the media library'],
  [/^\/admin\/pages$/, 'your pages'],
  [/^\/admin\/pages\/new$/, 'a new page'],
  [/^\/admin\/pages\/[^/]+\/editor$/, 'the page editor'],
  [/^\/admin\/pages\/[^/]+$/, 'the page settings'],
  [/^\/admin\/forms$/, 'your forms'],
  [/^\/admin\/forms\/[^/]+$/, 'the form and its messages'],
  [/^\/admin\/settings$/, 'settings'],
]

export function placeName(path: string): string {
  const p = (path || '').split(/[?#]/)[0].replace(/\/+$/, '') || '/'
  // Every record type's screens, in its own words (label, plural, key — lib/ade/records/type-config), then the fixed ones.
  for (const [re, name] of [...Object.values(RECORD_TYPES).flatMap((t) => navPhrasesFor(t)), ...NICE]) if (re.test(p)) return name
  const route = [...AGENT_NAV_ROUTES].sort((a, b) => b.path.length - a.path.length).find((r) => p === r.path || p.startsWith(`${r.path}/`))
  if (route) return route.label.toLowerCase().startsWith('the ') ? route.label : `${route.label}`
  if (!p.startsWith('/admin')) return p === '/' ? 'the home page' : 'that page of your site'
  return 'that screen'
}

export function navPhrase(path: string): string {
  return `Opened ${placeName(path)}`
}
