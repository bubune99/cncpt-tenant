/**
 * Run: npx -y tsx@4.23.15 src/lib/admin/nav-phrases.assert.ts
 */
import assert from 'node:assert/strict'
import { navPhrase } from './nav-phrases'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('plain words, never a raw path', () => {
  assert.equal(navPhrase('/admin/media'), 'Opened the media library')
  assert.equal(navPhrase('/admin/pages/cmv13e31n000106l5x0lnqvqo/editor'), 'Opened the page editor')
  assert.equal(navPhrase('/admin/todo?view=all'), 'Opened your To-do list')
  assert.equal(navPhrase('/admin'), 'Opened the dashboard')
  assert.equal(navPhrase('/'), 'Opened the home page')
  for (const p of ['/admin/audit-log', '/admin/whatever/x', '/about']) assert.doesNotMatch(navPhrase(p), /\//)
})

console.log(`\n${n} checks passed`)
