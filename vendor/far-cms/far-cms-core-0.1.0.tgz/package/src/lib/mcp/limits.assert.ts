/**
 * Run: npx -y tsx@4.23.15 src/lib/mcp/limits.assert.ts
 */
import assert from 'node:assert/strict'
import {
  DEFAULT_KEY_LIMITS,
  RATE_LIMITED_CODE,
  SPIKE_REFUSALS,
  chargesFor,
  costClassOf,
  decideDaily,
  decideMinute,
  jsonRpcRefusal,
  limitsFrom,
  parseMessages,
  refusalHeaders,
  shouldAlert,
} from './limits'
import { credentialFrom, deprecationHeaders, isMcpHost, mcpHosts, mcpPublicUrls, originAllowed, routeForHost } from './host'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const EFFECT: Record<string, string> = { list_pages: 'read', getPageBlocks: 'read', updateBlock: 'draft', update_setting: 'write', screenshot_page: 'write' }
const effectOf = (t: string) => EFFECT[t]
const NOW = Date.UTC(2026, 9, 10, 23, 0, 0)
const call = (id: number, name: string) => ({ jsonrpc: '2.0', id, method: 'tools/call', params: { name, arguments: {} } })

check('cost classes: reads, writes (drafts too), heavy tools; unknown counts as write', () => {
  assert.equal(costClassOf('list_pages', effectOf), 'read')
  assert.equal(costClassOf('updateBlock', effectOf), 'write')
  assert.equal(costClassOf('screenshot_page', effectOf), 'heavy')
  assert.equal(costClassOf('upload_media_from_url', effectOf), 'heavy')
  assert.equal(costClassOf('brand_new_tool', effectOf), 'write')
})

check('a batch is charged per message; only tools/call is charged to a class', () => {
  const msgs = parseMessages([{ jsonrpc: '2.0', id: 1, method: 'tools/list' }, call(2, 'list_pages'), call(3, 'screenshot_page'), call(4, 'updateBlock')])
  assert.deepEqual(chargesFor(msgs, effectOf), { total: 4, byClass: { read: 1, write: 1, heavy: 1 } })
  assert.equal(parseMessages(null).length, 1)
  assert.equal(parseMessages(call(9, 'x'))[0].tool, 'x')
})

check('a key over the minute limit → 429 with Retry-After and a JSON-RPC error per message', () => {
  const d = decideMinute({ allowed: false, resetAt: NOW + 42_000 }, 90, NOW, 'minute')
  assert.ok(!d.ok && d.status === 429 && d.retryAfterSeconds === 42)
  if (d.ok) return
  assert.equal(refusalHeaders(d)['Retry-After'], '42')
  const msgs = parseMessages([call(1, 'list_pages'), call(2, 'list_pages')])
  const body = jsonRpcRefusal(d, msgs, true) as Array<{ id: number; error: { code: number; data: { retryAfter: number } } }>
  assert.deepEqual(body.map((e) => e.id), [1, 2])
  assert.equal(body[0].error.code, RATE_LIMITED_CODE)
  assert.equal(body[0].error.data.retryAfter, 42)
  const single = jsonRpcRefusal(d, parseMessages(call(7, 'x')), false) as { id: number }
  assert.equal(single.id, 7)
  assert.deepEqual(decideMinute({ allowed: true, resetAt: NOW }, 90, NOW, 'minute'), { ok: true })
  const degraded = decideMinute({ allowed: false, resetAt: NOW + 1000, degraded: true }, 90, NOW, 'minute')
  assert.ok(!degraded.ok && degraded.status === 503)
  const heavy = decideMinute({ allowed: false, resetAt: NOW + 5000 }, 6, NOW, 'heavy-minute')
  assert.ok(!heavy.ok && heavy.costClass === 'heavy')
})

check('daily budget by cost class: heavy runs out first; reads still work; resets at UTC midnight', () => {
  const L = DEFAULT_KEY_LIMITS
  const heavyCall = chargesFor(parseMessages(call(1, 'screenshot_page')), effectOf)
  const over = decideDaily({ total: 100, byClass: { read: 30, write: 9, heavy: L.daily.heavy + 1 } }, heavyCall, L, NOW)
  assert.ok(!over.ok && over.scope === 'daily-class' && over.costClass === 'heavy' && over.retryAfterSeconds === 3600)
  // The same day, a READ isn't refused because heavy ran out.
  const readCall = chargesFor(parseMessages(call(2, 'list_pages')), effectOf)
  assert.deepEqual(decideDaily({ total: 101, byClass: { read: 31, write: 9, heavy: L.daily.heavy + 1 } }, readCall, L, NOW), { ok: true })
  const total = decideDaily({ total: L.dailyTotal + 1, byClass: { read: 1, write: 0, heavy: 0 } }, readCall, L, NOW)
  assert.ok(!total.ok && total.scope === 'daily-total')
  const writes = decideDaily({ total: 600, byClass: { read: 0, write: L.daily.write + 1, heavy: 0 } }, chargesFor(parseMessages(call(3, 'updateBlock')), effectOf), L, NOW)
  assert.ok(!writes.ok && writes.costClass === 'write')
})

check('limits come from optional env overrides; junk falls back', () => {
  const l = limitsFrom({ MCP_KEY_RATE_PER_MINUTE: '30', MCP_KEY_DAILY_HEAVY: 'lots', MCP_KEY_DAILY_WRITE: '0' })
  assert.equal(l.perMinute, 30)
  assert.equal(l.daily.heavy, DEFAULT_KEY_LIMITS.daily.heavy)
  assert.equal(l.daily.write, DEFAULT_KEY_LIMITS.daily.write)
})

check('owner alert: a daily budget running out, or a spike of refusals', () => {
  assert.equal(shouldAlert(1, 'daily-class'), true)
  assert.equal(shouldAlert(3, 'minute'), false)
  assert.equal(shouldAlert(SPIKE_REFUSALS, 'minute'), true)
})

check('MCP host: "/" and "/mcp" reach the handler; every main-site path is a 404', () => {
  const hosts = mcpHosts(' https://MCP.example.org/ , mcp-staging.example.org:443')
  assert.deepEqual(hosts, ['mcp.example.org', 'mcp-staging.example.org'])
  const r = (pathname: string, extra: Partial<{ host: string; method: string; origin: string | null }> = {}) =>
    routeForHost({ host: 'mcp.example.org', pathname, method: 'POST', origin: null, hosts, ...extra })
  assert.deepEqual(r('/mcp'), { kind: 'mcp', path: '/mcp' })
  assert.deepEqual(r('/'), { kind: 'mcp', path: '/mcp' })
  for (const p of ['/admin', '/admin/forms', '/api/forms/x/submit', '/handler/sign-in', '/about', '/mcp/extra']) assert.deepEqual(r(p), { kind: 'not-found' }, p)
  assert.deepEqual(r('/admin', { host: 'www.example.org' }), { kind: 'site' })
  assert.deepEqual(r('/mcp', { host: 'MCP.example.org:443' }), { kind: 'mcp', path: '/mcp' })
  assert.equal(isMcpHost('example.org', []), false)
})

check('MCP host: strict CORS — no cross-origin browsers; preflight allows nothing', () => {
  const hosts = ['mcp.example.org']
  assert.deepEqual(routeForHost({ host: 'mcp.example.org', pathname: '/mcp', method: 'POST', origin: 'https://evil.example', hosts }), { kind: 'forbidden-origin' })
  assert.deepEqual(routeForHost({ host: 'mcp.example.org', pathname: '/mcp', method: 'OPTIONS', origin: 'https://evil.example', hosts }), { kind: 'preflight' })
  assert.equal(originAllowed('https://mcp.example.org', 'mcp.example.org'), true)
  assert.equal(originAllowed('null', 'mcp.example.org'), false)
})

check('a cookie-only request carries no credential → 401 (cookies are never auth here)', () => {
  assert.equal(credentialFrom({ cookie: '__Secure-hexclave-access=abc; stack-refresh-x=1' }), null)
  assert.equal(credentialFrom({ authorization: 'Bearer cms_x', cookie: 'hexclave-access=abc' }), 'Bearer cms_x')
  assert.equal(credentialFrom({ xApiKey: 'cms_y' }), 'cms_y')
})

check('the old /mcp is marked deprecated, pointing at the new host when set', () => {
  assert.deepEqual(deprecationHeaders([]), { Deprecation: 'true' })
  assert.deepEqual(deprecationHeaders(['mcp.example.org']), { Deprecation: 'true', Link: '<https://mcp.example.org/mcp>; rel="successor-version"' })
  assert.deepEqual(mcpPublicUrls(['mcp.example.org']), ['https://mcp.example.org/mcp'])
})

console.log(`\n${n} checks passed`)
