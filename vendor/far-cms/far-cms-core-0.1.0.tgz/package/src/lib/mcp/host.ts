/**
 * MCP on its own host — the routing and auth rules, pure (asserted by
 * host.assert.ts). Edge-safe (no Node APIs): middleware imports it.
 *
 * MCP_PUBLIC_HOST (comma-separated, e.g. "mcp.example.org,mcp-staging.example.org"):
 *   - on those hosts, "/" and "/mcp" reach the MCP handler; every other path
 *     is a 404 (no site, no admin);
 *   - API keys only — site session cookies are dropped before the handler;
 *   - strict CORS: no cross-origin browser calls (MCP clients are programs).
 * The old /mcp on the main domain keeps working, marked deprecated.
 */

/** Hosts from MCP_PUBLIC_HOST, normalised (lowercase, no scheme/port/path). */
export function mcpHosts(raw: string | undefined | null): string[] {
  return (raw ?? '')
    .split(',')
    .map((h) => h.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/:\d+$/, '').replace(/\.$/, ''))
    .filter(Boolean)
}

export function hostOf(hostHeader: string | null | undefined): string {
  return (hostHeader ?? '').trim().toLowerCase().replace(/:\d+$/, '').replace(/\.$/, '')
}

export function isMcpHost(hostHeader: string | null | undefined, hosts: readonly string[]): boolean {
  const h = hostOf(hostHeader)
  return !!h && hosts.includes(h)
}

export type HostRoute =
  /** Not the MCP host — the normal site. */
  | { kind: 'site' }
  /** MCP host: rewrite to the handler, without cookies. */
  | { kind: 'mcp'; path: '/mcp' }
  /** MCP host, any other path. */
  | { kind: 'not-found' }
  /** MCP host, a browser on another origin. */
  | { kind: 'forbidden-origin' }
  /** MCP host, CORS preflight: answer without allowing anything. */
  | { kind: 'preflight' }

export function routeForHost(input: { host: string | null; pathname: string; method: string; origin: string | null; hosts: readonly string[] }): HostRoute {
  if (!isMcpHost(input.host, input.hosts)) return { kind: 'site' }
  const path = input.pathname.replace(/\/+$/, '') || '/'
  if (path !== '/' && path !== '/mcp') return { kind: 'not-found' }
  if (input.method === 'OPTIONS') return { kind: 'preflight' }
  if (!originAllowed(input.origin, input.host)) return { kind: 'forbidden-origin' }
  return { kind: 'mcp', path: '/mcp' }
}

/**
 * Strict CORS / DNS-rebinding guard: no Origin (a program) is fine; a
 * browser may only call from the MCP host itself.
 */
export function originAllowed(origin: string | null, host: string | null): boolean {
  if (!origin) return true
  try {
    return hostOf(new URL(origin).host) === hostOf(host)
  } catch {
    return false
  }
}

/** The API key a request carries — from headers only. Cookies are never a credential here. */
export function credentialFrom(headers: { authorization?: string | null; xApiKey?: string | null; cookie?: string | null }): string | null {
  return headers.authorization?.trim() || headers.xApiKey?.trim() || null
}

/** Headers for a call on the old /mcp address. */
export function deprecationHeaders(hosts: readonly string[]): Record<string, string> {
  const out: Record<string, string> = { Deprecation: 'true' }
  if (hosts[0]) out.Link = `<https://${hosts[0]}/mcp>; rel="successor-version"`
  return out
}

/** "The URL to give MCP clients". */
export function mcpPublicUrls(hosts: readonly string[]): string[] {
  return hosts.map((h) => `https://${h}/mcp`)
}
