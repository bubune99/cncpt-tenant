/**
 * MCP per-API-key limits — the decisions, pure (asserted by limits.assert.ts).
 *
 * The edge allows 120/min per IP; it can't key on a header on this plan, so
 * the app limits per API KEY, after auth:
 *   - per minute: every JSON-RPC message (a batch of N costs N), plus a
 *     tighter per-minute cap for HEAVY tools (screenshots, imports);
 *   - per day (UTC): a total budget AND a budget per COST CLASS —
 *     read (look things up), write (change/draft something), heavy (costly).
 * Only tools/call messages are charged to a class; protocol messages
 * (initialize, tools/list, ping) count toward the minute and the total.
 *
 * Over a limit → 429 with Retry-After and a JSON-RPC error body any MCP
 * client can show.
 */

export type CostClass = 'read' | 'write' | 'heavy'
export const COST_CLASSES: readonly CostClass[] = ['read', 'write', 'heavy']

/** Costly tools: a browser render, a remote fetch, a project import. */
export const HEAVY_TOOLS: ReadonlySet<string> = new Set(['screenshot_page', 'upload_media_from_url', 'import_from_project', 'scan_project'])

/**
 * A tool's class from its governance label (effect: read | write | draft |
 * irreversible). Unknown tools count as write — never cheaper than known.
 */
export function costClassOf(tool: string, effectOf: (name: string) => string | undefined): CostClass {
  if (HEAVY_TOOLS.has(tool)) return 'heavy'
  return effectOf(tool) === 'read' ? 'read' : 'write'
}

export interface McpMessage {
  id: string | number | null
  method: string
  /** tools/call only. */
  tool?: string
}

/** The JSON-RPC messages in a request body (a batch or one). Junk counts as one message. */
export function parseMessages(body: unknown): McpMessage[] {
  const list = Array.isArray(body) ? body : [body]
  if (!list.length) return [{ id: null, method: '' }]
  return list.map((m) => {
    const o = (m && typeof m === 'object' ? m : {}) as Record<string, unknown>
    const id = typeof o.id === 'string' || typeof o.id === 'number' ? o.id : null
    const method = typeof o.method === 'string' ? o.method : ''
    const params = (o.params && typeof o.params === 'object' ? o.params : {}) as Record<string, unknown>
    return method === 'tools/call' && typeof params.name === 'string' ? { id, method, tool: params.name } : { id, method }
  })
}

export interface Charges {
  /** Every message (the minute limit and the daily total). */
  total: number
  byClass: Record<CostClass, number>
}

export function chargesFor(messages: ReadonlyArray<McpMessage>, effectOf: (name: string) => string | undefined): Charges {
  const byClass: Record<CostClass, number> = { read: 0, write: 0, heavy: 0 }
  for (const m of messages) if (m.tool) byClass[costClassOf(m.tool, effectOf)]++
  return { total: messages.length, byClass }
}

export interface KeyLimits {
  perMinute: number
  heavyPerMinute: number
  dailyTotal: number
  daily: Record<CostClass, number>
}

export const DEFAULT_KEY_LIMITS: KeyLimits = {
  perMinute: 90,
  heavyPerMinute: 6,
  dailyTotal: 5000,
  daily: { read: 4000, write: 500, heavy: 60 },
}

function positive(raw: string | undefined, fallback: number): number {
  const n = Number.parseInt(raw ?? '', 10)
  return Number.isFinite(n) && n > 0 ? n : fallback
}

/** Limits from env overrides (all optional; the defaults apply when unset). */
export function limitsFrom(env: Record<string, string | undefined>): KeyLimits {
  const d = DEFAULT_KEY_LIMITS
  return {
    perMinute: positive(env.MCP_KEY_RATE_PER_MINUTE, d.perMinute),
    heavyPerMinute: positive(env.MCP_KEY_HEAVY_PER_MINUTE, d.heavyPerMinute),
    dailyTotal: positive(env.MCP_KEY_DAILY_BUDGET, d.dailyTotal),
    daily: {
      read: positive(env.MCP_KEY_DAILY_READ, d.daily.read),
      write: positive(env.MCP_KEY_DAILY_WRITE, d.daily.write),
      heavy: positive(env.MCP_KEY_DAILY_HEAVY, d.daily.heavy),
    },
  }
}

const DAY_MS = 86_400_000

export function secondsUntilUtcMidnight(now: number): number {
  return Math.max(1, Math.ceil((Math.floor(now / DAY_MS + 1) * DAY_MS - now) / 1000))
}

export type LimitScope = 'minute' | 'heavy-minute' | 'daily-total' | 'daily-class'

export type LimitDecision =
  | { ok: true }
  | { ok: false; status: 429 | 503; scope: LimitScope | 'accounting'; costClass?: CostClass; limit: number; retryAfterSeconds: number; message: string }

/** A per-minute limiter result (lib/rate-limit) → decision. */
export function decideMinute(r: { allowed: boolean; resetAt: number; degraded?: boolean }, limit: number, now: number, scope: 'minute' | 'heavy-minute'): LimitDecision {
  if (r.allowed) return { ok: true }
  const retryAfterSeconds = Math.max(1, Math.ceil((r.resetAt - now) / 1000))
  if (r.degraded) return { ok: false, status: 503, scope: 'accounting', limit, retryAfterSeconds, message: 'Usage limits are unavailable right now, so the call was refused. Try again shortly.' }
  return {
    ok: false,
    status: 429,
    scope,
    ...(scope === 'heavy-minute' ? { costClass: 'heavy' as const } : {}),
    limit,
    retryAfterSeconds,
    message: scope === 'heavy-minute' ? `This API key may make ${limit} heavy calls (screenshots, imports) a minute. Wait ${retryAfterSeconds}s.` : `This API key may make ${limit} calls a minute. Wait ${retryAfterSeconds}s.`,
  }
}

/**
 * Daily: `used` = counts for today INCLUDING this request. The total first,
 * then each class this request actually charged.
 */
export function decideDaily(used: { total: number; byClass: Record<CostClass, number> }, charges: Charges, limits: KeyLimits, now: number): LimitDecision {
  const retryAfterSeconds = secondsUntilUtcMidnight(now)
  if (used.total > limits.dailyTotal) {
    return { ok: false, status: 429, scope: 'daily-total', limit: limits.dailyTotal, retryAfterSeconds, message: `This API key has used its ${limits.dailyTotal} calls for today. It resets at 00:00 UTC.` }
  }
  for (const c of COST_CLASSES) {
    if (charges.byClass[c] > 0 && used.byClass[c] > limits.daily[c]) {
      const what = c === 'read' ? 'read' : c === 'write' ? 'change' : 'heavy (screenshot / import)'
      return { ok: false, status: 429, scope: 'daily-class', costClass: c, limit: limits.daily[c], retryAfterSeconds, message: `This API key has used its ${limits.daily[c]} ${what} calls for today. It resets at 00:00 UTC.` }
    }
  }
  return { ok: true }
}

/** JSON-RPC error code for "rate limited" (implementation-defined server error range). */
export const RATE_LIMITED_CODE = -32029

/** A JSON-RPC-shaped refusal: one error per message id (an array for a batch). */
export function jsonRpcRefusal(d: Extract<LimitDecision, { ok: false }>, messages: ReadonlyArray<McpMessage>, batch: boolean): unknown {
  const err = (id: string | number | null) => ({
    jsonrpc: '2.0',
    id,
    error: { code: d.status === 503 ? -32000 : RATE_LIMITED_CODE, message: d.message, data: { status: d.status, scope: d.scope, costClass: d.costClass ?? null, limit: d.limit, retryAfter: d.retryAfterSeconds } },
  })
  return batch ? messages.map((m) => err(m.id)) : err(messages[0]?.id ?? null)
}

export function refusalHeaders(d: Extract<LimitDecision, { ok: false }>): Record<string, string> {
  return { 'Content-Type': 'application/json', 'Retry-After': String(d.retryAfterSeconds), 'X-RateLimit-Limit': String(d.limit), 'X-RateLimit-Remaining': '0' }
}

/** Refusals per key per day that count as a spike worth telling the owner about (alert once at the threshold). */
export const SPIKE_REFUSALS = 25

/**
 * Tell the owner? A daily budget running out always counts; otherwise once
 * refusals for the key today reach the spike threshold. (The alert itself is
 * one To-do per key per day, so repeats don't add up.)
 */
export function shouldAlert(refusalsToday: number, scope: string): boolean {
  return scope === 'daily-total' || scope === 'daily-class' || refusalsToday >= SPIKE_REFUSALS
}
