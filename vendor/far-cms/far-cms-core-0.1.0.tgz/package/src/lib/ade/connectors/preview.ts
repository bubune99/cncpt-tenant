/**
 * What the person approves before an email is sent — pure; asserted.
 *
 * The send preview is resolved on the SERVER from the draft itself (sender,
 * recipients incl. Bcc, subject, the WHOLE body, attachments, the thread it
 * replies in) and signed with a short-lived token bound to the person, the
 * provider and the draft. The send tool carries both, so the approval card
 * shows exactly what will go out; at send the draft is read once more and the
 * send is refused when it no longer matches (edited since), when the preview
 * isn't the one we signed, or when the token has expired.
 */

import { createHash, createHmac, timingSafeEqual } from 'node:crypto'
import type { ConnectorProvider } from './types'
import { alternativeConflict } from './mime'

/** Bodies longer than this can't be approved in chat (they would not fit on the card whole). */
export const PREVIEW_TEXT_CAP = 20_000
export const PREVIEW_SUBJECT_CAP = 998
/** How long an approval preview stays valid. */
export const PREVIEW_TTL_MS = 30 * 60_000

export interface SendPreview {
  from: string | null
  to: string[]
  cc: string[]
  bcc: string[]
  subject: string
  /** The whole body (never cut: a longer one can't be prepared). */
  textBody: string
  /** SHA-256 of the whole body, as the canonical form compares it. */
  bodySha256: string
  /** File names of attachments on the draft. */
  attachments: string[]
  /** The thread the draft sits in (Gmail threadId / Graph conversationId), or null for a new message. */
  thread: string | null
  /** The In-Reply-To header of the draft (Gmail), or null. */
  inReplyTo: string | null
  /** The message being answered and its sender, when the reply was written here (signed with the rest). */
  replyTo: { messageId: string; from: string } | null
  /** For a multipart/alternative draft: SHA-256 of the plain and the HTML part, so a change to either is caught (C-26). */
  partsSha256?: [string, string] | null
}

export interface DraftForPreview {
  from: string | null
  to: readonly string[]
  cc: readonly string[]
  bcc?: readonly string[]
  subject: string
  text: string
  attachments?: readonly string[]
  threadId?: string | null
  inReplyTo?: string | null
  /** Both bodies when multipart/alternative. */
  alternative?: { plain: string; html: string } | null
}

const norm = (a: readonly string[]) => a.map((x) => x.trim().toLowerCase()).filter(Boolean)
const body = (t: string) => t.replace(/\r\n/g, '\n').trim()
export const sha256 = (s: string) => createHash('sha256').update(s, 'utf8').digest('hex')

export type PreviewBuild = { ok: true; preview: SendPreview } | { ok: false; error: string }

export function sendPreviewOf(d: DraftForPreview, account: string | null, replyTo: SendPreview['replyTo'] = null): PreviewBuild {
  const text = body(d.text)
  if (text.length > PREVIEW_TEXT_CAP) return { ok: false, error: `This email is too long to approve in the chat (over ${PREVIEW_TEXT_CAP.toLocaleString('en')} characters). Send it from your mailbox.` }
  const subject = d.subject.trim()
  if (subject.length > PREVIEW_SUBJECT_CAP) return { ok: false, error: 'The subject is too long to send.' }
  // A text-only reader gets the plain part: it must say what the approved (HTML) text says (C-26).
  const alt = d.alternative ?? null
  if (alt && alternativeConflict(alt.plain, alt.html)) {
    return { ok: false, error: 'This draft’s plain-text version says something different from what’s shown. Open it in your mailbox to fix it, or send it from there.' }
  }
  return {
    ok: true,
    preview: {
      from: (d.from || account || null)?.toLowerCase() ?? null,
      to: norm(d.to),
      cc: norm(d.cc),
      bcc: norm(d.bcc ?? []),
      subject,
      textBody: text,
      bodySha256: sha256(text),
      attachments: [...(d.attachments ?? [])].map((a) => a.trim()).filter(Boolean),
      thread: d.threadId ?? null,
      inReplyTo: d.inReplyTo ?? null,
      replyTo,
      partsSha256: alt ? [sha256(body(alt.plain)), sha256(body(alt.html))] : null,
    },
  }
}

/** Order-stable form of a preview (the token and the "changed?" check compare this). */
export function canonicalPreview(p: SendPreview): string {
  return JSON.stringify([
    p.from ?? '',
    norm(p.to),
    norm(p.cc),
    norm(p.bcc ?? []),
    p.subject.trim(),
    // The hash of the whole body (and the body itself, which must match it).
    sha256(body(p.textBody)),
    p.bodySha256,
    [...(p.attachments ?? [])].sort(),
    p.thread ?? '',
    p.inReplyTo ?? '',
    p.replyTo ? [p.replyTo.messageId, p.replyTo.from.toLowerCase()] : null,
    p.partsSha256 ?? null,
  ])
}

const mac = (secret: string, parts: unknown[]) => createHmac('sha256', secret).update(JSON.stringify(parts)).digest('hex')

/** "<expiresAt>.<hmac>" over a JSON array — no ambiguous framing — valid for PREVIEW_TTL_MS. */
export function previewToken(secret: string, q: { userId: string; provider: ConnectorProvider; draftId: string; preview: SendPreview; now: number }): string {
  const exp = q.now + PREVIEW_TTL_MS
  return `${exp}.${mac(secret, [q.userId, q.provider, q.draftId, canonicalPreview(q.preview), exp])}`
}

export type PreviewCheck = { ok: true } | { ok: false; reason: 'forged' | 'changed' | 'expired'; message: string }

/**
 * Send only what was approved: `given` must be the preview we signed (token,
 * not expired) and must still equal the draft as it is now (`current`).
 */
export function checkSendPreview(q: {
  secret: string
  userId: string
  provider: ConnectorProvider
  draftId: string
  given: SendPreview | null | undefined
  token: string | null | undefined
  current: SendPreview
  now: number
}): PreviewCheck {
  const m = typeof q.token === 'string' ? /^(\d{10,16})\.([0-9a-f]{64})$/.exec(q.token) : null
  if (!q.given || !m) return { ok: false, reason: 'forged', message: 'No signed preview: get one with email_prepare_send (or from the draft you just wrote), then ask again.' }
  const exp = Number(m[1])
  const want = Buffer.from(mac(q.secret, [q.userId, q.provider, q.draftId, canonicalPreview(q.given), exp]), 'hex')
  const got = Buffer.from(m[2], 'hex')
  if (want.length !== got.length || !timingSafeEqual(want, got)) return { ok: false, reason: 'forged', message: 'That preview isn’t the one prepared for this draft. Prepare it again.' }
  if (exp < q.now) return { ok: false, reason: 'expired', message: 'That approval is more than 30 minutes old. Prepare the email again and ask the person to approve it.' }
  if (sha256(body(q.given.textBody)) !== q.given.bodySha256 || canonicalPreview(q.given) !== canonicalPreview(q.current)) {
    return { ok: false, reason: 'changed', message: 'The draft changed after it was shown for approval, so it was not sent. Show the new version and ask again.' }
  }
  return { ok: true }
}
