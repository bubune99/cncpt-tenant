/**
 * The two mail providers: endpoints, the minimal scopes, the env each needs.
 * Checked 2026-10-11 against Google's OAuth 2.0 web-server docs + the
 * Workspace MCP guide (developers.google.com/workspace/guides/configure-mcp-servers)
 * and Microsoft identity platform v2.0 + Graph mail permissions.
 *
 * Scopes are the least that read, draft and send:
 *   Google    gmail.readonly (read) + gmail.compose (drafts and sending them) — the
 *             same pair the official Gmail MCP server asks for. No delete, no settings.
 *   Microsoft Mail.ReadWrite (read + drafts) + Mail.Send. No mailbox settings,
 *             no contacts, no calendar. offline_access gives the refresh token.
 */

import type { ConnectorProvider, MailCapability } from './types'

type Env = Record<string, string | undefined>

export interface ProviderDef {
  provider: ConnectorProvider
  label: string
  env: readonly string[]
  scopes: readonly string[]
  authUrl(env: Env): string
  tokenUrl(env: Env): string
  /** Token revocation endpoint, or null when the provider has none for one app's grant. */
  revokeUrl: string | null
  /** Where the person removes the app's access themselves (shown after Disconnect when revokeUrl is null). */
  manageUrl: string | null
  /** Extra /authorize params (offline access, consent). */
  authParams: Readonly<Record<string, string>>
}

const msTenant = (env: Env) => {
  const t = env.MS_OAUTH_TENANT?.trim() || 'common'
  // A GUID or one of Microsoft's named audiences; anything else is refused (no path tricks).
  return /^[0-9a-f-]{36}$/i.test(t) || ['common', 'organizations', 'consumers'].includes(t) ? t : 'invalid-tenant'
}

export const PROVIDERS: Readonly<Record<ConnectorProvider, ProviderDef>> = {
  google: {
    provider: 'google',
    label: 'Gmail',
    env: ['GOOGLE_OAUTH_CLIENT_ID', 'GOOGLE_OAUTH_CLIENT_SECRET'],
    scopes: ['openid', 'email', 'https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.compose'],
    authUrl: () => 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: () => 'https://oauth2.googleapis.com/token',
    revokeUrl: 'https://oauth2.googleapis.com/revoke',
    manageUrl: 'https://myaccount.google.com/connections',
    // offline → a refresh token; consent → Google sends it again on reconnect.
    authParams: { access_type: 'offline', prompt: 'consent', include_granted_scopes: 'true' },
  },
  microsoft: {
    provider: 'microsoft',
    label: 'Outlook',
    env: ['MS_OAUTH_CLIENT_ID', 'MS_OAUTH_CLIENT_SECRET', 'MS_OAUTH_TENANT'],
    scopes: ['openid', 'email', 'offline_access', 'https://graph.microsoft.com/User.Read', 'https://graph.microsoft.com/Mail.ReadWrite', 'https://graph.microsoft.com/Mail.Send'],
    authUrl: (env) => `https://login.microsoftonline.com/${msTenant(env)}/oauth2/v2.0/authorize`,
    tokenUrl: (env) => `https://login.microsoftonline.com/${msTenant(env)}/oauth2/v2.0/token`,
    // Microsoft has no per-app refresh-token revoke (revokeSignInSessions signs the person out everywhere).
    revokeUrl: null,
    manageUrl: 'https://myapplications.microsoft.com/',
    authParams: { prompt: 'select_account' },
  },
}

/** Set up on this deployment? Names of what's missing, never values. A missing tenant falls back to 'common'. */
export function providerConfigStatus(provider: ConnectorProvider, env: Env): { configured: boolean; missing: string[] } {
  const required = PROVIDERS[provider].env.filter((k) => k !== 'MS_OAUTH_TENANT')
  const missing = required.filter((k) => !env[k]?.trim())
  if (provider === 'microsoft' && msTenant(env) === 'invalid-tenant') missing.push('MS_OAUTH_TENANT')
  return { configured: missing.length === 0, missing }
}

export function clientCredentials(provider: ConnectorProvider, env: Env): { clientId: string; clientSecret: string } | null {
  const [idKey, secretKey] = PROVIDERS[provider].env
  const clientId = env[idKey]?.trim()
  const clientSecret = env[secretKey]?.trim()
  return clientId && clientSecret ? { clientId, clientSecret } : null
}

/** What the granted scopes allow (a person can untick scopes on Google's consent screen). */
export function capabilitiesOf(provider: ConnectorProvider, granted: readonly string[]): MailCapability[] {
  const has = (s: string) => granted.some((g) => g === s || g.endsWith(`/${s}`) || g.toLowerCase() === s.toLowerCase())
  const out: MailCapability[] = []
  if (provider === 'google') {
    if (has('gmail.readonly') || has('gmail.modify')) out.push('read')
    if (has('gmail.compose') || has('gmail.modify')) out.push('draft', 'send')
  } else {
    if (has('Mail.Read') || has('Mail.ReadWrite')) out.push('read')
    if (has('Mail.ReadWrite')) out.push('draft')
    if (has('Mail.Send')) out.push('send')
  }
  return out
}
