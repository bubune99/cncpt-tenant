/**
 * Personal connectors — one person's own mailbox, reached with their own
 * OAuth grant. App-agnostic core (BYB syncs this folder); the host stores
 * the tokens (encrypted) and mounts the routes.
 */

export type ConnectorProvider = 'google' | 'microsoft'
export const CONNECTOR_PROVIDERS: readonly ConnectorProvider[] = ['google', 'microsoft']
export const isConnectorProvider = (v: unknown): v is ConnectorProvider => v === 'google' || v === 'microsoft'

/**
 * Who a connection belongs to. Only 'personal' exists: the mailbox is seen by
 * its owner and their own assistant, nobody else. ('shared' — a team inbox
 * with an allow-list — is left room for, not built.)
 */
export type ConnectorScope = 'personal'

export type ConnectorStatus = 'active' | 'needs-reconnect'

/** What a grant lets the assistant do, in plain verbs. */
export type MailCapability = 'read' | 'draft' | 'send'

/** A stored connection as the core sees it (tokens already decrypted by the host). */
export interface ConnectorTokens {
  accessToken: string
  refreshToken: string | null
  expiresAt: Date | null
  grantedScopes: string[]
}

export interface MailAddress {
  name: string
  email: string
}

export interface MailThreadSummary {
  id: string
  subject: string
  from: MailAddress
  snippet: string
  date: string
  unread: boolean
  messageCount: number
}

export interface MailMessage {
  id: string
  from: MailAddress
  to: MailAddress[]
  cc: MailAddress[]
  date: string
  /** Plain text only (HTML is converted, never passed through), capped. */
  text: string
}

export interface MailThread {
  id: string
  subject: string
  messages: MailMessage[]
}

export interface MailDraftInput {
  to: string[]
  cc?: string[]
  subject: string
  text: string
  /** Reply in a thread: the provider threads it and copies In-Reply-To. */
  replyTo?: { threadId: string; messageId: string }
}

export interface MailDraft {
  id: string
  threadId?: string
  to: string[]
  cc: string[]
  /** Read from the draft (a draft made elsewhere may carry one); ours never set it, and rewriting clears it. */
  bcc: string[]
  subject: string
}

export interface DraftDetail extends MailDraft {
  replyToThreadId?: string | null
  /** The whole body as text (capText-cut when huge, which the preview then refuses). */
  text: string
  from: string | null
  /** File names of attached files. */
  attachments: string[]
  /** The In-Reply-To header (Gmail); Graph has none on drafts, so its thread stands in. */
  inReplyTo: string | null
  /** Both bodies when the draft is multipart/alternative (Gmail); null/absent for a single body. */
  alternative?: { plain: string; html: string } | null
}

/**
 * One mailbox, whatever is behind it (Gmail REST, Gmail MCP, Microsoft
 * Graph). Every method acts as the connected person, with their token.
 */
export interface MailAdapter {
  readonly via: 'mcp' | 'api'
  searchThreads(q: { query?: string; cursor?: string | null; limit?: number }): Promise<{ threads: MailThreadSummary[]; next: string | null }>
  getThread(id: string): Promise<MailThread>
  listDrafts(q: { limit?: number }): Promise<MailDraft[]>
  /**
   * One DRAFT (never a received message: not-found otherwise) as it will go
   * out, for the send preview: sender, the body the recipient sees (HTML
   * drafts as text), attachment names and the message it answers.
   */
  getDraft(id: string): Promise<DraftDetail>
  createDraft(d: MailDraftInput): Promise<MailDraft>
  updateDraft(id: string, d: MailDraftInput): Promise<MailDraft>
  /** Sends an existing draft. Irreversible: callers gate it (approval + send guard). */
  sendDraft(id: string): Promise<{ id: string }>
}

/** Provider HTTP failure the host turns into "Reconnect" (401/invalid_grant) or a plain error. */
export class ConnectorError extends Error {
  constructor(
    message: string,
    readonly kind: 'reconnect' | 'not-found' | 'rate-limited' | 'provider',
    readonly status?: number
  ) {
    super(message)
    this.name = 'ConnectorError'
  }
}
