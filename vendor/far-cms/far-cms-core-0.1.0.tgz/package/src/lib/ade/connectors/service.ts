/**
 * Tokens in and out of the host's store, refreshed on expiry, revoked on
 * Disconnect; and the mailbox adapter for one person. The host provides the
 * store (encrypted at rest) and fetch; nothing here keeps tokens in memory
 * beyond one request.
 */

import { gmailAdapter } from './gmail'
import { graphAdapter } from './graph'
import { idTokenEmail, needsRefresh, parseTokenResponse, tokenRequestBody } from './oauth'
import { PROVIDERS, clientCredentials } from './providers'
import { ConnectorError, type ConnectorProvider, type ConnectorStatus, type ConnectorTokens, type MailAdapter } from './types'

type Env = Record<string, string | undefined>
type Fetch = typeof fetch

export interface StoredConnection extends ConnectorTokens {
  status: ConnectorStatus
  account: string | null
  connectedAt: Date
}

/** The host's storage for one person's connections (tokens encrypted at rest). */
export interface ConnectorStore {
  get(userId: string, provider: ConnectorProvider): Promise<StoredConnection | null>
  /** A new connection (the OAuth callback): create or replace. */
  save(userId: string, provider: ConnectorProvider, c: ConnectorTokens & { account: string | null }): Promise<void>
  /**
   * Refreshed tokens, stored ONLY while the connection is still active: a
   * refresh finishing after Disconnect (or "needs reconnect") must not bring
   * the row back. False = nothing was updated.
   */
  update(userId: string, provider: ConnectorProvider, c: ConnectorTokens & { account: string | null }): Promise<boolean>
  /** Keep the row, drop nothing: the person sees "Reconnect". */
  markReconnect(userId: string, provider: ConnectorProvider): Promise<void>
  /** Delete the row and its tokens. */
  remove(userId: string, provider: ConnectorProvider): Promise<void>
}

async function postToken(provider: ConnectorProvider, env: Env, body: URLSearchParams, fetchImpl: Fetch): Promise<unknown> {
  const res = await fetchImpl(PROVIDERS[provider].tokenUrl(env), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body,
  })
  return res.json().catch(() => ({ error: `http_${res.status}` }))
}

/** The code → tokens exchange (with the PKCE verifier). */
export async function exchangeCode(
  provider: ConnectorProvider,
  env: Env,
  q: { code: string; verifier: string; redirectUri: string },
  deps: { fetch?: Fetch; now?: number } = {}
): Promise<ConnectorTokens & { account: string | null }> {
  const creds = clientCredentials(provider, env)
  if (!creds) throw new ConnectorError('Not set up yet', 'provider')
  const json = await postToken(provider, env, tokenRequestBody(provider, { ...creds, grant: 'code', ...q }), deps.fetch ?? fetch)
  const parsed = parseTokenResponse(json, deps.now ?? Date.now())
  if (!parsed.ok) throw new ConnectorError(`Sign-in was not completed (${parsed.error})`, parsed.reconnect ? 'reconnect' : 'provider')
  return { ...parsed.tokens, account: idTokenEmail((json as { id_token?: unknown }).id_token) }
}

// One refresh at a time per person + provider (parallel calls share it).
const inFlight = new Map<string, Promise<string>>()

/**
 * A usable access token for this person's mailbox: refreshed when it is
 * about to expire. A refused refresh (revoked at the provider, expired
 * grant) marks the connection "needs reconnect" and throws.
 */
export async function accessTokenFor(
  store: ConnectorStore,
  userId: string,
  provider: ConnectorProvider,
  env: Env,
  deps: { fetch?: Fetch; now?: () => number; force?: boolean } = {}
): Promise<string> {
  const now = deps.now ?? Date.now
  const c = await store.get(userId, provider)
  if (!c) throw new ConnectorError('Not connected', 'not-found')
  if (c.status === 'needs-reconnect') throw new ConnectorError('Needs reconnecting', 'reconnect')
  if (!deps.force && !needsRefresh(c.expiresAt, now())) return c.accessToken
  const key = `${userId}\u0000${provider}`
  const running = inFlight.get(key)
  if (running) return running
  const job = (async () => {
    if (!c.refreshToken) {
      await store.markReconnect(userId, provider)
      throw new ConnectorError('Needs reconnecting', 'reconnect')
    }
    const creds = clientCredentials(provider, env)
    if (!creds) throw new ConnectorError('Not set up yet', 'provider')
    const json = await postToken(provider, env, tokenRequestBody(provider, { ...creds, grant: 'refresh', refreshToken: c.refreshToken }), deps.fetch ?? fetch)
    const parsed = parseTokenResponse(json, now(), c)
    if (!parsed.ok) {
      if (parsed.reconnect) {
        await store.markReconnect(userId, provider)
        throw new ConnectorError('Needs reconnecting', 'reconnect')
      }
      throw new ConnectorError(`Refreshing failed (${parsed.error})`, 'provider')
    }
    // Only an ACTIVE row takes the new tokens: disconnected meanwhile → nothing comes back.
    if (!(await store.update(userId, provider, { ...parsed.tokens, account: c.account }))) throw new ConnectorError('Not connected', 'not-found')
    return parsed.tokens.accessToken
  })()
  inFlight.set(key, job)
  try {
    return await job
  } finally {
    inFlight.delete(key)
  }
}

/**
 * Disconnect: revoke at the provider where it can be done for one app
 * (Google), then delete our copy whatever the provider said. Returns where
 * the person can remove access themselves when we couldn't (Microsoft).
 */
export async function disconnect(
  store: ConnectorStore,
  userId: string,
  provider: ConnectorProvider,
  deps: { fetch?: Fetch } = {}
): Promise<{ revoked: boolean; manageUrl: string | null }> {
  // A row we can't read (key rotated, corrupt) is still removed — never stuck connected.
  let c: StoredConnection | null = null
  try {
    c = await store.get(userId, provider)
  } catch {
    c = null
  }
  const def = PROVIDERS[provider]
  let revoked = false
  if (c && def.revokeUrl) {
    // Revoking the refresh token ends the whole grant (and its access tokens).
    const token = c.refreshToken ?? c.accessToken
    try {
      const res = await (deps.fetch ?? fetch)(def.revokeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ token }),
      })
      // Already revoked only when Google says the token is invalid — any other 400 is not a revoke.
      const body = res.ok ? null : ((await res.json().catch(() => null)) as { error?: unknown } | null)
      revoked = res.ok || (res.status === 400 && body?.error === 'invalid_token')
    } catch {
      revoked = false
    }
  }
  await store.remove(userId, provider)
  return { revoked, manageUrl: revoked ? null : def.manageUrl }
}

/** The mailbox for this person and provider. A 401 mid-call forces one refresh and retries once. */
export function mailboxFor(
  store: ConnectorStore,
  userId: string,
  provider: ConnectorProvider,
  env: Env,
  deps: { fetch?: Fetch; now?: () => number } = {}
): MailAdapter {
  let forced = false
  const token = () => accessTokenFor(store, userId, provider, env, { ...deps, force: forced })
  const base = provider === 'google' ? gmailAdapter(token, deps.fetch) : graphAdapter(token, deps.fetch)
  // Retry once on 401 with a forced refresh (an access token revoked or rotated early).
  const retry = <A extends unknown[], R>(fn: (...a: A) => Promise<R>) => async (...a: A): Promise<R> => {
    try {
      return await fn(...a)
    } catch (e) {
      if (!(e instanceof ConnectorError) || e.kind !== 'reconnect' || e.status !== 401 || forced) throw e
      forced = true
      try {
        return await fn(...a)
      } finally {
        forced = false
      }
    }
  }
  return {
    via: base.via,
    searchThreads: retry(base.searchThreads),
    getThread: retry(base.getThread),
    listDrafts: retry(base.listDrafts),
    getDraft: retry(base.getDraft),
    createDraft: retry(base.createDraft),
    updateDraft: retry(base.updateDraft),
    sendDraft: retry(base.sendDraft),
  }
}
