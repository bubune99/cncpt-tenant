/**
 * The send preview as the email tools accept it back from the model —
 * every field of SendPreview, so nothing the token signed is stripped on the
 * way (zod drops unknown keys; a missing partsSha256 would make every Gmail
 * multipart draft "forged"). Asserted round-trip in connectors.assert.ts.
 */

import { z } from 'zod'
import { PREVIEW_SUBJECT_CAP, PREVIEW_TEXT_CAP } from './preview'

export const sendPreviewSchema = z.object({
  from: z.string().max(320).nullable(),
  to: z.array(z.string().max(320)).max(50),
  cc: z.array(z.string().max(320)).max(50),
  bcc: z.array(z.string().max(320)).max(50),
  subject: z.string().max(PREVIEW_SUBJECT_CAP),
  textBody: z.string().max(PREVIEW_TEXT_CAP),
  bodySha256: z.string().max(64),
  attachments: z.array(z.string().max(512)).max(100),
  thread: z.string().max(512).nullable(),
  inReplyTo: z.string().max(998).nullable(),
  replyTo: z.object({ messageId: z.string().max(512), from: z.string().max(320) }).nullable(),
  partsSha256: z.tuple([z.string().max(64), z.string().max(64)]).nullable().optional(),
})
