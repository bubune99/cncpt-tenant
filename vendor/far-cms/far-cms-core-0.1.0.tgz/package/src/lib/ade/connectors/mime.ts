/**
 * Plain-text RFC 822 messages for Gmail drafts, and text out of MIME parts.
 * Pure; asserted. Header values are single lines (CR/LF stripped), so text
 * from anywhere can't add a Bcc or a second message.
 */

const oneLine = (s: string) => s.replace(/[\r\n]+/g, ' ').trim()
const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64')
export const b64urlEncode = (s: string) => b64(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
export const b64urlDecode = (s: string) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')

/** RFC 2047 for non-ASCII header text. */
export function encodeHeader(s: string): string {
  const v = oneLine(s)
  return /^[\x20-\x7e]*$/.test(v) ? v : `=?UTF-8?B?${b64(v)}?=`
}

const ADDRESS = /^[^\s@<>(),;:"\\[\]]+@[^\s@<>(),;:"\\[\]]+\.[^\s@<>(),;:"\\[\]]+$/

/** ASCII only: a look-alike (e.g. the Kelvin sign K, which lower-cases to k) can't pass as a typed address. */
export const isAsciiAddress = (a: string) => /^[\x21-\x7e]+$/.test(a) && ADDRESS.test(a)

/** Only bare ASCII addresses; anything else (display names, injected headers, look-alikes) is refused. */
export function cleanAddresses(list: readonly string[] | undefined): string[] {
  return (list ?? []).map((a) => a.trim()).filter((a) => isAsciiAddress(a) && a.length <= 320)
}

export function buildPlainMessage(m: {
  to: readonly string[]
  cc?: readonly string[]
  subject: string
  text: string
  inReplyTo?: string | null
  references?: string | null
}): string {
  const headers = [
    `To: ${cleanAddresses(m.to).join(', ')}`,
    ...(m.cc?.length ? [`Cc: ${cleanAddresses(m.cc).join(', ')}`] : []),
    `Subject: ${encodeHeader(m.subject)}`,
    ...(m.inReplyTo ? [`In-Reply-To: ${oneLine(m.inReplyTo)}`] : []),
    ...(m.references || m.inReplyTo ? [`References: ${oneLine(`${m.references ?? ''} ${m.inReplyTo ?? ''}`)}`] : []),
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
  ]
  const body = b64(m.text).replace(/.{76}/g, '$&\r\n')
  return `${headers.join('\r\n')}\r\n\r\n${body}`
}

/** "Ama <ama@x.org>" → { name, email }. */
export function parseAddress(raw: string | undefined | null): { name: string; email: string } {
  const s = (raw ?? '').trim()
  const m = s.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/)
  if (m) return { name: m[1].trim(), email: m[2].trim().toLowerCase() }
  return { name: '', email: s.toLowerCase() }
}

export function parseAddressList(raw: string | undefined | null): { name: string; email: string }[] {
  if (!raw) return []
  // Split on commas outside quotes/angle brackets.
  const out: string[] = []
  let cur = ''
  let q = false
  let a = 0
  for (const ch of raw) {
    if (ch === '"') q = !q
    if (ch === '<') a++
    if (ch === '>') a = Math.max(0, a - 1)
    if (ch === ',' && !q && a === 0) {
      out.push(cur)
      cur = ''
    } else cur += ch
  }
  if (cur.trim()) out.push(cur)
  return out.map(parseAddress).filter((x) => x.email.includes('@'))
}

export const TEXT_CAP = 20_000

/** HTML → readable text (no markup reaches the model or the screen). */
export function htmlToText(html: string): string {
  return html
    .replace(/<(script|style|head)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|tr|h[1-6])>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n\s*\n+/g, '\n\n')
    .trim()
}

export const capText = (s: string) => (s.length > TEXT_CAP ? `${s.slice(0, TEXT_CAP)}\n…[cut]` : s)

interface GmailPart {
  mimeType?: string
  filename?: string
  body?: { data?: string; attachmentId?: string }
  parts?: GmailPart[]
}

/** The plain text of a Gmail message payload (text/plain preferred, else HTML converted). */
export function gmailBodyText(payload: GmailPart | undefined, prefer: 'plain' | 'html' = 'plain'): string {
  if (!payload) return ''
  const plain: string[] = []
  const html: string[] = []
  const walk = (p: GmailPart) => {
    if (!p.filename && p.mimeType === 'text/plain' && p.body?.data) plain.push(b64urlDecode(p.body.data))
    else if (!p.filename && p.mimeType === 'text/html' && p.body?.data) html.push(b64urlDecode(p.body.data))
    p.parts?.forEach(walk)
  }
  walk(payload)
  // For a send preview the HTML part wins: it is what the recipient's mail app shows.
  const useHtml = html.length > 0 && (prefer === 'html' || !plain.length)
  return capText(useHtml ? htmlToText(html.join('\n')) : plain.join('\n'))
}

/**
 * Both bodies of a multipart/alternative message (null when that part is
 * missing). A send preview must cover both: a text-only reader sees the
 * plain part, everyone else the HTML (audit C-26).
 */
export function gmailBodyParts(payload: GmailPart | undefined): { plain: string | null; html: string | null } {
  const plain: string[] = []
  const html: string[] = []
  const walk = (p: GmailPart) => {
    if (!p.filename && p.mimeType === 'text/plain' && p.body?.data) plain.push(b64urlDecode(p.body.data))
    else if (!p.filename && p.mimeType === 'text/html' && p.body?.data) html.push(b64urlDecode(p.body.data))
    p.parts?.forEach(walk)
  }
  if (payload) walk(payload)
  return { plain: plain.length ? plain.join('\n') : null, html: html.length ? html.join('\n') : null }
}

/** The words a reader gets, ignoring layout, punctuation and link addresses (mail apps write links differently in each part). */
const wordsOf = (t: string) =>
  t
    .toLowerCase()
    .replace(/https?:\/\/\S+|mailto:\S+/g, ' ')
    .split(/[^\p{L}\p{N}]+/u)
    .filter(Boolean)
    .join(' ')

/** Do the plain and HTML parts say different things? (Same words in the same order = the same message.) */
export function alternativeConflict(plain: string, html: string): boolean {
  // Gmail writes inline images (a logo in the signature…) as "[image: alt]" in the plain part; the HTML-to-text drops <img>.
  // Those words are only allowed when an <img alt> in the HTML says the same (C-26b): otherwise a text-only
  // reader could be shown "[image: wire it to X]" that the approved HTML never had.
  const alts = new Set(imgAlts(html).map(wordsOf))
  const placeholders = [...plain.matchAll(/\[image:([^\]]*)\]/gi)].map((m) => wordsOf(m[1]))
  if (placeholders.some((p) => p !== '' && !alts.has(p))) return true
  return wordsOf(plain.replace(/\[image:[^\]]*\]/gi, ' ')) !== wordsOf(htmlToText(html))
}

/** The alt text of every <img> in the HTML (entities decoded, as a mail app shows them). */
function imgAlts(html: string): string[] {
  const out: string[] = []
  for (const tag of html.match(/<img\b[^>]*>/gi) ?? []) {
    const m = /\balt\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(tag)
    if (m) out.push(htmlToText(m[1] ?? m[2] ?? m[3] ?? ''))
  }
  return out
}

/** File names of the attachments in a Gmail message (any part with a filename). */
export function gmailAttachmentNames(payload: GmailPart | undefined): string[] {
  const out: string[] = []
  const walk = (p: GmailPart) => {
    if (p.filename) out.push(p.filename)
    p.parts?.forEach(walk)
  }
  if (payload) walk(payload)
  return out
}
