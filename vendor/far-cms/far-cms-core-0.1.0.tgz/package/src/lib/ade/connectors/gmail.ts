/**
 * Gmail over its REST API (gmail.googleapis.com/gmail/v1), as the connected
 * person. Used for the Inbox screen, for sending (the official Gmail MCP
 * server has no send), and for everything when the MCP server isn't enabled.
 */

import { buildPlainMessage, b64urlEncode, capText, gmailAttachmentNames, gmailBodyParts, gmailBodyText, parseAddress, parseAddressList } from './mime'
import { ConnectorError, type MailAdapter, type MailDraft, type MailDraftInput, type MailThread, type MailThreadSummary } from './types'

const BASE = 'https://gmail.googleapis.com/gmail/v1/users/me'

type Fetch = typeof fetch
type Header = { name?: string; value?: string }
const header = (hs: Header[] | undefined, name: string) => hs?.find((h) => h.name?.toLowerCase() === name.toLowerCase())?.value ?? ''

export function gmailAdapter(accessToken: () => Promise<string>, fetchImpl: Fetch = fetch): MailAdapter {
  const call = async <T>(path: string, init: RequestInit = {}): Promise<T> => {
    const res = await fetchImpl(`${BASE}${path}`, {
      ...init,
      headers: { Authorization: `Bearer ${await accessToken()}`, 'Content-Type': 'application/json', ...(init.headers ?? {}) },
    })
    if (res.status === 401) throw new ConnectorError('Gmail needs reconnecting', 'reconnect', 401)
    if (res.status === 404) throw new ConnectorError('Not found in Gmail', 'not-found', 404)
    if (res.status === 429) throw new ConnectorError('Gmail is busy — try again shortly', 'rate-limited', 429)
    if (!res.ok) throw new ConnectorError(`Gmail answered ${res.status}`, 'provider', res.status)
    return (await res.json()) as T
  }

  const draftOf = (d: { id?: string; message?: { threadId?: string; payload?: { headers?: Header[] } } }): MailDraft => {
    const hs = d.message?.payload?.headers
    return {
      id: String(d.id ?? ''),
      threadId: d.message?.threadId,
      to: parseAddressList(header(hs, 'To')).map((a) => a.email),
      cc: parseAddressList(header(hs, 'Cc')).map((a) => a.email),
      // A draft keeps its Bcc header until it is sent: read it so nothing is copied unseen.
      bcc: parseAddressList(header(hs, 'Bcc')).map((a) => a.email),
      subject: header(hs, 'Subject'),
    }
  }

  const rawFor = async (d: MailDraftInput) => {
    let inReplyTo: string | null = null
    let references: string | null = null
    if (d.replyTo) {
      const m = await call<{ payload?: { headers?: Header[] } }>(`/messages/${encodeURIComponent(d.replyTo.messageId)}?format=metadata&metadataHeaders=Message-ID&metadataHeaders=References`)
      inReplyTo = header(m.payload?.headers, 'Message-ID') || null
      references = header(m.payload?.headers, 'References') || null
    }
    return { raw: b64urlEncode(buildPlainMessage({ ...d, inReplyTo, references })), ...(d.replyTo ? { threadId: d.replyTo.threadId } : {}) }
  }

  return {
    via: 'api',
    async searchThreads({ query, cursor, limit = 20 }) {
      const qs = new URLSearchParams({ maxResults: String(Math.min(50, Math.max(1, limit))) })
      if (query?.trim()) qs.set('q', query.trim().slice(0, 500))
      if (cursor) qs.set('pageToken', cursor)
      const list = await call<{ threads?: { id: string; snippet?: string }[]; nextPageToken?: string }>(`/threads?${qs}`)
      const threads: MailThreadSummary[] = await Promise.all(
        (list.threads ?? []).map(async (t) => {
          const th = await call<{ messages?: { labelIds?: string[]; internalDate?: string; payload?: { headers?: Header[] } }[] }>(
            `/threads/${encodeURIComponent(t.id)}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`
          )
          const msgs = th.messages ?? []
          const first = msgs[0]
          const last = msgs[msgs.length - 1]
          return {
            id: t.id,
            subject: header(first?.payload?.headers, 'Subject'),
            from: parseAddress(header(last?.payload?.headers, 'From')),
            snippet: (t.snippet ?? '').slice(0, 300),
            date: last?.internalDate ? new Date(Number(last.internalDate)).toISOString() : '',
            unread: msgs.some((m) => m.labelIds?.includes('UNREAD')),
            messageCount: msgs.length,
          }
        })
      )
      return { threads, next: list.nextPageToken ?? null }
    },
    async getThread(id) {
      const th = await call<{ id: string; messages?: { id: string; internalDate?: string; payload?: { headers?: Header[] } & Parameters<typeof gmailBodyText>[0] }[] }>(
        `/threads/${encodeURIComponent(id)}?format=full`
      )
      const messages = (th.messages ?? []).slice(-30).map((m) => ({
        id: m.id,
        from: parseAddress(header(m.payload?.headers, 'From')),
        to: parseAddressList(header(m.payload?.headers, 'To')),
        cc: parseAddressList(header(m.payload?.headers, 'Cc')),
        date: m.internalDate ? new Date(Number(m.internalDate)).toISOString() : '',
        text: capText(gmailBodyText(m.payload)),
      }))
      const thread: MailThread = { id: th.id, subject: header(th.messages?.[0]?.payload?.headers, 'Subject'), messages }
      return thread
    },
    async listDrafts({ limit = 20 }) {
      const list = await call<{ drafts?: { id: string }[] }>(`/drafts?maxResults=${Math.min(50, Math.max(1, limit))}`)
      return Promise.all((list.drafts ?? []).map(async (d) => draftOf(await call(`/drafts/${encodeURIComponent(d.id)}?format=metadata`))))
    },
    async getDraft(id) {
      const raw = await call<{ id?: string; message?: { threadId?: string; payload?: { headers?: Header[] } & Parameters<typeof gmailBodyText>[0] } }>(`/drafts/${encodeURIComponent(id)}?format=full`)
      const d = draftOf(raw)
      const hs = raw.message?.payload?.headers
      const from = parseAddress(header(hs, 'From')).email || null
      return {
        ...d,
        replyToThreadId: d.threadId ?? null,
        text: gmailBodyText(raw.message?.payload, 'html'),
        from,
        attachments: gmailAttachmentNames(raw.message?.payload),
        inReplyTo: header(hs, 'In-Reply-To') || null,
        alternative: (() => {
          const parts = gmailBodyParts(raw.message?.payload)
          return parts.plain !== null && parts.html !== null ? { plain: parts.plain, html: parts.html } : null
        })(),
      }
    },
    async createDraft(d) {
      return draftOf(await call('/drafts', { method: 'POST', body: JSON.stringify({ message: await rawFor(d) }) }))
    },
    async updateDraft(id, d) {
      return draftOf(await call(`/drafts/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify({ id, message: await rawFor(d) }) }))
    },
    async sendDraft(id) {
      const r = await call<{ id?: string }>('/drafts/send', { method: 'POST', body: JSON.stringify({ id }) })
      return { id: String(r.id ?? id) }
    },
  }
}
