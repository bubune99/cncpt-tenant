/**
 * Outlook / Microsoft 365 mail over Microsoft Graph (v1.0), as the connected
 * person. Microsoft's own mail MCP servers (Agent 365 / Work IQ) need
 * Copilot + Agent 365 licensing and a per-tenant setup, so Graph REST is the
 * path that works for any mailbox; it sits behind the same MailAdapter.
 * A "thread" is a Graph conversationId.
 */

import { capText, htmlToText } from './mime'
import { ConnectorError, type MailAdapter, type MailAddress, type MailDraft, type MailDraftInput } from './types'

const ROOT = 'https://graph.microsoft.com/v1.0'
const BASE = `${ROOT}/me`
type Fetch = typeof fetch

interface GraphRecipient {
  emailAddress?: { name?: string; address?: string }
}
interface GraphMessage {
  id: string
  conversationId?: string
  subject?: string
  from?: GraphRecipient
  toRecipients?: GraphRecipient[]
  ccRecipients?: GraphRecipient[]
  receivedDateTime?: string
  bccRecipients?: GraphRecipient[]
  bodyPreview?: string
  isRead?: boolean
  isDraft?: boolean
  hasAttachments?: boolean
  body?: { contentType?: string; content?: string }
}

const addr = (r: GraphRecipient | undefined): MailAddress => ({ name: r?.emailAddress?.name ?? '', email: (r?.emailAddress?.address ?? '').toLowerCase() })
const recipients = (list: readonly string[] | undefined) => (list ?? []).map((address) => ({ emailAddress: { address } }))
const odataQuote = (s: string) => s.replace(/'/g, "''")

/** A nextLink cursor must point back at Graph (never let a stored cursor send the token elsewhere). */
export function safeGraphNext(link: unknown): string | null {
  if (typeof link !== 'string') return null
  try {
    const u = new URL(link)
    return u.protocol === 'https:' && u.hostname === 'graph.microsoft.com' && u.pathname.startsWith('/v1.0/me/') ? u.toString() : null
  } catch {
    return null
  }
}

export function graphAdapter(accessToken: () => Promise<string>, fetchImpl: Fetch = fetch): MailAdapter {
  const call = async <T>(url: string, init: RequestInit = {}): Promise<T> => {
    const res = await fetchImpl(url, {
      ...init,
      headers: { Authorization: `Bearer ${await accessToken()}`, 'Content-Type': 'application/json', Prefer: 'outlook.body-content-type="text"', ...(init.headers ?? {}) },
    })
    if (res.status === 401) throw new ConnectorError('Outlook needs reconnecting', 'reconnect', 401)
    if (res.status === 404) throw new ConnectorError('Not found in Outlook', 'not-found', 404)
    if (res.status === 429) throw new ConnectorError('Outlook is busy — try again shortly', 'rate-limited', 429)
    if (!res.ok) throw new ConnectorError(`Outlook answered ${res.status}`, 'provider', res.status)
    return (res.status === 202 || res.status === 204 ? {} : await res.json()) as T
  }
  const SELECT = 'id,conversationId,subject,from,toRecipients,ccRecipients,bccRecipients,receivedDateTime,bodyPreview,isRead'
  const draftOf = (m: GraphMessage): MailDraft => ({
    id: m.id,
    threadId: m.conversationId,
    to: (m.toRecipients ?? []).map((r) => addr(r).email),
    cc: (m.ccRecipients ?? []).map((r) => addr(r).email),
    bcc: (m.bccRecipients ?? []).map((r) => addr(r).email),
    subject: m.subject ?? '',
  })
  const patchBody = (d: MailDraftInput) => ({
    subject: d.subject,
    body: { contentType: 'Text', content: d.text },
    toRecipients: recipients(d.to),
    ccRecipients: recipients(d.cc),
    // Rewriting a draft clears any Bcc it had (we never set one).
    bccRecipients: [],
  })

  return {
    via: 'api',
    async searchThreads({ query, cursor, limit = 25 }) {
      const top = Math.min(50, Math.max(1, limit))
      const url =
        safeGraphNext(cursor) ??
        (query?.trim()
          ? `${BASE}/messages?$search=${encodeURIComponent(`"${query.trim().slice(0, 200).replace(/"/g, '')}"`)}&$top=${top}&$select=${SELECT}`
          : `${BASE}/mailFolders/inbox/messages?$top=${top}&$orderby=receivedDateTime desc&$select=${SELECT}`)
      const page = await call<{ value?: GraphMessage[]; '@odata.nextLink'?: string }>(url)
      // Messages → one row per conversation (newest message first).
      const byConv = new Map<string, GraphMessage[]>()
      for (const m of page.value ?? []) {
        const k = m.conversationId ?? m.id
        byConv.set(k, [...(byConv.get(k) ?? []), m])
      }
      const threads = [...byConv.entries()].map(([id, ms]) => {
        const sorted = ms.sort((a, b) => (b.receivedDateTime ?? '').localeCompare(a.receivedDateTime ?? ''))
        const last = sorted[0]
        return { id, subject: last.subject ?? '', from: addr(last.from), snippet: (last.bodyPreview ?? '').slice(0, 300), date: last.receivedDateTime ?? '', unread: ms.some((m) => m.isRead === false), messageCount: ms.length }
      })
      return { threads, next: safeGraphNext(page['@odata.nextLink']) }
    },
    async getThread(id) {
      const page = await call<{ value?: GraphMessage[] }>(
        `${BASE}/messages?$filter=${encodeURIComponent(`conversationId eq '${odataQuote(id)}'`)}&$top=50&$select=${SELECT},body`
      )
      const ms = (page.value ?? []).sort((a, b) => (a.receivedDateTime ?? '').localeCompare(b.receivedDateTime ?? '')).slice(-30)
      if (!ms.length) throw new ConnectorError('Not found in Outlook', 'not-found', 404)
      return {
        id,
        subject: ms[0].subject ?? '',
        messages: ms.map((m) => ({
          id: m.id,
          from: addr(m.from),
          to: (m.toRecipients ?? []).map(addr),
          cc: (m.ccRecipients ?? []).map(addr),
          date: m.receivedDateTime ?? '',
          text: capText(m.body?.contentType === 'html' ? htmlToText(m.body.content ?? '') : m.body?.content ?? ''),
        })),
      }
    },
    async listDrafts({ limit = 20 }) {
      const page = await call<{ value?: GraphMessage[] }>(`${BASE}/mailFolders/drafts/messages?$top=${Math.min(50, Math.max(1, limit))}&$select=${SELECT}`)
      return (page.value ?? []).map(draftOf)
    },
    async getDraft(id) {
      const m = await call<GraphMessage>(`${BASE}/messages/${encodeURIComponent(id)}?$select=${SELECT},body,isDraft,hasAttachments`)
      // /messages/{id} reads ANY message: only a draft can be previewed or sent (a received email never comes back as one).
      if (m.isDraft !== true) throw new ConnectorError('Not found in Outlook', 'not-found', 404)
      const text = capText(m.body?.contentType === 'html' ? htmlToText(m.body.content ?? '') : m.body?.content ?? '')
      const files = m.hasAttachments
        ? ((await call<{ value?: { name?: string }[] }>(`${BASE}/messages/${encodeURIComponent(id)}/attachments?$select=name`)).value ?? []).map((a) => a.name || 'attachment')
        : []
      return { ...draftOf(m), replyToThreadId: m.conversationId ?? null, text, from: addr(m.from).email || null, attachments: files, inReplyTo: null }
    },
    async createDraft(d) {
      if (d.replyTo) {
        // createReply threads it (In-Reply-To, the conversation); then our own text and recipients replace its defaults.
        const reply = await call<GraphMessage>(`${BASE}/messages/${encodeURIComponent(d.replyTo.messageId)}/createReply`, { method: 'POST', body: '{}' })
        return draftOf(await call<GraphMessage>(`${BASE}/messages/${encodeURIComponent(reply.id)}`, { method: 'PATCH', body: JSON.stringify(patchBody(d)) }))
      }
      return draftOf(await call<GraphMessage>(`${BASE}/messages`, { method: 'POST', body: JSON.stringify(patchBody(d)) }))
    },
    async updateDraft(id, d) {
      return draftOf(await call<GraphMessage>(`${BASE}/messages/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(patchBody(d)) }))
    },
    async sendDraft(id) {
      await call(`${BASE}/messages/${encodeURIComponent(id)}/send`, { method: 'POST', body: '{}' })
      return { id }
    },
  }
}
