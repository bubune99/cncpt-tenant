/**
 * OAuth 2.0 authorization code + PKCE (S256) for personal connectors —
 * pure apart from node:crypto; asserted by connectors.assert.ts.
 *
 * - state is signed (HMAC-SHA256) and short-lived, and carries WHO started
 *   the flow: a callback for anyone else (or another provider) is refused, so
 *   a link someone else started can't attach their mailbox to your account.
 * - the PKCE verifier never leaves the server unencrypted (the host keeps it
 *   in an encrypted, httpOnly cookie scoped to the callback path).
 */

import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { PROVIDERS } from './providers'
import type { ConnectorProvider, ConnectorTokens } from './types'

type Env = Record<string, string | undefined>

export const STATE_TTL_MS = 10 * 60_000

/**
 * What ?connector_error= can carry back to the screen: codes only, never
 * free text (a crafted link must not put its own words in a trusted toast).
 * The screen maps each to its own sentence; anything else shows a fixed one.
 */
export const CONNECTOR_ERROR_CODES = ['unknown_provider', 'not_configured', 'state_expired', 'not_yours', 'denied', 'provider_error', 'no_code', 'sign_in_expired', 'exchange_failed', 'cross_site'] as const
export type ConnectorErrorCode = (typeof CONNECTOR_ERROR_CODES)[number]
export const isConnectorErrorCode = (v: unknown): v is ConnectorErrorCode => typeof v === 'string' && (CONNECTOR_ERROR_CODES as readonly string[]).includes(v)
/** Refresh this long before the access token runs out. */
export const REFRESH_SKEW_MS = 60_000

const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
const fromB64url = (s: string) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64')

/** RFC 7636: a 43-char verifier and its S256 challenge. */
export function pkcePair(random: (n: number) => Buffer = randomBytes): { verifier: string; challenge: string } {
  const verifier = b64url(random(32))
  return { verifier, challenge: b64url(createHash('sha256').update(verifier).digest()) }
}

export interface StatePayload {
  /** The signed-in person who started it. */
  u: string
  p: ConnectorProvider
  /** Where to come back to (same-site path). */
  r: string
  /** Expiry (ms since epoch). */
  x: number
  /** Nonce. */
  n: string
}

/** A same-site path to come back to; anything else becomes the default. */
export function safeReturnPath(p: unknown, fallback: string): string {
  if (typeof p !== 'string' || p.length > 512) return fallback
  if (!p.startsWith('/') || p.startsWith('//') || p.startsWith('/\\') || /^\/(%5c|%2f)/i.test(p)) return fallback
  return p
}

export function signState(input: { userId: string; provider: ConnectorProvider; returnTo: string; now: number; nonce?: string }, secret: string): string {
  const payload: StatePayload = { u: input.userId, p: input.provider, r: input.returnTo, x: input.now + STATE_TTL_MS, n: input.nonce ?? b64url(randomBytes(12)) }
  const body = b64url(Buffer.from(JSON.stringify(payload)))
  const sig = b64url(createHmac('sha256', secret).update(body).digest())
  return `${body}.${sig}`
}

export type StateCheck = { ok: true; returnTo: string } | { ok: false; reason: 'malformed' | 'bad-signature' | 'expired' | 'wrong-user' | 'wrong-provider' }

export function verifyState(token: unknown, secret: string, expect: { userId: string; provider: ConnectorProvider; now: number }): StateCheck {
  if (typeof token !== 'string' || token.length > 2048) return { ok: false, reason: 'malformed' }
  const [body, sig, extra] = token.split('.')
  if (!body || !sig || extra !== undefined) return { ok: false, reason: 'malformed' }
  const want = createHmac('sha256', secret).update(body).digest()
  const got = fromB64url(sig)
  if (got.length !== want.length || !timingSafeEqual(got, want)) return { ok: false, reason: 'bad-signature' }
  let p: StatePayload
  try {
    p = JSON.parse(fromB64url(body).toString('utf8'))
  } catch {
    return { ok: false, reason: 'malformed' }
  }
  if (typeof p?.x !== 'number' || p.x < expect.now) return { ok: false, reason: 'expired' }
  if (p.p !== expect.provider) return { ok: false, reason: 'wrong-provider' }
  if (p.u !== expect.userId) return { ok: false, reason: 'wrong-user' }
  return { ok: true, returnTo: typeof p.r === 'string' ? p.r : '/admin' }
}

/** The /authorize URL (code flow, PKCE S256, minimal scopes). */
export function authorizationUrl(
  provider: ConnectorProvider,
  env: Env,
  q: { clientId: string; redirectUri: string; state: string; challenge: string }
): string {
  const def = PROVIDERS[provider]
  const u = new URL(def.authUrl(env))
  u.searchParams.set('client_id', q.clientId)
  u.searchParams.set('redirect_uri', q.redirectUri)
  u.searchParams.set('response_type', 'code')
  u.searchParams.set('scope', def.scopes.join(' '))
  u.searchParams.set('state', q.state)
  u.searchParams.set('code_challenge', q.challenge)
  u.searchParams.set('code_challenge_method', 'S256')
  for (const [k, v] of Object.entries(def.authParams)) u.searchParams.set(k, v)
  return u.toString()
}

/** Form body for the token endpoint: the code exchange, or a refresh. */
export function tokenRequestBody(
  provider: ConnectorProvider,
  q: { clientId: string; clientSecret: string } & ({ grant: 'code'; code: string; verifier: string; redirectUri: string } | { grant: 'refresh'; refreshToken: string })
): URLSearchParams {
  const b = new URLSearchParams({ client_id: q.clientId, client_secret: q.clientSecret })
  if (q.grant === 'code') {
    b.set('grant_type', 'authorization_code')
    b.set('code', q.code)
    b.set('code_verifier', q.verifier)
    b.set('redirect_uri', q.redirectUri)
  } else {
    b.set('grant_type', 'refresh_token')
    b.set('refresh_token', q.refreshToken)
    // Microsoft wants the scopes again on refresh; Google ignores them.
    if (provider === 'microsoft') b.set('scope', PROVIDERS.microsoft.scopes.join(' '))
  }
  return b
}

/**
 * A token endpoint reply → tokens. A refresh reply may omit refresh_token
 * (Google) — the old one stays. invalid_grant = the person revoked access or
 * the grant expired: reconnect.
 */
export function parseTokenResponse(
  json: unknown,
  now: number,
  previous?: Pick<ConnectorTokens, 'refreshToken' | 'grantedScopes'>
): { ok: true; tokens: ConnectorTokens } | { ok: false; reconnect: boolean; error: string } {
  const j = (json ?? {}) as Record<string, unknown>
  if (typeof j.error === 'string') {
    return { ok: false, reconnect: j.error === 'invalid_grant' || j.error === 'interaction_required', error: j.error }
  }
  if (typeof j.access_token !== 'string' || !j.access_token) return { ok: false, reconnect: false, error: 'no_access_token' }
  const expiresIn = typeof j.expires_in === 'number' ? j.expires_in : Number(j.expires_in)
  const scope = typeof j.scope === 'string' ? j.scope.split(/\s+/).filter(Boolean) : previous?.grantedScopes ?? []
  return {
    ok: true,
    tokens: {
      accessToken: j.access_token,
      refreshToken: typeof j.refresh_token === 'string' && j.refresh_token ? j.refresh_token : previous?.refreshToken ?? null,
      expiresAt: Number.isFinite(expiresIn) && expiresIn > 0 ? new Date(now + expiresIn * 1000) : null,
      grantedScopes: scope,
    },
  }
}

/** Refresh before use? (no expiry known → use it; a 401 then triggers one refresh). */
export function needsRefresh(expiresAt: Date | null, now: number, skewMs = REFRESH_SKEW_MS): boolean {
  return expiresAt !== null && expiresAt.getTime() - skewMs <= now
}

/** The email address in an OpenID id_token (not verified here: it is only a label for the person's own screen). */
export function idTokenEmail(idToken: unknown): string | null {
  if (typeof idToken !== 'string') return null
  const part = idToken.split('.')[1]
  if (!part) return null
  try {
    const c = JSON.parse(fromB64url(part).toString('utf8')) as { email?: unknown; preferred_username?: unknown }
    const e = typeof c.email === 'string' ? c.email : typeof c.preferred_username === 'string' ? c.preferred_username : null
    return e && e.includes('@') && e.length <= 320 ? e : null
  } catch {
    return null
  }
}

/**
 * Is a state-changing request from our own pages? Sec-Fetch-Site must be
 * same-origin when the browser sends it; otherwise Origin must be ours.
 * Neither header → refused (fail closed): connect, disconnect, drafts and
 * sends only ever come from the admin's own screens.
 */
export function isSameSiteRequest(h: { secFetchSite: string | null; origin: string | null }, expectedOrigin: string): boolean {
  if (h.secFetchSite) return h.secFetchSite === 'same-origin'
  if (h.origin) return h.origin === expectedOrigin
  return false
}

/**
 * Mailbox tokens, the PKCE cookie and OAuth state need a real ENCRYPTION_KEY
 * everywhere except local development and tests — staging and previews
 * included (a missing key otherwise falls back to a key that is public).
 */
export function connectorSecretsReadyIn(env: Record<string, string | undefined>): boolean {
  return Boolean(env.ENCRYPTION_KEY?.trim()) || env.NODE_ENV === 'test' || env.NODE_ENV === 'development'
}
