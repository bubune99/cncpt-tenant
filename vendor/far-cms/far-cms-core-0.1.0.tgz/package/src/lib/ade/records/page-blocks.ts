/**
 * Blocks on a record's page (brief 2026-10-18 §1d): a draft record has no page
 * row yet (pageId is null until the page is made from the template), so the
 * sections added from the block library live in the RECORD's data — a field of
 * type 'blocks' — as unsaved edits until Propose. Reject leaves the record as it
 * was, so they go with it. When the page is made (or already exists), they sit
 * in one marked section after the template's own blocks.
 *
 * Pure and app-agnostic; asserted by page-blocks.assert.ts.
 */

import type { Block } from '../../block-editor/types'
import type { FieldDef, RecordData, RecordTypeDef } from './types'
import { LIBRARY_COPY, type BlockMode, type Shelf } from '../blocks/library'

export const PAGE_BLOCKS_KEY = 'pageBlocks'
export const PAGE_BLOCKS_MAX = 12
/** Most JSON bytes the added sections may take in the record's data. */
export const PAGE_BLOCKS_MAX_BYTES = 64 * 1024
/** The marked section on the page that holds them (found again on later edits). */
export const ADDED_SECTION_ATTR = 'data-record-added'

const FIELD: FieldDef = { key: PAGE_BLOCKS_KEY, label: 'Added sections', type: 'blocks', max: PAGE_BLOCKS_MAX, draftable: false }

/** Every record type with a page gets the field (once). Types without a page template are unchanged. */
export function withPageBlocksField(def: RecordTypeDef): RecordTypeDef {
  if (!def.pageTemplate.length || def.fields.some((f) => f.type === 'blocks')) return def
  return { ...def, fields: [...def.fields, FIELD] }
}

/** The record's added blocks (the first blocks field). */
export function pageBlocksOf(def: Pick<RecordTypeDef, 'fields'>, data: RecordData): Block[] {
  const f = def.fields.find((x) => x.type === 'blocks')
  const v = f ? data[f.key] : undefined
  return Array.isArray(v) ? (v as Block[]) : []
}

/** The key of the record's blocks field, or null. */
export const pageBlocksKey = (def: Pick<RecordTypeDef, 'fields'>) => def.fields.find((x) => x.type === 'blocks')?.key ?? null

function addedSection(blocks: Block[]): Block {
  return { id: 'record-added-sections', tag: 'div', className: '', label: 'Added sections', attrs: { [ADDED_SECTION_ATTR]: '1' }, children: blocks } as Block
}

/** A new page's blocks: the template's, then the added ones in their marked section (none → nothing extra). */
export function appendPageBlocks(templateBlocks: readonly Block[], added: readonly Block[]): Block[] {
  return added.length ? [...templateBlocks, addedSection([...added])] : [...templateBlocks]
}

/** An existing page's content with its added section replaced (added, updated, or removed when empty). Never mutates. */
export function replacePageBlocks(content: unknown, added: readonly Block[]): { blocks: Block[] } & Record<string, unknown> {
  const doc = (content && typeof content === 'object' ? content : {}) as { blocks?: Block[] } & Record<string, unknown>
  const blocks = (Array.isArray(doc.blocks) ? doc.blocks : []).filter((b) => !(b.attrs && ADDED_SECTION_ATTR in b.attrs))
  return { ...doc, blocks: added.length ? [...blocks, addedSection([...added])] : blocks }
}

/** Add one block to the record's list (an unsaved edit), at the end or after another added block. */
export function withAddedBlock(current: readonly Block[], block: Block, after?: string): Block[] {
  const at = after ? current.findIndex((b) => b.id === after) + 1 : current.length
  const i = at <= 0 ? current.length : at
  return [...current.slice(0, i), block, ...current.slice(i)].slice(0, PAGE_BLOCKS_MAX)
}

/** The chat line after an add on a record page: names the shelf and linked/copy (the library's own wording), and that it's unsaved. */
export function recordAddLine(name: string, shelf: Shelf, mode: BlockMode): string {
  const what = LIBRARY_COPY.addSummary(name, shelf, mode, 'this page').replace(/^Add /, 'Added ').replace(/ to “this page”$/, ' to this page')
  return `${what} — not saved until you propose it.`
}

const DROP_TAGS = new Set(['script', 'style', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'form'])
const UNSAFE_URL = /^\s*(javascript|vbscript|data):/i

/**
 * Write-time cleaning for added sections, on top of the page sanitizer (text HTML) —
 * this markup comes from a person or the model: no event-handler attributes, no
 * script-like tags, no javascript:/data: addresses. Never mutates.
 */
export function cleanAddedBlocks(blocks: readonly Block[]): Block[] {
  return blocks
    .filter((b) => !DROP_TAGS.has(String(b.tag).toLowerCase()))
    .map((b) => {
      const attrs = b.attrs ? Object.fromEntries(Object.entries(b.attrs).filter(([k, v]) => !/^on/i.test(k) && !(typeof v === 'string' && UNSAFE_URL.test(v)))) : undefined
      return { ...b, ...(attrs ? { attrs } : {}), ...(Array.isArray(b.children) ? { children: cleanAddedBlocks(b.children) } : {}) } as Block
    })
}

/** Too big to keep in the record (bytes of JSON)? */
export const pageBlocksTooBig = (blocks: readonly Block[]) => new TextEncoder().encode(JSON.stringify(blocks)).length > PAGE_BLOCKS_MAX_BYTES
