/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/type-config.assert.ts
 * A second, made-up record type ("drop", with its OWN field names) works
 * through all four per-type parts of the engine as data: the checklist,
 * the template's smart blocks (canvas parts + home card), the nav phrases,
 * and placement rules — and the initiative's values equal the old behaviour.
 */
import assert from 'node:assert/strict'
import { evaluateChecklist, REVIEWED_ITEM } from './checklist'
import { applyRules, DEFAULT_PLACEMENT_FIELDS, defaultRules, groupOptions, matchesRules, placementFields } from './rules'
import { canvasPartFor, homeCardOf, listComponentIndex, listIncludes, navPhrasesFor, partField } from './type-config'
import type { RecordTypeDef } from './types'
import { DROP } from './type-config.fixture'
import { initiativeType } from '../../ade-bindings/record-types/initiative'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }


check('1 checklist: the type brings its own; evaluated from its data', () => {
  const r = evaluateChecklist(DROP.checklist!, { data: { bannerUrl: '/m/b.jpg' } }, { [REVIEWED_ITEM]: true })
  assert.deepEqual(r.items.map((i) => [i.id, i.done]), [['banner', true], ['release', false], ['reviewed', true]])
  assert.equal(r.requiredLeft, 1)
  assert.ok(initiativeType.checklist && initiativeType.checklist.some((i) => i.id === 'photo'), 'the initiative carries its checklist in its definition')
})

check('2 template blocks: canvas parts and the home card come from the type; another type\'s blocks are not its parts', () => {
  const part = canvasPartFor(DROP, 'DropHeader')!
  assert.deepEqual([part.part, partField(part, 'title'), partField(part, 'image'), partField(part, 'badge'), partField(part, 'summary')], ['header', 'title', 'bannerUrl', 'phase', 'summary'])
  assert.equal(canvasPartFor(DROP, 'InitiativeHeader'), null)
  assert.deepEqual(homeCardOf(DROP), { componentName: 'DropCard', areaComponents: ['DropCard'] })
  assert.equal(homeCardOf({}), null, 'no home card unless the type has one')
  const ih = canvasPartFor(initiativeType, 'InitiativeHeader')!
  assert.deepEqual([partField(ih, 'title'), partField(ih, 'image'), partField(ih, 'badge'), partField(ih, 'place')], ['name', 'heroImageUrl', 'stage', 'location'], 'the initiative maps to its old fields')
  assert.deepEqual(homeCardOf(initiativeType), { componentName: 'InitiativeCard', areaComponents: ['InitiativeBlock', 'InitiativeCard'] })
})

check('3 nav phrases: from the label, plural and key — the initiative\'s are the old words', () => {
  const say = (def: Pick<RecordTypeDef, 'key' | 'label' | 'plural'>, path: string) => navPhrasesFor(def).find(([re]) => re.test(path))?.[1] ?? null
  assert.deepEqual([say(DROP, '/admin/records/drop'), say(DROP, '/admin/records/drop/new'), say(DROP, '/admin/records/drop/abc')], ['your drops', 'a new drop', 'the drop'])
  assert.deepEqual([say(initiativeType, '/admin/records/initiative'), say(initiativeType, '/admin/records/initiative/new'), say(initiativeType, '/admin/records/initiative/x1')], ['your initiatives', 'a new initiative', 'the initiative'])
  assert.equal(say(DROP, '/admin/records/initiative'), null)
})

check('4 placement: rules filter and sort on the type\'s own fields; list blocks by type; the initiative uses the old names', () => {
  const f = placementFields(DROP)
  assert.deepEqual(groupOptions(DROP), ['teaser', 'live', 'sold-out'])
  const recs = [
    { id: 'a', status: 'PUBLISHED', data: { title: 'A', phase: 'live', pinned: true, pinOrder: 2, bannerUrl: '/a.jpg', releaseDate: '2026-10-01' } },
    { id: 'b', status: 'PUBLISHED', data: { title: 'B', phase: 'live', pinned: true, pinOrder: 1, bannerUrl: '/b.jpg', releaseDate: '2026-11-01' } },
    { id: 'c', status: 'PUBLISHED', data: { title: 'C', phase: 'teaser', pinned: true, pinOrder: 0 } },
    { id: 'd', status: 'DRAFT', data: { title: 'D', phase: 'live', pinned: true } },
  ]
  const rules = { ...defaultRules('drop'), stages: ['live'], hasPhoto: true }
  assert.deepEqual(applyRules(recs, rules, f).map((r) => r.id), ['b', 'a'], 'live, pinned, with a banner — by pin order')
  const mixed = { id: 'm', status: 'PUBLISHED', data: { stage: 'live', phase: 'teaser', featured: true, pinned: true } }
  assert.equal(matchesRules(mixed, { ...defaultRules('drop'), stages: ['live'] }, f), false, 'the drop is filtered by its phase')
  assert.equal(matchesRules(mixed, { ...defaultRules('drop'), stages: ['live'] }), true, 'the default names would read the wrong field (stage) — this is why the type says')
  const idx = listComponentIndex([initiativeType, DROP])
  assert.deepEqual(Object.keys(idx).sort(), ['DropHighlights', 'InitiativeHighlights'])
  assert.equal(idx.DropHighlights.type, 'drop')
  assert.equal(listIncludes(DROP, idx.DropHighlights, {}, { status: 'PUBLISHED', data: { pinned: false } }), true, 'not featured by default: every live one')
  assert.equal(listIncludes(initiativeType, idx.InitiativeHighlights, {}, { status: 'PUBLISHED', data: { featured: false } }), false, 'the initiative block shows featured ones (old behaviour)')
  assert.equal(listIncludes(initiativeType, idx.InitiativeHighlights, { 'data-source': 'all' }, { status: 'PUBLISHED', data: { featured: false } }), true)
  assert.equal(listIncludes(DROP, idx.DropHighlights, { 'data-rules': JSON.stringify({ ...defaultRules('drop'), stages: ['sold-out'], featuredOnly: false }) }, { status: 'PUBLISHED', data: { phase: 'live' } }), false, 'rules on the drop\'s phase')
  assert.deepEqual(placementFields(initiativeType), DEFAULT_PLACEMENT_FIELDS, 'the initiative = the old field names')
})

console.log(`\n${n} checks passed`)
