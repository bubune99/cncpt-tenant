/**
 * Text that FOLLOWS a record. A record's own page is made from its template
 * once; story paragraphs were filled from the facts as plain text (not
 * bound). So that the record stays the one source of truth, an edit to a
 * fact also proposes the same edit to every unbound text block on the page
 * that still says exactly what the record says — and leaves alone any block
 * someone has since rewritten on the page (it "differs"). Pure; asserted.
 */

import { BIND_ATTR, type RecordData, type TemplateBlock } from './types'

interface AnyBlock {
  id?: string
  textContent?: string
  componentName?: string
  attrs?: Record<string, string>
  children?: AnyBlock[]
}

export interface FollowingBlock {
  blockId: string
  field: string
  /** The new text for the block. */
  text: string
}

export type FollowState = 'follows' | 'differs' | 'absent'

const norm = (s: unknown) => (typeof s === 'string' ? s.replace(/\s+/g, ' ').trim() : '')

function textBlocks(content: unknown): Array<{ id: string; text: string }> {
  const out: Array<{ id: string; text: string }> = []
  const walk = (bs: AnyBlock[] | undefined) => {
    for (const b of bs ?? []) {
      const bound = Boolean(b.componentName) || Boolean(b.attrs?.[BIND_ATTR])
      if (!bound && b.id && typeof b.textContent === 'string' && norm(b.textContent)) out.push({ id: b.id, text: norm(b.textContent) })
      walk(b.children)
    }
  }
  walk((content as { blocks?: AnyBlock[] } | null)?.blocks)
  return out
}

/** Unbound text blocks to update along with `patch` (only those still equal to the live value). */
export function followingBlocks(content: unknown, live: RecordData, patch: RecordData, fields: readonly string[]): FollowingBlock[] {
  const blocks = textBlocks(content)
  const out: FollowingBlock[] = []
  for (const field of fields) {
    if (!Object.hasOwn(patch, field)) continue
    const was = norm(live[field])
    const next = patch[field]
    if (!was || typeof next !== 'string' || !norm(next) || norm(next) === was) continue
    for (const b of blocks) if (b.text === was) out.push({ blockId: b.id, field, text: next })
  }
  return out
}

/**
 * Per story field: does the page still say what the record says ('follows'),
 * has it been rewritten on the page ('differs'), or is the field empty ('absent')?
 * A field "differs" when no unbound block carries the record's text.
 */
export function followStates(content: unknown, live: RecordData, fields: readonly string[]): Record<string, FollowState> {
  const texts = new Set(textBlocks(content).map((b) => b.text))
  const out: Record<string, FollowState> = {}
  for (const f of fields) {
    const v = norm(live[f])
    out[f] = !v ? 'absent' : texts.has(v) ? 'follows' : 'differs'
  }
  return out
}

export interface StoryInsert {
  field: string
  /** Insert into this block, right after the heading it belongs under. */
  parentBlockId: string
  index: number
  tag: string
  className: string
  text: string
}

/**
 * A story field that was EMPTY when the page was made has no paragraph on
 * the page (empty template text is dropped). Filling it later must add the
 * paragraph — right after the template's heading for it (e.g. "Progress so
 * far"), found on the page by its text. Nothing when the heading is gone.
 */
export function storyInserts(content: unknown, template: ReadonlyArray<TemplateBlock>, live: RecordData, patch: RecordData, fields: readonly string[]): StoryInsert[] {
  const out: StoryInsert[] = []
  const wanted = fields.filter((f) => Object.hasOwn(patch, f) && !norm(live[f]) && typeof patch[f] === 'string' && norm(patch[f]))
  if (!wanted.length) return out
  // In the template: "{{field}}" text → the heading text right before it.
  const headingFor = new Map<string, { heading: string; tag: string; className: string }>()
  const walkT = (bs: ReadonlyArray<TemplateBlock> | undefined) => {
    ;(bs ?? []).forEach((b, i) => {
      const m = b.textContent?.match(/^\{\{(\w+)\}\}$/)
      const prev = i > 0 ? bs![i - 1] : undefined
      if (m && prev?.textContent && !prev.textContent.includes('{{')) headingFor.set(m[1], { heading: norm(prev.textContent), tag: b.tag, className: b.className ?? '' })
      walkT(b.children)
    })
  }
  walkT(template)
  // On the page: the parent + position of each heading.
  const at = new Map<string, { parentId: string; index: number; next: string }>()
  const walkP = (bs: AnyBlock[] | undefined, parentId: string | null) => {
    ;(bs ?? []).forEach((b, i) => {
      const t = norm(b.textContent)
      if (parentId && t && !b.componentName && !at.has(t)) at.set(t, { parentId, index: i, next: norm(bs![i + 1]?.textContent) })
      walkP(b.children, b.id ?? null)
    })
  }
  walkP((content as { blocks?: AnyBlock[] } | null)?.blocks, null)
  for (const field of wanted) {
    const h = headingFor.get(field)
    const place = h && at.get(h.heading)
    const text = String(patch[field])
    if (!h || !place || place.next === norm(text)) continue
    out.push({ field, parentBlockId: place.parentId, index: place.index + 1, tag: h.tag, className: h.className, text })
  }
  return out
}
