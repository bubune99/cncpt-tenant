/**
 * A made-up second record type for asserts only ("drop", with its own field
 * names): proves a new type works as data (type-config.assert.ts,
 * ade-bindings/record-type-data.assert.ts). Never imported by app code.
 */

import { REVIEWED_ITEM } from './checklist'
import type { RecordTypeDef } from './types'

export const DROP: RecordTypeDef = {
  key: 'drop', label: 'Drop', plural: 'Drops', titleField: 'title', slugField: 'slug', pathPrefix: '/drops', category: 'drops',
  fields: [
    { key: 'title', label: 'Title', type: 'text', required: true },
    { key: 'slug', label: 'Web address', type: 'slug' },
    { key: 'phase', label: 'Phase', type: 'enum', default: 'teaser', options: [{ value: 'teaser', label: 'Teaser' }, { value: 'live', label: 'Live' }, { value: 'sold-out', label: 'Sold out' }] },
    { key: 'bannerUrl', label: 'Banner', type: 'image' },
    { key: 'releaseDate', label: 'Release date', type: 'date' },
    { key: 'pinned', label: 'Pin on the home page', type: 'boolean', default: false },
    { key: 'pinOrder', label: 'Pin order', type: 'number' },
  ],
  pageTemplate: [{ tag: 'section', label: 'Drop header', componentName: 'DropHeader', attrs: { 'data-record': '$record' } }],
  checklist: [
    { id: 'banner', label: 'Banner photo', required: true, kind: 'auto', check: ({ data }) => (typeof data.bannerUrl === 'string' && data.bannerUrl !== '') || 'Choose a banner' },
    { id: 'release', label: 'Release date', required: true, kind: 'auto', check: ({ data }) => typeof data.releaseDate === 'string' || 'Set the release date' },
    { id: REVIEWED_ITEM, label: 'Page reviewed in preview', required: true, kind: 'manual' },
  ],
  phoneWarnings: ['release'],
  canvasParts: { DropHeader: { part: 'header', fields: { title: 'title', image: 'bannerUrl', badge: 'phase', start: 'releaseDate' } } },
  listComponents: [{ componentName: 'DropHighlights', modes: ['grid'], featuredByDefault: false }],
  homeCard: { componentName: 'DropCard', areaComponents: ['DropCard'] },
  placement: { group: 'phase', featured: 'pinned', featuredOrder: 'pinOrder', photo: 'bannerUrl', start: 'releaseDate', end: 'releaseDate' },
}
