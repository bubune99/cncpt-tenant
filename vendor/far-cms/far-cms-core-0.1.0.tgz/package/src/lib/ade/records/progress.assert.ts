/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/progress.assert.ts
 */
import assert from 'node:assert/strict'
import { addProgressUpdate, addToGallery } from './progress'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the newest update goes on top, as its own paragraph', () => {
  assert.equal(addProgressUpdate('First load delivered.', 'Second delivery arrived at Atua.'), 'Second delivery arrived at Atua.\n\nFirst load delivered.')
  assert.equal(addProgressUpdate('', ' Started. '), 'Started.')
  assert.equal(addProgressUpdate(null, ''), '')
})

check('sending the same update twice doesn’t repeat it', () => {
  const once = addProgressUpdate('Old.', 'New.')
  assert.equal(addProgressUpdate(once, 'New.'), once)
})

check('within the field’s length: the oldest words go first, at a sentence or paragraph', () => {
  const old = Array.from({ length: 40 }, (_, i) => `Update ${i} happened.`).join(' ')
  const out = addProgressUpdate(old, 'Latest news.', 120)
  assert.ok(out.length <= 120)
  assert.ok(out.startsWith('Latest news.'))
  assert.ok(out.endsWith('.'))
})

check('new photos join the gallery once, up to its size', () => {
  assert.deepEqual(addToGallery(['a', 'b'], ['b', 'c']), ['a', 'b', 'c'])
  assert.equal(addToGallery(Array.from({ length: 12 }, (_, i) => `p${i}`), ['new']).length, 12)
  assert.deepEqual(addToGallery(undefined, ['x']), ['x'])
})

console.log(`\n${n} checks passed`)
