/**
 * Placement RULES — which records a list section shows (e.g. the home
 * page's initiative cards), declared as data instead of hand-picked copies:
 * which records (type, stages, live only, featured only, has a photo), in
 * what order, how many, what each card shows, and what happens when none
 * match. Stored on the list block (attr `data-rules`, JSON) so a change is a
 * normal page edit — a person or the assistant drafts it as a change set.
 * Pure and app-agnostic; asserted by rules.assert.ts.
 */

import type { PlacementFields, RecordTypeDef } from './types'

export const RULES_ATTR = 'data-rules'

/** The field names rules read when a type doesn't say otherwise (the first type, the initiative, uses these). */
export const DEFAULT_PLACEMENT_FIELDS: PlacementFields = {
  group: 'stage',
  featured: 'featured',
  featuredOrder: 'featuredOrder',
  photo: 'heroImageUrl',
  start: 'startDate',
  end: 'endDate',
}

/** The fields placement rules read for a type: its own names over the defaults. */
export function placementFields(def: Pick<RecordTypeDef, 'placement'> | null | undefined): PlacementFields {
  return { ...DEFAULT_PLACEMENT_FIELDS, ...(def?.placement ?? {}) }
}

/** The values rules may filter by: the type's group field's options (e.g. its stages). */
export function groupOptions(def: Pick<RecordTypeDef, 'fields' | 'placement'> | null | undefined): string[] | undefined {
  if (!def) return undefined
  return def.fields.find((f) => f.key === placementFields(def).group)?.options?.map((o) => o.value)
}

export const RULE_ORDERS = ['home-order', 'newest', 'end-date'] as const
export type RuleOrder = (typeof RULE_ORDERS)[number]

export const CARD_PARTS = ['photo', 'stage', 'location', 'summary', 'progress'] as const
export type CardPart = (typeof CARD_PARTS)[number]

export interface PlacementRules {
  version: 1
  /** Record type, e.g. "initiative". */
  type: string
  /** Any of these stages; empty = every stage. */
  stages: string[]
  /** Only records marked "feature on the home page". */
  featuredOnly: boolean
  /** Only records with a main photo. */
  hasPhoto: boolean
  /** home-order = feature order (then newest); newest = latest start date; end-date = ending soonest first. */
  order: RuleOrder
  /** How many, 1–12. */
  limit: number
  /** What each card shows. */
  show: Record<CardPart, boolean>
  /** No matches: hide the section, or show a short message. */
  fallback: 'hide' | 'message'
}

/** A record as rules see it. Live = status PUBLISHED (drafts never show). */
export interface RuleRecord {
  id: string
  status: string
  data: Record<string, unknown>
  updatedAt?: string
}

export const MAX_LIMIT = 12

export function defaultRules(type: string): PlacementRules {
  return {
    version: 1,
    type,
    stages: [],
    featuredOnly: true,
    hasPhoto: false,
    order: 'home-order',
    limit: 3,
    show: { photo: true, stage: true, location: true, summary: true, progress: false },
    fallback: 'hide',
  }
}

const isStr = (v: unknown): v is string => typeof v === 'string'

/** Parse + clamp stored rules (a JSON string or object); null when absent or not rules at all. */
export function parseRules(raw: unknown, allowedStages?: readonly string[]): PlacementRules | null {
  let v: unknown = raw
  if (isStr(raw)) {
    if (!raw.trim()) return null
    try {
      v = JSON.parse(raw)
    } catch {
      return null
    }
  }
  if (!v || typeof v !== 'object' || Array.isArray(v)) return null
  const o = v as Record<string, unknown>
  if (!isStr(o.type) || !/^[a-z][a-z0-9-]{0,39}$/.test(o.type)) return null
  const base = defaultRules(o.type)
  const stages = Array.isArray(o.stages) ? [...new Set(o.stages.filter(isStr))].filter((s) => !allowedStages || allowedStages.includes(s)) : base.stages
  const limit = Number.isFinite(Number(o.limit)) ? Math.min(MAX_LIMIT, Math.max(1, Math.round(Number(o.limit)))) : base.limit
  const showIn = o.show && typeof o.show === 'object' ? (o.show as Record<string, unknown>) : {}
  const show = Object.fromEntries(CARD_PARTS.map((p) => [p, typeof showIn[p] === 'boolean' ? (showIn[p] as boolean) : base.show[p]])) as Record<CardPart, boolean>
  return {
    version: 1,
    type: o.type,
    stages,
    featuredOnly: typeof o.featuredOnly === 'boolean' ? o.featuredOnly : base.featuredOnly,
    hasPhoto: typeof o.hasPhoto === 'boolean' ? o.hasPhoto : base.hasPhoto,
    order: (RULE_ORDERS as readonly string[]).includes(o.order as string) ? (o.order as RuleOrder) : base.order,
    limit,
    show,
    fallback: o.fallback === 'message' ? 'message' : 'hide',
  }
}

export function serializeRules(r: PlacementRules): string {
  return JSON.stringify(r)
}

const filled = (v: unknown) => isStr(v) && v.trim().length > 0

/** Does this record pass the filters (ignoring the limit)? */
export function matchesRules(rec: RuleRecord, r: PlacementRules, f: PlacementFields = DEFAULT_PLACEMENT_FIELDS): boolean {
  if (rec.status !== 'PUBLISHED') return false
  if (r.stages.length && !r.stages.includes(String(rec.data[f.group] ?? ''))) return false
  if (r.featuredOnly && rec.data[f.featured] !== true) return false
  if (r.hasPhoto && !filled(rec.data[f.photo])) return false
  return true
}

const num = (v: unknown, dflt: number) => (typeof v === 'number' && Number.isFinite(v) ? v : dflt)
const date = (v: unknown) => (isStr(v) && /^\d{4}-\d{2}-\d{2}/.test(v) ? v : '')

/** The records the section shows, in order, at most `limit`. Never mutates its input. */
export function applyRules<R extends RuleRecord>(records: readonly R[], r: PlacementRules, f: PlacementFields = DEFAULT_PLACEMENT_FIELDS): R[] {
  const indexed = records.map((rec, i) => ({ rec, i })).filter(({ rec }) => matchesRules(rec, r, f))
  const newest = (a: { rec: R; i: number }, b: { rec: R; i: number }) =>
    date(b.rec.data[f.start]).localeCompare(date(a.rec.data[f.start])) || (b.rec.updatedAt ?? '').localeCompare(a.rec.updatedAt ?? '') || a.i - b.i
  indexed.sort((a, b) => {
    if (r.order === 'home-order') {
      const fa = a.rec.data[f.featured] === true ? num(a.rec.data[f.featuredOrder], 999) : Infinity
      const fb = b.rec.data[f.featured] === true ? num(b.rec.data[f.featuredOrder], 999) : Infinity
      return fa === fb ? newest(a, b) : fa - fb
    }
    if (r.order === 'end-date') {
      // Ending soonest first; no end date goes last.
      const ea = date(a.rec.data[f.end]) || '9999'
      const eb = date(b.rec.data[f.end]) || '9999'
      return ea.localeCompare(eb) || newest(a, b)
    }
    return newest(a, b)
  })
  return indexed.slice(0, r.limit).map(({ rec }) => rec)
}

const ORDER_WORDS: Record<RuleOrder, string> = { 'home-order': 'home page order', newest: 'newest first', 'end-date': 'ending soonest first' }

/** One plain sentence, for the editor and the review card. */
export function explainRules(r: PlacementRules, labels: { plural: string; stage?: (s: string) => string } = { plural: `${r.type}s` }): string {
  const stage = labels.stage ?? ((s: string) => s)
  const parts = [`Live ${labels.plural.toLowerCase()}`]
  if (r.stages.length) parts.push(` that are ${r.stages.map(stage).join(' or ')}`)
  const extra = [r.featuredOnly && 'featured on the home page', r.hasPhoto && 'with a photo'].filter(Boolean)
  if (extra.length) parts.push(`${r.stages.length ? ',' : ''} ${extra.join(', ')}`)
  return `${parts.join('')} — ${ORDER_WORDS[r.order]}, up to ${r.limit}. ${r.fallback === 'hide' ? 'Hidden when none match.' : 'Shows a short message when none match.'}`
}
