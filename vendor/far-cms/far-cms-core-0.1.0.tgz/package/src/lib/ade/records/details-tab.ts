/**
 * Which Details tab a record / post editor opens on, and where it goes when
 * a tab's panel fails. A tab named in the address is only taken when it is
 * one the editor has; a panel that throws falls back to Details (and if
 * Details itself throws, the panel closes) — a bad tab never bricks a record.
 */

/** The tab named in the address when the editor has it, else null. */
export function tabFromParam<T extends string>(param: string | null | undefined, tabs: readonly T[]): T | null {
  return param != null && (tabs as readonly string[]).includes(param) ? (param as T) : null
}

/** After `failed`'s panel threw: Details, or null (close the panel) when Details is what failed. */
export function fallbackTab<T extends string>(failed: T, home: T): T | null {
  return failed === home ? null : home
}
