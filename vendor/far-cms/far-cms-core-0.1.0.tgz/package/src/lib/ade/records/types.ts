/**
 * ADE records — app-agnostic definitions + records. No app imports.
 *
 * A RECORD is structured facts of one TYPE (an initiative, later a blog post
 * or a product-launch CTA). A type is DATA — a RecordTypeDef — so adding one
 * needs no new code path: validation, forms, the page template, bound
 * placements, overrides and events are all driven by the definition.
 *
 * Each record owns one PAGE (made from the type's template; the page owns the
 * narrative). Facts render on any page through PLACEMENTS: blocks BOUND to a
 * record field. One source of truth — placements read the record; they never
 * copy it. A placement may carry an explicit per-field OVERRIDE ("customized
 * here"), which is visible and resettable.
 */

import type { ChecklistItemDef, RecordChecklistCtx } from './checklist'

export type FieldType =
  | 'text'
  | 'longtext'
  | 'slug'
  | 'enum'
  | 'date'
  | 'image'
  | 'url'
  | 'boolean'
  | 'number'
  | 'stats'
  /** A list of Media image URLs (a photo gallery); `max` = most photos. */
  | 'gallery'
  /** Blocks added to the record's page from the block library (lib/ade/records/page-blocks); `max` = most blocks. */
  | 'blocks'

export interface FieldDef {
  key: string
  label: string
  type: FieldType
  required?: boolean
  /** enum options */
  options?: ReadonlyArray<{ value: string; label: string }>
  /** max length for text-like fields / max items for stats */
  max?: number
  help?: string
  /** Shown on the short "new record" form. */
  quick?: boolean
  default?: unknown
  /** false = never drafted by the assistant from notes (placement choices like "feature on the home page"). */
  draftable?: boolean
  /** Other words people use for this field ("summary", "subtitle"): the assistant finds it by any of them. */
  aliases?: ReadonlyArray<string>
}

/** A block in a page template. `{{field}}` in text is filled from the record; `$record` binds. */
export interface TemplateBlock {
  tag: string
  className?: string
  textContent?: string
  attrs?: Record<string, string>
  componentName?: string
  label?: string
  children?: TemplateBlock[]
}

export interface RecordTypeDef {
  key: string
  label: string
  plural: string
  /** Field holding the display title (also the page title). */
  titleField: string
  /** Field holding the slug (derived from the title when empty). */
  slugField: string
  /** Pages live at `${pathPrefix}/${slug}`. */
  pathPrefix: string
  fields: ReadonlyArray<FieldDef>
  /** Page template for the record's own page. */
  pageTemplate: ReadonlyArray<TemplateBlock>
  /** Fields whose change is a lifecycle event (e.g. stage). */
  eventFields?: ReadonlyArray<string>
  /** Date fields that emit `date.reached` events. */
  dateEventFields?: ReadonlyArray<string>
  /** Review-queue category for edits to this type. */
  category: string
  /**
   * Everything below is optional and per type, so a new type (BYB's "drop")
   * is data, not code. Absent → the generic behaviour.
   */
  /** Ready to publish: the type's own checklist (gates Publish; shown on the record page). */
  checklist?: ReadonlyArray<ChecklistItemDef<RecordChecklistCtx>>
  /** Checklist items that only warn when sent from a phone (filled in later on the web). */
  phoneWarnings?: ReadonlyArray<string>
  /** The template's smart blocks as editor-canvas parts: componentName → part + which of this type's fields it shows. */
  canvasParts?: Readonly<Record<string, CanvasPartDef>>
  /** List blocks that show records of this type by membership (a home-page highlights block) and take placement rules. */
  listComponents?: ReadonlyArray<ListComponentDef>
  /** A featured record's card on the home page: its component and the blocks whose area it joins. */
  homeCard?: { componentName: string; areaComponents: ReadonlyArray<string> }
  /** Which of this type's fields placement rules read (lib/ade/records/rules); missing keys use the defaults. */
  placement?: Partial<PlacementFields>
  /** Fields edited under the record page's Details tab (default: every field not drawn on the page). */
  detailsFields?: ReadonlyArray<string>
}

/** An editor-canvas part (header, stats, goal, gallery) and the fields it shows, keyed by the part's own names. */
export interface CanvasPartDef {
  part: 'header' | 'stats' | 'goal' | 'gallery'
  fields?: Readonly<Record<string, string>>
}

export interface ListComponentDef {
  componentName: string
  /** Display modes it takes ("stats", "showcase"…). */
  modes?: ReadonlyArray<string>
  /** Without rules, it shows only records marked featured (else every live one when data-source="all"). */
  featuredByDefault?: boolean
}

/** The fields placement rules filter and sort by. */
export interface PlacementFields {
  /** The enum field rules filter by ("stage"). */
  group: string
  featured: string
  featuredOrder: string
  photo: string
  start: string
  end: string
}

export type RecordData = Record<string, unknown>

export type RecordStatus = 'DRAFT' | 'PUBLISHED' | 'ARCHIVED'

export interface RecordSnapshot {
  type: string
  slug: string
  status: RecordStatus
  pageId: string | null
  data: RecordData
}

/** `<type>:<id>` — what a bound block stores in data-record. */
export type RecordRef = `${string}:${string}`

/** Block attributes used by placements. */
export const BIND_ATTR = 'data-record'
export const FIELD_ATTR = 'data-field'
export const OVERRIDES_ATTR = 'data-overrides'
/** Template placeholder for "this record". */
export const SELF_REF = '$record'
