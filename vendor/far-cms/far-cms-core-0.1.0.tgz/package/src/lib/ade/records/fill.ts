/**
 * Fill in place (design rule R6): the assistant types into the REAL fields of a
 * record page, one at a time with the spotlight on it, and its work stays
 * marked — the assistant's outline + badge, then "You edited" in amber once the person
 * changes it, and "was: …" when it replaced an earlier value.
 *
 * Code does the choreography (which fields, in what order, where each lives);
 * the model only supplies values. Values are checked against the record type
 * (coerceDraft: known draftable fields, real options, real dates, lengths) —
 * an option the page doesn't have is never written, and what's still missing
 * becomes questions whose options are the page's real values (R7). Nothing here
 * saves: the page's own Propose does that (R8).
 *
 * Pure and app-agnostic (the record type comes in). Asserted by fill.assert.ts.
 */

import { coerceDraft } from './draft'
import type { FieldDef, RecordData, RecordTypeDef } from './types'

export const FILL_LIMITS = {
  /** Characters of the model's JSON argument. */
  argChars: 6000,
  /** Characters of a "was: …" label. */
  wasChars: 60,
  /** Typing speed (ms per step) and how many characters a step adds; reduced motion types at once. */
  typeStepMs: 18,
  typeChunk: 3,
  /** Pause on each field after typing, so the person sees it land. */
  holdMs: 450,
  /** Hard bounds (a run can never hang the tab): fields per run, renders per field, the whole run's time. */
  maxFields: 20,
  maxFrames: 14,
  runMs: 25_000,
  /** A field hidden in the drawer must appear within this long after the reveal. */
  revealMs: 1_500,
  /** Read-back after each write: tries × gap (bounded), then one retry of the write. */
  readbackTries: 6,
  readbackGapMs: 80,
  /** The working ring stays at least this long on each field (brief 1c: minimum dwell). */
  ringMs: 600,
} as const

/** Neutral defaults; the app names its assistant (lib/ade-bindings/record-fill RECORD_FILL_NAMES). */
export const FILL_COPY = {
  badgeAssistant: 'Assistant',
  badgeYou: 'You edited',
  was: (v: string) => `was: ${v}`,
  legendAssistant: 'Filled by the assistant',
  legendYou: 'Changed by you',
  legendNote: 'Edit anything. Nothing is saved until you propose it.',
  stepTitle: (label: string) => `Fill “${label}”`,
  proposeStep: 'Propose it for review',
} as const

/** Where a field lives on the record page: on the page itself (hero / story) or in the Details drawer. */
export type FillWhere = 'page' | 'details'

export interface FillMove {
  key: string
  label: string
  value: unknown
  /** The value it replaces, as text (empty when the field was empty). */
  was: string
  where: FillWhere
  /** The field's type: only text is typed character by character; dates, choices and numbers land at once. */
  type?: string
}

export interface FillQuestion {
  key: string
  label: string
  type: 'single' | 'text' | 'image'
  /** The page's own options (enum fields) — never invented. */
  options: ReadonlyArray<{ value: string; label: string }>
}

export interface FillPlan {
  moves: FillMove[]
  /** Sent but not written, and why (unknown field, not one of the page's options, a bad date…). */
  rejected: Array<{ key: string; reason: string }>
  /** Required facts still empty after the fill: ask the person (R7). */
  ask: FillQuestion[]
  /** Sent with the value the page already shows (an answer matching the default): nothing to type, but it is the assistant's value — marked (F4). */
  already?: Array<{ key: string; label: string; value: unknown }>
}

const asText = (v: unknown): string =>
  v === undefined || v === null ? '' : Array.isArray(v) ? v.map((x) => (typeof x === 'object' && x ? Object.values(x).join(' ') : String(x))).join(', ') : typeof v === 'object' ? JSON.stringify(v) : String(v)
const same = (a: unknown, b: unknown) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null)
const empty = (v: unknown) => v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0)

/** Template keys the page itself shows ({{field}} text and the bound header), in page order. */
export function pageFieldKeys(def: RecordTypeDef, boundParts: Readonly<Record<string, readonly string[]>> = {}): string[] {
  const out: string[] = []
  const walk = (blocks: RecordTypeDef['pageTemplate']) => {
    for (const b of blocks) {
      if (b.componentName && boundParts[b.componentName]) out.push(...boundParts[b.componentName])
      for (const m of (b.textContent ?? '').matchAll(/\{\{(\w+)\}\}/g)) out.push(m[1])
      if (b.children) walk(b.children)
    }
  }
  walk(def.pageTemplate)
  return [...new Set(out)].filter((k) => def.fields.some((f) => f.key === k))
}

/**
 * The order the fill visits fields: what the page shows first (hero, then the
 * story, top to bottom), then the Details drawer in the definition's order.
 */
export function fillOrder(def: RecordTypeDef, boundParts?: Readonly<Record<string, readonly string[]>>): Array<{ field: FieldDef; where: FillWhere }> {
  const onPage = pageFieldKeys(def, boundParts)
  const byKey = new Map(def.fields.map((f) => [f.key, f]))
  return [
    ...onPage.map((k) => ({ field: byKey.get(k)!, where: 'page' as const })),
    ...def.fields.filter((f) => !onPage.includes(f.key)).map((field) => ({ field, where: 'details' as const })),
  ]
}

/** Read the model's argument: a JSON object of field → value (untrusted). */
/**
 * "Name: Clinic visit in Ho; Location: Ho, Volta Region" → { Name: …, Location: … }. Pairs split on ";" or new
 * lines, each at its first ":" (a value's own commas and colons stay). Not that shape → null.
 */
function labelPairs(raw: string): Record<string, unknown> | null {
  const out: Record<string, unknown> = {}
  for (const piece of raw.split(/[;\n]+/)) {
    const at = piece.indexOf(':')
    if (at <= 0) continue
    const label = piece.slice(0, at).trim()
    const value = piece.slice(at + 1).trim()
    if (label && value && label.length <= 60 && !(label in out)) out[label] = value
  }
  return Object.keys(out).length ? out : null
}

export function parseFillArg(raw: unknown): Record<string, unknown> | null {
  let v: unknown = raw
  if (typeof raw === 'string') {
    if (raw.length > FILL_LIMITS.argChars) return null
    try {
      v = JSON.parse(raw)
    } catch {
      // "Label: value; Label: value" (seen on staging, run c964ab3d): labels map to keys later (normalizeFillKeys).
      return labelPairs(raw)
    }
  }
  // Shapes models send: { fields: {…} } wrapped once more, or a list of { key|field|name, value }.
  if (Array.isArray(v)) {
    const pairs = v.filter((p): p is Record<string, unknown> => !!p && typeof p === 'object').map((p) => [p.key ?? p.field ?? p.name, p.value] as const)
    const obj = Object.fromEntries(pairs.filter(([k]) => typeof k === 'string' && k.trim()))
    return Object.keys(obj).length ? obj : null
  }
  if (!v || typeof v !== 'object') return null
  const o = v as Record<string, unknown>
  const inner = o.fields
  if (Object.keys(o).length === 1 && inner && typeof inner === 'object') return parseFillArg(inner)
  return o
}

/**
 * What to type where. `current` is what the page holds now (unsaved edits
 * included). Values equal to what's there are skipped; the web address is never
 * typed (the page makes it from the name); images are chosen, not typed.
 */
export function planFill(def: RecordTypeDef, current: RecordData, proposed: Record<string, unknown>, opts: { boundParts?: Readonly<Record<string, readonly string[]>> } = {}): FillPlan {
  const { data, dropped } = coerceDraft(def, normalizeFillValues(def, normalizeFillKeys(def, proposed)))
  delete data[def.slugField]
  const order = fillOrder(def, opts.boundParts)
  const moves: FillMove[] = order
    .filter(({ field }) => field.key in data && !same(data[field.key], current[field.key]))
    .map(({ field, where }) => ({ key: field.key, label: field.label, value: data[field.key], was: asText(current[field.key]), where, type: field.type }))
  const already = order
    .filter(({ field }) => field.key in data && same(data[field.key], current[field.key]) && !empty(data[field.key]))
    .map(({ field }) => ({ key: field.key, label: field.label, value: data[field.key] }))
  const after = { ...current, ...data }
  // A value the page has no option for is asked too — with the page's real options.
  const badEnum = new Set(dropped.filter((d) => def.fields.find((f) => f.key === d.key)?.type === 'enum').map((d) => d.key))
  const ask: FillQuestion[] = order
    .map(({ field }) => field)
    .filter((f) => ((f.required && empty(after[f.key])) || badEnum.has(f.key)) && f.key !== def.slugField)
    .map((f) => ({ key: f.key, label: f.label, type: f.type === 'enum' ? 'single' : f.type === 'image' ? 'image' : 'text', options: f.type === 'enum' ? [...(f.options ?? [])] : [] }))
  // Images are picked from the media library (the photo question), never typed.
  const rejected = dropped.map((d) => {
    const f = def.fields.find((x) => x.key === d.key)
    if (f?.type === 'blocks') return { key: d.key, reason: 'add sections with record.add_block (the Blocks tab)' }
    return f?.type === 'image' || f?.type === 'gallery' ? { key: d.key, reason: 'choose it from the media library' } : d
  })
  return { moves, rejected, ask, ...(already.length ? { already } : {}) }
}

const squash = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '')
/** Words people (and models) use for a field instead of its key. */
const KEY_ALIASES: Readonly<Record<string, string>> = { start: 'startDate', starts: 'startDate', startson: 'startDate', begins: 'startDate', end: 'endDate', ends: 'endDate', endson: 'endDate', place: 'location', where: 'location', oneliner: 'summary', description: 'summary' }

/**
 * The model's keys mapped to the record's own: the key itself (any case), the
 * field's label ("Start date", "One-line summary"), or a common alias
 * ("starts", "title" → the title field). Unknown keys pass through (refused later).
 */
export function normalizeFillKeys(def: RecordTypeDef, raw: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(raw)) {
    // A plan step's title used as the key ("Fill “Name”") means the field it names.
    const s = squash(k.replace(/^\s*fill\s+/i, ''))
    const f = def.fields.find((x) => x.key === k) ?? def.fields.find((x) => squash(x.key) === s || squash(x.label) === s)
    const key = f?.key ?? (s === 'title' ? def.titleField : KEY_ALIASES[s] && def.fields.some((x) => x.key === KEY_ALIASES[s]) ? KEY_ALIASES[s] : k)
    if (!(key in out)) out[key] = v
  }
  return out
}

const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
const pad = (n: number) => String(n).padStart(2, '0')
/** A date as people write it → YYYY-MM-DD ("2026-11-02", "11/02/2026", "November 2, 2026", "2 Nov 2026"); null when not a date. */
export function toIsoDate(v: unknown): string | null {
  if (typeof v !== 'string') return null
  const s = v.trim()
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s)
  if (m) return `${m[1]}-${pad(+m[2])}-${pad(+m[3])}`
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s) // US: month/day/year (the page's own format)
  if (m) return `${m[3]}-${pad(+m[1])}-${pad(+m[2])}`
  m = /^([a-z]{3,})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$/i.exec(s)
  if (m && MONTHS.indexOf(m[1].slice(0, 3).toLowerCase()) >= 0) return `${m[3]}-${pad(MONTHS.indexOf(m[1].slice(0, 3).toLowerCase()) + 1)}-${pad(+m[2])}`
  m = /^(\d{1,2})(?:st|nd|rd|th)?\s+([a-z]{3,})\.?,?\s+(\d{4})$/i.exec(s)
  if (m && MONTHS.indexOf(m[2].slice(0, 3).toLowerCase()) >= 0) return `${m[3]}-${pad(MONTHS.indexOf(m[2].slice(0, 3).toLowerCase()) + 1)}-${pad(+m[1])}`
  return null
}

/** Dates in any common form become ISO before the checks (an impossible date is still refused and asked). */
export function normalizeFillValues(def: RecordTypeDef, raw: Record<string, unknown>): Record<string, unknown> {
  const out = { ...raw }
  for (const f of def.fields) if (f.type === 'date' && f.key in out) out[f.key] = toIsoDate(out[f.key]) ?? out[f.key]
  return out
}

/**
 * A choice the request names that the page doesn't offer ("set the stage to
 * paused") — found in the person's words, before any fill, so the question
 * form comes even when no value was sent to the page.
 */
export function invalidChoicesIn(def: RecordTypeDef, text: string): Array<{ key: string; label: string; value: string; options: Array<{ value: string; label: string }> }> {
  const out: Array<{ key: string; label: string; value: string; options: Array<{ value: string; label: string }> }> = []
  for (const f of def.fields) {
    if (f.type !== 'enum' || !f.options?.length) continue
    const names = [f.label, f.key].map((n) => n.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
    const m = new RegExp(`\\b(?:${names.join('|')})\\b\\s*(?:to|:|=|is|as|should be|of)?\\s*["“']?([a-z][a-z-]{1,30})`, 'i').exec(text)
    if (!m) continue
    const v = m[1].toLowerCase()
    if (['the', 'a', 'an', 'it', 'this', 'that', 'one', 'and', 'or'].includes(v)) continue
    if (f.options.some((o) => o.value.toLowerCase() === v || o.label.toLowerCase() === v)) continue
    out.push({ key: f.key, label: f.label, value: m[1], options: f.options.map((o) => ({ value: o.value, label: o.label })) })
  }
  return out
}

/** The prompt line for those: ask with the page's options only. */
export function invalidChoiceLine(bad: ReturnType<typeof invalidChoicesIn>): string {
  return `[Choice] ${bad.map((b) => `“${b.value}” isn’t a ${b.label.toLowerCase()} this page offers`).join('; ')}. Do not change it. Ask with ask_user (single choice) using ONLY these options: ${bad.map((b) => `${b.label}: ${b.options.map((o) => o.label).join(' / ')}`).join('; ')}.`
}

/** In a selected-text turn: the only field that may change (null = not a selection turn). */
export function selectionTurnField(i: { onRecord: boolean; text: string; selection: { text: string; fieldKey?: string } | null | undefined }): string | null {
  return i.onRecord && i.selection?.text && i.selection.fieldKey && isSelectionAction(i.text) ? i.selection.fieldKey : null
}

/**
 * Enforce a selection turn on the record.fill call itself (server, before it
 * reaches the page): only the selected field, always replaceSelection. Another
 * capability, or no value for that field → refused with the one right call.
 */
export function selectionOnlyCall(call: { capability: string; args: Record<string, unknown> }, fieldKey: string): { ok: true; args: Record<string, unknown> } | { ok: false; error: string } {
  const right = `Only the selected text changes now: call record.fill with fields {"${fieldKey}": "<the rewritten selection>"}.`
  if (call.capability !== 'record.fill') return { ok: false, error: right }
  const fields = parseFillArg(call.args.fields)
  const value = fields ? fields[fieldKey] : undefined
  if (typeof value !== 'string' || !value.trim()) return { ok: false, error: right }
  return { ok: true, args: { ...call.args, fields: JSON.stringify({ [fieldKey]: value }), replaceSelection: true } }
}

/** record.fill's `fields` given as an object (models often do) becomes the JSON text the capability declares. */
export function coerceFillArgs(args: Record<string, unknown>): Record<string, unknown> {
  const f = args.fields
  return f && typeof f === 'object' ? { ...args, fields: JSON.stringify(f) } : args
}

/** The renders a field's typing takes: text grows in chunks, never more than maxFrames; anything else lands at once. */
export function framesFor(value: unknown, type: string | undefined, still: boolean): unknown[] {
  if (still || typeof value !== 'string' || (type !== 'text' && type !== 'longtext')) return [value]
  const chunk = Math.max(FILL_LIMITS.typeChunk, Math.ceil(value.length / FILL_LIMITS.maxFrames))
  return typingFrames(value, chunk)
}

/** What a field shows after a write (read from the page itself). */
export interface FieldResult {
  key: string
  label: string
  intended: string
  found: string
  ok: boolean
  /** Why it didn't take, in plain words (not reachable, still shows something else, out of time). */
  why?: string
}

const norm = (s: string) => s.replace(/\s+/g, ' ').trim().toLowerCase()

/** Does what the page shows match what was written? Text: same words; choices: the value or its label; numbers/dates: same value. */
export function readbackMatches(intended: unknown, found: string, accept: readonly string[] = []): boolean {
  const want = [intended === null || intended === undefined ? '' : String(intended), ...accept].map(norm)
  const got = norm(found)
  if (want.includes(got)) return true
  if (typeof intended === 'number') return Number(found.replace(/[^\d.-]/g, '')) === intended
  return false
}

/**
 * The one line the chat shows after a fill, from the read-back results only —
 * never more than the page shows (the model does not write "I've set …").
 */
export function fillResultLine(results: readonly FieldResult[]): string {
  if (!results.length) return 'Nothing new to fill.'
  const ok = results.filter((r) => r.ok).map((r) => r.label)
  const bad = results.filter((r) => !r.ok)
  const list = (xs: string[]) => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`)
  const parts: string[] = []
  if (ok.length) parts.push(`Filled ${list(ok)} on the page — not saved until you propose it.`)
  for (const b of bad) parts.push(`${b.label} did not take${b.why ? ` (${b.why})` : ''}${b.found ? `; it still shows “${b.found.slice(0, 60)}”` : ''}. You can type it there yourself.`)
  return parts.join(' ')
}

/** Plan step titles that match the fields being filled (R11), ending with the page's own Propose. */
export function fillSteps(plan: FillPlan): string[] {
  return [...plan.moves.map((m) => FILL_COPY.stepTitle(m.label)), FILL_COPY.proposeStep]
}

/** The text in a field as it types: grows by `chunk` characters per step; non-text values land at once. */
export function typingFrames(value: unknown, chunk: number = FILL_LIMITS.typeChunk): unknown[] {
  if (typeof value !== 'string' || value.length <= chunk) return [value]
  const frames: string[] = []
  for (let i = chunk; i < value.length; i += chunk) frames.push(value.slice(0, i))
  frames.push(value)
  return frames
}

/**
 * The per-turn line when code starts a plan on a record page (R11): the steps are
 * the fields it will fill, and the values go through the page (record.fill).
 */
export const FILL_PLAN_HINT = `[Record page] Make each plan step one field you will fill, in the page's own words (${FILL_COPY.stepTitle('Name')}, ${FILL_COPY.stepTitle('One-line summary')}…), ending with "${FILL_COPY.proposeStep}". Type the values with operate_ui record.fill (one call, every field you have facts for); only facts the person gave or the page shows. Missing facts: ask_user with the page's own options. Never press Propose — the person does.`

// ── Marks: what the assistant filled, what the person changed after ───────

export interface FillMark {
  by: 'assistant' | 'you'
  /** The earlier value it replaced (existing records only); empty = none. */
  was: string
}
export type FillMarks = Readonly<Record<string, FillMark>>

/** The assistant filled `key` (replacing `was`). */
export function markAssistant(marks: FillMarks, key: string, was: string): FillMarks {
  return { ...marks, [key]: { by: 'assistant', was: marks[key]?.was || was } }
}

/** The person edited `key`: only a field the assistant filled turns amber ("You edited"). */
/** A value the assistant set that the page already showed (an answer equal to the default): its mark, unless the person changed it. */
export function markAssistantKept(marks: FillMarks, key: string): FillMarks {
  return marks[key]?.by === 'you' ? marks : markAssistant(marks, key, '')
}

export function markPersonEdit(marks: FillMarks, key: string): FillMarks {
  const m = marks[key]
  return m && m.by === 'assistant' ? { ...marks, [key]: { ...m, by: 'you' } } : marks
}

/** How a mark shows: the badge, and "was: …" only when it replaced a real value. */
export function markView(mark: FillMark | undefined, names: { badgeAssistant: string } = FILL_COPY): { badge: string; was: string | null } | null {
  if (!mark) return null
  const was = mark.was.trim()
  return {
    badge: mark.by === 'assistant' ? names.badgeAssistant : FILL_COPY.badgeYou,
    was: was ? FILL_COPY.was(was.length > FILL_LIMITS.wasChars ? `${was.slice(0, FILL_LIMITS.wasChars - 1)}…` : was) : null,
  }
}

/** What the fill tells the model back: what it typed, what it couldn't, and what to ask (with the page's options). */
export function fillReport(plan: FillPlan): string {
  const head = plan.moves.length ? `Filled ${plan.moves.map((m) => m.label).join(', ')} on the page — not saved; the person proposes it with the page's own button.` : 'Nothing new to fill.'
  return [head, fillExtras(plan)].filter(Boolean).join(' ')
}

/** What the fill could not type, and what to ask (with the page's options) — without the "Filled …" claim. */
export function fillExtras(plan: FillPlan): string {
  const parts: string[] = []
  if (plan.rejected.length) parts.push(`Not filled: ${plan.rejected.map((r) => `${r.key} (${r.reason})`).join('; ')}.`)
  if (plan.ask.length) {
    parts.push(
      `Still needed — ask with ask_user, using only these options: ${plan.ask
        .map((q) => (q.options.length ? `${q.label} [${q.options.map((o) => o.label).join(' / ')}]` : q.type === 'image' ? `${q.label} [from the media library]` : `${q.label} [type your own]`))
        .join('; ')}.`
    )
  }
  return parts.join(' ')
}

// ── The question form, from code (R7): what the fill still needs, as the chat's own form ──

/** The form for what the fill could not type — the page's own options; never invented. Null when nothing is needed. */
export function fillAskForm(plan: FillPlan): { title: string; questions: Array<{ id: string; prompt: string; type: 'single' | 'text'; options: Array<{ value: string; label: string }> }> } | null {
  const qs = plan.ask
    .filter((q) => q.type !== 'image')
    .slice(0, 4)
    .map((q) => ({
      id: q.key.toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 24) || 'field',
      prompt: q.type === 'single' ? `Which ${q.label.toLowerCase()} is it?` : `What is the ${q.label.toLowerCase()}?`,
      type: q.type === 'single' && q.options.length >= 2 ? ('single' as const) : ('text' as const),
      options: q.type === 'single' ? q.options.slice(0, 6).map((o) => ({ value: o.value, label: o.label })) : [],
    }))
  return qs.length ? { title: 'A few things I need from you', questions: qs } : null
}

/** One line before the form. */
export const FILL_ASK_LINE = 'I filled what I could. These need you — the options are the page’s own.'

// ── Selected text on the page: an edit to that part of the field only ──

const TEXT_ACTIONS = ['shorter', 'shorten', 'longer', 'expand', 'simpler', 'simplify', 'rewrite', 'reword', 'rephrase', 'fix', 'tighten', 'punchier', 'clearer', 'friendlier', 'warmer', 'formal', 'casual', 'polish', 'improve', 'translate', 'proofread', 'grammar', 'spelling']

/** Is this message an edit to the selected text ("make this shorter", "fix the grammar")? */
export function isSelectionAction(text: string): boolean {
  const w = ` ${text.toLowerCase().replace(/[^a-z ]+/g, ' ').replace(/\s+/g, ' ')} `
  return text.trim().length <= 120 && TEXT_ACTIONS.some((a) => w.includes(` ${a} `) || w.includes(` ${a}`))
}

/** The field after replacing just the selected part (when it is found); otherwise the new text replaces the field. */
export function applySelectionEdit(current: unknown, selected: string, replacement: string): string {
  const cur = typeof current === 'string' ? current : ''
  const sel = selected.trim()
  if (!sel || !cur.includes(sel) || cur.trim() === sel) return replacement
  return cur.replace(sel, replacement)
}

// ── What a turn on a record page may do (route): code, not the model ──

export interface RecordTurn {
  /** Write tools hidden on this screen, so the page (record.fill) is the only way to change the record. */
  hide: string[]
  /** toolChoice per step (0 = first): the plan, then the page; or the page at once for a selected-text edit. */
  steps: Partial<Record<0 | 1, string>>
  /** Lines for the dynamic prompt. */
  lines: string[]
  /** A selected-text edit takes over from a plan. */
  planned: boolean
}

export const RECORD_SCREEN_RULE = `[Record page] This record's page is open. Change its facts ONLY with operate_ui record.fill — it types into the page's own fields; the person proposes with the page's button. No change cards for this record, no other write tools. Propose, approve, publish, reject and delete are the person's: point at the page's own button (spotlight_steps) and say what it will do — never press it. To add a section to this page: find_blocks, then operate_ui record.add_block with its id — the page adds it unsaved and says which shelf it came from; don't repeat that.`

export function recordTurn({ onRecord, text, selection, forcedPlan, writeTools, screenTool, planTool, answers = false, changeRequest = false, invalid = [], askTool = 'ask_user', fieldsLine = null }: {
  onRecord: boolean
  /** Choices the request names that the page doesn't offer (invalidChoicesIn): ask first, change nothing. */
  invalid?: ReturnType<typeof invalidChoicesIn>
  askTool?: string
  /** The record's fields and their shapes, for the fill's keys (draftInstructions). */
  fieldsLine?: string | null
  /** The message asks for a change (plan.ts isChangeRequest): on the fly it goes straight to the page. */
  changeRequest?: boolean
  text: string
  /** The message answers a question form ("My answers: …"): it goes straight into the page. */
  answers?: boolean
  selection: { text: string; fieldKey?: string; fieldLabel?: string } | null | undefined
  forcedPlan: string | null
  /** The app's record write tools (hidden here). */
  writeTools: readonly string[]
  screenTool: string
  planTool: string
}): RecordTurn {
  if (!onRecord) return { hide: [], steps: {}, lines: [], planned: !!forcedPlan }
  // A choice the page doesn't have: the question form first (forced), with the page's options; nothing changes.
  if (invalid.length && !selection?.fieldKey) {
    return { hide: [...writeTools], steps: { 0: askTool }, lines: [RECORD_SCREEN_RULE, invalidChoiceLine(invalid)], planned: false }
  }
  if (answers) {
    return { hide: [...writeTools], steps: { 0: screenTool }, lines: [RECORD_SCREEN_RULE, '[Answers] Put their answers into the page now: ONE operate_ui record.fill with every answered field (choices like the stage too — not record.set_stage); say nothing about the result yourself.'], planned: false }
  }
  if (selection?.text && selection.fieldKey && isSelectionAction(text)) {
    return {
      hide: [...writeTools],
      steps: { 0: screenTool },
      lines: [
        RECORD_SCREEN_RULE,
        `[Selection] They selected this in “${selection.fieldLabel ?? selection.fieldKey}” (${selection.fieldKey}): “${selection.text.slice(0, 280)}”. Rewrite ONLY that text as they asked and call operate_ui record.fill with fields {"${selection.fieldKey}": "<the rewritten selection>"} and replaceSelection: true.`,
      ],
      planned: false,
    }
  }
  // Planned: show the plan and wait (propose); after Go: the plan, then the page's fill.
  if (forcedPlan === 'propose') return { hide: [...writeTools], steps: { 0: planTool }, lines: [RECORD_SCREEN_RULE], planned: true }
  // After Go the plan, then the fill — with the same instructions as on the fly (keys + shapes, one call), so it
  // runs exactly like "just do it" (F1, staging 81b58185).
  if (forcedPlan === 'go' || forcedPlan === 'start') return { hide: [...writeTools], steps: { 0: planTool, 1: screenTool }, lines: [RECORD_SCREEN_RULE, FILL_NOW_LINE, ...(fieldsLine ? [fieldsLine] : [])], planned: true }
  if (forcedPlan) return { hide: [...writeTools], steps: { 0: planTool }, lines: [RECORD_SCREEN_RULE], planned: true }
  // On the fly ("fill this in", "just do it", a small change): straight into the page — steps show as it types.
  if (changeRequest) return { hide: [...writeTools], steps: { 0: screenTool }, lines: [RECORD_SCREEN_RULE, FILL_NOW_LINE, ...(fieldsLine ? [fieldsLine] : [])], planned: false }
  return { hide: [...writeTools], steps: {}, lines: [RECORD_SCREEN_RULE], planned: false }
}

/** On the fly on a record page: fill now, in one call. */
export const FILL_NOW_LINE = '[Record page] Fill it now: one operate_ui record.fill with every field you have facts for — the page types them in place and reports what took; say nothing about the result yourself. The person proposes.'


/** Did this step call the page's fill (operate_ui record.fill)? Then the run ends there and the page reports. */
export function endsAtFill(toolCalls: ReadonlyArray<{ toolName: string; input?: unknown }>): boolean {
  return toolCalls.some((c) => c.toolName === 'operate_ui' && ((c.input ?? {}) as { capability?: unknown }).capability === 'record.fill')
}
