/**
 * Ready-to-go-public checklist — before a record (initiative, post, event…)
 * is published or shows in a placement, what's done and what's missing.
 * Items are checked automatically from the data, or ticked by a person
 * ("page reviewed in preview"). REQUIRED items gate Publish; optional ones
 * only warn. Pure and app-agnostic: the host app supplies the items.
 */

/** The manual "Page reviewed in preview" item's id (a person ticks it; sent with Publish). */
export const REVIEWED_ITEM = 'reviewed'

/** What a record type's checklist items read: the record's facts, and whether a home-page rule would show it. */
export interface RecordChecklistCtx {
  data: Record<string, unknown>
  /** Whether a home-page placement rule would show it once live; undefined = no rules to check. */
  placementMatches?: boolean
}

export interface ChecklistItemDef<C> {
  id: string
  /** Plain words, e.g. "Main photo chosen". */
  label: string
  required: boolean
  /** auto = from the data; manual = a person ticks it. */
  kind: 'auto' | 'manual'
  /** For auto items. Return a string to explain what's missing. */
  check?: (ctx: C) => boolean | string
  /** Shown while the item isn't done. */
  hint?: string
  /** Leave the item out entirely for this context (e.g. no placement rules yet). */
  applies?: (ctx: C) => boolean
  /** The chat's conversation starter for this item while it's open (default: made from the label). */
  starter?: { title: string; sub?: string; prompt: string }
}

export interface ChecklistRow {
  id: string
  label: string
  required: boolean
  kind: 'auto' | 'manual'
  done: boolean
  hint?: string
}

export interface ChecklistResult {
  items: ChecklistRow[]
  /** Required items not done — Publish waits for these. */
  requiredLeft: number
  /** Optional items not done — warnings only. */
  optionalLeft: number
  /** Everything required is done. */
  ready: boolean
}

export function evaluateChecklist<C>(defs: ReadonlyArray<ChecklistItemDef<C>>, ctx: C, ticks: Readonly<Record<string, boolean>> = {}): ChecklistResult {
  const items: ChecklistRow[] = []
  for (const d of defs) {
    if (d.applies && !d.applies(ctx)) continue
    let done: boolean
    let hint = d.hint
    if (d.kind === 'manual') done = ticks[d.id] === true
    else {
      const r = d.check ? d.check(ctx) : false
      done = r === true
      if (typeof r === 'string') hint = r
    }
    items.push({ id: d.id, label: d.label, required: d.required, kind: d.kind, done, ...(done || !hint ? {} : { hint }) })
  }
  const requiredLeft = items.filter((i) => i.required && !i.done).length
  const optionalLeft = items.filter((i) => !i.required && !i.done).length
  return { items, requiredLeft, optionalLeft, ready: requiredLeft === 0 }
}

/** "2 items left" / "Ready" — for tabs, buttons and To-do titles. */
export function checklistSummary(r: Pick<ChecklistResult, 'requiredLeft'>): string {
  return r.requiredLeft === 0 ? 'Ready' : `${r.requiredLeft} item${r.requiredLeft === 1 ? '' : 's'} left`
}

/** The required items a server must re-check before publishing, minus manual ticks it was sent. */
export function blockingItems(r: ChecklistResult): ChecklistRow[] {
  return r.items.filter((i) => i.required && !i.done)
}
