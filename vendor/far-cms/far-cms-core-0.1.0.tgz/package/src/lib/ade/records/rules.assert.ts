/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/rules.assert.ts
 */
import assert from 'node:assert/strict'
import { applyRules, defaultRules, explainRules, matchesRules, parseRules, serializeRules, type RuleRecord } from './rules'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const rec = (id: string, data: Record<string, unknown>, status = 'PUBLISHED', updatedAt = '2026-10-01'): RuleRecord => ({ id, status, data, updatedAt })
const recs = [
  rec('akuse', { stage: 'active', featured: true, featuredOrder: 2, heroImageUrl: 'x.jpg', startDate: '2024-01-01', endDate: '2027-01-01' }),
  rec('clinic', { stage: 'active', featured: true, featuredOrder: 1, startDate: '2025-06-01', endDate: '2026-12-01' }),
  rec('grants', { stage: 'completed', featured: false, heroImageUrl: 'g.jpg', startDate: '2023-01-01' }),
  rec('supply', { stage: 'ongoing', featured: true, heroImageUrl: 's.jpg', startDate: '2025-01-01', endDate: '2026-11-01' }),
  rec('draft', { stage: 'active', featured: true, featuredOrder: 0, heroImageUrl: 'd.jpg' }, 'DRAFT'),
]
const ids = (rs: RuleRecord[]) => rs.map((r) => r.id)

check('defaults: live + featured, home order, 3, hide when none', () => {
  const r = defaultRules('initiative')
  assert.deepEqual(ids(applyRules(recs, r)), ['clinic', 'akuse', 'supply'])
})

check('drafts never show, whatever the rules', () => {
  const r = { ...defaultRules('initiative'), featuredOnly: false, limit: 12 }
  assert.ok(!ids(applyRules(recs, r)).includes('draft'))
  assert.equal(matchesRules(recs[4], r), false)
})

check('filters: stages, has a photo', () => {
  const r = { ...defaultRules('initiative'), featuredOnly: false, stages: ['active', 'ongoing'], hasPhoto: true, limit: 12 }
  assert.deepEqual(ids(applyRules(recs, r)).sort(), ['akuse', 'supply'])
})

check('orders: newest start date; ending soonest (no end date last)', () => {
  const all = { ...defaultRules('initiative'), featuredOnly: false, limit: 12 }
  assert.deepEqual(ids(applyRules(recs, { ...all, order: 'newest' })), ['clinic', 'supply', 'akuse', 'grants'])
  assert.deepEqual(ids(applyRules(recs, { ...all, order: 'end-date' })), ['supply', 'clinic', 'akuse', 'grants'])
})

check('limit is honoured; input never mutated', () => {
  const before = ids(recs).join()
  assert.equal(applyRules(recs, { ...defaultRules('initiative'), featuredOnly: false, limit: 1 }).length, 1)
  assert.equal(ids(recs).join(), before)
})

check('parse: JSON round-trip, clamps, unknown stages dropped, junk rejected', () => {
  const r = { ...defaultRules('initiative'), stages: ['active'], limit: 4, order: 'end-date' as const }
  assert.deepEqual(parseRules(serializeRules(r)), r)
  const clamped = parseRules({ type: 'initiative', limit: 99, stages: ['active', 'paused', 'active'], order: 'random', show: { photo: false, nope: true } }, ['active', 'ongoing', 'completed'])!
  assert.equal(clamped.limit, 12)
  assert.deepEqual(clamped.stages, ['active'])
  assert.equal(clamped.order, 'home-order')
  assert.equal(clamped.show.photo, false)
  assert.equal(clamped.show.summary, true)
  assert.ok(!('nope' in clamped.show))
  for (const bad of ['', '{', '[]', 'null', { type: 'Bad Type!' }, 42, null]) assert.equal(parseRules(bad), null)
})

check('explained in one plain sentence', () => {
  const s = explainRules({ ...defaultRules('initiative'), stages: ['active', 'ongoing'], hasPhoto: true }, { plural: 'Initiatives', stage: (x) => x[0].toUpperCase() + x.slice(1) })
  assert.equal(s, 'Live initiatives that are Active or Ongoing, featured on the home page, with a photo — home page order, up to 3. Hidden when none match.')
})

check('explained without stages', () => {
  assert.equal(explainRules(defaultRules('initiative'), { plural: 'Initiatives' }), 'Live initiatives featured on the home page — home page order, up to 3. Hidden when none match.')
})

console.log(`\n${n} checks passed`)
