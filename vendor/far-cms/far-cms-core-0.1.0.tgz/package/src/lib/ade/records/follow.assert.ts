/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/follow.assert.ts
 */
import assert from 'node:assert/strict'
import { followingBlocks, followStates, storyInserts } from './follow'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const live = { goal: 'Build a  clinic.', progress: 'Seed stage.', beneficiaries: 'Residents', name: 'Clinic' }
const content = {
  version: '2.0',
  blocks: [
    { id: 'hdr', componentName: 'InitiativeHeader', attrs: { 'data-record': 'initiative:r1' } },
    { id: 'name-bound', tag: 'h1', textContent: 'Clinic', attrs: { 'data-record': 'initiative:r1', 'data-field': 'name' } },
    {
      id: 'story',
      children: [
        { id: 'h-goal', tag: 'h2', textContent: 'Our goal' },
        { id: 'p-goal', tag: 'p', textContent: 'Build a clinic.' },
        { id: 'p-progress', tag: 'p', textContent: 'Rewritten on the page by hand.' },
      ],
    },
  ],
}

check('a changed fact updates the page paragraph that still says the same', () => {
  assert.deepEqual(followingBlocks(content, live, { goal: 'Build and equip a clinic.' }, ['goal', 'progress']), [
    { blockId: 'p-goal', field: 'goal', text: 'Build and equip a clinic.' },
  ])
})

check('a paragraph rewritten on the page is left alone', () => {
  assert.deepEqual(followingBlocks(content, live, { progress: 'Walls are up.' }, ['goal', 'progress']), [])
})

check('bound blocks and unlisted fields never follow (they read the record already)', () => {
  assert.deepEqual(followingBlocks(content, live, { name: 'New clinic' }, ['name']), [])
  assert.deepEqual(followingBlocks(content, live, { goal: 'x' }, ['progress']), [])
})

check('clearing or not changing a fact proposes nothing', () => {
  assert.deepEqual(followingBlocks(content, live, { goal: '' }, ['goal']), [])
  assert.deepEqual(followingBlocks(content, live, { goal: 'Build a clinic.' }, ['goal']), [])
})

check('follow states per story field', () => {
  assert.deepEqual(followStates(content, { ...live, beneficiaries: '' }, ['goal', 'progress', 'beneficiaries']), { goal: 'follows', progress: 'differs', beneficiaries: 'absent' })
  assert.deepEqual(followStates(null, live, ['goal']), { goal: 'differs' })
})

check('filling an empty story section inserts its paragraph after the template heading', () => {
  const template = [
    { tag: 'section', label: 'Story', children: [{ tag: 'div', className: 'col', children: [
      { tag: 'h2', textContent: 'Our goal' }, { tag: 'p', className: 'para', textContent: '{{goal}}' },
      { tag: 'h2', textContent: 'Progress so far' }, { tag: 'p', textContent: '{{progress}}' },
      { tag: 'h2', textContent: 'Who it helps' }, { tag: 'p', textContent: '{{beneficiaries}}' },
    ] }] },
  ]
  const page = { blocks: [{ id: 's', children: [{ id: 'col', children: [
    { id: 'h1', textContent: 'Our goal' }, { id: 'g', textContent: 'Build it.' },
    { id: 'h2', textContent: 'Progress so far' },
    { id: 'h3', textContent: 'Who it helps' },
  ] }] }] }
  const live = { goal: 'Build it.', progress: '', beneficiaries: '' }
  assert.deepEqual(storyInserts(page, template, live, { progress: 'Walls up.' }, ['goal', 'progress', 'beneficiaries']), [
    { field: 'progress', parentBlockId: 'col', index: 3, tag: 'p', className: '', text: 'Walls up.' },
  ])
  // A field that already had text is a follow, not an insert; a missing heading inserts nothing.
  assert.deepEqual(storyInserts(page, template, live, { goal: 'New' }, ['goal']), [])
  assert.deepEqual(storyInserts({ blocks: [] }, template, live, { progress: 'x' }, ['progress']), [])
})

console.log(`\n${n} checks passed`)
