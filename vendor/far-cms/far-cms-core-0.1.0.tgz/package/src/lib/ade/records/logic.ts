/**
 * ADE records — pure logic, asserted by records.assert.ts.
 */

import { sanitizeBlockTree } from '../../block-editor/content-safety'
import type { Block } from '../../block-editor/types'
import { cleanAddedBlocks, pageBlocksTooBig } from './page-blocks'
import {
  BIND_ATTR,
  FIELD_ATTR,
  OVERRIDES_ATTR,
  SELF_REF,
  type FieldDef,
  type RecordData,
  type RecordRef,
  type RecordTypeDef,
  type TemplateBlock,
} from './types'

// ---------------------------------------------------------------------------
// Refs, slugs, paths
// ---------------------------------------------------------------------------

export function recordRef(type: string, id: string): RecordRef {
  return `${type}:${id}` as RecordRef
}

export function parseRecordRef(ref: unknown): { type: string; id: string } | null {
  if (typeof ref !== 'string') return null
  const i = ref.indexOf(':')
  if (i <= 0 || i === ref.length - 1) return null
  return { type: ref.slice(0, i), id: ref.slice(i + 1) }
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/['’]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}

export function recordPath(def: Pick<RecordTypeDef, 'pathPrefix'>, slug: string): string {
  return `${def.pathPrefix.replace(/\/+$/, '')}/${slug}`
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

export interface ValidationResult {
  data: RecordData
  errors: Record<string, string>
}

function coerce(field: FieldDef, raw: unknown): { value?: unknown; error?: string } {
  if (raw === undefined || raw === null || raw === '') {
    return field.type === 'boolean' ? { value: false } : field.type === 'stats' || field.type === 'gallery' || field.type === 'blocks' ? { value: [] } : { value: field.type === 'number' ? null : '' }
  }
  switch (field.type) {
    case 'text':
    case 'longtext':
    case 'image':
    case 'url':
    case 'slug': {
      if (typeof raw !== 'string') return { error: 'must be text' }
      const v = field.type === 'slug' ? slugify(raw) : raw.trim()
      if (field.max && v.length > field.max) return { error: `must be at most ${field.max} characters` }
      if (field.type === 'url' && v && !/^https?:\/\//i.test(v) && !v.startsWith('/')) return { error: 'must be a link' }
      return { value: v }
    }
    case 'enum': {
      const ok = field.options?.some((o) => o.value === raw)
      return ok ? { value: raw } : { error: `must be one of ${field.options?.map((o) => o.value).join(', ')}` }
    }
    case 'date': {
      if (typeof raw !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(raw) || Number.isNaN(Date.parse(raw))) {
        return { error: 'must be a date (YYYY-MM-DD)' }
      }
      return { value: raw }
    }
    case 'boolean':
      return typeof raw === 'boolean' ? { value: raw } : raw === 'true' || raw === 'false' ? { value: raw === 'true' } : { error: 'must be yes or no' }
    case 'number': {
      const n = typeof raw === 'number' ? raw : Number(raw)
      return Number.isFinite(n) ? { value: n } : { error: 'must be a number' }
    }
    case 'gallery': {
      if (!Array.isArray(raw)) return { error: 'must be a list of photos' }
      const urls = raw.filter((u): u is string => typeof u === 'string').map((u) => u.trim()).filter((u) => /^https?:\/\//i.test(u) || u.startsWith('/'))
      if (urls.length !== raw.length) return { error: 'must be photos from the Media library' }
      if (field.max && urls.length > field.max) return { error: `at most ${field.max} photos` }
      return { value: [...new Set(urls)] }
    }
    case 'blocks': {
      // Sections added from the block library: real block trees, sanitized like any page content.
      if (!Array.isArray(raw) || !raw.every((b) => !!b && typeof b === 'object' && typeof (b as { id?: unknown }).id === 'string' && typeof (b as { tag?: unknown }).tag === 'string')) return { error: 'must be blocks' }
      if (raw.length > (field.max ?? 12)) return { error: `at most ${field.max ?? 12} sections` }
      if (pageBlocksTooBig(raw as Block[])) return { error: 'too large — remove a section' }
      return { value: cleanAddedBlocks(sanitizeBlockTree(raw as Block[])) }
    }
    case 'stats': {
      if (!Array.isArray(raw)) return { error: 'must be a list' }
      const stats = raw
        .filter((s): s is Record<string, unknown> => !!s && typeof s === 'object')
        .map((s) => ({ value: String(s.value ?? '').trim(), label: String(s.label ?? '').trim() }))
        .filter((s) => s.value || s.label)
      if (field.max && stats.length > field.max) return { error: `at most ${field.max} items` }
      return { value: stats }
    }
  }
}

/**
 * Validate + normalise record data against its type. `partial` validates
 * only the keys present (an update); otherwise required fields are enforced
 * and missing fields take their defaults. Unknown keys are dropped.
 */
export function validateRecord(def: RecordTypeDef, input: RecordData, opts: { partial?: boolean } = {}): ValidationResult {
  const data: RecordData = {}
  const errors: Record<string, string> = {}
  for (const field of def.fields) {
    const present = Object.hasOwn(input, field.key)
    if (!present && opts.partial) continue
    const raw = present ? input[field.key] : field.default
    const { value, error } = coerce(field, raw)
    if (error) {
      errors[field.key] = `${field.label} ${error}`
      continue
    }
    if (field.required && (value === '' || value === null || (Array.isArray(value) && value.length === 0))) {
      errors[field.key] = `${field.label} is required`
      continue
    }
    data[field.key] = value
  }
  if (!opts.partial && !data[def.slugField] && typeof data[def.titleField] === 'string') {
    data[def.slugField] = slugify(data[def.titleField] as string)
  }
  return { data, errors }
}

export function titleOf(def: RecordTypeDef, data: RecordData): string {
  const t = data[def.titleField]
  return typeof t === 'string' && t ? t : def.label
}

// ---------------------------------------------------------------------------
// Page templates
// ---------------------------------------------------------------------------

export interface InstantiatedBlock {
  id: string
  tag: string
  className: string
  textContent?: string
  attrs?: Record<string, string>
  componentName?: string
  label?: string
  children?: InstantiatedBlock[]
}

function fill(text: string, data: RecordData): string {
  return text.replace(/\{\{(\w+)\}\}/g, (_m, key: string) => {
    const v = data[key]
    return typeof v === 'string' || typeof v === 'number' ? String(v) : ''
  })
}

/**
 * Build the record's page blocks from its type template: binds `$record` to
 * this record, fills `{{field}}` text (the first-draft story), gives every
 * block a fresh id, and drops text blocks that came out empty.
 */
export function instantiateTemplate(
  template: ReadonlyArray<TemplateBlock>,
  ref: RecordRef,
  data: RecordData,
  newId: () => string
): InstantiatedBlock[] {
  const out: InstantiatedBlock[] = []
  for (const t of template) {
    const attrs = t.attrs
      ? Object.fromEntries(Object.entries(t.attrs).map(([k, v]) => [k, v === SELF_REF ? ref : fill(v, data)]))
      : undefined
    const text = t.textContent !== undefined ? fill(t.textContent, data).trim() : undefined
    if (text === '' && !t.componentName && !t.children?.length) continue
    const id = newId()
    const children = t.children ? instantiateTemplate(t.children, ref, data, newId) : undefined
    out.push({
      id,
      tag: t.tag,
      className: t.className ?? '',
      ...(text !== undefined ? { textContent: text } : {}),
      ...(attrs ? { attrs } : {}),
      ...(t.componentName ? { componentName: t.componentName } : {}),
      ...(t.label ? { label: t.label } : {}),
      ...(children ? { children } : {}),
    })
  }
  return out
}

// ---------------------------------------------------------------------------
// Placements (bound blocks) + overrides
// ---------------------------------------------------------------------------

interface AnyBlock {
  id?: string
  componentName?: string
  label?: string
  attrs?: Record<string, string>
  children?: AnyBlock[]
}

export function readOverrides(attrs: Record<string, string> | undefined): Record<string, unknown> {
  const raw = attrs?.[OVERRIDES_ATTR]
  if (!raw) return {}
  try {
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : {}
  } catch {
    return {}
  }
}

/** The value a placement shows for a field: its override, else the record's. */
export function resolveBound(
  data: RecordData | null | undefined,
  field: string,
  overrides: Record<string, unknown>
): { value: unknown; overridden: boolean } {
  if (Object.hasOwn(overrides, field)) return { value: overrides[field], overridden: true }
  return { value: data?.[field], overridden: false }
}

/** Set (value) or clear (null) a per-placement override on one block — returns a new document. */
export function setOverride(content: unknown, blockId: string, field: string, value: unknown): { content: unknown } | { error: string } {
  const doc = structuredClone((content ?? {}) as { blocks?: AnyBlock[] })
  let found: AnyBlock | null = null
  const walk = (blocks: AnyBlock[] | undefined) => {
    for (const b of blocks ?? []) {
      if (found) return
      if (b.id === blockId) found = b
      else walk(b.children)
    }
  }
  walk(doc.blocks)
  if (!found) return { error: `Block not found: ${blockId}` }
  const block = found as AnyBlock
  if (!block.attrs?.[BIND_ATTR]) return { error: 'That block is not bound to a record.' }
  const overrides = readOverrides(block.attrs)
  if (value === null || value === undefined) delete overrides[field]
  else overrides[field] = value
  const attrs = { ...block.attrs }
  if (Object.keys(overrides).length) attrs[OVERRIDES_ATTR] = JSON.stringify(overrides)
  else delete attrs[OVERRIDES_ATTR]
  block.attrs = attrs
  return { content: doc }
}

export interface Placement {
  docId: string
  docTitle: string
  docPath: string | null
  blockId: string
  componentName: string | null
  label: string | null
  /** The single field this block shows (RecordField), when it shows one. */
  field: string | null
  overrides: Record<string, unknown>
}

/** Every block in `docs` bound to `ref` (one source of truth → where it shows). */
export function findPlacements(
  docs: ReadonlyArray<{ id: string; title: string; path: string | null; content: unknown }>,
  ref: string
): Placement[] {
  const out: Placement[] = []
  for (const doc of docs) {
    const walk = (blocks: AnyBlock[] | undefined) => {
      for (const b of blocks ?? []) {
        if (b.attrs?.[BIND_ATTR] === ref && b.id) {
          out.push({
            docId: doc.id,
            docTitle: doc.title,
            docPath: doc.path,
            blockId: b.id,
            componentName: b.componentName ?? null,
            label: b.label ?? null,
            field: b.attrs?.[FIELD_ATTR] ?? null,
            overrides: readOverrides(b.attrs),
          })
        }
        walk(b.children)
      }
    }
    walk((doc.content as { blocks?: AnyBlock[] } | null)?.blocks)
  }
  return out
}

/** Find one block and, if it is a single-field placement, its binding. */
export function boundFieldAt(content: unknown, blockId: string): { ref: string; field: string } | null {
  let hit: AnyBlock | null = null
  const walk = (blocks: AnyBlock[] | undefined) => {
    for (const b of blocks ?? []) {
      if (hit) return
      if (b.id === blockId) hit = b
      else walk(b.children)
    }
  }
  walk((content as { blocks?: AnyBlock[] } | null)?.blocks)
  const block = hit as AnyBlock | null
  const ref = block?.attrs?.[BIND_ATTR]
  const field = block?.attrs?.[FIELD_ATTR]
  return ref && field ? { ref, field } : null
}

// ---------------------------------------------------------------------------
// Events (design for the planned rules engine — not wired to the bus yet)
// ---------------------------------------------------------------------------

export type RecordEvent =
  | { type: 'record.created'; recordType: string }
  | { type: 'record.published' | 'record.unpublished'; recordType: string }
  | { type: 'field.changed'; recordType: string; field: string; from: unknown; to: unknown }
  | { type: 'date.reached'; recordType: string; field: string; date: string }

/** Events a record change emits (created, publish state, watched field changes). */
export function diffEvents(
  def: RecordTypeDef,
  before: { status: string; data: RecordData } | null,
  after: { status: string; data: RecordData }
): RecordEvent[] {
  const events: RecordEvent[] = []
  if (!before) events.push({ type: 'record.created', recordType: def.key })
  const wasLive = before?.status === 'PUBLISHED'
  const isLive = after.status === 'PUBLISHED'
  if (!wasLive && isLive) events.push({ type: 'record.published', recordType: def.key })
  if (wasLive && !isLive) events.push({ type: 'record.unpublished', recordType: def.key })
  for (const field of def.eventFields ?? []) {
    const from = before?.data[field]
    const to = after.data[field]
    if (before && JSON.stringify(from) !== JSON.stringify(to)) {
      events.push({ type: 'field.changed', recordType: def.key, field, from, to })
    }
  }
  return events
}

/** Date events due between `since` (exclusive) and `now` (inclusive) — for a scheduler. */
export function dueDateEvents(def: RecordTypeDef, data: RecordData, since: Date, now: Date): RecordEvent[] {
  const out: RecordEvent[] = []
  for (const field of def.dateEventFields ?? []) {
    const v = data[field]
    if (typeof v !== 'string' || !v) continue
    const at = Date.parse(`${v}T00:00:00Z`)
    if (at > since.getTime() && at <= now.getTime()) out.push({ type: 'date.reached', recordType: def.key, field, date: v })
  }
  return out
}
