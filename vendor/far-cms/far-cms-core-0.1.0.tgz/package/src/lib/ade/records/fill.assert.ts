/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/fill.assert.ts
 */
import assert from 'node:assert/strict'
import { FILL_NOW_LINE, FILL_COPY, FILL_LIMITS, RECORD_SCREEN_RULE, coerceFillArgs, endsAtFill, fillResultLine, framesFor, readbackMatches, invalidChoicesIn, normalizeFillKeys, selectionOnlyCall, selectionTurnField, toIsoDate, applySelectionEdit, fillAskForm, isSelectionAction, recordTurn, fillOrder, fillReport, fillSteps, markAssistant, markAssistantKept, markPersonEdit, markView, pageFieldKeys, parseFillArg, planFill, typingFrames, type FillMarks } from './fill'
import { initiativeType } from '../../ade-bindings/record-types/initiative'
import { RECORD_FILL_BOUND_PARTS as BOUND, RECORD_FILL_NAMES, RECORD_WRITE_TOOLS } from '../../ade-bindings/record-fill'
import { isChangeRequest, planToForce, runStyle } from '../chat/plan'
import { parseAskInput } from '../chat/ask-form'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const def = initiativeType

check('order: the banner first (name, summary, location), then the story, then the Details drawer', () => {
  const page = pageFieldKeys(def, BOUND)
  assert.deepEqual(page.slice(0, 4), ['name', 'summary', 'location', 'heroImageUrl'])
  assert.ok(page.includes('goal') && page.includes('progress') && page.includes('beneficiaries'), 'the story text')
  const order = fillOrder(def, BOUND)
  assert.equal(order.find((o) => o.field.key === 'stage')!.where, 'details')
  assert.equal(order.find((o) => o.field.key === 'name')!.where, 'page')
  assert.ok(order.findIndex((o) => o.field.key === 'beneficiaries') < order.findIndex((o) => o.field.key === 'startDate'))
})

check('the model supplies values; code decides what is typed where, skipping what is already there', () => {
  const plan = planFill(def, { name: 'Clinic visit in Ho', slug: 'clinic-visit-in-ho' }, {
    name: 'Clinic visit in Ho', summary: 'A community clinic outreach in the Volta Region', location: 'Ho, Volta Region', stage: 'Active', startDate: '2026-11-02',
  }, { boundParts: BOUND })
  assert.deepEqual(plan.moves.map((m) => [m.key, m.where]), [['summary', 'page'], ['location', 'page'], ['stage', 'details'], ['startDate', 'details']])
  assert.equal(plan.moves.find((m) => m.key === 'stage')!.value, 'active', 'the label becomes the page’s own option value')
  assert.ok(!plan.moves.some((m) => m.key === 'slug'), 'the web address is the page’s job')
})

check('never an option the page does not have; never a typed photo; unknown fields are refused', () => {
  const plan = planFill(def, {}, { stage: 'Paused', heroImageUrl: 'https://example.com/x.jpg', colour: 'blue', startDate: '2026-02-30' }, { boundParts: BOUND })
  assert.equal(plan.moves.length, 0)
  const why = Object.fromEntries(plan.rejected.map((r) => [r.key, r.reason]))
  assert.match(why.stage, /not one of active, ongoing, completed/)
  assert.equal(why.heroImageUrl, 'choose it from the media library')
  assert.equal(why.colour, 'not a field of this type')
  assert.match(why.startDate, /not a real date/)
})

check('missing required facts become questions with the page’s real options (R7), never invented', () => {
  const plan = planFill(def, {}, { summary: 'A clinic visit' }, { boundParts: BOUND })
  assert.deepEqual(plan.ask.map((q) => [q.key, q.type]), [['name', 'text']])
  // A required enum gets the page's own options.
  const withEnum = planFill({ ...def, fields: def.fields.map((f) => (f.key === 'stage' ? { ...f, required: true } : f)) }, {}, {}, { boundParts: BOUND })
  const stage = withEnum.ask.find((q) => q.key === 'stage')!
  assert.deepEqual(stage.options.map((o) => o.value), def.fields.find((f) => f.key === 'stage')!.options!.map((o) => o.value))
  assert.match(fillReport(withEnum), /ask with ask_user, using only these options: .*Stage \[Active \/ Ongoing \/ Completed\]/)
})

check('an edit to an existing record keeps what it replaced ("was: …")', () => {
  const plan = planFill(def, { name: 'Old clinic', summary: 'Old words' }, { summary: 'New words' }, { boundParts: BOUND })
  assert.deepEqual(plan.moves.map((m) => [m.key, m.was]), [['summary', 'Old words']])
})

check('marks: Kofi → You edited only on fields Kofi filled; "was" shown only when there was a value', () => {
  let m: FillMarks = {}
  m = markAssistant(m, 'name', '')
  m = markAssistant(m, 'summary', 'Old words')
  assert.deepEqual(markView(m.name, RECORD_FILL_NAMES), { badge: 'Kofi', was: null })
  assert.deepEqual(markView(m.summary, RECORD_FILL_NAMES), { badge: 'Kofi', was: 'was: Old words' })
  assert.deepEqual(markView(m.name), { badge: 'Assistant', was: null }, 'core is neutral; the app names its assistant')
  m = markPersonEdit(m, 'summary')
  assert.deepEqual(markView(m.summary), { badge: 'You edited', was: 'was: Old words' })
  assert.equal(markPersonEdit(m, 'location'), m, 'a field Kofi never touched gets no mark')
  // Filling again keeps the original "was".
  assert.equal(markAssistant(m, 'summary', 'New words').summary.was, 'Old words')
  assert.equal(FILL_COPY.legendNote, 'Edit anything. Nothing is saved until you propose it.')
})

check('plan steps match the fields being filled, ending with the page’s own Propose (R11)', () => {
  const plan = planFill(def, {}, { name: 'Clinic visit in Ho', location: 'Ho' }, { boundParts: BOUND })
  assert.deepEqual(fillSteps(plan), ['Fill “Name”', 'Fill “Location”', 'Propose it for review'])
})

check('the argument is untrusted JSON, capped', () => {
  assert.deepEqual(parseFillArg('{"name":"X"}'), { name: 'X' })
  assert.equal(parseFillArg('[1]'), null)
  assert.equal(parseFillArg('not json'), null)
  assert.equal(parseFillArg('x'.repeat(7000)), null)
})

check('typing frames grow to the value; non-text lands at once', () => {
  assert.deepEqual(typingFrames('Ho, Volta', 3), ['Ho,', 'Ho, Vo', 'Ho, Volta'])
  assert.deepEqual(typingFrames(3000), [3000])
  assert.deepEqual(typingFrames('ab'), ['ab'])
})

check('the report never claims a save and names what to ask', () => {
  const r = fillReport(planFill(def, {}, { name: 'Clinic visit' }, { boundParts: BOUND }))
  assert.match(r, /^Filled Name on the page — not saved; the person proposes it with the page's own button\./)
  assert.doesNotMatch(r, /saved it|published|is live/i)
})

const FILL_THIS = 'Fill this in: Clinic visit in Ho, a community clinic outreach in the Volta Region, in Ho, stage active, starts 2026-11-02'
const turn = (o: Partial<Parameters<typeof recordTurn>[0]>) => recordTurn({ onRecord: true, text: FILL_THIS, selection: null, forcedPlan: null, changeRequest: true, writeTools: RECORD_WRITE_TOOLS, screenTool: 'operate_ui', planTool: 'update_plan', ...o })

check('"Fill this in: …" runs ON THE FLY: no plan, straight into the page (record.fill) — the old write tools are gone', () => {
  assert.equal(runStyle(FILL_THIS), 'fly', 'playbook 11 CLARIFIED: "fill this in" executes on the fly')
  assert.equal(planToForce({ text: FILL_THIS, plan: null, newTurn: true }), null)
  const t = turn({})
  assert.deepEqual(t.hide, ['updateRecord', 'createRecordWithPage', 'publishRecord', 'archiveRecord'], 'no updateRecord / createRecordWithPage for the open record')
  assert.deepEqual(t.steps, { 0: 'operate_ui' }, 'step 0 = the page’s own fill')
  assert.equal(t.planned, false)
  assert.ok(t.lines.includes(RECORD_SCREEN_RULE))
  assert.match(t.lines[1], /one operate_ui record\.fill with every field you have facts for/)
  assert.match(RECORD_SCREEN_RULE, /ONLY with operate_ui record\.fill/)
  assert.deepEqual(recordTurn({ onRecord: false, text: FILL_THIS, selection: null, forcedPlan: null, writeTools: RECORD_WRITE_TOOLS, screenTool: 'operate_ui', planTool: 'update_plan' }).hide, [], 'other screens keep their tools')
})

check('each phrasing on the record page: plan request waits; Go plans then fills; just do it fills; a question does nothing', () => {
  // "Plan it out first" → show the plan only (the turn ends; nothing typed, nothing saved).
  const plan = turn({ text: 'Plan it out first: fill in the clinic visit', forcedPlan: planToForce({ text: 'Plan it out first: fill in the clinic visit', plan: null, newTurn: true }) })
  assert.deepEqual(plan.steps, { 0: 'update_plan' })
  // "Go" → the plan, then the page's fill.
  assert.deepEqual(turn({ text: 'Go', forcedPlan: 'go', changeRequest: false }).steps, { 0: 'update_plan', 1: 'operate_ui' })
  // "just do it" → straight to the page.
  assert.equal(planToForce({ text: 'Just do it: Clinic visit in Ho, active', plan: null, newTurn: true }), null)
  assert.deepEqual(turn({ text: 'Just do it: Clinic visit in Ho, active' }).steps, { 0: 'operate_ui' })
  // No signal, small → on the fly; no signal, risky → a short plan first.
  assert.deepEqual(turn({ text: 'change the summary to: A clinic visit' }).steps, { 0: 'operate_ui' })
  assert.equal(planToForce({ text: 'publish this initiative', plan: null, newTurn: true }), 'propose')
  // A question: nothing forced, still no write tools.
  const q = turn({ text: 'what is left before it can go live?', changeRequest: false })
  assert.deepEqual(q.steps, {})
  assert.deepEqual(q.hide, ['updateRecord', 'createRecordWithPage', 'publishRecord', 'archiveRecord'])
})

check('staging PARTIAL 5: an option the page lacks becomes the question form with the page’s options — from code', () => {
  const plan = planFill(def, {}, { stage: 'paused' }, { boundParts: BOUND })
  const form = fillAskForm(plan)!
  const stage = form.questions.find((q) => q.id === 'stage')!
  assert.equal(stage.type, 'single')
  assert.deepEqual(stage.options.map((o) => o.value), ['active', 'ongoing', 'completed'])
  assert.equal(parseAskInput(form).ok, true, 'a valid form for the chat’s own question widget')
  assert.equal(fillAskForm(planFill(def, { name: 'X' }, { summary: 'Y' }, { boundParts: BOUND })), null, 'nothing needed, no form')
  // The answers go straight back into the page.
  assert.deepEqual(turn({ text: 'My answers:\n- Stage: Active', forcedPlan: null, answers: true }).steps, { 0: 'operate_ui' })
})

check('staging FAIL 6: a selected-text edit fills that field through record.fill, replacing just the selection', () => {
  assert.ok(isSelectionAction('make this shorter'))
  assert.ok(isSelectionAction('fix the grammar'))
  assert.ok(!isSelectionAction('what does this field do?'))
  const t = turn({ text: 'make this shorter', selection: { text: 'A community clinic outreach in the Volta Region', fieldKey: 'summary', fieldLabel: 'One-line summary' }, forcedPlan: 'propose' })
  assert.deepEqual(t.steps, { 0: 'operate_ui' }, 'straight to the page, no plan')
  assert.equal(t.planned, false)
  assert.match(t.lines[1], /operate_ui record\.fill with fields \{"summary": "<the rewritten selection>"\} and replaceSelection: true/)
  assert.equal(applySelectionEdit('Ho clinic. A community clinic outreach in the Volta Region.', 'A community clinic outreach in the Volta Region', 'A Volta clinic outreach'), 'Ho clinic. A Volta clinic outreach.')
  assert.equal(applySelectionEdit('Whole text', 'Whole text', 'Short'), 'Short')
  assert.equal(applySelectionEdit('Other', 'missing', 'New'), 'New')
})

check('C11 commit boundary: on the record page the agent points at Propose / Approve / Publish and never presses them', () => {
  assert.ok((RECORD_WRITE_TOOLS as readonly string[]).includes('publishRecord'), 'no publish tool while the page is open')
  assert.match(RECORD_SCREEN_RULE, /point at the page's own button \(spotlight_steps\) and say what it will do — never press it/)
})

check('c6c4 F2: "set the stage to paused" — code finds the bad choice in the words and forces the question form first', () => {
  const bad = invalidChoicesIn(def, 'set the stage to paused')
  assert.deepEqual(bad.map((b) => [b.key, b.value]), [['stage', 'paused']])
  assert.deepEqual(bad[0].options.map((o) => o.value), ['active', 'ongoing', 'completed'])
  assert.deepEqual(invalidChoicesIn(def, 'set the stage to ongoing'), [], 'a real option is fine')
  assert.deepEqual(invalidChoicesIn(def, 'Stage: Completed'), [])
  assert.ok(isChangeRequest('set the stage to paused'), '"set" is a change word now')
  const t = turn({ text: 'set the stage to paused', invalid: bad })
  assert.deepEqual(t.steps, { 0: 'ask_user' }, 'the question form, forced, before anything changes')
  assert.match(t.lines[1], /“paused” isn’t a stage this page offers\. Do not change it\. Ask with ask_user \(single choice\) using ONLY these options: Stage: Active \/ Ongoing \/ Completed/)
  // And if a bad value ever reaches the page anyway, the fill refuses it and code shows the form (fillAskForm, above).
})

check('c6c4 F4: "starts 2026-11-02" fills the Details start date — keys by label/alias, dates in any common form, set at once', () => {
  assert.deepEqual(normalizeFillKeys(def, { 'Start date': 'x', starts: 'y', title: 'Ho', 'One-line summary': 's' }), { startDate: 'x', name: 'Ho', summary: 's' })
  for (const [inp, out] of [['2026-11-02', '2026-11-02'], ['11/02/2026', '2026-11-02'], ['November 2, 2026', '2026-11-02'], ['2 Nov 2026', '2026-11-02'], ['Nov 2nd 2026', '2026-11-02']] as const) assert.equal(toIsoDate(inp), out, inp)
  assert.equal(toIsoDate('soon'), null)
  const plan = planFill(def, {}, { starts: 'November 2, 2026', name: 'Clinic visit in Ho' }, { boundParts: BOUND })
  const sd = plan.moves.find((m) => m.key === 'startDate')!
  assert.deepEqual([sd.value, sd.where, sd.type], ['2026-11-02', 'details', 'date'], 'into the Details drawer, ISO, typed at once (not character by character)')
  assert.equal(plan.moves.find((m) => m.key === 'name')!.type, 'text')
  assert.ok(planFill(def, {}, { startDate: '2026-02-30' }, { boundParts: BOUND }).rejected.some((r) => r.key === 'startDate'), 'an impossible date is refused')
  // The fill is told the record's own keys and shapes.
  assert.match(turn({ fieldsLine: '[Fields] record.fill keys and shapes:\n- startDate (date YYYY-MM-DD)' }).lines.join('\n'), /startDate \(date YYYY-MM-DD\)/)
})

check('c6c4 F3: a selection turn changes ONLY the selected field — enforced on the record.fill call itself', () => {
  const sel = { text: 'community clinic outreach', fieldKey: 'summary' }
  assert.equal(selectionTurnField({ onRecord: true, text: 'make this shorter', selection: sel }), 'summary')
  assert.equal(selectionTurnField({ onRecord: true, text: 'what is this?', selection: sel }), null)
  assert.equal(selectionTurnField({ onRecord: false, text: 'make this shorter', selection: sel }), null)
  const ok = selectionOnlyCall({ capability: 'record.fill', args: { fields: JSON.stringify({ summary: 'clinic outreach', stage: 'ongoing' }) } }, 'summary')
  assert.ok(ok.ok)
  assert.deepEqual(ok.ok && JSON.parse(ok.args.fields as string), { summary: 'clinic outreach' }, 'the stray stage change is dropped')
  assert.equal(ok.ok && ok.args.replaceSelection, true)
  assert.equal(selectionOnlyCall({ capability: 'record.set_stage', args: { stage: 'ongoing' } }, 'summary').ok, false, 'no other capability in a selection turn')
  assert.equal(selectionOnlyCall({ capability: 'record.fill', args: { fields: '{"stage":"ongoing"}' } }, 'summary').ok, false, 'must change the selected field')
})

check('C25: the reply comes from the read-back — a field that did not take is never claimed', () => {
  const line = fillResultLine([
    { key: 'name', label: 'Name', intended: 'Clinic visit in Ho', found: 'Clinic visit in Ho', ok: true },
    { key: 'startDate', label: 'Start date', intended: '2026-11-02', found: '', ok: false, why: 'the field did not show it' },
  ])
  assert.match(line, /^Filled Name on the page — not saved until you propose it\./)
  assert.match(line, /Start date did not take \(the field did not show it\)\. You can type it there yourself\./)
  assert.doesNotMatch(line, /Filled [^.]*Start date/, 'never claims the date')
  assert.equal(fillResultLine([{ key: 'name', label: 'Name', intended: 'X', found: 'Name this initiative…', ok: false }]), 'Name did not take; it still shows “Name this initiative…”. You can type it there yourself.')
  // What counts as "the page shows it".
  assert.ok(readbackMatches('Clinic  visit in Ho', ' clinic visit in ho '))
  assert.ok(readbackMatches('active', 'Active', ['Active']), 'a choice by its label')
  assert.ok(readbackMatches(3000, '3000'))
  assert.ok(readbackMatches('2026-11-02', '2026-11-02'), 'a date input holds ISO')
  assert.ok(!readbackMatches('Clinic visit', 'Name this initiative…'))
})

check('severity-1 hang: every part of a fill is bounded (renders per field, fields, time, waits)', () => {
  assert.ok(framesFor('x'.repeat(2000), 'longtext', false).length <= FILL_LIMITS.maxFrames, 'a long text renders at most maxFrames times')
  assert.deepEqual(framesFor('2026-11-02', 'date', false), ['2026-11-02'], 'a date lands at once')
  assert.deepEqual(framesFor('Ho', 'text', true), ['Ho'], 'reduced motion: at once')
  assert.ok(FILL_LIMITS.maxFields > 0 && FILL_LIMITS.runMs <= 30_000 && FILL_LIMITS.readbackTries <= 10 && FILL_LIMITS.revealMs <= 3_000)
})

check('C5/C30: fields given as an object are accepted (not refused); the run ends at the fill so the page reports', () => {
  assert.deepEqual(coerceFillArgs({ fields: { name: 'Ho' } }), { fields: '{"name":"Ho"}' })
  assert.deepEqual(coerceFillArgs({ fields: '{"name":"Ho"}' }), { fields: '{"name":"Ho"}' })
  assert.ok(endsAtFill([{ toolName: 'update_plan' }, { toolName: 'operate_ui', input: { capability: 'record.fill', args: {} } }]))
  assert.ok(!endsAtFill([{ toolName: 'operate_ui', input: { capability: 'record.open_details' } }]))
})

check('F1: after Go the fill gets the same instructions as "just do it" (keys + shapes, one call); odd shapes still parse', () => {
  const FIELDS = '[Fields] record.fill keys and shapes: name (text) …'
  const go = turn({ forcedPlan: 'go', changeRequest: false, fieldsLine: FIELDS })
  const now = turn({ forcedPlan: null, changeRequest: true, fieldsLine: FIELDS })
  assert.deepEqual(go.steps, { 0: 'update_plan', 1: 'operate_ui' }, 'the plan, then the page’s fill')
  assert.ok(go.lines.includes(FILL_NOW_LINE) && go.lines.includes(FIELDS), 'Go carries the fill line and the field keys')
  assert.deepEqual(go.lines.filter((l) => l !== RECORD_SCREEN_RULE), now.lines.filter((l) => l !== RECORD_SCREEN_RULE), 'identical to the on-the-fly fill')
  assert.deepEqual(turn({ forcedPlan: 'start', changeRequest: false, fieldsLine: FIELDS }).lines, go.lines)
  // Shapes models send for `fields`.
  assert.deepEqual(parseFillArg('{"fields":{"name":"Ho"}}'), { name: 'Ho' })
  assert.deepEqual(parseFillArg([{ key: 'name', value: 'Ho' }, { field: 'location', value: 'Volta' }]), { name: 'Ho', location: 'Volta' })
  assert.deepEqual(parseFillArg('[{"name":"summary","value":"A visit"}]'), { summary: 'A visit' })
  assert.equal(parseFillArg('not json'), null)
  // The exact string the model sent on staging (run c964ab3d): labels, "; " between pairs, commas inside values.
  const seen = 'Name: Clinic visit in Ho; One-line summary: a community clinic outreach in the Volta Region; Location: Ho, Volta Region'
  assert.deepEqual(normalizeFillKeys(initiativeType, parseFillArg(seen)!), { name: 'Clinic visit in Ho', summary: 'a community clinic outreach in the Volta Region', location: 'Ho, Volta Region' })
  assert.deepEqual(planFill(initiativeType, {}, parseFillArg(seen)!, { boundParts: BOUND }).moves.map((m) => m.key).sort(), ['location', 'name', 'summary'])
  assert.deepEqual(parseFillArg('Website: https://example.org/a\nName: Ho'), { Website: 'https://example.org/a', Name: 'Ho' }, 'split at the first colon only')
  // A plan step's title as the key.
  assert.deepEqual(normalizeFillKeys(initiativeType, { 'Fill “Name”': 'Ho', 'Fill “One-line summary”': 'S' }), { name: 'Ho', summary: 'S' })
})

check('F4: an answer the page already shows is still the assistant’s value (marked); the answers turn uses record.fill', () => {
  const plan = planFill(initiativeType, { stage: 'ongoing' }, { stage: 'ongoing', name: 'Ho' }, { boundParts: BOUND })
  assert.deepEqual(plan.moves.map((m) => m.key), ['name'], 'nothing to type for the stage')
  assert.deepEqual(plan.already?.map((a) => a.key), ['stage'], 'but it is listed to be marked')
  const m = markAssistantKept({}, 'stage')
  assert.equal(m.stage?.by, 'assistant')
  assert.equal(markAssistantKept({ stage: { by: 'you', was: '' } }, 'stage').stage?.by, 'you', 'the person’s own change stays theirs')
  const ans = turn({ answers: true, changeRequest: false })
  assert.deepEqual(ans.steps, { 0: 'operate_ui' })
  assert.match(ans.lines.join(' '), /record\.fill with every answered field \(choices like the stage too — not record\.set_stage\)/)
})

console.log(`\n${n} checks passed`)
