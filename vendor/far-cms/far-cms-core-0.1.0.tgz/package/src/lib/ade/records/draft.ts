/**
 * Draft a record from notes and photos — app-agnostic, driven entirely by
 * the record type's definition (never by a hard-coded field list), so a new
 * type (or BYB's product-like types) drafts the same way. Asserted by
 * draft.assert.ts.
 *
 *   draftSpec    which fields the agent may fill, and their shape (the model
 *                gets this as its schema/instructions)
 *   coerceDraft  keep only what fits the definition: known draftable fields,
 *                right types, enum values (or their labels), dates, lengths
 *   assignPhotos photos fill the type's image fields in order (cover first);
 *                the rest are returned for a gallery or the story
 *   missingItems what's still empty that matters ("No start date yet") —
 *                required fields block; quick-form fields are suggestions
 */

import type { FieldDef, FieldType, RecordData, RecordTypeDef } from './types'
import { slugify } from './logic'

/** Field types filled by the system or by photos, not drafted from notes. */
const NOT_DRAFTED: ReadonlySet<FieldType> = new Set(['slug', 'image', 'gallery', 'blocks'])

export interface DraftField {
  key: string
  label: string
  type: FieldType
  required: boolean
  options?: ReadonlyArray<{ value: string; label: string }>
  max?: number
  help?: string
}

/** The fields the agent may fill from notes, in the definition's order. */
export function draftSpec(def: RecordTypeDef): DraftField[] {
  return def.fields
    .filter((f) => !NOT_DRAFTED.has(f.type) && f.draftable !== false)
    .map((f) => ({ key: f.key, label: f.label, type: f.type, required: !!f.required, ...(f.options ? { options: f.options } : {}), ...(f.max ? { max: f.max } : {}), ...(f.help ? { help: f.help } : {}) }))
}

/** One line per field for the model ("startDate (date YYYY-MM-DD) — Start date"). */
export function draftInstructions(def: RecordTypeDef): string {
  return draftSpec(def)
    .map((f) => {
      const shape =
        f.type === 'enum' ? `one of ${f.options?.map((o) => o.value).join(' | ')}` :
        f.type === 'date' ? 'date YYYY-MM-DD' :
        f.type === 'stats' ? `list of {value, label}${f.max ? `, at most ${f.max}` : ''}` :
        f.type === 'boolean' ? 'true/false' :
        f.type === 'number' ? 'number' :
        f.type === 'url' ? 'a link (https://…)' :
        `${f.type === 'longtext' ? 'paragraph' : 'short text'}${f.max ? `, ≤ ${f.max} characters` : ''}`
      return `- ${f.key} (${shape})${f.required ? ' REQUIRED' : ''} — ${f.label}${f.help ? `. ${f.help}` : ''}`
    })
    .join('\n')
}

export interface CoercedDraft {
  data: RecordData
  /** Fields the model sent that don't fit, and why (never written). */
  dropped: Array<{ key: string; reason: string }>
}

function coerceOne(f: FieldDef, raw: unknown): { value?: unknown; reason?: string } {
  if (raw === undefined || raw === null || raw === '') return {}
  switch (f.type) {
    case 'text':
    case 'longtext': {
      if (typeof raw !== 'string') return { reason: 'not text' }
      const v = raw.trim().replace(/\s+\n/g, '\n')
      if (!v) return {}
      return { value: f.max && v.length > f.max ? `${v.slice(0, f.max - 1).trimEnd()}…` : v }
    }
    case 'url': {
      if (typeof raw !== 'string' || !/^https?:\/\/\S+$/i.test(raw.trim())) return { reason: 'not a link' }
      return { value: raw.trim() }
    }
    case 'enum': {
      const s = String(raw).trim().toLowerCase()
      const hit = f.options?.find((o) => o.value.toLowerCase() === s || o.label.toLowerCase() === s)
      return hit ? { value: hit.value } : { reason: `not one of ${f.options?.map((o) => o.value).join(', ')}` }
    }
    case 'date': {
      const s = String(raw).trim()
      const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s)
      if (!m || Number.isNaN(Date.parse(s)) || new Date(`${s}T00:00:00Z`).getUTCDate() !== Number(m[3])) return { reason: 'not a real date (YYYY-MM-DD)' }
      return { value: s }
    }
    case 'number': {
      if (typeof raw === 'number') return Number.isFinite(raw) ? { value: raw } : { reason: 'not a number' }
      // "$3,000", "GH₵ 12 500", "3k", "1.5m" — amounts as people type them.
      const m = /^[^\d-]*(-?[\d][\d,\s]*(?:\.\d+)?)\s*([km])?\b/i.exec(String(raw).trim())
      if (!m) return { reason: 'not a number' }
      const n = Number(m[1].replace(/[,\s]/g, '')) * (m[2]?.toLowerCase() === 'k' ? 1_000 : m[2]?.toLowerCase() === 'm' ? 1_000_000 : 1)
      return Number.isFinite(n) ? { value: n } : { reason: 'not a number' }
    }
    case 'boolean':
      return typeof raw === 'boolean' ? { value: raw } : { reason: 'not yes/no' }
    case 'stats': {
      if (!Array.isArray(raw)) return { reason: 'not a list' }
      const stats = raw
        .filter((s): s is Record<string, unknown> => !!s && typeof s === 'object')
        .map((s) => ({ value: String(s.value ?? '').trim().slice(0, 40), label: String(s.label ?? '').trim().slice(0, 80) }))
        .filter((s) => s.value && s.label)
        .slice(0, f.max ?? 4)
      return stats.length ? { value: stats } : {}
    }
    default:
      return { reason: 'filled another way' }
  }
}

/** Keep only what the definition allows; unknown or system fields are dropped with the reason. */
export function coerceDraft(def: RecordTypeDef, raw: Record<string, unknown>): CoercedDraft {
  const spec = new Map(draftSpec(def).map((f) => [f.key, f]))
  const byKey = new Map(def.fields.map((f) => [f.key, f]))
  const data: RecordData = {}
  const dropped: CoercedDraft['dropped'] = []
  for (const [key, value] of Object.entries(raw ?? {})) {
    if (!spec.has(key)) {
      if (value !== undefined && value !== null && value !== '') dropped.push({ key, reason: byKey.has(key) ? 'filled another way' : 'not a field of this type' })
      continue
    }
    const r = coerceOne(byKey.get(key)!, value)
    if (r.reason) dropped.push({ key, reason: r.reason })
    else if (r.value !== undefined) data[key] = r.value
  }
  // The address comes from the title.
  const title = data[def.titleField]
  if (typeof title === 'string' && title) data[def.slugField] = slugify(title)
  return { data, dropped }
}

export interface DraftPhoto {
  url: string
  mediaId?: string
}

/**
 * Photos fill the type's image fields in definition order (the first is the
 * cover), then its first gallery field takes the rest (up to its max); any
 * left over are returned.
 */
export function assignPhotos(def: RecordTypeDef, data: RecordData, photos: readonly DraftPhoto[]): { data: RecordData; unused: DraftPhoto[] } {
  const out: RecordData = { ...data }
  const queue = [...photos]
  for (const f of def.fields) {
    if (f.type !== 'image' || f.draftable === false) continue
    if (out[f.key]) continue
    const next = queue.shift()
    if (!next) break
    out[f.key] = next.url
  }
  const gallery = def.fields.find((f) => f.type === 'gallery' && f.draftable !== false)
  if (gallery && queue.length) {
    const have = Array.isArray(out[gallery.key]) ? (out[gallery.key] as string[]) : []
    const room = Math.max(0, (gallery.max ?? 12) - have.length)
    out[gallery.key] = [...have, ...queue.splice(0, room).map((p) => p.url)]
  }
  return { data: out, unused: queue }
}

export interface MissingItem {
  key: string
  label: string
  /** Required fields block saving; the rest are worth adding. */
  required: boolean
  message: string
}

/** What's still empty that matters, record-type driven ("No start date yet"). */
export function missingItems(def: RecordTypeDef, data: RecordData): MissingItem[] {
  const empty = (v: unknown) => v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0)
  return def.fields
    .filter((f) => (f.required || f.quick) && f.type !== 'slug' && f.type !== 'boolean' && empty(data[f.key]))
    .map((f) => ({ key: f.key, label: f.label, required: !!f.required, message: `No ${f.label.toLowerCase()} yet` }))
}

/**
 * "Fill it in myself" before the assistant finished: keep what it had
 * already written (coerced like a finished draft — a half-typed value that
 * doesn't fit is dropped), with the photos in place.
 */
export function prefillDraft(def: RecordTypeDef, partial: { fields?: unknown; story?: unknown } | null | undefined, photos: readonly DraftPhoto[]): { data: RecordData; story: string[] } {
  const all = partial?.fields && typeof partial.fields === 'object' && !Array.isArray(partial.fields) ? (partial.fields as Record<string, unknown>) : {}
  const story = Array.isArray(partial?.story) ? partial.story.filter((p): p is string => typeof p === 'string' && p.trim().length > 0).map((p) => p.trim()) : []
  // The field being written when it stopped may be cut short ("$3,0" of "$3,000"): only fields the
  // model has moved past are kept — all of them once the story has started.
  const keys = Object.keys(all)
  const fields = story.length ? all : Object.fromEntries(keys.slice(0, -1).map((k) => [k, all[k]]))
  const { data } = coerceDraft(def, fields)
  return { data: assignPhotos(def, data, photos).data, story }
}
