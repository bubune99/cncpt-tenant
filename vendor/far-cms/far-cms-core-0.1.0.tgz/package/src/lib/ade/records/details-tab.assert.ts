import assert from 'node:assert/strict'
import { fallbackTab, tabFromParam } from './details-tab'

let n = 0
const check = (name: string, fn: () => void) => {
  fn()
  console.log(`ok ${++n} - ${name}`)
}

const RECORD = ['details', 'where', 'ready'] as const

check('a tab from the address is taken only when the editor has it', () => {
  assert.equal(tabFromParam('where', RECORD), 'where')
  assert.equal(tabFromParam('ready', RECORD), 'ready')
  for (const bad of ['sharing', 'WHERE', '', '__proto__', 'toString', null, undefined]) assert.equal(tabFromParam(bad, RECORD), null, String(bad))
})

check('a panel that throws falls back to Details; Details throwing closes the panel (never a loop)', () => {
  assert.equal(fallbackTab('where', 'details'), 'details')
  assert.equal(fallbackTab('ready', 'details'), 'details')
  assert.equal(fallbackTab('details', 'details'), null)
  // Following the fallback from any tab ends within two steps.
  for (const start of RECORD) {
    let t: string | null = start
    let steps = 0
    while (t !== null && steps < 5) {
      t = fallbackTab(t, 'details')
      steps++
    }
    assert.ok(steps <= 2, start)
  }
})

console.log(`\n${n} checks passed`)
