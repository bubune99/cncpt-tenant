/**
 * Field updates on a record's "Progress so far" (pure; asserted by
 * progress.assert.ts): the newest update goes on top of what's there, as
 * its own paragraph, within the field's length; and new photos join the
 * gallery without repeats or going over its size.
 */

/** The new update first, then the earlier text; trimmed to max (the oldest words go first). */
export function addProgressUpdate(existing: unknown, update: string, max = 2000): string {
  const next = update.trim()
  const prev = typeof existing === 'string' ? existing.trim() : ''
  if (!next) return prev
  if (prev.startsWith(next)) return prev
  const all = prev ? `${next}\n\n${prev}` : next
  if (all.length <= max) return all
  const cut = all.slice(0, max)
  const end = Math.max(cut.lastIndexOf('\n\n'), cut.lastIndexOf('. ') + 1)
  return (end > next.length ? cut.slice(0, end) : cut).trim()
}

/** The gallery with new photos added at the end, no repeats, at most max. */
export function addToGallery(existing: unknown, photos: readonly string[], max = 12): string[] {
  const have = Array.isArray(existing) ? existing.filter((u): u is string => typeof u === 'string') : []
  return [...new Set([...have, ...photos])].slice(0, max)
}
