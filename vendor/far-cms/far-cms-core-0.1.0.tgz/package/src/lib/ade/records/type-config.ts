/**
 * Everything the record engine needs to know about a TYPE, read from its
 * definition — so a new type (BYB's "drop") is data, not code: its list
 * blocks and what they show, its editor-canvas parts, its home-page card, and
 * the plain words for its screens. The first type (the initiative) is just
 * one definition; nothing here names it.
 *
 * Pure and app-agnostic. Asserted by type-config.assert.ts.
 */

import type { CanvasPartDef, ListComponentDef, RecordData, RecordStatus, RecordTypeDef, TemplateBlock } from './types'
import { matchesRules, parseRules, placementFields, RULES_ATTR } from './rules'

export interface ListComponentEntry extends ListComponentDef {
  type: string
}

/** Every list block of every type, by its component name. */
export function listComponentIndex(types: ReadonlyArray<RecordTypeDef>): Readonly<Record<string, ListComponentEntry>> {
  const out: Record<string, ListComponentEntry> = {}
  for (const t of types) for (const l of t.listComponents ?? []) out[l.componentName] = { ...l, type: t.key }
  return out
}

/**
 * Does a list block show this record? With placement rules: the rules (on the
 * type's own fields). Without: published, and featured when the block shows
 * featured ones by default (unless data-source="all").
 */
export function listIncludes(def: RecordTypeDef, list: ListComponentDef, attrs: Readonly<Record<string, string>>, rec: { status: RecordStatus | string; data: RecordData }): boolean {
  const f = placementFields(def)
  const rules = parseRules(attrs[RULES_ATTR])
  if (rules) return matchesRules({ id: '', status: rec.status, data: rec.data }, rules, f)
  if (rec.status !== 'PUBLISHED') return false
  return attrs['data-source'] === 'all' || !list.featuredByDefault || rec.data[f.featured] === true
}

/** The canvas part a template block draws, from the type's own map (unknown component → null). */
export function canvasPartFor(def: Pick<RecordTypeDef, 'canvasParts'>, componentName: string): CanvasPartDef | null {
  return def.canvasParts && Object.hasOwn(def.canvasParts, componentName) ? def.canvasParts[componentName] : null
}

/** The field a canvas part shows for one of its slots ("title" → "name"); the slot's own name when the type doesn't map it. */
export function partField(part: CanvasPartDef, slot: string): string {
  return part.fields?.[slot] ?? slot
}

/** The home-page card for a featured record of this type, if it has one. */
export function homeCardOf(def: Pick<RecordTypeDef, 'homeCard'>): RecordTypeDef['homeCard'] | null {
  return def.homeCard ?? null
}

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

/** Plain words for a type's admin screens: its list, a new one, one of them — from its label, plural and key. */
export function navPhrasesFor(def: Pick<RecordTypeDef, 'key' | 'label' | 'plural'>, base = '/admin/records'): Array<[RegExp, string]> {
  const root = `${base}/${def.key}`
  return [
    [new RegExp(`^${esc(root)}$`), `your ${def.plural.toLowerCase()}`],
    [new RegExp(`^${esc(root)}/new$`), `a new ${def.label.toLowerCase()}`],
    [new RegExp(`^${esc(root)}/[^/]+$`), `the ${def.label.toLowerCase()}`],
  ]
}

// ── A type's key fields and its record page ───────────────────────────

/** The fields that play a role (title, summary, place, badge, picture, dates, featured), by this type's own names. */
export interface RecordFacets {
  title: string
  summary: string
  place: string
  /** The enum shown as a pill (its group: stage, phase…). */
  badge: string
  image: string
  start: string
  end: string
  featured: string
  featuredOrder: string
}

export function recordFacets(def: Pick<RecordTypeDef, 'titleField' | 'canvasParts' | 'placement'>): RecordFacets {
  const pf = placementFields(def)
  const header = Object.values(def.canvasParts ?? {}).find((p) => p.part === 'header')
  const h = (slot: string, fallback: string) => (header?.fields?.[slot] ?? fallback)
  return {
    title: h('title', def.titleField),
    summary: h('summary', 'summary'),
    place: h('place', 'location'),
    badge: h('badge', pf.group),
    image: h('image', pf.photo),
    start: h('start', pf.start),
    end: h('end', pf.end),
    featured: pf.featured,
    featuredOrder: pf.featuredOrder,
  }
}

/** The record page's drawer: its tabs and the capability that opens it (the shared record page, record-detail.tsx). */
export const RECORD_DRAWER = {
  openCapability: 'record.open_details',
  tabs: [
    { id: 'details', label: 'Details', selector: '[data-ui="record.tab.details"]' },
    { id: 'blocks', label: 'Blocks', selector: '[data-ui="record.tab.blocks"]' },
    { id: 'where', label: 'Where it shows', selector: '[data-ui="record.tab.where"]' },
    { id: 'ready', label: 'Ready to publish', selector: '[data-ui="record.ready"]' },
  ],
} as const

function placeholders(blocks: ReadonlyArray<TemplateBlock>, into: Set<string>) {
  for (const b of blocks) {
    const one = b.textContent?.match(/^\{\{(\w+)\}\}$/)
    if (one) into.add(one[1])
    if (b.children) placeholders(b.children, into)
  }
}

/** Fields drawn on the record page: the header part's text, picture and pill, plus the template's {{field}} text. */
export function fieldsOnPage(def: Pick<RecordTypeDef, 'pageTemplate' | 'canvasParts' | 'titleField' | 'placement' | 'fields'>): Readonly<Record<string, string | true>> {
  const out: Record<string, string | true> = {}
  const has = (k: string) => def.fields.some((x) => x.key === k)
  const header = Object.values(def.canvasParts ?? {}).find((p) => p.part === 'header')
  if (header) {
    const f = recordFacets(def)
    for (const k of [f.title, f.summary, f.place]) if (has(k)) out[k] = true
    if (has(f.image)) out[f.image] = '[data-ui="record.hero"]'
    if (has(f.badge)) out[f.badge] = '[data-ui="record.stage"]'
  }
  const texts = new Set<string>()
  placeholders(def.pageTemplate, texts)
  for (const k of texts) if (has(k)) out[k] ??= true
  return out
}

/** The record page's layout for units (lib/ade/records/field-units), from the type. */
/**
 * The Details tab's fields with no built-in input, split by where the type lists them: before its
 * first built-in field (they lead the tab) or after (they follow it).
 */
export function splitDetailsFields(inDrawer: readonly string[], builtIn: ReadonlySet<string | undefined>): { lead: string[]; tail: string[] } {
  const first = inDrawer.findIndex((k) => builtIn.has(k))
  const others = inDrawer.map((k, i) => ({ k, i })).filter(({ k }) => !builtIn.has(k))
  return {
    lead: others.filter(({ i }) => first !== -1 && i < first).map(({ k }) => k),
    tail: others.filter(({ i }) => first === -1 || i > first).map(({ k }) => k),
  }
}

export function recordPageLayout(def: Pick<RecordTypeDef, 'fields' | 'pageTemplate' | 'canvasParts' | 'titleField' | 'placement' | 'detailsFields'>) {
  const onPage = fieldsOnPage(def)
  // Added sections (type 'blocks') live on the Blocks tab, not as a Details input.
  const inDrawer = (def.detailsFields ?? def.fields.map((f) => f.key).filter((k) => !(k in onPage))).filter((k) => def.fields.find((f) => f.key === k)?.type !== 'blocks')
  const hasBlocks = def.fields.some((f) => f.type === 'blocks')
  return { onPage, inDrawer, tabs: RECORD_DRAWER.tabs.filter((t) => hasBlocks || t.id !== 'blocks'), openDrawer: RECORD_DRAWER.openCapability }
}
