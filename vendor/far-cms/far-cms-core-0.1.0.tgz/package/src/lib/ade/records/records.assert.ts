/**
 * Assertions for the ADE records core (pure).
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/records.assert.ts
 */
import assert from 'node:assert/strict'
import type { RecordTypeDef } from './types'
import {
  boundFieldAt,
  diffEvents,
  dueDateEvents,
  findPlacements,
  instantiateTemplate,
  parseRecordRef,
  recordPath,
  recordRef,
  resolveBound,
  setOverride,
  slugify,
  validateRecord,
} from './logic'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

const def: RecordTypeDef = {
  key: 'thing',
  label: 'Thing',
  plural: 'Things',
  titleField: 'name',
  slugField: 'slug',
  pathPrefix: '/things/',
  category: 'things',
  eventFields: ['stage'],
  dateEventFields: ['startDate'],
  fields: [
    { key: 'name', label: 'Name', type: 'text', required: true, max: 40 },
    { key: 'slug', label: 'Slug', type: 'slug' },
    { key: 'stage', label: 'Stage', type: 'enum', options: [{ value: 'a', label: 'A' }, { value: 'b', label: 'B' }], default: 'a' },
    { key: 'startDate', label: 'Start', type: 'date' },
    { key: 'featured', label: 'Featured', type: 'boolean' },
    { key: 'stats', label: 'Stats', type: 'stats', max: 2 },
    { key: 'goal', label: 'Goal', type: 'longtext' },
  ],
  pageTemplate: [
    { tag: 'section', children: [
      { tag: 'h1', componentName: 'RecordField', attrs: { 'data-record': '$record', 'data-field': 'name' } },
      { tag: 'p', textContent: 'Our goal: {{goal}}' },
      { tag: 'p', textContent: '{{missing}}' },
    ] },
  ],
}

check('refs and slugs round-trip; paths use the type prefix', () => {
  assert.equal(recordRef('thing', 'abc'), 'thing:abc')
  assert.deepEqual(parseRecordRef('thing:a:b'), { type: 'thing', id: 'a:b' })
  assert.equal(parseRecordRef('nocolon'), null)
  assert.equal(slugify("Women’s Small-Business Grants!"), 'womens-small-business-grants')
  assert.equal(recordPath(def, 'x'), '/things/x')
})

check('validation: required, enum, date, coercion, defaults, slug from title, unknown keys dropped', () => {
  const ok = validateRecord(def, { name: 'Clinic Build', featured: 'true', stats: [{ value: '5', label: 'beds' }, {}], junk: 1 })
  assert.deepEqual(ok.errors, {})
  assert.equal(ok.data.slug, 'clinic-build')
  assert.equal(ok.data.stage, 'a')
  assert.equal(ok.data.featured, true)
  assert.deepEqual(ok.data.stats, [{ value: '5', label: 'beds' }])
  assert.ok(!('junk' in ok.data))
  const bad = validateRecord(def, { name: '', stage: 'z', startDate: '9/10/26', stats: [{ value: 1 }, { value: 2 }, { value: 3 }] })
  assert.deepEqual(Object.keys(bad.errors).sort(), ['name', 'stage', 'startDate', 'stats'])
})

check('partial validation touches only the given keys', () => {
  const r = validateRecord(def, { stage: 'b' }, { partial: true })
  assert.deepEqual(r, { data: { stage: 'b' }, errors: {} })
})

check('template: binds $record, fills {{field}} story text, fresh ids, drops empty text', () => {
  let i = 0
  const blocks = instantiateTemplate(def.pageTemplate, recordRef('thing', 'r1'), { name: 'X', goal: 'heal' }, () => `b${++i}`)
  assert.equal(blocks.length, 1)
  const kids = blocks[0].children!
  assert.equal(kids.length, 2, 'the {{missing}} paragraph is dropped')
  assert.equal(kids[0].attrs?.['data-record'], 'thing:r1')
  assert.equal(kids[1].textContent, 'Our goal: heal')
  assert.deepEqual([blocks[0].id, kids[0].id, kids[1].id], ['b1', 'b2', 'b3'])
})

const page = {
  blocks: [
    { id: 'c1', componentName: 'InitiativeCard', attrs: { 'data-record': 'thing:r1' } },
    { id: 'wrap', children: [{ id: 'f1', componentName: 'RecordField', attrs: { 'data-record': 'thing:r1', 'data-field': 'name' } }] },
    { id: 'other', attrs: { 'data-record': 'thing:r2', 'data-field': 'name' } },
  ],
}

check('placements: finds every block bound to the record, with field + overrides', () => {
  const p = findPlacements([{ id: 'home', title: 'Home', path: '/', content: page }], 'thing:r1')
  assert.deepEqual(p.map((x) => x.blockId), ['c1', 'f1'])
  assert.equal(p[1].field, 'name')
  assert.deepEqual(boundFieldAt(page, 'f1'), { ref: 'thing:r1', field: 'name' })
  assert.equal(boundFieldAt(page, 'c1'), null, 'composite blocks are not single-field')
})

check('overrides: set marks the placement customized; reset returns to the record; non-bound refused', () => {
  const set = setOverride(page, 'c1', 'name', 'Short')
  assert.ok(!('error' in set))
  if ('error' in set) return
  const [card] = findPlacements([{ id: 'home', title: 'Home', path: '/', content: set.content }], 'thing:r1')
  assert.deepEqual(card.overrides, { name: 'Short' })
  assert.deepEqual(resolveBound({ name: 'Long name' }, 'name', card.overrides), { value: 'Short', overridden: true })
  assert.deepEqual(resolveBound({ name: 'Long name' }, 'name', {}), { value: 'Long name', overridden: false })
  const reset = setOverride(set.content, 'c1', 'name', null)
  assert.ok(!('error' in reset))
  if ('error' in reset) return
  assert.ok(!(reset.content as typeof page).blocks[0].attrs!['data-overrides' as keyof object])
  assert.equal(page.blocks[0].attrs!['data-record'], 'thing:r1', 'input untouched')
  assert.ok('error' in setOverride(page, 'wrap', 'name', 'x'))
})

check('events: created, published, watched field changed; due date events', () => {
  assert.deepEqual(diffEvents(def, null, { status: 'DRAFT', data: { stage: 'a' } }).map((e) => e.type), ['record.created'])
  const ev = diffEvents(def, { status: 'DRAFT', data: { stage: 'a' } }, { status: 'PUBLISHED', data: { stage: 'b' } })
  assert.deepEqual(ev.map((e) => e.type), ['record.published', 'field.changed'])
  assert.deepEqual(dueDateEvents(def, { startDate: '2026-10-09' }, new Date('2026-10-08T00:00:00Z'), new Date('2026-10-09T12:00:00Z')).length, 1)
  assert.deepEqual(dueDateEvents(def, { startDate: '2026-10-09' }, new Date('2026-10-09T12:00:00Z'), new Date('2026-10-10T00:00:00Z')).length, 0)
})

console.log(`\n${n} checks passed`)
