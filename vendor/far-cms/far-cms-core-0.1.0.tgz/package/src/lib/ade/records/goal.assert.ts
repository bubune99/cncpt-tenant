/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/records/goal.assert.ts
 */
import assert from 'node:assert/strict'
import { formatMoney, goalProgress } from './goal'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('a numeric goal reads as money; no raised amount = no bar (never invented)', () => {
  assert.equal(formatMoney(3000, 'USD'), '$3,000')
  const g = goalProgress(3000, 'USD')!
  assert.equal(g.goalLabel, 'Goal: $3,000')
  assert.equal(g.pct, null)
})

check('a real raised amount gives the bar, clamped', () => {
  assert.deepEqual(goalProgress(3000, 'USD', 1200), { goalLabel: 'Goal: $3,000', pct: 40, label: '$1,200 of $3,000 raised' })
  assert.equal(goalProgress(1000, 'USD', 5000)!.pct, 100)
})

check('no goal, a zero/negative goal or text = nothing shown', () => {
  for (const g of [undefined, null, 0, -5, '3000', Number.NaN]) assert.equal(goalProgress(g, 'USD'), null, String(g))
  assert.equal(goalProgress(500, 'nope')!.goalLabel, 'Goal: $500', 'unknown currency falls back to USD')
})

console.log(`\n${n} checks passed`)
