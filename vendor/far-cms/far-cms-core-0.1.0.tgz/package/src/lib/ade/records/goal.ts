/**
 * Money goals on records (pure, app-agnostic; asserted by goal.assert.ts):
 * "Goal: $3,000", and a progress bar ONLY when a real raised amount exists —
 * never an invented percentage.
 */

export const CURRENCIES = [
  { value: 'USD', label: 'US dollars ($)' },
  { value: 'GHS', label: 'Ghana cedis (GH₵)' },
  { value: 'EUR', label: 'Euros (€)' },
  { value: 'GBP', label: 'Pounds (£)' },
] as const

/** "$3,000", "GH₵12,500" — whole amounts without decimals. */
export function formatMoney(amount: number, currency = 'USD', locale = 'en-US'): string {
  try {
    return new Intl.NumberFormat(locale, { style: 'currency', currency, maximumFractionDigits: Number.isInteger(amount) ? 0 : 2 }).format(amount)
  } catch {
    return `${currency} ${amount.toLocaleString(locale)}`
  }
}

export interface GoalProgress {
  /** "Goal: $3,000" */
  goalLabel: string
  /** 0–100, or null when nothing real says how much is raised. */
  pct: number | null
  /** "$1,200 of $3,000 raised" when known. */
  label: string
}

/** Null when there's no positive numeric goal. */
export function goalProgress(goal: unknown, currency: unknown, raised?: unknown): GoalProgress | null {
  if (typeof goal !== 'number' || !Number.isFinite(goal) || goal <= 0) return null
  const cur = typeof currency === 'string' && /^[A-Z]{3}$/.test(currency) ? currency : 'USD'
  const goalLabel = `Goal: ${formatMoney(goal, cur)}`
  // Goal only (owner, 2026-10-11: "raised so far" is just an idea) — a bar only from a real raised amount.
  if (typeof raised !== 'number' || !Number.isFinite(raised) || raised < 0) return { goalLabel, pct: null, label: goalLabel }
  return { goalLabel, pct: Math.max(0, Math.min(100, Math.round((raised / goal) * 100))), label: `${formatMoney(raised, cur)} of ${formatMoney(goal, cur)} raised` }
}
