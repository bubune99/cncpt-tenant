/**
 * Agent run recorder — builds one run's timeline (spans) in memory while the
 * agent works, and hands back plain rows when it ends. Pure and app-agnostic:
 * the host injects the clock, ids, redaction and tool labels, and does the
 * single batched write. Asserted by observability.assert.ts.
 *
 * Timeline:
 *   agent  "Assistant"                       (root, the whole run)
 *   ├ model  step 1 (start → first tool of that step, or step end)
 *   ├ tool   load_tools → kind 'io'
 *   ├ tool   update_page (effect from the tool's labels, attempt n on a retry)
 *   ├ model  step 2 …
 *   └ agent  sub-agent (phase 3 `delegate`), with its own children
 *
 * Nothing here touches a model, so recording can never add model calls.
 */

export type SpanKind = 'agent' | 'model' | 'tool' | 'io'
/** blocked / masked = the visibility policy refused or masked a read. */
/**
 * blocked / masked = the visibility policy refused or masked a read.
 * waiting = a call the browser answers (read_view…) — its result arrives with
 * the next request, which joins the same run.
 */
export type SpanStatus = 'ok' | 'error' | 'cached' | 'blocked' | 'masked' | 'waiting'
/** waiting = paused on a browser-answered call (never a failure; the continuation finishes it). */
export type RunStatus = 'ok' | 'error' | 'aborted' | 'budget' | 'waiting'
export type SpanEffect = 'read' | 'draft' | 'write' | 'irreversible'

export interface SpanRow {
  id: string
  runId: string
  parentId: string | null
  seq: number
  kind: SpanKind
  label: string
  startMs: number
  endMs: number
  status: SpanStatus
  attempt: number
  tokens: number
  detail: string | null
  effect: SpanEffect | null
  changeSetId: string | null
  auditLogId: string | null
  inputRedacted: unknown
  outputSummary: string | null
  /** The tool-call id of a browser-answered call (joins the continuation). */
  callId: string | null
}

export interface RunRow {
  id: string
  startedAt: Date
  endedAt: Date
  status: RunStatus
  steps: number
  tokensIn: number
  tokensOut: number
  cacheRead: number
  cacheWrite: number
  tokens: number
  durationMs: number
  toolGroupsLoaded: string[]
  droppedSpans: number
  error: string | null
}

export interface StepUsage {
  input?: number
  output?: number
  cacheRead?: number
  cacheWrite?: number
}

export interface RecorderDeps {
  /** Epoch ms. */
  now(): number
  newId(): string
  /** Redact + shrink a tool input before it is kept (the host's audit redaction). */
  redact(input: unknown): unknown
  /**
   * Tools whose input and result are never kept (a person's own mailbox):
   * the span records what `input`/`summary` return — counts only — and a
   * failure reads `error`, never the provider's message.
   */
  sealed?: { is(name: string): boolean; input(name: string, input: unknown): unknown; summary(name: string, output: unknown): string; error: string }
  /** The tool's effect label, or null when unknown. */
  effectOf(toolName: string): SpanEffect | null
  /** Tools that are plumbing, not actions (e.g. load_tools) → kind 'io'. */
  ioTools?: ReadonlySet<string>
  /** Groups a load_tools-style call turned on, from its input. */
  groupsFromIo?(toolName: string, input: unknown): string[]
  /** Short model name for step labels ("claude-haiku-5.5 · step 1 · read_view"). */
  modelLabel?: string
}

/** Where a waiting run left off — loaded by the host when the continuation arrives. */
export interface ResumeState {
  /** Epoch ms of the original start (offsets continue from it). */
  startedAt: number
  rootId: string
  nextSeq: number
  steps: number
  spanCount: number
  droppedSpans: number
  totals: { tokensIn: number; tokensOut: number; cacheRead: number; cacheWrite: number }
  groups: string[]
  /** Browser-answered calls still waiting for their result. */
  waiting: Array<{ spanId: string; callId: string; label: string; startMs: number }>
}

/** A change to a span already written (a joined run). */
export interface SpanUpdate {
  id: string
  endMs: number
  status: SpanStatus
  detail?: string | null
  outputSummary?: string | null
  tokens?: number
}

export interface ToolCallInfo {
  toolName: string
  input?: unknown
  toolCallId?: string
}

export const SPAN_CAP = 300
export const INPUT_CAP = 2000
export const LINE_CAP = 160

const clip = (s: string, n = LINE_CAP) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

/** Keep a redacted input under INPUT_CAP characters of JSON. */
export function capInput(value: unknown): unknown {
  if (value === undefined) return null
  let json: string
  try {
    json = JSON.stringify(value)
  } catch {
    return { _unserializable: true }
  }
  if (json === undefined) return null
  return json.length <= INPUT_CAP ? value : { _truncated: clip(json, INPUT_CAP) }
}

/** One line saying what a tool returned (never the payload). */
export function summarizeOutput(output: unknown, redactLine: (s: string) => string = (s) => s): string {
  if (output === null || output === undefined) return 'No result'
  if (typeof output !== 'object') return clip(redactLine(String(output)))
  const o = output as Record<string, unknown>
  if (o.success === false || typeof o.error === 'string') return clip(`Failed: ${redactLine(String(o.error ?? 'error'))}`)
  if (o.drafted === true) return 'Drafted for review'
  if (Array.isArray(o.loaded)) return clip(`Loaded ${(o.loaded as unknown[]).join(', ') || 'nothing'}`)
  const keys = Object.keys(o).filter((k) => k !== 'success')
  return clip(keys.length ? `Returned ${keys.slice(0, 6).join(', ')}${keys.length > 6 ? ', …' : ''}` : 'Done')
}

/** A tool result that hands the work to the browser (operate_ui and friends). */
export function isScreenSentinel(output: unknown): boolean {
  return !!output && typeof output === 'object' && (output as Record<string, unknown>).__requires_client_execution === true
}

function failed(output: unknown): string | null {
  if (!output || typeof output !== 'object') return null
  const o = output as Record<string, unknown>
  if (o.success === false || (typeof o.error === 'string' && o.error)) return String(o.error ?? 'Failed')
  return null
}

/** Stable key for "the same call again" (retry detection). */
function callKey(name: string, input: unknown): string {
  const stable = (v: unknown): unknown =>
    Array.isArray(v) ? v.map(stable) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v as object).sort().map((k) => [k, stable((v as Record<string, unknown>)[k])])) : v
  try {
    return `${name}:${JSON.stringify(stable(input))}`
  } catch {
    return `${name}:?`
  }
}

export interface BlockedRead {
  mode: 'blocked' | 'masked' | 'metadata-only'
  target: string
  fields?: readonly string[]
  reason?: string
  tool?: string
}

/** The one-line detail for a blocked/masked read (labels only). */
export function blockedDetail(b: BlockedRead): string {
  const fields = (b.fields ?? []).filter(Boolean).slice(0, 12)
  const what = b.mode === 'blocked' ? 'Blocked' : b.mode === 'metadata-only' ? 'Only names and dates shown' : `Masked${fields.length ? `: ${fields.join(', ')}` : ''}`
  return clip(`${what}${b.reason ? ` (${b.reason})` : ''}${b.tool ? ` · ${b.tool}` : ''}`)
}

export interface ToolHandle {
  id: string
}

export interface AgentHandle {
  id: string
  end(status?: SpanStatus, detail?: string): void
}

export interface RunRecorder {
  readonly runId: string
  readonly rootId: string
  /** A tool started (parent = the given agent span, or the root). `callId` = the SDK tool-call id. */
  toolStart(name: string, input: unknown, parentId?: string, callId?: string): ToolHandle
  /** It finished: output (status from it) or a thrown error. */
  toolEnd(h: ToolHandle, result: { output?: unknown; error?: unknown }): void
  /**
   * A model step finished (AI SDK onStepFinish). `calls` = the step's tool
   * calls: any without a server execute (seen by wrapTools) ran on the
   * client — e.g. reading the screen — and become 'waiting' tool spans.
   */
  step(usage: StepUsage, parentId?: string, calls?: ReadonlyArray<ToolCallInfo>): void
  /** The browser's answer to a waiting call arrived (joined run): close its span. False = not waiting here. */
  resolveClientCall(callId: string, result: { output?: unknown; error?: unknown }): boolean
  /**
   * A read the visibility policy refused ('blocked'), or allowed with fields
   * hidden ('masked' / metadata-only). `target` is a label (route, entity,
   * field names) — never the value.
   */
  blocked(b: BlockedRead, parentId?: string): void
  /** Open a sub-agent span (phase 3 delegate). */
  agent(label: string, parentId?: string): AgentHandle
  /** Wrap every tool's execute so starts/ends are recorded. Returns a new object; tools without execute pass through. */
  wrapTools<T extends Record<string, unknown>>(tools: T, parentId?: string): T
  /**
   * Close the run. Idempotent: the second call returns null. `spans` are new
   * rows; `updates` change rows already written (a joined run: the root and
   * the calls the browser answered). A run that ended on a browser-answered
   * call is 'waiting', never 'budget' or 'ok'.
   */
  finish(status: RunStatus, error?: string): { run: RunRow; spans: SpanRow[]; updates: SpanUpdate[]; resumed: boolean } | null
}

interface OpenTool {
  span: SpanRow
  startAbs: number
  stepIndex: number
}

export function createRunRecorder(deps: RecorderDeps, runId = deps.newId(), resume?: ResumeState): RunRecorder {
  const t0 = resume?.startedAt ?? deps.now()
  const rel = () => Math.max(0, deps.now() - t0)
  const rootId = resume?.rootId ?? deps.newId()
  const spans: SpanRow[] = []
  const updates: SpanUpdate[] = []
  const open = new Map<string, OpenTool>()
  const attempts = new Map<string, number>()
  const groups = new Set<string>(resume?.groups ?? [])
  const waiting = new Map((resume?.waiting ?? []).map((w) => [w.callId, w]))
  const already = resume ? resume.spanCount : 1
  let seq = resume?.nextSeq ?? 0
  let dropped = resume?.droppedSpans ?? 0
  let stepIndex = resume?.steps ?? 0
  // A joined run's next model step starts when the continuation arrives (the pause is the screen's, not the model's).
  let stepStart = resume ? rel() : 0
  let firstToolInStep: number | null = null
  let toolsInStep: string[] = []
  /** Tools with a server execute (from wrapTools); other calls run on the client. */
  const executable = new Set<string>()
  let lastStepClientCalls = 0
  let totals = resume ? { ...resume.totals } : { tokensIn: 0, tokensOut: 0, cacheRead: 0, cacheWrite: 0 }
  let done = false

  const root: SpanRow = {
    id: rootId, runId, parentId: null, seq: resume ? -1 : seq++, kind: 'agent', label: 'Assistant', startMs: 0, endMs: 0,
    status: 'ok', attempt: 1, tokens: 0, detail: null, effect: null, changeSetId: null, auditLogId: null, inputRedacted: null, outputSummary: null, callId: null,
  }

  const redactLine = (x: string) => {
    const r = deps.redact(x)
    return typeof r === 'string' ? r : x
  }

  const push = (s: SpanRow): boolean => {
    if (spans.length + already >= SPAN_CAP) {
      dropped++
      return false
    }
    spans.push(s)
    return true
  }

  const recorder: RunRecorder = {
    runId,
    rootId,

    toolStart(name, input, parentId, callId) {
      const id = deps.newId()
      const at = rel()
      if (firstToolInStep === null) firstToolInStep = at
      if (!toolsInStep.includes(name)) toolsInStep.push(name)
      const key = callKey(name, input)
      const attempt = (attempts.get(key) ?? 0) + 1
      attempts.set(key, attempt)
      const io = deps.ioTools?.has(name) ?? false
      if (io) for (const g of deps.groupsFromIo?.(name, input) ?? []) groups.add(g)
      let redacted: unknown
      try {
        redacted = deps.sealed?.is(name) ? deps.sealed.input(name, input) : capInput(deps.redact(input))
      } catch {
        redacted = { _redactionFailed: true }
      }
      const span: SpanRow = {
        id, runId, parentId: parentId ?? rootId, seq: seq++, kind: io ? 'io' : 'tool', label: name, startMs: at, endMs: at,
        status: 'ok', attempt, tokens: 0, detail: null, effect: io ? null : deps.effectOf(name), changeSetId: null, auditLogId: null,
        inputRedacted: redacted, outputSummary: null, callId: callId ?? null,
      }
      open.set(id, { span, startAbs: at, stepIndex })
      return { id }
    },

    toolEnd(h, result) {
      const o = open.get(h.id)
      if (!o) return
      open.delete(h.id)
      const s = o.span
      s.endMs = Math.max(s.startMs, rel())
      if (result.error !== undefined) {
        s.status = 'error'
        const msg = result.error instanceof Error ? result.error.message : String(result.error)
        s.outputSummary = deps.sealed?.is(s.label) ? deps.sealed.error : clip(`Error: ${redactLine(msg)}`)
        s.detail = s.outputSummary
      } else {
        const out = result.output
        if (isScreenSentinel(out)) {
          // Handed to the screen (operate_ui): the turn goes on; the browser's
          // result comes with the next request (uiReport) and closes this span.
          s.status = 'waiting'
          s.outputSummary = 'Sent to the screen'
          s.detail = 'Sent to the screen — its result arrives with the next request'
          push(s)
          return
        }
        const fail = failed(out)
        s.status = fail ? 'error' : out && typeof out === 'object' && (out as Record<string, unknown>).cached === true ? 'cached' : 'ok'
        s.outputSummary = deps.sealed?.is(s.label) ? deps.sealed.summary(s.label, out) : summarizeOutput(out, redactLine)
        s.detail = s.outputSummary
        const cs = out && typeof out === 'object' ? (out as Record<string, unknown>).changeSetId : undefined
        if (typeof cs === 'string' && cs) s.changeSetId = cs
      }
      push(s)
    },

    step(usage, parentId, calls) {
      const end = rel()
      const input = usage.input ?? 0
      const output = usage.output ?? 0
      const cacheRead = usage.cacheRead ?? 0
      const cacheWrite = usage.cacheWrite ?? 0
      totals = { tokensIn: totals.tokensIn + input, tokensOut: totals.tokensOut + output, cacheRead: totals.cacheRead + cacheRead, cacheWrite: totals.cacheWrite + cacheWrite }
      stepIndex++
      const names = [...toolsInStep]
      for (const c of calls ?? []) if (!names.includes(c.toolName)) names.push(c.toolName)
      const label = clip([deps.modelLabel, `step ${stepIndex}`, names.join(', ')].filter(Boolean).join(' · '), 120)
      push({
        id: deps.newId(), runId, parentId: parentId ?? rootId, seq: seq++, kind: 'model', label,
        startMs: stepStart, endMs: Math.max(stepStart, firstToolInStep ?? end), status: 'ok', attempt: 1, tokens: input + output,
        detail: `${input.toLocaleString('en-US')} in · ${output.toLocaleString('en-US')} out · ${cacheRead.toLocaleString('en-US')} cached`,
        effect: null, changeSetId: null, auditLogId: null, inputRedacted: null, outputSummary: null, callId: null,
      })
      // Calls the client answers (no server execute): the round trip continues in the next request.
      const client = (calls ?? []).filter((c) => executable.size > 0 && !executable.has(c.toolName))
      lastStepClientCalls = client.length
      for (const c of client) {
        let redacted: unknown
        try {
          redacted = deps.sealed?.is(c.toolName) ? deps.sealed.input(c.toolName, c.input) : capInput(deps.redact(c.input))
        } catch {
          redacted = { _redactionFailed: true }
        }
        push({
          id: deps.newId(), runId, parentId: parentId ?? rootId, seq: seq++, kind: 'tool', label: c.toolName, startMs: end, endMs: end,
          status: 'waiting', attempt: 1, tokens: 0, detail: 'Waiting for the screen', effect: deps.effectOf(c.toolName),
          changeSetId: null, auditLogId: null, inputRedacted: redacted, outputSummary: null, callId: c.toolCallId ?? null,
        })
      }
      stepStart = end
      firstToolInStep = null
      toolsInStep = []
    },

    resolveClientCall(callId, result) {
      const w = waiting.get(callId)
      if (!w) return false
      waiting.delete(callId)
      const end = Math.max(w.startMs, rel())
      if (result.error !== undefined) {
        const msg = result.error instanceof Error ? result.error.message : String(result.error)
        const line = clip(`Error: ${redactLine(msg)}`)
        updates.push({ id: w.spanId, endMs: end, status: 'error', detail: line, outputSummary: line })
      } else {
        const fail = failed(result.output)
        const line = summarizeOutput(result.output, redactLine)
        updates.push({ id: w.spanId, endMs: end, status: fail ? 'error' : 'ok', detail: line, outputSummary: line })
      }
      return true
    },

    blocked(b, parentId) {
      const at = rel()
      push({
        id: deps.newId(), runId, parentId: parentId ?? rootId, seq: seq++, kind: 'io', label: clip(b.target || 'Something private', 120),
        startMs: at, endMs: at, status: b.mode === 'blocked' ? 'blocked' : 'masked', attempt: 1, tokens: 0, detail: blockedDetail(b),
        effect: 'read', changeSetId: null, auditLogId: null, callId: null,
        // Labels only: which fields, which rule — never values.
        inputRedacted: { mode: b.mode, fields: (b.fields ?? []).slice(0, 20), reason: b.reason ?? null, tool: b.tool ?? null },
        outputSummary: b.mode === 'blocked' ? 'Refused by the visibility policy' : 'Returned with fields hidden',
      })
    },

    agent(label, parentId) {
      const span: SpanRow = {
        id: deps.newId(), runId, parentId: parentId ?? rootId, seq: seq++, kind: 'agent', label: clip(label, 80), startMs: rel(), endMs: rel(),
        status: 'ok', attempt: 1, tokens: 0, detail: null, effect: null, changeSetId: null, auditLogId: null, inputRedacted: null, outputSummary: null, callId: null,
      }
      let ended = false
      return {
        id: span.id,
        end(status = 'ok', detail) {
          if (ended) return
          ended = true
          span.endMs = Math.max(span.startMs, rel())
          span.status = status
          span.detail = detail ? clip(detail) : null
          push(span)
        },
      }
    },

    wrapTools(tools, parentId) {
      const out: Record<string, unknown> = {}
      for (const [name, t] of Object.entries(tools)) {
        const exec = t && typeof t === 'object' ? (t as { execute?: unknown }).execute : undefined
        if (typeof exec !== 'function') {
          out[name] = t
          continue
        }
        executable.add(name)
        out[name] = {
          ...(t as object),
          execute: async (...args: unknown[]) => {
            const opts = args[1] as { toolCallId?: unknown } | undefined
            const h = recorder.toolStart(name, args[0], parentId, typeof opts?.toolCallId === 'string' ? opts.toolCallId : undefined)
            try {
              const output = await (exec as (...a: unknown[]) => unknown)(...args)
              recorder.toolEnd(h, { output })
              return output
            } catch (error) {
              recorder.toolEnd(h, { error })
              throw error
            }
          },
        }
      }
      return out as typeof tools
    },

    finish(requested, error) {
      if (done) return null
      done = true
      // A turn that stopped on a call the BROWSER answers is waiting for the
      // screen — not out of budget, not finished, not failed.
      const status: RunStatus = (requested === 'ok' || requested === 'budget') && lastStepClientCalls > 0 ? 'waiting' : requested
      const end = rel()
      // Tools still running when the turn ended (abort, crash).
      for (const [id] of open) recorder.toolEnd({ id }, { error: new Error('Interrupted') })
      const rootStatus: SpanStatus = status === 'waiting' ? 'waiting' : status === 'ok' || status === 'budget' ? 'ok' : 'error'
      const rootTokens = totals.tokensIn + totals.tokensOut
      const rootDetail = clip(`${stepIndex} step${stepIndex === 1 ? '' : 's'} · ${status}`)
      if (resume) updates.push({ id: rootId, endMs: end, status: rootStatus, tokens: rootTokens, detail: rootDetail })
      else Object.assign(root, { endMs: end, status: rootStatus, tokens: rootTokens, detail: rootDetail })
      const all = (resume ? spans : [root, ...spans]).sort((a, b) => a.seq - b.seq)
      return {
        run: {
          id: runId,
          startedAt: new Date(t0),
          endedAt: new Date(t0 + end),
          status,
          steps: stepIndex,
          ...totals,
          tokens: totals.tokensIn + totals.tokensOut,
          durationMs: end,
          toolGroupsLoaded: [...groups],
          droppedSpans: dropped,
          error: error ? clip(error, 500) : null,
        },
        spans: all,
        updates,
        resumed: !!resume,
      }
    },
  }
  return recorder
}
