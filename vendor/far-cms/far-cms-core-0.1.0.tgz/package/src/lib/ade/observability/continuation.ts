/**
 * A browser-answered tool call (read_view…) splits one turn across two
 * requests: the first stops on the call, the browser runs it and sends the
 * conversation back with the result. This finds those results in the
 * continuation request, so the host can join it to the waiting run. Pure.
 */

export interface ClientToolResult {
  callId: string
  toolName: string
  output?: unknown
  error?: string
}

/**
 * Tool results in the LAST message, when it is the assistant's (that is what
 * a continuation looks like; a new user message starts a new run).
 */
export function clientToolResults(messages: ReadonlyArray<unknown>): ClientToolResult[] {
  const last = messages[messages.length - 1] as { role?: unknown; parts?: unknown } | undefined
  if (!last || last.role !== 'assistant' || !Array.isArray(last.parts)) return []
  const out: ClientToolResult[] = []
  for (const p of last.parts as Array<Record<string, unknown>>) {
    if (!p || typeof p !== 'object' || typeof p.toolCallId !== 'string') continue
    const type = typeof p.type === 'string' ? p.type : ''
    const toolName = type === 'dynamic-tool' ? String(p.toolName ?? '') : type.startsWith('tool-') ? type.slice(5) : ''
    if (!toolName) continue
    if (p.state === 'output-available') out.push({ callId: p.toolCallId, toolName, output: p.output })
    else if (p.state === 'output-error') out.push({ callId: p.toolCallId, toolName, error: String(p.errorText ?? 'Failed on the screen') })
  }
  return out
}

export interface ReportedBlock {
  mode: 'blocked' | 'masked' | 'metadata-only'
  target: string
  fields?: string[]
  reason?: string
}

const MODES = new Set(['blocked', 'masked', 'metadata-only'])

/**
 * What the visibility policy refused or masked in the BROWSER (read_view,
 * capture_view): the tool's output carries `blocked: [{ mode, target,
 * fields?, reason? }]` — labels only. Junk entries are dropped; at most 20.
 */
export function blockedFromOutput(output: unknown): ReportedBlock[] {
  const list = output && typeof output === 'object' ? (output as { blocked?: unknown }).blocked : undefined
  if (!Array.isArray(list)) return []
  const out: ReportedBlock[] = []
  for (const b of list.slice(0, 20)) {
    if (!b || typeof b !== 'object') continue
    const o = b as Record<string, unknown>
    if (typeof o.mode !== 'string' || !MODES.has(o.mode) || typeof o.target !== 'string' || !o.target.trim()) continue
    out.push({
      mode: o.mode as ReportedBlock['mode'],
      target: o.target.slice(0, 120),
      ...(Array.isArray(o.fields) ? { fields: o.fields.filter((f): f is string => typeof f === 'string').map((f) => f.slice(0, 60)).slice(0, 20) } : {}),
      ...(typeof o.reason === 'string' ? { reason: o.reason.slice(0, 80) } : {}),
    })
  }
  return out
}

export interface ScreenReport {
  capability: string
  ok: boolean
  message: string
}

export interface PendingScreenAction {
  spanId: string
  capability: string | null
}

/**
 * The browser's results for screen actions sent earlier (uiReport, in the
 * order it ran them) → updates for those still-waiting spans: each report
 * closes the oldest pending action with the same capability. Unmatched
 * reports are ignored; unmatched actions stay waiting.
 */
export function matchScreenReports(pending: readonly PendingScreenAction[], reports: readonly ScreenReport[]): Array<{ spanId: string; ok: boolean; message: string }> {
  const left = [...pending]
  const out: Array<{ spanId: string; ok: boolean; message: string }> = []
  for (const r of reports) {
    const i = left.findIndex((p) => p.capability === r.capability)
    if (i === -1) continue
    out.push({ spanId: left[i].spanId, ok: r.ok, message: r.message.slice(0, 160) })
    left.splice(i, 1)
  }
  return out
}
