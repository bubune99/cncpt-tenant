/**
 * The workspace's per-screen manifest — ONE place that says, for each kind
 * of CMS screen, which action-bar items and tool panels it offers. Editing
 * tools exist only while editing; everywhere else the assistant column is
 * plain chat. Pure; asserted by screens.assert.ts. App-agnostic: the host
 * app supplies its own table.
 */

export type ScreenPanel = 'add' | 'outline' | 'style'
export type ScreenAction =
  | 'undo'
  | 'redo'
  | 'add'
  | 'devices'
  | 'beforeAfter'
  | 'revisions'
  | 'fullView'
  | 'submit'
  | 'upload'
  | 'todoFilters'

export interface ScreenDef {
  key: string
  /** Matches the pathname (no query string). */
  match: RegExp
  /** editing = a person is changing content here (unsaved-changes guard, editing tools). */
  kind: 'editing' | 'screen'
  panels: ReadonlyArray<ScreenPanel>
  actions: ReadonlyArray<ScreenAction>
  /** Plain names for this screen's dock tabs when they differ (forms: "Fields", not "Sections"). */
  labels?: Partial<Record<ScreenPanel, string>>
  /** The assistant's per-screen briefing (a provider the host app registers under this name — lib/ade/briefing). */
  briefing?: string
}

const EDIT_ACTIONS: ReadonlyArray<ScreenAction> = ['undo', 'redo', 'add', 'devices', 'fullView', 'submit']
const ALL_PANELS: ReadonlyArray<ScreenPanel> = ['add', 'outline', 'style']

export const DEFAULT_SCREEN: ScreenDef = { key: 'screen', match: /$^/, kind: 'screen', panels: [], actions: [] }

export const SCREENS: ReadonlyArray<ScreenDef> = [
  { key: 'page-editor', match: /^\/admin\/pages\/[^/]+\/editor$/, kind: 'editing', panels: ALL_PANELS, actions: [...EDIT_ACTIONS, 'beforeAfter', 'revisions'] },
  { key: 'partial-editor', match: /^\/admin\/partials\/[^/]+\/editor$/, kind: 'editing', panels: ALL_PANELS, actions: EDIT_ACTIONS },
  { key: 'layout-editor', match: /^\/admin\/site-settings\/(header|footer)\/editor$/, kind: 'editing', panels: ALL_PANELS, actions: EDIT_ACTIONS },
  // The form builder: Build docks Fields + Outline; Automations/Submissions/Settings dock nothing.
  { key: 'form-builder', match: /^\/admin\/forms\/(?!new$)[^/]+$/, kind: 'editing', panels: ['add', 'outline'], actions: ['fullView', 'submit'], labels: { add: 'Fields' } },
  // The email editor: Build docks Blocks · Outline · Style; Audience / Review & send dock nothing.
  { key: 'email-template-editor', match: /^\/admin\/email-marketing\/templates\/(?!new$)[^/]+$/, kind: 'editing', panels: ALL_PANELS, actions: ['fullView'], labels: { add: 'Blocks' } },
  { key: 'media', match: /^\/admin\/media$/, kind: 'screen', panels: [], actions: ['upload'] },
  { key: 'todo', match: /^\/admin\/todo$/, kind: 'screen', panels: [], actions: ['todoFilters'] },
  { key: 'blog', match: /^\/admin\/blog$/, kind: 'screen', panels: [], actions: [] },
  { key: 'post', match: /^\/admin\/blog\/(?!new$|categories$|tags$|initiatives$)[^/]+$/, kind: 'editing', panels: [], actions: ['fullView'] },
  // Records (initiatives…): the list, and one record as a templated page editor.
  { key: 'records', match: /^\/admin\/records\/[^/]+$/, kind: 'screen', panels: [], actions: [] },
  { key: 'record', match: /^\/admin\/records\/[^/]+\/(?!new$)[^/]+$/, kind: 'editing', panels: [], actions: ['fullView'] },
  { key: 'review', match: /^\/admin\/todo\/review\/[^/]+$/, kind: 'screen', panels: [], actions: ['beforeAfter', 'devices', 'fullView'] },
  // Email campaign editor: the assistant briefs on what stops it going out (ade-bindings/briefings/email-editor).
  // The editor itself is /[id]/design (Build docks Blocks · Outline · Style); /[id] is the campaign's overview.
  { key: 'email-editor', match: /^\/admin\/email-marketing\/(?!new$|templates$)[^/]+(?:\/design)?$/, kind: 'editing', panels: ALL_PANELS, actions: ['fullView'], labels: { add: 'Blocks' }, briefing: 'email-editor' },
  // Settings screen (one screen, grouped sections) — no editing tools.
  { key: 'settings', match: /^\/admin\/settings$/, kind: 'screen', panels: [], actions: [] },
  // Phone screens (/admin/m): the Inbox and editing a page's phone layout.
  { key: 'mobile-inbox', match: /^\/admin\/m\/inbox$/, kind: 'screen', panels: [], actions: [] },
  { key: 'mobile-page-edit', match: /^\/admin\/m\/pages\/[^/]+\/edit$/, kind: 'screen', panels: [], actions: [] },
  // Agent activity: the runs table; one run's trace opens in a drawer (?run=).
  { key: 'agent-activity', match: /^\/admin\/agent-activity$/, kind: 'screen', panels: [], actions: [] },
]

export function screenFor(pathname: string | null | undefined, table: ReadonlyArray<ScreenDef> = SCREENS): ScreenDef {
  const path = (pathname ?? '').split('?')[0].replace(/\/+$/, '') || '/'
  return table.find((s) => s.match.test(path)) ?? DEFAULT_SCREEN
}

export function screenHasPanel(def: ScreenDef, panel: ScreenPanel): boolean {
  return def.panels.includes(panel)
}

export function screenHasAction(def: ScreenDef, action: ScreenAction): boolean {
  return def.actions.includes(action)
}
