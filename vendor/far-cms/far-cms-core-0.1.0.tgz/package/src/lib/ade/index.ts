/**
 * ADE core — the agent development environment primitives.
 *
 * Boundary rule: nothing under src/lib/ade imports app code (no Prisma, no
 * Dzidzor modules). Storage, tool drafters and target adapters are injected
 * by the host app (Dzidzor: src/lib/ade-bindings). That keeps this folder
 * liftable into the shared @cncpt/cms package as-is.
 */
export * from './dock-layout'
export * from './screens'
export * from './admin-mode'
export * from './locks/logic'
export * from './capabilities/labels'
export * from './capabilities/dispatch'
export * from './capabilities/external-list'
export * from './changesets/types'
export * from './changesets/logic'
export * from './changesets/service'
export * from './tasks/generate'
export * from './code-exec/flag'
export * from './ui/split'
export * from './records/types'
export * from './records/logic'
export * from './records/draft'
export * from './records/goal'
