/**
 * Per-screen assistant briefings — the generic shape. A screen that knows
 * what matters while you're on it (e.g. an email that can't go out yet)
 * names a briefing in its manifest entry (lib/ade/screens `briefing`), the
 * host app registers a provider under that name, and the assistant column
 * shows it instead of the general "what needs you" briefing. Pure data and
 * helpers, no React, no app code. Asserted by briefing.assert.ts.
 */

/** What a button or chip does. */
export type BriefingAction =
  | { label: string; href: string }
  /** Ask the assistant (sent as a chat message). */
  | { label: string; ask: string }
  /** Run one of the screen's UI capabilities directly — no model call. */
  | { label: string; ui: { capability: string; args: Record<string, unknown> } }

export interface BriefingCard {
  id: string
  title: string
  detail?: string
  actions: BriefingAction[]
}

/** A run of the opening sentence; `strong` runs are bold. */
export type LeadPart = string | { strong: string }

export interface ScreenBriefing {
  lead: LeadPart[]
  cards: BriefingCard[]
  chips: BriefingAction[]
}

/** What a provider gets about the screen it's on. */
export interface BriefingContext {
  pathname: string
}

export type BriefingProvider = (ctx: BriefingContext, deps: { fetchJson: (url: string) => Promise<unknown> }) => Promise<ScreenBriefing | null>

const WORDS = ['No', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten']

/** "Two things", "One thing", "11 things". */
export function countThings(n: number, noun = 'thing', plural = `${noun}s`): string {
  return `${WORDS[n] ?? n.toLocaleString('en-US')} ${n === 1 ? noun : plural}`
}

/** The lead as plain text (for titles, tests, screen readers). */
export function leadText(lead: ReadonlyArray<LeadPart>): string {
  return lead.map((p) => (typeof p === 'string' ? p : p.strong)).join('')
}
