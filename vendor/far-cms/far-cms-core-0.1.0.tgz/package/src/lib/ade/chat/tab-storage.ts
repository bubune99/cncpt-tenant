/**
 * Per-tab chat state. The assistant's active conversation and its open
 * thread tabs belong to ONE browser tab: the owner works in several tabs,
 * and a shared value made a new tab (or another agent's window) post into
 * someone else's conversation. Preferences (panel mode, the history list)
 * stay shared across tabs.
 *
 * splitStorage() gives zustand's persist one storage that writes the named
 * keys to the per-tab store (sessionStorage — survives reload, not shared)
 * and everything else to the shared one (localStorage). Pure: the stores
 * are injected. Asserted by tab-storage.assert.ts.
 */

import { previewFrameNow } from '../ui/preview-sizes'

export interface KeyValueStore {
  getItem(name: string): string | null
  setItem(name: string, value: string): void
  removeItem(name: string): void
}

interface Persisted {
  state: Record<string, unknown>
  version?: number
}

function parse(raw: string | null): Persisted | null {
  if (!raw) return null
  try {
    const v = JSON.parse(raw) as Persisted
    return v && typeof v === 'object' && v.state && typeof v.state === 'object' ? v : null
  } catch {
    return null
  }
}

const pick = (o: Record<string, unknown>, keys: readonly string[]) => Object.fromEntries(keys.filter((k) => k in o).map((k) => [k, o[k]]))
const omit = (o: Record<string, unknown>, keys: readonly string[]) => Object.fromEntries(Object.entries(o).filter(([k]) => !keys.includes(k)))

/**
 * `perTabKeys` are read ONLY from the per-tab store: a fresh tab starts
 * without them (a new conversation), even if the shared store has an old
 * value from before this split.
 */
export function splitStorage(shared: () => KeyValueStore | undefined, perTab: () => KeyValueStore | undefined, perTabKeys: readonly string[]): KeyValueStore {
  const safe = <T>(fn: () => T, fallback: T): T => {
    try {
      return fn()
    } catch {
      return fallback
    }
  }
  return {
    getItem(name) {
      const s = parse(safe(() => shared()?.getItem(name) ?? null, null))
      const t = parse(safe(() => perTab()?.getItem(name) ?? null, null))
      if (!s && !t) return null
      const state = { ...omit(s?.state ?? {}, perTabKeys), ...pick(t?.state ?? {}, perTabKeys) }
      return JSON.stringify({ state, version: s?.version ?? t?.version ?? 0 })
    },
    setItem(name, value) {
      const v = parse(value)
      if (!v) return
      safe(() => shared()?.setItem(name, JSON.stringify({ state: omit(v.state, perTabKeys), version: v.version })), undefined)
      safe(() => perTab()?.setItem(name, JSON.stringify({ state: pick(v.state, perTabKeys), version: v.version })), undefined)
    },
    removeItem(name) {
      safe(() => shared()?.removeItem(name), undefined)
      safe(() => perTab()?.removeItem(name), undefined)
    },
  }
}

/**
 * Reads fall through to `base`; writes stay in memory. A Preview sizes frame
 * starts from the person's remembered state but never changes it.
 */
export function readThrough(base: () => KeyValueStore | undefined): KeyValueStore {
  const mem = new Map<string, string | null>()
  return {
    getItem: (k) => (mem.has(k) ? mem.get(k)! : base()?.getItem(k) ?? null),
    setItem: (k, v) => void mem.set(k, v),
    removeItem: (k) => void mem.set(k, null),
  }
}

let framed: KeyValueStore | null = null
/** The browser's stores, or undefined on the server (SSR). Inside a preview frame: read-through, writes kept in memory. */
export const browserLocal = (): KeyValueStore | undefined => {
  if (typeof window === 'undefined') return undefined
  if (previewFrameNow()) return (framed ??= readThrough(() => window.localStorage))
  return window.localStorage
}
export const browserSession = (): KeyValueStore | undefined => (typeof window === 'undefined' ? undefined : window.sessionStorage)
