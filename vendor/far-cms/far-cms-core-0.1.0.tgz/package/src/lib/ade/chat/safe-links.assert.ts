/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/safe-links.assert.ts
 */
import assert from 'node:assert/strict'
import { safeChatHref, safeChatImageSrc } from './safe-links'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const ME = 'https://dzidzor-staging.vercel.app'

const MEDIA = ['https://media.example.org/']

check('images never fetch a remote URL (the zero-click exfiltration channel)', () => {
  for (const bad of ['https://attacker.s3.amazonaws.com/p.png?d=summary', 'http://x.r2.dev/a.png', '//evil.example/p.png', '/\\evil.example/p.png', 'data:image/png;base64,AAAA', 'javascript:alert(1)', '']) assert.equal(safeChatImageSrc(bad, MEDIA), null, bad)
  assert.equal(safeChatImageSrc('https://media.example.org/uploads/a.jpg', MEDIA), 'https://media.example.org/uploads/a.jpg')
})

check('C-6: only our media prefix — no query, no escapes, no "..", nothing under /_next/, no same-site paths', () => {
  for (const bad of [
    '/_next/image?url=https%3A%2F%2Fattacker.s3.amazonaws.com%2Fp.png%3Fd%3Dx&w=64&q=75',
    '/_next/image?url=/x',
    '/api/proxy?url=https://evil.example/p.png',
    '/api/media/abc/file.jpg', // a same-site path is not "our media" unless the host lists it
    'https://media.example.org/a.png?d=summary',
    'https://media.example.org/a.png#d=summary',
    'https://media.example.org/%2e%2e/x.png',
    'https://media.example.org/../_next/image',
    'https://media.example.org//evil.example/p.png',
    'https://media.example.org.evil.example/p.png',
    'https://media.example.org/_next/image/x.png',
    'https://media.example.org/a b.png',
  ]) assert.equal(safeChatImageSrc(bad, MEDIA), null, bad)
  assert.equal(safeChatImageSrc('/_next/static/x.png', ['/_next/']), null, 'a /_next/ prefix is never allowed')
  assert.equal(safeChatImageSrc('https://media.example.org/a.png', ['https://media.example.org']), null, 'a prefix must end in "/"')
})

check('links: https or our own site only; the real destination is shown', () => {
  for (const bad of ['javascript:alert(1)', 'data:text/html,x', 'http://evil.example', 'https://user:pw@evil.example', '//evil.example', 'mailto:x@evil.example', 'ftp://x']) assert.equal(safeChatHref(bad, ME), null, bad)
  assert.deepEqual(safeChatHref('/admin/pages', ME), { href: '/admin/pages', external: false, shown: '/admin/pages' })
  assert.deepEqual(safeChatHref(`${ME}/admin/todo?x=1`, ME), { href: `${ME}/admin/todo?x=1`, external: false, shown: '/admin/todo?x=1' })
  const ext = safeChatHref('https://evil.example/collect?d=secret', ME)!
  assert.equal(ext.external, true)
  assert.equal(ext.shown, 'evil.example', 'the host is shown next to the link text')
})

console.log(`\n${n} checks passed`)
