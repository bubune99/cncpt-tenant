/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/chat-text.assert.ts
 */
import assert from 'node:assert/strict'
import { chatText } from './chat-text'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the link seen on staging becomes a markdown link', () => {
  assert.equal(chatText('Stock lives in <a href="/admin/inventory">/admin/inventory</a>.'), 'Stock lives in [/admin/inventory](/admin/inventory).')
  assert.equal(chatText("<a class='x' href='/admin/forms' target=\"_blank\">Forms</a>"), '[Forms](/admin/forms)')
})

check('other formatting tags become markdown; unknown tags are dropped, never shown', () => {
  assert.equal(chatText('<strong>Save</strong> then <em>wait</em><br>Done'), '**Save** then _wait_\nDone')
  assert.equal(chatText('<p>One</p><p>Two</p>'), 'One\n\nTwo\n\n')
  assert.equal(chatText('<ul><li>A</li><li>B</li></ul>'), '\n- A\n- B\n\n')
  assert.equal(chatText('Click <span class="x">Save</span>.'), 'Click Save.')
  assert.ok(!/<[a-z]/i.test(chatText('<div><img src="x.png"><script>x</script></div>')))
})

check('code and plain comparisons are left alone', () => {
  const code = 'Use `<a href="/x">` in a template:\n```html\n<a href="/x">X</a>\n```'
  assert.equal(chatText(code), code)
  assert.equal(chatText('Pick a < b and b > c'), 'Pick a < b and b > c')
  assert.equal(chatText('No tags here.'), 'No tags here.')
})

console.log(`\n${n} checks passed`)
