/**
 * The small "what you're looking at" chip in the assistant's composer:
 * the screen's section ("Blog"), and the item's own title when a screen
 * publishes one ("Blog · My post"). Never an id: a missing or id-looking
 * title falls back to the section alone.
 * Host-agnostic. Pure; asserted by context-label.assert.ts.
 */

/** cuid / uuid / long hex / plain numbers — ids, not names. */
const ID_LIKE = /^(?:c[a-z0-9]{20,}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|[0-9a-f]{24,}|\d+)$/i

export function looksLikeId(text: string): boolean {
  return ID_LIKE.test(text.trim())
}

export function contextLabel(section: string | null | undefined, title: string | null | undefined): string | undefined {
  const s = section?.trim() || ''
  const raw = title?.trim() || ''
  const t = raw && raw !== 'undefined' && raw !== 'null' && !looksLikeId(raw) && raw.toLowerCase() !== s.toLowerCase() ? raw : ''
  if (s && t) return `${s} · ${t}`
  return s || t || undefined
}
