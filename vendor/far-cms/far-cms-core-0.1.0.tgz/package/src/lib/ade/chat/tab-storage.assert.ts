/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/tab-storage.assert.ts
 */
import assert from 'node:assert/strict'
import { readThrough, splitStorage, type KeyValueStore } from './tab-storage'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

function mem(): KeyValueStore & { data: Map<string, string> } {
  const data = new Map<string, string>()
  return { data, getItem: (k) => data.get(k) ?? null, setItem: (k, v) => void data.set(k, v), removeItem: (k) => void data.delete(k) }
}
const save = (st: KeyValueStore, state: Record<string, unknown>) => st.setItem('admin-chat-storage', JSON.stringify({ state, version: 0 }))
const load = (st: KeyValueStore) => JSON.parse(st.getItem('admin-chat-storage') ?? 'null')?.state

check('the active conversation is per tab; mode and history are shared', () => {
  const local = mem()
  const tabA = mem()
  const tabB = mem()
  const A = splitStorage(() => local, () => tabA, ['conversationId'])
  const B = splitStorage(() => local, () => tabB, ['conversationId'])
  save(A, { mode: 'expanded', conversationId: 'conv-A', conversationHistory: [{ id: 'conv-A', title: 'A' }] })
  // A new tab sees the shared prefs and history, but NOT tab A's conversation.
  assert.deepEqual(load(B), { mode: 'expanded', conversationHistory: [{ id: 'conv-A', title: 'A' }] })
  save(B, { ...load(B), conversationId: 'conv-B' })
  assert.equal(load(A).conversationId, 'conv-A')
  assert.equal(load(B).conversationId, 'conv-B')
  assert.ok(!JSON.parse(local.data.get('admin-chat-storage')!).state.conversationId, 'never written to the shared store')
})

check('a reload of the same tab keeps its conversation', () => {
  const local = mem()
  const tab = mem()
  save(splitStorage(() => local, () => tab, ['conversationId']), { mode: 'docked', conversationId: 'conv-1' })
  assert.equal(load(splitStorage(() => local, () => tab, ['conversationId'])).conversationId, 'conv-1')
})

check('an old shared conversationId (from before the split) is ignored: a fresh tab starts its own', () => {
  const local = mem()
  local.setItem('admin-chat-storage', JSON.stringify({ state: { mode: 'expanded', conversationId: 'someone-elses' }, version: 0 }))
  const st = load(splitStorage(() => local, () => mem(), ['conversationId']))
  assert.equal(st.conversationId, undefined)
  assert.equal(st.mode, 'expanded')
})

check('no browser (server render) or broken storage never throws', () => {
  const none = splitStorage(() => undefined, () => undefined, ['conversationId'])
  assert.equal(none.getItem('x'), null)
  save(none, { a: 1 })
  none.removeItem('x')
  const broken: KeyValueStore = { getItem: () => { throw new Error('denied') }, setItem: () => { throw new Error('quota') }, removeItem: () => { throw new Error('x') } }
  const tab = mem()
  const st = splitStorage(() => broken, () => tab, ['conversationId'])
  save(st, { conversationId: 'c', mode: 'm' })
  assert.deepEqual(load(st), { conversationId: 'c' })
  assert.equal(splitStorage(() => mem(), () => mem(), ['conversationId']).getItem('missing'), null)
})

check('preview frames read the person\'s stored state but never write it (read-through, writes in memory)', () => {
  const base = new Map<string, string>([['admin-chat-storage', '{"state":{"mode":"split"}}']])
  const real: KeyValueStore = { getItem: (k) => base.get(k) ?? null, setItem: (k, v) => void base.set(k, v), removeItem: (k) => void base.delete(k) }
  const framed = readThrough(() => real)
  assert.equal(framed.getItem('admin-chat-storage'), '{"state":{"mode":"split"}}', 'starts from the person\'s state')
  framed.setItem('admin-chat-storage', '{"state":{"mode":"collapsed"}}')
  assert.equal(framed.getItem('admin-chat-storage'), '{"state":{"mode":"collapsed"}}', 'the frame sees its own change')
  assert.equal(base.get('admin-chat-storage'), '{"state":{"mode":"split"}}', 'the person\'s storage is untouched')
  framed.removeItem('admin-chat-storage')
  assert.equal(framed.getItem('admin-chat-storage'), null)
  assert.equal(base.has('admin-chat-storage'), true)
})

console.log(`\n${n} checks passed`)
