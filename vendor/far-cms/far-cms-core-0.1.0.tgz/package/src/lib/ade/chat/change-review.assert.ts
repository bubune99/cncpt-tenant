/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/change-review.assert.ts
 */
import assert from 'node:assert/strict'
import {
  actionItem, batchMore, canAct, canUndo, changeSetOf, collapsedRow, headerWord, isFolded, kindLine, kindOf, reviewPathFor, secondaryOf,
  showOnPageHref, showingOnPage, stateOf, unchangedLine, verbOf,
} from './change-review'
import type { ChangeView } from './change-widgets'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const view = (extra: Partial<ChangeView> = {}): ChangeView => ({
  key: 'cs:set1', status: 'pending', entityType: 'Page', entityName: 'About us', href: '/admin/todo/review/set1',
  fields: [{ field: 'title', label: 'Title', before: 'About', after: 'About us' }], more: 0, version: null, revisionId: null,
  canRestore: false, itemIds: ['i1'], canApprove: true, error: null, ...extra,
})

check('kind: things with a look and a render are previews; a batch is a batch; everything else falls back to values', () => {
  assert.equal(kindOf({ target: 'page-content', previewPath: '/ade-preview/about?set=s' }), 'preview')
  assert.equal(kindOf({ target: 'record', previewPath: '/ade-preview/initiatives?set=s' }), 'preview')
  assert.equal(kindOf({ target: 'page-content', previewPath: null }), 'values', 'no render to show → values')
  assert.equal(kindOf({ target: 'site-setting', previewPath: '/x' }), 'values', 'settings have no look')
  assert.equal(kindOf({ target: 'role' }), 'values')
  assert.equal(kindOf({ target: 'something-new', previewPath: '/x' }), 'values', 'unmapped → values, never unsupported')
  assert.equal(kindOf({}), 'values')
  assert.equal(kindOf({ target: 'record', previewPath: '/x', batch: { count: 24, noun: 'products', rows: [] } }), 'batch')
  assert.equal(kindOf({ target: 'record', batch: { count: 1, noun: 'products', rows: [] } }), 'values', 'a batch of one is not a batch')
})

check('state: waiting is Draft; done is Live / Saved / Applied / Sent by kind; rejected or out of date is Not applied', () => {
  assert.equal(stateOf('preview', 'pending'), 'draft')
  assert.equal(stateOf('preview', 'applied'), 'live')
  assert.equal(stateOf('preview', 'applied', false), 'saved', 'a preview that saves a draft is Saved, not Live')
  assert.equal(stateOf('values', 'applied'), 'saved')
  assert.equal(stateOf('batch', 'applied'), 'applied')
  assert.equal(stateOf('action', 'applied'), 'sent')
  assert.equal(stateOf('values', 'rejected'), 'rejected')
  assert.equal(stateOf('values', 'stale'), 'rejected')
  assert.equal(stateOf('values', 'failed'), 'failed')
  assert.equal(headerWord('action', 'draft'), 'Ready to send')
  assert.equal(headerWord('preview', 'draft'), 'Draft')
})

check('words: "Kind · location", the one verb per body, and the text secondary (Reject always reachable)', () => {
  assert.equal(kindLine({ entityType: 'Product', entityName: 'Kente Tote Bag' }), 'Product · Kente Tote Bag')
  assert.equal(kindLine({ entityType: 'Settings', entityName: null }), 'Settings')
  assert.equal(kindLine({ entityType: 'Product', entityName: 'Shop', batch: { count: 24, noun: 'products', rows: [] } }), '24 products · Shop')
  assert.equal(verbOf('preview', {}), 'Publish')
  assert.equal(verbOf('preview', { publishes: false }), 'Approve')
  assert.equal(verbOf('values', {}), 'Save')
  assert.equal(verbOf('batch', { batch: { count: 24, noun: 'products', rows: [] } }), 'Apply to 24')
  assert.deepEqual(secondaryOf('preview'), { keep: 'Keep as draft', reject: 'Reject' })
  assert.deepEqual(secondaryOf('values'), { keep: null, reject: 'Discard' })
  assert.equal(unchangedLine(['Currency', 'Receipts', 'A', 'B', 'C', 'D']), 'Currency, Receipts, 4 more')
  assert.equal(unchangedLine(['Currency']), 'Currency')
  assert.equal(unchangedLine([]), null)
  assert.equal(batchMore(24, 3), '21 more')
  assert.equal(batchMore(3, 3), null)
})

check('acting: only a waiting change this person may approve; Undo only with a revision, the right, and a host undo path', () => {
  assert.equal(canAct(view()), true)
  assert.equal(canAct(view({ canApprove: false })), false)
  assert.equal(canAct(view({ itemIds: [] })), false)
  assert.equal(canAct(view({ status: 'applied' })), false)
  const applied = view({ status: 'applied', revisionId: 'r1', canRestore: true })
  assert.equal(canUndo(applied, true), true)
  assert.equal(canUndo(applied, false), false, 'no undo endpoint on this host → no Undo')
  assert.equal(canUndo({ ...applied, canRestore: false }, true), false)
  assert.equal(canUndo({ ...applied, revisionId: null }, true), false)
})

check('after acting: one row, State · name · Undo / Open; Not applied is dashed; kept drafts fold with Open', () => {
  const live = collapsedRow(view({ status: 'applied', revisionId: 'r1', canRestore: true, href: '/admin/pages/p1' }), 'preview', { hostUndo: true })
  assert.deepEqual(live, { state: 'live', word: 'Live', name: 'About us', action: 'undo', dashed: false })
  assert.equal(collapsedRow(view({ status: 'applied', revisionId: 'r1', canRestore: true, href: '/admin/pages/p1' }), 'preview', { hostUndo: false }).action, 'open')
  const rejected = collapsedRow(view({ status: 'rejected', entityName: null, entityType: 'Settings', href: null }), 'values', { hostUndo: true })
  assert.deepEqual(rejected, { state: 'rejected', word: 'Not applied', name: 'Settings', action: null, dashed: true })
  assert.equal(collapsedRow(view(), 'preview', { hostUndo: true, kept: true }).action, 'open')
  assert.equal(collapsedRow(view({ batch: { count: 24, noun: 'products', rows: [] }, entityName: null }), 'batch', { hostUndo: false }).name, '24 products')
  assert.equal(isFolded(view()), false)
  assert.equal(isFolded(view(), true), true)
  assert.equal(isFolded(view({ status: 'applied' })), true)
})

check('4a / 4b: a waiting preview shows on its page when the workspace has its review open; values never do', () => {
  assert.equal(reviewPathFor('set 1'), '/admin/todo/review/set%201')
  assert.equal(changeSetOf('cs:abc'), 'abc')
  assert.equal(changeSetOf('rev:abc'), null)
  const v = view({ previewPath: '/ade-preview/about?set=set1' })
  assert.equal(showingOnPage(v, 'preview', '/admin/todo/review/set1'), true)
  assert.equal(showingOnPage(v, 'preview', '/admin/todo/review/set1?x=1'), true)
  assert.equal(showingOnPage(v, 'preview', '/admin/pages'), false)
  assert.equal(showingOnPage(v, 'values', '/admin/todo/review/set1'), false, 'values never use 4a')
  assert.equal(showingOnPage({ ...v, status: 'applied' }, 'preview', '/admin/todo/review/set1'), false)
  assert.equal(showOnPageHref(v, 'preview'), '/admin/todo/review/set1')
  assert.equal(showOnPageHref({ ...v, previewPath: null }, 'preview'), null)
  assert.equal(showOnPageHref(v, 'values'), null)
})

check('irreversible approvals become "can\'t be undone" rows that only point at their card; others stay out', () => {
  const email = actionItem({ toolCallId: 'c1', toolName: 'sendCampaign', input: { to: ['a@x.org', 'b@x.org'], subject: 'Clinic build starts Saturday' } })!
  assert.equal(email.callId, 'c1')
  assert.equal(email.state, 'draft')
  assert.match(email.line, /^Email · 2 people$/)
  assert.equal(email.blind, false)
  assert.ok(email.verb.length > 0)
  assert.equal(actionItem({ toolCallId: 'c2', toolName: 'deletePage', input: { title: 'Old page' } })!.line, 'Delete · Old page')
  assert.equal(actionItem({ toolCallId: 'c3', toolName: 'publishPage', input: { title: 'About' } }), null, 'publishing can be taken back: not here')
  assert.equal(actionItem({ toolCallId: 'c4', toolName: 'updateRecord', input: {} }), null, 'a generic approval is not an irreversible action')
  assert.equal(actionItem({ toolCallId: 'c5', toolName: 'sendCampaign', input: { to: 'a@x.org' }, resolved: 'approved' })!.state, 'sent')
  assert.equal(actionItem({ toolCallId: 'c6', toolName: 'sendCampaign', input: { to: 'a@x.org' }, resolved: 'denied' })!.state, 'rejected')
  const blind = actionItem({ toolCallId: 'c7', toolName: 'email_send_draft', input: {} })!
  assert.equal(blind.blind, true, 'an email that can\'t be shown has no Approve anywhere')
})

console.log(`\n${n} checks passed`)
