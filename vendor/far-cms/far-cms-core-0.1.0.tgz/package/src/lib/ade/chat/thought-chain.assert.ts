/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/thought-chain.assert.ts
 */
import assert from 'node:assert/strict'
import { buildChain, genericTitle, resultLine, type ChainDeps } from './thought-chain'
import { newPlan } from './plan'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const tool = (name: string, state: string, input: unknown = {}, output?: unknown, id = name) => ({ type: `tool-${name}`, toolCallId: id, state, input, ...(output !== undefined ? { output } : {}) })
const plan = (input: unknown, state = 'output-available', id = `pl${Math.random()}`) => tool('update_plan', state, input, { ok: true }, id)
const text = (t: string) => ({ type: 'text', text: t })
const DEPS: ChainDeps = {
  titleOf: (name) => ({ read_view: 'Look at the screen', listInitiatives: 'Check the initiatives', spotlight_steps: 'Point it out on screen' } as Record<string, string>)[name] ?? null,
  lookedAtOf: (name) => (name === 'listInitiatives' ? 'The initiatives list' : null),
  manualPathOf: (name) => (name === 'updateRecord' ? 'You can do it yourself: open the record and edit it there.' : null),
}
const states = (c: ReturnType<typeof buildChain>['chain']) => c!.steps.map((s) => s.state).join(',')

check('nothing yet, streaming: the thinking indicator; a plain answer: no chain at all', () => {
  assert.equal(buildChain({ parts: [], planBefore: null, busy: true }).chain!.phase, 'thinking')
  assert.equal(buildChain({ parts: [text('Hi.')], planBefore: null, busy: false }).chain, null)
  assert.equal(buildChain({ parts: [text('Typing…')], planBefore: null, busy: true }).chain, null, 'words streaming: no indicator')
})

check('on the fly: each call is a step with a plain title and a result line; done → folded label', () => {
  const parts = [
    tool('listInitiatives', 'output-available', {}, { initiatives: [1, 2, 3, 4, 5, 6, 7] }, 'a'),
    tool('read_view', 'output-available', {}, { title: 'Media library', units: [] }, 'b'),
    text('6 photos are ready.'),
  ]
  const { chain } = buildChain({ parts, planBefore: null, busy: false, deps: DEPS })
  assert.equal(chain!.style, 'fly')
  assert.equal(chain!.phase, 'done')
  assert.deepEqual(chain!.steps.map((s) => [s.title, s.result]), [['Check the initiatives', 'Found 7'], ['Look at the screen', 'Read “Media library”']])
  assert.equal(chain!.fold, '2 steps')
  assert.equal(chain!.header, undefined, 'no header once done')
})

check('on the fly while running: the latest call is current, header "Working it out"', () => {
  const parts = [tool('listInitiatives', 'output-available', {}, { count: 7 }, 'a'), tool('read_view', 'input-available', {}, undefined, 'b')]
  const { chain } = buildChain({ parts, planBefore: null, busy: true, deps: DEPS })
  assert.equal(states(chain), 'done,current')
  assert.equal(chain!.phase, 'working')
  assert.equal(chain!.header!.title, 'Working it out')
})

check('repeated screen reads are one step, not three', () => {
  const parts = [1, 2, 3].map((i) => tool('read_view', 'output-available', {}, { title: 'Pages' }, `r${i}`))
  assert.equal(buildChain({ parts, planBefore: null, busy: false, deps: DEPS }).chain!.steps.length, 1)
})

check('a pointing step is done once the screen took it — never "waiting"', () => {
  const parts = [tool('spotlight_steps', 'output-available', { steps: [] }, { __requires_client_execution: true, name: 'spotlight_steps' }, 's')]
  const { chain } = buildChain({ parts, planBefore: null, busy: false, deps: DEPS })
  assert.equal(states(chain), 'done')
  assert.equal(chain!.steps[0].result, 'Shown on screen')
})

check('no step title is ever a tool name, with or without app words', () => {
  const names = ['getEntityDetails', 'searchEntities', 'createRecordWithPage', 'updateRecord', 'describe_platform', 'navigateTo', 'read_view', 'mystery_tool', 'vmcp_stats']
  for (const name of names) {
    for (const deps of [{}, DEPS]) {
      const t = buildChain({ parts: [tool(name, 'output-available', {}, { ok: true })], planBefore: null, busy: false, deps }).chain!.steps[0].title
      assert.ok(!t.includes(name) && !/[_A-Z]{2,}|[a-z][A-Z]/.test(t.slice(1)), `${name} → "${t}"`)
    }
  }
  assert.equal(genericTitle('createBlogPost', 'draft'), 'Draft a new blog post')
  assert.equal(genericTitle('listForms', 'read'), 'Check the forms')
  assert.equal(genericTitle('zzz', 'read'), 'Look something up')
  // Whole first word only: no prefix matches inside a word.
  assert.equal(genericTitle('address_lookup', 'read'), 'Look something up')
  assert.equal(genericTitle('settingsPanel', 'read'), 'Look something up')
  assert.equal(genericTitle('countryList', 'read'), 'Look something up')
})

check('result lines are short code-made facts, never the payload', () => {
  assert.equal(resultLine('updateRecord', { drafted: true, changeSetId: 'x' }), 'Drafted, not live')
  assert.equal(resultLine('searchEntities', { count: 3, results: [] }), 'Found 3')
  assert.equal(resultLine('navigate_to_route', { ok: true }), 'Opened it')
  assert.equal(resultLine('getSiteContext', { name: 'x'.repeat(400) }), 'Done')
})

check('planned: the plan shows first ("Plan · 5 steps · nothing goes live without your OK")', () => {
  const parts = [plan({ action: 'start', steps: ['Look for an existing Ho visit', 'Draft the initiative page', 'Add photos', 'Draft a home card', 'Ask for your OK'] })]
  const { chain, planAfter } = buildChain({ parts, planBefore: null, busy: true, deps: DEPS })
  assert.equal(chain!.style, 'planned')
  assert.equal(chain!.phase, 'plan')
  assert.deepEqual(chain!.header, { title: 'Plan', sub: '5 steps · nothing goes live without your OK' })
  assert.equal(states(chain), 'current,ahead,ahead,ahead,ahead')
  assert.equal(planAfter!.steps.length, 5)
})

check('planned work is filed under the current step; progress gives its result; trace = recorded facts', () => {
  const parts = [
    plan({ action: 'start', steps: ['Look for an existing Ho visit', 'Draft the initiative page', 'Ask for your OK'] }),
    tool('listInitiatives', 'output-available', {}, { count: 7 }, 'l'),
    plan({ action: 'progress', step: 1, result: 'Checked 7 initiatives. None is about Ho.' }),
    tool('updateRecord', 'output-available', {}, { drafted: true }, 'u'),
    plan({ action: 'progress', step: 2, result: 'Title, region and stage. Not live.' }),
  ]
  const { chain } = buildChain({ parts, planBefore: null, busy: true, deps: DEPS })
  assert.equal(chain!.phase, 'working')
  assert.deepEqual(chain!.header, { title: 'Working', sub: 'step 3 of 3' })
  assert.equal(states(chain), 'done,done,current')
  const [a, b] = chain!.steps
  assert.equal(a.result, 'Checked 7 initiatives. None is about Ho.')
  assert.deepEqual(a.trace, { lookedAt: ['The initiatives list'], result: 'Checked 7 initiatives. None is about Ho.', effect: 'read' })
  assert.equal(b.tag, 'Drafted')
  assert.equal(b.trace!.effect, 'draft')
  assert.equal(chain!.steps[2].trace, undefined, 'a step not finished has nothing to open yet')
})

check('an approval card makes the current step "needs you"; done run folds with "needs you"', () => {
  const parts = [
    plan({ action: 'start', steps: ['Draft the page', 'Ask for your OK'] }),
    tool('updateRecord', 'output-available', {}, { drafted: true }, 'u'),
    plan({ action: 'progress', step: 1 }),
    tool('publishRecord', 'approval-requested', { id: 'r1' }, undefined, 'p'),
    text('It is waiting for your OK.'),
  ]
  const { chain } = buildChain({ parts, planBefore: null, busy: false, deps: DEPS })
  assert.equal(chain!.phase, 'done')
  assert.equal(states(chain), 'done,needs-you')
  assert.equal(chain!.steps[1].tag, 'Waiting on you')
  assert.equal(chain!.steps[1].trace!.effect, 'needs-you')
  assert.equal(chain!.fold, '2 steps · needs you')
})

check('Haiku adds a step along the way: "+ Added a step" note, the new step in place', () => {
  const parts = [
    plan({ action: 'start', steps: ['Add photos', 'Draft a home card'] }),
    plan({ action: 'progress', step: 1 }),
    plan({ action: 'amend', add: [{ title: 'Check the photo sizes', after: 1 }] }),
  ]
  const { chain } = buildChain({ parts, planBefore: null, busy: true, deps: DEPS })
  assert.deepEqual(chain!.steps.map((s) => s.title), ['Add photos', 'Check the photo sizes', 'Draft a home card'])
  assert.deepEqual(chain!.notes, ['+ Added a step: Check the photo sizes'])
})

check('the five interruptions on a plan from an earlier reply', () => {
  const before = newPlan(['A', 'B', 'C', 'D', 'E'])!
  // side: no list repeated, just the way back
  const side = buildChain({ parts: [plan({ action: 'side' }), text('It drafts a page.')], planBefore: before, busy: false }).chain!
  assert.deepEqual(side.steps, [])
  assert.equal(side.back, 'Back to the plan (1 of 5)')
  // amend: skip C → struck through
  const amend = buildChain({ parts: [plan({ action: 'amend', skip: [3] })], planBefore: before, busy: false }).chain!
  assert.equal(states(amend), 'ahead,ahead,skipped,ahead,ahead')
  assert.match(amend.notes[0], /^Skipped a step: C/)
  assert.equal(amend.fold, '5 steps · 1 skipped')
  // replace: new plan, note on the old one
  const rep = buildChain({ parts: [plan({ action: 'replace', steps: ['Open the forms', 'Point at the contact form'] })], planBefore: before, busy: true }).chain!
  assert.deepEqual(rep.steps.map((s) => s.title), ['Open the forms', 'Point at the contact form'])
  assert.match(rep.notes[0], /^Plan replaced: the earlier plan stopped after 0 of 5 steps/)
  // pause: header "Paused", nothing spins
  const pause = buildChain({ parts: [plan({ action: 'pause' })], planBefore: before, busy: false }).chain!
  assert.equal(pause.phase, 'paused')
  assert.deepEqual(pause.header, { title: 'Paused', sub: 'at step 1 of 5 · nothing changed' })
  assert.ok(!pause.steps.some((s) => s.state === 'current'))
  // stop
  const stop = buildChain({ parts: [plan({ action: 'stop' }), text('Stopped.')], planBefore: before, busy: false }).chain!
  assert.equal(stop.phase, 'stopped')
  assert.match(stop.notes[0], /^Stopped\. 0 steps done; 5 not touched/)
})

check('a plain reply while a plan is open does not repeat the plan', () => {
  const before = newPlan(['A', 'B'])!
  assert.equal(buildChain({ parts: [text('Sure.')], planBefore: before, busy: false }).chain, null)
})

check('a failed step: amber "!", the problem said together with the manual path', () => {
  const parts = [tool('updateRecord', 'output-available', {}, { success: false, error: 'Record not found' }, 'u'), text('That did not work.')]
  const { chain } = buildChain({ parts, planBefore: null, busy: false, deps: DEPS })
  assert.equal(states(chain), 'needs-you')
  assert.equal(chain!.steps[0].problem, true)
  assert.equal(chain!.steps[0].result, 'Didn’t work: Record not found')
  assert.deepEqual(chain!.problem, { text: 'Couldn’t finish “Draft changes to the record”. Nothing else was changed.', manual: 'You can do it yourself: open the record and edit it there.' })
  // A private screen read is an answer, not a problem.
  const priv = buildChain({ parts: [tool('read_view', 'output-available', {}, { ok: false, private: true })], planBefore: null, busy: false, deps: DEPS }).chain!
  assert.equal(priv.problem, undefined)
})

check('a declined card is a skipped step, not a failure', () => {
  const { chain } = buildChain({ parts: [tool('publishRecord', 'output-denied', {}, undefined, 'p')], planBefore: null, busy: false, deps: DEPS })
  assert.equal(states(chain), 'skipped')
  assert.equal(chain!.steps[0].result, 'Not done: you said no')
  assert.equal(chain!.problem, undefined)
})

check('plumbing (load_tools, the plan tool itself) is never a step', () => {
  const { chain } = buildChain({ parts: [tool('load_tools', 'output-available', { groups: ['pages'] }, { loaded: ['pages'] })], planBefore: null, busy: false })
  assert.equal(chain, null)
})

check('a half-streamed plan call changes nothing yet', () => {
  const { chain } = buildChain({ parts: [plan({ action: 'start', steps: ['A'] }, 'input-streaming')], planBefore: null, busy: true })
  assert.equal(chain!.phase, 'thinking')
})

check('replace mid-message: the work done under the old plan stays visible, before the new plan', () => {
  const parts = [
    plan({ action: 'start', steps: ['A', 'B'] }),
    tool('listInitiatives', 'output-available', {}, { count: 7 }, 'l'),
    plan({ action: 'replace', steps: ['C', 'D'] }),
  ]
  const { chain } = buildChain({ parts, planBefore: null, busy: true, deps: DEPS })
  assert.deepEqual(chain!.steps.map((s) => s.title), ['Check the initiatives', 'C', 'D'])
  assert.equal(chain!.steps[0].state, 'done')
})

check('a side question with a lookup: the lookup is its own step, not filed under the plan', () => {
  const before = newPlan(['A', 'B'])!
  const parts = [plan({ action: 'side' }), tool('listInitiatives', 'output-available', {}, { count: 2 }, 'l'), text('There are 2.')]
  const { chain, planAfter } = buildChain({ parts, planBefore: before, busy: false, deps: DEPS })
  assert.deepEqual(chain!.steps.map((s) => s.title), ['Check the initiatives'])
  assert.equal(chain!.back, 'Back to the plan (1 of 2)')
  assert.equal(planAfter, before, 'the plan is untouched')
})

check('a waiting approval is never merged away by a later call with the same title', () => {
  const parts = [tool('publishRecord', 'approval-requested', {}, undefined, 'a'), tool('publishRecord', 'output-available', {}, { ok: true }, 'b')]
  assert.equal(states(buildChain({ parts, planBefore: null, busy: false }).chain), 'needs-you,done')
})

check('an answered "no" is skipped; a call without an id still gets a unique key', () => {
  const no = buildChain({ parts: [{ ...tool('publishRecord', 'approval-responded', {}, undefined, 'a'), approval: { id: 'x', approved: false } }], planBefore: null, busy: false }).chain!
  assert.equal(states(no), 'skipped')
  const ids = buildChain({ parts: [{ type: 'tool-read_view', state: 'output-available', output: {} }, { type: 'tool-listForms', state: 'output-available', output: {} }, { type: 'tool-read_view', state: 'output-available', output: {} }], planBefore: null, busy: false }).chain!.steps.map((s) => s.id)
  assert.equal(new Set(ids).size, ids.length)
})

check('a private read says so', () => {
  assert.equal(resultLine('read_view', { ok: false, private: true }), 'Private, so not read')
})

check('a finished reply that never touched the open plan ends it; a streaming one or a side question keeps it', () => {
  const before = newPlan(['A', 'B'])!
  assert.equal(buildChain({ parts: [text('Sure.')], planBefore: before, busy: false }).planAfter!.status, 'ended')
  assert.equal(buildChain({ parts: [], planBefore: before, busy: true }).planAfter!.status, 'active')
  assert.equal(buildChain({ parts: [plan({ action: 'side' }), text('It drafts a page.')], planBefore: before, busy: false }).planAfter!.status, 'active')
})

check('a plan shown first: phase "proposed", every step ahead, "nothing runs until you say go"; Go makes it run', () => {
  const parts = [plan({ action: 'propose', steps: ['Fill “Name”', 'Fill “Location”', 'Propose it for review'] })]
  const { chain, planAfter } = buildChain({ parts, planBefore: null, busy: false })
  assert.equal(chain!.phase, 'proposed')
  assert.deepEqual(chain!.header, { title: 'Plan', sub: '3 steps · nothing runs until you say go' })
  assert.equal(states(chain), 'ahead,ahead,ahead')
  assert.equal(planAfter!.status, 'waiting')
  const go = buildChain({ parts: [plan({ action: 'go' }), tool('read_view', 'output-available', {}, { title: 'X' }, 'r')], planBefore: planAfter, busy: true, deps: DEPS }).chain!
  assert.equal(go.phase, 'working')
  assert.equal(go.steps[0].state, 'current')
})

check('c6c4 P4: a proposed plan shows alone — the look-ups before it are not left under the card', () => {
  const parts = [tool('read_view', 'output-available', {}, { title: 'X' }, 'r'), plan({ action: 'propose', steps: ['A', 'B'] })]
  const { chain } = buildChain({ parts, planBefore: null, busy: false, deps: DEPS })
  assert.equal(chain!.phase, 'proposed')
  assert.deepEqual(chain!.steps.map((s) => s.title), ['A', 'B'])
})

// Seen 2026-11-16 on staging: a picture saved straight to the media library was tagged "Drafted, not live".
check('a step that saved (a recorded revision) says Saved; only a change-set draft says Drafted', () => {
  const saved = { success: true, changes: [{ kind: 'revision', revisionId: 'rev1', entityType: 'media', entityId: 'm1', version: 1 }] }
  const { chain } = buildChain({ parts: [tool('generateImage', 'output-available', {}, saved, 'g')], planBefore: null, busy: false, deps: DEPS })
  const step = chain!.steps[0]
  assert.equal(step.tag, 'Saved')
  assert.equal(step.trace!.effect, 'saved')
  assert.equal(step.result, 'Saved')
  const drafted = buildChain({ parts: [tool('updateRecord', 'output-available', {}, { drafted: true, changeSetId: 'cs1' }, 'u')], planBefore: null, busy: false, deps: DEPS }).chain!.steps[0]
  assert.equal(drafted.tag, 'Drafted')
})

// Seen 2026-11-16 on staging: a failed generateImage read "Couldn't finish 'Look something up'".
check('making a picture and importing code have their own step titles', () => {
  assert.equal(genericTitle('generateImage', 'read'), 'Make a picture')
  assert.equal(genericTitle('importPageCode', 'draft'), 'Draft the import of page code')
})

console.log(`\n${n} checks passed`)
