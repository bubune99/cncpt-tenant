/**
 * Several assistant conversations at once, as tabs. Each thread is its own
 * conversation (own id → own history and audit trail on the server; the
 * per-user token budget covers them all). A thread working in the
 * background reports into To-do when it finishes or needs approval.
 *
 * Host-agnostic. Pure; asserted by threads.assert.ts.
 */

export type ThreadStatus = 'idle' | 'thinking' | 'waiting' | 'done' | 'error'

export interface Thread {
  id: string
  title: string
  status: ThreadStatus
  /** Tokens this thread has used (from the server's per-turn usage), 0 if unknown. */
  tokens: number
  createdAt: number
  /** Started here, never saved yet: nothing to load from the server. */
  fresh?: boolean
  /** Opened from history or a saved link: a 404 means it was deleted, not that it was never sent. */
  saved?: boolean
}

export const MAX_THREADS = 4

export const STATUS_LABEL: Record<ThreadStatus, string> = {
  idle: 'New',
  thinking: 'Thinking',
  waiting: 'Waiting for you',
  done: 'Done',
  error: 'Stopped',
}

/** What the chat hook reports, reduced to what decides the status. */
export interface ChatSignals {
  /** AI SDK useChat status. */
  chatStatus: 'submitted' | 'streaming' | 'ready' | 'error'
  /** An approval request is waiting for an answer. */
  pendingApproval: boolean
  messageCount: number
}

export function deriveStatus(s: ChatSignals): ThreadStatus {
  if (s.chatStatus === 'submitted' || s.chatStatus === 'streaming') return 'thinking'
  if (s.pendingApproval) return 'waiting'
  if (s.chatStatus === 'error') return 'error'
  return s.messageCount > 0 ? 'done' : 'idle'
}

export interface ThreadReport {
  kind: 'done' | 'waiting' | 'error'
  title: string
  detail: string
}

/**
 * Should a status change go to To-do? Only for threads in the background
 * (the person isn't looking), and only on the way out of "thinking".
 */
export function reportFor(prev: ThreadStatus, next: ThreadStatus, thread: Pick<Thread, 'title'>, active: boolean): ThreadReport | null {
  if (active || prev !== 'thinking' || next === 'thinking') return null
  const name = thread.title || 'Assistant task'
  if (next === 'waiting') return { kind: 'waiting', title: `Approve to continue: ${name}`, detail: 'An assistant thread is waiting for your approval.' }
  if (next === 'done') return { kind: 'done', title: `Assistant finished: ${name}`, detail: 'Open the thread to see what it did.' }
  if (next === 'error') return { kind: 'error', title: `Assistant stopped: ${name}`, detail: 'The thread hit a problem — open it to retry.' }
  return null
}

/** A tab title from the first thing asked. */
export function titleFrom(text: string, max = 28): string {
  const t = text.replace(/\s+/g, ' ').trim()
  if (!t) return 'New thread'
  return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t
}

export function newThread(id: string, now: number, title = 'New thread'): Thread {
  return { id, title, status: 'idle', tokens: 0, createdAt: now }
}

export type AddResult = { ok: true; threads: Thread[] } | { ok: false; error: string }

export function addThread(threads: readonly Thread[], thread: Thread): AddResult {
  if (threads.some((t) => t.id === thread.id)) return { ok: true, threads: [...threads] }
  if (threads.length >= MAX_THREADS) return { ok: false, error: `Up to ${MAX_THREADS} threads at once — close one that’s done first.` }
  return { ok: true, threads: [...threads, thread] }
}

/** Close a thread; the last one can't close (it becomes a fresh thread instead). Returns the next active id. */
export function closeThread(threads: readonly Thread[], id: string, activeId: string): { threads: Thread[]; activeId: string } {
  const i = threads.findIndex((t) => t.id === id)
  if (i < 0 || threads.length <= 1) return { threads: [...threads], activeId }
  const next = threads.filter((t) => t.id !== id)
  const nextActive = activeId === id ? next[Math.min(i, next.length - 1)].id : activeId
  return { threads: next, activeId: nextActive }
}

/** Closing a thread that's still working stops it — ask first. */
export function closeNeedsConfirm(t: Pick<Thread, 'status'>): boolean {
  return t.status === 'thinking'
}

export function patchThread(threads: readonly Thread[], id: string, patch: Partial<Omit<Thread, 'id'>>): Thread[] {
  let changed = false
  const out = threads.map((t) => {
    if (t.id !== id) return t
    const keys = Object.keys(patch) as Array<keyof typeof patch>
    if (keys.every((k) => t[k] === patch[k])) return t
    changed = true
    return { ...t, ...patch }
  })
  return changed ? out : (threads as Thread[])
}

/** Sum the per-turn usage the server attaches to assistant messages. */
export function tokensUsed(messages: ReadonlyArray<{ role: string; metadata?: unknown }>): number {
  let n = 0
  for (const m of messages) {
    if (m.role !== 'assistant') continue
    const t = (m.metadata as { usage?: { totalTokens?: unknown } } | undefined)?.usage?.totalTokens
    if (typeof t === 'number' && Number.isFinite(t) && t > 0) n += t
  }
  return n
}

/** "12k tokens" — compact, for the tab tooltip. */
export function formatTokens(n: number): string {
  if (n <= 0) return ''
  return n >= 1000 ? `${Math.round(n / 100) / 10}k tokens` : `${n} tokens`
}
