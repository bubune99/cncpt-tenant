/**
 * Links and images in the assistant's text — pure; asserted.
 *
 * The assistant's text can be steered by content it read (an email, a
 * page). An image tag would make the browser fetch a URL by itself — a
 * zero-click way to send what it read to someone else — so the chat shows
 * no remote images at all. Links open only on a click, only to https or
 * our own site, and show where they really go.
 */

/** A link we may render: same-site paths and https only. Null → plain text. */
export function safeChatHref(href: unknown, ownOrigin: string): { href: string; external: boolean; shown: string } | null {
  if (typeof href !== 'string') return null
  const h = href.trim()
  if (!h || h.length > 2048) return null
  if (h.startsWith('/') && !h.startsWith('//') && !h.startsWith('/\\')) return { href: h, external: false, shown: h }
  let u: URL
  try {
    u = new URL(h)
  } catch {
    return null
  }
  if (u.origin === ownOrigin) return { href: u.toString(), external: false, shown: u.pathname + u.search }
  if (u.protocol !== 'https:' || u.username || u.password) return null
  return { href: u.toString(), external: true, shown: u.host }
}

/**
 * An image in the assistant's text: rendered only when it is the app's OWN
 * media — the URL starts with one of `mediaPrefixes` (an exact origin+path
 * prefix ending in "/", supplied by the host app) and is a plain file path:
 * no query, no fragment, no escapes, no "..", nothing under /_next/. Anything
 * else (a remote host, the image optimizer or any ?url= proxy, which would
 * make the server fetch for it) shows its alt text instead.
 */
export function safeChatImageSrc(src: unknown, mediaPrefixes: readonly string[]): string | null {
  if (typeof src !== 'string') return null
  const s = src.trim()
  if (!s || s.length > 2048) return null
  if (/[?#%\\\s]/.test(s) || /\/\.\.?(\/|$)/.test(s) || /\/_next\//i.test(s)) return null
  const prefix = mediaPrefixes.find((p) => p.endsWith('/') && !/\/_next\//i.test(p) && s.startsWith(p))
  if (!prefix) return null
  const rest = s.slice(prefix.length)
  if (!rest || rest.startsWith('/')) return null
  return s
}
