/**
 * What a reply's pointing calls asked for and what the page answered, kept in
 * the assistant message's metadata (ai_messages.metadata.spotCalls), so a
 * failed point can be read from the DB later (staging 2026-11-05: the rows
 * kept no parts, so nothing showed what was asked or answered).
 *
 * A row that ends at the call keeps it as `pending` (its targets); the row the
 * continuation saves carries the page's answer. Bounded and clipped: the
 * outputs come from the browser.
 *
 * Pure. Asserted by spot-record.assert.ts.
 */

export interface SpotCallRecord {
  id: string
  /** The targets the model sent. */
  targets: string[]
  /** pending = the page hasn't answered in this row; else what it said. */
  status: 'pending' | 'shown' | 'failed'
  reason?: string
  shown?: string
  substituted?: boolean
  /** The selectors the page actually looked for (names mapped to menu sections). */
  aimed?: string[]
  ms?: number
  error?: string
}

const MAX_CALLS = 12
const MAX_TARGETS = 12
const clip = (v: unknown, n: number): string | undefined => (typeof v === 'string' && v ? v.slice(0, n) : undefined)
const strs = (v: unknown, n: number): string[] => (Array.isArray(v) ? v.flatMap((x) => (typeof x === 'string' ? [x.slice(0, n)] : [])).slice(0, MAX_TARGETS) : [])

export function spotCallRecords(parts: readonly unknown[]): SpotCallRecord[] {
  const out: SpotCallRecord[] = []
  for (const raw of parts) {
    const p = (raw ?? {}) as Record<string, unknown>
    if (p.type !== 'tool-spotlight_steps' || typeof p.toolCallId !== 'string') continue
    const input = (p.input ?? {}) as { steps?: unknown }
    const targets = Array.isArray(input.steps) ? input.steps.flatMap((s) => (s && typeof (s as { target?: unknown }).target === 'string' ? [String((s as { target: string }).target).slice(0, 200)] : [])).slice(0, MAX_TARGETS) : []
    const rec: SpotCallRecord = { id: p.toolCallId.slice(0, 80), targets, status: 'pending' }
    if (p.state === 'output-available' && p.output && typeof p.output === 'object') {
      const o = p.output as Record<string, unknown>
      rec.status = o.ok === true ? 'shown' : 'failed'
      const reason = clip(o.reason, 40)
      if (reason) rec.reason = reason
      const shown = clip(o.shown, 120)
      if (shown) rec.shown = shown
      if (o.substituted === true) rec.substituted = true
      const trace = (o.trace ?? {}) as { aimed?: unknown; ms?: unknown }
      const aimed = strs(trace.aimed, 200)
      if (aimed.length) rec.aimed = aimed
      if (typeof trace.ms === 'number' && Number.isFinite(trace.ms)) rec.ms = Math.max(0, Math.round(trace.ms))
      const error = clip(o.error, 300)
      if (error) rec.error = error
    } else if (p.state === 'output-error') {
      rec.status = 'failed'
      rec.reason = 'error'
      const error = clip(p.errorText, 300)
      if (error) rec.error = error
    }
    out.push(rec)
  }
  return out.slice(-MAX_CALLS)
}
