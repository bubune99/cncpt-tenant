/**
 * Files in the assistant chat: what may be attached, how big, and how each
 * kind reaches the model. Images and PDFs go to the media library and are
 * sent as file parts (the model reads them); plain-text documents are read
 * in the browser and sent as text. Older turns keep a short note instead of
 * the file, so a long conversation doesn't resend every image.
 *
 * Host-agnostic (no app imports) so the ADE can be ported. Pure; asserted
 * by attachments.assert.ts.
 */

export type AttachmentKind = 'image' | 'pdf' | 'text'

export interface AttachRule {
  kind: AttachmentKind
  mediaTypes: readonly string[]
  extensions: readonly string[]
  maxBytes: number
  label: string
}

const MB = 1024 * 1024

export const ATTACH_RULES: readonly AttachRule[] = [
  { kind: 'image', mediaTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'], extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif'], maxBytes: 5 * MB, label: 'Images' },
  { kind: 'pdf', mediaTypes: ['application/pdf'], extensions: ['pdf'], maxBytes: 10 * MB, label: 'PDFs' },
  { kind: 'text', mediaTypes: ['text/plain', 'text/markdown', 'text/csv', 'application/json'], extensions: ['txt', 'md', 'markdown', 'csv', 'json'], maxBytes: 200 * 1024, label: 'Text files' },
]

/** At most this many files per message. */
export const MAX_FILES_PER_MESSAGE = 5
/** Text read from a document is cut to this many characters (the request has a size cap). */
export const MAX_TEXT_CHARS = 20_000
/** Inline screenshots (click-to-reference) must stay under this. */
export const MAX_INLINE_IMAGE_BYTES = 400 * 1024
/** File parts kept for the model in this many most recent user turns. */
export const KEEP_FILES_FOR_TURNS = 2

/** The `accept` attribute for the file picker. */
export const ACCEPT = ATTACH_RULES.flatMap((r) => [...r.mediaTypes, ...r.extensions.map((e) => `.${e}`)]).join(',')

function formatBytes(n: number): string {
  return n >= MB ? `${Math.round((n / MB) * 10) / 10} MB` : `${Math.round(n / 1024)} KB`
}

const EXT_TYPE: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  gif: 'image/gif',
  pdf: 'application/pdf',
  txt: 'text/plain',
  md: 'text/markdown',
  markdown: 'text/markdown',
  csv: 'text/csv',
  json: 'application/json',
}

export type FileCheck = { ok: true; kind: AttachmentKind; mediaType: string } | { ok: false; error: string }

/**
 * Can this file be attached? Browsers often leave `type` empty for .md/.csv,
 * so the extension decides when the type is missing or generic.
 */
export function classifyFile(file: { name: string; type: string; size: number }): FileCheck {
  const ext = file.name.toLowerCase().split('.').pop() ?? ''
  const claimed = (file.type || '').toLowerCase()
  const type = claimed === 'image/jpg' ? 'image/jpeg' : claimed
  const byType = ATTACH_RULES.find((r) => r.mediaTypes.includes(type))
  const byExt = ATTACH_RULES.find((r) => r.extensions.includes(ext))
  const rule = byType ?? (type === '' || type === 'application/octet-stream' ? byExt : undefined)
  if (!rule) {
    if (['doc', 'docx', 'odt', 'pages', 'rtf'].includes(ext)) return { ok: false, error: `“${file.name}” is a Word-style document — save it as PDF and attach that.` }
    if (['heic', 'heif', 'tif', 'tiff', 'bmp', 'svg'].includes(ext)) return { ok: false, error: `“${file.name}” can’t be read — use PNG, JPG, WebP or GIF.` }
    return { ok: false, error: `“${file.name}” isn’t a kind of file the assistant can read. Attach images, PDFs or text files.` }
  }
  if (file.size === 0) return { ok: false, error: `“${file.name}” is empty.` }
  if (file.size > rule.maxBytes) return { ok: false, error: `“${file.name}” is ${formatBytes(file.size)} — ${rule.label.toLowerCase()} can be up to ${formatBytes(rule.maxBytes)}.` }
  return { ok: true, kind: rule.kind, mediaType: byType ? type : EXT_TYPE[ext] }
}

/** Check a whole selection against what's already attached; returns the ones to add and plain errors. */
export function admitFiles<F extends { name: string; type: string; size: number }>(
  files: readonly F[],
  alreadyAttached: number
): { accepted: Array<{ file: F; kind: AttachmentKind; mediaType: string }>; errors: string[] } {
  const accepted: Array<{ file: F; kind: AttachmentKind; mediaType: string }> = []
  const errors: string[] = []
  for (const f of files) {
    const c = classifyFile(f)
    if (!c.ok) {
      errors.push(c.error)
      continue
    }
    if (alreadyAttached + accepted.length >= MAX_FILES_PER_MESSAGE) {
      errors.push(`Up to ${MAX_FILES_PER_MESSAGE} files per message — “${f.name}” wasn’t added.`)
      continue
    }
    accepted.push({ file: f, kind: c.kind, mediaType: c.mediaType })
  }
  return { accepted, errors }
}

/** A ready attachment, as the composer holds it. */
export interface ReadyAttachment {
  name: string
  kind: AttachmentKind
  mediaType: string
  /** Media library URL (image / pdf). */
  url?: string
  /** Document text (text kind). */
  text?: string
}

/**
 * A picture chosen from the media library ("+ › Add from the media library"):
 * already stored, so it is ready at once. Images only (what the picker
 * offers); anything else → null.
 */
export function libraryAttachment(url: string): ReadyAttachment | null {
  if (typeof url !== 'string' || !url.trim()) return null
  let path: string
  try {
    path = new URL(url, 'http://local').pathname
  } catch {
    return null
  }
  const name = decodeURIComponent(path.split('/').filter(Boolean).pop() ?? '')
  const ext = name.toLowerCase().split('.').pop() ?? ''
  const image = ATTACH_RULES.find((r) => r.kind === 'image')
  if (!name || !image?.extensions.includes(ext)) return null
  return { name, kind: 'image', mediaType: EXT_TYPE[ext], url }
}

export type ChatPart =
  | { type: 'text'; text: string }
  | { type: 'file'; mediaType: string; url: string; filename?: string }

/** The message parts for a set of attachments. */
export function attachmentParts(list: readonly ReadyAttachment[]): ChatPart[] {
  const parts: ChatPart[] = []
  for (const a of list) {
    if (a.kind === 'text') {
      const body = (a.text ?? '').slice(0, MAX_TEXT_CHARS)
      const cut = (a.text ?? '').length > MAX_TEXT_CHARS ? '\n[… the rest was cut to keep the message small]' : ''
      parts.push({ type: 'text', text: `Attached file “${a.name}”:\n\`\`\`\n${body}${cut}\n\`\`\`` })
    } else if (a.url) {
      parts.push({ type: 'file', mediaType: a.mediaType, url: a.url, filename: a.name })
    }
  }
  return parts
}

interface PartLike {
  type: string
  [k: string]: unknown
}
interface MessageLike {
  role: string
  parts?: PartLike[]
}

/** Older user turns keep a short note instead of the file (images are expensive to resend). */
export function pruneAttachments<M extends MessageLike>(messages: readonly M[], keepTurns = KEEP_FILES_FOR_TURNS): M[] {
  let userSeen = 0
  const keepFrom = new Set<number>()
  for (let i = messages.length - 1; i >= 0; i--) {
    if (messages[i].role !== 'user') continue
    if (userSeen < keepTurns) keepFrom.add(i)
    userSeen++
  }
  return messages.map((m, i) => {
    if (m.role !== 'user' || keepFrom.has(i) || !m.parts?.some((p) => p.type === 'file')) return m
    return {
      ...m,
      parts: m.parts.map((p) =>
        p.type === 'file' ? { type: 'text', text: `[Earlier attachment: ${typeof p.filename === 'string' && p.filename ? p.filename : String(p.mediaType ?? 'file')}]` } : p
      ),
    }
  })
}

export interface AttachmentPolicy {
  /** Hosts media library files are served from. */
  allowedHosts: readonly string[]
  maxInlineBytes?: number
}

const INLINE = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/

/**
 * Server-side check of every file part: a media-library URL (https, known
 * host, allowed type) or a small inline screenshot. Returns the URLs the
 * host should confirm exist in its media library.
 */
export function checkAttachmentParts(messages: readonly MessageLike[], policy: AttachmentPolicy): { ok: true; urls: string[] } | { ok: false; error: string } {
  const allowedTypes = new Set(ATTACH_RULES.filter((r) => r.kind !== 'text').flatMap((r) => r.mediaTypes))
  const maxInline = policy.maxInlineBytes ?? MAX_INLINE_IMAGE_BYTES
  const urls: string[] = []
  for (const m of messages) {
    const files = (m.parts ?? []).filter((p) => p.type === 'file')
    // Files plus up to 4 click-to-reference screenshots.
    if (files.length > MAX_FILES_PER_MESSAGE + 4) return { ok: false, error: 'Too many attachments in one message.' }
    for (const p of files) {
      const url = typeof p.url === 'string' ? p.url : ''
      const mediaType = typeof p.mediaType === 'string' ? p.mediaType.toLowerCase() : ''
      const inline = INLINE.exec(url)
      if (inline) {
        if (inline[1] !== mediaType) return { ok: false, error: 'An attached picture has the wrong type.' }
        if (Math.floor((inline[2].length * 3) / 4) > maxInline) return { ok: false, error: 'An attached screenshot is too large.' }
        continue
      }
      if (!allowedTypes.has(mediaType)) return { ok: false, error: 'That kind of attachment isn’t supported.' }
      let u: URL
      try {
        u = new URL(url)
      } catch {
        return { ok: false, error: 'An attachment link is broken.' }
      }
      if (u.protocol !== 'https:' || !policy.allowedHosts.includes(u.host)) return { ok: false, error: 'Attachments must come from the media library.' }
      urls.push(url)
    }
  }
  return { ok: true, urls: [...new Set(urls)] }
}

/** A short line for the saved conversation ("[Attached: menu.pdf, logo.png]"). */
export function attachmentNote(parts: readonly PartLike[] | undefined): string {
  const names = (parts ?? []).filter((p) => p.type === 'file').map((p) => (typeof p.filename === 'string' && p.filename ? p.filename : 'screenshot'))
  return names.length ? `[Attached: ${names.join(', ')}]` : ''
}
