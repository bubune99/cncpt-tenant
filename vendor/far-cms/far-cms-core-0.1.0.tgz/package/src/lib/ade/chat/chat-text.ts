/**
 * Assistant text before it is rendered as markdown: HTML the model wrote
 * (seen: `<a href="/admin/inventory">/admin/inventory</a>` shown as literal
 * text) becomes markdown, and any other tag is dropped, so raw tags never
 * show as text. Code (fenced or inline) is left exactly as written.
 *
 * Pure; asserted by chat-text.assert.ts.
 */

const CODE = /(```[\s\S]*?```|`[^`\n]*`)/g

function prose(s: string): string {
  return s
    .replace(/<a\b[^>]*?\bhref\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a\s*>/gi, (_m, href: string, label: string) => {
      const text = label.replace(/<[^>]+>/g, '').trim() || href
      return `[${text}](${href})`
    })
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<(strong|b)\b[^>]*>([\s\S]*?)<\/\1\s*>/gi, '**$2**')
    .replace(/<(em|i)\b[^>]*>([\s\S]*?)<\/\1\s*>/gi, '_$2_')
    .replace(/<code\b[^>]*>([\s\S]*?)<\/code\s*>/gi, '`$1`')
    .replace(/<li\b[^>]*>/gi, '\n- ')
    .replace(/<\/(p|div|ul|ol|h[1-6])\s*>/gi, '\n\n')
    .replace(/<\/?[a-zA-Z][a-zA-Z0-9-]*(\s[^<>]*)?\/?>/g, '')
}

export function chatText(text: string): string {
  if (!/<\/?[a-zA-Z]/.test(text)) return text
  return text
    .split(CODE)
    .map((part, i) => (i % 2 === 1 ? part : prose(part)))
    .join('')
    .replace(/\n{3,}/g, '\n\n')
}
