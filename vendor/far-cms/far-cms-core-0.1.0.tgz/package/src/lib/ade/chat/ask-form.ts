/**
 * The question form ("asks"): when the assistant needs choices only the
 * person can make, it shows a small wizard in the chat instead of a list of
 * questions. The model gives the questions (the ask_user tool); code checks
 * them, renders the wizard, and sends the answers back as the person's own
 * next message — so no tool call is ever left waiting, and earlier forms
 * replay to the model as plain conversation.
 *
 * Pure and app-agnostic (no app names; media is resolved by the host and
 * passed in). Asserted by ask-form.assert.ts. Every default is in ASK_LIMITS
 * / ASK_COPY.
 */

export const ASK_TOOL = 'ask_user'

export const ASK_LIMITS = {
  maxQuestions: 4,
  maxOptions: 6,
  /** single / multi need a real choice; an image question may offer one picture (plus the media library). */
  minChoices: 2,
  minImages: 1,
  title: 80,
  prompt: 140,
  hint: 140,
  /** The short label on the summary pill ("Background"). */
  tag: 24,
  label: 60,
  description: 100,
  value: 60,
  /** The "type your own" answer. */
  other: 300,
  /** Swatch colors per option (one color, or two for a gradient). */
  swatchColors: 2,
} as const

export const ASK_COPY = {
  chip: (n: number, of: number) => `Question ${n} of ${of}`,
  back: 'Back',
  skip: 'Skip',
  next: 'Next',
  send: 'Send answers',
  summary: 'Your answers',
  /** The first line of the answers message: how code (and the model) knows it answers the form. */
  answersHeader: 'My answers:',
  skippedTag: 'Skipped',
  library: 'From the media library',
  libraryHint: 'Browse your photos',
  passed: 'You answered in the chat instead.',
  groupLabel: 'A few questions',
  hint: { single: 'Choose one.', multi: 'Choose all that apply.', image: 'Choose one.', text: '' },
  other: { single: 'Or type your own', multi: 'Anything else to add?', image: 'Or describe what you want', text: 'Type your answer' },
} as const

/** The built-in last choice of every image question: answer "the media library" and the assistant follows up. */
export const LIBRARY_VALUE = '__library__'

export type AskType = 'single' | 'multi' | 'image' | 'text'

export interface AskOption {
  value: string
  label: string
  description?: string
  /** A media-library id (image questions); checked against the site's library by the host. */
  mediaId?: string
  /** The picture: set by code from the library, never by the model. */
  image?: string
  /** An approved swatch: one or two #rrggbb colors. */
  swatch?: string[]
}

export interface AskQuestion {
  id: string
  prompt: string
  hint?: string
  tag?: string
  type: AskType
  options: AskOption[]
}

export interface AskForm {
  title?: string
  questions: AskQuestion[]
}

export interface AskMediaInfo {
  url: string
  alt?: string
}

// ── Input from the model (untrusted): checked and cleaned ─────────────

const plain = (v: unknown, max: number): string => {
  if (typeof v !== 'string') return ''
  // One line of plain words: no control characters, markup or backticks.
  const s = v.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/[<>`]/g, '').replace(/\s{2,}/g, ' ').trim()
  return s.length > max ? `${s.slice(0, max - 1).trimEnd()}…` : s
}
const ID = /^[a-z][a-z0-9_-]{0,23}$/
const HEX = /^#[0-9a-f]{6}$/i
const TYPES: ReadonlyArray<AskType> = ['single', 'multi', 'image', 'text']

export type AskParse = { ok: true; form: AskForm; notes: string[] } | { ok: false; error: string }

/**
 * The model's form, checked: counts, types, lengths, unique ids and values;
 * media ids kept only when the host found them in this site's library
 * (`media`), swatches only as #rrggbb. Structure errors are refused with a
 * plain reason the model can fix; text is cleaned and clipped.
 */
export function parseAskInput(raw: unknown, media: ReadonlyMap<string, AskMediaInfo> = new Map()): AskParse {
  const r = (raw ?? {}) as Record<string, unknown>
  const qs = Array.isArray(r.questions) ? r.questions : []
  if (qs.length < 1) return { ok: false, error: 'Give at least one question.' }
  if (qs.length > ASK_LIMITS.maxQuestions) return { ok: false, error: `At most ${ASK_LIMITS.maxQuestions} questions in one form.` }
  const notes: string[] = []
  const ids = new Set<string>()
  const questions: AskQuestion[] = []
  for (const [i, q0] of qs.entries()) {
    const q = (q0 ?? {}) as Record<string, unknown>
    const type = TYPES.includes(q.type as AskType) ? (q.type as AskType) : null
    if (!type) return { ok: false, error: `Question ${i + 1}: type must be single, multi, image or text.` }
    const prompt = plain(q.prompt, ASK_LIMITS.prompt)
    if (!prompt) return { ok: false, error: `Question ${i + 1} has no prompt.` }
    let id = typeof q.id === 'string' && ID.test(q.id) ? q.id : `q${i + 1}`
    while (ids.has(id)) id = `${id}_${i + 1}`
    ids.add(id)
    const rawOpts = Array.isArray(q.options) ? q.options : []
    if (rawOpts.length > ASK_LIMITS.maxOptions) return { ok: false, error: `Question ${i + 1}: at most ${ASK_LIMITS.maxOptions} options.` }
    const values = new Set<string>()
    const options: AskOption[] = []
    if (type !== 'text') {
      for (const o0 of rawOpts) {
        const o = (o0 ?? {}) as Record<string, unknown>
        const label = plain(o.label ?? o.value, ASK_LIMITS.label)
        const value = plain(o.value ?? o.label, ASK_LIMITS.value)
        if (!label || !value || values.has(value) || value === LIBRARY_VALUE) continue
        const description = plain(o.description, ASK_LIMITS.description)
        const opt: AskOption = { value, label, ...(description ? { description } : {}) }
        if (type === 'image') {
          const mid = typeof o.mediaId === 'string' ? o.mediaId : ''
          const found = mid ? media.get(mid) : undefined
          const swatch = Array.isArray(o.swatch) ? o.swatch.filter((c): c is string => typeof c === 'string' && HEX.test(c)).slice(0, ASK_LIMITS.swatchColors) : []
          if (found) Object.assign(opt, { mediaId: mid, image: found.url })
          else if (swatch.length) opt.swatch = swatch
          else {
            notes.push(mid ? `"${label}": that media id isn't in this site's media library, so it was left out.` : `"${label}": an image option needs a mediaId or a swatch; left out.`)
            continue
          }
        }
        values.add(value)
        options.push(opt)
      }
      const min = type === 'image' ? ASK_LIMITS.minImages : ASK_LIMITS.minChoices
      if (options.length < min) return { ok: false, error: `Question ${i + 1} needs at least ${min} valid option${min === 1 ? '' : 's'}.${notes.length ? ` ${notes.join(' ')}` : ''}` }
    }
    const hint = plain(q.hint, ASK_LIMITS.hint)
    const tag = plain(q.tag, ASK_LIMITS.tag)
    questions.push({ id, prompt, type, options, ...(hint ? { hint } : {}), ...(tag ? { tag } : {}) })
  }
  const title = plain(r.title, ASK_LIMITS.title)
  return { ok: true, form: { ...(title ? { title } : {}), questions }, notes }
}

/** Media ids the model offered (to check against the site's library before parsing). */
export function mediaIdsIn(raw: unknown): string[] {
  const qs = Array.isArray((raw as { questions?: unknown } | null)?.questions) ? ((raw as { questions: unknown[] }).questions) : []
  const ids = qs.flatMap((q) => (Array.isArray((q as { options?: unknown })?.options) ? (q as { options: unknown[] }).options : [])).map((o) => (o as { mediaId?: unknown })?.mediaId)
  return [...new Set(ids.filter((v): v is string => typeof v === 'string' && /^[\w-]{1,64}$/.test(v)))].slice(0, ASK_LIMITS.maxQuestions * ASK_LIMITS.maxOptions)
}

// ── The wizard ───────────────────────────────────────────────────────

export interface AskAnswer {
  selected: string[]
  other: string
}

export interface AskState {
  step: number
  answers: Record<string, AskAnswer>
  skipped: string[]
  done: boolean
}

export function initAskState(): AskState {
  return { step: 0, answers: {}, skipped: [], done: false }
}

const answerOf = (s: AskState, id: string): AskAnswer => s.answers[id] ?? { selected: [], other: '' }
const withAnswer = (s: AskState, id: string, a: AskAnswer): AskState => ({ ...s, answers: { ...s.answers, [id]: a }, skipped: s.skipped.filter((x) => x !== id) })

/** Nothing selected by default; a single/image choice replaces the last and clears the typed answer; multi toggles. */
export function chooseOption(s: AskState, q: AskQuestion, value: string): AskState {
  const known = value === LIBRARY_VALUE ? q.type === 'image' : q.options.some((o) => o.value === value)
  if (s.done || !known || q.type === 'text') return s
  const a = answerOf(s, q.id)
  if (q.type === 'multi') {
    const on = a.selected.includes(value)
    return withAnswer(s, q.id, { ...a, selected: on ? a.selected.filter((v) => v !== value) : [...a.selected, value] })
  }
  return withAnswer(s, q.id, { selected: [value], other: '' })
}

/** The "type your own" field: typing clears a single/image choice (the answer is sent as text). */
export function typeOther(s: AskState, q: AskQuestion, text: string): AskState {
  if (s.done) return s
  const other = text.slice(0, ASK_LIMITS.other)
  const a = answerOf(s, q.id)
  const clears = other.trim() !== '' && (q.type === 'single' || q.type === 'image')
  return withAnswer(s, q.id, { selected: clears ? [] : a.selected, other })
}

export function askBack(s: AskState): AskState {
  return s.done || s.step === 0 ? s : { ...s, step: s.step - 1 }
}

const advance = (s: AskState, form: AskForm): AskState => (s.step >= form.questions.length - 1 ? { ...s, done: true } : { ...s, step: s.step + 1 })

/** Skip leaves the question unanswered (what was picked is cleared). */
export function askSkip(s: AskState, form: AskForm): AskState {
  if (s.done) return s
  const q = form.questions[s.step]
  if (!q) return s
  const answers = Object.fromEntries(Object.entries(s.answers).filter(([k]) => k !== q.id))
  return advance({ ...s, answers, skipped: [...s.skipped.filter((x) => x !== q.id), q.id] }, form)
}

/** Next; on the last question it is "Send answers" and finishes the form. */
export function askNext(s: AskState, form: AskForm): AskState {
  return s.done ? s : advance(s, form)
}

export interface AskStepView {
  question: AskQuestion
  chip: string
  /** Step bar: one entry per question, on up to the current one. */
  bar: boolean[]
  canBack: boolean
  primary: string
  hint: string
  otherPlaceholder: string
  answer: AskAnswer
}

export function askStepView(s: AskState, form: AskForm): AskStepView | null {
  const q = form.questions[s.step]
  if (!q || s.done) return null
  const n = form.questions.length
  return {
    question: q,
    chip: ASK_COPY.chip(s.step + 1, n),
    bar: form.questions.map((_, i) => i <= s.step),
    canBack: s.step > 0,
    primary: s.step === n - 1 ? ASK_COPY.send : ASK_COPY.next,
    hint: q.hint ?? ASK_COPY.hint[q.type],
    otherPlaceholder: ASK_COPY.other[q.type],
    answer: answerOf(s, q.id),
  }
}

// ── Answers: one message, the summary read back from it ───────────────

export interface AskResult {
  answers: Array<{ id: string; selected: string[]; other?: string }>
  skipped: string[]
}

/** What was answered: a question with nothing chosen or typed counts as skipped. */
export function askResult(s: AskState, form: AskForm): AskResult {
  const answers: AskResult['answers'] = []
  const skipped: string[] = []
  for (const q of form.questions) {
    const a = s.answers[q.id]
    const other = a?.other.trim() ?? ''
    if (!a || (!a.selected.length && !other) || s.skipped.includes(q.id)) skipped.push(q.id)
    else answers.push({ id: q.id, selected: a.selected, ...(other ? { other } : {}) })
  }
  return { answers, skipped }
}

/** A question's pill label: its tag, else its prompt's first words. */
export function tagOf(q: AskQuestion): string {
  if (q.tag) return q.tag
  const words = q.prompt.replace(/[?.!:]+$/, '').split(/\s+/)
  return plain(words.length > 4 ? `${words.slice(0, 4).join(' ')}…` : words.join(' '), ASK_LIMITS.tag)
}

/** One line; a tag also loses colons (the first ": " splits tag from answer). */
const pillText = (s: string) => s.replace(/[\r\n]+/g, ' ').trim()
const tagText = (s: string) => pillText(s).replace(/:/g, ' -')

/**
 * The person's message that answers the form: a header line, then one
 * "- Tag: answer" line per answered question (media keeps its id for the
 * assistant), then the skipped ones. It is the only record of the answers,
 * so the summary is read back from it (also after a reload).
 */
export function answersMessage(form: AskForm, r: AskResult): string {
  const lines: string[] = [ASK_COPY.answersHeader]
  for (const a of r.answers) {
    const q = form.questions.find((x) => x.id === a.id)
    if (!q) continue
    const picked = a.selected.map((v) => {
      if (v === LIBRARY_VALUE) return ASK_COPY.library
      const o = q.options.find((x) => x.value === v)
      return o ? `${pillText(o.label)}${o.mediaId ? ` (media ${o.mediaId})` : ''}` : null
    }).filter(Boolean)
    const other = a.other ? `“${pillText(a.other)}”` : ''
    lines.push(`- ${tagText(tagOf(q))}: ${[...picked, other].filter(Boolean).join(', ')}`)
  }
  const skipped = r.skipped.map((id) => form.questions.find((q) => q.id === id)).filter((q): q is AskQuestion => !!q).map((q) => tagText(tagOf(q)))
  if (skipped.length) lines.push(`- ${ASK_COPY.skippedTag}: ${skipped.join(', ')}`)
  return lines.join('\n')
}

export function isAnswersMessage(text: string): boolean {
  return text.trimStart().startsWith(ASK_COPY.answersHeader)
}

/** The summary pills, read from the answers message: [{ tag, value }], skipped last. Media ids are not shown. */
export function summaryFromMessage(text: string): Array<{ tag: string; value: string }> {
  if (!isAnswersMessage(text)) return []
  return text
    .split('\n')
    .slice(1)
    .map((l) => /^-\s+([^:]{1,40}):\s*(.+)$/.exec(l.trim()))
    .filter((m): m is RegExpExecArray => !!m)
    .map((m) => ({ tag: m[1].trim(), value: m[2].replace(/\s*\(media [\w-]+\)/g, '').trim() }))
    .slice(0, ASK_LIMITS.maxQuestions + 1)
}

// ── Where each form stands in the thread ─────────────────────────────

export type AskStatus = { state: 'open' } | { state: 'answered'; summary: Array<{ tag: string; value: string }>; messageId: string } | { state: 'passed' }

interface MsgLike {
  id?: string
  role?: string
  parts?: ReadonlyArray<unknown>
}

const textOf = (m: MsgLike) => (m.parts ?? []).filter((p) => (p as { type?: unknown })?.type === 'text').map((p) => String((p as { text?: unknown }).text ?? '')).join('')

/**
 * Each shown form (by tool call id): open (the latest reply, nothing said
 * since), answered (the next message from the person is its answers), or
 * passed (they wrote something else instead — the form folds, nothing waits).
 */
export function askStatuses(messages: ReadonlyArray<MsgLike>): Map<string, AskStatus> {
  const out = new Map<string, AskStatus>()
  messages.forEach((m, i) => {
    if (m.role !== 'assistant') return
    for (const p of m.parts ?? []) {
      const part = p as { type?: unknown; state?: unknown; toolCallId?: unknown; output?: unknown }
      if (part.type !== `tool-${ASK_TOOL}` || part.state !== 'output-available' || typeof part.toolCallId !== 'string') continue
      if (!(part.output as { shown?: unknown } | null)?.shown) continue
      const next = messages.slice(i + 1).find((x) => x.role === 'user')
      if (!next) out.set(part.toolCallId, { state: 'open' })
      else if (isAnswersMessage(textOf(next))) out.set(part.toolCallId, { state: 'answered', summary: summaryFromMessage(textOf(next)), messageId: next.id ?? '' })
      else out.set(part.toolCallId, { state: 'passed' })
    }
  })
  return out
}

/** The assistant's rule for asking (static prompt). */
export const ASK_GUIDANCE = [
  `Use \`${ASK_TOOL}\` only when you need choices only the person can make (the look, the wording, which item) and cannot read the answer from the site or the screen. Never use it instead of doing the obvious thing, and never for facts a tool can tell you.`,
  `At most one form per turn, ${ASK_LIMITS.maxQuestions} questions, ${ASK_LIMITS.maxOptions} options each, plain words, nothing chosen for them. Image options use media ids from the site's media library (or #rrggbb swatches) — never outside or made-up pictures. The person can always type their own answer.`,
  `Write one short line before the form ("A few quick questions so I get it right."), then stop: the answers come back as their next message, starting "${ASK_COPY.answersHeader}". Then carry on; changes still go through drafts and approval.`,
].join('\n')

/** A picture url the chat may show: a site path or https (the host resolved it from its library). */
const SAFE_IMAGE = /^(?:\/(?!\/)[^\s"'<>]*|https:\/\/[^\s"'<>]+)$/

/**
 * The form as the chat renders it, from a stored ask_user result (thread
 * history is client data): checked again with the same rules; a picture is
 * kept only with its library id and a safe url.
 */
export function askFormFromOutput(output: unknown): AskForm | null {
  const out = (output ?? {}) as { shown?: unknown; form?: unknown }
  if (out.shown !== true || !out.form || typeof out.form !== 'object') return null
  const media = new Map<string, AskMediaInfo>()
  for (const q of ((out.form as { questions?: unknown }).questions as unknown[] | undefined) ?? []) {
    for (const o of ((q as { options?: unknown })?.options as unknown[] | undefined) ?? []) {
      const { mediaId, image } = (o ?? {}) as { mediaId?: unknown; image?: unknown }
      if (typeof mediaId === 'string' && typeof image === 'string' && SAFE_IMAGE.test(image)) media.set(mediaId, { url: image })
    }
  }
  const parsed = parseAskInput(out.form, media)
  return parsed.ok ? parsed.form : null
}
