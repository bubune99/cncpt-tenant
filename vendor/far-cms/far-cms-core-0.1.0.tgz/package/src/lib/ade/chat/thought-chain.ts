/**
 * The thought chain under an assistant reply: built from what the run
 * really did (its tool calls, in order) plus the plan code holds. Nothing
 * here is guessed or written by the model except the plan's step titles and
 * result lines. Two run styles: planned (the plan's steps, with the work
 * filed under the step that was current) and on the fly (each piece of work
 * is a step, as it happens). Pure; asserted by thought-chain.assert.ts.
 */

import { changeRefsFromOutput, refKey } from './change-widgets'
import { CHAIN_COPY, PLAN_LIMITS, PLAN_TOOL, PLUMBING_TOOLS } from './chain-constants'
import { applyPlanCall, endTurn, parsePlanCall, planPosition, type Plan } from './plan'

export type ChainStepState = 'done' | 'current' | 'ahead' | 'skipped' | 'needs-you'
export type ChainEffect = 'read' | 'saved' | 'draft' | 'needs-you' | 'none'
/** proposed = a plan shown and waiting for Go (nothing has run). */
export type ChainPhase = 'thinking' | 'plan' | 'proposed' | 'working' | 'done' | 'paused' | 'stopped'

/** What the per-step caret opens: only recorded facts. */
export interface StepTrace {
  lookedAt: string[]
  result: string
  effect: ChainEffect
}

export interface ChainStep {
  id: string
  title: string
  state: ChainStepState
  result?: string
  /** The small tag after the title (Drafted / Waiting on you / Skipped / In progress). */
  tag?: string
  trace?: StepTrace
  /** This step is where something went wrong. */
  problem?: boolean
  /** The changes this step made (change-widget keys, refKey): its "Review ›" link; the card links back (sourceStepId). */
  changeKeys?: string[]
  /** The tool call waiting on an approval card, when this step needs your OK. */
  waitingCallId?: string
}

/** When the run started and finished (server clock, ms), from the reply's metadata. */
export interface ChainTiming {
  startedAt?: number
  finishedAt?: number
}

export interface ChainVM {
  style: 'planned' | 'fly'
  phase: ChainPhase
  /** Header while it runs ("Plan" / "Working" / "Working it out" / "Paused"). */
  header?: { title: string; sub: string }
  steps: ChainStep[]
  /** "Plan updated: …", "Plan replaced: …", "Paused at …", "Stopped. …" */
  notes: string[]
  /** A side question mid-plan: "Back to the plan (3 of 5)". */
  back?: string
  /** The one subtle line the steps fold behind ("6 steps · 1 skipped"). */
  fold: string
  /** Something went wrong: what, and the manual path. */
  problem?: { text: string; manual: string }
  /** Set by the message mapper from the reply's metadata (lib/ade/chat/chain-ledger reads it). */
  timing?: ChainTiming
}

export interface ChainDeps {
  /** Plain title for a tool call ("Looked at the screen"), never the tool's name. */
  titleOf?(name: string, input: Record<string, unknown>): string | null
  /** Plain words for what a call looked at ("Initiatives list"). Defaults to the title. */
  lookedAtOf?(name: string, input: Record<string, unknown>): string | null
  /** One short result line from a call's output, when the app knows better. */
  resultOf?(name: string, output: Record<string, unknown>): string | null
  /** Where the person can do it by hand when a call fails. */
  manualPathOf?(name: string, input: Record<string, unknown>): string | null
}

interface ToolPart {
  type: string
  state?: string
  input?: unknown
  output?: unknown
  errorText?: unknown
  toolCallId?: unknown
}

interface Work {
  id: string
  name: string
  title: string
  lookedAt: string
  state: ChainStepState
  result: string
  effect: ChainEffect
  failed: boolean
  input: Record<string, unknown>
  changeKeys: string[]
}

const obj = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {})
const clip = (s: string, n: number = PLAN_LIMITS.lineCap) => {
  const t = s.replace(/\s+/g, ' ').trim()
  return t.length > n ? `${t.slice(0, n - 1)}…` : t
}

const NAV_TOOLS = new Set(['navigateTo', 'navigate_to_route', 'open_tab', 'expand', 'collapse', 'scroll_to', 'open_menu'])
const LIST_KEYS = ['results', 'products', 'orders', 'items', 'records', 'initiatives', 'pages', 'posts', 'tabs', 'forms']

/** "getEntityDetails" → "entity details". */
const words = (s: string) => s.replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().trim()

// Imperative, like the plan's own steps ("Draft the page"), so a title reads right whether the step is ahead, running, done or failed.
// Whole first word only: "address lookup" is not "add", "settings" is not "set".
const VERB_TITLES: ReadonlyArray<readonly [RegExp, (noun: string) => string]> = [
  [/^(?:search|find)(?:\s+(.*))?$/, (n) => (n ? `Search ${n}` : 'Search the site')],
  [/^list(?:\s+(.*))?$/, (n) => `Check the ${n || 'list'}`],
  [/^(?:get|read|load|describe|count)(?:\s+(.*))?$/, (n) => `Look up the ${n || 'details'}`],
  [/^(?:create|add|insert|duplicate)(?:\s+(.*))?$/, (n) => `Draft a new ${n || 'item'}`],
  [/^(?:update|set|customize|override|reset|manage|edit|rename|move)(?:\s+(.*))?$/, (n) => `Draft changes to the ${n || 'item'}`],
  [/^(?:delete|remove|purge)(?:\s+(.*))?$/, (n) => `Draft removing the ${n || 'item'}`],
  [/^publish(?:\s+(.*))?$/, (n) => `Ask to publish the ${n || 'item'}`],
  [/^(?:send|message|reply)(?:\s+(.*))?$/, () => 'Write a message'],
  [/^(?:generate|make)\s+image$/, () => 'Make a picture'],
  [/^import(?:\s+(.*))?$/, (n) => `Draft the import of ${n || 'code'}`],
]

/** A plain title from the tool's verb when the app gave none; never the raw name. */
export function genericTitle(name: string, effect: ChainEffect): string {
  const w = words(name)
  for (const [re, make] of VERB_TITLES) {
    const m = w.match(re)
    if (m) return clip(make((m[1] ?? '').trim()), PLAN_LIMITS.titleCap)
  }
  return effect === 'draft' ? 'Draft a change' : 'Look something up'
}

function failure(state: string | undefined, out: Record<string, unknown>, errorText: unknown): string | null {
  if (state === 'output-error') return typeof errorText === 'string' ? errorText : ''
  if (out.success === false || (typeof out.error === 'string' && out.error)) return typeof out.error === 'string' ? out.error : ''
  // A refused private read is an answer ("private"), not a failure.
  if (out.ok === false && out.private !== true) return typeof out.reason === 'string' ? out.reason : ''
  return null
}

/** One short line for what a call returned (code-made, never the payload). */
export function resultLine(name: string, out: Record<string, unknown>, deps: ChainDeps = {}): string {
  const own = deps.resultOf?.(name, out)
  if (own) return clip(own)
  const r = CHAIN_COPY.result
  const refs = changeRefsFromOutput(out)
  if (out.drafted === true || refs.some((x) => x.kind === 'changeset')) return r.drafted
  if (refs.length) return r.saved
  // Browser-run: ok false = nothing showed (lib/ade/ui/spot-target), never "Shown".
  if (name === 'spotlight_steps') return out.ok === false ? r.notShown : r.shown
  if (NAV_TOOLS.has(name)) return r.opened
  if (out.private === true) return r.private
  if (name === 'read_view' || name === 'capture_view') return typeof out.title === 'string' && out.title ? clip(r.read(out.title)) : r.readScreen
  if (typeof out.count === 'number') return r.found(out.count)
  for (const k of LIST_KEYS) if (Array.isArray(out[k])) return r.found((out[k] as unknown[]).length)
  return r.done
}

function workOf(part: ToolPart, busy: boolean, deps: ChainDeps, index: number): Work {
  const name = part.type.slice(5)
  const input = obj(part.input)
  const out = obj(part.output)
  const state = part.state
  const id = typeof part.toolCallId === 'string' && part.toolCallId ? part.toolCallId : `${name}-${index}`
  // A change-set draft waits for approval; a recorded revision was saved (shown as Saved, not Drafted).
  const refs = changeRefsFromOutput(out)
  const draft = out.drafted === true || refs.some((r) => r.kind === 'changeset')
  const saved = !draft && refs.some((r) => r.kind === 'revision')
  const base = { id, name, input, failed: false, changeKeys: [...new Set(changeRefsFromOutput(out).map(refKey))] }
  let s: Pick<Work, 'state' | 'result' | 'effect' | 'failed'>
  if (state === 'approval-requested') s = { state: 'needs-you', result: CHAIN_COPY.result.waiting, effect: 'needs-you', failed: false }
  else if (state === 'approval-responded') {
    // Answered: a yes carries on (the result arrives next); a no is a skipped step, like a settled decline.
    const approved = (part as { approval?: { approved?: unknown } }).approval?.approved !== false
    s = approved
      ? { state: busy ? 'current' : 'done', result: busy ? '' : CHAIN_COPY.result.done, effect: 'needs-you', failed: false }
      : { state: 'skipped', result: CHAIN_COPY.result.declined, effect: 'none', failed: false }
  }
  else if (state === 'output-denied') s = { state: 'skipped', result: CHAIN_COPY.result.declined, effect: 'none', failed: false }
  else if (state === 'output-available' || state === 'output-error') {
    const err = failure(state, out, part.errorText)
    s = err !== null
      ? { state: 'needs-you', result: clip(err ? `${CHAIN_COPY.result.failed}: ${err}` : CHAIN_COPY.result.failed, 100), effect: 'none', failed: true }
      // A pointing step is done once the screen has it (the browser took the call), never "waiting".
      : { state: 'done', result: resultLine(name, out, deps), effect: draft ? 'draft' : saved ? 'saved' : 'read', failed: false }
  } else s = { state: busy ? 'current' : 'ahead', result: busy ? '' : CHAIN_COPY.result.unfinished, effect: 'none', failed: false }
  const title = clip(deps.titleOf?.(name, input) ?? genericTitle(name, s.effect === 'draft' ? 'draft' : 'read'), PLAN_LIMITS.titleCap)
  return { ...base, ...s, title, lookedAt: clip(deps.lookedAtOf?.(name, input) ?? title, PLAN_LIMITS.titleCap) }
}

const tagOf = (state: ChainStepState, effect: ChainEffect): string | undefined =>
  state === 'skipped' ? CHAIN_COPY.stepTag.skipped
    : state === 'needs-you' ? CHAIN_COPY.stepTag.needsYou
      : state === 'current' ? CHAIN_COPY.stepTag.current
        : state === 'done' && effect === 'draft' ? CHAIN_COPY.stepTag.draft
          : state === 'done' && effect === 'saved' ? CHAIN_COPY.stepTag.saved
          : undefined

const worst = (a: ChainEffect, b: ChainEffect): ChainEffect => {
  const rank: Record<ChainEffect, number> = { none: 0, read: 1, saved: 2, draft: 3, 'needs-you': 4 }
  return rank[b] > rank[a] ? b : a
}

function foldLabel(steps: readonly ChainStep[]): string {
  const skipped = steps.filter((s) => s.state === 'skipped').length
  // Only an approval waits on you; a failed step says it didn't work.
  const needs = steps.some((s) => s.state === 'needs-you' && !s.problem)
  const failed = steps.filter((s) => s.state === 'needs-you' && s.problem).length
  return [CHAIN_COPY.fold(steps.length), skipped ? CHAIN_COPY.foldSkipped(skipped) : null, failed ? CHAIN_COPY.foldFailed(failed) : null, needs ? CHAIN_COPY.foldNeedsYou : null].filter(Boolean).join(' · ')
}

/** Consecutive calls with the same title are one step ("Looked at the screen" ×3 → once, latest state). */
function mergeRuns(work: readonly Work[]): Work[] {
  const out: Work[] = []
  for (const w of work) {
    const last = out[out.length - 1]
    // Only a finished, plain step absorbs the next one: a failure or a waiting approval always stays visible.
    if (last && last.title === w.title && last.state === 'done' && !last.failed && last.effect !== 'needs-you') out[out.length - 1] = { ...w, id: last.id, effect: worst(last.effect, w.effect), changeKeys: [...new Set([...last.changeKeys, ...w.changeKeys])] }
    else out.push(w)
  }
  return out
}

export interface ChainInput {
  parts: readonly unknown[]
  /** The plan as it stood before this message (from the earlier messages). */
  planBefore: Plan | null
  /** This message is still streaming. */
  busy: boolean
  deps?: ChainDeps
  /** Prefix for ids of plans this message starts. */
  idPrefix?: string
}

export interface ChainResult {
  chain: ChainVM | null
  /** The plan after this message, for the next one. */
  planAfter: Plan | null
}

const isOpen = (p: Plan | null): p is Plan => !!p && (p.status === 'active' || p.status === 'paused' || p.status === 'waiting')

/** Build one reply's chain. Returns chain null when there is nothing to show (a plain answer). */
export function buildChain({ parts, planBefore, busy, deps = {}, idPrefix = 'p' }: ChainInput): ChainResult {
  let plan: Plan | null = isOpen(planBefore) ? planBefore : null
  let startedHere = false
  let planEventHere = false
  let hadText = false
  const notes: string[] = []
  let back: string | undefined
  const fly: Work[] = []
  /** Work filed under a plan this message then replaced. */
  const earlier: Work[] = []
  const buckets = new Map<string, Work[]>()
  let callIx = 0
  let partIx = 0
  // After a side question, lookups answer the question: they are not the plan's work.
  let aside = false
  /** Any plan call took effect here (a side question counts: the plan stays open for the way back). */
  let touched = false

  for (const raw of parts) {
    const rec = obj(raw)
    const part = rec as unknown as ToolPart
    partIx++
    const type = typeof rec.type === 'string' ? rec.type : ''
    if (type === 'text' && typeof rec.text === 'string' && rec.text.trim()) { hadText = true; continue }
    if (!type.startsWith('tool-')) continue
    const name = type.slice(5)
    if (name === PLAN_TOOL) {
      if (part.state === 'input-streaming' || part.state === undefined) continue
      const call = parsePlanCall(part.input)
      if (!call) continue
      const r = applyPlanCall(plan, call, `${idPrefix}${callIx++}-`)
      if (r.event.kind === 'ignored') continue
      touched = true
      if (r.event.kind === 'side') {
        back = r.event.back ?? undefined
        aside = true
        continue
      }
      aside = false
      planEventHere = true
      if (r.event.kind === 'started' || r.event.kind === 'replaced') {
        startedHere = true
        // Work done under the plan it replaced stays visible (done is never hidden), as plain steps.
        for (const ws of buckets.values()) earlier.push(...ws)
        buckets.clear()
      }
      if ('note' in r.event) notes.push(r.event.note)
      plan = r.plan
      continue
    }
    if (PLUMBING_TOOLS.has(name)) continue
    const w = workOf(part, busy, deps, partIx)
    const cur = plan && isOpen(plan) && !aside ? plan.steps.find((s) => s.state === 'current') : undefined
    if (cur) (buckets.get(cur.id) ?? buckets.set(cur.id, []).get(cur.id)!).push(w)
    else if (!plan) fly.push(w)
    // Work after the plan finished or stopped, with no step to file it under: shown on the fly.
    else fly.push(w)
  }

  // A reply that only talks (no plan call, no work) while a plan is open does not repeat the plan.
  const planned = !!plan && (startedHere || planEventHere || buckets.size > 0)
  let steps: ChainStep[] = []
  let failedWork: Work | undefined

  if (planned && plan) {
    const paused = plan.status === 'paused'
    steps = plan.steps.map((s) => {
      const work = buckets.get(s.id) ?? []
      const bad = work.find((w) => w.failed)
      const asks = work.some((w) => w.state === 'needs-you' && !w.failed)
      if (bad && !failedWork) failedWork = bad
      let state: ChainStepState =
        s.state === 'done' ? 'done' : s.state === 'skipped' ? 'skipped' : s.state === 'ahead' ? 'ahead' : busy && !paused ? 'current' : 'ahead'
      if (s.state !== 'done' && s.state !== 'skipped' && (asks || bad)) state = 'needs-you'
      const effect = work.reduce<ChainEffect>((e, w) => worst(e, w.effect), 'none')
      const result = s.result ?? (bad ? bad.result : asks ? CHAIN_COPY.result.waiting : s.state === 'done' && work.length ? work[work.length - 1].result : undefined)
      const lookedAt = [...new Set(work.map((w) => w.lookedAt))]
      const changeKeys = [...new Set(work.flatMap((w) => w.changeKeys))]
      const waiting = work.find((w) => w.state === 'needs-you' && !w.failed)
      return {
        id: s.id,
        title: s.title,
        state,
        ...(result ? { result } : {}),
        ...(tagOf(state, effect) ? { tag: tagOf(state, effect) } : {}),
        // Only finished, waiting or failed steps have facts to open.
        ...(state === 'done' || state === 'needs-you' ? { trace: { lookedAt, result: result ?? CHAIN_COPY.result.done, effect } } : {}),
        ...(bad ? { problem: true } : {}),
        ...(changeKeys.length ? { changeKeys } : {}),
        ...(waiting && state === 'needs-you' ? { waitingCallId: waiting.id } : {}),
      }
    })
  }

  const asSteps = (work: readonly Work[]): ChainStep[] => mergeRuns(work).map((w) => {
    if (w.failed && !failedWork) failedWork = w
    const tag = tagOf(w.state, w.effect)
    return {
      id: w.id,
      title: w.title,
      state: w.state,
      ...(w.result ? { result: w.result } : {}),
      ...(tag ? { tag } : {}),
      ...(w.state === 'done' || w.state === 'needs-you' || w.state === 'skipped' ? { trace: { lookedAt: [w.lookedAt], result: w.result || CHAIN_COPY.result.done, effect: w.effect } } : {}),
      ...(w.failed ? { problem: true } : {}),
      ...(w.changeKeys.length ? { changeKeys: w.changeKeys } : {}),
      ...(w.state === 'needs-you' && !w.failed ? { waitingCallId: w.id } : {}),
    }
  })
  steps = [...asSteps(earlier), ...steps, ...asSteps(fly)]

  // A finished reply that never touched an active plan ends it (plan.ts endTurn); a streaming one doesn't yet.
  const planAfter = busy ? plan : endTurn(plan, touched)
  if (!steps.length && !notes.length && !back) {
    // Nothing done yet and nothing said: the thinking indicator.
    return { chain: busy && !hadText ? { style: planned ? 'planned' : 'fly', phase: 'thinking', steps: [], notes: [], fold: '' } : null, planAfter }
  }

  const style: ChainVM['style'] = planned ? 'planned' : 'fly'
  const anyWork = buckets.size > 0 || fly.length > 0 || earlier.length > 0
  const phase: ChainPhase = plan?.status === 'waiting' && planned
    ? 'proposed'
    : plan?.status === 'paused' && planned
    ? 'paused'
    : plan?.status === 'stopped' && planned
      ? 'stopped'
      : busy
        ? planned && !anyWork && !steps.some((s) => s.state === 'done') ? 'plan' : 'working'
        : 'done'

  // A plan shown first replaces what led up to it: the card shows the plan alone (no old fly steps under it).
  if (phase === 'proposed' && plan) {
    const planIds = new Set(plan.steps.map((s) => s.id))
    steps = steps.filter((s) => planIds.has(s.id))
  }

  let header: ChainVM['header']
  const counted = steps.filter((s) => s.state !== 'skipped')
  if (phase === 'plan') header = { title: CHAIN_COPY.planHeader, sub: CHAIN_COPY.planSub(counted.length) }
  else if (phase === 'proposed') header = { title: CHAIN_COPY.planHeader, sub: CHAIN_COPY.proposedSub(counted.length) }
  else if (phase === 'working' && style === 'planned' && plan) {
    const { at, of } = planPosition(plan)
    header = { title: CHAIN_COPY.workingHeader, sub: CHAIN_COPY.workingSub(at, of) }
  } else if (phase === 'working') header = { title: CHAIN_COPY.flyHeader, sub: CHAIN_COPY.flySub }
  else if (phase === 'paused' && plan) {
    const { at, of } = planPosition(plan)
    header = { title: CHAIN_COPY.pausedHeader, sub: CHAIN_COPY.pausedSub(at, of) }
  }

  const fw = failedWork as Work | undefined
  const problem = fw
    ? { text: CHAIN_COPY.problem(fw.title), manual: clip(deps.manualPathOf?.(fw.name, fw.input) ?? CHAIN_COPY.manualDefault) }
    : undefined

  return {
    chain: { style, phase, ...(header ? { header } : {}), steps, notes, ...(back ? { back } : {}), fold: steps.length ? foldLabel(steps) : '', ...(problem ? { problem } : {}) },
    planAfter,
  }
}
