/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/replay.assert.ts
 */
import assert from 'node:assert/strict'
import { toolCallIdsIn } from './replay'

const restored = [
  { parts: [{ type: 'text' }] },
  { parts: [{ type: 'tool-navigateTo', toolCallId: 'nav1' }, { type: 'tool-spotlight_steps', toolCallId: 'spot1' }, { type: 'step-start' }] },
  { parts: [{ type: 'tool-operate_ui', toolCallId: 'ui1' }, { type: 'dynamic-tool', toolCallId: 'mcp1' }] },
]
assert.deepEqual(toolCallIdsIn(restored), ['nav1', 'spot1', 'ui1', 'mcp1'], 'every restored tool call is marked handled (none replays)')
assert.deepEqual(toolCallIdsIn([]), [])
assert.deepEqual(toolCallIdsIn(undefined), [])
assert.deepEqual(toolCallIdsIn([{ parts: [{ type: 'tool-x' }] }]), [], 'no id, nothing to mark')
console.log('4 checks passed')
