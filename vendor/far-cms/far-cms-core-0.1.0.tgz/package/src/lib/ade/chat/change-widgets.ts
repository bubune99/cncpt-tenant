/**
 * Change widgets: what a reply actually changed on the site, shown under it.
 *
 * A widget exists only when a change RECORD exists. Its reference comes from
 * the tool result (a change set the edit was drafted into, or the revision an
 * applied edit recorded), never from what the model wrote. References are
 * kept on the reply's metadata (like spots), and the server resolves them to
 * views at read time, so the status is live (pending → approved) and private
 * values are masked for the person looking.
 *
 * Pure and host-agnostic; asserted by change-widgets.assert.ts.
 */

import { stableEqual } from '../changesets/logic'

// ── References (stored on the message) ───────────────────────────────

export type ChangeRef =
  /** Drafted for review: the change set and the items this reply added or folded into. */
  | { kind: 'changeset'; changeSetId: string; itemIds: string[] }
  /** Applied: the revision the change recorded (lib/ade/history). */
  | { kind: 'revision'; revisionId: string; entityType?: string; entityId?: string; version?: number }

export const MAX_CHANGE_REFS = 20
const ID = /^[A-Za-z0-9_:-]{1,128}$/

const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '')
const isId = (v: unknown): v is string => typeof v === 'string' && ID.test(v)
const ids = (v: unknown): string[] => (Array.isArray(v) ? v.filter(isId) : [])

/** One tool output → the change reference it carries, if any. */
export function changeRefFromOutput(out: unknown): ChangeRef | null {
  if (!out || typeof out !== 'object') return null
  const o = out as Record<string, unknown>
  if (o.success === false || o.ok === false) return null
  // The shared revision mechanism: { change: { kind: 'revision', revisionId, entityType, entityId, version } },
  // or a bare revisionId (apply results: { resultId, revisionId, version }; null when nothing changed).
  const c = (o.change && typeof o.change === 'object' ? o.change : null) as Record<string, unknown> | null
  const revisionId = c?.kind === 'revision' ? c.revisionId : o.revisionId
  if (isId(revisionId)) {
    const src = c ?? o
    const version = typeof src.version === 'number' && Number.isInteger(src.version) && src.version > 0 ? src.version : undefined
    return {
      kind: 'revision',
      revisionId,
      ...(str(src.entityType) ? { entityType: str(src.entityType) } : {}),
      ...(str(src.entityId) ? { entityId: str(src.entityId) } : {}),
      ...(version ? { version } : {}),
    }
  }
  // Drafted into a change set (draft mode): changeSetId + the item(s) it made.
  const setId = c?.kind === 'changeset' ? c.changeSetId : o.drafted === true ? o.changeSetId : null
  if (isId(setId) && setId !== 'direct') {
    const items = [...ids(c?.itemIds), ...ids(o.itemIds), ...(isId(o.itemId) ? [o.itemId] : [])]
    return { kind: 'changeset', changeSetId: setId, itemIds: [...new Set(items)] }
  }
  return null
}

/**
 * Every ref one tool output carries: its own (above), plus `changes` — what a
 * direct-mode apply recorded, one revision per thing it changed. Those count
 * even when a later step failed: they were saved, so they have a record.
 */
export function changeRefsFromOutput(out: unknown): ChangeRef[] {
  const own = changeRefFromOutput(out)
  const o = (out ?? {}) as Record<string, unknown>
  if (!out || typeof out !== 'object' || !Array.isArray(o.changes)) return own ? [own] : []
  const more = o.changes.flatMap((c) => changeRefFromOutput(c && typeof c === 'object' && 'kind' in c ? { change: c } : null) ?? [])
  return [...(own ? [own] : []), ...more]
}

/** A revision a tool call recorded (lib/ade-bindings/revision-capture). */
export interface RecordedRevision {
  revisionId: string
  /** null when the store numbers versions only when read (pages). */
  version: number | null
  entityType: string
  entityId: string
}

/**
 * A tool's result with the revisions its call recorded attached as
 * `changes` (merged with any it listed itself). Non-object results and
 * calls that recorded nothing come back unchanged.
 */
export function withRecordedChanges<T>(result: T, recorded: readonly RecordedRevision[]): T {
  if (!recorded.length || !result || typeof result !== 'object' || Array.isArray(result)) return result
  const r = result as Record<string, unknown>
  const own = Array.isArray(r.changes) ? r.changes : []
  const listed = new Set(changeRefsFromOutput(r).flatMap((x) => (x.kind === 'revision' ? [x.revisionId] : [])))
  const added = recorded.filter((v) => !listed.has(v.revisionId)).map((v) => ({ kind: 'revision' as const, ...v }))
  return added.length ? ({ ...r, changes: [...own, ...added] } as T) : result
}

/** Several refs → one per change set (item ids merged) and one per revision, in first-seen order. */
export function mergeChangeRefs(refs: readonly ChangeRef[]): ChangeRef[] {
  const out: ChangeRef[] = []
  for (const r of refs) {
    if (r.kind === 'changeset') {
      const i = out.findIndex((x) => x.kind === 'changeset' && x.changeSetId === r.changeSetId)
      if (i >= 0) {
        const prev = out[i] as Extract<ChangeRef, { kind: 'changeset' }>
        out[i] = { ...prev, itemIds: [...new Set([...prev.itemIds, ...r.itemIds])] }
        continue
      }
    } else if (out.some((x) => x.kind === 'revision' && x.revisionId === r.revisionId)) continue
    out.push(r)
  }
  return out.slice(0, MAX_CHANGE_REFS)
}

/** The refs a reply's tool parts carry (finished calls only). */
export function changeRefsFromParts(parts: readonly unknown[]): ChangeRef[] {
  const refs: ChangeRef[] = []
  for (const p of parts) {
    const part = (p ?? {}) as Record<string, unknown>
    if (!str(part.type).startsWith('tool-') || part.state !== 'output-available') continue
    refs.push(...changeRefsFromOutput(part.output))
  }
  return mergeChangeRefs(refs)
}

/** Refs kept on a message's metadata, validated (stored JSON is untrusted). */
export function changeRefsFromMetadata(metadata: unknown): ChangeRef[] | null {
  const raw = (metadata as { changes?: unknown } | null | undefined)?.changes
  if (!Array.isArray(raw)) return null
  const refs = raw.flatMap((r) => {
    const ref = changeRefFromOutput(r && typeof r === 'object' && 'kind' in r ? { change: r } : null)
    return ref ? [ref] : []
  })
  return mergeChangeRefs(refs)
}

/** Stable key for a ref (React keys, request dedupe). */
export const refKey = (r: ChangeRef) => (r.kind === 'changeset' ? `cs:${r.changeSetId}` : `rev:${r.revisionId}`)

// ── Views (resolved by the server, masked for the viewer) ────────────

export type ChangeStatus = 'pending' | 'applied' | 'rejected' | 'stale' | 'failed'

export interface FieldLine {
  field: string
  label: string
  before: string
  after: string
  /** Changed, but its values are never shown (secrets): "changed (hidden)". */
  hidden?: boolean
}

export interface ChangeView {
  key: string
  status: ChangeStatus
  /** "Page", "Initiative", "Header"… */
  entityType: string
  /** The thing's own name ("About us"); null when it has none. */
  entityName: string | null
  /** Where the thing is edited; null when there is no screen for it. */
  href: string | null
  /** What changed, masked; at most MAX_FIELD_LINES. */
  fields: FieldLine[]
  /** Changed fields not listed. */
  more: number
  /** Version number of the target after this change; null until the revision mechanism provides one. */
  version: number | null
  /** The revision to compare / restore; null while pending or for things without history yet. */
  revisionId: string | null
  /** May this person restore it (the thing's edit permission)? */
  canRestore: boolean
  /** Review items behind it (Approve / Reject act on these). */
  itemIds: string[]
  canApprove: boolean
  /** Why it did not apply (stale / failed). */
  error: string | null
  /** Why the assistant proposed it, in its own words (owner 2026-10-17); absent/null when it gave none. */
  why?: string | null
  // ── Review (assistant chat v2 P2, lib/ade/chat/change-review): all optional, the host adds what it knows ──
  /** The kind of thing (change-set targetType or history entity type): picks the body. */
  target?: string
  /** The reviewer-only render of the result (the Preview body; "Show on page"). */
  previewPath?: string | null
  /** The blocks it touches on that page (the outline and "Find it"). */
  blockIds?: string[]
  /** The page it shows on, when it is a page's content. */
  pageId?: string | null
  /** The same edit on many records: how many, what they are, and a few of them. */
  batch?: { count: number; noun: string; rows: Array<{ name: string; before: string; after: string }> } | null
  /** Fields it leaves as they are (the Values body's "Unchanged: …"). */
  unchanged?: string[]
  /** Approving changes what visitors see (Publish); false = it saves a draft (Approve). */
  publishes?: boolean
  /** A product's cells under its preview (Price / Stock / Visible). */
  strip?: Array<{ label: string; value: string }> | null
}

export const MAX_FIELD_LINES = 4
const MAX_VALUE = 60

/** An item status (change sets) → what the widget shows. */
export function statusOfItems(statuses: readonly string[]): ChangeStatus {
  if (statuses.some((s) => s === 'failed')) return 'failed'
  if (statuses.some((s) => s === 'stale')) return 'stale'
  if (statuses.some((s) => s === 'pending' || s === 'saved' || s === 'applying')) return 'pending'
  if (statuses.length && statuses.every((s) => s === 'rejected')) return 'rejected'
  return 'applied'
}

/** "heroImage" → "Hero image"; "seo.title" → "SEO title". */
export function fieldLabel(field: string): string {
  const words = field
    .replace(/[._-]+/g, ' ')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .trim()
    .toLowerCase()
    .replace(/\b(seo|url|id|cta|og)\b/g, (w) => w.toUpperCase())
  return words ? words.charAt(0).toUpperCase() + words.slice(1) : field
}

const clip = (s: string) => (s.length > MAX_VALUE ? `${s.slice(0, MAX_VALUE - 1).trimEnd()}…` : s)

/** One value as a short line: text clipped, lists counted, objects named, nothing → "—". */
export function formatValue(v: unknown): string {
  if (v === null || v === undefined || v === '') return '—'
  if (typeof v === 'string') return clip(v.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() || '—')
  if (typeof v === 'number' || typeof v === 'boolean') return v === true ? 'Yes' : v === false ? 'No' : String(v)
  if (Array.isArray(v)) return v.length === 0 ? 'None' : `${v.length} item${v.length === 1 ? '' : 's'}`
  if (typeof v === 'object') {
    const o = v as Record<string, unknown>
    const name = str(o.title) || str(o.name) || str(o.label) || str(o.alt)
    return name ? clip(name) : 'Changed'
  }
  return '—'
}

type Change = { field: string; before: unknown; after: unknown }

/** Snapshot wrappers whose own name means nothing to a person ({ doc: {...} }, { data: {...} }). */
const WRAPPERS = new Set(['doc', 'data'])
const isPlain = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v)

/**
 * A change to a whole object ("display", a form's "doc") → the fields inside
 * it that changed ("Display mode: Inline → Popup"), two levels deep. A
 * wrapper's name is dropped; anything else prefixes its fields. An object
 * that appeared (or went away) lists its fields from (or to) nothing — never
 * one "— → Changed" line.
 */
export function expandChanges(changes: readonly Change[], depth = 2): Change[] {
  return changes.flatMap((c) => {
    const none = (v: unknown) => v === null || v === undefined
    // Not objects (a value or a list), or an object replaced by a value: one line.
    if (depth <= 0 || !(isPlain(c.before) || none(c.before)) || !(isPlain(c.after) || none(c.after)) || (none(c.before) && none(c.after))) return [c]
    const b = isPlain(c.before) ? c.before : {}
    const a = isPlain(c.after) ? c.after : {}
    const keys = [...new Set([...Object.keys(b), ...Object.keys(a)])].sort()
    const inner = keys.filter((k) => !stableEqual(b[k], a[k])).map((k) => ({ field: WRAPPERS.has(c.field) ? k : `${c.field}.${k}`, before: b[k] ?? null, after: a[k] ?? null }))
    return inner.length ? expandChanges(inner, depth - 1) : []
  })
}

/** Field changes → the lines the widget lists (first MAX_FIELD_LINES) and how many more. */
export function fieldLines(changes: ReadonlyArray<{ field: string; before: unknown; after: unknown }>): { fields: FieldLine[]; more: number } {
  const lines = expandChanges(changes).map((c) => ({ field: c.field, label: fieldLabel(c.field), before: formatValue(c.before), after: formatValue(c.after) }))
  return { fields: lines.slice(0, MAX_FIELD_LINES), more: Math.max(0, lines.length - MAX_FIELD_LINES) }
}

const TAG_NAMES: Record<string, string> = {
  h1: 'Heading', h2: 'Heading', h3: 'Heading', h4: 'Heading', h5: 'Heading', h6: 'Heading',
  p: 'Paragraph', span: 'Text', a: 'Link', button: 'Button', img: 'Image', video: 'Video',
  ul: 'List', ol: 'List', li: 'List item', section: 'Section', header: 'Header', footer: 'Footer',
  nav: 'Menu', form: 'Form', blockquote: 'Quote', figure: 'Figure', table: 'Table',
}

/** A block with no label, named the way a person would: "<h2>" → "Heading". */
export function tagName(tag: string | undefined): string {
  return (tag && TAG_NAMES[tag.toLowerCase()]) || 'Block'
}

/** Block changes (page content) → lines named after the block. */
export function blockLines(
  changes: ReadonlyArray<{ kind: string; tag?: string; label?: string; fields: ReadonlyArray<{ field: string; before: unknown; after: unknown }> }>
): Array<{ field: string; before: unknown; after: unknown }> {
  return changes.map((b) => {
    const name = b.label || tagName(b.tag)
    if (b.kind === 'added') return { field: name, before: null, after: 'Added' }
    if (b.kind === 'removed') return { field: name, before: 'Present', after: 'Removed' }
    if (b.kind === 'moved') return { field: name, before: 'Here', after: 'Moved' }
    const text = b.fields.find((f) => f.field === 'textContent')
    if (text) return { field: name, before: text.before, after: text.after }
    return { field: name, before: 'Old', after: `${b.fields.map((f) => fieldLabel(f.field).toLowerCase()).join(', ')} changed` }
  })
}

// ── Header and actions ───────────────────────────────────────────────

export interface WidgetHeader {
  title: string
  sub: string
  badge: string
}

const BADGE: Record<ChangeStatus, string> = {
  pending: 'Waiting for approval',
  applied: 'Saved',
  rejected: 'Rejected',
  stale: 'Out of date',
  failed: "Didn't save",
}

/** The header's verb per status: only an applied change says "Changed" (golden 2b: a rejected one read "Changed …"). */
const VERB: Record<ChangeStatus, string> = {
  pending: 'Drafted a change to',
  applied: 'Changed',
  rejected: 'Rejected a change to',
  stale: 'Not applied (out of date): change to',
  failed: 'Couldn’t apply a change to',
}

export function widgetHeader(v: ChangeView): WidgetHeader {
  const what = v.entityName ? `${v.entityType} “${v.entityName}”` : v.entityType
  const n = v.fields.length + v.more
  const parts = [v.version ? `Version ${v.version}` : null, n ? `${n} change${n === 1 ? '' : 's'}` : null]
  return {
    title: `${VERB[v.status]} ${what}`,
    sub: parts.filter(Boolean).join(' · '),
    badge: BADGE[v.status],
  }
}

export type ChangeAction = 'open' | 'compare' | 'restore' | 'approve' | 'reject'

/**
 * What the widget offers. Pending: Approve / Reject, for someone allowed to
 * review it (the review API checks the same permission for both). Applied:
 * Open, Compare once a revision exists, and Restore for someone who may edit
 * the thing. Rejected / stale / failed: Open only.
 */
export function widgetActions(v: ChangeView): ChangeAction[] {
  const open: ChangeAction[] = v.href ? ['open'] : []
  if (v.status === 'pending') return [...(v.canApprove ? (['approve', 'reject'] as const) : []), ...open]
  if (v.status === 'applied') return [...open, ...(v.revisionId ? (['compare'] as const) : []), ...(v.revisionId && v.canRestore ? (['restore'] as const) : [])]
  return open
}
