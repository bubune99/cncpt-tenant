/**
 * Requests for a channel the site does not have (the site sends email only). Such a
 * request is not given a plan to approve: the first sentence of the reply says it
 * cannot be done and offers the nearest thing. Checked by cannot-do.assert.ts.
 */

export interface CannotDo {
  what: string
  nearest: string
}

const EMAIL_INSTEAD = 'a thank-you or update email to the same people, drafted for approval'

// Whole-word patterns, so "text block", "heading text" and "call to action" are not caught.
const CHANNELS: ReadonlyArray<{ re: RegExp; what: string; nearest: string }> = [
  { re: /\b(text message|text messages|texts|sms)\b|\btext (?:everyone|them|all|the|people|volunteers|donors|members|him|her)\b/i, what: 'text messages', nearest: EMAIL_INSTEAD },
  { re: /\bwhats ?app\b/i, what: 'WhatsApp messages', nearest: EMAIL_INSTEAD },
  { re: /\b(?:call|phone|ring) (?:everyone|them|all|the people|people|volunteers|donors|members)\b/i, what: 'phone calls', nearest: EMAIL_INSTEAD },
]

export function cannotDo(text: string): CannotDo | null {
  const c = CHANNELS.find((ch) => ch.re.test(text))
  return c ? { what: c.what, nearest: c.nearest } : null
}

/** The per-turn line for the model when the request needs a channel the site lacks. */
export function cannotDoLine(c: CannotDo): string {
  return `[Cannot do] The site cannot send ${c.what}; it sends email only. Say so in the first sentence, in plain words, then offer the nearest thing: ${c.nearest}. Do not propose a plan and do not run steps to check first. Keep the whole reply to three short sentences; one offer, no list.`
}
