/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/change-widgets.assert.ts
 */
import assert from 'node:assert/strict'
import {
  blockLines,
  expandChanges,
  changeRefFromOutput,
  changeRefsFromOutput,
  changeRefsFromMetadata,
  changeRefsFromParts,
  fieldLabel,
  fieldLines,
  formatValue,
  mergeChangeRefs,
  statusOfItems,
  widgetActions,
  widgetHeader,
  withRecordedChanges,
  type ChangeView,
} from './change-widgets'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const done = (output: unknown, type = 'tool-updateRecord') => ({ type, state: 'output-available', output })

check('a drafted edit carries its change set and item', () => {
  assert.deepEqual(changeRefFromOutput({ success: true, drafted: true, changeSetId: 'cs1', itemId: 'i1', message: 'Drafted…' }), { kind: 'changeset', changeSetId: 'cs1', itemIds: ['i1'] })
})

check('a revision from the shared mechanism, nested or bare', () => {
  assert.deepEqual(changeRefFromOutput({ success: true, change: { kind: 'revision', revisionId: 'r9', entityType: 'form', entityId: 'x', version: 4 } }), { kind: 'revision', revisionId: 'r9', entityType: 'form', entityId: 'x', version: 4 })
  assert.deepEqual(changeRefFromOutput({ success: true, revisionId: 'r1' }), { kind: 'revision', revisionId: 'r1' })
  assert.equal(changeRefFromOutput({ success: true, resultId: 'f1', revisionId: null, version: null }), null, 'nothing changed → no revision → no widget')
})

check('NO record, no widget: words, failures and direct-mode results make none', () => {
  assert.equal(changeRefFromOutput({ success: true, message: 'Updated the page title to "About".' }), null)
  assert.equal(changeRefFromOutput({ success: false, drafted: true, changeSetId: 'cs1', itemId: 'i1' }), null)
  assert.equal(changeRefFromOutput({ success: true, applied: [{ targetType: 'page', resultId: 'p1' }] }), null)
  assert.equal(changeRefFromOutput({ success: true, drafted: true, changeSetId: 'direct', itemId: 'direct' }), null)
  assert.equal(changeRefFromOutput({ success: true, changeSetId: 'cs1' }), null, 'a changeSetId alone (a read) is not a drafted change')
  assert.equal(changeRefFromOutput({ success: true, revisionId: 'bad id with spaces' }), null)
  assert.equal(changeRefFromOutput('Changed it'), null)
})

check('only finished tool calls count; several edits to one set fold into one widget', () => {
  const refs = changeRefsFromParts([
    { type: 'text', text: 'I changed the title (changeSetId cs9).' },
    { type: 'tool-updateRecord', state: 'input-available', input: {} },
    done({ success: true, drafted: true, changeSetId: 'cs1', itemId: 'i1' }),
    done({ success: true, drafted: true, changeSetId: 'cs1', itemId: 'i2' }),
    done({ success: true, drafted: true, changeSetId: 'cs1', itemId: 'i1' }),
    done({ success: true, revisionId: 'r1' }),
    done({ success: true, revisionId: 'r1' }),
  ])
  assert.deepEqual(refs, [
    { kind: 'changeset', changeSetId: 'cs1', itemIds: ['i1', 'i2'] },
    { kind: 'revision', revisionId: 'r1' },
  ])
})

check('a direct-mode apply lists the revision of each thing it changed', () => {
  assert.deepEqual(changeRefsFromOutput({ success: true, applied: [], changes: [{ kind: 'revision', revisionId: 'r1', entityType: 'form', entityId: 'f1', version: 2 }, { kind: 'revision', revisionId: null }, 'x'] }), [{ kind: 'revision', revisionId: 'r1', entityType: 'form', entityId: 'f1', version: 2 }])
  assert.deepEqual(changeRefsFromOutput({ success: false, error: 'No adapter for x', changes: [{ kind: 'revision', revisionId: 'r1' }] }), [{ kind: 'revision', revisionId: 'r1' }], 'saved before a later step failed: still recorded')
  assert.deepEqual(changeRefsFromParts([done({ success: true, changes: [{ kind: 'revision', revisionId: 'r1' }] })]), [{ kind: 'revision', revisionId: 'r1' }])
})

check('what a call recorded is attached to its result (and then becomes a widget)', () => {
  const rec = [{ revisionId: 'r1', version: 3, entityType: 'form', entityId: 'f1' }]
  const out = withRecordedChanges({ success: true, formId: 'f1', display: { mode: 'popup' } }, rec)
  assert.deepEqual(changeRefsFromOutput(out), [{ kind: 'revision', revisionId: 'r1', entityType: 'form', entityId: 'f1', version: 3 }])
  const same = { success: true, change: { kind: 'revision', revisionId: 'r1' } }
  assert.equal(withRecordedChanges(same, rec), same, 'already listed by the tool: untouched')
  const none = { success: true }
  assert.equal(withRecordedChanges(none, []), none)
  assert.equal(withRecordedChanges('done', rec), 'done')
  assert.deepEqual((withRecordedChanges({ changes: [{ kind: 'revision', revisionId: 'r0' }] }, rec) as { changes: unknown[] }).changes.length, 2)
})

check('a bundle keeps every item', () => {
  assert.deepEqual(changeRefFromOutput({ success: true, drafted: true, changeSetId: 'cs2', itemId: 'a', itemIds: ['a', 'b'] }), { kind: 'changeset', changeSetId: 'cs2', itemIds: ['a', 'b'] })
})

check('metadata round-trips and junk is dropped', () => {
  const refs = changeRefsFromParts([done({ success: true, drafted: true, changeSetId: 'cs1', itemId: 'i1' }), done({ success: true, revisionId: 'r1', version: 2 })])
  assert.deepEqual(changeRefsFromMetadata(JSON.parse(JSON.stringify({ changes: refs }))), refs)
  assert.deepEqual(changeRefsFromMetadata({ changes: [{ kind: 'changeset', changeSetId: '<script>' }, 'x', null, { kind: 'revision', revisionId: 'r2', version: -1 }] }), [{ kind: 'revision', revisionId: 'r2' }])
  assert.equal(changeRefsFromMetadata({}), null)
  assert.equal(changeRefsFromMetadata(null), null)
})

check('merge caps the list', () => {
  const many = Array.from({ length: 30 }, (_, i) => ({ kind: 'revision' as const, revisionId: `r${i}` }))
  assert.equal(mergeChangeRefs(many).length, 20)
})

check('status from items', () => {
  assert.equal(statusOfItems(['pending', 'approved']), 'pending')
  assert.equal(statusOfItems(['saved']), 'pending')
  assert.equal(statusOfItems(['approved', 'approved']), 'applied')
  assert.equal(statusOfItems(['rejected']), 'rejected')
  assert.equal(statusOfItems(['approved', 'rejected']), 'applied')
  assert.equal(statusOfItems(['approved', 'stale']), 'stale')
  assert.equal(statusOfItems(['failed', 'pending']), 'failed')
})

check('field labels and values read like the screen', () => {
  assert.equal(fieldLabel('heroImage'), 'Hero image')
  assert.equal(fieldLabel('seo.title'), 'SEO title')
  assert.equal(fieldLabel('og_image_url'), 'OG image URL')
  assert.equal(formatValue(null), '—')
  assert.equal(formatValue(''), '—')
  assert.equal(formatValue('<p>Hello   <b>there</b></p>'), 'Hello there')
  assert.equal(formatValue(true), 'Yes')
  assert.equal(formatValue([1, 2]), '2 items')
  assert.equal(formatValue({ url: 'x', alt: 'Clinic roof' }), 'Clinic roof')
  assert.equal(formatValue('x'.repeat(100)).length, 60)
  assert.equal(formatValue('[private]'), '[private]', 'a masked value stays masked')
})

check('field lines cap at 4 and count the rest', () => {
  const ch = ['a', 'b', 'c', 'd', 'e', 'f'].map((f) => ({ field: f, before: 1, after: 2 }))
  const r = fieldLines(ch)
  assert.equal(r.fields.length, 4)
  assert.equal(r.more, 2)
  assert.deepEqual(r.fields[0], { field: 'a', label: 'A', before: '1', after: '2' })
})

check('a whole-object change lists the fields inside it (found on staging: "Doc: X → X")', () => {
  const doc = (automations: unknown[], mode: string) => ({ name: 'ZZ form', automations, display: { mode, popupDelay: 5 } })
  const out = expandChanges([{ field: 'doc', before: doc([], 'inline'), after: doc([{ id: 1 }], 'popup') }])
  assert.deepEqual(out, [
    { field: 'automations', before: [], after: [{ id: 1 }] },
    { field: 'display.mode', before: 'inline', after: 'popup' },
  ])
  assert.deepEqual(fieldLines([{ field: 'doc', before: doc([], 'inline'), after: doc([{ id: 1 }], 'popup') }]).fields.map((f) => [f.label, f.before, f.after]), [['Automations', 'None', '1 item'], ['Display mode', 'inline', 'popup']])
  // Seen on staging: a first display setting read "Where it shows · — → Changed".
  assert.deepEqual(expandChanges([{ field: 'display', before: null, after: { mode: 'popup', popupDelay: 5 } }]), [
    { field: 'display.mode', before: null, after: 'popup' },
    { field: 'display.popupDelay', before: null, after: 5 },
  ], 'appeared: its fields from nothing')
  assert.deepEqual(expandChanges([{ field: 'display', before: { mode: 'inline' }, after: 'off' }]), [{ field: 'display', before: { mode: 'inline' }, after: 'off' }], 'object replaced by a value: one line')
  assert.deepEqual(expandChanges([{ field: 'tags', before: ['a'], after: ['b'] }]), [{ field: 'tags', before: ['a'], after: ['b'] }])
  assert.deepEqual(expandChanges([{ field: 'doc', before: { a: 1 }, after: { a: 1 } }]), [], 'nothing really changed inside: no line')
})

check('block changes are named after the block', () => {
  const lines = blockLines([
    { kind: 'changed', tag: 'h1', label: 'Headline', fields: [{ field: 'textContent', before: 'Old', after: 'New' }] },
    { kind: 'added', tag: 'p', fields: [] },
    { kind: 'removed', label: 'Banner', fields: [] },
    { kind: 'changed', tag: 'div', fields: [{ field: 'className', before: 'a', after: 'b' }] },
  ])
  assert.deepEqual(lines[0], { field: 'Headline', before: 'Old', after: 'New' })
  assert.deepEqual(lines[1], { field: 'Paragraph', before: null, after: 'Added' }, 'an unlabelled block is named like a person would (seen: "<h2>")')
  assert.deepEqual(lines[2], { field: 'Banner', before: 'Present', after: 'Removed' })
  assert.equal(lines[3].after, 'class name changed')
  assert.equal(lines[3].field, 'Block')
  assert.equal(blockLines([{ kind: 'changed', tag: 'H2', fields: [{ field: 'textContent', before: 'a', after: 'b' }] }])[0].field, 'Heading')
})

const view = (over: Partial<ChangeView> = {}): ChangeView => ({
  key: 'cs:cs1', status: 'applied', entityType: 'Initiative', entityName: 'Clinic', href: '/admin/records/initiative/x',
  fields: [{ field: 'title', label: 'Title', before: 'A', after: 'B' }], more: 0, version: null, revisionId: null, canRestore: true,
  itemIds: ['i1'], canApprove: true, error: null, ...over,
})

check('header names the thing, version and count', () => {
  assert.deepEqual(widgetHeader(view({ version: 4, more: 2 })), { title: 'Changed Initiative “Clinic”', sub: 'Version 4 · 3 changes', badge: 'Saved' })
  assert.deepEqual(widgetHeader(view({ status: 'pending', entityName: null })), { title: 'Drafted a change to Initiative', sub: '1 change', badge: 'Waiting for approval' })
  // Golden 2b: after Reject the card must not say "Changed".
  assert.equal(widgetHeader(view({ status: 'rejected' })).title, 'Rejected a change to Initiative “Clinic”')
  assert.equal(widgetHeader(view({ status: 'stale' })).title, 'Not applied (out of date): change to Initiative “Clinic”')
  assert.equal(widgetHeader(view({ status: 'failed' })).title, 'Couldn’t apply a change to Initiative “Clinic”')
  for (const status of ['pending', 'rejected', 'stale', 'failed'] as const) assert.ok(!widgetHeader(view({ status })).title.startsWith('Changed'), status)
})

check('actions follow the stored state', () => {
  assert.deepEqual(widgetActions(view({ status: 'pending' })), ['approve', 'reject', 'open'])
  assert.deepEqual(widgetActions(view({ status: 'pending', canApprove: false })), ['open'], 'no review buttons for someone who cannot review')
  assert.deepEqual(widgetActions(view()), ['open'], 'no Compare/Restore without a revision')
  assert.deepEqual(widgetActions(view({ revisionId: 'r1' })), ['open', 'compare', 'restore'])
  assert.deepEqual(widgetActions(view({ revisionId: 'r1', canRestore: false })), ['open', 'compare'], 'Restore only for someone who may edit it')
  assert.deepEqual(widgetActions(view({ status: 'rejected', revisionId: 'r1' })), ['open'])
  assert.deepEqual(widgetActions(view({ status: 'stale', href: null })), [])
})

console.log(`\n${n} checks passed`)
