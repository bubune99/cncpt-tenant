/**
 * Every default for the assistant's plan and thought chain, in one place.
 * Fixed presets for now; per-site or per-user settings later read these as
 * their defaults. Plain words only: the person reads these strings.
 */

/** The tool the model calls to show, update or end a plan (lib/ai/tools/plan-tools). */
export const PLAN_TOOL = 'update_plan'

/** Tools that are plumbing, not steps the person cares about. */
export const PLUMBING_TOOLS: ReadonlySet<string> = new Set([PLAN_TOOL, 'load_tools', 'ask_user'])

export const PLAN_LIMITS = {
  /** Steps in one plan (more is a sign the request should be split). */
  maxSteps: 8,
  /** Characters in a step title. */
  titleCap: 80,
  /** Characters in a result line or the model's one line. */
  lineCap: 140,
  /** A request needing more than this many steps is planned, not done on the fly. */
  flyMaxSteps: 3,
} as const

/** What the person's message mid-plan does to the plan (playbook section 12). */
export const INTERRUPTIONS = ['side', 'amend', 'replace', 'pause', 'stop'] as const
export type Interruption = (typeof INTERRUPTIONS)[number]

/** Everything update_plan can do: the five interruptions plus starting, progress and carrying on. */
/** propose = show the plan and wait for Go (nothing runs); go = they said go: run it. */
export const PLAN_ACTIONS = ['start', 'propose', 'go', 'progress', 'resume', ...INTERRUPTIONS] as const
export type PlanAction = (typeof PLAN_ACTIONS)[number]

/** Unclear mid-plan input is a side question: the safest outcome (nothing changes). */
export const DEFAULT_INTERRUPTION: Interruption = 'side'

/**
 * Words that mark a request as one that changes something: those runs are
 * planned. Matched as whole words, case-insensitive.
 */
export const CHANGE_WORDS = [
  'add', 'create', 'make', 'draft', 'write', 'edit', 'update', 'change', 'fix', 'rename', 'move',
  'replace', 'remove', 'delete', 'publish', 'unpublish', 'send', 'set up', 'setup', 'schedule', 'approve',
  'reject', 'upload', 'feature', 'hide', 'build', 'turn on', 'turn off', 'enable', 'disable',
  // Filling a record or form in place (R6) is a change too.
  'fill', 'fill in', 'set',
] as const

/** Requests that ask for several things ("and then", "also") count as long. */
export const MANY_STEP_WORDS = ['and then', 'then', 'also', 'after that', 'step by step'] as const

/**
 * Run style follows what the person asks for (playbook 11 CLARIFIED). Later a Settings default
 * ("Show me a plan first: Never / For big jobs / Always"); for now this one constant.
 */
export type PlanFirst = 'never' | 'big' | 'always'
export const PLAN_FIRST_DEFAULT: PlanFirst = 'big'

/** They asked to see the plan first: show it, run nothing, wait for Go. */
export const PLAN_REQUEST_WORDS = ['plan it out', 'plan it first', 'plan first', 'plan this', 'make a plan', 'stop and plan', 'walk me through it', 'walk me through the steps', 'what would you do', 'let me approve', 'show me the plan', 'show me the steps', 'before you do anything'] as const

/** They asked to just do it: run on the fly. */
export const JUST_DO_WORDS = ['just do it', 'just run it', 'just fill', 'fill this in', 'fill it in', 'fill in', 'fill this', 'do it now', 'go ahead and'] as const

/** Bigger or riskier jobs get a short plan first by default (money, publishing, deleting, several records). */
export const RISK_WORDS = ['publish', 'unpublish', 'delete', 'remove', 'send', 'email everyone', 'refund', 'charge', 'price', 'prices', 'payment', 'all the', 'every', 'each', 'several', 'bulk'] as const

/** While a plan waits: these mean Go. */
export const GO_WORDS = ['go', 'go ahead', 'yes', 'yes go', 'run it', 'do it', 'looks good', 'start', 'ok', 'okay', 'sounds good'] as const

/** Code's first guess at an interruption, before the model picks the label. Order matters: first match wins. */
export const INTERRUPTION_WORDS: ReadonlyArray<readonly [Interruption, readonly string[]]> = [
  ['stop', ['never mind', 'nevermind', 'stop', 'cancel', 'forget it', 'leave it', 'drop it']],
  ['pause', ['hold on', 'wait', 'pause', 'one sec', 'one second', 'hang on', 'not yet']],
  ['replace', ['forget that', 'instead', 'rather', 'scrap that', 'start over', 'do something else']],
  ['amend', ['change the plan', 'skip', 'also', 'add a step', 'leave out', "don't do", 'do not do', 'before that', 'after that', 'first do']],
]

/** Words that mean "carry on" while a plan is paused. */
export const RESUME_WORDS = ['carry on', 'continue', 'go on', 'go ahead', 'resume', 'ok go', 'keep going'] as const

/** What the chain says. Plain US English, no tool names. */
export const CHAIN_COPY = {
  thinking: 'Thinking',
  planHeader: 'Plan',
  planSub: (n: number) => `${n} ${n === 1 ? 'step' : 'steps'} · nothing goes live without your OK`,
  workingHeader: 'Working',
  workingSub: (i: number, n: number) => `step ${i} of ${n}`,
  flyHeader: 'Working it out',
  flySub: 'steps appear as they’re found',
  pausedHeader: 'Paused',
  pausedSub: (i: number, n: number) => `at step ${i} of ${n} · nothing changed`,
  stoppedHeader: 'Stopped',
  fold: (n: number) => `${n} ${n === 1 ? 'step' : 'steps'}`,
  foldSkipped: (n: number) => `${n} skipped`,
  foldNeedsYou: 'needs you',
  foldFailed: (n: number) => `${n} didn’t work`,
  backToPlan: (i: number, n: number) => `Back to the plan (${i} of ${n})`,
  carryOnPrompt: 'Carry on with the plan',
  proposedSub: (n: number) => `${n} ${n === 1 ? 'step' : 'steps'} · nothing runs until you say go`,
  goLabel: 'Go',
  changeLabel: 'Change the plan',
  goPrompt: 'Go',
  changePrefix: 'Change the plan: ',
  // A plan change is one muted line (1a), never blue: "+ Added a step: …".
  added: (titles: readonly string[]) => `+ Added ${titles.length === 1 ? 'a step' : `${titles.length} steps`}: ${titles.join(', ')}`,
  skipped: (titles: readonly string[]) => `Skipped ${titles.length === 1 ? 'a step' : `${titles.length} steps`}: ${titles.join(', ')}`,
  replaced: (done: number, total: number) => `Plan replaced: the earlier plan stopped after ${done} of ${total} steps. Done steps stay done.`,
  paused: (i: number, n: number) => `Paused at step ${i} of ${n}. Nothing changed.`,
  stopped: (done: number, untouched: number) =>
    `Stopped. ${done} ${done === 1 ? 'step' : 'steps'} done; ${untouched} not touched. Done steps are kept.`,
  stepTag: { draft: 'Drafted', saved: 'Saved', needsYou: 'Waiting on you', skipped: 'Skipped', current: 'In progress' },
  trace: { lookedAt: 'Looked at', result: 'Result', effect: 'Effect', fullTrace: 'Full trace' },
  effect: { read: 'Read only, nothing changed', saved: 'Saved, with a version you can undo', draft: 'Drafted, not live', needsYou: 'Needs your OK', none: 'Nothing changed' },
  result: {
    failed: 'Didn’t work',
    drafted: 'Drafted, not live',
    saved: 'Saved',
    shown: 'Shown on screen',
    notShown: 'Not on screen',
    opened: 'Opened it',
    readScreen: 'Read the screen',
    private: 'Private, so not read',
    declined: 'Not done: you said no',
    waiting: 'Waiting for your OK',
    unfinished: 'Not finished',
    done: 'Done',
    found: (n: number) => `Found ${n}`,
    read: (title: string) => `Read “${title}”`,
  },
  problem: (title: string) => `Couldn’t finish “${title}”. Nothing else was changed.`,
  manualDefault: 'You can still do it yourself on that screen.',
  /** The 1a "Quiet ledger" (lib/ade/chat/chain-ledger). */
  ledger: {
    working: 'Working on it',
    waiting: 'Waiting on you',
    paused: 'Paused',
    stopped: 'Stopped',
    proposed: 'Here’s the plan',
    proposedSub: 'nothing runs until you say go',
    pausedMeta: 'paused',
    position: (at: number, of: number) => `${at} of ${of}`,
    flyPosition: (n: number) => `step ${n}`,
    details: 'Details',
    review: 'Review',
    reviewApproval: 'Review',
    retry: 'Try again',
    retryPrompt: (title: string) => `Try “${title}” again`,
    skip: 'Skip this step',
    skipPrompt: (title: string) => `Skip this step: “${title}”`,
    doneNext: (done: number, next: string | null) =>
      `${done} ${done === 1 ? 'step' : 'steps'} done${next ? ` · ${next} is next` : ''}`,
    fromStep: (n: number, title: string) => `From step ${n}: ${title}`,
  },
} as const

/** Shown to the model (static, cached): when to plan and how to handle interruptions. */
export const PLAN_GUIDANCE = `Use \`${PLAN_TOOL}\` so the person can follow your work. Code keeps the plan; you only say what happened.
- Run style follows what they ask (code tells you each turn): "plan it out first" / "walk me through it" → action "propose" with 2–${PLAN_LIMITS.maxSteps} short plain step titles, then STOP until they press Go; "just do it" / "fill this in" / a small change → on the fly, no plan — your steps show as they happen. After Go: action "go", then do the steps and call "progress" with the step number and one short result line as each finishes. Never tool names as titles.
- Found something that needs another step: action "amend" with \`add\`.
- When the person writes while a plan is active, pick ONE label and call \`${PLAN_TOOL}\` with it and one short line:
  "side" (a question; answer it, the plan stays), "amend" (skip, add or reorder steps: \`skip\` step numbers, \`add\` titles),
  "replace" (they want something else: new \`steps\`), "pause" (hold on / wait), "stop" (never mind). "resume" when they say carry on after a pause.
  If unsure, use "side". Done steps are never undone; a plan change never skips an approval.`
