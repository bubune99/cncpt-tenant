/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/context-label.assert.ts
 */
import assert from 'node:assert/strict'
import { contextLabel, looksLikeId } from './context-label'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('list screen: just the section', () => {
  assert.equal(contextLabel('Blog', null), 'Blog')
  assert.equal(contextLabel('Blog', undefined), 'Blog')
})

check('an item with a title: section · title', () => {
  assert.equal(contextLabel('Blog', 'My post'), 'Blog · My post')
  assert.equal(contextLabel('Initiatives', 'Reading club'), 'Initiatives · Reading club')
  assert.equal(contextLabel('Settings', 'Appearance'), 'Settings · Appearance')
})

check('missing or id-looking titles fall back to the section — never an id', () => {
  assert.equal(contextLabel('Blog', ''), 'Blog')
  assert.equal(contextLabel('Blog', '   '), 'Blog')
  assert.equal(contextLabel('Blog', 'undefined'), 'Blog')
  assert.equal(contextLabel('Blog', 'cms6825d40000r4izabh9'), 'Blog')
  assert.equal(contextLabel('Pages', '3f2b8c1e-9a7d-4e21-b5c4-0d9e8f7a6b5c'), 'Pages')
  assert.equal(contextLabel('Orders', '1042'), 'Orders')
  assert.ok(!looksLikeId('Our story'))
})

check('the title equal to the section is not repeated; no section → title or nothing', () => {
  assert.equal(contextLabel('Media', 'Media'), 'Media')
  assert.equal(contextLabel(null, 'Review a change'), 'Review a change')
  assert.equal(contextLabel(null, null), undefined)
  assert.equal(contextLabel(null, 'cms6825d40000r4izabh9'), undefined)
})

console.log(`\n${n} checks passed`)
