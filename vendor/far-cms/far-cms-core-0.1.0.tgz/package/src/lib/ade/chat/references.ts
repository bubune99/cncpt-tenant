/**
 * Click-to-reference: point at something on the screen and it rides along
 * with the next prompt ("make this match that"). The browser takes a plain
 * snapshot of the clicked element and its ancestors; this module decides
 * what it is (a page block, a named control, or any element), names it,
 * and writes it into the message the model reads.
 *
 * Host-agnostic: the host says which attribute marks blocks / controls.
 * Pure; asserted by references.assert.ts.
 */

export interface NodeSnapshot {
  tag: string
  id?: string
  classes?: string[]
  /** Only the attributes that identify things (data-*, aria-label, role, name, href, alt). */
  attrs?: Record<string, string>
  /** 1-based position among same-tag siblings. */
  nth?: number
}

export interface ElementSnapshot {
  /** Clicked element first, then its ancestors up to (not including) body. */
  chain: NodeSnapshot[]
  /** Visible text of the referenced element (trimmed by the browser side too). */
  text: string
  /** Where it was clicked (path or screen name). */
  screen: string
}

export interface RefMarkers {
  /** Attribute holding a page block id (e.g. data-block-id). */
  block: string
  /** Attribute marking the page canvas (blocks only count inside it). */
  canvas: string
  /** Attributes naming admin controls, best first (e.g. data-ui, data-help-key). */
  controls: readonly string[]
}

export type RefKind = 'block' | 'control' | 'element'

export interface ElementRef {
  kind: RefKind
  /** Block id, control id, or a short CSS path. */
  key: string
  /** Plain name for the chip ("Heading — “Our Story”"). */
  label: string
  tag: string
  text: string
  screen: string
  /** Cropped screenshot (data URL), when the browser could take one. */
  image?: string
  /** Inside [data-ade-private]: the reference only — no words, no screenshot. */
  private?: boolean
}

export const MAX_REFS = 4
const MAX_TEXT = 280

const TAG_NAMES: Record<string, string> = {
  h1: 'Heading',
  h2: 'Heading',
  h3: 'Heading',
  h4: 'Heading',
  h5: 'Heading',
  h6: 'Heading',
  p: 'Text',
  a: 'Link',
  button: 'Button',
  img: 'Image',
  video: 'Video',
  input: 'Field',
  textarea: 'Field',
  select: 'Field',
  section: 'Section',
  nav: 'Menu',
  header: 'Header',
  footer: 'Footer',
  form: 'Form',
  table: 'Table',
  tr: 'Row',
  li: 'Item',
  ul: 'List',
  ol: 'List',
}

function shorten(s: string, max: number): string {
  const t = s.replace(/\s+/g, ' ').trim()
  return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t
}

function cssEscape(s: string): string {
  return s.replace(/[^a-zA-Z0-9_-]/g, (c) => `\\${c}`)
}

/** A short, readable CSS path: stops at the first id or named control. */
export function cssPath(chain: readonly NodeSnapshot[], markers: Pick<RefMarkers, 'controls'>, maxDepth = 4): string {
  const segs: string[] = []
  for (const n of chain.slice(0, maxDepth)) {
    const named = markers.controls.find((a) => n.attrs?.[a])
    if (named) {
      segs.unshift(`[${named}="${n.attrs![named]}"]`)
      break
    }
    if (n.id && !/\d{4,}|^:r/.test(n.id)) {
      segs.unshift(`#${cssEscape(n.id)}`)
      break
    }
    segs.unshift(n.nth && n.nth > 1 ? `${n.tag}:nth-of-type(${n.nth})` : n.tag)
  }
  return segs.join(' > ')
}

/** What was clicked, as a reference (null when it's the assistant itself or nothing useful). */
export function toRef(snap: ElementSnapshot, markers: RefMarkers): ElementRef | null {
  if (snap.chain.length === 0) return null
  const inCanvas = snap.chain.some((n) => n.attrs?.[markers.canvas] !== undefined)
  const text = shorten(snap.text, MAX_TEXT)
  const quote = text ? ` — “${shorten(text, 32)}”` : ''

  if (inCanvas) {
    const at = snap.chain.findIndex((n) => n.attrs?.[markers.block])
    if (at >= 0) {
      const node = snap.chain[at]
      // The block wrapper is often a div around the real element: name it by what was clicked.
      const tag = (at > 0 ? snap.chain[0].tag : node.tag).toLowerCase()
      const kind = node.attrs?.['data-block-kind'] || TAG_NAMES[tag] || 'Block'
      return { kind: 'block', key: node.attrs![markers.block], label: `${kind}${quote}`, tag, text, screen: snap.screen }
    }
  }
  for (const attr of markers.controls) {
    const node = snap.chain.find((n) => n.attrs?.[attr])
    if (node) {
      const name = node.attrs?.['aria-label'] || text || node.attrs![attr]
      return { kind: 'control', key: `${attr}=${node.attrs![attr]}`, label: shorten(name, 40), tag: node.tag.toLowerCase(), text, screen: snap.screen }
    }
  }
  const first = snap.chain[0]
  const tag = first.tag.toLowerCase()
  const name = first.attrs?.['aria-label'] || first.attrs?.alt || ''
  return {
    kind: 'element',
    key: cssPath(snap.chain, markers),
    label: `${TAG_NAMES[tag] ?? 'Element'}${name ? ` — ${shorten(name, 32)}` : quote}`,
    tag,
    text,
    screen: snap.screen,
  }
}

/**
 * A reference to a functional unit (lib/ade/ui/view-units) the person
 * pointed at: `snap.chain[0]` is the unit itself and `name` its hover name
 * ("Button · Save"). In the page canvas it's the block, as toRef; elsewhere
 * the unit is keyed by its own control name, or by a short CSS path — never
 * by a bigger control it happens to sit inside.
 */
export function toUnitRef(snap: ElementSnapshot, markers: RefMarkers, name: string): ElementRef | null {
  if (snap.chain.length === 0) return null
  if (snap.chain.some((n) => n.attrs?.[markers.canvas] !== undefined)) return toRef(snap, markers)
  const self = snap.chain[0]
  const text = shorten(snap.text, MAX_TEXT)
  const tag = self.tag.toLowerCase()
  const attr = markers.controls.find((a) => self.attrs?.[a])
  if (attr) return { kind: 'control', key: `${attr}=${self.attrs![attr]}`, label: shorten(name, 48), tag, text, screen: snap.screen }
  return { kind: 'element', key: cssPath(snap.chain, markers), label: shorten(name, 48), tag, text, screen: snap.screen }
}

/** Swap one reference for another in place (clicking again climbs to the parent). */
export function replaceRef(list: readonly ElementRef[], old: ElementRef, ref: ElementRef): ElementRef[] {
  const at = list.findIndex((r) => r.kind === old.kind && r.key === old.key)
  if (at < 0) return addRef(list, ref)
  // The parent is already there: just drop the child.
  if (list.some((r) => r.kind === ref.kind && r.key === ref.key)) return list.filter((_, i) => i !== at)
  return list.map((r, i) => (i === at ? ref : r))
}

/** Add a reference (same thing twice replaces; oldest drops past the limit). */
export function addRef(list: readonly ElementRef[], ref: ElementRef): ElementRef[] {
  const rest = list.filter((r) => !(r.kind === ref.kind && r.key === ref.key))
  return [...rest, ref].slice(-MAX_REFS)
}

/** The text the model reads, numbered so the prompt can say "1" and "2". */
export function describeRefs(refs: readonly ElementRef[]): string {
  if (refs.length === 0) return ''
  const lines = refs.map((r, i) => {
    const what = r.kind === 'block' ? `page block id "${r.key}"` : r.kind === 'control' ? `screen control ${r.key}` : `element at ${r.key}`
    const shot = r.image ? ` (screenshot ${i + 1} attached)` : ''
    return `${i + 1}. ${r.label} — ${what}, <${r.tag}> on ${r.screen}${shot}${r.text ? `\n   Text: “${r.text}”` : ''}`
  })
  const missing = refs.some((r) => !r.image) ? '\n(Some references have no screenshot; work from the details above.)' : ''
  return `The person pointed at ${refs.length === 1 ? 'this' : 'these'} on screen (“this”, “that”, “1”, “2” refer to them):\n${lines.join('\n')}${missing}`
}

/** Message parts for the references: the description, then any screenshots in the same order. */
export function refParts(refs: readonly ElementRef[]): Array<{ type: 'text'; text: string } | { type: 'file'; mediaType: string; url: string; filename: string }> {
  if (refs.length === 0) return []
  const shots = refs.flatMap((r, i) => {
    const m = r.image ? /^data:(image\/(?:png|jpeg|webp));base64,/.exec(r.image) : null
    return m ? [{ type: 'file' as const, mediaType: m[1], url: r.image!, filename: `screenshot ${i + 1}` }] : []
  })
  return [{ type: 'text', text: describeRefs(refs) }, ...shots]
}
