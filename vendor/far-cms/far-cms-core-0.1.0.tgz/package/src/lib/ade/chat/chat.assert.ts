/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/chat/chat.assert.ts
 */
import assert from 'node:assert/strict'
import { ACCEPT, MAX_FILES_PER_MESSAGE, admitFiles, attachmentNote, attachmentParts, checkAttachmentParts, classifyFile, pruneAttachments } from './attachments'
import { MAX_REFS, addRef, cssPath, describeRefs, refParts, replaceRef, toRef, toUnitRef, type ElementSnapshot, type RefMarkers } from './references'
import { addThread, closeNeedsConfirm, closeThread, deriveStatus, newThread, patchThread, reportFor, titleFrom, tokensUsed, MAX_THREADS } from './threads'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const MB = 1024 * 1024

// ── Attachments ──────────────────────────────────────────────────────

check('kinds and limits, in plain words', () => {
  assert.deepEqual(classifyFile({ name: 'logo.PNG', type: 'image/png', size: 1000 }), { ok: true, kind: 'image', mediaType: 'image/png' })
  assert.deepEqual(classifyFile({ name: 'a.jpg', type: 'image/jpg', size: 1000 }), { ok: true, kind: 'image', mediaType: 'image/jpeg' })
  assert.deepEqual(classifyFile({ name: 'menu.pdf', type: 'application/pdf', size: 2 * MB }), { ok: true, kind: 'pdf', mediaType: 'application/pdf' })
  // Browsers leave .md / .csv untyped: the extension decides.
  assert.deepEqual(classifyFile({ name: 'notes.md', type: '', size: 500 }), { ok: true, kind: 'text', mediaType: 'text/markdown' })
  assert.deepEqual(classifyFile({ name: 'list.csv', type: 'application/octet-stream', size: 500 }), { ok: true, kind: 'text', mediaType: 'text/csv' })
  const big = classifyFile({ name: 'huge.png', type: 'image/png', size: 6 * MB })
  assert.ok(!big.ok && big.error === '“huge.png” is 6 MB — images can be up to 5 MB.')
  const word = classifyFile({ name: 'letter.docx', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', size: 100 })
  assert.ok(!word.ok && word.error.includes('save it as PDF'))
  const exe = classifyFile({ name: 'x.exe', type: 'application/x-msdownload', size: 100 })
  assert.ok(!exe.ok && exe.error.includes('images, PDFs or text files'))
  // A claimed type wins over a misleading extension only when the type is one we take.
  assert.ok(!classifyFile({ name: 'evil.png', type: 'text/html', size: 10 }).ok)
  assert.ok(!classifyFile({ name: 'empty.txt', type: 'text/plain', size: 0 }).ok)
  assert.ok(ACCEPT.includes('.pdf') && ACCEPT.includes('image/png'))
})

check('at most five files per message; the rest are refused by name', () => {
  const files = Array.from({ length: 4 }, (_, i) => ({ name: `p${i}.png`, type: 'image/png', size: 10 }))
  const r = admitFiles(files, 2)
  assert.equal(r.accepted.length, MAX_FILES_PER_MESSAGE - 2)
  assert.equal(r.errors.length, 1)
  assert.ok(r.errors[0].includes('p3.png'))
})

check('images/PDFs become file parts; text files become text', () => {
  const parts = attachmentParts([
    { name: 'logo.png', kind: 'image', mediaType: 'image/png', url: 'https://media.example.org/a.png' },
    { name: 'notes.md', kind: 'text', mediaType: 'text/markdown', text: '# Hi' },
  ])
  assert.deepEqual(parts[0], { type: 'file', mediaType: 'image/png', url: 'https://media.example.org/a.png', filename: 'logo.png' })
  assert.equal(parts[1].type, 'text')
  assert.ok((parts[1] as { text: string }).text.startsWith('Attached file “notes.md”:'))
  const long = attachmentParts([{ name: 'big.txt', kind: 'text', mediaType: 'text/plain', text: 'x'.repeat(25_000) }])
  assert.ok((long[0] as { text: string }).text.includes('the rest was cut'))
})

check('older turns keep a note instead of the file', () => {
  const msgs = [
    { role: 'user', parts: [{ type: 'file', mediaType: 'image/png', url: 'u1', filename: 'one.png' }, { type: 'text', text: 'a' }] },
    { role: 'assistant', parts: [{ type: 'text', text: 'ok' }] },
    { role: 'user', parts: [{ type: 'file', mediaType: 'image/png', url: 'u2', filename: 'two.png' }] },
    { role: 'user', parts: [{ type: 'text', text: 'c' }] },
  ]
  const out = pruneAttachments(msgs, 2)
  assert.deepEqual(out[0].parts![0], { type: 'text', text: '[Earlier attachment: one.png]' })
  assert.equal(out[2].parts![0].type, 'file')
  assert.equal(out[1], msgs[1])
})

check('server: only media-library URLs or small inline screenshots', () => {
  const policy = { allowedHosts: ['media.example.org'] }
  const ok = checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'application/pdf', url: 'https://media.example.org/m.pdf' }] }], policy)
  assert.deepEqual(ok, { ok: true, urls: ['https://media.example.org/m.pdf'] })
  const other = checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'image/png', url: 'https://evil.example.com/x.png' }] }], policy)
  assert.ok(!other.ok)
  const internal = checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'image/png', url: 'http://169.254.169.254/latest' }] }], policy)
  assert.ok(!internal.ok)
  const html = checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'text/html', url: 'https://media.example.org/x.html' }] }], policy)
  assert.ok(!html.ok)
  const shot = `data:image/jpeg;base64,${'A'.repeat(1000)}`
  assert.ok(checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'image/jpeg', url: shot }] }], policy).ok)
  const huge = `data:image/jpeg;base64,${'A'.repeat(600_000)}`
  assert.ok(!checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'image/jpeg', url: huge }] }], policy).ok)
  const svg = 'data:image/svg+xml;base64,AAAA'
  assert.ok(!checkAttachmentParts([{ role: 'user', parts: [{ type: 'file', mediaType: 'image/svg+xml', url: svg }] }], policy).ok)
  assert.equal(attachmentNote([{ type: 'file', filename: 'menu.pdf' }, { type: 'text' }, { type: 'file' }]), '[Attached: menu.pdf, screenshot]')
})

// ── References ───────────────────────────────────────────────────────

const markers: RefMarkers = { block: 'data-block-id', canvas: 'data-site-canvas', controls: ['data-ui', 'data-help-key'] }

check('a click on the page canvas references the block by id', () => {
  const snap: ElementSnapshot = {
    chain: [{ tag: 'H2' }, { tag: 'div', attrs: { 'data-block-id': 'b-123' } }, { tag: 'div', attrs: { 'data-site-canvas': '' } }],
    text: 'Our Story',
    screen: '/admin/pages/1/editor',
  }
  assert.deepEqual(toRef(snap, markers), { kind: 'block', key: 'b-123', label: 'Heading — “Our Story”', tag: 'h2', text: 'Our Story', screen: '/admin/pages/1/editor' })
})

check('on other screens: named controls first, then a short CSS path', () => {
  const ctl = toRef({ chain: [{ tag: 'span' }, { tag: 'button', attrs: { 'data-ui': 'todo-approve', 'aria-label': 'Approve all' } }], text: 'Approve', screen: '/admin/todo' }, markers)!
  assert.equal(ctl.kind, 'control')
  assert.equal(ctl.key, 'data-ui=todo-approve')
  assert.equal(ctl.label, 'Approve all')
  const help = toRef({ chain: [{ tag: 'div', attrs: { 'data-help-key': 'kpi-visitors' } }], text: '1,204 visitors', screen: '/admin' }, markers)!
  assert.equal(help.key, 'data-help-key=kpi-visitors')
  const el = toRef({ chain: [{ tag: 'td', nth: 3 }, { tag: 'tr', nth: 2 }, { tag: 'tbody' }, { tag: 'table', id: 'orders' }], text: '$40.00', screen: '/admin/orders' }, markers)!
  assert.equal(el.kind, 'element')
  assert.equal(el.key, '#orders > tbody > tr:nth-of-type(2) > td:nth-of-type(3)')
  assert.equal(cssPath([{ tag: 'div', id: ':r1a:' }, { tag: 'main' }], markers), 'main > div')
  assert.equal(toRef({ chain: [], text: '', screen: '/' }, markers), null)
})

check('a pointed-at unit is keyed by itself, never by a bigger control around it', () => {
  // A button inside a named panel: the button, by CSS path, named as the unit.
  const btn = toUnitRef({ chain: [{ tag: 'button', nth: 2 }, { tag: 'div', attrs: { 'data-ui': 'settings.panel' } }], text: 'Save', screen: '/admin/settings' }, markers, 'Button · Save')!
  assert.deepEqual(btn, { kind: 'element', key: '[data-ui="settings.panel"] > button:nth-of-type(2)', label: 'Button · Save', tag: 'button', text: 'Save', screen: '/admin/settings' })
  // A unit that carries its own control name keeps it.
  const own = toUnitRef({ chain: [{ tag: 'button', attrs: { 'data-ui': 'todo-approve' } }], text: 'Approve', screen: '/admin/todo' }, markers, 'Button · Approve')!
  assert.equal(own.key, 'data-ui=todo-approve')
  // In the page canvas it is still the block.
  const blk = toUnitRef({ chain: [{ tag: 'h2', attrs: { 'data-block-id': 'b-1' } }, { tag: 'div', attrs: { 'data-site-canvas': '' } }], text: 'Hi', screen: '/x' }, markers, 'Block · Hi')!
  assert.equal(blk.kind, 'block')
  assert.equal(toUnitRef({ chain: [], text: '', screen: '/' }, markers, 'x'), null)
})

check('clicking again swaps the reference for its parent, in the same slot', () => {
  const r = (key: string) => ({ kind: 'element' as const, key, label: key, tag: 'div', text: '', screen: '/' })
  const list = [r('a'), r('btn'), r('c')]
  assert.deepEqual(replaceRef(list, r('btn'), r('card')).map((x) => x.key), ['a', 'card', 'c'])
  assert.deepEqual(replaceRef(list, r('zz'), r('card')).map((x) => x.key), ['a', 'btn', 'c', 'card'])
  // The parent was already picked: no duplicate.
  assert.deepEqual(replaceRef(list, r('btn'), r('a')).map((x) => x.key), ['a', 'c'])
})

check('references: no duplicates, at most four, described in order for the model', () => {
  const r = (key: string, image?: string) => ({ kind: 'block' as const, key, label: `Block ${key}`, tag: 'div', text: '', screen: '/p', image })
  let list = addRef([], r('a'))
  list = addRef(list, r('a', 'data:image/png;base64,AA'))
  assert.equal(list.length, 1)
  assert.equal(list[0].image, 'data:image/png;base64,AA')
  for (const k of ['b', 'c', 'd', 'e']) list = addRef(list, r(k))
  assert.equal(list.length, MAX_REFS)
  assert.equal(list[0].key, 'b')
  const two = [r('x', 'data:image/jpeg;base64,AA'), r('y')]
  const d = describeRefs(two)
  assert.ok(d.startsWith('The person pointed at these on screen'))
  assert.ok(d.includes('1. Block x — page block id "x", <div> on /p (screenshot 1 attached)'))
  assert.ok(d.includes('Some references have no screenshot'))
  const parts = refParts(two)
  assert.equal(parts.length, 2)
  assert.deepEqual(parts[1], { type: 'file', mediaType: 'image/jpeg', url: 'data:image/jpeg;base64,AA', filename: 'screenshot 1' })
  assert.deepEqual(refParts([]), [])
})

// ── Threads ──────────────────────────────────────────────────────────

check('status follows the chat: thinking, waiting for you, done', () => {
  assert.equal(deriveStatus({ chatStatus: 'streaming', pendingApproval: false, messageCount: 3 }), 'thinking')
  assert.equal(deriveStatus({ chatStatus: 'ready', pendingApproval: true, messageCount: 3 }), 'waiting')
  assert.equal(deriveStatus({ chatStatus: 'ready', pendingApproval: false, messageCount: 3 }), 'done')
  assert.equal(deriveStatus({ chatStatus: 'ready', pendingApproval: false, messageCount: 0 }), 'idle')
  assert.equal(deriveStatus({ chatStatus: 'error', pendingApproval: false, messageCount: 2 }), 'error')
})

check('only background threads report to To-do, on the way out of thinking', () => {
  const t = { title: 'Fix the footer' }
  assert.equal(reportFor('thinking', 'done', t, true), null)
  assert.equal(reportFor('done', 'done', t, false), null)
  assert.equal(reportFor('idle', 'done', t, false), null)
  assert.deepEqual(reportFor('thinking', 'done', t, false)?.title, 'Assistant finished: Fix the footer')
  assert.equal(reportFor('thinking', 'waiting', t, false)?.kind, 'waiting')
  assert.equal(reportFor('thinking', 'error', t, false)?.kind, 'error')
})

check('thread list: add up to four, close moves to a neighbour, last one stays', () => {
  let ts = [newThread('a', 1)]
  for (const id of ['b', 'c', 'd']) {
    const r = addThread(ts, newThread(id, 2))
    assert.ok(r.ok)
    ts = r.threads
  }
  const over = addThread(ts, newThread('e', 3))
  assert.ok(!over.ok && over.error.includes(`Up to ${MAX_THREADS}`))
  assert.deepEqual(closeThread(ts, 'b', 'b'), { threads: ts.filter((t) => t.id !== 'b'), activeId: 'c' })
  assert.deepEqual(closeThread(ts, 'd', 'd').activeId, 'c')
  assert.deepEqual(closeThread(ts, 'b', 'a').activeId, 'a')
  assert.equal(closeThread([ts[0]], 'a', 'a').threads.length, 1)
  assert.equal(closeNeedsConfirm({ status: 'thinking' }), true)
  assert.equal(closeNeedsConfirm({ status: 'done' }), false)
  const same = patchThread(ts, 'a', { status: 'idle' })
  assert.equal(same, ts)
  assert.equal(patchThread(ts, 'a', { status: 'done' })[0].status, 'done')
})

check('titles and per-thread usage', () => {
  assert.equal(titleFrom('  Change the headline on the home page please '), 'Change the headline on the…')
  assert.equal(titleFrom(''), 'New thread')
  assert.equal(tokensUsed([{ role: 'assistant', metadata: { usage: { totalTokens: 1200 } } }, { role: 'user' }, { role: 'assistant', metadata: { usage: { totalTokens: 'x' } } }, { role: 'assistant', metadata: { usage: { totalTokens: 300 } } }]), 1500)
})

console.log(`\n${n} checks passed`)
