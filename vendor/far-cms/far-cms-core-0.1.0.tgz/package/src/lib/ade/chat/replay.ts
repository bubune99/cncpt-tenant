/**
 * A conversation that comes back (reload, history, To-do link) carries its
 * old tool results. The chat's screen effects (navigate, spotlight,
 * operate_ui) must not run them again: replaying a restored "navigate to
 * Settings" + "spotlight this" moved every agent window that reopened the
 * thread to /admin/settings and re-ran the spotlight there. Tool calls that
 * were already in the restored messages are marked handled up front.
 *
 * Pure. Run: npx -y tsx@4.23.15 src/lib/ade/chat/replay.assert.ts
 */

interface PartLike {
  type?: unknown
  toolCallId?: unknown
}
interface MessageLike {
  parts?: readonly PartLike[]
}

/** Every tool call id in these messages (any tool, any state). */
export function toolCallIdsIn(messages: readonly MessageLike[] | null | undefined): string[] {
  const out: string[] = []
  for (const m of messages ?? []) {
    for (const p of m.parts ?? []) {
      const type = typeof p.type === 'string' ? p.type : ''
      if ((type.startsWith('tool-') || type === 'dynamic-tool') && typeof p.toolCallId === 'string') out.push(p.toolCallId)
    }
  }
  return out
}
