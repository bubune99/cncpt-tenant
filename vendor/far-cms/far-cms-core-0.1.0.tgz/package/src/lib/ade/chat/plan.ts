/**
 * The assistant's plan as data held by code: steps, which one is current,
 * and the edits made along the way. The model only calls update_plan with
 * an action (one label) and a short line; everything here decides what that
 * does to the plan. The thought chain and the context card both read from
 * it. Pure, immutable; asserted by plan.assert.ts.
 */

import { cannotDo } from './cannot-do'
import {
  CHAIN_COPY,
  CHANGE_WORDS,
  DEFAULT_INTERRUPTION,
  GO_WORDS,
  JUST_DO_WORDS,
  PLAN_FIRST_DEFAULT,
  PLAN_REQUEST_WORDS,
  RISK_WORDS,
  type PlanFirst,
  INTERRUPTION_WORDS,
  MANY_STEP_WORDS,
  PLAN_ACTIONS,
  PLAN_LIMITS,
  PLAN_TOOL,
  RESUME_WORDS,
  type Interruption,
  type PlanAction,
} from './chain-constants'

export type PlanStepState = 'ahead' | 'current' | 'done' | 'skipped'
/** ended = a turn went by without touching it (code closes it so the next request starts fresh). */
export type PlanStatus = 'active' | 'waiting' | 'paused' | 'stopped' | 'done' | 'ended'

export interface PlanStep {
  id: string
  title: string
  state: PlanStepState
  /** One short result line, from the model's progress call. */
  result?: string
  /** Added along the way (amend). */
  added?: boolean
}

export interface Plan {
  steps: readonly PlanStep[]
  status: PlanStatus
}

/** An update_plan call, checked. */
export interface PlanCall {
  action: PlanAction
  steps?: string[]
  add?: Array<{ title: string; after?: number }>
  skip?: number[]
  step?: number
  result?: string
  line?: string
}

export type PlanEvent =
  | { kind: 'started' }
  | { kind: 'progress'; step: number }
  | { kind: 'side'; back: string | null }
  | { kind: 'amended'; note: string }
  | { kind: 'replaced'; note: string }
  | { kind: 'paused'; note: string }
  | { kind: 'resumed' }
  | { kind: 'stopped'; note: string; done: string[]; untouched: string[] }
  | { kind: 'ignored'; reason: string }

const clip = (s: string, n: number) => {
  const t = s.replace(/\s+/g, ' ').trim()
  return t.length > n ? `${t.slice(0, n - 1)}…` : t
}
const str = (v: unknown) => (typeof v === 'string' ? v : '')
const int = (v: unknown) => (typeof v === 'number' && Number.isInteger(v) ? v : typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : null)

/** Plain step titles, de-duplicated and capped. */
function titles(v: unknown): string[] {
  if (!Array.isArray(v)) return []
  const out: string[] = []
  for (const x of v) {
    const t = clip(typeof x === 'string' ? x : str((x as { title?: unknown } | null)?.title), PLAN_LIMITS.titleCap)
    if (t && !out.includes(t)) out.push(t)
  }
  return out.slice(0, PLAN_LIMITS.maxSteps)
}

/** Read an update_plan input (untrusted model output). Unknown actions → null. */
export function parsePlanCall(input: unknown): PlanCall | null {
  if (!input || typeof input !== 'object') return null
  const o = input as Record<string, unknown>
  const action = str(o.action) as PlanAction
  if (!(PLAN_ACTIONS as readonly string[]).includes(action)) return null
  const call: PlanCall = { action }
  const steps = titles(o.steps)
  if (steps.length) call.steps = steps
  if (Array.isArray(o.add)) {
    const add = o.add.flatMap((a) => {
      const title = clip(typeof a === 'string' ? a : str((a as { title?: unknown } | null)?.title), PLAN_LIMITS.titleCap)
      const after = typeof a === 'object' && a ? int((a as { after?: unknown }).after) : null
      return title ? [{ title, ...(after !== null ? { after } : {}) }] : []
    })
    if (add.length) call.add = add.slice(0, PLAN_LIMITS.maxSteps)
  }
  if (Array.isArray(o.skip)) {
    const skip = o.skip.map(int).filter((n): n is number => n !== null && n > 0)
    if (skip.length) call.skip = [...new Set(skip)]
  }
  const step = int(o.step)
  if (step !== null && step > 0) call.step = step
  const result = clip(str(o.result), PLAN_LIMITS.lineCap)
  if (result) call.result = result
  const line = clip(str(o.line), PLAN_LIMITS.lineCap)
  if (line) call.line = line
  return call
}

/** A fresh plan from step titles: the first is current. */
export function newPlan(stepTitles: readonly string[], idPrefix = 'p'): Plan | null {
  const t = titles(stepTitles)
  if (!t.length) return null
  return { status: 'active', steps: t.map((title, i) => ({ id: `${idPrefix}${i + 1}`, title, state: i === 0 ? 'current' : 'ahead' })) }
}

/** Position of the current step (1-based) and the number of steps still counted (skipped ones are not). */
export function planPosition(plan: Plan): { at: number; of: number } {
  const counted = plan.steps.filter((s) => s.state !== 'skipped')
  const cur = counted.findIndex((s) => s.state === 'current')
  const done = counted.filter((s) => s.state === 'done').length
  return { at: cur >= 0 ? cur + 1 : Math.min(done + 1, counted.length), of: counted.length }
}

/** No current step and something ahead → the first ahead step becomes current; nothing left → done. */
function settle(steps: PlanStep[], status: PlanStatus): Plan {
  if (status === 'active' && !steps.some((s) => s.state === 'current')) {
    const next = steps.findIndex((s) => s.state === 'ahead')
    if (next >= 0) steps[next] = { ...steps[next], state: 'current' }
    else if (steps.length) return { steps, status: 'done' }
  }
  return { steps, status }
}

/** waiting = shown, nothing run yet, until they press Go. */
const isOpen = (p: Plan | null): p is Plan => !!p && (p.status === 'active' || p.status === 'paused' || p.status === 'waiting')

/** Apply one update_plan call. Never mutates the plan given; done steps are never undone. */
export function applyPlanCall(plan: Plan | null, call: PlanCall, idPrefix = 'p'): { plan: Plan | null; event: PlanEvent } {
  const ignored = (reason: string) => ({ plan, event: { kind: 'ignored', reason } as PlanEvent })

  if (call.action === 'start' || call.action === 'replace' || call.action === 'propose') {
    const made = newPlan(call.steps ?? [], idPrefix)
    if (!made) return ignored('no steps')
    // A proposed plan (or a replacement of one that was waiting) runs nothing until Go: every step ahead.
    const waits = call.action === 'propose' || (call.action === 'replace' && plan?.status === 'waiting')
    const fresh: Plan = waits ? { status: 'waiting', steps: made.steps.map((s) => ({ ...s, state: 'ahead' as const })) } : made
    // A second "start" while a plan is open is a replace: the old one stops, its done steps stay done.
    if (isOpen(plan)) {
      const done = plan.steps.filter((s) => s.state === 'done').length
      const total = plan.steps.filter((s) => s.state !== 'skipped').length
      return { plan: fresh, event: { kind: 'replaced', note: CHAIN_COPY.replaced(done, total) } }
    }
    return { plan: fresh, event: { kind: 'started' } }
  }

  if (!isOpen(plan)) return ignored('no open plan')

  switch (call.action) {
    case 'go': {
      if (plan.status !== 'waiting') return ignored('nothing waiting')
      return { plan: settle([...plan.steps], 'active'), event: { kind: 'resumed' } }
    }
    case 'progress': {
      if (plan.status === 'paused' || plan.status === 'waiting') return ignored(plan.status)
      const i = (call.step ?? planPosition(plan).at) - 1
      const target = plan.steps.filter((s) => s.state !== 'skipped')[i]
      if (!target || target.state === 'done') return ignored('no such step')
      const steps = plan.steps.map((s) => (s.id === target.id ? { ...s, state: 'done' as const, ...(call.result ? { result: call.result } : {}) } : s))
      // Later steps marked done out of order leave the earlier current one current.
      return { plan: settle(steps, 'active'), event: { kind: 'progress', step: i + 1 } }
    }
    case 'side': {
      const { at, of } = planPosition(plan)
      return { plan, event: { kind: 'side', back: CHAIN_COPY.backToPlan(at, of) } }
    }
    case 'amend': {
      // Step numbers are the plan as the model saw it (before this call), so every anchor resolves against that.
      const counted = plan.steps.filter((s) => s.state !== 'skipped')
      const skipIds = new Set((call.skip ?? []).map((n) => counted[n - 1]).filter((s) => s && s.state !== 'done').map((s) => s.id))
      let steps: PlanStep[] = plan.steps.map((s) => (skipIds.has(s.id) ? { ...s, state: 'skipped' as const } : s))
      const room = PLAN_LIMITS.maxSteps - steps.filter((s) => s.state !== 'skipped').length
      const seen = new Set(steps.map((s) => s.title))
      const adds = (call.add ?? []).filter((a) => (seen.has(a.title) ? false : (seen.add(a.title), true))).slice(0, Math.max(0, room))
      const currentId = plan.steps.find((s) => s.state === 'current')?.id ?? null
      // Several steps added after the same anchor keep the order they were given in.
      const lastAfter = new Map<string, string>()
      let n = plan.steps.length
      for (const a of adds) {
        const step: PlanStep = { id: `${idPrefix}${++n}`, title: a.title, state: 'ahead', added: true }
        // after 0 = at the front; after N = after step N; none = right after the current step.
        const anchorId = a.after === 0 ? '^' : a.after !== undefined ? counted[a.after - 1]?.id ?? '$' : currentId ?? '$'
        const after = lastAfter.get(anchorId) ?? anchorId
        const at = after === '^' ? 0 : after === '$' ? steps.length : steps.findIndex((s) => s.id === after) + 1
        // Never before a done step.
        const firstOpen = steps.findIndex((s) => s.state !== 'done')
        const pos = Math.max(at, firstOpen < 0 ? steps.length : firstOpen)
        steps = [...steps.slice(0, pos), step, ...steps.slice(pos)]
        lastAfter.set(anchorId, step.id)
      }
      if (!skipIds.size && !adds.length) return ignored('nothing to change')
      const notes = [
        ...(adds.length ? [CHAIN_COPY.added(adds.map((a) => a.title))] : []),
        ...(skipIds.size ? [CHAIN_COPY.skipped(plan.steps.filter((s) => skipIds.has(s.id)).map((s) => s.title))] : []),
      ]
      return { plan: settle(steps, plan.status), event: { kind: 'amended', note: notes.join(' · ') } }
    }
    case 'pause': {
      if (plan.status === 'paused' || plan.status === 'waiting') return ignored('not running')
      const { at, of } = planPosition(plan)
      return { plan: { ...plan, status: 'paused' }, event: { kind: 'paused', note: CHAIN_COPY.paused(at, of) } }
    }
    case 'resume': {
      if (plan.status !== 'paused') return ignored('not paused')
      return { plan: settle([...plan.steps], 'active'), event: { kind: 'resumed' } }
    }
    case 'stop': {
      const done = plan.steps.filter((s) => s.state === 'done').map((s) => s.title)
      const untouched = plan.steps.filter((s) => s.state === 'ahead' || s.state === 'current').map((s) => s.title)
      // The step under way is not done: it goes back to "ahead", nothing is marked finished.
      const steps = plan.steps.map((s) => (s.state === 'current' ? { ...s, state: 'ahead' as const } : s))
      return { plan: { steps, status: 'stopped' }, event: { kind: 'stopped', note: CHAIN_COPY.stopped(done.length, untouched.length), done, untouched } }
    }
    default:
      return ignored('unknown action')
  }
}

interface PartLike {
  type?: unknown
  state?: unknown
  input?: unknown
}

/** The update_plan calls in a message's parts, in order (only calls whose input is complete). */
export function planCallsIn(parts: readonly unknown[]): PlanCall[] {
  return parts.flatMap((p) => {
    const part = (p ?? {}) as PartLike
    if (part.type !== `tool-${PLAN_TOOL}`) return []
    if (part.state === 'input-streaming' || part.state === undefined) return []
    const call = parsePlanCall(part.input)
    return call ? [call] : []
  })
}

/** The plan after a list of messages (each with parts), folding every update_plan call in order. */
export function planAfter(messages: ReadonlyArray<{ id?: string; role?: string; parts?: readonly unknown[] }>, start: Plan | null = null): Plan | null {
  let plan = start
  messages.forEach((m, mi) => {
    if (m.role !== 'assistant') return
    let touched = false
    planCallsIn(m.parts ?? []).forEach((c, ci) => {
      const r = applyPlanCall(plan, c, `${m.id ?? mi}-${ci}-`)
      if (r.event.kind !== 'ignored') touched = true
      plan = r.plan
    })
    plan = endTurn(plan, touched)
  })
  return plan
}

/**
 * Code keeps the plan's lifetime (the model rarely closes one): an active plan
 * that a whole reply went by without touching has ended, so the next request
 * starts fresh instead of being filed under an old step. A paused plan waits.
 */
export function endTurn(plan: Plan | null, touched: boolean): Plan | null {
  return plan && plan.status === 'active' && !touched ? { ...plan, status: 'ended' } : plan
}

/**
 * Code, not the model, starts and steers the plan (owner: Haiku's job stays small;
 * on staging Haiku called update_plan in 0 of 2 runs). On a new turn: a change or
 * long request with no open plan → force update_plan "start"; with a plan open,
 * clear words force pause / stop / amend / replace / resume. An unclear message
 * (a side question) is never forced. The route forces the tool on step 0.
 */
export function planToForce({ text, plan, newTurn }: { text: string; plan: Plan | null; newTurn: boolean }): PlanAction | null {
  if (!newTurn || !text.trim()) return null
  // Something the site cannot do at all gets a plain answer, not a plan to approve (lib/ade/chat/cannot-do).
  if (!isOpen(plan) && cannotDo(text)) return null
  // A plan is shown first (and waits for Go) only when the request calls for one; otherwise on the fly.
  if (!isOpen(plan)) return runStyle(text) === 'planned' ? 'propose' : null
  const guess = guessInterruption(text, plan)
  return guess && guess !== DEFAULT_INTERRUPTION ? guess : null
}

/** The per-turn line when code forces the plan tool on step 0. */
export function forcedPlanLine(action: PlanAction): string {
  if (action === 'propose') return `[Plan] Show the plan first: call ${PLAN_TOOL} with action "propose" and 2–${PLAN_LIMITS.maxSteps} short plain step titles, then STOP — nothing runs until they press Go (or change the plan).`
  if (action === 'go') return `[Plan] They said go: call ${PLAN_TOOL} with action "go", then do the steps, calling "progress" as each one finishes.`
  return action === 'start'
    ? `[Plan] Code starts this turn with ${PLAN_TOOL}: call it with action "start" and 2–${PLAN_LIMITS.maxSteps} short plain step titles, then do the work and call "progress" as each step finishes.`
    : `[Plan] Code starts this turn with ${PLAN_TOOL}: call it with action "${action}" and one short line${action === 'amend' ? ' (skip: step numbers / add: titles)' : action === 'replace' ? ' and the new steps' : ''}.`
}

const words = (text: string) => ` ${text.toLowerCase().replace(/[^a-z0-9' ]+/g, ' ').replace(/\s+/g, ' ')} `
const hasWord = (text: string, list: readonly string[]) => {
  const w = words(text)
  return list.some((x) => w.includes(` ${x} `))
}

/** Planned (changes something, or many steps) or on the fly (a simple question). */
/** Does the message ask for a change (rather than a question)? */
export function isChangeRequest(text: string): boolean {
  return hasWord(text, CHANGE_WORDS) || hasWord(text, JUST_DO_WORDS)
}

/** How many separate things the request asks for, roughly (facts, clauses, "and then"). */
export function requestSize(text: string): number {
  const clauses = text.split(/[,;:\n]|\band then\b|\bthen\b|\balso\b/i).map((s) => s.trim()).filter((s) => s.length > 2)
  return Math.max(1, clauses.length)
}

/**
 * Planned (show the plan, run nothing, wait for Go) or on the fly (do it; steps
 * appear as they happen) — from what the person asks (playbook 11 CLARIFIED):
 * an explicit plan request → planned; "just do it" / "fill this in" → on the fly;
 * no signal → on the fly, unless the setting says otherwise or the job is big or
 * risky (more than ~3 things, money, publishing, deleting, several records).
 */
export function runStyle(text: string, planFirst: PlanFirst = PLAN_FIRST_DEFAULT): 'planned' | 'fly' {
  if (hasWord(text, PLAN_REQUEST_WORDS)) return 'planned'
  if (hasWord(text, JUST_DO_WORDS)) return 'fly'
  if (!isChangeRequest(text) || planFirst === 'never') return 'fly'
  if (planFirst === 'always') return 'planned'
  const big = requestSize(text) > PLAN_LIMITS.flyMaxSteps || hasWord(text, MANY_STEP_WORDS)
  return big || hasWord(text, RISK_WORDS) ? 'planned' : 'fly'
}

/**
 * Code's guess at what a message sent mid-plan means. The model picks the
 * final label; this is the hint it gets. Paused + "carry on" → resume.
 * Anything unclear → side question.
 */
export function guessInterruption(text: string, plan: Plan | null): Interruption | 'resume' | 'go' | null {
  if (!isOpen(plan)) return null
  if (plan.status === 'paused' && hasWord(text, RESUME_WORDS)) return 'resume'
  // A waiting plan: "go" (or the Go button) runs it; a bare yes counts.
  if (plan.status === 'waiting' && (hasWord(text, GO_WORDS) || hasWord(text, RESUME_WORDS)) && text.trim().split(/\s+/).length <= 4) return 'go'
  for (const [label, list] of INTERRUPTION_WORDS) if (hasWord(text, list)) return label
  return DEFAULT_INTERRUPTION
}

/** The plan's state for the model's per-turn context: labels only, only while a plan is open. */
export function planContextLine(plan: Plan | null): string | null {
  if (!isOpen(plan)) return null
  const { at, of } = planPosition(plan)
  // Numbered as update_plan counts them (skipped steps are not counted), so "progress"/"skip"/"after" hit the right step.
  const counted = plan.steps.filter((s) => s.state !== 'skipped')
  const label = (s: PlanStep) => `${counted.indexOf(s) + 1}. “${s.title}”`
  const cur = counted.find((s) => s.state === 'current')
  const done = counted.filter((s) => s.state === 'done').map(label)
  const left = counted.filter((s) => s.state === 'ahead').map(label)
  return [
    `Plan (${plan.status}): step ${at} of ${of}`,
    done.length ? `done ${done.join(', ')}` : null,
    cur ? `now ${label(cur)}` : null,
    left.length ? `still to do ${left.join(', ')}` : null,
  ].filter(Boolean).join('; ')
}

/**
 * The per-turn hint: how to run this request, and what the person's words likely mean for an open plan.
 * `lineElsewhere`: the plan's line already rides in the context card (lib/ade/assistant/context-card), so leave it out here.
 */
export function planTurnHint(lastUserText: string, plan: Plan | null, opts: { lineElsewhere?: boolean } = {}): string {
  const line = planContextLine(plan)
  if (line) {
    const guess = guessInterruption(lastUserText, plan)
    return `[Plan] ${opts.lineElsewhere ? '' : `${line}. `}Their message looks like "${guess}"; call ${PLAN_TOOL} with the label you judge right (unsure → "side").`
  }
  return runStyle(lastUserText) === 'planned'
    ? `[Run style] plan first: call ${PLAN_TOOL} with action "propose", then stop until they press Go.`
    : `[Run style] on the fly: just do it — no plan; your steps show as they happen.`
}

/** Plumbing tools whose bad input code repairs instead of failing the run. */
export const REPAIRABLE_TOOLS: ReadonlySet<string> = new Set([PLAN_TOOL, 'load_tools', 'ask_user'])

const clipDeep = (v: unknown, depth = 0): unknown => {
  if (typeof v === 'string') return v.length > 2000 ? v.slice(0, 2000) : v
  if (Array.isArray(v)) return v.slice(0, 20).map((x) => clipDeep(x, depth + 1))
  if (v && typeof v === 'object' && depth < 6) return Object.fromEntries(Object.entries(v as Record<string, unknown>).slice(0, 40).map(([k, x]) => [k, clipDeep(x, depth + 1)]))
  return v
}

/**
 * A plumbing tool's input that failed its schema, repaired: update_plan is read
 * the way code reads it anyway (parsePlanCall clips titles to 80 characters,
 * caps the steps) and re-sent; the others are clipped. null = not repairable.
 */
export function repairPlumbingInput(toolName: string, input: unknown): string | null {
  if (!REPAIRABLE_TOOLS.has(toolName)) return null
  let raw: unknown = input
  if (typeof input === 'string') {
    try {
      raw = JSON.parse(input)
    } catch {
      return null
    }
  }
  if (toolName === PLAN_TOOL) {
    const call = parsePlanCall(raw)
    return call ? JSON.stringify(call) : null
  }
  return raw && typeof raw === 'object' ? JSON.stringify(clipDeep(raw)) : null
}
