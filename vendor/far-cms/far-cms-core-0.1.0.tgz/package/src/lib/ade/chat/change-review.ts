/**
 * Change review (assistant chat v2 P2): one shell (3a) for every change the
 * assistant made, with one of four bodies picked by what changed.
 *
 *   preview  pages, sections, initiatives, posts, cards, products: the rendered look (+ Fields)
 *   values   settings, prices, roles, anything without a look: old (struck) → new (bold), "Unchanged: …"
 *   batch    the same edit on many records: count, three rows, "N more · See all"
 *   action   emails, deletes, refunds: who it reaches, what they get, "can't be recalled"
 *
 * Anything not mapped falls back to values, so nothing is unsupported. The
 * header is a state word + "Kind · location"; the footer is one filled verb,
 * a text secondary and a muted "Open in editor"; after acting it collapses to
 * one 40px row: State · name · Undo / Open ("Not applied" has a dashed border).
 *
 * Pure and host-agnostic: it reads the ChangeView the server resolved
 * (lib/ade/chat/change-widgets) and an approval's tool input; every action
 * still goes through the existing approve / reject / approval paths.
 * Asserted by change-review.assert.ts.
 */

import type { ChangeStatus, ChangeView } from './change-widgets'
import { approvalCardModel, approvalForTool, type IrreversibleKind } from '../mobile/approval'

export type ReviewKind = 'preview' | 'values' | 'batch' | 'action'
/** Per change: draft (waiting) → live / saved / applied / sent, or rejected / failed. */
export type ReviewState = 'draft' | 'live' | 'saved' | 'applied' | 'sent' | 'rejected' | 'failed'

// ── Kind ─────────────────────────────────────────────────────────────

/** Things with a look on the site: their change is reviewed by looking at it. */
export const PREVIEW_TARGETS: ReadonlySet<string> = new Set([
  'page', 'page-content', 'partial', 'site-layout', 'record', 'initiative', 'blog-post', 'saved-block', 'product',
])

/**
 * Which body a change gets. A batch (the same edit on several records) is a
 * batch whatever it is; a thing with a look is a preview when there is a
 * render to show; everything else, and anything unknown, is values.
 */
export function kindOf(view: Pick<ChangeView, 'target' | 'previewPath' | 'batch'>): Exclude<ReviewKind, 'action'> {
  if (view.batch && view.batch.count > 1) return 'batch'
  if (view.target && PREVIEW_TARGETS.has(view.target) && view.previewPath) return 'preview'
  return 'values'
}

// ── State ────────────────────────────────────────────────────────────

const DONE_STATE: Record<Exclude<ReviewKind, 'action'>, ReviewState> = { preview: 'live', values: 'saved', batch: 'applied' }

export function stateOf(kind: ReviewKind, status: ChangeStatus, publishes = true): ReviewState {
  if (status === 'pending') return 'draft'
  if (status === 'rejected' || status === 'stale') return 'rejected'
  if (status === 'failed') return 'failed'
  if (kind === 'action') return 'sent'
  // A preview that saves a draft (a new initiative not yet public) is Saved, not Live.
  return kind === 'preview' && !publishes ? 'saved' : DONE_STATE[kind]
}

export const STATE_WORD: Record<ReviewState, string> = {
  draft: 'Draft',
  live: 'Live',
  saved: 'Saved',
  applied: 'Applied',
  sent: 'Sent',
  rejected: 'Not applied',
  failed: 'Didn’t apply',
}

/** The header's state word: an irreversible action that waits reads "Ready to send". */
export const headerWord = (kind: ReviewKind, state: ReviewState): string => (kind === 'action' && state === 'draft' ? 'Ready to send' : STATE_WORD[state])

// ── Words: header, verbs ─────────────────────────────────────────────

/** "Product · Kente Tote Bag", "24 products · Shop", "Settings · Donations". */
export function kindLine(view: Pick<ChangeView, 'entityType' | 'entityName' | 'batch'>): string {
  const what = view.batch && view.batch.count > 1 ? `${view.batch.count} ${view.batch.noun}` : view.entityType
  return [what, view.entityName].filter(Boolean).join(' · ')
}

/** The one filled button. Publish / Approve (preview), Save (values), Apply to N (batch). */
export function verbOf(kind: Exclude<ReviewKind, 'action'>, view: Pick<ChangeView, 'publishes' | 'batch'>): string {
  if (kind === 'batch') return `Apply to ${view.batch?.count ?? 0}`
  if (kind === 'values') return 'Save'
  return view.publishes === false ? 'Approve' : 'Publish'
}

/** The text secondary next to it. Reject stays reachable on every body. */
export function secondaryOf(kind: Exclude<ReviewKind, 'action'>): { keep: string | null; reject: string } {
  return kind === 'preview' ? { keep: 'Keep as draft', reject: 'Reject' } : { keep: null, reject: 'Discard' }
}

/** The Values body's "Unchanged: Currency, Receipts, 4 more". */
export function unchangedLine(names: readonly string[] | undefined, show = 2): string | null {
  const list = (names ?? []).filter((n) => n.trim())
  if (!list.length) return null
  const head = list.slice(0, show).join(', ')
  return list.length > show ? `${head}, ${list.length - show} more` : head
}

/** The Batch body's tail: "21 more · See all". */
export const batchMore = (count: number, shown: number): string | null => (count > shown ? `${count - shown} more` : null)

// ── Actions on a card ────────────────────────────────────────────────

/**
 * Can this change be undone from the chat? Only an applied change with a
 * recorded revision the person may restore, and only where the host has an
 * undo path (a revision undo endpoint). Without one the collapsed row offers
 * Open, never an Undo that does nothing.
 */
export function canUndo(view: Pick<ChangeView, 'status' | 'revisionId' | 'canRestore'>, hostUndo: boolean): boolean {
  return hostUndo && view.status === 'applied' && !!view.revisionId && view.canRestore
}

/** The change is waiting and this person may act on it. */
export const canAct = (view: Pick<ChangeView, 'status' | 'canApprove' | 'itemIds'>): boolean =>
  view.status === 'pending' && view.canApprove && view.itemIds.length > 0

// ── After acting: the one-line row ───────────────────────────────────

export interface CollapsedRow {
  state: ReviewState
  word: string
  name: string
  /** What the row offers on the right. */
  action: 'undo' | 'open' | null
  /** "Not applied": a dashed border. */
  dashed: boolean
}

/** The thing's name for a row: its own name, else its kind ("24 products", "Settings"). */
export const rowName = (view: Pick<ChangeView, 'entityType' | 'entityName' | 'batch'>): string =>
  view.entityName || (view.batch && view.batch.count > 1 ? `${view.batch.count} ${view.batch.noun}` : view.entityType)

/**
 * State · name · Undo / Open. `kept` = the person chose "Keep as draft": it
 * stays a draft, folded, with Open.
 */
export function collapsedRow(view: ChangeView, kind: ReviewKind, opts: { hostUndo: boolean; kept?: boolean }): CollapsedRow {
  const state = stateOf(kind, view.status, view.publishes ?? true)
  const open = view.href ? 'open' : null
  const action: CollapsedRow['action'] = state === 'draft' ? open : canUndo(view, opts.hostUndo) ? 'undo' : open
  return { state, word: STATE_WORD[state], name: rowName(view), action, dashed: state === 'rejected' }
}

/** A finished change folds; a waiting one shows its body (unless kept as a draft). */
export const isFolded = (view: Pick<ChangeView, 'status'>, kept = false): boolean => view.status !== 'pending' || kept

// ── Where you review it (4a / 4b) ────────────────────────────────────

/** 4a "Find it": the page's review screen brings the change into view. detail: { changeSetId, blockIds }. */
export const FIND_CHANGE_EVENT = 'ade:find-change'

/** The review-in-place screen for a change set: the draft on the real page. */
export const reviewPathFor = (changeSetId: string): string => `/admin/todo/review/${encodeURIComponent(changeSetId)}`

/** The change set behind a view key ("cs:<id>"); null for a recorded revision. */
export const changeSetOf = (key: string): string | null => (key.startsWith('cs:') ? key.slice(3) : null)

/**
 * 4a: is this change showing on the page open in the workspace right now?
 * Only previews have a page; values and actions never use 4a.
 */
export function showingOnPage(view: Pick<ChangeView, 'key' | 'status'>, kind: ReviewKind, workspacePath: string | null): boolean {
  if (kind !== 'preview' || view.status !== 'pending' || !workspacePath) return false
  const set = changeSetOf(view.key)
  return !!set && workspacePath.split(/[?#]/)[0] === reviewPathFor(set)
}

/** 4b "Show on page": where the draft is shown on its page (null = nothing to show). */
export function showOnPageHref(view: Pick<ChangeView, 'key' | 'status' | 'previewPath'>, kind: ReviewKind): string | null {
  const set = changeSetOf(view.key)
  return kind === 'preview' && view.status === 'pending' && set && view.previewPath ? reviewPathFor(set) : null
}

// ── Irreversible actions (approval cards) ────────────────────────────

/** What can't be taken back once approved: these sit under "CAN'T BE UNDONE" and never count in "Publish N". */
export const IRREVERSIBLE: ReadonlySet<IrreversibleKind> = new Set(['send-email', 'delete', 'refund', 'charge', 'cancel-order'])

const ACTION_NOUN: Partial<Record<IrreversibleKind, string>> = {
  'send-email': 'Email', delete: 'Delete', refund: 'Refund', charge: 'Charge', 'cancel-order': 'Order',
}

export interface ActionItem {
  /** The tool call: the approval card it stands for (data-call-id). */
  callId: string
  title: string
  /** "Email · 42 people". */
  line: string
  /** The approval card's own confirm words ("Send to 42"). */
  verb: string
  state: Extract<ReviewState, 'draft' | 'sent' | 'rejected'>
  /** No Approve anywhere (an email that can't be shown). */
  blind: boolean
}

/**
 * A pending or answered approval → its tray row, when it is one that can't
 * be undone. The row only points at the approval card; approving still
 * happens on that card, with its own words.
 */
export function actionItem(part: { toolCallId: string; toolName: string; input: Record<string, unknown>; resolved?: 'approved' | 'denied' }): ActionItem | null {
  const req = approvalForTool(part.toolName, part.input)
  const feedback = part.toolName === 'send_feedback_to_owner'
  // An email whose preview can't be read is still an email that can't be unsent (its card has no Approve).
  const blindEmail = !req && part.toolName === 'email_send_draft'
  if (!feedback && !blindEmail && (!req || !IRREVERSIBLE.has(req.kind))) return null
  const card = approvalCardModel(part.toolName, part.input, 'panel')
  if (!card) return null
  const n = req?.count && req.count > 1 ? `${req.count} people` : req?.target?.trim() || null
  const noun = feedback ? 'Feedback' : req ? ACTION_NOUN[req.kind] ?? 'Action' : 'Email'
  const subject = card.email?.rows.find(([k]) => k === 'Subject')?.[1]
  return {
    callId: part.toolCallId,
    title: subject || card.title,
    line: [noun, n].filter(Boolean).join(' · '),
    verb: card.confirmLabel || card.cancelLabel,
    state: part.resolved === 'approved' ? 'sent' : part.resolved === 'denied' ? 'rejected' : 'draft',
    blind: card.blind,
  }
}
