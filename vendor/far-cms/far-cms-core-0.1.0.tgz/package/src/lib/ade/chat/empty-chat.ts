/**
 * The empty chat (owner 2026-10-17, REVISION 2): a welcome headline, the
 * composer in the middle, and ONE "Try asking" component under it —
 * collapsed, the first six starter cards in a sideways row with page dots
 * and "View all"; expanded in place, every card under its category
 * ("Quick actions"), with "Show less". A card fills the composer and never
 * sends. The prompts are data supplied by the app (lib/ade-bindings);
 * this module is host-agnostic. Cards are neutral — soft grey, no colour,
 * no accent bars (owner R14; colour is only for a continuing conversation, R13).
 * Pure; asserted by empty-chat.assert.ts.
 */

export interface StarterCard {
  /** Bold first line. */
  title: string
  /** One muted line under it. */
  hint: string
  /** What the composer is filled with. */
  prompt: string
}

export interface StarterGroup {
  name: string
  cards: ReadonlyArray<StarterCard>
}

export interface StarterLibrary {
  groups: ReadonlyArray<StarterGroup>
  /** Titles for the collapsed row, in order; none → one card from each group in turn. */
  row?: ReadonlyArray<string>
}

/** Every number and word the empty chat uses. */
export const EMPTY_CHAT = {
  rowSize: 6,
  card: { width: 196, minHeight: 82, gap: 10, radius: 16 },
  /** The row's faded edge (and the inset the first card sits behind). */
  edge: 28,
  composer: { maxWidth: 640, minHeight: 58, radius: 22, textSize: 15.5 },
  headline: { size: 30, weight: 560, tracking: '-0.025em' },
  labels: { collapsed: 'Try asking', expanded: 'Quick actions', viewAll: 'View all', showLess: 'Show less' },
  /** The expanded library's top sits this far under the top of the scroll when it opens. */
  openOffset: 90,
} as const

/**
 * Which starters this screen shows (owner R3): a working screen supplies its
 * own page-specific starters, keyed by its screen key (lib/ade/screens);
 * any other screen gets the Home library.
 */
export function startersForScreen(home: StarterLibrary, byScreen: Readonly<Record<string, StarterLibrary>>, screenKey: string | null | undefined): StarterLibrary {
  const own = screenKey ? byScreen[screenKey] : undefined
  return own && own.groups.some((g) => g.cards.length > 0) ? own : home
}

/**
 * A working screen's live starters (its screen context: id, title, sub, prompt)
 * as a library for "Try asking": one group named for the page, its cards in
 * order, so the row shows the first six and "View all" shows them all.
 */
export function screenLibrary(label: string, starters: ReadonlyArray<{ title: string; sub?: string; prompt: string }>): StarterLibrary {
  return { groups: [{ name: label, cards: starters.map((s) => ({ title: s.title, hint: s.sub ?? '', prompt: s.prompt })) }] }
}

/** The collapsed row: the named cards, else one per group round-robin; never more than `max`. */
export function starterRow(lib: StarterLibrary, max: number = EMPTY_CHAT.rowSize): StarterCard[] {
  const all = lib.groups.flatMap((g) => g.cards)
  if (lib.row?.length) {
    const picked = lib.row.flatMap((t) => all.filter((c) => c.title === t).slice(0, 1))
    return dedupe(picked).slice(0, max)
  }
  const out: StarterCard[] = []
  const longest = Math.max(0, ...lib.groups.map((g) => g.cards.length))
  for (let i = 0; i < longest && out.length < max; i++) {
    for (const g of lib.groups) {
      if (g.cards[i] && out.length < max) out.push(g.cards[i])
    }
  }
  return out
}

function dedupe(cards: StarterCard[]): StarterCard[] {
  const seen = new Set<string>()
  return cards.filter((c) => (seen.has(c.title) ? false : (seen.add(c.title), true)))
}

/** How many whole cards one page of the row shows at this width (at least one). */
export function cardsPerPage(rowWidth: number, card: number = EMPTY_CHAT.card.width, gap: number = EMPTY_CHAT.card.gap, edge: number = EMPTY_CHAT.edge): number {
  const room = Math.max(0, rowWidth - edge * 2)
  return Math.max(1, Math.floor((room + gap) / (card + gap)))
}

export function pageCount(cards: number, perPage: number): number {
  return cards <= 0 ? 0 : Math.ceil(cards / Math.max(1, perPage))
}

/** Which page the row is on, from its scroll position (the last page when scrolled to the end). */
export function currentPage(scrollLeft: number, maxScroll: number, pages: number): number {
  if (pages <= 1 || maxScroll <= 0) return 0
  const t = Math.min(1, Math.max(0, scrollLeft / maxScroll))
  return Math.min(pages - 1, Math.round(t * (pages - 1)))
}

/** The card a dot scrolls to: the first card of that page. */
export function pageFirstCard(page: number, perPage: number, cards: number): number {
  if (cards <= 0) return 0
  return Math.min(cards - 1, Math.max(0, page) * Math.max(1, perPage))
}

/** Dots only when there is more than one page. */
export function showDots(pages: number): boolean {
  return pages > 1
}

/**
 * The briefing's one line, split for the welcome: the greeting sentence is the
 * headline, the rest a muted line under it. A line without a greeting
 * (loading, failed) is all subline.
 */
export function splitGreeting(line: string): { headline: string | null; subline: string } {
  const m = /^(Good (?:morning|afternoon|evening)(?:, [^.]+)?\.)\s*([\s\S]*)$/.exec(line.trim())
  if (!m) return { headline: null, subline: line.trim() }
  return { headline: m[1], subline: m[2] }
}

/** The welcome when the briefing has no greeting yet (loading / failed). */
export function welcomeHeadline(name: string | null, hour: number): string {
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'
  return name ? `${greet}, ${name}.` : `${greet}.`
}
