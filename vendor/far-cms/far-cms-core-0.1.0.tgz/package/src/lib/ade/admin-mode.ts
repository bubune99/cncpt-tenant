/**
 * Two ways to run the admin, same engine and approvals:
 *   workspace — agent-first: the assistant on the left, the real CMS screen
 *               on the right, action bar + ☰ menu, docked tools
 *   classic   — the familiar sidebar admin with the assistant as a side panel
 * A person's own choice wins; otherwise their role's default, which the site
 * owner sets. Pure; asserted by admin-mode.assert.ts.
 */

export type AdminMode = 'workspace' | 'classic'

export const ADMIN_MODES: ReadonlyArray<AdminMode> = ['workspace', 'classic']

export function isAdminMode(v: unknown): v is AdminMode {
  return v === 'workspace' || v === 'classic'
}

/** The role default: workspace when ANY of the person's roles is set to it. */
export function roleDefaultMode(roleNames: ReadonlyArray<string>, workspaceRoles: ReadonlyArray<string>): AdminMode {
  const set = new Set(workspaceRoles.map((r) => r.toLowerCase()))
  return roleNames.some((r) => set.has(r.toLowerCase())) ? 'workspace' : 'classic'
}

export function resolveAdminMode(
  userPref: unknown,
  roleNames: ReadonlyArray<string>,
  workspaceRoles: ReadonlyArray<string>
): { mode: AdminMode; source: 'user' | 'role' } {
  if (isAdminMode(userPref)) return { mode: userPref, source: 'user' }
  return { mode: roleDefaultMode(roleNames, workspaceRoles), source: 'role' }
}

/** Clean a role list from settings input (names only, bounded). */
export function normalizeWorkspaceRoles(v: unknown): string[] {
  if (!Array.isArray(v)) return []
  return Array.from(new Set(v.filter((r): r is string => typeof r === 'string' && r.trim() !== '' && r.length <= 64).map((r) => r.trim()))).slice(0, 50)
}

/**
 * Whether the action-bar (workspace) layout is on: the sidebar collapsed into
 * ☰, or the assistant agent-first. Agent-first needs a working assistant —
 * when it is resting the full CMS with its sidebar (Classic) comes back, so
 * nobody is left with a half-empty screen. Every task stays doable by hand.
 */
export function inWorkspaceLayout(s: { split: boolean; collapsed: boolean; assistantAvailable: boolean }): boolean {
  const agentDown = s.split && !s.assistantAvailable
  return !agentDown && (s.collapsed || s.split)
}

/**
 * What applying a mode does to the layout (owner 2026-10-17). The sidebar is
 * shown unless the PERSON closed it themselves — a mode default is never
 * stored as if they had. Workspace opens the assistant (when there's room);
 * Classic shows the sidebar and closes it.
 */
/**
 * The mode to store when the person hides or opens the assistant themselves (owner 2026-11-16:
 * "hiding it switches me to the classic admin until I open it again"); null = store nothing.
 */
export function modeAfterAssistant(action: 'hide' | 'open', current: AdminMode | null): AdminMode | null {
  if (action === 'hide') return current === 'classic' ? null : 'classic'
  return current === 'classic' ? 'workspace' : null
}

/**
 * Whether the assistant opens now. A mode that wants it opens it where there is room; below the
 * slide-over width it waits to be asked, except when the person just asked by pressing Open
 * workspace / Switch to Workspace (at 1068px that press did nothing, staging 2026-11-17).
 */
export function assistantOpensNow(s: { openAssistant: boolean; roomy: boolean; asked: boolean }): boolean {
  return s.openAssistant && (s.roomy || s.asked)
}

export function layoutForMode(mode: AdminMode, closedByPerson: boolean): { collapsed: boolean; openAssistant: boolean } {
  return mode === 'workspace' ? { collapsed: closedByPerson, openAssistant: true } : { collapsed: false, openAssistant: false }
}

/**
 * Which page editor a page opens in (owner 2026-10-17): the agent-first
 * editor only while the assistant is open beside it; otherwise the original
 * builder, until the agent-first one is cleaned up.
 */
export function pageEditorKind(s: { inWorkspace: boolean; assistantOpen: boolean }): 'agent-first' | 'original' {
  return s.inWorkspace && s.assistantOpen ? 'agent-first' : 'original'
}
