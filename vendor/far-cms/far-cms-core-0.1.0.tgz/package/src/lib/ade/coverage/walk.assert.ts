/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/coverage/walk.assert.ts
 */
import assert from 'node:assert/strict'
import { collectUnits, safeLabel, unitKind, walkScreen, type ReadViewLike, type ViewUnitLike, type WalkStepLike } from './walk'

let n = 0
const check = (name: string, fn: () => Promise<void> | void) => Promise.resolve(fn()).then(() => { n++; console.log(`ok ${n} - ${name}`) })

// A fake Settings screen in read_view's shapes: two tabs; the Privacy tab
// holds a collapsed "Advanced" section with a toggle; a "More" menu with Export.
type Tab = 'identity' | 'privacy'
export function fakeScreen() {
  let tab: Tab = 'identity'
  let advanced = false
  let menu = false
  let seq = 0
  const id = () => `u${++seq}`
  const view = (): ReadViewLike => {
    seq = 0
    const units: ViewUnitLike[] = [
      { id: id(), role: 'tabs', label: 'Sections', children: [
        { id: id(), role: 'tab', label: 'Identity', state: tab === 'identity' ? 'selected' : undefined, ...(tab !== 'identity' ? { hidden: 'inactive-tab' as const, action: 'open_tab' as const } : {}), stable: '[data-ui="settings.tab.identity"]' },
        { id: id(), role: 'tab', label: 'Privacy', state: tab === 'privacy' ? 'selected' : undefined, ...(tab !== 'privacy' ? { hidden: 'inactive-tab' as const, action: 'open_tab' as const, reveals: 'Privacy & cookies' } : {}), stable: '[data-ui="settings.tab.privacy"]' },
      ] },
      { id: id(), role: 'button', label: 'More', ...(menu ? {} : { hidden: 'menu' as const, action: 'open_menu' as const }), stable: '[data-ws-more]' },
    ]
    if (menu) units.push({ id: id(), role: 'menu', label: 'More', children: [{ id: id(), role: 'option', label: 'Export settings' }] })
    if (tab === 'identity') units.push({ id: id(), role: 'field', label: 'Site name' }, { id: id(), role: 'button', label: 'Save' })
    else {
      units.push({ id: id(), role: 'field', label: 'Cookie banner', state: 'on' })
      units.push({ id: id(), role: 'button', label: 'Advanced', ...(advanced ? { action: 'collapse' as const } : { hidden: 'collapsed' as const, action: 'expand' as const }) })
      if (advanced) units.push({ id: id(), role: 'field', label: 'Consent log', state: 'off', stable: '[data-ui="settings.consent_log"]' })
      units.push({ id: id(), role: 'link', label: 'Privacy policy', hidden: 'below-fold' })
    }
    return { ok: true, route: '/admin/settings', units }
  }
  const all = (us: ViewUnitLike[]): ViewUnitLike[] => us.flatMap((u) => [u, ...all(u.children ?? [])])
  const plan = (units: ViewUnitLike[]): WalkStepLike[] =>
    all(units)
      .filter((u) => u.hidden && u.action && u.action !== 'collapse' && u.hidden !== 'below-fold')
      .map((u) => ({ action: u.action as WalkStepLike['action'], unit: u.id, label: u.label }))
  const act = async (s: WalkStepLike) => {
    if (s.action === 'open_tab') tab = s.label === 'Privacy' ? 'privacy' : 'identity'
    if (s.action === 'expand') advanced = true
    if (s.action === 'open_menu') menu = true
    return { ok: true, view: view() }
  }
  return { read: async () => view(), plan, act }
}

async function main() {
  const walked = await walkScreen(fakeScreen())

  await check('the walk opens every tab, section and menu once, re-planning after each', async () => {
    assert.equal(walked.steps, 3)
    assert.equal(walked.truncated, false)
    assert.deepEqual(walked.snapshots.map((s) => s.path.map((p) => p.label)), [[], ['Privacy'], ['Privacy', 'Advanced'], ['More']])
  })

  const units = collectUnits(walked.snapshots)
  const by = (label: string) => units.find((u) => u.label === label)!

  await check('controls carry the path of the first view they appeared in', () => {
    assert.deepEqual(by('Site name').reveal, [])
    assert.deepEqual(by('Consent log').reveal.map((r) => `${r.action}:${r.label}`), ['open-tab:Privacy', 'expand:Advanced'])
    assert.deepEqual(by('Export settings').reveal.map((r) => r.action), ['open-menu'])
    assert.equal(by('Consent log').target, '[data-ui="settings.consent_log"]')
    assert.equal(by('Consent log').stable, true)
  })

  await check('below the fold → its own scroll step; containers dropped; kinds mapped', () => {
    assert.deepEqual(by('Privacy policy').reveal.map((r) => r.action), ['open-tab', 'scroll'])
    assert.ok(!units.some((u) => u.label === 'Sections'))
    assert.equal(by('Cookie banner').kind, 'toggle')
    assert.equal(by('Export settings').kind, 'action')
    assert.equal(unitKind({ role: 'field', state: 'required' }), 'field')
    assert.equal(by('Advanced').kind, 'other')
    assert.equal(unitKind({ role: 'tab', action: 'open_tab' }), 'tab')
  })

  await check('a capped walk says it stopped early; failed reveals are listed, not fatal', async () => {
    const capped = await walkScreen({ ...fakeScreen(), maxSteps: 1 })
    assert.equal(capped.truncated, true)
    const s = fakeScreen()
    const failing = await walkScreen({ ...s, act: async (st) => (st.action === 'open_menu' ? { ok: false } : s.act(st)) })
    assert.deepEqual(failing.failed, ['More'])
  })

  await check('Close/Cancel are not functions; units in a form or dialog carry their group', () => {
    assert.equal(unitKind({ role: 'button', label: 'Close' }), 'other')
    assert.equal(unitKind({ role: 'button', label: 'Close account' }), 'action')
    const snap = { path: [], units: [{ id: 'u1', role: 'dialog', label: 'Select Image', children: [{ id: 'u2', role: 'field', label: 'Image URL' }] }, { id: 'u3', role: 'field', label: 'Site name' }] } as unknown as Parameters<typeof collectUnits>[0][number]
    const got = collectUnits([snap])
    // The dialog is the unit; its field is a member, not a unit of its own.
    assert.deepEqual(got.find((x) => x.label === 'Select Image')!.members!.map((m) => m.label), ['Image URL'])
    assert.ok(!got.some((x) => x.label === 'Image URL'))
    assert.equal(got.find((x) => x.label === 'Site name')!.group, undefined)
  })

  await check('functional units: chips, fields and tab labels are reported as their form / section, not one by one (BYB Inventory)', () => {
    const h = (id: string, role: string, label: string, extra: Record<string, unknown> = {}) => ({ id, role, label, ...extra })
    const snap = {
      path: [],
      units: [
        h('u1', 'tabs', 'Inventory views', { children: [h('u2', 'tab', 'Stock', { state: 'selected' }), h('u3', 'tab', 'Write-offs')] }),
        h('u4', 'button', 'Add base product', { stable: '[data-ui="inventory.add_base"]' }),
        h('u5', 'button', 'Paste counts'),
        h('u6', 'form', 'Write-off form', {
          children: [
            h('u7', 'section', 'Reason', { children: [h('u8', 'button', 'Misprint', { state: 'pressed' }), h('u9', 'button', 'Damaged'), h('u10', 'button', 'Lost')] }),
            h('u11', 'field', 'Qty'),
            h('u12', 'button', 'Write off'),
          ],
        }),
        h('u13', 'section', 'Low stock alerts', { children: [h('u14', 'field', 'Alert below', { state: 'filled' }), h('u15', 'field', 'Email me', { state: 'off' })] }),
      ],
    } as unknown as Parameters<typeof collectUnits>[0][number]
    const got = collectUnits([snap])
    const actionable = got.filter((u) => u.kind === 'action' || u.kind === 'field' || u.kind === 'toggle').map((u) => u.label)
    assert.deepEqual(actionable, ['Add base product', 'Paste counts', 'Write-off form', 'Low stock alerts'])
    for (const chip of ['Misprint', 'Damaged', 'Lost', 'Qty', 'Write off', 'Reason', 'Alert below']) assert.ok(!got.some((u) => u.label === chip), chip)
    const form = got.find((u) => u.label === 'Write-off form')!
    assert.equal(form.kind, 'action')
    assert.deepEqual(form.members!.map((m) => m.label), ['Misprint', 'Damaged', 'Lost', 'Qty', 'Write off'])
    assert.equal(got.find((u) => u.label === 'Low stock alerts')!.kind, 'field')
    assert.equal(got.find((u) => u.label === 'Stock')!.kind, 'tab')
  })

  await check('cards side by side are a list of records: never read (like table rows)', () => {
    const h = (id: string, role: string, label: string, extra: Record<string, unknown> = {}) => ({ id, role, label, ...extra })
    const snap = {
      path: [],
      units: [
        h('u1', 'button', 'New initiative'),
        h('u2', 'section', 'Initiatives', { children: [h('u3', 'card', 'Akuse Hospital', { children: [h('u4', 'button', 'Edit Akuse Hospital')] }), h('u5', 'card', 'Community Clinic', { children: [h('u6', 'button', 'Edit Community Clinic')] })] }),
        h('u7', 'card', 'Danger zone', { children: [h('u8', 'button', 'Delete site')] }),
      ],
    } as unknown as Parameters<typeof collectUnits>[0][number]
    const got = collectUnits([snap]).map((u) => u.label)
    assert.ok(!got.some((l) => /Akuse|Clinic/.test(l)), JSON.stringify(got))
    // A lone card is a panel of the screen, not a record list.
    assert.ok(got.includes('Delete site'))
  })

  await check('a screen that never settles stops at the time budget (truncated, out of time) and names its slow reveals', async () => {
    let clock = 0
    const s = fakeScreen()
    // Every reveal "takes" 5 s; the budget is 8 s, so the walk stops after two (one left).
    const r = await walkScreen({ ...s, clock: () => clock, budgetMs: 8_000, act: async (st) => { clock += 5_000; return s.act(st) } })
    assert.equal(r.outOfTime, true)
    assert.equal(r.truncated, true)
    assert.equal(r.steps, 2)
    assert.equal(r.slow!.length, 2)
    assert.ok(r.slow!.every((x) => x.ms === 5_000))
    // A quick screen has neither.
    const quick = await walkScreen(fakeScreen())
    assert.equal(quick.outOfTime, undefined)
    assert.equal(quick.slow, undefined)
  })

  await check('a stale first read is refused (never stored as an empty screen); a stale step read counts as failed', async () => {
    await assert.rejects(() => walkScreen({ read: async () => ({ ok: false, route: '/admin/x', units: [] }), plan: () => [], act: async () => ({ ok: true }) }), /wasn’t ready/)
    const s = fakeScreen()
    const r = await walkScreen({ ...s, act: async (st) => (st.action === 'open_menu' ? { ok: true, view: { ok: false, route: '/admin/settings', units: [] } } : s.act(st)) })
    assert.deepEqual(r.failed, ['More'])
  })

  await check('never reads content: table rows, canvas blocks and select options are left out; labels capped', async () => {
    const content: ViewUnitLike[] = [
      { id: 'u1', role: 'button', label: 'New page' },
      { id: 'u2', role: 'table', label: 'Pages', children: [
        { id: 'u3', role: 'row', label: 'Akuse Hospital · Live', children: [{ id: 'u4', role: 'link', label: 'Akuse Hospital' }, { id: 'u5', role: 'button', label: 'Edit Akuse Hospital', action: 'expand' }] },
      ] },
      { id: 'u6', role: 'block', label: 'Hero', children: [{ id: 'u7', role: 'link', label: 'Support this initiative' }] },
      { id: 'u8', role: 'field', label: 'Category', children: [{ id: 'u9', role: 'option', label: 'Medical missions' }] },
      { id: 'u10', role: 'menu', label: 'More', children: [{ id: 'u11', role: 'option', label: 'Export' }] },
      { id: 'u12', role: 'button', label: `Publish ${'x'.repeat(200)}` },
    ]
    const labels = collectUnits([{ path: [], units: content }]).map((u) => u.label)
    for (const leaked of ['Akuse Hospital', 'Edit Akuse Hospital', 'Support this initiative', 'Medical missions']) assert.ok(!labels.includes(leaked), leaked)
    assert.ok(labels.includes('New page') && labels.includes('Export') && labels.includes('Category'))
    assert.ok(labels.every((l) => l.length <= 80))
    assert.equal(safeLabel('  two\n  lines  '), 'two lines')
    // …and the walk never opens a trigger that sits inside content.
    let acted = 0
    await walkScreen({ read: async () => ({ ok: true, route: '/admin/pages', units: content }), plan: () => [{ action: 'expand', unit: 'u5', label: 'Edit Akuse Hospital' }], act: async () => { acted++; return { ok: true } } })
    assert.equal(acted, 0)
  })

  console.log(`\n${n} checks passed`)
}

if (process.argv[1]?.endsWith('walk.assert.ts')) void main()
