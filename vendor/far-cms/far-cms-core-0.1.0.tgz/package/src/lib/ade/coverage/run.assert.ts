/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/coverage/run.assert.ts
 */
import assert from 'node:assert/strict'
import { runScreenCoverage } from './run'
import type { PlatformAction, UnitMatcher } from './logic'
import { fakeScreen } from './walk.assert'

let n = 0
const check = (name: string, fn: () => Promise<void> | void) => Promise.resolve(fn()).then(() => { n++; console.log(`ok ${n} - ${name}`) })

// Settings in the platform map: save identity, toggle cookie banner, export (no tool), reset theme (tool, no UI).
const actions: PlatformAction[] = [
  { entity: 'settings:identity', action: 'save', label: 'Save', synonyms: [], tools: ['updateSettings'], routes: ['/admin/settings'] },
  { entity: 'settings:privacy', action: 'cookie_banner', label: 'Cookie banner', synonyms: [], tools: ['updateSettings'], routes: ['/admin/settings'] },
  { entity: 'settings', action: 'export', label: 'Export settings', synonyms: [], tools: [], routes: ['/admin/settings'] },
  { entity: 'settings', action: 'reset_theme', label: 'Reset theme', synonyms: [], tools: ['resetTheme'], routes: ['/admin/settings'] },
]
// The host matcher (findAction stand-in) knows only "Save".
const matcherFor = (_route: string, acts: PlatformAction[]): UnitMatcher => (u) => (u.label === 'Save' ? acts[0] : undefined)

async function main() {
  const cov = await runScreenCoverage({ ...fakeScreen(), actionsFor: () => actions, matcherFor, toolNames: new Set(['updateSettings', 'resetTheme']), now: () => '2026-10-11T12:00:00Z' })

  await check('the three lists for the screen', () => {
    // Site name is saved by its tab's Save (updateSettings); Consent log's tab has no Save.
    assert.deepEqual(cov.row.toolGaps.sort(), ['Consent log', 'Export settings'].sort())
    assert.deepEqual(cov.row.uiGaps, ['Reset theme'])
    assert.deepEqual(cov.row.hiddenOnly.sort(), ['Consent log', 'Cookie banner', 'Export settings', 'Privacy policy'].sort())
  })

  await check('the walk-through tours a hidden control with a stable target', () => {
    assert.equal(cov.tour?.title, 'Where to find “Consent log”')
    assert.deepEqual(cov.tour?.steps.map((s) => s.caption), ['Open the “Privacy” tab.', 'Expand “Advanced”.', '“Consent log” is here.'])
    assert.equal(cov.tour?.steps[2].target, '[data-ui="settings.consent_log"]')
  })

  await check('hidden controls without a stable selector are listed (they need a data-ui)', () => {
    assert.ok(cov.needsStableTarget.includes('Cookie banner'))
    assert.ok(!cov.needsStableTarget.includes('Consent log'))
  })

  await check('unit detail names the action and the reveal path', () => {
    const save = cov.units.find((u) => u.label === 'Save')!
    assert.equal(save.action, 'settings:identity.save')
    assert.deepEqual(save.tools, ['updateSettings'])
    assert.deepEqual(cov.units.find((u) => u.label === 'Consent log')!.reveal, ['Privacy', 'Advanced'])
  })

  console.log(`\n${n} checks passed`)
}

void main()
