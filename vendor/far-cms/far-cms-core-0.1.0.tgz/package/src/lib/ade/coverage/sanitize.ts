/**
 * Coverage storage keeps the KIND of a control, never what it holds. Labels a
 * screen builds from its record ("Hero banner — “Delivering Hope”", "Tag the
 * contact Tag: volunteer", "Give store credit $5 gift-card balance") are cut
 * back to the control's own words before anything is stored. Generic: quoted
 * spans, everything after a "Key:" / " — " / " · " detail, and money/number
 * tokens. Pure; asserted by coverage-payload.assert.ts.
 *
 * Only for what is persisted (coverage rows, To-do items). The assistant's
 * read_view of a readable screen is not changed by this.
 */

const QUOTED = /[“"‘«][^”"’»]*[”"’»]?/g
/** " — detail", " – detail", " · detail": what follows is the item's content. */
const DETAIL = /\s+[—–·]\s*.*$/
/** "Tag: volunteer", "For: Trip coordinator": a key and its value (the key word goes too). */
const KEY_VALUE = /\s*[^\s:]+:(\s.*)?$/
/** "$5 gift-card balance …": an amount and the description that follows it. */
const MONEY = /\s*[$€£¥]\s?\d[\d.,]*.*$/
const NUMBER = /(^|\s)[#(]?\d[\d.,:/–-]*\)?(?=\s|$)/g
/** Values a field can be named by when it has no label: colours, emails, hosts and URLs. */
const VALUE_TOKEN = /(^|\s)(#[0-9a-f]{3,8}|\S+@\S+|https?:\/\/\S+|[\w-]+(\.[\w-]+)+\.[a-z]{2,})(?=\s|$)/gi

export function contentFreeLabel(label: string): string {
  return label
    .replace(/\s+/g, ' ')
    .replace(QUOTED, ' ')
    .replace(DETAIL, '')
    .replace(KEY_VALUE, '')
    .replace(MONEY, '')
    .replace(VALUE_TOKEN, '$1')
    .replace(NUMBER, '$1')
    .replace(/\(\s*[^\w\s]*\s*\)/g, '')
    .replace(/\s+/g, ' ')
    .replace(/[\s:·—–-]+$/, '')
    .trim()
}

/**
 * A selector is stored only when it names no content: data-ui / data-tour-id
 * style ids pass; an [aria-label="…"] (or similar) whose words aren't
 * content-free is dropped (null).
 */
export function contentFreeTarget(target: string): string | null {
  const attrs = [...target.matchAll(/\[([\w-]+)=["']([^"']*)["']\]/g)]
  for (const [, name, value] of attrs) {
    if (/^(data-ui|data-tour-id|data-help-key|data-ade-unit|role)$/.test(name)) continue
    if (contentFreeLabel(value) !== value.replace(/\s+/g, ' ').trim()) return null
  }
  return target
}

/** Verbs a list puts on every record ("Edit Akuse Hospital", "Hide Orders"). */
const PER_ITEM_VERB = /^(edit|delete|remove|open|view|duplicate|archive|restore|rename|hide|show|approve|reject|publish|unpublish|preview|select|icon for|more for|actions for|options for|menu for)\s+(.+)$/i

/**
 * Labels that name the record they act on: when one verb is used with two or
 * more different objects across a screen, the objects are records, so the
 * label becomes "Edit (each item)" instead of each record's name.
 */
export function perItemCollapser(labels: ReadonlyArray<string>): (label: string) => string {
  const objects = new Map<string, Set<string>>()
  for (const l of labels) {
    const m = PER_ITEM_VERB.exec(l)
    if (m) objects.set(m[1].toLowerCase(), (objects.get(m[1].toLowerCase()) ?? new Set()).add(m[2].toLowerCase()))
  }
  return (l) => {
    const m = PER_ITEM_VERB.exec(l)
    return m && (objects.get(m[1].toLowerCase())?.size ?? 0) >= 2 ? `${m[1][0].toUpperCase()}${m[1].slice(1).toLowerCase()} (each item)` : l
  }
}

/** A list with per-record labels collapsed, each once. */
export function collapsePerItem(labels: ReadonlyArray<string>, collapse = perItemCollapser(labels)): string[] {
  return [...new Set(labels.map(collapse))]
}

/**
 * Units named only by their own id's last segment (a rule card "every" with
 * data-ui="forms.rule.every"): when one prefix has two or more of them, the
 * segments are records' slugs, so each becomes "(each item)".
 */
export function slugCollapser(units: ReadonlyArray<{ id: string; label: string }>): (u: { id: string; label: string }) => string {
  const slugOf = (u: { id: string; label: string }) => {
    const m = /^\[data-ui=["']([\w.-]+)\.([\w-]+)["']\]$/.exec(u.id)
    return m && m[2].toLowerCase() === u.label.trim().toLowerCase() ? m[1] : null
  }
  const count = new Map<string, number>()
  for (const u of units) {
    const p = slugOf(u)
    if (p) count.set(p, (count.get(p) ?? 0) + 1)
  }
  return (u) => {
    const p = slugOf(u)
    return p && (count.get(p) ?? 0) >= 2 ? '(each item)' : u.label
  }
}
