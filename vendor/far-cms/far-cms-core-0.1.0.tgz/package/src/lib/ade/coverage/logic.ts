/**
 * Coverage check — pure core (app-agnostic; asserted by coverage.assert.ts).
 *
 * Input: the functional units a read of one admin screen found (every tab,
 * accordion, menu and scroll region expanded), the platform map's actions
 * (entity · action · synonyms · tools · routes) and the agent's tool names.
 * Output, per route, three lists:
 *   toolGaps   on screen, but no agent tool can do it
 *   uiGaps     the agent has a tool for it here, but the screen shows no way to do it
 *   hiddenOnly present, but only reachable through hidden UI (tabs, menus,
 *              collapsed panels…) — what tours and training should cover
 * …plus a replayable spotlight step list for any unit (reveal → highlight →
 * caption), in the tour system's spotlight_steps shape.
 */

/** How a hidden unit is revealed, in order (read_view's walk). */
export interface RevealStep {
  action: 'open-tab' | 'expand' | 'open-menu' | 'open-panel' | 'scroll' | 'click'
  /** Selector of the control to use (e.g. [data-ui="forms.tab.automations"]). */
  target: string
  /** What the control says, as the person sees it. */
  label: string
}

export interface CoverageUnit {
  /** Stable id: the data-ui id when there is one, else the selector. */
  id: string
  /** What it says on screen. */
  label: string
  kind: 'action' | 'field' | 'toggle' | 'tab' | 'link' | 'other'
  /** Selector for spotlighting it. */
  target: string
  /** Empty = visible as the screen opens. */
  reveal: ReadonlyArray<RevealStep>
  /** Extra words the reader found (aria-label, title, data-ui id) — used for matching. */
  hints?: ReadonlyArray<string>
  /** The form or dialog it sits in (e.g. "dialog:Select Image"); none = the screen itself. */
  group?: string
  /**
   * A functional unit (a form, dialog or section) lists the controls it was
   * built from — option chips, fields, tab labels, its buttons. They are
   * matched when the unit's own name isn't, and are never listed as units.
   */
  members?: ReadonlyArray<Pick<CoverageUnit, 'id' | 'label' | 'kind' | 'hints'>>
}

/** One thing the platform can do (platform map), and the tools that do it. */
export interface PlatformAction {
  entity: string
  action: string
  label: string
  synonyms: ReadonlyArray<string>
  /** Agent tool names (TOOL_REGISTRY keys). */
  tools: ReadonlyArray<string>
  /** Admin routes where a person does it (patterns like /admin/forms/:id). */
  routes: ReadonlyArray<string>
}

export interface MappedUnit {
  unit: CoverageUnit
  action: PlatformAction | null
  /** The action's tools the agent really has. */
  tools: string[]
  /** A field with no action of its own, saved by this button of its form (its label). */
  via?: string
}

export interface CoverageResult {
  route: string
  mapped: MappedUnit[]
  toolGaps: CoverageUnit[]
  uiGaps: PlatformAction[]
  hiddenOnly: MappedUnit[]
}

/** Units a person does something with (navigation-only units don't need a tool). */
const ACTIONABLE: ReadonlySet<CoverageUnit['kind']> = new Set(['action', 'field', 'toggle'])

export function normalizeLabel(s: string): string {
  return s
    .toLowerCase()
    .replace(/[‘’'"“”]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
}

/** Does a route match a pattern (":param" and "*" segments; exact otherwise). */
export function routeMatches(pattern: string, route: string): boolean {
  const clean = (p: string) => p.split('?')[0].replace(/\/+$/, '') || '/'
  const ps = clean(pattern).split('/')
  const rs = clean(route).split('/')
  if (ps[ps.length - 1] === '*') return rs.length >= ps.length - 1 && ps.slice(0, -1).every((seg, i) => seg.startsWith(':') || seg === rs[i])
  return ps.length === rs.length && ps.every((seg, i) => seg.startsWith(':') || seg === rs[i])
}

function words(u: CoverageUnit): string[] {
  return [u.label, u.id, ...(u.hints ?? [])].map(normalizeLabel).filter(Boolean)
}

/**
 * Best platform action for a unit: an exact label/synonym match first, then a
 * synonym contained in the unit's words (whole words only). Actions offered on
 * this route win ties.
 */
export function matchUnit(unit: CoverageUnit, actions: ReadonlyArray<PlatformAction>, route: string): PlatformAction | null {
  const unitWords = words(unit)
  let best: { a: PlatformAction; score: number } | null = null
  for (const a of actions) {
    const names = [a.label, ...a.synonyms].map(normalizeLabel).filter(Boolean)
    let score = 0
    for (const w of unitWords) {
      for (const nm of names) {
        if (w === nm) score = Math.max(score, 3)
        else if (` ${w} `.includes(` ${nm} `)) score = Math.max(score, 2)
      }
    }
    if (!score) continue
    if (a.routes.some((r) => routeMatches(r, route))) score += 0.5
    if (!best || score > best.score) best = { a, score }
  }
  return best?.a ?? null
}

/**
 * The host app's own label → action matcher (e.g. the platform map's
 * findAction), tried first so the coverage check and the assistant agree
 * about a button. Return undefined to fall back to matchUnit's scoring.
 */
export type UnitMatcher = (unit: CoverageUnit) => PlatformAction | null | undefined

/** Buttons that save what the fields around them hold. */
const COMMIT = /^(save|submit|apply|update|publish)\b/

export function mapUnits(
  units: ReadonlyArray<CoverageUnit>,
  actions: ReadonlyArray<PlatformAction>,
  toolNames: ReadonlySet<string>,
  route: string,
  matcher?: UnitMatcher
): MappedUnit[] {
  const find = (u: CoverageUnit) => matcher?.(u) ?? matchUnit(u, actions, route)
  const mapped: MappedUnit[] = units.map((unit) => {
    // The unit by its own name, else by what it holds (its buttons first: "Save" maps a form).
    let action = find(unit)
    if (!action && unit.members?.length) {
      const order = [...unit.members].sort((a, b) => Number(b.kind === 'action') - Number(a.kind === 'action'))
      for (const m of order) {
        action = find({ ...m, target: unit.target, reveal: unit.reveal })
        if (action) break
      }
    }
    return { unit, action, tools: action ? action.tools.filter((t) => toolNames.has(t)) : [] }
  })
  // A field is done through its form's Save: the field inherits that button's action —
  // same form or dialog, and the same tab/section showing (another tab has its own Save;
  // a picker dialog's fields aren't the page's Save).
  const scope = (u: CoverageUnit) => [u.group ?? '', ...u.reveal.filter((r) => r.action !== 'scroll').map((r) => r.target)].join('|')
  const saves = new Map<string, MappedUnit>()
  for (const m of mapped) {
    const k = scope(m.unit)
    if (m.action && m.unit.kind !== 'field' && m.unit.kind !== 'toggle' && COMMIT.test(normalizeLabel(m.unit.label)) && !saves.has(k)) saves.set(k, m)
  }
  return mapped.map((m) => {
    if (m.action || (m.unit.kind !== 'field' && m.unit.kind !== 'toggle')) return m
    const save = saves.get(scope(m.unit))
    return save ? { ...m, action: save.action, tools: save.tools, via: save.unit.label } : m
  })
}

/** The three lists for one screen. */
export function classifyCoverage(input: {
  route: string
  units: ReadonlyArray<CoverageUnit>
  actions: ReadonlyArray<PlatformAction>
  toolNames: ReadonlySet<string>
  /** Tried first; matchUnit's scoring only when it returns null/undefined. */
  matcher?: UnitMatcher
}): CoverageResult {
  const mapped = mapUnits(input.units, input.actions, input.toolNames, input.route, input.matcher)
  const toolGaps = mapped.filter((m) => ACTIONABLE.has(m.unit.kind) && m.tools.length === 0).map((m) => m.unit)
  const covered = new Set(mapped.filter((m) => m.action).map((m) => `${m.action!.entity}.${m.action!.action}`))
  const uiGaps = input.actions.filter(
    (a) => a.routes.some((r) => routeMatches(r, input.route)) && a.tools.some((t) => input.toolNames.has(t)) && !covered.has(`${a.entity}.${a.action}`)
  )
  // Things a person USES that only hidden UI reaches (not the tabs / expanders themselves).
  const hiddenOnly = mapped.filter((m) => m.unit.reveal.length > 0 && (ACTIONABLE.has(m.unit.kind) || m.unit.kind === 'link'))
  return { route: input.route, mapped, toolGaps, uiGaps, hiddenOnly }
}

// ---------------------------------------------------------------------------
// Training: the same walk as a replayable spotlight step list.
// ---------------------------------------------------------------------------

/** spotlight_steps step (the tour system's stored shape), plus the reveal for later recording. */
export interface TourStep {
  target: string
  caption: string
  position?: 'top' | 'bottom' | 'left' | 'right' | 'auto'
  /** Ignored by today's player; the recorder (later) performs it before highlighting. */
  meta?: { reveal?: RevealStep; unit?: string }
}

export const MAX_TOUR_STEPS = 12

const REVEAL_VERB: Record<RevealStep['action'], string> = {
  'open-tab': 'Open the',
  expand: 'Expand',
  'open-menu': 'Open the',
  'open-panel': 'Open the',
  scroll: 'Scroll to',
  click: 'Click',
}
const REVEAL_NOUN: Partial<Record<RevealStep['action'], string>> = { 'open-tab': 'tab', 'open-menu': 'menu', 'open-panel': 'panel' }

export function revealCaption(r: RevealStep): string {
  const noun = REVEAL_NOUN[r.action]
  return `${REVEAL_VERB[r.action]} “${r.label}”${noun && !normalizeLabel(r.label).endsWith(noun) ? ` ${noun}` : ''}.`
}

/** Reveal path, then the unit itself — at most MAX_TOUR_STEPS. */
export function tourStepsFor(unit: CoverageUnit, caption?: string): TourStep[] {
  const steps: TourStep[] = unit.reveal.map((r) => ({ target: r.target, caption: revealCaption(r), position: 'auto', meta: { reveal: r, unit: unit.id } }))
  steps.push({ target: unit.target, caption: caption ?? `“${unit.label}” is here.`, position: 'auto', meta: { unit: unit.id } })
  return steps.slice(-MAX_TOUR_STEPS)
}

// ---------------------------------------------------------------------------
// Per-route rows → one table for a sweep.
// ---------------------------------------------------------------------------

export interface CoverageRow {
  route: string
  at: string
  /** The agent may not read this route (visibility policy): not checked, lists empty. */
  private?: boolean
  units: number
  toolGaps: string[]
  uiGaps: string[]
  hiddenOnly: string[]
}

export function coverageRow(r: CoverageResult, at: string): CoverageRow {
  return {
    route: r.route,
    at,
    units: r.mapped.length,
    toolGaps: r.toolGaps.map((u) => u.label),
    uiGaps: r.uiGaps.map((a) => a.label),
    hiddenOnly: r.hiddenOnly.map((m) => m.unit.label),
  }
}

const count = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`

/** "Coverage of /admin/settings: 3 tool gaps, 1 UI gap, 4 only through hidden UI." */
export function coverageSentence(row: CoverageRow): string {
  if (row.private) return `Coverage of ${row.route}: private (not checked).`
  const bits = [count(row.toolGaps.length, 'tool gap'), count(row.uiGaps.length, 'UI gap'), `${row.hiddenOnly.length} only through hidden UI`]
  return `Coverage of ${row.route}: ${bits.join(', ')}.`
}

/** Latest row per route, sorted by route; the tool gap list across all routes (for building tools). */
export function coverageTable(rows: ReadonlyArray<CoverageRow>): { rows: CoverageRow[]; toolGapList: Array<{ label: string; routes: string[] }> } {
  const latest = new Map<string, CoverageRow>()
  for (const r of rows) {
    const prev = latest.get(r.route)
    if (!prev || prev.at < r.at) latest.set(r.route, r)
  }
  const sorted = [...latest.values()].sort((a, b) => a.route.localeCompare(b.route))
  const gaps = new Map<string, Set<string>>()
  for (const r of sorted) for (const g of r.toolGaps) (gaps.get(g) ?? gaps.set(g, new Set()).get(g)!).add(r.route)
  const toolGapList = [...gaps.entries()]
    .map(([label, routes]) => ({ label, routes: [...routes].sort() }))
    .sort((a, b) => b.routes.length - a.routes.length || a.label.localeCompare(b.label))
  return { rows: sorted, toolGapList }
}

/** The row stored for a route the agent may not read: the route only, nothing from the screen. */
export function privateRow(route: string, at: string): CoverageRow {
  return { route: route.split('?')[0], at, private: true, units: 0, toolGaps: [], uiGaps: [], hiddenOnly: [] }
}

/**
 * Where the person reads the full result: a real link (markdown) to the
 * screen's coverage item, never a description of where it might be. Only an
 * in-app /admin path is linked.
 */
export function coverageReportNote(href?: string | null): { note: string; report?: { label: string; href: string } } {
  const base = 'Read-only: nothing on the site was changed.'
  if (!href || !/^\/admin\/[\w\-/?=&%.]*$/.test(href)) return { note: `${base} The result is saved with this screen's To-do item.` }
  return { note: `${base} Full detail: [Coverage report for this screen](${href}).`, report: { label: 'Coverage report for this screen', href } }
}

/** The ONE coverage item in To-do (updated in place by every run; the detail lives in the coverage table). */
export const COVERAGE_REPORT_KEY = 'coverage:report'

/**
 * The single "Coverage report" To-do item for all stored rows: open while any
 * screen has a gap, with the totals and the screens that need the most work;
 * null when every checked screen is clean (the item closes).
 */
export function coverageReportTask(rows: ReadonlyArray<CoverageRow>): { title: string; detail: string } | null {
  const checked = rows.filter((r) => !r.private)
  const gaps = (r: CoverageRow) => r.toolGaps.length + r.uiGaps.length + r.hiddenOnly.length
  const withGaps = checked.filter((r) => gaps(r) > 0)
  if (!withGaps.length) return null
  const sum = (k: 'toolGaps' | 'uiGaps' | 'hiddenOnly') => checked.reduce((n, r) => n + r[k].length, 0)
  const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`
  const worst = [...withGaps].sort((a, b) => b.toolGaps.length - a.toolGaps.length || gaps(b) - gaps(a) || a.route.localeCompare(b.route)).slice(0, 5)
  return {
    title: `Coverage report: ${plural(withGaps.length, 'screen')} of ${checked.length} need a look`,
    detail: [
      `${plural(sum('toolGaps'), 'thing')} with no agent tool, ${plural(sum('uiGaps'), 'tool')} with nothing on screen, ${plural(sum('hiddenOnly'), 'control')} only through hidden UI.`,
      `Most to do: ${worst.map((r) => `${r.route} (${r.toolGaps.length} no tool)`).join(', ')}.`,
    ].join(' '),
  }
}
