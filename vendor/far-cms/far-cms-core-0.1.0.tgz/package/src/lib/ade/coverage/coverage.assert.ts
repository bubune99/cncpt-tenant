/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/coverage/coverage.assert.ts
 */
import assert from 'node:assert/strict'
import {
  classifyCoverage,
  coverageReportNote,
  coverageReportTask,
  coverageRow,
  coverageSentence,
  coverageTable,
  matchUnit,
  MAX_TOUR_STEPS,
  revealCaption,
  privateRow,
  routeMatches,
  tourStepsFor,
  type CoverageUnit,
  type PlatformAction,
} from './logic'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// A forms screen (stub of read_view's units) and a slice of the platform map.
const route = '/admin/forms/frm_test'
const units: CoverageUnit[] = [
  { id: 'forms.add_field', label: 'Add field', kind: 'action', target: '[data-ui="forms.add_field"]', reveal: [] },
  { id: 'forms.submit_review', label: 'Submit for review', kind: 'action', target: '[data-ui="forms.submit_review"]', reveal: [] },
  { id: 'forms.export_csv', label: 'Export CSV', kind: 'action', target: '[data-ui="forms.export_csv"]', reveal: [{ action: 'open-tab', target: '[data-ui="forms.tab.submissions"]', label: 'Submissions' }] },
  {
    id: 'forms.rule.toggle',
    label: 'Turn rule on',
    kind: 'toggle',
    target: '[data-ui="forms.rule.toggle"]',
    reveal: [
      { action: 'open-tab', target: '[data-ui="forms.tab.automations"]', label: 'Automations' },
      { action: 'expand', target: '[data-ui="forms.rule.1"]', label: 'When someone submits' },
    ],
    hints: ['automation on off'],
  },
  { id: 'forms.tab.settings', label: 'Settings', kind: 'tab', target: '[data-ui="forms.tab.settings"]', reveal: [] },
]
const actions: PlatformAction[] = [
  { entity: 'form', action: 'add_field', label: 'Add a field', synonyms: ['add field', 'new field'], tools: ['updateFormDoc'], routes: ['/admin/forms/:id'] },
  { entity: 'form', action: 'submit', label: 'Submit for review', synonyms: ['submit for review', 'propose'], tools: ['proposeFormChange'], routes: ['/admin/forms/:id'] },
  { entity: 'form', action: 'export_submissions', label: 'Export submissions', synonyms: ['export csv'], tools: ['exportSubmissions'], routes: ['/admin/forms/:id'] },
  { entity: 'form', action: 'toggle_automation', label: 'Turn an automation on or off', synonyms: ['automation on off', 'turn rule on'], tools: ['setAutomationEnabled'], routes: ['/admin/forms/:id'] },
  { entity: 'form', action: 'duplicate', label: 'Duplicate a form', synonyms: ['duplicate form', 'copy form'], tools: ['duplicateForm'], routes: ['/admin/forms/:id', '/admin/forms'] },
  { entity: 'page', action: 'publish', label: 'Publish a page', synonyms: ['publish'], tools: ['publishPage'], routes: ['/admin/pages/:id/editor'] },
]
// The agent has these tools (exportSubmissions is missing → a tool gap).
const toolNames = new Set(['updateFormDoc', 'proposeFormChange', 'setAutomationEnabled', 'duplicateForm', 'publishPage'])

check('routes match :params and trailing *', () => {
  assert.ok(routeMatches('/admin/forms/:id', '/admin/forms/frm_test'))
  assert.ok(!routeMatches('/admin/forms/:id', '/admin/forms'))
  assert.ok(routeMatches('/admin/settings/*', '/admin/settings/assistant/limits'))
  assert.ok(routeMatches('/admin/settings/*', '/admin/settings'))
  assert.ok(routeMatches('/admin/pages/:id/editor/', '/admin/pages/p1/editor?x=1'))
})

check('units match by label, synonym or hint (whole words)', () => {
  assert.equal(matchUnit(units[0], actions, route)?.action, 'add_field')
  assert.equal(matchUnit(units[3], actions, route)?.action, 'toggle_automation')
  assert.equal(matchUnit({ id: 'x', label: 'Republished items', kind: 'other', target: 'x', reveal: [] }, actions, route), null)
})

const result = classifyCoverage({ route, units, actions, toolNames })

check('tool gaps: on screen, no agent tool (tabs never count)', () => {
  assert.deepEqual(result.toolGaps.map((u) => u.id), ['forms.export_csv'])
})

check('UI gaps: a tool exists for this route but nothing on screen does it', () => {
  assert.deepEqual(result.uiGaps.map((a) => a.action), ['duplicate'])
})

check('hidden-only: reachable only through tabs / expanders', () => {
  assert.deepEqual(result.hiddenOnly.map((m) => m.unit.id), ['forms.export_csv', 'forms.rule.toggle'])
})

check('tour steps: reveal path then the control, in spotlight_steps shape', () => {
  const steps = tourStepsFor(units[3])
  assert.deepEqual(steps.map((s) => s.target), ['[data-ui="forms.tab.automations"]', '[data-ui="forms.rule.1"]', '[data-ui="forms.rule.toggle"]'])
  assert.equal(steps[0].caption, 'Open the “Automations” tab.')
  assert.equal(steps[1].caption, 'Expand “When someone submits”.')
  assert.equal(steps[2].caption, '“Turn rule on” is here.')
  assert.equal(steps[0].meta?.reveal?.action, 'open-tab')
  const long = tourStepsFor({ ...units[3], reveal: Array.from({ length: 20 }, (_, i) => ({ action: 'click' as const, target: `#s${i}`, label: `Step ${i}` })) })
  assert.equal(long.length, MAX_TOUR_STEPS)
  assert.equal(long[long.length - 1].target, '[data-ui="forms.rule.toggle"]')
})

check('reveal captions don’t double the noun', () => {
  assert.equal(revealCaption({ action: 'open-menu', target: '#m', label: 'More menu' }), 'Open the “More menu”.')
  assert.equal(revealCaption({ action: 'scroll', target: '#s', label: 'Danger zone' }), 'Scroll to “Danger zone”.')
})

check('rows, sentence and the sweep table (latest per route; gap list across routes)', () => {
  const row = coverageRow(result, '2026-10-11T10:00:00Z')
  assert.equal(coverageSentence(row), 'Coverage of /admin/forms/frm_test: 1 tool gap, 1 UI gap, 2 only through hidden UI.')
  const older = { ...row, at: '2026-10-10T10:00:00Z', toolGaps: ['Stale'] }
  const other = { route: '/admin/settings', at: '2026-10-11T09:00:00Z', units: 4, toolGaps: ['Export CSV', 'Reset theme'], uiGaps: [], hiddenOnly: [] }
  const t = coverageTable([older, row, other])
  assert.deepEqual(t.rows.map((r) => r.route), ['/admin/forms/frm_test', '/admin/settings'])
  assert.deepEqual(t.rows[0].toolGaps, ['Export CSV'])
  assert.deepEqual(t.toolGapList, [
    { label: 'Export CSV', routes: ['/admin/forms/frm_test', '/admin/settings'] },
    { label: 'Reset theme', routes: ['/admin/settings'] },
  ])
})

check('a private route: the route only, said plainly', () => {
  const p = privateRow('/admin/settings?section=people', '2026-10-11T12:00:00Z')
  assert.deepEqual(p, { route: '/admin/settings', at: '2026-10-11T12:00:00Z', private: true, units: 0, toolGaps: [], uiGaps: [], hiddenOnly: [] })
  assert.equal(coverageSentence(p), 'Coverage of /admin/settings: private (not checked).')
})

check('a field with no action of its own is done through its form’s Save (same form or dialog only)', () => {
  const save: PlatformAction = { entity: 'settings', action: 'update', label: 'update settings', synonyms: ['save'], tools: ['updateSettings'], routes: ['/admin/settings'] }
  const u = (label: string, kind: CoverageUnit['kind'], group?: string): CoverageUnit => ({ id: label, label, kind, target: `#${label}`, reveal: [], ...(group ? { group } : {}) })
  const r = classifyCoverage({
    route: '/admin/settings',
    units: [u('Site name', 'field'), u('Save', 'action'), u('Image URL', 'field', 'dialog:Select Image'), u('Use This URL', 'action', 'dialog:Select Image')],
    actions: [save],
    toolNames: new Set(['updateSettings']),
  })
  const site = r.mapped.find((m) => m.unit.label === 'Site name')!
  assert.deepEqual([site.action?.action, site.tools, site.via], ['update', ['updateSettings'], 'Save'])
  assert.deepEqual(r.toolGaps.map((g) => g.label), ['Image URL', 'Use This URL'])
})

check('a functional unit maps through what it holds (its button first), and only the unit is listed', () => {
  const writeOff: PlatformAction = { entity: 'inventory', action: 'write_off', label: 'write off stock', synonyms: ['write off'], tools: ['writeOffStock'], routes: ['/admin/inventory'] }
  const form: CoverageUnit = { id: 'form:write-off form', label: 'Write-off form', kind: 'action', target: '#wo', reveal: [], members: [{ id: 'button:misprint', label: 'Misprint', kind: 'action' }, { id: 'field:qty', label: 'Qty', kind: 'field' }, { id: 'button:write off', label: 'Write off', kind: 'action' }] }
  const paste: CoverageUnit = { id: 'button:paste counts', label: 'Paste counts', kind: 'action', target: '#pc', reveal: [] }
  const r = classifyCoverage({ route: '/admin/inventory', units: [form, paste], actions: [writeOff], toolNames: new Set(['writeOffStock']) })
  assert.equal(r.mapped[0].action?.action, 'write_off')
  assert.deepEqual(r.toolGaps.map((u) => u.label), ['Paste counts'])
})

check('the full report is a real link to the screen’s coverage item, never a description of a place', () => {
  const r = coverageReportNote('/admin/todo?item=cmabc123')
  assert.equal(r.note, 'Read-only: nothing on the site was changed. Full detail: [Coverage report for this screen](/admin/todo?item=cmabc123).')
  assert.deepEqual(r.report, { label: 'Coverage report for this screen', href: '/admin/todo?item=cmabc123' })
  assert.ok(!/\/admin\/settings coverage/.test(r.note))
  // Nothing outside the admin is linked; no link when the server didn't save one.
  for (const bad of ['https://evil.example/x', 'javascript:alert(1)', '/admin/todo?item=a)(b', undefined]) {
    const b = coverageReportNote(bad)
    assert.equal(b.report, undefined)
    assert.ok(!b.note.includes(']('))
  }
})

check('one Coverage report item for the whole sweep, not one per screen; it closes when everything is clean', () => {
  const r = (route: string, t: number, u = 0, h = 0, priv = false) => ({ route, at: '2026-10-11T10:00:00Z', units: 5, toolGaps: Array(t).fill('x'), uiGaps: Array(u).fill('y'), hiddenOnly: Array(h).fill('z'), ...(priv ? { private: true } : {}) })
  const task = coverageReportTask([r('/admin/settings', 9, 1, 4), r('/admin/blog', 2), r('/admin/clean', 0), r('/admin/secret', 0, 0, 0, true)])!
  assert.equal(task.title, 'Coverage report: 2 screens of 3 need a look')
  assert.equal(task.detail, '11 things with no agent tool, 1 tool with nothing on screen, 4 controls only through hidden UI. Most to do: /admin/settings (9 no tool), /admin/blog (2 no tool).')
  assert.equal(coverageReportTask([r('/admin/clean', 0), r('/admin/secret', 0, 0, 0, true)]), null)
  assert.equal(coverageReportTask([]), null)
  // At most five screens are named, worst first.
  const many = Array.from({ length: 8 }, (_, i) => r(`/admin/s${i}`, i + 1))
  assert.match(coverageReportTask(many)!.detail, /Most to do: \/admin\/s7 \(8 no tool\), \/admin\/s6.*\/admin\/s3 \(4 no tool\)\.$/)
})

console.log(`\n${n} checks passed`)
