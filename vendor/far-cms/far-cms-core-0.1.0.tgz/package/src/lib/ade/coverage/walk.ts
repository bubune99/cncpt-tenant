/**
 * Coverage check — the walk (app-agnostic; asserted by walk.assert.ts).
 *
 * Reads a screen, then repeatedly takes the next unexplored reveal from the
 * view's walk plan (open a tab, expand a section, open a menu, scroll), runs
 * it, and keeps the fresh view — opening a tab replaces what's below it, so
 * it plans again after every step. Every control is recorded with the reveal
 * path at which it first appeared. View-only: the injected actions are the
 * read_view navigation tools, which refuse anything that saves.
 *
 * Shapes follow lib/ade/ui/view-units (ViewUnit / WalkStep / ReadViewOutput),
 * typed structurally so this works before that module merges.
 */

import type { CoverageUnit, RevealStep } from './logic'

export interface ViewUnitLike {
  id: string
  role: string
  label: string
  state?: string
  hidden?: 'collapsed' | 'inactive-tab' | 'menu' | 'below-fold'
  action?: 'open_tab' | 'expand' | 'collapse' | 'open_menu' | 'scroll_to'
  reveals?: string
  /** A selector that survives re-reads (data-ui / data-tour-id …), when the reader found one. */
  stable?: string
  children?: ViewUnitLike[]
}

export interface ReadViewLike {
  ok: boolean
  route: string
  units: ViewUnitLike[]
}

export interface WalkStepLike {
  action: 'open_tab' | 'expand' | 'open_menu' | 'scroll_to'
  unit: string
  label: string
  reveals?: string
  /** The control's stable selector, when it has one (finds it again after a read that stamped nothing). */
  stable?: string
}

export interface WalkDeps {
  read: () => Promise<ReadViewLike>
  plan: (units: ViewUnitLike[]) => WalkStepLike[]
  act: (step: WalkStepLike) => Promise<{ ok: boolean; view?: ReadViewLike }>
  /** Safety cap on reveals for one screen. */
  maxSteps?: number
  /** Time cap for one screen (ms): a screen that never settles stops here, truncated. */
  budgetMs?: number
  /** Clock in ms (injected so the budget is testable). */
  clock?: () => number
}

/** Reveals slower than this are reported (what made a screen slow). */
export const SLOW_STEP_MS = 3000

export interface WalkSnapshot {
  path: RevealStep[]
  units: ViewUnitLike[]
}

export interface WalkResult {
  route: string
  snapshots: WalkSnapshot[]
  steps: number
  /** Stopped at maxSteps or the time budget with reveals left. */
  truncated: boolean
  failed: string[]
  /** Reveals that took longer than SLOW_STEP_MS (label, ms). */
  slow?: Array<{ label: string; ms: number }>
  /** Ran out of time (budgetMs) rather than steps. */
  outOfTime?: boolean
}

const ACTION_MAP: Record<WalkStepLike['action'], RevealStep['action']> = { open_tab: 'open-tab', expand: 'expand', open_menu: 'open-menu', scroll_to: 'scroll' }

/**
 * Content containers: what's inside them is the site's DATA (table rows,
 * page-canvas blocks, embedded frames) — names, values, copy. The coverage
 * check never reads into them; it only records the controls of the screen.
 */
export const CONTENT_ROLES: ReadonlySet<string> = new Set(['table', 'row', 'block', 'frame'])

/** Every unit outside content containers, with its parent's role. */
export function flattenUnits(units: ReadonlyArray<ViewUnitLike>): ViewUnitLike[] {
  return flattenWithParent(units).map((x) => x.unit)
}

/** Containers whose Save button saves the fields inside them. */
const GROUP_ROLES: ReadonlySet<string> = new Set(['form', 'dialog'])
/**
 * Functional units (the owner's selection rule): a form or dialog is one unit
 * with everything inside it; elsewhere a labelled section (section, fieldset,
 * region, named group) is. Cards are not — a card's title is often a record's.
 */
const SECTION_ROLES: ReadonlySet<string> = new Set(['section'])

/** The functional unit a control belongs to. */
export interface UnitContainer {
  key: string
  role: string
  label: string
  unit: ViewUnitLike
}

export function flattenWithParent(
  units: ReadonlyArray<ViewUnitLike>
): Array<{ unit: ViewUnitLike; parentRole: string | null; group?: string; container?: UnitContainer }> {
  const out: Array<{ unit: ViewUnitLike; parentRole: string | null; group?: string; container?: UnitContainer }> = []
  const walk = (us: ReadonlyArray<ViewUnitLike>, parentRole: string | null, group?: string, container?: UnitContainer) => {
    // Cards side by side are a list of records (initiatives, posts): like table rows, never read.
    const cardList = us.filter((x) => x.role === 'card').length >= 2
    for (const u of us) {
      if (CONTENT_ROLES.has(u.role) || (cardList && u.role === 'card')) continue
      out.push({ unit: u, parentRole, group, container })
      if (!u.children?.length) continue
      const named = safeLabel(u.label)
      const inForm = container && GROUP_ROLES.has(container.role)
      // Inside a form or dialog nothing narrower takes over; otherwise the nearest named section does.
      const next =
        named && (GROUP_ROLES.has(u.role) ? !inForm : SECTION_ROLES.has(u.role) && !inForm)
          ? { key: `${u.role}:${named.toLowerCase()}`, role: u.role, label: named, unit: u }
          : container
      walk(u.children, u.role, GROUP_ROLES.has(u.role) ? `${u.role}:${named}` : group, next)
    }
  }
  walk(units, null)
  return out
}

/** A label as stored: one line, at most 80 characters (labels name controls; they are not content). */
export function safeLabel(label: string): string {
  const one = label.replace(/\s+/g, ' ').trim()
  return one.length > 80 ? `${one.slice(0, 79)}…` : one
}

/** A unit's selector: the stable one when known, else this read's data-ade-unit. */
export function unitSelector(u: Pick<ViewUnitLike, 'id' | 'stable'>): string {
  return u.stable || `[data-ade-unit="${u.id}"]`
}

const stepKey = (s: Pick<WalkStepLike, 'action' | 'label'>) => `${s.action}:${s.label.trim().toLowerCase()}`

export async function walkScreen(deps: WalkDeps): Promise<WalkResult> {
  const max = deps.maxSteps ?? 40
  const now = deps.clock ?? (() => Date.now())
  const started = now()
  const budget = deps.budgetMs ?? 90_000
  const slow: Array<{ label: string; ms: number }> = []
  let outOfTime = false
  let view = await deps.read()
  // A read that isn't of this screen (still navigating, stale) must not be stored as "nothing here".
  if (!view.ok) throw new Error('The screen wasn’t ready to read (it was still changing) — try again.')
  const snapshots: WalkSnapshot[] = [{ path: [], units: view.units }]
  // The reveal path at which each trigger was first seen.
  const pathOf = new Map<string, RevealStep[]>()
  const done = new Set<string>()
  const note = (units: ReadonlyArray<ViewUnitLike>, path: RevealStep[]) => {
    for (const u of flattenUnits(units)) {
      // A tab already showing has been seen: never "open" it again.
      if (u.role === 'tab' && /(^|,)\s*(selected|current)\s*(,|$)/.test(u.state ?? '')) done.add(stepKey({ action: 'open_tab', label: u.label }))
      if (u.action && u.action !== 'collapse') {
        const k = stepKey({ action: u.action, label: u.label })
        if (!pathOf.has(k)) pathOf.set(k, path)
      }
    }
  }
  note(view.units, [])
  const failed: string[] = []
  let steps = 0
  while (steps < max) {
    if (now() - started >= budget) {
      outOfTime = true
      break
    }
    // Depth first: explore what the last reveal uncovered before going back up
    // (opening a sibling tab would replace it).
    // Never open things inside content (a table row, a canvas block): only the screen's own controls.
    const controls = new Set(flattenUnits(view.units).map((u) => u.id))
    const next = deps
      .plan(view.units)
      .filter((s) => !done.has(stepKey(s)) && controls.has(s.unit))
      .sort((a, b) => (pathOf.get(stepKey(b))?.length ?? 0) - (pathOf.get(stepKey(a))?.length ?? 0))[0]
    if (!next) break
    done.add(stepKey(next))
    steps++
    const trigger = flattenUnits(view.units).find((u) => u.id === next.unit)
    const reveal: RevealStep = { action: ACTION_MAP[next.action], target: trigger ? unitSelector(trigger) : `[data-ade-unit="${next.unit}"]`, label: next.label }
    const t0 = now()
    const res = await deps.act(next)
    const ms = now() - t0
    if (ms > SLOW_STEP_MS) slow.push({ label: next.label, ms })
    if (!res.ok || !res.view || !res.view.ok) {
      failed.push(next.label)
      continue
    }
    view = res.view
    const path = [...(pathOf.get(stepKey(next)) ?? []), reveal]
    snapshots.push({ path, units: view.units })
    note(view.units, path)
  }
  const ids = new Set(flattenUnits(view.units).map((u) => u.id))
  const truncated = (steps >= max || outOfTime) && deps.plan(view.units).some((s) => !done.has(stepKey(s)) && ids.has(s.unit))
  return { route: view.route, snapshots, steps, truncated, failed, ...(slow.length ? { slow } : {}), ...(outOfTime ? { outOfTime } : {}) }
}

// ---------------------------------------------------------------------------
// Snapshots → the coverage core's units.
// ---------------------------------------------------------------------------

/** Roles that are containers or structure — not something a person does. */
const STRUCTURE = new Set(['section', 'card', 'form', 'dialog', 'table', 'row', 'tabs', 'menu', 'block', 'frame'])

/** Buttons that only close what's open — not a function of the screen. */
const DISMISS = /^(close|cancel|dismiss|done)$/i

export function unitKind(u: Pick<ViewUnitLike, 'role' | 'state' | 'action'> & { label?: string }): CoverageUnit['kind'] {
  // Reveal triggers (expand a section, open a menu) are navigation, not a function of the screen.
  if (u.action && u.role !== 'tab') return 'other'
  if (u.role === 'button' && DISMISS.test((u.label ?? '').trim())) return 'other'
  if (u.role === 'button' || u.role === 'option') return 'action'
  if (u.role === 'tab') return 'tab'
  if (u.role === 'link') return 'link'
  if (u.role === 'field') return /(^|,)\s*(on|off)\s*(,|$)/.test(u.state ?? '') ? 'toggle' : 'field'
  return 'other'
}

/**
 * Every control seen on the walk, once (by role + label), with the reveal
 * path of the FIRST view it appeared in. (Later views keep earlier reveals
 * open — a tab stays open while a menu is opened — so a later, shorter path
 * would be wrong.) A unit off-screen below the fold gets a scroll step too.
 */
export function collectUnits(snapshots: ReadonlyArray<WalkSnapshot>): Array<CoverageUnit & { stable: boolean }> {
  const best = new Map<string, CoverageUnit & { stable: boolean }>()
  const members = new Map<string, Map<string, NonNullable<CoverageUnit['members']>[number]>>()
  for (const snap of snapshots) {
    for (const { unit: u, parentRole, group, container } of flattenWithParent(snap.units)) {
      if (STRUCTURE.has(u.role) || !u.label.trim()) continue
      // A choice is a control only in a UI menu; elsewhere (select / listbox options) it's data.
      if (u.role === 'option' && parentRole !== 'menu') continue
      const ownKey = `${u.role}:${u.label.trim().toLowerCase()}`
      const kind = unitKind(u)
      // The container is the unit; its chips, fields, tab labels and buttons are its members.
      const host = container?.unit ?? u
      const key = container?.key ?? ownKey
      if (container) {
        const m = members.get(key) ?? new Map()
        if (!m.has(ownKey)) m.set(ownKey, { id: u.stable || ownKey, label: safeLabel(u.label), kind })
        members.set(key, m)
      }
      if (best.has(key)) continue
      const reveal = host.hidden === 'below-fold' || u.hidden === 'below-fold' ? [...snap.path, { action: 'scroll' as const, target: unitSelector(host), label: host.label }] : snap.path
      best.set(key, {
        id: host.stable || key,
        label: safeLabel(host.label),
        kind: container ? 'other' : kind,
        target: unitSelector(host),
        reveal: reveal.map((r) => ({ ...r, label: safeLabel(r.label) })),
        ...(group && !container ? { group } : container && group && !GROUP_ROLES.has(container.role) ? { group } : {}),
        stable: !!host.stable,
      })
    }
  }
  // A unit is an action if it holds one, a field if it only holds fields (saved by its scope's Save), else navigation.
  for (const [key, m] of members) {
    const u = best.get(key)
    if (!u) continue
    const list = [...m.values()]
    const kind: CoverageUnit['kind'] = list.some((x) => x.kind === 'action') ? 'action' : list.some((x) => x.kind === 'field' || x.kind === 'toggle') ? 'field' : 'other'
    best.set(key, { ...u, kind, members: list })
  }
  return [...best.values()]
}
