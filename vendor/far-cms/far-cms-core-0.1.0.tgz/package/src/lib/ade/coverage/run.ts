/**
 * Coverage check — one screen, end to end (app-agnostic; asserted by
 * run.assert.ts). Walk the screen (read-only), collect its controls, map
 * them to the platform's actions (the host's matcher first), classify the
 * three lists, and build a replayable walk-through of one hidden control.
 * The caller posts the result (it stores coverage data only — nothing on
 * the site is ever saved by the check).
 */

import { classifyCoverage, coverageRow, tourStepsFor, type CoverageResult, type CoverageRow, type PlatformAction, type TourStep, type UnitMatcher } from './logic'
import { collectUnits, walkScreen, type WalkDeps } from './walk'

export interface RunDeps extends WalkDeps {
  /** The platform actions for this route (the screen's platform-map entry). */
  actionsFor: (route: string) => PlatformAction[]
  /** The host's label → action matcher for this route (e.g. platform-map findAction). */
  matcherFor?: (route: string, actions: PlatformAction[]) => UnitMatcher | undefined
  /** Agent tool names (TOOL_REGISTRY keys). */
  toolNames: ReadonlySet<string>
  now?: () => string
}

export interface ScreenCoverage {
  result: CoverageResult
  row: CoverageRow
  /** Per-unit detail for the report. */
  units: Array<{ id: string; label: string; kind: string; action: string | null; tools: string[]; reveal: string[] }>
  /** Walk-through of the first hidden control (with a stable target when there is one). */
  tour: { title: string; steps: TourStep[] } | null
  /** Hidden controls whose target only works in this session — they need a data-ui to be toured. */
  needsStableTarget: string[]
  walk: { steps: number; truncated: boolean; failed: string[]; slow?: Array<{ label: string; ms: number }>; outOfTime?: boolean }
}

export async function runScreenCoverage(deps: RunDeps): Promise<ScreenCoverage> {
  const walked = await walkScreen(deps)
  const units = collectUnits(walked.snapshots)
  const route = walked.route.split('?')[0]
  const actions = deps.actionsFor(route)
  const result = classifyCoverage({ route, units, actions, toolNames: deps.toolNames, matcher: deps.matcherFor?.(route, actions) })
  const row = coverageRow(result, deps.now?.() ?? new Date().toISOString())
  const stable = new Map(units.map((u) => [u.id, u.stable]))
  const hidden = result.hiddenOnly.map((m) => m.unit)
  // Tour the first hidden control that can be pointed at again later; else the first one.
  const pick = hidden.find((u) => stable.get(u.id)) ?? hidden[0]
  return {
    result,
    row,
    units: result.mapped.map((m) => ({
      id: m.unit.id,
      label: m.unit.label,
      kind: m.unit.kind,
      action: m.action ? `${m.action.entity}.${m.action.action}` : null,
      tools: m.tools,
      reveal: m.unit.reveal.map((r) => r.label),
    })),
    tour: pick ? { title: `Where to find “${pick.label}”`, steps: tourStepsFor(pick) } : null,
    needsStableTarget: hidden.filter((u) => !stable.get(u.id)).map((u) => u.label),
    walk: { steps: walked.steps, truncated: walked.truncated, failed: walked.failed, ...(walked.slow ? { slow: walked.slow } : {}), ...(walked.outOfTime ? { outOfTime: true } : {}) },
  }
}
