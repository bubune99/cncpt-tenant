/**
 * The block library (design rules R22/R23, playbook 19/19a): the tray's three
 * shelves, and the vocabulary the assistant builds pages from.
 *   saved     the site owner's reusable blocks (stored as Partials), linked or copy
 *   sections  generic starting layouts in the site's style
 *   ideas     layouts for a goal with placeholder words — never saved until added
 * Preference: saved → sections → ideas → new markup, with a one-line note. Two
 * saved blocks that fit equally → ask the person. An added block's copy and
 * images are changed on the INSTANCE only (overrides); the saved definition is
 * never touched here.
 *
 * Pure and app-agnostic: the app injects its catalog and its styles. Asserted by
 * library.assert.ts.
 */

import type { Block } from '../../block-editor/types'

export type Shelf = 'saved' | 'sections' | 'ideas'
export type BlockMode = 'linked' | 'copy'

export const SHELF_ORDER: readonly Shelf[] = ['saved', 'sections', 'ideas']

export const LIBRARY_LIMITS = { findMax: 6, ideasMax: 6, ideasDefault: 4, noteChars: 160, nameChars: 80 } as const

export const LIBRARY_COPY = {
  savedTitle: 'Your saved blocks',
  savedNote: 'Designs you saved to reuse. Linked blocks update everywhere they’re used; copies are yours to change.',
  sectionsNote: 'Starting layouts in your site’s style. They are not saved designs: add one, then change it.',
  ideasTitle: (goal: string) => `Ideas for ${goal}`,
  ideasNote: 'Starting layouts to get ahead faster. Not saved designs: they use placeholder words and your site’s colors.',
  saveSelection: 'Save selection as a block',
  saveSelectionHint: 'Pick a section on the page, then save it here',
  usage: (mode: BlockMode, n: number, savedOn?: string) => (mode === 'linked' ? `Linked · used on ${n} ${n === 1 ? 'page' : 'pages'}` : `Copy${savedOn ? ` · saved ${savedOn}` : ''}`),
  /** The one line naming what was used and the SHELF it came from (staging: replies said "a copy of the starting layout"). */
  usedNote: (name: string, shelf: Shelf, mode?: BlockMode) =>
    shelf === 'saved'
      ? `I used your saved block “${name}” (${mode === 'copy' ? 'a copy' : 'linked'}).`
      : shelf === 'sections'
        ? `No saved block fits, so I used “${name}” from Sections (a starting layout, added as a copy).`
        : `No saved block or layout fits, so I used “${name}” from Ideas (a copy with placeholder words).`,
  /** The draft's summary (also the add_block result the model reads), with the shelf. */
  addSummary: (name: string, shelf: Shelf, mode: BlockMode, page: string) =>
    shelf === 'saved' ? `Add your saved block “${name}” (${mode === 'copy' ? 'a copy' : 'linked'}) to “${page}”` : `Add “${name}” from ${shelf === 'sections' ? 'Sections' : 'Ideas'} (a copy) to “${page}”`,
} as const

/** One block on a shelf. `tree` is the real block tree the tray renders mini and the page receives. */
export interface LibraryBlock {
  id: string
  shelf: Shelf
  name: string
  category: string
  summary: string
  tree: Block
  /** Saved: how it is added by default, and how many pages use it linked. */
  mode?: BlockMode
  usage?: number
  savedOn?: string
  keywords?: string
}

export interface FoundBlock {
  id: string
  name: string
  shelf: Shelf
  category: string
  summary: string
  usage?: number
  mode?: BlockMode
}

const words = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter((w) => w.length > 1)
const STOP = new Set(['a', 'an', 'the', 'to', 'for', 'of', 'and', 'with', 'on', 'my', 'our', 'block', 'section', 'add', 'me', 'some', 'page'])

/** How well a block matches the words (0 = not at all). Name counts most, then category, then the rest. */
export function matchScore(b: LibraryBlock, query: string): number {
  const q = words(query).filter((w) => !STOP.has(w))
  if (!q.length) return 1
  const name = words(b.name)
  const cat = words(b.category)
  const rest = words(`${b.summary} ${b.keywords ?? ''}`)
  const hit = (list: string[], w: string) => list.some((x) => x === w || x.startsWith(w) || w.startsWith(x))
  return q.reduce((s, w) => s + (hit(name, w) ? 3 : 0) + (hit(cat, w) ? 2 : 0) + (hit(rest, w) ? 1 : 0), 0)
}

/** find_blocks: matches across the shelves, best first, saved before sections before ideas at equal score. */
export function findBlocks(catalog: readonly LibraryBlock[], opts: { query?: string; shelf?: Shelf; category?: string; limit?: number } = {}): FoundBlock[] {
  const limit = Math.max(1, Math.min(opts.limit ?? LIBRARY_LIMITS.findMax, LIBRARY_LIMITS.findMax))
  return catalog
    .filter((b) => (!opts.shelf || b.shelf === opts.shelf) && (!opts.category || b.category.toLowerCase() === opts.category.toLowerCase()))
    .map((b) => ({ b, s: matchScore(b, opts.query ?? '') }))
    .filter((x) => x.s > 0)
    .sort((x, y) => y.s - x.s || SHELF_ORDER.indexOf(x.b.shelf) - SHELF_ORDER.indexOf(y.b.shelf))
    .slice(0, limit)
    .map(({ b }) => ({ id: b.id, name: b.name, shelf: b.shelf, category: b.category, summary: b.summary, ...(b.usage !== undefined ? { usage: b.usage } : {}), ...(b.mode ? { mode: b.mode } : {}) }))
}

export type Pick =
  | { kind: 'use'; block: LibraryBlock; note: string }
  | { kind: 'ask'; options: LibraryBlock[]; question: string }
  | { kind: 'none'; note: string }

/**
 * What to use for a request, in preference order: the best saved block; two
 * saved blocks that fit equally → ask; else the best starting layout; else the
 * best idea; else nothing (new markup is the last resort).
 */
export function pickBlock(catalog: readonly LibraryBlock[], query: string): Pick {
  for (const shelf of SHELF_ORDER) {
    const scored = catalog.filter((b) => b.shelf === shelf).map((b) => ({ b, s: matchScore(b, query) })).filter((x) => x.s > 0).sort((x, y) => y.s - x.s)
    if (!scored.length || words(query).filter((w) => !STOP.has(w)).length === 0) continue
    const top = scored.filter((x) => x.s === scored[0].s)
    if (shelf === 'saved' && top.length > 1) {
      return { kind: 'ask', options: top.slice(0, 4).map((x) => x.b), question: 'Two of your saved blocks fit. Which one?' }
    }
    const block = scored[0].b
    return { kind: 'use', block, note: LIBRARY_COPY.usedNote(block.name, shelf, block.mode) }
  }
  return { kind: 'none', note: 'Nothing in your blocks fits, so I’ll build it from scratch.' }
}

// ── Placing a block: linked (a reference) or a copy; overrides on the instance only ──

export interface Overrides {
  /** New words for the block's headline (first heading), then its first paragraph. */
  text?: string
  body?: string
  /** A new picture (the first image, or the section background). */
  image?: string
  /** Where its button or link goes, and its words. */
  link?: string
  linkText?: string
}

const cut = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : undefined)
const safeUrl = (v: unknown) => {
  const s = cut(v, 2000)
  return s && (/^https:\/\/\S+$/i.test(s) || /^\/[^\s/]/.test(s) || s === '/' || s.startsWith('#')) ? s : undefined
}

/** The model's overrides, checked: plain words (capped), and only https or same-site links and pictures. */
export function cleanOverrides(raw: unknown): Overrides {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const text = cut(o.text, 200)
  const body = cut(o.body, 600)
  const image = safeUrl(o.image)
  const link = safeUrl(o.link)
  const linkText = cut(o.linkText, 60)
  return { ...(text ? { text } : {}), ...(body ? { body } : {}), ...(image ? { image } : {}), ...(link ? { link } : {}), ...(linkText ? { linkText } : {}) }
}

type Override = { textContent?: string; attrs?: Record<string, string> }

function walk(b: Block, f: (x: Block) => void) {
  f(b)
  for (const c of b.children ?? []) walk(c, f)
}

/** Which blocks of a tree the overrides land on: first heading, first paragraph, first image, first link. */
export function overrideTargets(tree: Block): { heading?: Block; para?: Block; image?: Block; link?: Block } {
  const out: { heading?: Block; para?: Block; image?: Block; link?: Block } = {}
  walk(tree, (x) => {
    if (!out.heading && /^h[1-6]$/.test(x.tag)) out.heading = x
    else if (!out.para && x.tag === 'p' && x.textContent) out.para = x
    if (!out.image && x.tag === 'img') out.image = x
    if (!out.link && (x.tag === 'a' || x.tag === 'button')) out.link = x
  })
  return out
}

/** Overrides as per-block changes, keyed by the TREE's own block ids (a linked block's partialOverrides). */
export function overrideMap(tree: Block, o: Overrides): Record<string, Override> {
  const t = overrideTargets(tree)
  const map: Record<string, Override> = {}
  const put = (b: Block | undefined, v: Override) => {
    if (!b) return
    map[b.id] = { ...map[b.id], ...v, ...(v.attrs || map[b.id]?.attrs ? { attrs: { ...map[b.id]?.attrs, ...v.attrs } } : {}) }
  }
  if (o.text) put(t.heading, { textContent: o.text })
  if (o.body) put(t.para, { textContent: o.body })
  if (o.image && t.image) put(t.image, { attrs: { src: o.image } })
  if (o.link) put(t.link, { attrs: { href: o.link } })
  if (o.linkText) put(t.link, { textContent: o.linkText })
  return map
}

/** A fresh copy of a tree with new ids (and its id map), so a copy never shares ids with its source. */
export function cloneTree(tree: Block, newId: () => string): { tree: Block; ids: Record<string, string> } {
  const ids: Record<string, string> = {}
  const copy = (b: Block): Block => {
    const id = newId()
    ids[b.id] = id
    return { ...b, id, ...(b.attrs ? { attrs: { ...b.attrs } } : {}), ...(b.children ? { children: b.children.map(copy) } : {}) }
  }
  return { tree: copy(tree), ids }
}

/**
 * The block to insert for a library item. Saved + linked → a reference to the
 * saved block (its overrides ride on the reference); anything else → a copy
 * with the overrides applied to the copy. Never changes `item`.
 */
export function instanceOf(item: LibraryBlock, mode: BlockMode, o: Overrides, newId: () => string): Block {
  if (item.shelf === 'saved' && mode === 'linked') {
    const overrides = overrideMap(item.tree, o)
    return {
      id: newId(),
      tag: 'div',
      className: '',
      componentName: 'PartialReference',
      partialId: item.id,
      label: item.name,
      ...(Object.keys(overrides).length ? { partialOverrides: overrides } : {}),
    } as Block
  }
  const { tree, ids } = cloneTree(item.tree, newId)
  const changes = overrideMap(item.tree, o)
  const apply = (b: Block): Block => {
    const src = Object.keys(ids).find((k) => ids[k] === b.id)
    const c = src ? changes[src] : undefined
    const next = c ? { ...b, ...(c.textContent !== undefined ? { textContent: c.textContent } : {}), ...(c.attrs ? { attrs: { ...b.attrs, ...c.attrs } } : {}) } : b
    return next.children ? { ...next, children: next.children.map(apply) } : next
  }
  const placed = apply(tree)
  // A background picture (the hero) takes the image when there is no <img>.
  if (o.image && !overrideTargets(item.tree).image && placed.background) return { ...placed, background: { ...placed.background, url: o.image } } as Block
  return { ...placed, label: placed.label || item.name }
}

/** Where a block goes: after a section on the page (its top-level section), or at an index; default the end. */
export interface Position {
  after?: string
  at?: number
}

/** The page content with `tree` inserted at the top level. Never mutates `content`. */
export function insertTreeAt(content: unknown, tree: Block, pos: Position = {}): { content: { blocks: Block[] } & Record<string, unknown>; at: number } | { error: string } {
  const doc = (content && typeof content === 'object' ? content : {}) as { blocks?: Block[] } & Record<string, unknown>
  const blocks = Array.isArray(doc.blocks) ? doc.blocks : []
  let at = blocks.length
  if (pos.after) {
    const top = blocks.findIndex((b) => {
      let found = false
      walk(b, (x) => {
        if (x.id === pos.after) found = true
      })
      return found
    })
    if (top < 0) return { error: `No block ${pos.after} on this page` }
    at = top + 1
  } else if (typeof pos.at === 'number' && Number.isInteger(pos.at)) at = Math.max(0, Math.min(pos.at, blocks.length))
  return { content: { ...doc, version: (doc.version as string) ?? '2.0', blocks: [...blocks.slice(0, at), tree, ...blocks.slice(at)] }, at }
}

/** How many pages use a saved block linked (a PartialReference anywhere in their tree). */
export function usageOf(pages: ReadonlyArray<{ content: unknown }>, partialId: string): number {
  let n = 0
  for (const p of pages) {
    const blocks = ((p.content ?? {}) as { blocks?: Block[] }).blocks ?? []
    let used = false
    for (const b of blocks) walk(b, (x) => {
      if (x.partialId === partialId) used = true
    })
    if (used) n++
  }
  return n
}

// ── Saved blocks stored as Partials ───────────────────────────────────────

/** What a saved block keeps beside its blocks in Partial.content (no new table: content is JSON). */
export interface SavedMeta {
  kind: 'saved-block'
  mode: BlockMode
  category: string
}

export function savedMetaOf(content: unknown): SavedMeta | null {
  const m = ((content ?? {}) as { meta?: Record<string, unknown> }).meta
  if (!m || m.kind !== 'saved-block') return null
  return { kind: 'saved-block', mode: m.mode === 'copy' ? 'copy' : 'linked', category: typeof m.category === 'string' && m.category ? m.category.slice(0, 40) : 'other' }
}

/** A saved block's Partial.content, from the block the person (or the assistant) chose to save. */
export function savedContent(tree: Block, meta: { mode: BlockMode; category: string }): { version: string; blocks: Block[]; meta: SavedMeta } {
  return { version: '2.0', blocks: [tree], meta: { kind: 'saved-block', mode: meta.mode, category: meta.category.slice(0, 40) || 'other' } }
}

// ── Ideas: layouts for a goal, from the site's own styles, placeholder words ──

/** The site's styles the ideas are drawn with (the app passes its own). */
export interface IdeaTheme {
  heading: string
  body: string
  button: string
  buttonAlt: string
  dark: string
  light: string
  wrap: string
}

const IDEA_LAYOUTS = ['centered', 'split', 'numbers', 'banner', 'choices', 'quote'] as const
export type IdeaLayout = (typeof IDEA_LAYOUTS)[number]
const IDEA_NAMES: Record<IdeaLayout, string> = {
  centered: 'Centered statement',
  split: 'Split with photo',
  numbers: 'Numbers, then the ask',
  banner: 'Banner strip',
  choices: 'Two choices',
  quote: 'A voice, then the ask',
}

/** "idea:<layout>:<goal>" — ideas are not stored; the id rebuilds the same layout. */
export const ideaId = (layout: IdeaLayout, goal: string) => `idea:${layout}:${goal.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'cta'}`
export function parseIdeaId(id: string): { layout: IdeaLayout; goal: string } | null {
  const m = /^idea:([a-z]+):([a-z0-9-]{1,40})$/.exec(id)
  return m && (IDEA_LAYOUTS as readonly string[]).includes(m[1]) ? { layout: m[1] as IdeaLayout, goal: m[2].replace(/-/g, ' ') } : null
}

/** Placeholder words for a goal — clearly placeholders, for the person (or the fill) to replace. */
function placeholderWords(goal: string) {
  const g = goal.toLowerCase()
  if (/donat|give|support|appeal|fund/.test(g)) return { h: 'Your headline about the gift', p: 'One sentence on what a gift makes possible.', btn: 'Give now', alt: 'Learn more' }
  if (/volunteer|join|sign ?up|newsletter|subscribe/.test(g)) return { h: 'Your invitation headline', p: 'One sentence on why people join.', btn: 'Sign up', alt: 'Find out more' }
  return { h: 'Your headline', p: 'One sentence that leads to the button.', btn: 'Your button', alt: 'Second choice' }
}

/** suggest_layouts: `count` idea layouts for a goal (4–6), each a real block tree for the mini render. */
export function ideasFor(goal: string, count: number, theme: IdeaTheme, newId: () => string, offset = 0): LibraryBlock[] {
  const n = Math.max(1, Math.min(count || LIBRARY_LIMITS.ideasDefault, LIBRARY_LIMITS.ideasMax))
  const w = placeholderWords(goal)
  const B = (tag: string, className: string, text?: string, children?: Block[], attrs?: Record<string, string>): Block =>
    ({ id: newId(), tag, className, ...(text ? { textContent: text } : {}), ...(children?.length ? { children } : {}), ...(attrs ? { attrs } : {}) }) as Block
  const sec = (label: string, cls: string, kids: Block[]): Block => ({ ...B('section', cls, undefined, kids), label })
  const btn = (text: string, alt = false) => B('a', alt ? theme.buttonAlt : theme.button, text, undefined, { href: '#' })
  const build: Record<IdeaLayout, () => Block> = {
    centered: () => sec('Centered statement', `${theme.light} py-16 text-center`, [B('div', theme.wrap, undefined, [B('h2', theme.heading, w.h), B('p', `${theme.body} mt-3 mb-6`, w.p), btn(w.btn)])]),
    split: () => sec('Split with photo', `${theme.light} py-16`, [B('div', `${theme.wrap} grid md:grid-cols-2 gap-8 items-center`, undefined, [B('img', 'w-full rounded-lg', undefined, undefined, { src: '', alt: 'Your photo' }), B('div', '', undefined, [B('h2', theme.heading, w.h), B('p', `${theme.body} mt-3 mb-6`, w.p), btn(w.btn)])])]),
    numbers: () => sec('Numbers, then the ask', `${theme.light} py-16 text-center`, [B('div', theme.wrap, undefined, [B('div', 'grid grid-cols-3 gap-6 mb-8', undefined, ['100+', '12', '3'].map((v) => B('div', '', undefined, [B('p', theme.heading, v), B('p', theme.body, 'What it counts')]))), B('h2', theme.heading, w.h), btn(w.btn)])]),
    banner: () => sec('Banner strip', `${theme.dark} py-10`, [B('div', `${theme.wrap} flex flex-wrap items-center justify-between gap-4`, undefined, [B('h2', `${theme.heading} text-white`, w.h), btn(w.btn)])]),
    choices: () => sec('Two choices', `${theme.light} py-16 text-center`, [B('div', theme.wrap, undefined, [B('h2', theme.heading, w.h), B('p', `${theme.body} mt-3 mb-6`, w.p), B('div', 'flex flex-wrap justify-center gap-3', undefined, [btn(w.btn), btn(w.alt, true)])])]),
    quote: () => sec('A voice, then the ask', `${theme.light} py-16 text-center`, [B('div', theme.wrap, undefined, [B('p', `${theme.body} italic mb-2`, '“A short quote from someone it helped.”'), B('p', `${theme.body} mb-6`, '— Their name'), B('h2', theme.heading, w.h), btn(w.btn)])]),
  }
  return Array.from({ length: n }, (_, i) => IDEA_LAYOUTS[(i + offset) % IDEA_LAYOUTS.length]).map((layout) => ({
    id: ideaId(layout, goal),
    shelf: 'ideas' as const,
    name: IDEA_NAMES[layout],
    category: 'idea',
    summary: `An idea for ${goal}, with placeholder words`,
    tree: build[layout](),
  }))
}

/** The idea an id names, rebuilt (ideas are never stored). */
export function ideaById(id: string, theme: IdeaTheme, newId: () => string): LibraryBlock | null {
  const p = parseIdeaId(id)
  if (!p) return null
  const all = ideasFor(p.goal, LIBRARY_LIMITS.ideasMax, theme, newId)
  return all.find((x) => x.id === id) ?? null
}

/** The per-turn line when code starts a plan on the page builder: build from the library. */
export const BUILD_PLAN_HINT = `[Page builder] Build from the block library: find_blocks first and use Saved blocks, then Sections, then Ideas — new markup only when nothing fits. Make each plan step one block you place ("Add the hero", "Add the call to action"…), then fill their words, ending with "Propose it for review". Then say find_blocks' \`note\` line word for word (it names the block, its shelf — Saved, Sections or Ideas — and linked or copy). Two saved blocks fit equally → ask_user. Change the added block's words and pictures only (overrides), never the saved block itself.`
