/**
 * Where a drop or an insert lands in the block tree (shared by the canvas,
 * Layers and the Library). A DropTarget names a block and a place; targetId
 * null means the end of the page. Pure; asserted by design-fields.assert.ts.
 */

export interface TreeNodeLike {
  id: string
  children?: ReadonlyArray<TreeNodeLike>
}

export interface DropTarget {
  targetId: string | null
  place: 'before' | 'after' | 'inside'
}

/** The parent id (null = page root) and index a DropTarget means; null when the target isn't in the tree. */
export function resolveDrop(tree: ReadonlyArray<TreeNodeLike>, at: DropTarget): { parentId: string | null; index: number } | null {
  if (at.targetId === null) return { parentId: null, index: tree.length }
  const walk = (list: ReadonlyArray<TreeNodeLike>, parentId: string | null): { parentId: string | null; index: number } | null => {
    for (let i = 0; i < list.length; i++) {
      const n = list[i]
      if (n.id === at.targetId) {
        if (at.place === 'inside') return { parentId: n.id, index: n.children?.length ?? 0 }
        return { parentId, index: at.place === 'before' ? i : i + 1 }
      }
      const hit = n.children ? walk(n.children, n.id) : null
      if (hit) return hit
    }
    return null
  }
  return walk(tree, null)
}
