/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/blocks/library.assert.ts
 */
import assert from 'node:assert/strict'
import type { Block } from '../../block-editor/types'
import {
  BUILD_PLAN_HINT, LIBRARY_COPY, cleanOverrides, cloneTree, insertTreeAt, findBlocks, ideaById, ideaId, ideasFor, instanceOf, overrideMap, parseIdeaId, pickBlock,
  savedContent, savedMetaOf, usageOf, type IdeaTheme, type LibraryBlock,
} from './library'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
let seq = 0
const id = () => `n${++seq}`

const cta = (label: string): Block => ({ id: `${label}-s`, tag: 'section', className: 'py-16', label, children: [
  { id: `${label}-h`, tag: 'h2', className: 'x', textContent: 'Your gift delivers care' },
  { id: `${label}-p`, tag: 'p', className: 'x', textContent: 'Every donation sends a nurse.' },
  { id: `${label}-a`, tag: 'a', className: 'btn', textContent: 'Donate', attrs: { href: '/donate' } },
] } as Block)
const CATALOG: LibraryBlock[] = [
  { id: 'p-winter', shelf: 'saved', name: 'Winter appeal CTA', category: 'call to action', summary: 'Donate band', tree: cta('winter'), mode: 'linked', usage: 4 },
  { id: 'p-news', shelf: 'saved', name: 'Newsletter signup', category: 'signup', summary: 'Stay in the loop', tree: cta('news'), mode: 'linked', usage: 2 },
  { id: 'donate', shelf: 'sections', name: 'Donate band', category: 'call to action', summary: 'A bold strip asking visitors to give', tree: cta('donate') },
  { id: 'gallery', shelf: 'sections', name: 'Gallery', category: 'photos', summary: 'A grid of photos', tree: cta('gallery') },
]
const THEME: IdeaTheme = { heading: 'text-4xl font-heading', body: 'text-lg', button: 'btn', buttonAlt: 'btn-alt', dark: 'bg-dark', light: 'bg-white', wrap: 'max-w-5xl mx-auto px-4' }

check('find_blocks: best match first, Saved before Sections at equal fit, capped at 6', () => {
  const r = findBlocks(CATALOG, { query: 'call to action' })
  assert.deepEqual(r.map((b) => [b.id, b.shelf]), [['p-winter', 'saved'], ['donate', 'sections']])
  assert.equal(findBlocks(CATALOG, { shelf: 'sections' }).length, 2)
  assert.equal(findBlocks(CATALOG, { category: 'photos' })[0].id, 'gallery')
  assert.ok(findBlocks(CATALOG, { limit: 99 }).length <= 6)
  assert.equal(r[0].usage, 4)
})

check('preference: a Saved block wins and says so (linked); otherwise a Section; otherwise nothing', () => {
  const p = pickBlock(CATALOG, 'add a call to action after the story')
  assert.equal(p.kind, 'use')
  assert.equal(p.kind === 'use' && p.block.id, 'p-winter')
  assert.equal(p.kind === 'use' && p.note, 'I used your saved block “Winter appeal CTA” (linked).')
  const g = pickBlock(CATALOG, 'a photo gallery')
  assert.equal(g.kind === 'use' && g.block.shelf, 'sections')
  assert.match(g.kind === 'use' ? g.note : '', /“Gallery” from Sections \(a starting layout, added as a copy\)/)
  assert.equal(pickBlock(CATALOG, 'pricing table').kind, 'none')
})

check('two saved blocks that fit equally → ask the person', () => {
  const two = [...CATALOG, { ...CATALOG[0], id: 'p-spring', name: 'Spring appeal CTA' }]
  const p = pickBlock(two, 'appeal CTA')
  assert.equal(p.kind, 'ask')
  assert.deepEqual(p.kind === 'ask' && p.options.map((o) => o.id).sort(), ['p-spring', 'p-winter'])
})

check('linked: a reference to the saved block; overrides ride on the reference; the saved tree is untouched', () => {
  const before = JSON.stringify(CATALOG[0].tree)
  const ref = instanceOf(CATALOG[0], 'linked', { text: 'Warm a family this winter', link: '/give' }, id)
  assert.equal(ref.componentName, 'PartialReference')
  assert.equal(ref.partialId, 'p-winter')
  assert.deepEqual(ref.partialOverrides, { 'winter-h': { textContent: 'Warm a family this winter' }, 'winter-a': { attrs: { href: '/give' } } })
  assert.equal(JSON.stringify(CATALOG[0].tree), before, 'never edits the saved definition')
})

check('copy: fresh ids, the overrides applied to the copy only', () => {
  const copy = instanceOf(CATALOG[0], 'copy', { text: 'New headline', body: 'New line.', linkText: 'Give' }, id)
  const ids: string[] = []
  const all = (b: Block) => { ids.push(b.id); (b.children ?? []).forEach(all) }
  all(copy)
  assert.ok(!ids.some((x) => x.startsWith('winter-')), 'no shared ids with the source')
  assert.deepEqual(copy.children!.map((c) => c.textContent), ['New headline', 'New line.', 'Give'])
  assert.equal(CATALOG[0].tree.children![0].textContent, 'Your gift delivers care')
  // A section (never linked) is always a copy, even if "linked" is asked.
  assert.notEqual(instanceOf(CATALOG[2], 'linked', {}, id).componentName, 'PartialReference')
})

check('override targets: first heading, first paragraph, first image / link', () => {
  const tree: Block = { id: 's', tag: 'section', className: '', children: [{ id: 'i', tag: 'img', className: '', attrs: { src: 'a.jpg' } }, cta('x')] } as Block
  assert.deepEqual(overrideMap(tree, { image: 'b.jpg', text: 'T' }), { i: { attrs: { src: 'b.jpg' } }, 'x-h': { textContent: 'T' } })
})

check('cloneTree never shares ids', () => {
  const { tree, ids } = cloneTree(CATALOG[0].tree, id)
  assert.equal(Object.keys(ids).length, 4)
  assert.notEqual(tree.id, CATALOG[0].tree.id)
})

check('"used on N pages": pages with a reference anywhere in their tree', () => {
  const page = (partialId?: string) => ({ content: { blocks: [{ id: 'r', tag: 'div', className: '', children: partialId ? [{ id: 'q', tag: 'div', className: '', partialId }] : [] }] } })
  assert.equal(usageOf([page('p-winter'), page('p-winter'), page('p-news'), page()], 'p-winter'), 2)
  assert.equal(LIBRARY_COPY.usage('linked', 4), 'Linked · used on 4 pages')
  assert.equal(LIBRARY_COPY.usage('copy', 0, 'Oct 9'), 'Copy · saved Oct 9')
})

check('saved blocks live in Partial.content: blocks + a meta (no new table)', () => {
  const c = savedContent(CATALOG[0].tree, { mode: 'copy', category: 'call to action' })
  assert.equal(c.version, '2.0')
  assert.deepEqual(savedMetaOf(c), { kind: 'saved-block', mode: 'copy', category: 'call to action' })
  assert.equal(savedMetaOf({ version: '2.0', blocks: [] }), null, 'an ordinary partial is not a saved block meta')
})

check('ideas: 4–6 real trees with placeholder words and the site styles; the id rebuilds the same idea', () => {
  const ideas = ideasFor('a call to action for the winter appeal', 4, THEME, id)
  assert.equal(ideas.length, 4)
  assert.ok(ideas.every((i) => i.shelf === 'ideas' && i.tree.children?.length))
  assert.ok(JSON.stringify(ideas[0].tree).includes('Your headline about the gift'), 'placeholder words for a donation goal')
  assert.ok(JSON.stringify(ideas[0].tree).includes(THEME.button), 'the site’s own button style')
  assert.equal(ideasFor('x', 99, THEME, id).length, 6)
  const rebuilt = ideaById(ideas[1].id, THEME, id)!
  assert.equal(rebuilt.name, ideas[1].name)
  assert.deepEqual(parseIdeaId(ideaId('split', 'Donate Now!')), { layout: 'split', goal: 'donate now' })
  assert.equal(parseIdeaId('idea:bogus:x'), null)
  // More ideas = the next layouts.
  assert.notEqual(ideasFor('x', 2, THEME, id, 2)[0].name, ideasFor('x', 2, THEME, id)[0].name)
})

check('the build-a-page hint: library first, steps = blocks, overrides only', () => {
  assert.match(BUILD_PLAN_HINT, /Saved blocks, then Sections, then Ideas/)
  assert.match(BUILD_PLAN_HINT, /never the saved block itself/)
})

check('insertTreeAt: after a section (found anywhere inside it), at an index, or at the end; never mutates', () => {
  const content = { version: '2.0', blocks: [cta('a'), cta('b')] }
  const snap = JSON.stringify(content)
  const tree = { id: 'new', tag: 'section', className: '' } as Block
  const r = insertTreeAt(content, tree, { after: 'a-p' })
  assert.ok(!('error' in r))
  assert.deepEqual('content' in r && r.content.blocks.map((b) => b.id), ['a-s', 'new', 'b-s'])
  assert.equal((insertTreeAt(content, tree, { at: 0 }) as { at: number }).at, 0)
  assert.equal((insertTreeAt(content, tree) as { at: number }).at, 2)
  assert.ok('error' in insertTreeAt(content, tree, { after: 'nope' }))
  assert.equal(JSON.stringify(content), snap)
})

check('overrides are checked: plain words capped; only https or same-site links and pictures', () => {
  assert.deepEqual(cleanOverrides({ text: '  Warm a family  ', image: 'javascript:alert(1)', link: '/donate', linkText: 'x'.repeat(99) }), { text: 'Warm a family', link: '/donate', linkText: 'x'.repeat(60) })
  assert.deepEqual(cleanOverrides({ image: 'https://cdn.example.com/a.jpg', link: '//evil.com' }), { image: 'https://cdn.example.com/a.jpg' })
  assert.deepEqual(cleanOverrides(null), {})
})

check('c6c4 P5: every block note and draft summary names the shelf (Saved / Sections / Ideas) and linked or copy — from code', () => {
  assert.match(LIBRARY_COPY.usedNote('Winter appeal CTA', 'saved', 'linked'), /your saved block “Winter appeal CTA” \(linked\)/)
  assert.match(LIBRARY_COPY.usedNote('Winter appeal CTA', 'saved', 'copy'), /your saved block .*\(a copy\)/)
  assert.match(LIBRARY_COPY.usedNote('Donate band', 'sections'), /from Sections/)
  assert.match(LIBRARY_COPY.usedNote('Banner strip', 'ideas'), /from Ideas/)
  assert.equal(LIBRARY_COPY.addSummary('Donate band', 'sections', 'copy', 'Donate'), 'Add “Donate band” from Sections (a copy) to “Donate”')
  assert.equal(LIBRARY_COPY.addSummary('Winter appeal CTA', 'saved', 'linked', 'Donate'), 'Add your saved block “Winter appeal CTA” (linked) to “Donate”')
  assert.match(BUILD_PLAN_HINT, /find_blocks' `note` line word for word/)
})

console.log(`\n${n} checks passed`)
