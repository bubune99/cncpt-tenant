/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/history/compare.assert.ts
 */
import assert from 'node:assert/strict'
import { EMPTY, compareRevision, describeReason, formatValue, humanize, listChanges } from './compare'
import { SECRET_MARK, restoreReason, DRIFT_REASON } from './revisions'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('plain values read as words', () => {
  assert.equal(formatValue(true), 'On')
  assert.equal(formatValue(false), 'Off')
  assert.equal(formatValue(''), EMPTY)
  assert.equal(formatValue(null), EMPTY)
  assert.equal(formatValue(['a@x.org', 'b@x.org']), 'a@x.org, b@x.org')
  assert.equal(formatValue([{ id: 1 }, { id: 2 }]), '2 items')
  assert.equal(formatValue('x'.repeat(1000)).length, 400)
})

check('field names are humanized when the host gives no label', () => {
  assert.equal(humanize('submitButtonText'), 'Submit button text')
  assert.equal(humanize('cookie_banner'), 'Cookie banner')
})

check('a form question list: added, removed, changed (with what), reordered', () => {
  const before = [{ id: 'a', label: 'Name', required: false }, { id: 'b', label: 'Email' }, { id: 'c', label: 'Phone' }]
  const after = [{ id: 'b', label: 'Email' }, { id: 'a', label: 'Name', required: true }, { id: 'd', label: 'Why?' }]
  const r = listChanges(before, after)
  assert.deepEqual(r.items.map((i) => `${i.change}:${i.name}`), ['changed:Name', 'added:Why?', 'removed:Phone'])
  assert.deepEqual(r.items[0].details, [{ key: 'Required', before: 'Off', after: 'On' }])
  assert.equal(r.reordered, true)
  assert.equal(listChanges(before, before).reordered, false)
})

check('compareRevision picks the shape per field and uses the host labels', () => {
  const d = compareRevision(
    {
      changed: ['captchaEnabled', 'display', 'fields', 'name', 'apiKey', 'notes'],
      before: { captchaEnabled: false, display: { showAs: 'page' }, fields: [{ id: 'a', label: 'Name' }], name: 'Old', apiKey: SECRET_MARK },
      after: { captchaEnabled: true, display: { showAs: 'popup', delay: 3 }, fields: [], name: 'New', apiKey: SECRET_MARK },
    },
    { fields: 'Questions', display: 'Where it shows' },
  )
  assert.deepEqual(d.map((x) => `${x.kind}:${x.label}`), ['value:Captcha enabled', 'object:Where it shows', 'list:Questions', 'value:Name', 'secret:Api key', 'hidden:Notes'])
  const display = d[1]
  assert.ok(display.kind === 'object')
  assert.deepEqual(display.entries, [{ key: 'Delay', before: EMPTY, after: '3' }, { key: 'Show as', before: 'page', after: 'popup' }])
  const list = d[2]
  assert.ok(list.kind === 'list' && list.items[0].change === 'removed' && list.items[0].name === 'Name')
})

check('a value that appeared from nothing is a value change, not hidden', () => {
  const d = compareRevision({ changed: ['redirectUrl'], before: { redirectUrl: null }, after: { redirectUrl: '/thanks' } })
  assert.deepEqual(d[0], { kind: 'value', field: 'redirectUrl', label: 'Redirect url', before: EMPTY, after: '/thanks' })
})

check('reasons read as sentences (matches the core’s reason strings)', () => {
  assert.equal(describeReason(restoreReason(3)), 'Restored version 3')
  assert.equal(describeReason(restoreReason(0)), 'Restored the original')
  assert.equal(describeReason(DRIFT_REASON), 'Changed outside the editor')
  assert.equal(describeReason(null), null)
  assert.equal(describeReason('Agent: tidy labels'), 'Agent: tidy labels')
  assert.equal(describeReason('save'), null)
  assert.equal(describeReason('ai-edit'), 'Approved assistant change')
  assert.equal(describeReason('delete'), 'Deleted')
  assert.equal(describeReason('publish'), 'Published') // pages' own reasons
})

console.log(`\n${n} checks passed`)
