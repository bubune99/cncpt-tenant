/**
 * Versioning & history — what a revision changed, in words people read.
 * Pure and app-agnostic: the History panel and the change widgets render
 * this, they don't diff anything themselves.
 *
 * - Plain values: before → after ("On" / "Off", "(empty)").
 * - Lists of items with an `id` (a form's questions): which were added,
 *   removed, changed (and what in them) or reordered.
 * - Objects (settings blocks): the keys inside that changed.
 * - A secret shows only that it changed; a value hidden from the viewer
 *   shows as hidden.
 *
 * Asserted by compare.assert.ts.
 */

import { SECRET_MARK, stableJson, type RevisionChange } from './revisions'

type Obj = Record<string, unknown>

export interface ValueChange {
  key: string
  before: string
  after: string
}

export interface ItemChange {
  change: 'added' | 'removed' | 'changed'
  name: string
  details: ValueChange[]
}

export type FieldDiff =
  | { kind: 'hidden'; field: string; label: string }
  | { kind: 'secret'; field: string; label: string }
  | { kind: 'value'; field: string; label: string; before: string; after: string }
  | { kind: 'list'; field: string; label: string; items: ItemChange[]; reordered: boolean }
  | { kind: 'object'; field: string; label: string; entries: ValueChange[] }

export const EMPTY = '(empty)'
const MAX_TEXT = 400

const isObj = (v: unknown): v is Obj => !!v && typeof v === 'object' && !Array.isArray(v)
const clip = (s: string) => (s.length > MAX_TEXT ? `${s.slice(0, MAX_TEXT - 1)}…` : s)

/** One value as text. */
export function formatValue(v: unknown): string {
  if (v === null || v === undefined || v === '') return EMPTY
  if (typeof v === 'boolean') return v ? 'On' : 'Off'
  if (typeof v === 'string') return clip(v)
  if (typeof v === 'number') return String(v)
  if (Array.isArray(v)) {
    if (!v.length) return EMPTY
    if (v.every((x) => x === null || typeof x !== 'object')) return clip(v.map(formatValue).join(', '))
    return `${v.length} item${v.length === 1 ? '' : 's'}`
  }
  return clip(JSON.stringify(v))
}

/** "fieldName" → "Field name" when the host gives no label. */
export function humanize(key: string): string {
  const words = key.replace(/[_-]+/g, ' ').replace(/([a-z0-9])([A-Z])/g, '$1 $2').trim().toLowerCase()
  return words ? words[0].toUpperCase() + words.slice(1) : key
}

/** What people call a list item: its label, name or title, else its id. */
export function itemName(item: Obj): string {
  for (const k of ['label', 'name', 'title', 'text']) {
    const v = item[k]
    if (typeof v === 'string' && v.trim()) return clip(v.trim())
  }
  return typeof item.id === 'string' || typeof item.id === 'number' ? String(item.id) : 'Item'
}

/** The top-level keys that differ between two objects, as text. */
export function objectChanges(before: Obj, after: Obj, skip: ReadonlySet<string> = new Set()): ValueChange[] {
  const keys = [...new Set([...Object.keys(before), ...Object.keys(after)])].filter((k) => !skip.has(k)).sort()
  return keys
    .filter((k) => stableJson(before[k]) !== stableJson(after[k]))
    .map((k) => ({ key: humanize(k), before: formatValue(before[k]), after: formatValue(after[k]) }))
}

const hasIds = (v: unknown): v is Obj[] =>
  Array.isArray(v) && v.every((x) => isObj(x) && (typeof x.id === 'string' || typeof x.id === 'number'))

const ID_ONLY = new Set(['id'])

/** Lists of items with ids: added / removed / changed, and whether the order changed. */
export function listChanges(before: Obj[], after: Obj[]): { items: ItemChange[]; reordered: boolean } {
  const b = new Map(before.map((x) => [String(x.id), x]))
  const a = new Map(after.map((x) => [String(x.id), x]))
  const items: ItemChange[] = []
  for (const x of after) {
    const old = b.get(String(x.id))
    if (!old) items.push({ change: 'added', name: itemName(x), details: [] })
    else if (stableJson(old) !== stableJson(x)) items.push({ change: 'changed', name: itemName(x), details: objectChanges(old, x, ID_ONLY) })
  }
  for (const x of before) if (!a.has(String(x.id))) items.push({ change: 'removed', name: itemName(x), details: [] })
  const kept = (list: Obj[], other: Map<string, Obj>) => list.map((x) => String(x.id)).filter((id) => other.has(id))
  const reordered = kept(before, a).join('\u0000') !== kept(after, b).join('\u0000')
  return { items, reordered }
}

/**
 * Each changed field of a revision, ready to show. `labels` names the fields
 * ("fields" → "Questions"); fields without one are humanized.
 */
export function compareRevision(rev: RevisionChange, labels: Readonly<Record<string, string>> = {}): FieldDiff[] {
  return rev.changed.map((field): FieldDiff => {
    const label = labels[field] ?? humanize(field)
    const inB = Object.prototype.hasOwnProperty.call(rev.before, field)
    const inA = Object.prototype.hasOwnProperty.call(rev.after, field)
    if (!inB && !inA) return { kind: 'hidden', field, label }
    const before = rev.before[field]
    const after = rev.after[field]
    if (before === SECRET_MARK || after === SECRET_MARK) return { kind: 'secret', field, label }
    if (hasIds(before ?? []) && hasIds(after ?? []) && (Array.isArray(before) || Array.isArray(after))) {
      return { kind: 'list', field, label, ...listChanges((before ?? []) as Obj[], (after ?? []) as Obj[]) }
    }
    if ((isObj(before) || before == null) && (isObj(after) || after == null) && (isObj(before) || isObj(after))) {
      return { kind: 'object', field, label, entries: objectChanges((before ?? {}) as Obj, (after ?? {}) as Obj) }
    }
    return { kind: 'value', field, label, before: formatValue(before), after: formatValue(after) }
  })
}

/** What the writers record as a reason, in words. */
const REASON_TEXT: Record<string, string | null> = {
  save: null, // the plain case — who and what already say it
  'ai-edit': 'Approved assistant change',
  create: 'Created',
  delete: 'Deleted',
  cli: 'From the command line',
  'project import': 'From a project import',
  'Content API': 'From the Content API',
  publish: 'Published',
  unpublish: 'Unpublished',
  restore: 'Restored an earlier version',
}

/** "restore of v3" → "Restored version 3"; the drift note; known writer codes; otherwise as written. */
export function describeReason(reason: string | null | undefined): string | null {
  if (!reason) return null
  if (Object.prototype.hasOwnProperty.call(REASON_TEXT, reason)) return REASON_TEXT[reason]
  if (reason === 'restore of the original') return 'Restored the original'
  const m = /^restore of v(\d+)$/.exec(reason)
  if (m) return `Restored version ${m[1]}`
  if (reason === 'changed outside history') return 'Changed outside the editor'
  return reason
}
