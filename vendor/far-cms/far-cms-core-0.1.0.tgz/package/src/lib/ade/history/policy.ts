/**
 * Versioning & history — the RESTORE POLICY (pure, app-agnostic; asserted
 * by policy.assert.ts). A restore is never "put the old snapshot back": it is
 * a plan of individual fields, each classed by the entity's policy, and only
 * the fields the person ticks are written.
 *
 *   restorable  editorial/config — ticked by default
 *   guarded     has side effects (price, address/slug, status/publish,
 *               variants/options, category links) — unticked; restorable only
 *               when ticked explicitly, with its consequence shown
 *   never       stock, orders, payments, external ids, counters, timestamps,
 *               audit, customer-owned data, other entities' data — never
 *               written. A field the policy doesn't list is `never`.
 *
 * Every revision carries the schemaVersion it was written under; an old
 * version is migrated forward by the policy before planning, and a field
 * that no longer exists, changed type, or holds an unknown enum value is
 * skipped with the reason. A field changed by someone else after that
 * version is a conflict (flagged, unticked). A reference that no longer
 * exists (deleted image, category, variant) is skipped.
 */

import { stableJson } from './revisions'

type Obj = Record<string, unknown>

export type FieldClass = 'restorable' | 'guarded' | 'never'
export type FieldType = 'string' | 'number' | 'boolean' | 'json' | 'date' | 'enum' | 'string[]'

export interface FieldPolicy {
  class: FieldClass
  type?: FieldType
  /** Allowed values when type is 'enum'. */
  values?: readonly string[]
  /** Guarded: what happens if it's restored ("The page's address changes — …"). */
  consequence?: string
  /** A follow-up the person must do or is offered (Stripe re-sync, a redirect…). */
  followUp?: 'stripe-resync' | 'redirect' | 'publish-gate'
  /** Never: why ("stock comes from movements"). */
  reason?: string
  /** Values a restore may not set — they go through their own gate (e.g. publishing). */
  gateValues?: readonly string[]
  /** Why gateValues are refused ("Publish it from the editor, where its checks run"). */
  gateReason?: string
}

export interface RestorePolicy {
  /** The shape revisions are written in now. */
  schemaVersion: number
  fields: Readonly<Record<string, FieldPolicy>>
  /** For entities whose fields are open-ended (settings groups): the class of a field not listed. Default: never. */
  defaultField?: FieldPolicy
  /** Bring a state recorded under an older schemaVersion up to the current one. */
  migrate?: (state: Obj, fromVersion: number) => Obj
}

export type SkipReason = 'never' | 'unknown-field' | 'removed-field' | 'type-changed' | 'unknown-value' | 'missing-reference' | 'secret' | 'hidden' | 'gated'

export interface PlanField {
  field: string
  class: FieldClass
  /** Now → what the restore would write. */
  current: unknown
  restored: unknown
  /** Ticked when the plan opens. */
  selected: boolean
  /** Can be ticked at all. */
  selectable: boolean
  conflict: boolean
  consequence?: string
  followUp?: FieldPolicy['followUp']
  skip?: { reason: SkipReason; detail: string }
}

export interface RestorePlan {
  fromVersion: number
  schemaVersion: number
  fields: PlanField[]
}

const SECRET = '[changed]'

function typeOk(v: unknown, p: FieldPolicy): boolean {
  if (v === null || v === undefined) return true // clearing is always shape-safe
  switch (p.type) {
    case undefined:
    case 'json':
      return true
    case 'string':
      return typeof v === 'string'
    case 'number':
      return typeof v === 'number' && Number.isFinite(v)
    case 'boolean':
      return typeof v === 'boolean'
    case 'date':
      return typeof v === 'string' && !Number.isNaN(Date.parse(v))
    case 'enum':
      return typeof v === 'string'
    case 'string[]':
      return Array.isArray(v) && v.every((x) => typeof x === 'string')
  }
}

export interface PlanInput {
  policy: RestorePolicy
  /** The entity now. */
  current: Obj
  /** The entity as it was right after `fromVersion`. */
  target: Obj
  fromVersion: number
  /** schemaVersion the target state was recorded under. */
  targetSchemaVersion: number
  /** Fields someone else changed after `fromVersion`. */
  changedSince: ReadonlySet<string>
  /** Fields whose referenced records no longer exist (field → what's missing). */
  missingRefs?: Readonly<Record<string, string | undefined>>
  /** Fields the viewer may not see (masked): never offered. */
  hidden?: ReadonlySet<string>
}

/** Exactly the fields a restore would change, each classed, ticked or not, or skipped with why. */
export function planRestore(input: PlanInput): RestorePlan {
  const { policy } = input
  const target = input.targetSchemaVersion < policy.schemaVersion && policy.migrate ? policy.migrate({ ...input.target }, input.targetSchemaVersion) : input.target
  const keys = [...new Set([...Object.keys(target), ...Object.keys(input.current)])].sort()
  const out: PlanField[] = []
  for (const field of keys) {
    const current = input.current[field]
    const restored = target[field]
    if (!(field in target)) continue // the old version says nothing about it
    if (stableJson(current) === stableJson(restored)) continue
    const p = policy.fields[field] ?? policy.defaultField
    const base = { field, current, restored, conflict: input.changedSince.has(field) }
    const skip = (reason: SkipReason, detail: string, cls: FieldClass = p?.class ?? 'never'): PlanField => ({ ...base, class: cls, selected: false, selectable: false, skip: { reason, detail } })
    if (input.hidden?.has(field)) { out.push(skip('hidden', 'You can’t see this field')); continue }
    if (restored === SECRET || current === SECRET) { out.push(skip('secret', 'Secret values are never kept, so they can’t be restored')); continue }
    if (!p) {
      out.push(skip(field in input.current ? 'unknown-field' : 'removed-field', field in input.current ? 'Not something a restore can change' : 'This field no longer exists', 'never'))
      continue
    }
    if (p.class === 'never') { out.push(skip('never', p.reason ?? 'Never restored')); continue }
    if (!typeOk(restored, p)) { out.push(skip('type-changed', 'This field has changed shape since that version')); continue }
    if (p.type === 'enum' && restored != null && !(p.values ?? []).includes(restored as string)) { out.push(skip('unknown-value', `“${String(restored)}” is no longer an option`)); continue }
    const missing = input.missingRefs?.[field]
    if (missing) { out.push(skip('missing-reference', missing)); continue }
    if (p.gateValues && typeof restored === 'string' && p.gateValues.includes(restored)) { out.push(skip('gated', p.gateReason ?? 'This has its own checks — do it from the editor')); continue }
    const guarded = p.class === 'guarded'
    out.push({
      ...base,
      class: p.class,
      selectable: true,
      selected: !guarded && !base.conflict,
      ...(p.consequence ? { consequence: p.consequence } : {}),
      ...(p.followUp ? { followUp: p.followUp } : {}),
    })
  }
  return { fromVersion: input.fromVersion, schemaVersion: policy.schemaVersion, fields: out }
}

export interface RestoreSelection {
  /** What to write — only selectable fields the person ticked. */
  patch: Obj
  restored: string[]
  skipped: Array<{ field: string; reason: string }>
  followUps: Array<NonNullable<FieldPolicy['followUp']>>
}

/**
 * Turn the person's ticks into the write. Anything not selectable, not in
 * the plan, or not ticked is left alone — a whole-snapshot restore can't
 * happen. Throws if nothing selectable was ticked.
 */
export function selectRestore(plan: RestorePlan, ticked: readonly string[]): RestoreSelection {
  const want = new Set(ticked)
  const patch: Obj = {}
  const restored: string[] = []
  const skipped: RestoreSelection['skipped'] = []
  const followUps = new Set<NonNullable<FieldPolicy['followUp']>>()
  for (const f of plan.fields) {
    if (f.skip) { skipped.push({ field: f.field, reason: f.skip.detail }); continue }
    if (!want.has(f.field)) { skipped.push({ field: f.field, reason: f.conflict ? 'Changed by someone else since — left as it is' : 'Not chosen' }); continue }
    patch[f.field] = f.restored
    restored.push(f.field)
    if (f.followUp) followUps.add(f.followUp)
  }
  for (const t of want) if (!plan.fields.some((f) => f.field === t)) skipped.push({ field: t, reason: 'Nothing to restore for this field' })
  if (!restored.length) throw new Error('Choose at least one field to restore')
  return { patch, restored, skipped, followUps: [...followUps] }
}

/** Policies for kinds of record that are NEVER restorable (customer-owned data). */
export const NEVER_RESTORABLE_ENTITIES: ReadonlySet<string> = new Set([
  'customer', 'customer-address', 'address', 'consent', 'subscriber', 'message', 'conversation', 'order', 'payment', 'form-submission',
])
