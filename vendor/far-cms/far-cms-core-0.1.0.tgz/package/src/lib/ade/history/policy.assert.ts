/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/history/policy.assert.ts
 */
import assert from 'node:assert/strict'
import { NEVER_RESTORABLE_ENTITIES, planRestore, selectRestore, type RestorePolicy } from './policy'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const PRODUCT: RestorePolicy = {
  schemaVersion: 2,
  fields: {
    title: { class: 'restorable', type: 'string' },
    description: { class: 'restorable', type: 'string' },
    imageId: { class: 'restorable', type: 'string' },
    price: { class: 'guarded', type: 'number', consequence: 'The price changes for new orders', followUp: 'stripe-resync' },
    slug: { class: 'guarded', type: 'string', consequence: 'The old address stops working', followUp: 'redirect' },
    status: { class: 'guarded', type: 'enum', values: ['DRAFT', 'ACTIVE', 'ARCHIVED'], followUp: 'publish-gate' },
    stock: { class: 'never', reason: 'Stock comes from stock movements' },
    tags: { class: 'restorable', type: 'string[]' },
  },
  // v1 called the title "name".
  migrate: (s, from) => (from < 2 && 'name' in s ? (({ name, ...rest }) => ({ ...rest, title: name }))(s as { name: unknown }) : s),
}

const plan = (target: Record<string, unknown>, extra: Partial<Parameters<typeof planRestore>[0]> = {}) =>
  planRestore({
    policy: PRODUCT,
    current: { title: 'Now', description: 'd2', imageId: 'img2', price: 20, slug: 'now', status: 'ACTIVE', stock: 5, tags: ['a'], createdAt: 'x' },
    target,
    fromVersion: 3,
    targetSchemaVersion: 2,
    changedSince: new Set(),
    ...extra,
  })

check('1 field classes: restorable ticked, guarded unticked with its consequence, never not offered', () => {
  const p = plan({ title: 'Old', price: 10, stock: 9 })
  const by = Object.fromEntries(p.fields.map((f) => [f.field, f]))
  assert.equal(by.title.selected, true)
  assert.equal(by.price.selected, false); assert.equal(by.price.selectable, true); assert.match(by.price.consequence!, /price/)
  assert.equal(by.stock.selectable, false); assert.equal(by.stock.skip!.reason, 'never')
})

check('1 a field the policy does not list is never written (no whole-snapshot restore)', () => {
  const p = plan({ title: 'Old', createdAt: 'y', internalId: 'z' })
  assert.deepEqual(p.fields.filter((f) => f.selectable).map((f) => f.field), ['title'])
  const s = selectRestore(p, ['title', 'createdAt', 'internalId', 'stock'])
  assert.deepEqual(Object.keys(s.patch), ['title'])
})

check('2 only fields that would change are listed; conflicts flagged and unticked', () => {
  const p = plan({ title: 'Now', description: 'd1', imageId: 'img2' }, { changedSince: new Set(['description']) })
  assert.deepEqual(p.fields.map((f) => f.field), ['description'])
  assert.equal(p.fields[0].conflict, true); assert.equal(p.fields[0].selected, false); assert.equal(p.fields[0].selectable, true)
})

check('2 the person picks fields; guarded only when ticked; follow-ups reported', () => {
  const p = plan({ title: 'Old', price: 10, slug: 'old' })
  assert.deepEqual(selectRestore(p, p.fields.filter((f) => f.selected).map((f) => f.field)).patch, { title: 'Old' })
  const s = selectRestore(p, ['title', 'price', 'slug'])
  assert.deepEqual(s.patch, { title: 'Old', price: 10, slug: 'old' })
  assert.deepEqual(s.followUps.sort(), ['redirect', 'stripe-resync'])
  assert.throws(() => selectRestore(p, []), /at least one/)
})

check('3 schemaVersion: old shapes migrate forward; changed type / removed field / unknown enum skipped with a reason', () => {
  const p = plan({ name: 'Old name', price: 'ten', status: 'PENDING', colour: 'red' }, { targetSchemaVersion: 1 })
  const by = Object.fromEntries(p.fields.map((f) => [f.field, f]))
  assert.equal(by.title.restored, 'Old name')
  assert.equal(by.price.skip!.reason, 'type-changed')
  assert.equal(by.status.skip!.reason, 'unknown-value')
  assert.equal(by.colour.skip!.reason, 'removed-field')
})

check('4 a deleted reference is flagged and skipped', () => {
  const p = plan({ imageId: 'img-deleted' }, { missingRefs: { imageId: 'That picture was deleted from Media' } })
  assert.equal(p.fields[0].skip!.reason, 'missing-reference')
  assert.throws(() => selectRestore(p, ['imageId']), /at least one/)
})

check('5 secrets and hidden fields are never offered; customer-owned kinds are never restorable', () => {
  const p = plan({ title: 'Old', description: '[changed]' }, { hidden: new Set(['title']) })
  assert.ok(p.fields.every((f) => !f.selectable))
  for (const k of ['customer', 'customer-address', 'consent', 'message', 'order']) assert.ok(NEVER_RESTORABLE_ENTITIES.has(k), k)
})

check('7 the selection says what was restored and what was skipped and why', () => {
  const p = plan({ title: 'Old', price: 10, stock: 1 }, { changedSince: new Set(['title']) })
  const s = selectRestore(p, ['price'])
  assert.deepEqual(s.restored, ['price'])
  assert.deepEqual(s.skipped.map((x) => x.field).sort(), ['stock', 'title'])
  assert.match(s.skipped.find((x) => x.field === 'title')!.reason, /someone else/)
})

check('4 status → a published value goes through the publish gate, not a restore', () => {
  const pol: RestorePolicy = { schemaVersion: 1, fields: { status: { class: 'guarded', type: 'enum', values: ['DRAFT', 'PUBLISHED'], gateValues: ['PUBLISHED'], gateReason: 'Publish it from the editor' } } }
  const p = planRestore({ policy: pol, current: { status: 'DRAFT' }, target: { status: 'PUBLISHED' }, fromVersion: 1, targetSchemaVersion: 1, changedSince: new Set() })
  assert.equal(p.fields[0].skip!.reason, 'gated')
  const back = planRestore({ policy: pol, current: { status: 'PUBLISHED' }, target: { status: 'DRAFT' }, fromVersion: 1, targetSchemaVersion: 1, changedSince: new Set() })
  assert.equal(back.fields[0].selectable, true, 'unpublishing is a plain guarded change')
})

check('open-ended entities (settings) use defaultField; still nothing outside the policy', () => {
  const pol: RestorePolicy = { schemaVersion: 1, fields: {}, defaultField: { class: 'restorable', type: 'json' } }
  const p = planRestore({ policy: pol, current: { a: 1 }, target: { a: 2 }, fromVersion: 1, targetSchemaVersion: 1, changedSince: new Set() })
  assert.equal(p.fields[0].selected, true)
})

console.log(`\n${n} checks passed`)
