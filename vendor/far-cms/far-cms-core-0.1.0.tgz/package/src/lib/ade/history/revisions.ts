/**
 * Versioning & history — the pure core. App-agnostic: the host stores
 * revisions and loads/saves entities (lib/ade-bindings/history).
 *
 * A revision is the CHANGE one write made to one entity: the top-level fields
 * that differ, with their value before and after (not a full snapshot).
 * Versions are 1-based and monotonic per entity; version 0 = the state before
 * history began (the first revision's `before`).
 *
 * Restoring never rewrites history: the state at version N is rebuilt by
 * undoing every later revision from the current state, and the difference
 * is written as a NEW revision.
 *
 * Secrets are never stored: a secret field records only that it changed
 * (SECRET_MARK in both before and after), and a restore leaves it as it is.
 * Personal data IS stored (a restore needs it) and is masked when read.
 *
 * Asserted by history.assert.ts.
 */

export type ActorKind = 'user' | 'agent' | 'system'

export interface Actor {
  kind: ActorKind
  userId?: string | null
  runId?: string | null
}

export interface RevisionChange {
  /** Top-level field names that changed. */
  changed: string[]
  before: Record<string, unknown>
  after: Record<string, unknown>
}

export interface RevisionRow extends RevisionChange {
  id: string
  version: number
}

/** An adapter refusing a restore for a reason people should see (→ 403, not 500). */
export class HistoryRefusal extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'HistoryRefusal'
  }
}

/**
 * Same value, ignoring key order and keys that are undefined — how editor
 * documents must be compared: editors and the database (jsonb sorts keys)
 * don't keep keys in the same order, and editors leave optional keys
 * undefined. A JSON.stringify comparison made untouched documents look
 * edited, so merely opening an editor wrote.
 */
export function canonical(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(canonical)
  if (v instanceof Date) return v.toISOString()
  if (v && typeof v === 'object') {
    return Object.fromEntries(
      Object.keys(v as Record<string, unknown>)
        .filter((k) => (v as Record<string, unknown>)[k] !== undefined)
        .sort()
        .map((k) => [k, canonical((v as Record<string, unknown>)[k])])
    )
  }
  return v
}

export function sameValue(a: unknown, b: unknown): boolean {
  return JSON.stringify(canonical(a)) === JSON.stringify(canonical(b))
}

/** Stored in place of a secret's value. */
export const SECRET_MARK = '[changed]'

type Obj = Record<string, unknown>

/** Order-independent JSON for comparing values. */
export function stableJson(v: unknown): string {
  const norm = (x: unknown): unknown => {
    if (x instanceof Date) return x.toISOString()
    if (Array.isArray(x)) return x.map(norm)
    if (x && typeof x === 'object') return Object.fromEntries(Object.keys(x as Obj).sort().map((k) => [k, norm((x as Obj)[k])]))
    return x === undefined ? null : x
  }
  return JSON.stringify(norm(v))
}

const plain = (v: unknown): unknown => (v === undefined ? null : v instanceof Date ? v.toISOString() : v)

export interface DiffOptions {
  /** Fields never versioned (ids, timestamps, counters). */
  ignore?: ReadonlySet<string>
  /** Is this field a secret (never stored)? */
  isSecret?: (field: string) => boolean
}

/**
 * The change between two states (top-level fields only). Returns null when
 * nothing that is versioned changed.
 */
export function diffState(before: Obj | null, after: Obj | null, opts: DiffOptions = {}): RevisionChange | null {
  const b = before ?? {}
  const a = after ?? {}
  const keys = [...new Set([...Object.keys(b), ...Object.keys(a)])].filter((k) => !opts.ignore?.has(k)).sort()
  const out: RevisionChange = { changed: [], before: {}, after: {} }
  for (const k of keys) {
    if (stableJson(b[k]) === stableJson(a[k])) continue
    out.changed.push(k)
    const secret = opts.isSecret?.(k) ?? false
    out.before[k] = secret ? SECRET_MARK : plain(b[k])
    out.after[k] = secret ? SECRET_MARK : plain(a[k])
  }
  return out.changed.length ? out : null
}

/** The next version number for an entity, given the versions it has. */
export function nextVersion(existing: readonly number[]): number {
  return existing.length ? Math.max(...existing) + 1 : 1
}

/**
 * The entity's state at `version`, rebuilt from its CURRENT state by undoing
 * every revision newer than `version` (newest first). Secret fields are left
 * as they are now. Throws when the history has a gap (can't be trusted).
 */
export function stateAt(current: Obj, revisions: readonly RevisionRow[], version: number): Obj {
  const newer = [...revisions].filter((r) => r.version > version).sort((x, y) => y.version - x.version)
  const latest = revisions.reduce((m, r) => Math.max(m, r.version), 0)
  if (version < 0 || version > latest) throw new RangeError(`No version ${version} (latest is ${latest})`)
  // Every version between `version` and the latest must be present.
  for (let v = latest; v > version; v--) if (!newer.some((r) => r.version === v)) throw new Error(`Version ${v} is missing from the history`)
  const state: Obj = { ...current }
  for (const r of newer) {
    for (const k of r.changed) {
      if (r.before[k] === SECRET_MARK) continue // secrets aren't kept; leave the current value
      state[k] = r.before[k]
    }
  }
  return state
}

/**
 * What a restore to `version` must write: only the fields that differ from
 * now. Null = already in that state (nothing to do).
 */
export function restorePatch(current: Obj, revisions: readonly RevisionRow[], version: number, opts: DiffOptions = {}): Obj | null {
  const target = stateAt(current, revisions, version)
  const change = diffState(current, target, opts)
  if (!change) return null
  return Object.fromEntries(change.changed.filter((k) => change.after[k] !== SECRET_MARK).map((k) => [k, target[k]]))
}

/**
 * Did the entity change since the history last saw it (a write that didn't
 * record)? Compares the last known value of every field the history has
 * touched with the state just before this write. Returns that difference as
 * its own change (record it first, reason DRIFT_REASON), so undoing later
 * revisions never lands on a stale value. Secrets are ignored.
 */
export function driftChange(revisions: readonly RevisionRow[], before: Obj, opts: DiffOptions = {}): RevisionChange | null {
  const known: Obj = {}
  for (const r of [...revisions].sort((x, y) => x.version - y.version)) for (const k of r.changed) known[k] = r.after[k]
  const keys = Object.keys(known).filter((k) => known[k] !== SECRET_MARK && !(opts.isSecret?.(k) ?? false) && !opts.ignore?.has(k))
  if (!keys.length) return null
  return diffState(Object.fromEntries(keys.map((k) => [k, known[k]])), Object.fromEntries(keys.map((k) => [k, before[k]])), opts)
}

export const DRIFT_REASON = 'changed outside history'

/** Reason text for a restore revision. */
export const restoreReason = (version: number): string => (version === 0 ? 'restore of the original' : `restore of v${version}`)

/**
 * Mask a stored change for a viewer: `mask` gets each side's changed fields
 * and returns them with private values hidden (the host passes its
 * visibility maskData). Secrets are already SECRET_MARK.
 */
export function maskChange<T extends RevisionChange>(change: T, mask: (fields: Obj) => Obj): T {
  return { ...change, before: mask(change.before), after: mask(change.after) }
}
