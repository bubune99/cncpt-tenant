/**
 * Outside text taints the conversation — pure; asserted by taint.assert.ts.
 * The ONE shared core for Dzidzor and BYB (BYB's provenance.ts folded in).
 *
 * Owner decisions (2026-10-12/13, via BYB's security closure): once the
 * assistant has read text written by outsiders (a customer message, a form
 * submission, an email, a review, a web page, anything a tool returns
 * marked untrusted), every change it makes for the REST OF THE CONVERSATION
 * needs the person's approval — even in auto mode, drafts included. Reads
 * stay free. A new chat starts clean.
 *
 * - Which tools bring outside text is a per-tool meta flag
 *   (`untrustedSource`), set by each app in its own bindings
 *   (withUntrustedSources); unregistered (vMCP / MCP) tools count.
 * - The taint lives on the SERVER: one object per request, seeded from the
 *   conversation's own run records — never from the client.
 * - Same step: a possibly-tainting CALL marks the step pending before its
 *   result, so a write issued in the same step asks (or, if it was decided
 *   first, is refused at execute and can be asked again).
 * - Apps apply it in their governance guard, combined with their own
 *   approval rules (labels, input-dependent risk). MCP key calls have no
 *   conversation and are not covered here.
 */

export const TAINT_REASON = 'Approval needed because the assistant read outside text in this conversation'

export interface RunTaint {
  /** True once any outside text was read in this run (or conversation, when seeded). */
  readonly tainted: boolean
  /**
   * The current step has CALLED a tool that may bring outside text, whose
   * result isn't in yet (parallel calls in one step: a write must not slip
   * through because the read resolves after the write was decided).
   */
  readonly pending: boolean
  /** The tool whose result first tainted the run (name only), or null. */
  readonly source: string | null
  /** Ms offset (from the host's clock) when it was tainted, or null. */
  readonly at: number | null
  /** Record that `tool` returned outside text. First source wins. */
  mark(tool: string, at?: number): void
  /** A possibly-tainting call was issued in this step (before its result). */
  markPending(tool: string): void
  /** The step ended: what was pending either tainted the run (mark) or was clean. */
  endStep(): void
}

export function createRunTaint(seed?: { source: string; at?: number | null } | null): RunTaint {
  let source: string | null = seed?.source ?? null
  let at: number | null = seed ? seed.at ?? 0 : null
  let pending = false
  return {
    get tainted() {
      return source !== null
    },
    get pending() {
      return pending
    },
    markPending() {
      pending = true
    },
    endStep() {
      pending = false
    },
    get source() {
      return source
    },
    get at() {
      return at
    },
    mark(tool: string, when?: number) {
      if (source !== null) return
      source = String(tool).slice(0, 120) || 'unknown tool'
      at = when ?? 0
    },
  }
}

/** A result wrapped by asUntrusted (lib/ade/connectors) or flagged { provenance: 'untrusted' } (BYB's marker). */
export function outputIsUntrusted(output: unknown): boolean {
  if (!output || typeof output !== 'object') return false
  const o = output as { untrusted?: unknown; provenance?: unknown }
  return o.untrusted === true || o.provenance === 'untrusted'
}

/**
 * Before the result: could this CALL bring outside text? (true and 'screen'
 * labels: yes — a screen read's route isn't known until it answers; a
 * function label decides from the input; no label: no.) Used to hold the
 * same step's writes.
 */
export function callMayTaint(label: UntrustedLabel | undefined, input: unknown): boolean {
  if (label === true || label === 'screen') return true
  if (typeof label === 'function') {
    try {
      return label(input) === true
    } catch {
      return true
    }
  }
  return false
}

/**
 * How a tool is labelled for taint:
 * - true: its results are always outside text;
 * - a function: decides from the call's input (e.g. an entity type);
 * - 'screen': a screen read — tainted when the screen shows outside text;
 * - undefined: staff-authored / structural data.
 */
export type UntrustedLabel = true | 'screen' | ((input: unknown) => boolean)

/** The route a screen read reported (`route` or `view.route`), or null. */
export function screenRouteOf(output: unknown): string | null {
  if (!output || typeof output !== 'object') return null
  const o = output as { route?: unknown; view?: { route?: unknown } }
  const r = o.route ?? o.view?.route
  return typeof r === 'string' ? r : null
}

/**
 * Does this screen show text written by outsiders? The host's patterns:
 * "/admin/orders" (that area and everything under it), "*submissions"
 * (any path containing it), "?tab=submissions" (that query pair). A screen
 * read that reported no route counts as outside text — fail closed.
 */
export function routeShowsOutsideText(route: string | null, patterns: readonly string[]): boolean {
  if (route === null) return true
  const [path, query = ''] = route.split('?')
  const pairs = query.split('&')
  return patterns.some((p) => {
    if (p.startsWith('?')) return pairs.includes(p.slice(1))
    if (p.startsWith('*')) return path.includes(p.slice(1))
    return path === p || path.startsWith(`${p}/`)
  })
}

/** Did this call put outside text in front of the model? */
export function callTaints(q: {
  label: UntrustedLabel | undefined
  /** An unregistered (vMCP / external MCP) tool: its output is never trusted. */
  unregistered?: boolean
  input: unknown
  output: unknown
  screenPatterns: readonly string[]
}): boolean {
  if (q.unregistered || outputIsUntrusted(q.output)) return true
  if (q.label === true) return true
  if (q.label === 'screen') return routeShowsOutsideText(screenRouteOf(q.output), q.screenPatterns)
  if (typeof q.label === 'function') {
    try {
      return q.label(q.input) === true
    } catch {
      return true
    }
  }
  return false
}

/** A tool's registry meta, as far as taint is concerned: apps set the flag in their own bindings. */
export interface UntrustedSourceMeta {
  untrustedSource?: UntrustedLabel
}

/**
 * An app's registry with its untrusted-source flags applied: each app lists
 * its own tools that read public text (Dzidzor: lib/ade-bindings/
 * untrusted-sources) — core never names an app's tools. Unknown names are
 * returned so the app's assert can fail on a typo.
 */
export function withUntrustedSources<M extends UntrustedSourceMeta>(registry: Readonly<Record<string, M>>, sources: Readonly<Record<string, UntrustedLabel>>): { registry: Record<string, M>; unknown: string[] } {
  const out: Record<string, M> = {}
  for (const [k, m] of Object.entries(registry)) out[k] = Object.hasOwn(sources, k) ? { ...m, untrustedSource: sources[k] } : m
  return { registry: out, unknown: Object.keys(sources).filter((k) => !Object.hasOwn(registry, k)) }
}

/** A write/draft/irreversible call needs approval when its own rules say so, or the run is (or this step may be) tainted. */
export const approvalUnderTaint = (effect: 'read' | 'draft' | 'write' | 'irreversible', base: boolean, taint: Pick<RunTaint, 'tainted' | 'pending'> | undefined): boolean =>
  effect === 'read' ? base : base || taint?.tainted === true || taint?.pending === true

/** The refusal a write gets when it was decided before a same-step read of outside text was issued. */
export const SAME_STEP_REFUSAL =
  'Not done: in the same step the assistant also read outside text, so this change needs the person’s approval. Ask again on its own and they will see an approval card.'
