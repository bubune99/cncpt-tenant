/**
 * What the agent may see. Every screen, record type and field resolves to
 * one of three levels:
 *
 *   readable       — the agent may read it (the default)
 *   metadata-only  — it may see what is there (labels, roles, how many) but
 *                    no values, text or rows
 *   blocked        — nothing; the agent says "this screen is private" and
 *                    can offer to guide the person there without reading it
 *
 * A FLOOR of rules (secrets, passwords, payment details, sign-in screens,
 * MCP keys, personal-data requests) is always blocked: the owner can add
 * rules and tighten them, never loosen the floor. The strictest matching
 * rule wins, so a looser custom rule can't undo a stricter one.
 *
 * Host-agnostic: the host supplies its own routes, entity names and field
 * markers (lib/ade-bindings). Pure; asserted by visibility.assert.ts.
 */

export type Visibility = 'readable' | 'metadata-only' | 'blocked'
/** owner = site owner / developer; staff = everyone else who can use the admin. */
export type ViewerRole = 'owner' | 'staff'

export const LEVELS: readonly Visibility[] = ['readable', 'metadata-only', 'blocked']
const RANK: Record<Visibility, number> = { readable: 0, 'metadata-only': 1, blocked: 2 }

export type RuleTarget =
  /** A route glob: `*` one path segment, `**` any depth; `?k=v` must also match. */
  | { kind: 'route'; pattern: string }
  /** A record type, as the read tools name it ("user", "order", "settings"). */
  | { kind: 'entity'; type: string }
  /** A field: its name pattern in data (e.g. "email"), or a data-ade-private marker value. */
  | { kind: 'field'; name: string }

export interface VisibilityRule {
  /** Stable id: floor.* (locked), app defaults, custom.<slug>. Used as `reason` in audits. */
  id: string
  label: string
  target: RuleTarget
  level: Visibility
  /** Who it applies to; absent = everyone. */
  roles?: readonly ViewerRole[]
  /** Floor rules can't be removed, loosened or edited. */
  floor?: boolean
}

export interface Resolution {
  level: Visibility
  /** The deciding rule (null = default readable). */
  rule: VisibilityRule | null
}

// ── Matching ─────────────────────────────────────────────────────────

function segs(path: string): string[] {
  return path.split('/').filter(Boolean)
}

function matchSegs(pat: string[], path: string[]): boolean {
  if (pat.length === 0) return path.length === 0
  const [head, ...rest] = pat
  if (head === '**') {
    for (let i = 0; i <= path.length; i++) if (matchSegs(rest, path.slice(i))) return true
    return false
  }
  if (path.length === 0) return false
  if (head !== '*' && head.toLowerCase() !== path[0].toLowerCase()) return false
  return matchSegs(rest, path.slice(1))
}

/** Does a route glob match a path (with its query string)? */
export function matchRoute(pattern: string, url: string): boolean {
  const [patPath, patQuery] = pattern.split('?')
  const [path, query] = url.split('#')[0].split('?')
  if (!matchSegs(segs(patPath), segs(path))) return false
  if (!patQuery) return true
  const want = new URLSearchParams(patQuery)
  const have = new URLSearchParams(query ?? '')
  for (const [k, v] of want) if ((have.get(k) ?? '').toLowerCase() !== v.toLowerCase()) return false
  return true
}

/** Field names compare loosely: case, `_`/`-` and a trailing number don't matter. */
function fieldKey(name: string): string {
  return name.toLowerCase().replace(/[_\-\s]/g, '')
}

/** Does a field rule name (exact, or `*suffix` / `prefix*`) match a field name? */
export function matchField(ruleName: string, field: string): boolean {
  const r = fieldKey(ruleName)
  const f = fieldKey(field)
  if (r.startsWith('*')) return f.endsWith(r.slice(1))
  if (r.endsWith('*')) return f.startsWith(r.slice(0, -1))
  return r === f
}

function applies(rule: VisibilityRule, role: ViewerRole): boolean {
  return !rule.roles || rule.roles.includes(role)
}

function strictest(rules: readonly VisibilityRule[]): Resolution {
  let best: Resolution = { level: 'readable', rule: null }
  for (const r of rules) {
    if (RANK[r.level] > RANK[best.level] || (RANK[r.level] === RANK[best.level] && r.floor && !best.rule?.floor)) {
      best = { level: r.level, rule: r }
    }
  }
  return best
}

export function resolveRoute(rules: readonly VisibilityRule[], url: string, role: ViewerRole): Resolution {
  return strictest(rules.filter((r) => r.target.kind === 'route' && applies(r, role) && matchRoute(r.target.pattern, url)))
}

export function resolveEntity(rules: readonly VisibilityRule[], type: string, role: ViewerRole): Resolution {
  const t = type.toLowerCase()
  return strictest(rules.filter((r) => r.target.kind === 'entity' && applies(r, role) && r.target.type.toLowerCase() === t))
}

export function resolveField(rules: readonly VisibilityRule[], field: string, role: ViewerRole): Resolution {
  return strictest(rules.filter((r) => r.target.kind === 'field' && applies(r, role) && matchField(r.target.name, field)))
}

// ── Masking ──────────────────────────────────────────────────────────

export const PRIVATE_VALUE = '[private]'

/** A unit as read_view / capture_view see it (a field, a row, a section). */
export interface ViewUnit {
  label?: string
  role?: string
  kind?: string
  /** data-ade-private marker on the unit, if any. */
  private?: string
  value?: unknown
  text?: string
  rows?: unknown[]
  children?: ViewUnit[]
  [k: string]: unknown
}

const VALUE_KEYS = new Set(['value', 'text', 'rows', 'html', 'src', 'href', 'items', 'content', 'screenshot', 'image'])

/**
 * A unit with values stripped to fit the level: metadata-only keeps labels,
 * roles and counts; blocked keeps nothing but the fact it's private. A unit
 * marked private (data-ade-private) is checked against the field rules too.
 */
export function maskUnit(unit: ViewUnit, level: Visibility, rules: readonly VisibilityRule[] = [], role: ViewerRole = 'staff'): ViewUnit {
  // A marker no rule knows about stays private (metadata-only); a known one follows its rule for this role.
  const known = unit.private !== undefined && rules.some((r) => r.target.kind === 'field' && matchField(r.target.name, unit.private!))
  const markedPrivate: Visibility = unit.private === undefined ? 'readable' : known ? resolveField(rules, unit.private, role).level : 'metadata-only'
  const lvl = RANK[markedPrivate] > RANK[level] ? markedPrivate : level
  if (lvl === 'blocked') return { label: unit.label, blocked: true }
  if (lvl === 'readable') return unit.children ? { ...unit, children: unit.children.map((c) => maskUnit(c, level, rules, role)) } : unit
  const out: ViewUnit = {}
  for (const [k, v] of Object.entries(unit)) {
    if (k === 'children') continue
    if (VALUE_KEYS.has(k)) {
      if (k === 'rows' && Array.isArray(v)) out.rowCount = v.length
      if (k === 'value' && v !== undefined && v !== null && v !== '') out.hasValue = true
      continue
    }
    out[k] = v
  }
  if (unit.children) out.children = unit.children.map((c) => maskUnit(c, 'metadata-only', rules, role))
  return out
}

export interface MaskReport {
  /** Field names whose values were replaced. */
  fields: string[]
  /** The rules that did it (ids). */
  rules: string[]
}

/**
 * Walk any tool result and replace the values of private fields (by the
 * field rules) with "[private]"; blocked fields are dropped. Returns the
 * masked copy and what was masked (names only, never values).
 */
export function maskData<T>(data: T, rules: readonly VisibilityRule[], role: ViewerRole): { data: T; report: MaskReport } {
  const fields = new Set<string>()
  const ruleIds = new Set<string>()
  const seen = new WeakSet<object>()
  const walk = (v: unknown, depth: number): unknown => {
    if (depth > 12 || v === null || typeof v !== 'object') return v
    if (seen.has(v as object)) return v
    seen.add(v as object)
    if (Array.isArray(v)) return v.map((x) => walk(x, depth + 1))
    const out: Record<string, unknown> = {}
    for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
      const r = resolveField(rules, k, role)
      if (r.level === 'readable' || val === null || val === undefined || val === '') {
        out[k] = walk(val, depth + 1)
        continue
      }
      fields.add(k)
      if (r.rule) ruleIds.add(r.rule.id)
      if (r.level === 'metadata-only') out[k] = PRIVATE_VALUE
    }
    return out
  }
  return { data: walk(data, 0) as T, report: { fields: [...fields], rules: [...ruleIds] } }
}

/** Metadata-only for a whole record or list: keep keys and counts, no values. */
export function metadataOnly(data: unknown, depth = 0): unknown {
  if (depth > 6) return '…'
  if (Array.isArray(data)) return { count: data.length, ...(data.length ? { each: metadataOnly(data[0], depth + 1) } : {}) }
  if (data !== null && typeof data === 'object') {
    const out: Record<string, unknown> = {}
    for (const [k, v] of Object.entries(data as Record<string, unknown>)) out[k] = v !== null && typeof v === 'object' ? metadataOnly(v, depth + 1) : typeof v
    return out
  }
  return typeof data
}

// ── What tools return when blocked ───────────────────────────────────

export interface BlockedResult {
  blocked: true
  reason: string
  canGuide: true
  message: string
}

export function blockedResult(rule: VisibilityRule | null, what: string): BlockedResult {
  return {
    blocked: true,
    reason: rule?.id ?? 'policy',
    canGuide: true,
    message: `${what} is private: the assistant can't read or capture it. Offer to show the person where it is (spotlight) instead, without reading it.`,
  }
}

/** One line for tool descriptions, so the model answers blocks the same way. */
export const BLOCKED_GUIDANCE =
  'Let the policy refuse, never you: when asked about any screen or record — even one you believe is private, or one refused earlier in this chat — call the tool (read_view for a screen) and answer from what it returns. A refusal only counts, and is only recorded, when the tool gives it; never decline from memory before calling. ' +
  'If a result says { blocked: true } — or, from the screen tools (read_view, capture_view, scan_page), { private: true } with a blocked list — say plainly that the screen or data is private and you can’t read it; offer to show the person where it is (navigate + spotlight) without reading it. "[private]" values, "filled" fields and "Row N" labels are withheld on purpose. Never guess at private values.'

// ── Editing the rules ────────────────────────────────────────────────

/** Rules as stored: the floor is never stored or editable, only the custom part. */
export function effectiveRules(floor: readonly VisibilityRule[], custom: readonly VisibilityRule[]): VisibilityRule[] {
  const floorIds = new Set(floor.map((r) => r.id))
  return [...floor.map((r) => ({ ...r, floor: true })), ...custom.filter((r) => !floorIds.has(r.id)).map((r) => ({ ...r, floor: false }))]
}

export type RuleCheck = { ok: true; rules: VisibilityRule[] } | { ok: false; error: string }

const ID = /^[a-z0-9][a-z0-9.\-]{1,63}$/

/** Validate owner-edited rules (settings save). Floor ids can't be reused; targets must be well formed. */
export function sanitizeRules(input: unknown, floor: readonly VisibilityRule[]): RuleCheck {
  if (!Array.isArray(input)) return { ok: false, error: 'Rules must be a list' }
  if (input.length > 100) return { ok: false, error: 'Up to 100 rules' }
  const floorIds = new Set(floor.map((r) => r.id))
  const out: VisibilityRule[] = []
  const ids = new Set<string>()
  for (const raw of input as Array<Record<string, unknown>>) {
    const id = typeof raw?.id === 'string' ? raw.id.trim() : ''
    if (!ID.test(id)) return { ok: false, error: `“${id || '(no id)'}” isn’t a valid rule id` }
    if (floorIds.has(id) || id.startsWith('floor.')) return { ok: false, error: 'Built-in protections can’t be changed' }
    const level = raw.level
    if (!LEVELS.includes(level as Visibility)) return { ok: false, error: `Rule “${id}” needs a level: readable, metadata-only or blocked` }
    const t = raw.target as Record<string, unknown> | undefined
    let target: RuleTarget
    if (t?.kind === 'route' && typeof t.pattern === 'string' && t.pattern.startsWith('/') && t.pattern.length <= 200) target = { kind: 'route', pattern: t.pattern }
    else if (t?.kind === 'entity' && typeof t.type === 'string' && /^[a-z][a-z0-9_-]{0,39}$/i.test(t.type)) target = { kind: 'entity', type: t.type }
    else if (t?.kind === 'field' && typeof t.name === 'string' && /^\*?[a-z0-9_\-]{1,40}\*?$/i.test(t.name)) target = { kind: 'field', name: t.name }
    else return { ok: false, error: `Rule “${id}” has an invalid target` }
    const roles = Array.isArray(raw.roles) ? (raw.roles.filter((r) => r === 'owner' || r === 'staff') as ViewerRole[]) : undefined
    // One id may cover several targets (a route and its record type); the same target twice is a mistake.
    const key = `${id} ${JSON.stringify(target)}`
    if (ids.has(key)) return { ok: false, error: `Rule “${id}” lists the same target twice` }
    ids.add(key)
    const label = typeof raw.label === 'string' && raw.label.trim() ? raw.label.trim().slice(0, 80) : id
    out.push({ id, label, target, level: level as Visibility, ...(roles && roles.length ? { roles } : {}) })
  }
  return { ok: true, rules: out }
}

/**
 * Rules that a change makes LESS strict (removed, or a lower level, or
 * fewer roles covered): the settings screen asks for confirmation on these.
 */
export function loosenedBy(before: readonly VisibilityRule[], after: readonly VisibilityRule[]): string[] {
  const keyOf = (r: VisibilityRule) => `${r.id} ${JSON.stringify(r.target)}`
  const next = new Map(after.map((r) => [keyOf(r), r]))
  const out: string[] = []
  for (const b of before) {
    const a = next.get(keyOf(b))
    if (!a) {
      if (b.level !== 'readable') out.push(b.id)
      continue
    }
    const fewerRoles = (b.roles === undefined && a.roles !== undefined) || (b.roles ?? []).some((r) => a.roles !== undefined && !a.roles.includes(r))
    if (RANK[a.level] < RANK[b.level] || (fewerRoles && b.level !== 'readable')) out.push(b.id)
  }
  return [...new Set(out)]
}
