/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/governance/visibility.assert.ts
 */
import assert from 'node:assert/strict'
import {
  BLOCKED_GUIDANCE,
  blockedResult,
  effectiveRules,
  loosenedBy,
  maskData,
  maskUnit,
  matchField,
  matchRoute,
  metadataOnly,
  resolveEntity,
  resolveField,
  resolveRoute,
  sanitizeRules,
  PRIVATE_VALUE,
  type VisibilityRule,
} from './visibility'
import { PRIVACY_AREAS, VISIBILITY_DEFAULTS, VISIBILITY_FLOOR } from '../../ade-bindings/visibility-rules'
import { areaRules } from './access'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
// What an assistant may see = the floor + site-wide rules + its person's area access (RBAC).
const staffRules = [...effectiveRules(VISIBILITY_FLOOR, VISIBILITY_DEFAULTS), ...areaRules(PRIVACY_AREAS, { permissions: ['orders.view'], overrides: [] }, 'agent')]
const ownerRules = [...effectiveRules(VISIBILITY_FLOOR, VISIBILITY_DEFAULTS), ...areaRules(PRIVACY_AREAS, { permissions: ['*'], overrides: [] }, 'agent')]
const rules = staffRules

check('route globs: * one segment, ** any depth, ?k=v must match too', () => {
  assert.ok(matchRoute('/admin/users/*', '/admin/users/abc'))
  assert.ok(!matchRoute('/admin/users/*', '/admin/users/abc/edit'))
  assert.ok(matchRoute('/admin/users/**', '/admin/users'))
  assert.ok(matchRoute('/admin/users/**', '/admin/users/abc/edit'))
  assert.ok(matchRoute('/handler/**', '/handler/sign-in?after=/admin'))
  assert.ok(matchRoute('/admin/settings?section=mcp', '/admin/settings?section=mcp&x=1'))
  assert.ok(!matchRoute('/admin/settings?section=mcp', '/admin/settings?section=assistant'))
  assert.ok(!matchRoute('/admin/settings?section=mcp', '/admin/settings'))
  assert.ok(matchRoute('/Admin/Users/*', '/admin/users/x#top'))
})

check('the floor is blocked for everyone, owner included', () => {
  for (const role of ['owner', 'staff'] as const) {
    for (const url of ['/admin/settings?section=environment', '/admin/settings?section=storage', '/admin/settings?section=mcp', '/admin/settings?section=personal-data', '/handler/sign-in', '/handler/account-settings']) {
      const r = resolveRoute(rules, url, role)
      assert.equal(r.level, 'blocked', `${url} for ${role}`)
      assert.ok(r.rule?.floor && r.rule.id.startsWith('floor.'))
    }
    assert.equal(resolveEntity(rules, 'apikey', role).level, 'blocked')
    assert.equal(resolveEntity(rules, 'DataRequest', role).level, 'blocked')
  }
  assert.equal(resolveRoute(rules, '/admin/settings?section=assistant', 'staff').level, 'readable')
  assert.equal(resolveRoute(rules, '/admin/pages', 'staff').level, 'readable')
})

check('roles: people screens are metadata-only for staff, readable for the owner', () => {
  assert.equal(resolveRoute(rules, '/admin/users', 'staff').level, 'metadata-only')
  assert.equal(resolveRoute(rules, '/admin/users/cmk8', 'staff').rule?.id, 'area.people')
  assert.equal(resolveRoute(ownerRules, '/admin/users/cmk8', 'owner').level, 'readable')
  assert.equal(resolveEntity(rules, 'user', 'staff').level, 'metadata-only')
  assert.equal(resolveEntity(ownerRules, 'user', 'owner').level, 'readable')
})

check('a looser custom rule can’t undo the floor (strictest wins)', () => {
  const loose: VisibilityRule[] = [{ id: 'custom.open-mcp', label: 'x', target: { kind: 'route', pattern: '/admin/settings?section=mcp' }, level: 'readable' }]
  assert.equal(resolveRoute(effectiveRules(VISIBILITY_FLOOR, loose), '/admin/settings?section=mcp', 'owner').level, 'blocked')
  // A custom rule pretending to be a floor rule is dropped.
  const fake: VisibilityRule[] = [{ id: 'floor.secrets', label: 'x', target: { kind: 'route', pattern: '/admin/**' }, level: 'readable' }]
  assert.equal(effectiveRules(VISIBILITY_FLOOR, fake).filter((r) => !r.floor).length, 0)
  // Tightening works.
  const tight: VisibilityRule[] = [{ id: 'custom.orders', label: 'Orders', target: { kind: 'route', pattern: '/admin/orders/**' }, level: 'blocked' }]
  assert.equal(resolveRoute(effectiveRules(VISIBILITY_FLOOR, tight), '/admin/orders/123', 'owner').level, 'blocked')
})

check('field names: secrets, passwords, payment blocked; contact masked for staff only', () => {
  assert.ok(matchField('*secret', 'webhookSecret') && matchField('*secret', 'client_secret') && matchField('password*', 'passwordHash'))
  assert.ok(!matchField('*token', 'tokensUsed') && matchField('*token', 'accessToken'))
  for (const f of ['apiKey', 'secretKey', 'clientSecret', 'password', 'accessToken', 'keyHash', 'cardNumber', 'smtpPass', 'smtpPassword', 'sendgridApiKey', 'sesAccessKeyId', 'sesSecretAccessKey', 'R2_SECRET_ACCESS_KEY']) assert.equal(resolveField(ownerRules, f, 'owner').level, 'blocked', f)
  assert.equal(resolveField(rules, 'customerEmail', 'staff').level, 'metadata-only')
  assert.equal(resolveField(rules, 'phone', 'staff').rule?.id, 'area.contact')
  assert.equal(resolveField(ownerRules, 'email', 'owner').level, 'readable')
  assert.equal(resolveField(rules, 'title', 'staff').level, 'readable')
  assert.equal(resolveField(rules, 'helpKey', 'staff').level, 'readable')
})

check('tool results: secrets dropped, contact masked, nothing else touched; names reported, never values', () => {
  const order = { id: 'o1', total: 40, customer: { name: 'Ama', email: 'ama@example.org', phone: '+23320000' }, stripeSecretKey: 'sk_live_x', items: [{ title: 'Mug', apiKey: 'k' }] }
  const staff = maskData(order, rules, 'staff')
  assert.deepEqual(staff.data, { id: 'o1', total: 40, customer: { name: 'Ama', email: PRIVATE_VALUE, phone: PRIVATE_VALUE }, items: [{ title: 'Mug' }] })
  assert.deepEqual(staff.report.fields.sort(), ['apiKey', 'email', 'phone', 'stripeSecretKey'])
  assert.ok(staff.report.rules.includes('area.contact') && staff.report.rules.includes('floor.secrets'))
  assert.ok(!JSON.stringify(staff.report).includes('ama@'))
  const owner = maskData(order, ownerRules, 'owner')
  assert.equal((owner.data as typeof order).customer.email, 'ama@example.org')
  assert.equal('stripeSecretKey' in (owner.data as object), false)
  // The input isn't changed.
  assert.equal(order.customer.email, 'ama@example.org')
})

check('view units: metadata-only keeps labels and counts, blocked keeps nothing, data-ade-private masks', () => {
  const table = { label: 'Submissions', role: 'table', rows: [['a'], ['b']], children: [{ label: 'Email', private: 'contact', value: 'x@y.z' }, { label: 'Message', value: 'Hi' }] }
  const meta = maskUnit(table, 'metadata-only', rules, 'staff')
  assert.equal(meta.rowCount, 2)
  assert.equal(meta.rows, undefined)
  assert.equal(meta.children?.[1].value, undefined)
  assert.equal(meta.children?.[1].hasValue, true)
  const readable = maskUnit(table, 'readable', rules, 'staff')
  assert.equal(readable.children?.[0].value, undefined, 'private contact masked for staff')
  assert.equal(readable.children?.[1].value, 'Hi')
  assert.equal(maskUnit(table, 'readable', ownerRules, 'owner').children?.[0].value, 'x@y.z')
  assert.deepEqual(maskUnit({ label: 'API key', private: 'secret', value: 'sk' }, 'readable', ownerRules, 'owner'), { label: 'API key', blocked: true })
  // An unknown marker is still private (metadata-only), never readable.
  assert.equal(maskUnit({ label: 'X', private: 'whatever', value: 'v' }, 'readable', ownerRules, 'owner').value, undefined)
  assert.deepEqual(maskUnit({ label: 'Env', value: 'v' }, 'blocked'), { label: 'Env', blocked: true })
  assert.deepEqual(metadataOnly([{ a: 1, b: 'x' }, { a: 2 }]), { count: 2, each: { a: 'number', b: 'string' } })
})

check('blocked results tell the model to guide, not read', () => {
  const b = blockedResult(VISIBILITY_FLOOR[0], 'Settings › Environment')
  assert.equal(b.blocked, true)
  assert.equal(b.canGuide, true)
  assert.equal(b.reason, 'floor.secrets')
  assert.ok(b.message.includes('is private') && b.message.includes('spotlight'))
})

check('owner edits: validated; the floor can’t be edited; loosening is detected for confirmation', () => {
  const ok = sanitizeRules([{ id: 'custom.orders', label: 'Orders', target: { kind: 'route', pattern: '/admin/orders/**' }, level: 'blocked', roles: ['staff', 'robot'] }], VISIBILITY_FLOOR)
  assert.ok(ok.ok && ok.rules[0].roles?.length === 1)
  assert.ok(!sanitizeRules([{ id: 'floor.secrets', target: { kind: 'route', pattern: '/x' }, level: 'readable' }], VISIBILITY_FLOOR).ok)
  assert.ok(!sanitizeRules([{ id: 'custom.x', target: { kind: 'route', pattern: 'no-slash' }, level: 'blocked' }], VISIBILITY_FLOOR).ok)
  assert.ok(!sanitizeRules([{ id: 'custom.x', target: { kind: 'route', pattern: '/x' }, level: 'open' }], VISIBILITY_FLOOR).ok)
  assert.ok(!sanitizeRules('nope', VISIBILITY_FLOOR).ok)
  // One id may cover several targets.
  const base: VisibilityRule[] = [
    { id: 'custom.people', label: 'People', target: { kind: 'route', pattern: '/admin/users/**' }, level: 'metadata-only', roles: ['staff'] },
    { id: 'custom.people', label: 'People', target: { kind: 'entity', type: 'user' }, level: 'metadata-only', roles: ['staff'] },
    { id: 'custom.notes', label: 'Notes', target: { kind: 'field', name: 'notes' }, level: 'blocked' },
  ]
  assert.ok(sanitizeRules(base as unknown[], VISIBILITY_FLOOR).ok)
  const opened = base.map((r) => (r.id === 'custom.notes' ? { ...r, level: 'readable' as const } : r))
  assert.deepEqual(loosenedBy(base, opened), ['custom.notes'])
  assert.deepEqual(loosenedBy(base, base.filter((r) => r.id !== 'custom.people')), ['custom.people'])
  const everyone = base.map((r) => (r.id === 'custom.people' ? { ...r, roles: undefined } : r))
  assert.deepEqual(loosenedBy(base, everyone), [], 'covering more roles is stricter')
})

check('the guidance covers both refusal shapes (data tools: blocked:true; screen tools: private:true + blocked list)', () => {
  assert.match(BLOCKED_GUIDANCE, /blocked: true/)
  assert.match(BLOCKED_GUIDANCE, /private: true/)
  assert.match(BLOCKED_GUIDANCE, /\[private\]/)
})

check('refusals come from the policy, so they are traced: the guidance says call the tool first, never pre-refuse from memory', () => {
  assert.match(BLOCKED_GUIDANCE, /call the tool \(read_view for a screen\)/)
  assert.match(BLOCKED_GUIDANCE, /even one you believe is private, or one refused earlier/)
  assert.match(BLOCKED_GUIDANCE, /never decline from memory before calling/)
  // It leads the guidance, ahead of how to word a refusal.
  assert.ok(BLOCKED_GUIDANCE.indexOf('call the tool') < BLOCKED_GUIDANCE.indexOf('blocked: true'))
})

console.log(`\n${n} checks passed`)
