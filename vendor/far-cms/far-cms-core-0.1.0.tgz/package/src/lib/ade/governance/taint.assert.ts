/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/governance/taint.assert.ts
 */
import assert from 'node:assert/strict'
import { TAINT_REASON, approvalUnderTaint, callMayTaint, callTaints, createRunTaint, outputIsUntrusted, routeShowsOutsideText, screenRouteOf, withUntrustedSources } from './taint'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const SCREENS = ['/admin/todo', '/admin/orders', '*submissions', '?tab=submissions']

check('a run starts clean, the first source wins, and a seed carries a continuation', () => {
  const t = createRunTaint()
  assert.equal(t.tainted, false)
  t.mark('email_read_thread', 5)
  t.mark('searchOrders', 9)
  assert.deepEqual([t.tainted, t.source, t.at], [true, 'email_read_thread', 5])
  assert.equal(createRunTaint({ source: 'read_view' }).tainted, true)
  assert.equal(TAINT_REASON, 'Approval needed because the assistant read outside text in this conversation')
})

check('what taints: labelled tools, asUntrusted results, unregistered tools, outside-text screens (unknown screen = yes)', () => {
  const q = (o: Partial<Parameters<typeof callTaints>[0]>) => callTaints({ label: undefined, input: {}, output: {}, screenPatterns: SCREENS, ...o })
  assert.equal(q({}), false, 'a plain staff-data read')
  assert.equal(q({ label: true }), true)
  assert.equal(q({ output: { untrusted: true, notice: 'x' } }), true, 'asUntrusted marker, whatever the label')
  assert.equal(q({ unregistered: true }), true, 'vMCP / external MCP output')
  assert.equal(q({ label: (i) => (i as { t?: string }).t === 'order', input: { t: 'order' } }), true)
  assert.equal(q({ label: (i) => (i as { t?: string }).t === 'order', input: { t: 'page' } }), false)
  assert.equal(q({ label: () => { throw new Error('x') } }), true, 'a failing check fails closed')
  assert.equal(q({ label: 'screen', output: { route: '/admin/todo' } }), true)
  assert.equal(q({ label: 'screen', output: { view: { route: '/admin/forms/f1/submissions' } } }), true)
  assert.equal(q({ label: 'screen', output: { route: '/admin/forms/f1?tab=submissions' } }), true)
  assert.equal(q({ label: 'screen', output: { route: '/admin/pages/p1/editor' } }), false)
  assert.equal(q({ label: 'screen', output: { route: '/admin/ordersXYZ' } }), false, 'a prefix is a whole segment')
  assert.equal(q({ label: 'screen', output: {} }), true, 'no route reported → fail closed')
  assert.equal(screenRouteOf(null), null)
  assert.equal(routeShowsOutsideText('/admin/orders/o1', SCREENS), true)
  assert.equal(outputIsUntrusted({ untrusted: 'yes' }), false, 'only a literal true')
})

check('approval: reads stay free; draft / write / irreversible ask once tainted; untainted rules unchanged', () => {
  const clean = createRunTaint()
  const dirty = createRunTaint({ source: 'email_read_thread' })
  assert.equal(approvalUnderTaint('read', false, dirty), false)
  for (const e of ['draft', 'write', 'irreversible'] as const) {
    assert.equal(approvalUnderTaint(e, false, dirty), true, e)
    assert.equal(approvalUnderTaint(e, false, clean), false, e)
    assert.equal(approvalUnderTaint(e, true, clean), true, e)
  }
  assert.equal(approvalUnderTaint('write', false, undefined), false, 'no taint object → old rules')
})

check('same step: a possibly-tainting call holds the step\'s writes until the step ends; BYB\'s provenance marker counts', () => {
  const t = createRunTaint()
  t.markPending('read_view')
  assert.equal(t.pending, true)
  assert.equal(approvalUnderTaint('write', false, t), true)
  assert.equal(approvalUnderTaint('read', false, t), false)
  t.endStep()
  assert.equal(t.pending, false)
  assert.equal(t.tainted, false, 'pending never taints by itself')
  assert.equal(callMayTaint(true, {}), true)
  assert.equal(callMayTaint('screen', {}), true, 'a screen read holds writes until its route is known')
  assert.equal(callMayTaint((i) => (i as { t?: string }).t === 'order', { t: 'page' }), false)
  assert.equal(callMayTaint(undefined, {}), false)
  assert.equal(outputIsUntrusted({ provenance: 'untrusted' }), true, 'BYB marker')
})

check('apps flag their own tools: withUntrustedSources sets untrustedSource without touching the rest, and reports unknown names', () => {
  const reg: Record<string, { effect: string; untrustedSource?: true }> = { readMail: { effect: 'read' }, writePage: { effect: 'write' } }
  const r = withUntrustedSources(reg, { readMail: true, typo_tool: true })
  assert.deepEqual(r.registry.readMail, { effect: 'read', untrustedSource: true })
  assert.equal(r.registry.writePage, reg.writePage, 'untouched entries are the same object')
  assert.deepEqual(r.unknown, ['typo_tool'])
  assert.equal((reg.readMail as { untrustedSource?: unknown }).untrustedSource, undefined, 'the input registry is not mutated')
})

console.log(`\n${n} checks passed`)
