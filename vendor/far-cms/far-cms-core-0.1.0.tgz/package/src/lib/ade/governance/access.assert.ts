/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/governance/access.assert.ts
 */
import assert from 'node:assert/strict'
import {
  agentKey,
  agentWithinUser,
  applyToOverrides,
  applyToRole,
  areaAccess,
  areaRules,
  checkAccessChange,
  describeChange,
  explainAccess,
  personFieldRules,
  guardPrivateWrites,
  holds,
  seeKey,
  type PermissionView,
  type PrivacyArea,
} from './access'
import { effectiveRules, maskData, resolveEntity, resolveField, resolveRoute } from './visibility'
import { PRIVACY_AREAS, VISIBILITY_FLOOR, withAreaSettings } from '../../ade-bindings/visibility-rules'
import { PERMISSION_GROUPS } from '../../permissions/constants'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

type O = PermissionView['overrides'][number]
const person = (permissions: string[], overrides: O[] = []): PermissionView => {
  // Same order as lib/permissions computeEffectivePermissions: roles, minus DENY, plus GRANT.
  const set = new Set(permissions)
  for (const o of overrides) if (o.type === 'DENY') set.delete(o.permission)
  for (const o of overrides) if (o.type === 'GRANT') set.add(o.permission)
  return { permissions: set, overrides }
}
const owner = person(['*'])
const staff = person(['orders.view', 'customers.view'])
const area = (over: Partial<PrivacyArea> = {}): PrivacyArea => ({ id: 'customers', label: 'Customers', what: 'customer records', targets: [{ kind: 'route', pattern: '/admin/customers/**' }, { kind: 'entity', type: 'customer' }], withoutAccess: 'metadata-only', confidential: true, agentByDefault: true, ...over })

check('exceptions beat roles: GRANT gives it, DENY takes it away even from a wildcard role', () => {
  assert.equal(holds(person([]), seeKey('customers')), false)
  assert.equal(holds(person(['privacy.customers.see']), seeKey('customers')), true)
  assert.equal(holds(person(['privacy.*']), seeKey('customers')), true)
  assert.equal(holds(person(['privacy.*'], [{ permission: 'privacy.customers.see', type: 'DENY' }]), seeKey('customers')), false)
  assert.equal(holds(person([], [{ permission: 'privacy.customers.see', type: 'GRANT' }]), seeKey('customers')), true)
  assert.equal(holds(owner, seeKey('customers')), true)
  assert.equal(holds(person(['*'], [{ permission: 'privacy.customers.see', type: 'DENY' }]), seeKey('customers')), false)
})

check('confidential area: key workers (role or exception) see it, others get the outline — and so do their assistants', () => {
  const a = area()
  assert.deepEqual([areaAccess(a, staff).user, areaAccess(a, staff).agent], ['metadata-only', 'metadata-only'])
  const keyWorker = person(['customers.view', 'privacy.customers.see'])
  assert.deepEqual([areaAccess(a, keyWorker).user, areaAccess(a, keyWorker).agent], ['readable', 'readable'])
  const viaException = person(['customers.view'], [{ permission: 'privacy.customers.see', type: 'GRANT' }])
  assert.equal(areaAccess(a, viaException).user, 'readable')
  // Not confidential: everyone who can open the screen sees it.
  assert.equal(areaAccess(area({ confidential: false }), staff).user, 'readable')
})

check('the assistant can be kept out while the person sees it (DENY exception, or areas that need a grant)', () => {
  const keyWorker = person(['privacy.customers.see'], [{ permission: agentKey('customers'), type: 'DENY' }])
  const r = areaAccess(area(), keyWorker)
  assert.deepEqual([r.user, r.agent], ['readable', 'metadata-only'])
  assert.ok(r.why.agent.includes('exception'))
  const optIn = area({ agentByDefault: false, confidential: false })
  assert.equal(areaAccess(optIn, staff).agent, 'metadata-only')
  assert.equal(areaAccess(optIn, person(['privacy.customers.agent'])).agent, 'readable')
  assert.equal(areaAccess(optIn, owner).agent, 'readable')
})

check('INVARIANT: an assistant never sees more than its person (every combination)', () => {
  const keys = ['privacy.customers.see', 'privacy.customers.agent']
  const states: Array<'none' | 'role' | 'GRANT' | 'DENY'> = ['none', 'role', 'GRANT', 'DENY']
  for (const confidential of [true, false])
    for (const agentByDefault of [true, false])
      for (const withoutAccess of ['metadata-only', 'blocked'] as const)
        for (const s1 of states)
          for (const s2 of states)
            for (const wildcard of [[], ['privacy.*'], ['*']]) {
              const roles: string[] = [...wildcard]
              const overrides: O[] = []
              ;[s1, s2].forEach((s, i) => {
                if (s === 'role') roles.push(keys[i])
                if (s === 'GRANT' || s === 'DENY') overrides.push({ permission: keys[i], type: s })
              })
              const r = areaAccess(area({ confidential, agentByDefault, withoutAccess }), person(roles, overrides))
              assert.ok(agentWithinUser(r), JSON.stringify({ confidential, agentByDefault, s1, s2, wildcard, r }))
            }
})

check('areas become route / entity / field rules for resolution', () => {
  const rules = areaRules([area()], staff, 'agent')
  assert.equal(resolveRoute(rules, '/admin/customers/abc', 'staff').level, 'metadata-only')
  assert.equal(resolveRoute(rules, '/admin/customers/abc', 'staff').rule?.id, 'area.customers')
  assert.equal(resolveEntity(rules, 'customer', 'staff').level, 'metadata-only')
  assert.equal(resolveRoute(rules, '/admin/orders', 'staff').level, 'readable')
  assert.ok(areaRules([area()], owner, 'agent').every((r) => r.level === 'readable'))
  // Dzidzor's contact area: staff assistants get emails masked, the owner's doesn't.
  const dz = PRIVACY_AREAS
  assert.equal(resolveField(areaRules(dz, staff, 'agent'), 'customerEmail', 'staff').level, 'metadata-only')
  assert.equal(resolveField(areaRules(dz, staff, 'user'), 'customerEmail', 'staff').level, 'readable', 'people still see emails (not confidential)')
  assert.equal(resolveField(areaRules(dz, owner, 'agent'), 'customerEmail', 'owner').level, 'readable')
})

check('the floor stays absolute: no grant opens it, for anyone', () => {
  const everything = person(['*', 'privacy.*'], PRIVACY_AREAS.flatMap((a) => [{ permission: seeKey(a.id), type: 'GRANT' as const }, { permission: agentKey(a.id), type: 'GRANT' as const }]))
  const rules = [...effectiveRules(VISIBILITY_FLOOR, []), ...areaRules(PRIVACY_AREAS, everything, 'agent')]
  for (const url of ['/admin/settings?section=environment', '/admin/settings?section=mcp', '/handler/sign-in', '/admin/settings?section=personal-data']) assert.equal(resolveRoute(rules, url, 'owner').level, 'blocked')
  assert.equal(resolveField(rules, 'apiKey', 'owner').level, 'blocked')
})

check('owner switches apply on top of the area defaults', () => {
  const areas = withAreaSettings(PRIVACY_AREAS, { customers: { confidential: true }, contact: { agentByDefault: true }, junk: { confidential: true } })
  assert.equal(areas.find((a) => a.id === 'customers')?.confidential, true)
  assert.equal(areas.find((a) => a.id === 'contact')?.agentByDefault, true)
  assert.equal(areas.length, PRIVACY_AREAS.length)
})

check('explain_access in plain words', () => {
  const lines = explainAccess([area()], person(['privacy.customers.see'], [{ permission: agentKey('customers'), type: 'DENY' }]), 'Ama')
  assert.ok(lines[0].startsWith('Customers: Ama can see customer records'))
  assert.ok(lines[0].includes('Their assistant sees only an outline of customer records'))
  assert.ok(lines[1].includes('Never visible to any assistant'))
})

check('draft_access_change: only privacy keys of known areas; applied to exceptions or role lists', () => {
  const areas = [area()]
  assert.ok(!checkAccessChange(areas, { grant: ['users.delete'] }).ok)
  assert.ok(!checkAccessChange(areas, { grant: ['privacy.secrets.see'] }).ok)
  assert.ok(!checkAccessChange(areas, {}).ok)
  assert.ok(!checkAccessChange(areas, { grant: ['privacy.customers.see'], deny: ['privacy.customers.see'] }).ok)
  const c = checkAccessChange(areas, { grant: ['privacy.customers.see'], deny: ['privacy.customers.agent'] })
  assert.ok(c.ok)
  if (!c.ok) return
  assert.deepEqual(applyToOverrides([{ permission: 'privacy.customers.see', type: 'DENY' }, { permission: 'orders.view', type: 'GRANT' }], c.change), [
    { permission: 'orders.view', type: 'GRANT' },
    { permission: 'privacy.customers.see', type: 'GRANT' },
    { permission: 'privacy.customers.agent', type: 'DENY' },
  ])
  assert.deepEqual(applyToRole(['orders.view', 'privacy.customers.agent'], c.change), ['orders.view', 'privacy.customers.see'])
  assert.deepEqual(describeChange(areas, c.change), ['Allow: see customer records', 'Don’t allow: let their assistant read customer records'])
})

check('a person’s own screens: confidential areas mask their record fields; key workers see them', () => {
  const areas = withAreaSettings(PRIVACY_AREAS, { customers: { confidential: true } })
  const customer = { id: 'c1', name: 'Ama Owusu', email: 'ama@x.org', phone: '+233', totalOrders: 3, address1: 'Accra' }
  const rules = personFieldRules(areas, staff, ['customers', 'contact'])
  assert.deepEqual(maskData(customer, rules, 'staff').data, { id: 'c1', name: '[private]', email: '[private]', phone: '[private]', totalOrders: 3, address1: '[private]' })
  const keyWorker = person(['customers.view', 'privacy.customers.see'])
  // Contact isn't confidential here, so a key worker sees everything.
  assert.deepEqual(personFieldRules(areas, keyWorker, ['customers', 'contact']), [])
  // Not confidential (the default): nothing is masked for anyone.
  assert.deepEqual(personFieldRules(PRIVACY_AREAS, staff, ['customers', 'contact']), [])
})

check('edits: the mask is never saved; without access, private fields are ignored', () => {
  const areas = withAreaSettings(PRIVACY_AREAS, { customers: { confidential: true } })
  const form = { firstName: '[private]', phone: '+1 555', company: 'Acme', notes: 'call back', tags: ['vip'] }
  const staffWrite = guardPrivateWrites(form, areas, staff, ['customers', 'contact'])
  assert.deepEqual(staffWrite.body, { tags: ['vip'] })
  assert.deepEqual(staffWrite.ignored.sort(), ['company', 'firstName', 'notes', 'phone'])
  const keyWorker = person(['privacy.customers.see'])
  const kw = guardPrivateWrites(form, areas, keyWorker, ['customers', 'contact'])
  assert.deepEqual(kw.body, { phone: '+1 555', company: 'Acme', notes: 'call back', tags: ['vip'] })
  assert.deepEqual(kw.ignored, ['firstName'], 'the mask itself is never saved, even by someone with access')
  // Open area (the default): only the mask is dropped.
  assert.deepEqual(guardPrivateWrites({ notes: '[private]', company: 'B' }, PRIVACY_AREAS, staff, ['customers']).body, { company: 'B' })
})

check('every area’s permissions are in the RBAC catalog (roles and exceptions can grant them)', () => {
  const catalog = new Set(PERMISSION_GROUPS.privacy.permissions.map((p) => p.key as string))
  for (const a of PRIVACY_AREAS) {
    assert.ok(catalog.has(seeKey(a.id)), seeKey(a.id))
    assert.ok(catalog.has(agentKey(a.id)), agentKey(a.id))
  }
  assert.equal(catalog.size, PRIVACY_AREAS.length * 2)
})

console.log(`\n${n} checks passed`)
