/**
 * Who may see private areas — people and their assistants — expressed as
 * ordinary RBAC permissions, so roles grant them and per-person exceptions
 * (overrides) allow or deny them like any other permission.
 *
 * For each protected area (customer contact details, admin people, …):
 *
 *   privacy.<area>.see    the person can see the area's private details.
 *                         Needed only while the area is CONFIDENTIAL; then
 *                         people without it see the area masked or blocked
 *                         — and so does their assistant.
 *   privacy.<area>.agent  their assistant may read the area for them.
 *                         Needed when the area keeps the assistant out by
 *                         default (agentByDefault: false); otherwise only an
 *                         explicit DENY exception removes it.
 *
 * INVARIANT: the assistant never sees more than its person —
 * agentLevel is always at least as strict as userLevel (agentWithinUser).
 * The floor (lib/ade/governance/visibility) stays absolute on top.
 *
 * Host-agnostic: the host supplies the areas. Pure; asserted by access.assert.ts.
 */

import { matchField, PRIVATE_VALUE, type RuleTarget, type Visibility, type VisibilityRule } from './visibility'

export interface PrivacyArea {
  id: string
  label: string
  /** "Customer emails and phone numbers" — what is private here, in plain words. */
  what: string
  targets: readonly RuleTarget[]
  /** What someone without access gets. */
  withoutAccess: Exclude<Visibility, 'readable'>
  /** People need privacy.<area>.see (owner-switchable). */
  confidential: boolean
  /** Assistants read it without privacy.<area>.agent (a DENY exception still removes it). */
  agentByDefault: boolean
  /**
   * The values that are private in this area's records (e.g. name, email,
   * address on a customer). Masked in what the admin's own screens and APIs
   * return to someone without access; the area's field targets always are.
   */
  fields?: readonly string[]
}

/** The parts of a person's RBAC state the rules need (mirrors lib/permissions). */
export interface PermissionView {
  /** Effective permissions: roles' permissions, minus DENY, plus GRANT exceptions. */
  permissions: ReadonlySet<string> | readonly string[]
  overrides: ReadonlyArray<{ permission: string; type: 'GRANT' | 'DENY' }>
}

export const seeKey = (area: string) => `privacy.${area}.see`
export const agentKey = (area: string) => `privacy.${area}.agent`

const RANK: Record<Visibility, number> = { readable: 0, 'metadata-only': 1, blocked: 2 }
const stricter = (a: Visibility, b: Visibility): Visibility => (RANK[a] >= RANK[b] ? a : b)

function matches(held: string, key: string): boolean {
  if (held === key || held === '*') return true
  return held.endsWith('.*') && key.startsWith(held.slice(0, -1))
}

/**
 * Does the person hold `key`? Exceptions win over roles: an explicit GRANT
 * holds, an explicit DENY doesn't — even when a role grants it through a
 * wildcard (lib/permissions only removes the exact key on DENY).
 */
export function holds(p: PermissionView, key: string): boolean {
  const own = p.overrides.filter((o) => o.permission === key)
  if (own.some((o) => o.type === 'GRANT')) return true
  if (own.some((o) => o.type === 'DENY')) return false
  for (const held of p.permissions) if (matches(held, key)) return true
  return false
}

export function isExplicitlyDenied(p: PermissionView, key: string): boolean {
  const own = p.overrides.filter((o) => o.permission === key)
  return own.some((o) => o.type === 'DENY') && !own.some((o) => o.type === 'GRANT')
}

export interface AreaAccess {
  area: string
  user: Visibility
  agent: Visibility
  /** Plain-language reasons, for explain_access and the UI. */
  why: { user: string; agent: string }
}

export function areaAccess(area: PrivacyArea, p: PermissionView): AreaAccess {
  const canSee = !area.confidential || holds(p, seeKey(area.id))
  const user: Visibility = canSee ? 'readable' : area.withoutAccess
  const agentAllowed = area.agentByDefault ? !isExplicitlyDenied(p, agentKey(area.id)) : holds(p, agentKey(area.id))
  // The assistant can never see more than its person.
  const agent = stricter(user, agentAllowed ? 'readable' : area.withoutAccess)
  const userWhy = !area.confidential
    ? 'not confidential — everyone who can open the screen sees it'
    : canSee
      ? 'allowed (role or exception)'
      : 'confidential, and they don’t have access'
  const agentWhy =
    agent === 'readable'
      ? area.agentByDefault
        ? 'follows the person'
        : 'allowed for their assistant'
      : user !== 'readable'
        ? 'their assistant can’t see more than they can'
        : area.agentByDefault
          ? 'turned off for their assistant (exception)'
          : 'assistants are kept out unless allowed'
  return { area: area.id, user, agent, why: { user: userWhy, agent: agentWhy } }
}

export function agentWithinUser(a: Pick<AreaAccess, 'user' | 'agent'>): boolean {
  return RANK[a.agent] >= RANK[a.user]
}

/**
 * The person's (or their assistant's) area access as visibility rules.
 * Readable areas are included too (they never loosen anything — the
 * strictest rule wins) so their fields count as known private markers.
 */
export function areaRules(areas: readonly PrivacyArea[], p: PermissionView, who: 'user' | 'agent'): VisibilityRule[] {
  const out: VisibilityRule[] = []
  for (const a of areas) {
    const level = areaAccess(a, p)[who]
    for (const target of a.targets) out.push({ id: `area.${a.id}`, label: a.label, target, level })
  }
  return out
}

/**
 * Field rules for masking what a PERSON's own screens get (admin APIs),
 * for the areas a response belongs to: their fields and field targets,
 * at the person's level. Readable areas add nothing.
 */
export function personFieldRules(areas: readonly PrivacyArea[], p: PermissionView, areaIds: readonly string[]): VisibilityRule[] {
  const out: VisibilityRule[] = []
  for (const a of areas) {
    if (!areaIds.includes(a.id)) continue
    const level = areaAccess(a, p).user
    if (level === 'readable') continue
    const names = [...(a.fields ?? []), ...a.targets.flatMap((t) => (t.kind === 'field' ? [t.name] : []))]
    for (const name of names) out.push({ id: `area.${a.id}`, label: a.label, target: { kind: 'field', name }, level: 'metadata-only' })
  }
  return out
}

/**
 * A write from someone's edit form, made safe: any value that is the mask
 * itself ("[private]") is never saved, and in confidential areas the person
 * lacks, their writes to the private fields are ignored (they could only
 * have seen the mask). Returns what was dropped, by name.
 */
export function guardPrivateWrites<T extends Record<string, unknown>>(
  body: T,
  areas: readonly PrivacyArea[],
  p: PermissionView,
  areaIds: readonly string[]
): { body: Partial<T>; ignored: string[] } {
  const names = personFieldRules(areas, p, areaIds).flatMap((r) => (r.target.kind === 'field' ? [r.target.name] : []))
  const out: Record<string, unknown> = {}
  const ignored: string[] = []
  for (const [k, v] of Object.entries(body)) {
    if (v === PRIVATE_VALUE || names.some((n) => matchField(n, k))) ignored.push(k)
    else out[k] = v
  }
  return { body: out as Partial<T>, ignored }
}

const LEVEL_WORDS: Record<Visibility, string> = { readable: 'can see', 'metadata-only': 'sees only an outline of', blocked: 'can’t see' }

/** Plain words for explain_access: what this person and their assistant can see. */
export function explainAccess(areas: readonly PrivacyArea[], p: PermissionView, subject: string): string[] {
  const lines: string[] = []
  for (const a of areas) {
    const r = areaAccess(a, p)
    const person = `${subject} ${LEVEL_WORDS[r.user]} ${a.what} (${r.why.user}).`
    const helper =
      r.agent === r.user ? `Their assistant: the same.` : `Their assistant ${LEVEL_WORDS[r.agent]} ${a.what} (${r.why.agent}).`
    lines.push(`${a.label}: ${person} ${helper}`)
  }
  lines.push('Never visible to any assistant: passwords, keys and secrets, payment details, sign-in screens, MCP keys, personal-data requests.')
  return lines
}

// ── Proposed changes (draft_access_change) ───────────────────────────

export interface AccessChange {
  /** Permission keys to grant / deny as exceptions (users) or add / remove (roles). */
  grant?: string[]
  deny?: string[]
  /** Remove an exception (users) — back to what the role gives. */
  clear?: string[]
}

export type ChangeCheck = { ok: true; change: Required<AccessChange> } | { ok: false; error: string }

/** Only privacy.<known area>.see|agent keys may be changed by the assistant. */
export function checkAccessChange(areas: readonly PrivacyArea[], input: unknown): ChangeCheck {
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>
  const ids = new Set(areas.map((a) => a.id))
  const list = (k: string): string[] | string => {
    const v = i[k]
    if (v === undefined) return []
    if (!Array.isArray(v) || v.some((x) => typeof x !== 'string')) return `${k} must be a list of permission keys`
    for (const key of v as string[]) {
      const m = /^privacy\.([a-z0-9-]+)\.(see|agent)$/.exec(key)
      if (!m || !ids.has(m[1])) return `“${key}” isn’t an access setting the assistant can change`
    }
    return [...new Set(v as string[])]
  }
  const grant = list('grant')
  const deny = list('deny')
  const clear = list('clear')
  for (const x of [grant, deny, clear]) if (typeof x === 'string') return { ok: false, error: x }
  const g = grant as string[]
  const d = deny as string[]
  const c = clear as string[]
  if (!g.length && !d.length && !c.length) return { ok: false, error: 'Nothing to change' }
  if (g.some((k) => d.includes(k))) return { ok: false, error: 'The same setting can’t be granted and denied' }
  return { ok: true, change: { grant: g, deny: d, clear: c } }
}

/** A person's exceptions after a change (pure; the adapter writes them). */
export function applyToOverrides(
  overrides: ReadonlyArray<{ permission: string; type: 'GRANT' | 'DENY' }>,
  change: Required<AccessChange>
): Array<{ permission: string; type: 'GRANT' | 'DENY' }> {
  const touched = new Set([...change.grant, ...change.deny, ...change.clear])
  const kept = overrides.filter((o) => !touched.has(o.permission))
  return [...kept, ...change.grant.map((permission) => ({ permission, type: 'GRANT' as const })), ...change.deny.map((permission) => ({ permission, type: 'DENY' as const }))]
}

/** A role's permission list after a change (grant adds, deny/clear remove). */
export function applyToRole(permissions: readonly string[], change: Required<AccessChange>): string[] {
  const remove = new Set([...change.deny, ...change.clear])
  return [...new Set([...permissions.filter((p) => !remove.has(p)), ...change.grant])]
}

/** Plain words for the review card: "Allow: … Deny: …". */
export function describeChange(areas: readonly PrivacyArea[], change: Required<AccessChange>): string[] {
  const name = (key: string) => {
    const [, id, kind] = key.split('.')
    const a = areas.find((x) => x.id === id)
    return kind === 'see' ? `see ${a?.what ?? id}` : `let their assistant read ${a?.what ?? id}`
  }
  return [
    ...change.grant.map((k) => `Allow: ${name(k)}`),
    ...change.deny.map((k) => `Don’t allow: ${name(k)}`),
    ...change.clear.map((k) => `Back to the role’s setting: ${name(k)}`),
  ]
}
