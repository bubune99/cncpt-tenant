/**
 * Changes whose target was deleted since they were drafted (a page, a record,
 * a form) can't be approved: they go to To-do with Discard, and stay out of the
 * Review deck and its badge. Checks: orphan-review.assert.ts.
 */

const OPEN = new Set(['pending', 'saved'])
const isOpen = (status: string) => OPEN.has(status)

/** Every still-open item edits something that no longer exists. */
export function onlyRemovedTargets(items: ReadonlyArray<{ status: string; targetRemoved: boolean }>): boolean {
  const open = items.filter((i) => isOpen(i.status))
  return open.length > 0 && open.every((i) => i.targetRemoved)
}

/** The items a reviewer can act on: open items whose target is gone are left out. */
export function reviewableItems<T extends { status: string; targetRemoved: boolean }>(items: readonly T[]): T[] {
  return items.filter((i) => !(isOpen(i.status) && i.targetRemoved))
}
