/**
 * Run: node_modules/.bin/tsx src/lib/ade/todo/orphan-review.assert.ts
 * A change whose page / record / form was deleted can't be approved. It belongs in
 * To-do with Discard, never in the Review deck or its badge (staging 2026-11-22: a
 * deleted SAMPLE form's card stayed in Review with Approve greyed and no way out).
 */
import assert from 'node:assert/strict'
import { onlyRemovedTargets, reviewableItems } from './orphan-review'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const it = (status: string, targetRemoved: boolean) => ({ status, targetRemoved })

check('every open item edits something deleted: only removed targets', () => {
  assert.equal(onlyRemovedTargets([it('pending', true)]), true)
  assert.equal(onlyRemovedTargets([it('pending', true), it('approved', false)]), true, 'decided items do not count')
})
check('one open item still has its target: still reviewable', () => {
  assert.equal(onlyRemovedTargets([it('pending', true), it('pending', false)]), false)
})
check('nothing open: not an orphan set (it is settled, handled elsewhere)', () => {
  assert.equal(onlyRemovedTargets([it('approved', false)]), false)
  assert.equal(onlyRemovedTargets([]), false)
})
check('saved drafts count as open', () => {
  assert.equal(onlyRemovedTargets([it('saved', true)]), true)
})
check('reviewableItems drops only open items whose target is gone', () => {
  const rows = [{ id: 'a', status: 'pending', targetRemoved: true }, { id: 'b', status: 'pending', targetRemoved: false }, { id: 'c', status: 'approved', targetRemoved: true }]
  assert.deepEqual(reviewableItems(rows).map((r) => r.id), ['b', 'c'])
})
console.log(`\n${n} checks passed`)
