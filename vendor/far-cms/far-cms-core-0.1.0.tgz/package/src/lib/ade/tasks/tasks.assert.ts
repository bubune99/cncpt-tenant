/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/tasks/tasks.assert.ts
 * What generate.ts promises: real signals → roll-up tasks with stable
 * dedupe keys, a new signal reopens, stale threshold, priorities, auto-resolve,
 * per-permission visibility.
 */
import assert from 'node:assert/strict'
import { generateTasks, tasksToResolve, visibleTo, type TaskSignals } from './generate'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const NOW = new Date('2026-10-11T12:00:00Z')
const days = (d: number) => new Date(NOW.getTime() - d * 86_400_000)
const empty: TaskSignals = { pendingChangeSets: [], unreadSubmissions: [], staleDrafts: [], brokenMedia: [], failedJobs: [] }
const gen = (s: Partial<TaskSignals>, staleDraftDays = 14) => generateTasks({ ...empty, ...s }, { now: NOW, staleDraftDays })

check('no signals, no tasks; zero counts never make a task', () => {
  assert.deepEqual(gen({}), [])
  assert.deepEqual(gen({ pendingChangeSets: [{ id: 'cs', title: 'X', itemCount: 0, oldestAt: NOW }], unreadSubmissions: [{ formId: 'f', formName: 'F', count: 0, newestId: 's' }] }), [])
})

check('roll-ups, not one task per row: 12 unread submissions to one form = ONE task; one task per change set', () => {
  const t = gen({ unreadSubmissions: [{ formId: 'f1', formName: 'Volunteer', count: 12, newestId: 's12' }], pendingChangeSets: [{ id: 'cs1', title: 'Home edits', itemCount: 5, oldestAt: NOW }] })
  assert.equal(t.length, 2)
  assert.equal(t.find((x) => x.source === 'form-submissions')!.title, 'Read 12 new submissions to “Volunteer”')
  assert.equal(t.find((x) => x.source === 'pending-changes')!.title, 'Review 5 agent changes: Home edits')
})

check('dedupe keys are stable across regenerations; a NEW submission reopens (key changes)', () => {
  const a = gen({ unreadSubmissions: [{ formId: 'f1', formName: 'V', count: 2, newestId: 's2' }] })[0]
  const b = gen({ unreadSubmissions: [{ formId: 'f1', formName: 'V', count: 2, newestId: 's2' }] })[0]
  assert.equal(a.dedupeKey, b.dedupeKey)
  const c = gen({ unreadSubmissions: [{ formId: 'f1', formName: 'V', count: 3, newestId: 's3' }] })[0]
  assert.notEqual(c.dedupeKey, a.dedupeKey, 'yesterday’s ticked-off task does not hide today’s new submission')
  // Records: stable per record even as the wording changes.
  const r1 = gen({ recordsToPublish: [{ type: 'initiative', id: 'r1', title: 'Clean water', left: 3 }] })[0]
  const r2 = gen({ recordsToPublish: [{ type: 'initiative', id: 'r1', title: 'Clean water', left: 1 }] })[0]
  assert.equal(r1.dedupeKey, r2.dedupeKey)
  assert.notEqual(r1.title, r2.title)
})

check('stale drafts: only at or past the threshold; page vs post links and permissions', () => {
  const t = gen({ staleDrafts: [{ kind: 'page', id: 'p1', title: 'About', updatedAt: days(14) }, { kind: 'blog-post', id: 'b1', title: 'News', updatedAt: days(30) }, { kind: 'page', id: 'p2', title: 'Fresh', updatedAt: days(13) }] })
  assert.deepEqual(t.map((x) => x.targetId).sort(), ['b1', 'p1'])
  assert.equal(t.find((x) => x.targetId === 'p1')!.href, '/admin/pages/p1')
  assert.equal(t.find((x) => x.targetId === 'b1')!.permission, 'blog.edit')
  assert.equal(t.find((x) => x.targetId === 'b1')!.detail, 'Untouched for 30 days.')
})

check('priorities: unread mail first; a change set waiting 2+ days rises to 1; drafts last; sorted by priority then title', () => {
  const t = gen({
    pendingChangeSets: [{ id: 'old', title: 'B old', itemCount: 1, oldestAt: days(3) }, { id: 'new', title: 'A new', itemCount: 1, oldestAt: NOW }],
    unreadSubmissions: [{ formId: 'f', formName: 'F', count: 1, newestId: 's' }],
    staleDrafts: [{ kind: 'page', id: 'p', title: 'P', updatedAt: days(40) }],
    failedJobs: [{ id: 'j', name: 'Nightly', at: NOW, error: 'x'.repeat(400) }],
  })
  // Within a priority, by title ("Check…" < "Read…" < "Review…").
  assert.deepEqual(t.map((x) => [x.priority, x.targetId]), [[1, 'f'], [1, 'old'], [2, 'j'], [2, 'new'], [3, 'p']])
  assert.equal(t.find((x) => x.targetId === 'old')!.detail, 'Waiting 3 days.')
  assert.equal(t.find((x) => x.targetId === 'j')!.detail!.length, 280, 'error text capped')
})

check('auto-resolve: an open task whose signal is gone closes itself; live ones stay', () => {
  const drafts = gen({ brokenMedia: [{ id: 'm1', filename: 'a.jpg', reason: '404' }] })
  assert.deepEqual(tasksToResolve(['broken-media:m1', 'broken-media:m2', 'stale-drafts:page:p9'], drafts), ['broken-media:m2', 'stale-drafts:page:p9'])
})

check('visibility: a task shows only to people holding its permission (or no permission needed)', () => {
  const t = gen({ unreadSubmissions: [{ formId: 'f', formName: 'F', count: 1, newestId: 's' }], staleDrafts: [{ kind: 'page', id: 'p', title: 'P', updatedAt: days(20) }] })
  const editorOnly = visibleTo(t, (p) => p === 'pages.edit')
  assert.deepEqual(editorOnly.map((x) => x.source), ['stale-drafts'])
  assert.equal(visibleTo([{ permission: null as string | null }], () => false).length, 1)
})

check('undelivered client feedback: one task per item, feedback admins only, screen + reason (never the note), closes once delivered', () => {
  const t = gen({ undeliveredFeedback: [{ id: 'fb1', screen: 'Initiatives', reason: 'Email is not set up' }] })
  assert.equal(t.length, 1)
  assert.deepEqual([t[0].source, t[0].targetType, t[0].targetId, t[0].permission, t[0].dedupeKey], ['feedback-undelivered', 'client-feedback', 'fb1', 'settings.general', 'feedback-undelivered:fb1'])
  assert.equal(t[0].title, 'Feedback not delivered: “Initiatives”')
  assert.match(t[0].detail ?? '', /Try again/)
  assert.equal(gen({ undeliveredFeedback: [{ id: 'fb2', screen: '', reason: null }] })[0].title, 'Feedback not delivered')
  assert.deepEqual(tasksToResolve(['feedback-undelivered:fb1'], gen({})), ['feedback-undelivered:fb1'], 'delivered → closes itself')
})

check('feedback not set up: ONE owner task for the whole backlog, links to the setup steps, gone once nothing waits', () => {
  const t = gen({ feedbackNotSetUp: { waiting: 2, missing: ['planner', 'email'] } })
  assert.equal(t.length, 1)
  assert.deepEqual([t[0].source, t[0].dedupeKey, t[0].permission, t[0].href], ['feedback-not-set-up', 'feedback-not-set-up', 'settings.general', '/admin/todo/feedback#setup'])
  assert.equal(t[0].title, 'Client feedback isn’t being forwarded yet (2 waiting) — set up the planner and email')
  assert.equal(t[0].detail, '2 items waiting.')
  assert.equal(gen({ feedbackNotSetUp: { waiting: 1, missing: ['email'] } })[0].title, 'Client feedback isn’t being forwarded yet (1 waiting) — set up email')
  // Set up but the backlog hasn't gone yet: still one task, saying it goes next run.
  assert.match(gen({ feedbackNotSetUp: { waiting: 3, missing: [] } })[0].detail ?? '', /next hourly run/)
  assert.equal(gen({ feedbackNotSetUp: { waiting: 0, missing: ['planner'] } }).length, 0)
  assert.deepEqual(tasksToResolve(['feedback-not-set-up'], gen({ feedbackNotSetUp: { waiting: 0, missing: [] } })), ['feedback-not-set-up'])
})

console.log(`\n${n} checks passed`)
