/**
 * Daily task list v0 — pure generator, asserted by tasks.assert.ts.
 *
 * Turns real signals (fetched by the host app) into task drafts. Each draft
 * has a stable dedupeKey so regenerating updates tasks instead of piling up
 * duplicates; the key changes when the underlying signal does (a NEW unread
 * submission reopens the form task even if yesterday's was ticked off).
 */

/** Built-in task sources; an app may add its own (e.g. BYB's 'orders-to-fulfil') without a cast. */
export type BuiltInTaskSource = 'pending-changes' | 'form-submissions' | 'stale-drafts' | 'broken-media' | 'failed-jobs' | 'record-ready' | 'feedback-undelivered' | 'feedback-not-set-up'
export type TaskSource = BuiltInTaskSource | (string & {})

export interface TaskSignals {
  pendingChangeSets: Array<{ id: string; title: string; itemCount: number; oldestAt: Date }>
  unreadSubmissions: Array<{ formId: string; formName: string; count: number; newestId: string }>
  staleDrafts: Array<{ kind: 'page' | 'blog-post'; id: string; title: string; updatedAt: Date }>
  brokenMedia: Array<{ id: string; filename: string; reason: string }>
  failedJobs: Array<{ id: string; name: string; at: Date; error: string | null }>
  /** Draft records and how many required checklist items are left (records). */
  recordsToPublish?: Array<{ type: string; id: string; title: string; left: number }>
  /** Client feedback whose forwarding to the owner failed (lib/ade-bindings/feedback-channels): screen name + safe reason only, never the note. */
  undeliveredFeedback?: Array<{ id: string; screen: string; reason: string | null }>
  /** Client feedback held because forwarding isn't set up: how many wait, and which channels are missing. */
  feedbackNotSetUp?: { waiting: number; missing: ReadonlyArray<'planner' | 'email'> }
}

/** Where the owner finds the forwarding setup steps (the Client feedback list). */
export const FEEDBACK_SETUP_HREF = '/admin/todo/feedback#setup'

export interface TaskDraft {
  source: TaskSource
  title: string
  detail: string | null
  href: string
  targetType: string | null
  targetId: string | null
  dedupeKey: string
  /** 1 = do first … 3 = when you can */
  priority: 1 | 2 | 3
  /** Permission that makes the task relevant to a user (any one). */
  permission: string
}

export interface GenerateOptions {
  now: Date
  /** Drafts untouched this many days count as stale. */
  staleDraftDays: number
}

const DAY_MS = 86_400_000

function plural(n: number, one: string, many = `${one}s`): string {
  return `${n} ${n === 1 ? one : many}`
}

function daysBetween(a: Date, b: Date): number {
  return Math.floor((b.getTime() - a.getTime()) / DAY_MS)
}

export function generateTasks(signals: TaskSignals, opts: GenerateOptions): TaskDraft[] {
  const tasks: TaskDraft[] = []

  for (const cs of signals.pendingChangeSets) {
    if (cs.itemCount <= 0) continue
    const age = daysBetween(cs.oldestAt, opts.now)
    tasks.push({
      source: 'pending-changes',
      title: `Review ${plural(cs.itemCount, 'agent change')}: ${cs.title}`,
      detail: age >= 1 ? `Waiting ${plural(age, 'day')}.` : 'Proposed today.',
      href: `/admin/todo?view=all&item=${encodeURIComponent(cs.id)}`,
      targetType: 'change-set',
      targetId: cs.id,
      dedupeKey: `pending-changes:${cs.id}`,
      priority: age >= 2 ? 1 : 2,
      permission: 'pages.edit',
    })
  }

  for (const f of signals.unreadSubmissions) {
    if (f.count <= 0) continue
    tasks.push({
      source: 'form-submissions',
      title: `Read ${plural(f.count, 'new submission')} to “${f.formName}”`,
      detail: null,
      href: `/admin/forms/${encodeURIComponent(f.formId)}`,
      targetType: 'form',
      targetId: f.formId,
      dedupeKey: `form-submissions:${f.formId}:${f.newestId}`,
      priority: 1,
      permission: 'forms.submissions',
    })
  }

  for (const d of signals.staleDrafts) {
    const age = daysBetween(d.updatedAt, opts.now)
    if (age < opts.staleDraftDays) continue
    const isPage = d.kind === 'page'
    tasks.push({
      source: 'stale-drafts',
      title: `Finish or archive the draft ${isPage ? 'page' : 'post'} “${d.title}”`,
      detail: `Untouched for ${plural(age, 'day')}.`,
      href: isPage ? `/admin/pages/${encodeURIComponent(d.id)}` : `/admin/blog/${encodeURIComponent(d.id)}`,
      targetType: d.kind,
      targetId: d.id,
      dedupeKey: `stale-drafts:${d.kind}:${d.id}`,
      priority: 3,
      permission: isPage ? 'pages.edit' : 'blog.edit',
    })
  }

  for (const m of signals.brokenMedia) {
    tasks.push({
      source: 'broken-media',
      title: `Fix the broken image “${m.filename}”`,
      detail: m.reason,
      href: `/admin/media?focus=${encodeURIComponent(m.id)}`,
      targetType: 'media',
      targetId: m.id,
      dedupeKey: `broken-media:${m.id}`,
      priority: 2,
      permission: 'media.upload',
    })
  }

  for (const j of signals.failedJobs) {
    tasks.push({
      source: 'failed-jobs',
      title: `Check the failed run of “${j.name}”`,
      detail: j.error ? j.error.slice(0, 280) : null,
      href: '/admin/workflows',
      targetType: 'workflow-execution',
      targetId: j.id,
      dedupeKey: `failed-jobs:${j.id}`,
      priority: 2,
      permission: 'workflows.view',
    })
  }

  for (const r of signals.recordsToPublish ?? []) {
    tasks.push({
      source: 'record-ready',
      title: `Ready to publish: ${r.title} — ${r.left === 0 ? 'all set' : plural(r.left, 'item')} left`.replace('all set left', 'all set'),
      detail: r.left <= 1 ? 'Review the page in preview, then publish.' : null,
      href: `/admin/records/${encodeURIComponent(r.type)}/${encodeURIComponent(r.id)}?details=1&tab=ready`,
      targetType: 'record',
      targetId: r.id,
      // Stable per record: the wording updates as items get done.
      dedupeKey: `record-ready:${r.id}`,
      priority: 3,
      permission: 'pages.edit',
    })
  }

  for (const f of signals.undeliveredFeedback ?? []) {
    tasks.push({
      source: 'feedback-undelivered',
      title: f.screen ? `Feedback not delivered: “${f.screen}”` : 'Feedback not delivered',
      detail: f.reason ? `${f.reason.slice(0, 200)} — use Try again.` : 'It is saved; use Try again.',
      href: '/admin/todo?view=all',
      targetType: 'client-feedback',
      targetId: f.id,
      // Per item: delivered later (Try again or the hourly retry) → it closes itself.
      dedupeKey: `feedback-undelivered:${f.id}`,
      priority: 2,
      permission: 'settings.general',
    })
  }

  // ONE owner task for the whole backlog, not one per item; gone once it is set up and the backlog has gone.
  const held = signals.feedbackNotSetUp
  if (held && held.waiting > 0) {
    const what = held.missing.length === 2 ? 'the planner and email' : held.missing.length === 1 ? (held.missing[0] === 'planner' ? 'the planner' : 'email') : null
    tasks.push({
      source: 'feedback-not-set-up',
      // The count is in the title: rows show the title first (the detail can be cut off).
      title: what ? `Client feedback isn’t being forwarded yet (${held.waiting} waiting) — set up ${what}` : `Client feedback is waiting to be forwarded (${held.waiting})`,
      detail: `${plural(held.waiting, 'item')} waiting.${what ? '' : ' Set up — they go with the next hourly run.'}`,
      href: FEEDBACK_SETUP_HREF,
      targetType: null,
      targetId: null,
      dedupeKey: 'feedback-not-set-up',
      priority: 2,
      permission: 'settings.general',
    })
  }

  return tasks.sort((a, b) => a.priority - b.priority || a.title.localeCompare(b.title))
}

/**
 * Which open tasks to auto-resolve: an open task generated from a signal
 * that is no longer present was handled elsewhere (the draft got published,
 * the submissions were read), so it closes itself.
 */
export function tasksToResolve(openKeys: ReadonlyArray<string>, drafts: ReadonlyArray<TaskDraft>): string[] {
  const live = new Set(drafts.map((d) => d.dedupeKey))
  return openKeys.filter((k) => !live.has(k))
}

/** Tasks a user should see: ones whose permission they hold (any). */
export function visibleTo<T extends { permission: string | null }>(
  tasks: ReadonlyArray<T>,
  can: (permission: string) => boolean
): T[] {
  return tasks.filter((t) => !t.permission || can(t.permission))
}
