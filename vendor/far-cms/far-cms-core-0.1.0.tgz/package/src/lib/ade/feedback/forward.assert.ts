/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/feedback/forward.assert.ts
 */
import assert from 'node:assert/strict'
import {
  LOCK_MS,
  MAX_ATTEMPTS,
  backoffMs,
  deliveryLabel,
  digestDue,
  errorSummary,
  formatDigest,
  formatFeedback,
  forwardFeedback,
  maskNote,
  retryDelivery,
  safeRoute,
  displayNameOnly,
  type DeliveryRow,
  type DeliveryStore,
  type FeedbackChannel,
  type FeedbackChannelName,
  type FeedbackItem,
  type ForwardDeps,
  DeliveryRefused,
} from './forward'
import { PLANNER_TIMEOUT_MS, plannerChannel, plannerConfigFrom } from './planner'

let n = 0
const check = async (name: string, fn: () => void | Promise<void>) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }

const T0 = new Date(Date.UTC(2026, 9, 11, 12))
const ITEM: FeedbackItem = {
  id: 'cf1',
  kind: 'bug',
  screen: 'Initiatives › Edit',
  route: '/admin/initiatives/abc?token=secret#x',
  unitRef: 'card · Goal amount',
  note: 'The goal field resets. Call me on +1 (555) 123-4567 or mail ama@client.example',
  senderName: 'Ama',
  createdAt: T0,
  screenshotId: 'shot_1',
}

/** In-memory store with the claim semantics the Prisma binding implements. */
function memStore() {
  const rows = new Map<string, DeliveryRow>()
  const log: string[] = []
  const feedbackStatus = new Map<string, string>()
  const k = (id: string, c: FeedbackChannelName) => `${id}:${c}`
  const store: DeliveryStore = {
    async ensure(id, c, now) {
      log.push(`ensure:${c}`)
      if (!rows.has(k(id, c))) rows.set(k(id, c), { feedbackId: id, channel: c, status: 'pending', attempts: 0, nextAttemptAt: now, lockedUntil: null, externalId: null, lastError: null })
      return { ...rows.get(k(id, c))! }
    },
    async claim(id, c, now, lockMs) {
      const r = rows.get(k(id, c))
      if (!r) return null
      const takeable = ((r.status === 'pending' || r.status === 'not-set-up') && r.nextAttemptAt <= now) || (r.status === 'sending' && !!r.lockedUntil && r.lockedUntil <= now)
      if (!takeable) return null
      Object.assign(r, { status: 'sending', lockedUntil: new Date(now.getTime() + lockMs) })
      log.push(`claim:${c}`)
      return { ...r }
    },
    async update(id, c, patch) { Object.assign(rows.get(k(id, c))!, patch) },
    async setFeedbackStatus(id, s) { feedbackStatus.set(id, s) },
  }
  return { store, rows, log, feedbackStatus, row: (c: FeedbackChannelName) => rows.get(k('cf1', c))! }
}

function channel(name: FeedbackChannelName, opts: { configured?: boolean; atMostOnce?: boolean; fail?: () => boolean; found?: () => string | null; slow?: Promise<void> } = {}) {
  const sent: string[] = []
  const ch: FeedbackChannel = {
    name,
    configured: () => opts.configured ?? true,
    atMostOnce: opts.atMostOnce ?? name === 'email',
    ...(opts.found ? { find: async () => opts.found!() } : {}),
    async send(m) {
      if (opts.slow) await opts.slow
      if (opts.fail?.()) throw new Error('planner answered 503 Bearer aipp_SECRETKEY123 for owner@me.example')
      sent.push(m.ref)
      return { externalId: `${name}-${sent.length}` }
    },
  }
  return { ch, sent }
}

const deps = (s: ReturnType<typeof memStore>, channels: FeedbackChannel[], now = () => T0, load = async (id: string) => (id === 'cf1' ? ITEM : null)): ForwardDeps =>
  ({ load, store: s.store, channels, now, adminUrl: 'https://admin.example.org/' })

async function main() {
  await check('formatter: title, note, screen, masked unit, route without query, admin-only screenshot link, name only, ref', () => {
    const m = formatFeedback(ITEM, { adminUrl: 'https://admin.example.org/' })
    assert.equal(m.title, 'Client feedback: bug on Initiatives › Edit')
    assert.equal(m.ref, 'fb-cf1')
    assert.match(m.text, /^The goal field resets\./)
    assert.match(m.text, /Route: \/admin\/initiatives\/abc\n/)
    assert.doesNotMatch(m.text, /token=secret/)
    assert.match(m.text, /Unit: card\n/, 'the role only, never the element text')
    assert.match(m.text, /Screenshot \(private — admin sign-in\): https:\/\/admin\.example\.org\/api\/admin\/feedback\/screenshots\/shot_1\n/)
    assert.match(m.text, /From: Ama\n/)
    assert.match(m.text, /When: 2026-10-11T12:00:00\.000Z/)
    assert.match(m.html, /&rsaquo;|›/)
    assert.doesNotMatch(m.html, /<script/i)
    const x = formatFeedback({ ...ITEM, note: '<img src=x onerror=alert(1)>', screen: 'A\nB' }, { adminUrl: 'https://a.example.org' })
    assert.doesNotMatch(x.html, /<img/)
    assert.equal(x.title, 'Client feedback: bug on A B', 'one line')
  })

  await check('the sender is a display name only: an address-like name becomes "A client"', () => {
    assert.equal(displayNameOnly('Ama Owusu'), 'Ama Owusu')
    for (const x of ['ama@client.example', 'Ama <ama@client.example>', '', null, undefined]) assert.equal(displayNameOnly(x), 'A client')
    assert.match(formatFeedback({ ...ITEM, senderName: 'ama@client.example' }, { adminUrl: 'https://a.example.org' }).text, /From: A client\n/)
    assert.match(formatFeedback({ ...ITEM, unitRef: 'A private field (story)' }, { adminUrl: 'https://a.example.org' }).text, /Unit: A private field \(story\)/)
  })

  await check('masking: no client email addresses or long numbers; unit references are labels, never contents', () => {
    const m = formatFeedback(ITEM, { adminUrl: 'https://a.example.org' })
    assert.doesNotMatch(m.text + m.html, /ama@client\.example|555\) 123-4567/)
    assert.match(m.text, /\[email\]/)
    assert.match(m.text, /\[number\]/)
    assert.equal(maskNote('order 12345 is late'), 'order 12345 is late', 'short numbers stay')
    assert.equal(maskNote('x'.repeat(5000)).length, 4001)
    const leaky = formatFeedback({ ...ITEM, unitRef: 'row · ama@client.example · 4111 1111 1111 1111' }, { adminUrl: 'https://a.example.org' })
    assert.match(leaky.text, /Unit: row\n/)
    assert.doesNotMatch(leaky.text, /ama@client|4111/)
    // F-1: a record's name after the role never leaves.
    const row = formatFeedback({ ...ITEM, unitRef: 'Row · Ama Mensah · GHS 400' }, { adminUrl: 'https://a.example.org' })
    assert.match(row.text, /Unit: Row\n/)
    assert.doesNotMatch(row.text + row.html, /Ama Mensah|GHS 400/)
    assert.match(formatFeedback({ ...ITEM, unitRef: 'ama@client.example' }, { adminUrl: 'https://a.example.org' }).text, /Unit: private unit/)
    // F-10: encoded addresses and long numbers in the path are decoded, then masked.
    assert.equal(safeRoute('/admin/customers/ama%40client.example'), '/admin/customers/[email]')
    assert.equal(safeRoute('/admin/orders/%34%31%31%31111111111'), '/admin/orders/[number]')
    assert.equal(safeRoute('/admin/x%E0%A4%A'), '(unknown)', 'malformed encoding')
    assert.equal(safeRoute('/admin/a%2F%2Fevil'), '/admin/a//evil', 'decoded slashes stay a path on our host')
    assert.equal(safeRoute('https://evil.example/x'), '(unknown)')
    assert.equal(safeRoute('//evil.example'), '(unknown)')
    assert.equal(errorSummary(new Error('401 Bearer aipp_abcDEF for me@x.example')), 'Error: 401 Bearer [redacted] for [email]')
  })

  await check('store first: delivery rows exist before anything is sent; the feedback is "sent" once every set-up channel has it', async () => {
    const s = memStore()
    const p = channel('planner', { found: () => null })
    const e = channel('email')
    const out = await forwardFeedback(deps(s, [p.ch, e.ch]), 'cf1')
    assert.deepEqual(out, { planner: 'sent', email: 'sent' })
    assert.ok(s.log.indexOf('ensure:planner') < s.log.indexOf('claim:planner'))
    assert.equal(s.row('planner').externalId, 'planner-1')
    assert.equal(s.feedbackStatus.get('cf1'), 'sent')
    assert.deepEqual(await forwardFeedback(deps(s, [p.ch]), 'missing'), {}, 'an unknown id sends nothing')
  })

  await check('idempotent: a second call and two concurrent calls make ONE todo and ONE email', async () => {
    const s = memStore()
    let release!: () => void
    const slow = new Promise<void>((r) => { release = r })
    const p = channel('planner', { slow })
    const e = channel('email', { slow })
    const a = forwardFeedback(deps(s, [p.ch, e.ch]), 'cf1')
    const b = forwardFeedback(deps(s, [p.ch, e.ch]), 'cf1')
    await new Promise((r) => setTimeout(r, 10))
    release()
    await Promise.all([a, b])
    await forwardFeedback(deps(s, [p.ch, e.ch]), 'cf1')
    assert.equal(p.sent.length, 1)
    assert.equal(e.sent.length, 1)
  })

  await check('retry with backoff: a failure is retried when due (not before), and stops as failed after MAX_ATTEMPTS', async () => {
    const s = memStore()
    let failing = true
    const p = channel('planner', { fail: () => failing })
    let now = T0
    const d = deps(s, [p.ch], () => now)
    assert.deepEqual(await forwardFeedback(d, 'cf1'), { planner: 'pending' })
    assert.equal(s.row('planner').attempts, 1)
    assert.equal(s.row('planner').nextAttemptAt.getTime(), T0.getTime() + backoffMs(1))
    assert.doesNotMatch(s.row('planner').lastError!, /aipp_|owner@/, 'no key or address stored')
    now = new Date(T0.getTime() + backoffMs(1) - 1)
    await forwardFeedback(d, 'cf1')
    assert.equal(s.row('planner').attempts, 1, 'not due yet: nothing tried')
    failing = false
    now = new Date(T0.getTime() + backoffMs(1))
    assert.deepEqual(await forwardFeedback(d, 'cf1'), { planner: 'sent' })
    assert.equal(p.sent.length, 1)
    // Always failing → failed after MAX_ATTEMPTS, then nothing more.
    const s2 = memStore()
    const bad = channel('planner', { fail: () => true })
    let t = T0
    for (let i = 0; i < MAX_ATTEMPTS + 3; i++) {
      await forwardFeedback(deps(s2, [bad.ch], () => t), 'cf1')
      t = new Date(t.getTime() + 24 * 3_600_000)
    }
    assert.equal(s2.row('planner').status, 'failed')
    assert.equal(s2.row('planner').attempts, MAX_ATTEMPTS)
    assert.equal(deliveryLabel([s2.row('planner')]).label, 'Feedback not delivered')
    // A refusal retrying can't change (staging allow-list) fails at once.
    const s3 = memStore()
    const held: FeedbackChannel = { name: 'email', configured: () => true, atMostOnce: true, send: async () => { throw new DeliveryRefused('Held: not on the test allow-list') } }
    assert.deepEqual(await forwardFeedback(deps(s3, [held]), 'cf1'), { email: 'failed' })
    assert.equal(s3.row('email').attempts, 1)
    await retryDelivery(s2.store, 'cf1', 'planner', t)
    assert.equal(s2.row('planner').status, 'pending', 'the owner can try again')
  })

  await check('crash recovery: the planner finds its earlier todo (no duplicate); an interrupted email is never resent', async () => {
    const s = memStore()
    const created: string[] = []
    const p = channel('planner', { found: () => (created.length ? 'todo-earlier' : null) })
    const e = channel('email')
    // Simulate a crash after the provider accepted, before the row was marked: rows left 'sending' with a lock.
    await s.store.ensure('cf1', 'planner', T0)
    await s.store.ensure('cf1', 'email', T0)
    await s.store.claim('cf1', 'planner', T0, LOCK_MS)
    await s.store.claim('cf1', 'email', T0, LOCK_MS)
    created.push('todo-earlier')
    const later = new Date(T0.getTime() + LOCK_MS + 1)
    const out = await forwardFeedback(deps(s, [p.ch, e.ch], () => later), 'cf1')
    assert.equal(out.planner, 'sent')
    assert.equal(s.row('planner').externalId, 'todo-earlier')
    assert.equal(p.sent.length, 0, 'no second todo')
    assert.equal(out.email, 'failed')
    assert.equal(e.sent.length, 0, 'no second email')
    assert.match(s.row('email').lastError!, /may have gone out/)
    // Still locked (crash just happened): nobody touches it.
    const s2 = memStore()
    await s2.store.ensure('cf1', 'email', T0)
    await s2.store.claim('cf1', 'email', T0, LOCK_MS)
    assert.equal((await forwardFeedback(deps(s2, [e.ch], () => new Date(T0.getTime() + 1000)), 'cf1')).email, 'pending')
  })

  await check('not set up: nothing attempted, "Not set up yet", picked up once configured', async () => {
    const s = memStore()
    let ready = false
    const p = channel('planner')
    p.ch.configured = () => ready
    assert.deepEqual(await forwardFeedback(deps(s, [p.ch]), 'cf1'), { planner: 'not-set-up' })
    assert.equal(p.sent.length, 0)
    assert.equal(deliveryLabel([s.row('planner')]).label, 'Not set up yet')
    assert.equal(s.feedbackStatus.get('cf1'), undefined, 'still "new" in To-do')
    ready = true
    assert.deepEqual(await forwardFeedback(deps(s, [p.ch]), 'cf1'), { planner: 'sent' })
  })

  await check('labels and the digest', () => {
    const row = (channel: FeedbackChannelName, status: DeliveryRow['status'], lastError: string | null = null) => ({ channel, status, lastError })
    assert.equal(deliveryLabel([row('planner', 'sent'), row('email', 'not-set-up')]).label, 'Sent')
    assert.equal(deliveryLabel([row('planner', 'pending', 'Error: 503')]).label, 'Sending')
    assert.match(deliveryLabel([row('planner', 'pending', 'Error: 503')]).detail!, /Retrying/)
    assert.equal(formatDigest([], '2026-10-10', { adminUrl: 'https://a.example.org' }), null, 'nothing that day → no email')
    const d = formatDigest([ITEM, { ...ITEM, id: 'cf2' }], '2026-10-10', { adminUrl: 'https://a.example.org' })!
    assert.equal(d.title, 'Client feedback: 2 items on 2026-10-10')
    assert.doesNotMatch(d.text, /ama@client/)
    assert.equal(digestDue(new Date(Date.UTC(2026, 9, 11, 7)), null), null, 'before 08:00 UTC')
    assert.equal(digestDue(new Date(Date.UTC(2026, 9, 11, 9)), null), '2026-10-10')
    assert.equal(digestDue(new Date(Date.UTC(2026, 9, 11, 9)), '2026-10-10'), null, 'once per day')
  })

  await check('planner channel: real API shape (POST /api/todos, Bearer aipp_), dedupe by ref, env validated, no redirects', async () => {
    const env = { PLANNER_API_URL: 'https://faridea.dev/some/path', PLANNER_API_KEY: 'aipp_abcdefghijklmnopqrstuvwxyz012345', PLANNER_FEEDBACK_PROJECT_ID: '4c58fff5-f272-4bb4-87a4-fc109b0e1c8e' }
    assert.deepEqual(plannerConfigFrom(env), { apiUrl: 'https://faridea.dev', apiKey: env.PLANNER_API_KEY, projectId: env.PLANNER_FEEDBACK_PROJECT_ID })
    for (const bad of [{ ...env, PLANNER_API_URL: 'http://faridea.dev' }, { ...env, PLANNER_API_KEY: 'sk_live_x' }, { ...env, PLANNER_FEEDBACK_PROJECT_ID: 'dzidzor' }, {}]) assert.equal(plannerConfigFrom(bad), null)
    const calls: Array<{ url: string; init: RequestInit }> = []
    const todos: Array<{ id: string; description: string }> = []
    const f = (async (url: string, init: RequestInit = {}) => {
      calls.push({ url: String(url), init })
      if ((init.method ?? 'GET') === 'POST') {
        const b = JSON.parse(String(init.body))
        todos.push({ id: `t${todos.length + 1}`, description: b.description })
        return new Response(JSON.stringify({ success: true, data: { id: `t${todos.length}` } }), { status: 201 })
      }
      const q = new URL(String(url)).searchParams.get('search')!
      return new Response(JSON.stringify({ success: true, data: todos.filter((t) => t.description.includes(q)) }))
    }) as typeof fetch
    const ch = plannerChannel(() => plannerConfigFrom(env), f)
    const s = memStore()
    const d = deps(s, [ch])
    assert.deepEqual(await forwardFeedback(d, 'cf1'), { planner: 'sent' })
    const post = calls.find((c) => c.init.method === 'POST')!
    assert.equal(post.url, 'https://faridea.dev/api/todos')
    assert.equal((post.init.headers as Record<string, string>).Authorization, `Bearer ${env.PLANNER_API_KEY}`)
    assert.equal(post.init.redirect, 'error')
    assert.ok(post.init.signal instanceof AbortSignal, 'F-8: every planner call has a timeout signal')
    assert.equal(PLANNER_TIMEOUT_MS, 10_000)
    const body = JSON.parse(String(post.init.body))
    assert.equal(body.projectId, env.PLANNER_FEEDBACK_PROJECT_ID)
    assert.equal(body.title, 'Client feedback: bug on Initiatives › Edit')
    assert.match(body.description, /Ref: fb-cf1/)
    // Row lost (e.g. DB restored) → the next run finds the todo instead of making another.
    s.rows.clear()
    await forwardFeedback(d, 'cf1')
    assert.equal(todos.length, 1, 'one todo')
    assert.equal(s.row('planner').externalId, 't1')
    // A 401 is a retry with a stored, key-free error.
    const s2 = memStore()
    const denied = plannerChannel(() => plannerConfigFrom(env), (async () => new Response('{}', { status: 401 })) as typeof fetch)
    assert.deepEqual(await forwardFeedback(deps(s2, [denied]), 'cf1'), { planner: 'pending' })
    assert.equal(s2.row('planner').lastError, 'PlannerError: The planner answered 401')
  })
}

main().then(() => console.log(`\n${n} checks passed`)).catch((e) => { console.error(e); process.exit(1) })
