/**
 * The AI Project Planner as a feedback channel — pure (fetch injected);
 * asserted by forward.assert.ts.
 *
 * Planner HTTP API (ai-project-planner, app/api/todos/route.ts):
 *   POST /api/todos  { title, description, projectId, priority, metadata }
 *        → 201 { success: true, data: { id, … } }
 *   GET  /api/todos?projectId=…&search=…  (ILIKE on title + description)
 *        → { success: true, data: [{ id, description, … }] }
 * Auth: `Authorization: Bearer aipp_…` — an API key made in the planner
 * (Settings › API keys, scope "write") by the person who owns the project
 * (the route checks project ownership).
 */

import type { FeedbackChannel, ForwardMessage } from './forward'

export interface PlannerConfig {
  apiUrl: string
  apiKey: string
  projectId: string
}

export const PLANNER_TIMEOUT_MS = 10_000
const KEY = /^aipp_[A-Za-z0-9_-]{20,}$/
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

/** The planner settings from env, or null when any is missing or malformed ("Not set up yet"). */
export function plannerConfigFrom(env: Record<string, string | undefined>): PlannerConfig | null {
  const apiKey = env.PLANNER_API_KEY?.trim() ?? ''
  const projectId = env.PLANNER_FEEDBACK_PROJECT_ID?.trim() ?? ''
  let apiUrl: URL
  try {
    apiUrl = new URL(env.PLANNER_API_URL?.trim() ?? '')
  } catch {
    return null
  }
  const local = apiUrl.hostname === 'localhost' || apiUrl.hostname === '127.0.0.1'
  if (apiUrl.protocol !== 'https:' && !(local && apiUrl.protocol === 'http:')) return null
  if (!KEY.test(apiKey) || !UUID.test(projectId)) return null
  return { apiUrl: apiUrl.origin, apiKey, projectId }
}

class PlannerError extends Error {
  constructor(readonly status: number) {
    super(`The planner answered ${status}`)
    this.name = 'PlannerError'
  }
}

export function plannerChannel(config: () => PlannerConfig | null, fetchImpl: typeof fetch = fetch): FeedbackChannel {
  const call = async <T>(path: string, init: RequestInit = {}): Promise<T> => {
    const c = config()
    if (!c) throw new Error('The planner is not set up')
    const res = await fetchImpl(`${c.apiUrl}${path}`, {
      ...init,
      redirect: 'error', // the key never follows a redirect elsewhere
      // A hung planner must not hold the delivery lock (2 min) or the cron's budget.
      signal: AbortSignal.timeout(PLANNER_TIMEOUT_MS),
      headers: { Authorization: `Bearer ${c.apiKey}`, 'Content-Type': 'application/json', Accept: 'application/json' },
    })
    if (!res.ok) throw new PlannerError(res.status)
    const body = (await res.json()) as { success?: boolean; data?: T }
    if (body?.success !== true) throw new Error('The planner answered without success')
    return body.data as T
  }
  return {
    name: 'planner',
    configured: () => config() !== null,
    atMostOnce: false,
    async find(ref) {
      const c = config()!
      const qs = new URLSearchParams({ projectId: c.projectId, search: ref })
      const rows = await call<Array<{ id?: string; description?: string | null }>>(`/api/todos?${qs}`)
      const hit = (rows ?? []).find((r) => typeof r.id === 'string' && (r.description ?? '').includes(`Ref: ${ref}`))
      return hit?.id ?? null
    },
    async send(m: ForwardMessage) {
      const c = config()!
      const todo = await call<{ id?: string }>('/api/todos', {
        method: 'POST',
        body: JSON.stringify({ title: m.title.slice(0, 200), description: m.text, projectId: c.projectId, priority: 'medium', metadata: { source: 'client-feedback', ref: m.ref } }),
      })
      return { externalId: typeof todo?.id === 'string' ? todo.id : null }
    },
  }
}
