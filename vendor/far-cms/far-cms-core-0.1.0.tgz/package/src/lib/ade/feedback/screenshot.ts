/**
 * Feedback screenshots are PRIVATE — pure helpers, asserted.
 *
 * A screenshot of a part of the admin can show whatever that screen showed
 * (names, amounts), so it never goes to the media library (whose files sit
 * on the public media domain). The host stores the bytes itself and serves
 * them only through an authenticated route; links in the planner and email
 * point there and need an admin sign-in.
 */

export const SCREENSHOT_MAX_BYTES = 1_500_000
export type ScreenshotType = 'image/jpeg' | 'image/png' | 'image/webp'

/** What the bytes really are (magic numbers — never the client's Content-Type), or null. */
export function sniffScreenshot(b: Uint8Array): ScreenshotType | null {
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg'
  if (b.length >= 8 && [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every((x, i) => b[i] === x)) return 'image/png'
  if (b.length >= 12 && String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP') return 'image/webp'
  return null
}

/** The admin-only address of a stored screenshot. */
export const screenshotPath = (id: string) => `/api/admin/feedback/screenshots/${encodeURIComponent(id)}`

/** Response headers for serving one: never cached by shared caches, never sniffed, never run. */
export function screenshotHeaders(type: ScreenshotType, size: number): Record<string, string> {
  return {
    'Content-Type': type,
    'Content-Length': String(size),
    'Cache-Control': 'private, no-store',
    'X-Content-Type-Options': 'nosniff',
    'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'",
    'Content-Disposition': 'inline; filename="feedback-screenshot"',
    'Referrer-Policy': 'no-referrer',
  }
}
