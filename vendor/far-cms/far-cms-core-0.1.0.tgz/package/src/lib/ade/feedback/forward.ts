/**
 * Client feedback → the owner (their AI Project Planner, their email) —
 * pure core, asserted by forward.assert.ts. App-agnostic (BYB syncs it);
 * the host supplies the store, the channels and the clock.
 *
 * Store first, then forward: the feedback row exists (and shows in the
 * app's To-do) before anything leaves; each channel gets one delivery row
 * (feedback × channel), claimed before sending, so a second call, a
 * concurrent call or a cron retry never sends twice:
 * - a channel that can look up what it already created (the planner: by
 *   the "fb-<id>" ref in the todo) is retried until it lands, and a retry
 *   after a crash finds the earlier todo instead of making another;
 * - a channel that can't (email) is at-most-once: a send interrupted
 *   mid-flight is marked failed ("check before resending"), never resent.
 *
 * Nothing private is forwarded: the client's note (emails / long numbers
 * masked), a MASKED unit reference, the screen and route, the sender's
 * display name, and an admin-only screenshot link.
 */

import { screenshotPath } from './screenshot'

export type FeedbackChannelName = 'planner' | 'email'
export type DeliveryStatus = 'pending' | 'sending' | 'sent' | 'failed' | 'not-set-up'
/** What a caller hears back per channel. */
export type DeliveryState = 'sent' | 'pending' | 'failed' | 'not-set-up'

export interface FeedbackItem {
  id: string
  kind: string
  /** Human label of the screen, e.g. "Initiatives › Edit". */
  screen: string
  route: string
  /** Masked functional-unit reference (role/label only), or null. */
  unitRef: string | null
  note: string
  /** Display name only — never an email address. */
  senderName: string
  createdAt: Date
  /** Id of a PRIVATE feedback screenshot (lib/ade/feedback/screenshot; linked behind an admin sign-in), or null. */
  screenshotId: string | null
}

export interface ForwardMessage {
  ref: string
  title: string
  text: string
  html: string
}

export interface FeedbackChannel {
  name: FeedbackChannelName
  /** Env / settings present? (false → "Not set up yet", nothing is attempted) */
  configured(): boolean
  /** True when the channel can't look up an earlier send: never resend after an interrupted attempt. */
  atMostOnce: boolean
  /** The id of something already created for this ref (planner), or null. */
  find?(ref: string): Promise<string | null>
  send(message: ForwardMessage, item: FeedbackItem): Promise<{ externalId?: string | null }>
}

export interface DeliveryRow {
  feedbackId: string
  channel: FeedbackChannelName
  status: DeliveryStatus
  attempts: number
  nextAttemptAt: Date
  lockedUntil: Date | null
  externalId: string | null
  lastError: string | null
}

export interface DeliveryStore {
  /** The row for (feedback, channel), created 'pending' if missing. */
  ensure(feedbackId: string, channel: FeedbackChannelName, now: Date): Promise<DeliveryRow>
  /**
   * Atomically take the row for one attempt: only when it is pending or
   * not-set-up and due, or 'sending' with its lock run out (an interrupted
   * attempt). Returns the claimed row (status 'sending', locked) or null
   * when someone else has it or it isn't due.
   */
  claim(feedbackId: string, channel: FeedbackChannelName, now: Date, lockMs: number): Promise<DeliveryRow | null>
  update(feedbackId: string, channel: FeedbackChannelName, patch: Partial<Omit<DeliveryRow, 'feedbackId' | 'channel'>>): Promise<void>
  /** Mark the feedback itself (new → sent once every set-up channel has it). */
  setFeedbackStatus(feedbackId: string, status: 'sent'): Promise<void>
}

export interface ForwardDeps {
  load(id: string): Promise<FeedbackItem | null>
  store: DeliveryStore
  channels: readonly FeedbackChannel[]
  now(): Date
  /** Absolute base URL of the admin (links in the message). */
  adminUrl: string
}

export const MAX_ATTEMPTS = 7
export const LOCK_MS = 2 * 60_000
const BACKOFF_MS = [5, 15, 60, 180, 360, 720].map((m) => m * 60_000)
/** Wait before attempt n+1 after n failures (5 min … 12 h). */
export const backoffMs = (failures: number) => BACKOFF_MS[Math.min(Math.max(failures, 1), BACKOFF_MS.length) - 1]

export const NOTE_CAP = 4000

/** A refusal that retrying can't change (e.g. the staging allow-list): failed at once, not retried. */
export class DeliveryRefused extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'DeliveryRefused'
  }
}

export const feedbackRef = (id: string) => `fb-${id}`

/** The client's text, with email addresses and long digit runs (phones, card / account numbers) masked. */
export function maskNote(note: string): string {
  const s = String(note ?? '')
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email]')
    .replace(/\+?\d[\d\s().-]{7,}\d/g, (m) => (m.replace(/\D/g, '').length >= 9 ? '[number]' : m))
    .trim()
  return s.length > NOTE_CAP ? `${s.slice(0, NOTE_CAP)}…` : s
}

/** An admin path only: query and fragment dropped (they can carry record data or tokens). */
export function safeRoute(route: string): string {
  let path = String(route ?? '').split(/[?#]/)[0].trim()
  // Decode first, so an encoded address (/customers/ama%40x.com) is masked like a plain one.
  try {
    path = decodeURIComponent(path)
  } catch {
    return '(unknown)'
  }
  path = path
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email]')
    .replace(/\d{9,}/g, '[number]')
  return /^\/[\w\-./~[\]()]*$/.test(path) && !path.startsWith('//') ? path.slice(0, 300) : '(unknown)'
}

const oneLine = (s: string, cap: number) => String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, cap)
/** A unit reference is a role/label, never contents: anything longer or with an @ is dropped. */
/**
 * A unit reference forwards its ROLE only ("Row", "Card", "A private field"):
 * anything after the first " · " (the element's own text, e.g. a record's
 * name) is dropped, whatever the client sent (F-1, defence in depth).
 */
const safeUnit = (u: string | null) => {
  if (!u) return null
  const role = oneLine(u.split(' · ')[0], 80)
  return role && !role.includes('@') && !/\d{6,}/.test(role) ? role : 'private unit'
}

/** A display name only: anything that looks like an address becomes "A client". */
export const displayNameOnly = (name: string | null | undefined) => {
  const v = oneLine(name ?? '', 80)
  return v && !v.includes('@') ? v : 'A client'
}
const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] as string)

/** Title + plain text + HTML for one item (the planner todo and the email share it). */
export function formatFeedback(item: FeedbackItem, opts: { adminUrl: string }): ForwardMessage {
  const base = opts.adminUrl.replace(/\/+$/, '')
  const ref = feedbackRef(item.id)
  const kind = oneLine(item.kind, 40) || 'feedback'
  const screen = oneLine(item.screen, 120) || 'an admin screen'
  const unit = safeUnit(item.unitRef)
  const shot = item.screenshotId ? `${base}${screenshotPath(item.screenshotId)}` : null
  const open = `${base}/admin/todo?feedback=${encodeURIComponent(item.id)}`
  const fields: Array<[string, string]> = [
    ['Screen', screen],
    ['Route', safeRoute(item.route)],
    ...(unit ? ([['Unit', unit]] as Array<[string, string]>) : []),
    ['From', displayNameOnly(item.senderName)],
    ['When', item.createdAt.toISOString()],
    ...(shot ? ([['Screenshot (private — admin sign-in)', shot]] as Array<[string, string]>) : []),
    ['Open in the admin', open],
    ['Ref', ref],
  ]
  const note = maskNote(item.note)
  const text = [note || '(no note)', '', ...fields.map(([k, v]) => `${k}: ${v}`)].join('\n')
  const html = [
    `<p style="white-space:pre-wrap">${esc(note || '(no note)')}</p>`,
    '<table style="border-collapse:collapse;font-size:14px">',
    ...fields.map(([k, v]) => `<tr><td style="padding:4px 12px 4px 0;color:#666">${esc(k)}</td><td style="padding:4px 0">${/^https:\/\//.test(v) ? `<a href="${esc(v)}">${esc(v)}</a>` : esc(v)}</td></tr>`),
    '</table>',
  ].join('\n')
  return { ref, title: `Client feedback: ${kind} on ${screen}`, text, html }
}

/** A failure as stored and shown: short, no tokens or keys. */
export function errorSummary(e: unknown): string {
  const raw = e instanceof Error ? `${e.name}: ${e.message}` : String(e)
  return raw
    .replace(/Bearer\s+\S+/gi, 'Bearer [redacted]')
    .replace(/\baipp_[A-Za-z0-9_-]+/g, '[key]')
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email]')
    .slice(0, 200)
}

const stateOf = (s: DeliveryStatus): DeliveryState => (s === 'sent' ? 'sent' : s === 'failed' ? 'failed' : s === 'not-set-up' ? 'not-set-up' : 'pending')

/** One channel, one attempt (if due and not taken). */
async function forwardTo(deps: ForwardDeps, ch: FeedbackChannel, item: FeedbackItem, message: ForwardMessage): Promise<DeliveryState> {
  const now = deps.now()
  // Store first: the delivery row exists before anything leaves.
  const row = await deps.store.ensure(item.id, ch.name, now)
  if (row.status === 'sent' || row.status === 'failed') return stateOf(row.status)
  if (!ch.configured()) {
    if (row.status !== 'not-set-up') await deps.store.update(item.id, ch.name, { status: 'not-set-up' })
    return 'not-set-up'
  }
  // A send that was interrupted mid-flight (lock ran out while 'sending'):
  if (row.status === 'sending' && row.lockedUntil && row.lockedUntil <= now && ch.atMostOnce) {
    await deps.store.update(item.id, ch.name, { status: 'failed', lockedUntil: null, lastError: 'Interrupted while sending — it may have gone out. Check before resending.' })
    return 'failed'
  }
  const claimed = await deps.store.claim(item.id, ch.name, now, LOCK_MS)
  if (!claimed) return 'pending'
  try {
    const existing = ch.find ? await ch.find(message.ref) : null
    const externalId = existing ?? (await ch.send(message, item)).externalId ?? null
    await deps.store.update(item.id, ch.name, { status: 'sent', lockedUntil: null, externalId, lastError: null, attempts: claimed.attempts + (existing ? 0 : 1) })
    return 'sent'
  } catch (e) {
    const attempts = claimed.attempts + 1
    const done = attempts >= MAX_ATTEMPTS || e instanceof DeliveryRefused
    await deps.store.update(item.id, ch.name, {
      status: done ? 'failed' : 'pending',
      attempts,
      lockedUntil: null,
      nextAttemptAt: new Date(now.getTime() + backoffMs(attempts)),
      lastError: errorSummary(e),
    })
    return done ? 'failed' : 'pending'
  }
}

/**
 * Forward one stored feedback item to every channel. Never throws; safe to
 * call again (and from the retry cron) — each channel sends at most once.
 */
export async function forwardFeedback(deps: ForwardDeps, id: string): Promise<Partial<Record<FeedbackChannelName, DeliveryState>>> {
  const out: Partial<Record<FeedbackChannelName, DeliveryState>> = {}
  let item: FeedbackItem | null
  try {
    item = await deps.load(id)
  } catch {
    return out
  }
  if (!item) return out
  const message = formatFeedback(item, { adminUrl: deps.adminUrl })
  for (const ch of deps.channels) {
    try {
      out[ch.name] = await forwardTo(deps, ch, item, message)
    } catch {
      out[ch.name] = 'pending' // the store itself failed; the cron tries again
    }
  }
  const states = Object.values(out)
  const configured = states.filter((s) => s !== 'not-set-up')
  if (configured.length && configured.every((s) => s === 'sent')) {
    await deps.store.setFeedbackStatus(id, 'sent').catch(() => {})
  }
  return out
}

export type DeliveryLabel = 'Sent' | 'Sending' | 'Feedback not delivered' | 'Not set up yet'

/** The To-do label for one item from its delivery rows. */
export function deliveryLabel(rows: readonly Pick<DeliveryRow, 'channel' | 'status' | 'lastError'>[]): { label: DeliveryLabel; detail?: string } {
  const failed = rows.filter((r) => r.status === 'failed')
  if (failed.length) return { label: 'Feedback not delivered', detail: failed.map((r) => `${r.channel === 'planner' ? 'Planner' : 'Email'}: ${r.lastError ?? 'failed'}`).join(' · ') }
  const live = rows.filter((r) => r.status !== 'not-set-up')
  if (!live.length) return { label: 'Not set up yet', detail: 'Forwarding to the planner and email needs setting up (PLANNER_API_KEY, FEEDBACK_NOTIFY_EMAIL).' }
  if (live.every((r) => r.status === 'sent')) return { label: 'Sent' }
  const retrying = live.find((r) => r.lastError)
  return { label: 'Sending', ...(retrying ? { detail: `Retrying — ${retrying.lastError}` } : {}) }
}

/** The daily digest: one message for the items of one day (empty → null, nothing sent). */
export function formatDigest(items: readonly FeedbackItem[], day: string, opts: { adminUrl: string }): ForwardMessage | null {
  if (!items.length) return null
  const parts = items.map((it) => formatFeedback(it, opts))
  const text = parts.map((p, i) => `${i + 1}. ${p.title}\n${p.text}`).join('\n\n———\n\n')
  const html = parts.map((p) => `<h3>${esc(p.title)}</h3>\n${p.html}`).join('\n<hr>\n')
  return { ref: `fb-digest-${day}`, title: `Client feedback: ${items.length} item${items.length === 1 ? '' : 's'} on ${day}`, text, html }
}

/** Is the digest for `day` (UTC date, yyyy-mm-dd) due? After `hourUtc`, once per day. */
export function digestDue(now: Date, lastSentDay: string | null, hourUtc = 8): string | null {
  if (now.getUTCHours() < hourUtc) return null
  const yesterday = new Date(now.getTime() - 86_400_000).toISOString().slice(0, 10)
  return lastSentDay && lastSentDay >= yesterday ? null : yesterday
}

/** Owner's "Try again" on a failed delivery: back to pending, due now, attempts reset. */
export async function retryDelivery(store: DeliveryStore, feedbackId: string, channel: FeedbackChannelName, now: Date): Promise<void> {
  await store.update(feedbackId, channel, { status: 'pending', attempts: 0, nextAttemptAt: now, lockedUntil: null, lastError: null })
}
