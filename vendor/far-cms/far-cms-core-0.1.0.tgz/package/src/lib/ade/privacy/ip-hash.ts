/**
 * Keyed IP hashing (HMAC-SHA256), rotation-safe. App-agnostic: the host app
 * supplies the key(s) — e.g. derived from a server secret it already has.
 *
 * Stored form: `h1.<keyId>.<32 hex>` — the key id says which key made it, so
 * when the secret changes, old hashes still match under the previous key and
 * new ones use the new key. The raw address is never stored or recoverable;
 * equal addresses under the same key give equal hashes (rate limits, abuse
 * lookups still work).
 */

import { createHash, createHmac } from 'node:crypto'

export interface HashKey {
  /** Short public id (first 6 hex of the key's own hash). */
  id: string
  secret: string
}

const PREFIX = 'h1'
const HASHED = /^h1\.[0-9a-f]{6}\.[0-9a-f]{32}$/

/** A purpose-specific key from a master secret (so the master is never used directly). */
export function deriveKey(master: string, label: string): HashKey {
  const secret = createHmac('sha256', master).update(`derive:${label}`).digest('hex')
  return { id: createHash('sha256').update(secret).digest('hex').slice(0, 6), secret }
}

/** One canonical spelling per address: first of a forwarded list, trimmed, lower-case, IPv4-mapped unwrapped. */
export function normalizeIp(raw: string): string {
  return raw.split(',')[0].trim().toLowerCase().replace(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/, '$1').replace(/^\[|\]$/g, '')
}

export function isHashedIp(v: unknown): v is string {
  return typeof v === 'string' && HASHED.test(v)
}

export function hashIp(raw: string, key: HashKey): string {
  return `${PREFIX}.${key.id}.${createHmac('sha256', key.secret).update(normalizeIp(raw)).digest('hex').slice(0, 32)}`
}

/**
 * What to store for an address: its hash; nothing for empty/"unknown";
 * an already-hashed value unchanged (so a backfill can run twice).
 */
export function ipForStorage(raw: string | null | undefined, key: HashKey): string | null {
  if (raw === null || raw === undefined) return null
  if (isHashedIp(raw)) return raw
  const ip = normalizeIp(raw)
  if (!ip || ip === 'unknown') return null
  return hashIp(ip, key)
}

/** Does a stored hash belong to this address under any accepted key (current + previous)? */
export function ipMatches(stored: string | null | undefined, raw: string, keys: readonly HashKey[]): boolean {
  if (!isHashedIp(stored)) return false
  const id = stored.split('.')[1]
  const key = keys.find((k) => k.id === id)
  return !!key && hashIp(raw, key) === stored
}
