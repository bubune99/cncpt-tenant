/**
 * Retention purge rules — pure. The host app runs the plan (batched deletes)
 * and logs the counts.
 */

export interface PurgeRule {
  /** What to purge (the app maps it to a table). */
  target: string
  /** Keep rows newer than this. */
  keep: { months: number } | { days: number }
  /** Per-owner overrides (e.g. a form's own retention, in months); null = use the default. */
  overrides?: ReadonlyMap<string, number | null>
}

export interface PurgeStep {
  target: string
  /** Delete rows created before this instant. */
  before: Date
  /** Only rows of these owners (an override) — or every owner NOT in `exceptOwners` (the default). */
  owners?: string[]
  exceptOwners?: string[]
}

/** Calendar months back (clamped to the month's last day), UTC. */
export function monthsAgo(now: Date, months: number): Date {
  const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - months, 1, now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds()))
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate()
  d.setUTCDate(Math.min(now.getUTCDate(), last))
  return d
}

export function cutoff(keep: PurgeRule['keep'], now: Date): Date {
  return 'months' in keep ? monthsAgo(now, keep.months) : new Date(now.getTime() - keep.days * 86_400_000)
}

/**
 * The shortest a form may keep its answers (audit run-2 R2-12): a shorter
 * setting — by a person or an approved agent draft — can't make the nightly
 * purge wipe months of answers at once.
 */
export const MIN_RETENTION_MONTHS = 6

/** A sane retention: whole months up to 120, never under MIN_RETENTION_MONTHS (raised to it); anything else means "use the default". */
export function validMonths(v: unknown): number | null {
  return typeof v === 'number' && Number.isInteger(v) && v >= 1 && v <= 120 ? Math.max(v, MIN_RETENTION_MONTHS) : null
}

export function planPurge(rules: readonly PurgeRule[], now: Date): PurgeStep[] {
  const steps: PurgeStep[] = []
  for (const r of rules) {
    const overrides = [...(r.overrides ?? new Map()).entries()].filter(([, m]) => validMonths(m) !== null) as Array<[string, number]>
    steps.push({ target: r.target, before: cutoff(r.keep, now), ...(overrides.length ? { exceptOwners: overrides.map(([o]) => o) } : {}) })
    // Group owners that share a retention into one step.
    const byMonths = new Map<number, string[]>()
    for (const [owner, m] of overrides) byMonths.set(m, [...(byMonths.get(m) ?? []), owner])
    for (const [m, owners] of byMonths) steps.push({ target: r.target, before: monthsAgo(now, m), owners })
  }
  return steps
}

/** How many batches one run may take per step (a nightly job, not a stampede). */
export const PURGE_BATCH = 500
export const PURGE_MAX_BATCHES = 20
