/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/privacy/privacy.assert.ts
 */
import assert from 'node:assert/strict'
import { deriveKey, hashIp, ipForStorage, ipMatches, isHashedIp, normalizeIp } from './ip-hash'
import { isUaFamily, uaFamily } from './ua'
import { redactText, redactValue } from './redact'
import { cutoff, monthsAgo, planPurge, validMonths } from './retention'
import { missingFromInventory, modelsFromSchema, whatWeCollect, whatWeCollectMarkdown, type InventoryEntry } from './inventory'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('IP hash: keyed, stable, never the raw address, one spelling per address', () => {
  const k = deriveKey('master-secret', 'ip-hash:v1')
  const h = hashIp('203.0.113.7', k)
  assert.ok(isHashedIp(h) && !h.includes('203'))
  assert.equal(hashIp(' 203.0.113.7, 10.0.0.1', k), h)
  assert.equal(hashIp('::ffff:203.0.113.7', k), h)
  assert.notEqual(hashIp('203.0.113.7', deriveKey('another-secret', 'ip-hash:v1')), h)
  assert.notEqual(hashIp('203.0.113.7', deriveKey('master-secret', 'other-purpose')), h)
  assert.equal(normalizeIp('[2001:DB8::1]'), '2001:db8::1')
})

check('IP hash: idempotent for backfills; empty/unknown store nothing', () => {
  const k = deriveKey('m', 'ip-hash:v1')
  const h = ipForStorage('198.51.100.1', k)!
  assert.equal(ipForStorage(h, k), h)
  assert.equal(ipForStorage(null, k), null)
  assert.equal(ipForStorage('unknown', k), null)
  assert.equal(ipForStorage('  ', k), null)
})

check('IP hash: rotation-safe — old hashes still match under the previous key', () => {
  const old = deriveKey('old-master', 'ip-hash:v1')
  const cur = deriveKey('new-master', 'ip-hash:v1')
  const stored = hashIp('192.0.2.5', old)
  assert.equal(ipMatches(stored, '192.0.2.5', [cur, old]), true)
  assert.equal(ipMatches(stored, '192.0.2.5', [cur]), false)
  assert.equal(ipMatches(stored, '192.0.2.6', [cur, old]), false)
  assert.equal(ipMatches('192.0.2.5', '192.0.2.5', [cur, old]), false)
})

check('user agent → browser family + major version only', () => {
  assert.equal(uaFamily('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.6668.90 Safari/537.36'), 'Chrome 129')
  assert.equal(uaFamily('Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36 Edg/129.0.2792.79'), 'Edge 129')
  assert.equal(uaFamily('Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1'), 'Safari 17')
  assert.equal(uaFamily('Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0'), 'Firefox 131')
  assert.equal(uaFamily('Googlebot/2.1 (+http://www.google.com/bot.html)'), 'Bot')
  assert.equal(uaFamily('curl/8.4.0'), 'Bot')
  assert.equal(uaFamily(''), null)
  assert.ok(isUaFamily('Chrome 129') && !isUaFamily('Mozilla/5.0 (X11)'))
})

check('redaction: emails and phones go, dates/ids/prices stay, secret keys blanked', () => {
  assert.equal(redactText('Reach ama.mensah@example.com or +233 24 123 4567 by 2026-10-10'), 'Reach [email] or [phone] by 2026-10-10')
  assert.equal(redactText('Order #1042 costs $19.99'), 'Order #1042 costs $19.99')
  assert.equal(redactText('card 4111111111111111'), 'card [number]')
  const v = redactValue({ email: 'a@example.com', notes: 'call (555) 010-0100', apiKey: 'cms_x', nested: [{ password: 'p', title: 'Hello' }], id: 'ckabc123' }, new Set(['id']))
  assert.deepEqual(v, { email: '[email]', notes: 'call [phone]', apiKey: '[redacted]', nested: [{ password: '[redacted]', title: 'Hello' }], id: 'ckabc123' })
})

check('purge rules: calendar months, per-owner overrides, invalid overrides ignored', () => {
  const now = new Date('2026-10-10T03:00:00Z')
  assert.equal(monthsAgo(now, 24).toISOString(), '2024-10-10T03:00:00.000Z')
  assert.equal(monthsAgo(new Date('2026-03-31T00:00:00Z'), 1).toISOString(), '2026-02-28T00:00:00.000Z')
  assert.equal(cutoff({ days: 90 }, now).toISOString(), '2026-07-12T03:00:00.000Z')
  const steps = planPurge([{ target: 'submissions', keep: { months: 24 }, overrides: new Map([['f1', 6], ['f2', 6], ['f3', null], ['f4', 999]]) }], now)
  assert.deepEqual(steps, [
    { target: 'submissions', before: monthsAgo(now, 24), exceptOwners: ['f1', 'f2'] },
    { target: 'submissions', before: monthsAgo(now, 6), owners: ['f1', 'f2'] },
  ])
  assert.deepEqual(planPurge([{ target: 'audit', keep: { months: 12 } }], now), [{ target: 'audit', before: monthsAgo(now, 12) }])
  assert.equal(validMonths(0), null)
  assert.equal(validMonths(36), 36)
})

check('R2-12: retention can’t go under 6 months — 1 month is kept as 6 (stored and when purging)', () => {
  assert.equal(validMonths(1), 6)
  assert.equal(validMonths(5), 6)
  assert.equal(validMonths(6), 6)
  const now = new Date(Date.UTC(2026, 9, 11, 3, 30))
  const steps = planPurge([{ target: 'submissions', keep: { months: 24 }, overrides: new Map([['f1', validMonths(1)]]) }], now)
  assert.deepEqual(steps[1], { target: 'submissions', before: monthsAgo(now, 6), owners: ['f1'] })
})

check('inventory: completeness check and the "What we collect" table', () => {
  const schema = 'model Person {\n  id String @id\n  email String\n  bio String?\n  city String?\n}\nmodel Thing {\n  name String\n}\n'
  const models = modelsFromSchema(schema)
  const entry: InventoryEntry = { model: 'Person', fields: ['email'], category: 'People', kinds: ['email'], purpose: 'To reply.', retention: { kind: 'months', months: 12 }, visibleTo: 'Staff', onSubjectDelete: 'delete' }
  assert.deepEqual(missingFromInventory(models, [entry], new Set()), ['Person.city', 'Thing.name'])
  assert.deepEqual(missingFromInventory(models, [{ ...entry, fields: ['email', 'city'] }], new Set(['Thing.name'])), [])
  const rows = whatWeCollect([entry, { ...entry, model: 'Other', kinds: ['name'], retention: { kind: 'days', days: 90 } }])
  assert.deepEqual(rows, [{ category: 'People', what: 'email, name', why: 'To reply.', howLong: '12 months; 90 days', whoSees: 'Staff' }])
  assert.ok(whatWeCollectMarkdown(rows).startsWith('| What | Details |'))
})

console.log(`\n${n} checks passed`)
