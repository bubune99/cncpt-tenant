/**
 * Redact personal details from text sent where they aren't the point (AI
 * prompts, tool outputs, logs). Emails → [email], phone numbers → [phone],
 * long digit runs that look like card/ID numbers → [number]. Keys that hold
 * secrets are blanked entirely.
 */

const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g
// +country or local formats with separators; at least 7 digits overall.
const PHONE = /(?<![\w/.-])\+?\(?\d[\d ().-]{6,}\d(?![\w/-])/g
const LONG_NUMBER = /\b\d{12,19}\b/g
const SECRET_KEY = /(pass(word)?|secret|token|api[_-]?key|authorization|cookie|private[_-]?key)/i

function digits(s: string): number {
  return (s.match(/\d/g) ?? []).length
}

export function redactText(text: string): string {
  return text
    .replace(EMAIL, '[email]')
    .replace(LONG_NUMBER, '[number]')
    .replace(PHONE, (m) => (digits(m) >= 7 && digits(m) <= 15 && !/^\d{4}-\d{2}-\d{2}/.test(m) ? '[phone]' : m))
}

/** Deep copy with strings redacted and secret-named keys blanked; `keep` names fields left as they are. */
export function redactValue<T>(value: T, keep: ReadonlySet<string> = new Set()): T {
  const walk = (v: unknown, key?: string): unknown => {
    if (key && SECRET_KEY.test(key)) return v === null || v === undefined ? v : '[redacted]'
    if (key && keep.has(key)) return v
    if (typeof v === 'string') return redactText(v)
    if (Array.isArray(v)) return v.map((x) => walk(x))
    if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v as Record<string, unknown>).map(([k, x]) => [k, walk(x, k)]))
    return v
  }
  return walk(value) as T
}
