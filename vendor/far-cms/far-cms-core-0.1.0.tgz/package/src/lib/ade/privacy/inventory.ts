/**
 * A personal-data inventory: for every table that holds something about a
 * person — what, why, how long, who can see it, and what happens on a
 * "delete my data" request. App-agnostic shape; the host app supplies the
 * entries (Dzidzor: src/lib/privacy/inventory.ts) and everything else —
 * the purge job, the subject export/delete, the privacy-policy table — reads
 * from it.
 */

export type DataKind =
  | 'name'
  | 'email'
  | 'email (hashed)'
  | 'phone'
  | 'postal address'
  | 'IP address (hashed)'
  | 'browser (family only)'
  | 'free text'
  | 'answers to a form'
  | 'payment reference'
  | 'approximate location'
  | 'account id'
  | 'page visited'
  | 'chat messages'
  | 'screenshot'

export type Retention =
  | { kind: 'months'; months: number; configurable?: string }
  | { kind: 'days'; days: number }
  | { kind: 'account'; note: string }
  | { kind: 'legal'; note: string }
  | { kind: 'until-removed'; note: string }

export type SubjectAction =
  /** Rows are deleted. */
  | 'delete'
  /** Personal fields are blanked/replaced; the row stays (e.g. an order total). */
  | 'anonymise'
  /** Kept (a legal reason), only exported. */
  | 'keep'
  /** Not linkable to a person (e.g. anonymous consent choice). */
  | 'not-linkable'

export interface InventoryEntry {
  /** Prisma model name. */
  model: string
  /** Fields holding personal data. */
  fields: readonly string[]
  /** Plain-language category for the privacy-policy table. */
  category: string
  kinds: readonly DataKind[]
  purpose: string
  retention: Retention
  /** Who in the admin can see it. */
  visibleTo: string
  /** How to find a person's rows by email (field name), if at all. */
  subjectEmailField?: string
  onSubjectDelete: SubjectAction
  /** Optional legal basis / note for the policy draft. */
  basis?: string
}

export function retentionText(r: Retention): string {
  switch (r.kind) {
    case 'months':
      return `${r.months} months${r.configurable ? ` (${r.configurable})` : ''}`
    case 'days':
      return `${r.days} days`
    case 'account':
      return `While the account exists — ${r.note}`
    case 'legal':
      return `As long as the law requires — ${r.note}`
    case 'until-removed':
      return `Until removed — ${r.note}`
  }
}

export interface CollectRow {
  category: string
  what: string
  why: string
  howLong: string
  whoSees: string
}

/** The "What we collect" table: one row per category, merged across tables. */
export function whatWeCollect(entries: readonly InventoryEntry[]): CollectRow[] {
  const by = new Map<string, InventoryEntry[]>()
  for (const e of entries) by.set(e.category, [...(by.get(e.category) ?? []), e])
  return [...by.entries()].map(([category, es]) => ({
    category,
    what: [...new Set(es.flatMap((e) => e.kinds))].join(', '),
    why: [...new Set(es.map((e) => e.purpose))].join(' '),
    howLong: [...new Set(es.map((e) => retentionText(e.retention)))].join('; '),
    whoSees: [...new Set(es.map((e) => e.visibleTo))].join('; '),
  }))
}

/** The table as plain text (Markdown) for a privacy-policy draft. */
export function whatWeCollectMarkdown(rows: readonly CollectRow[]): string {
  const esc = (s: string) => s.replace(/\|/g, '\\|').replace(/\n/g, ' ')
  return [
    '| What | Details | Why | How long we keep it | Who can see it |',
    '| --- | --- | --- | --- | --- |',
    ...rows.map((r) => `| ${esc(r.category)} | ${esc(r.what)} | ${esc(r.why)} | ${esc(r.howLong)} | ${esc(r.whoSees)} |`),
  ].join('\n')
}

/** Field names that look personal (for the completeness check). */
export const PERSONAL_FIELD = /^(email|.*Email|phone|.*Phone|firstName|lastName|name|fullName|recipientName|ipAddress|consentIp|userAgent|street1|street2|city|postalCode|zip|guestEmail|reviewerEmail|attendeeEmail|attendeePhone|assignedEmail|customerEmail|purchaserEmail|recipientEmail|billingEmail|actorEmail|authorEmail|createdByEmail|organizerEmail|userEmail|data|content|parts|personalMessage|notes|customerNotes)$/

export interface SchemaModel {
  model: string
  fields: string[]
}

/** Models and their scalar field names from a Prisma schema's text. */
export function modelsFromSchema(schema: string): SchemaModel[] {
  const out: SchemaModel[] = []
  for (const m of schema.matchAll(/^model (\w+) \{([\s\S]*?)^\}/gm)) {
    const fields = m[2]
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('//') && !l.startsWith('@@'))
      .map((l) => l.split(/\s+/))
      .filter((p) => p.length > 1 && /^(String|Json|Bytes)\??(\[\])?$/.test(p[1]))
      .map((p) => p[0])
    out.push({ model: m[1], fields })
  }
  return out
}

/**
 * Personal-looking fields the inventory doesn't account for. `notPersonal`
 * lists model.field pairs judged not about a person (with a reason, in the app).
 */
export function missingFromInventory(models: readonly SchemaModel[], entries: readonly InventoryEntry[], notPersonal: ReadonlySet<string>): string[] {
  const listed = new Set(entries.flatMap((e) => e.fields.map((f) => `${e.model}.${f}`)))
  const out: string[] = []
  for (const m of models) for (const f of m.fields) if (PERSONAL_FIELD.test(f) && !listed.has(`${m.model}.${f}`) && !notPersonal.has(`${m.model}.${f}`) && !notPersonal.has(`${m.model}.*`)) out.push(`${m.model}.${f}`)
  return out
}
