/**
 * User agents, minimised: only the browser family and major version
 * ("Chrome 129", "Safari 17"), never the full fingerprintable string.
 */

const RULES: ReadonlyArray<[RegExp, string]> = [
  [/\b(bot|crawler|spider|slurp|curl|wget|python-requests|httpclient|headless)\b/i, 'Bot'],
  [/\bEdg(?:e|A|iOS)?\/(\d+)/, 'Edge'],
  [/\bOPR\/(\d+)/, 'Opera'],
  [/\bSamsungBrowser\/(\d+)/, 'Samsung Internet'],
  [/\b(?:Firefox|FxiOS)\/(\d+)/, 'Firefox'],
  [/\b(?:Chrome|CriOS)\/(\d+)/, 'Chrome'],
  [/\bVersion\/(\d+)[^ ]* (?:Mobile\/\S+ )?Safari\//, 'Safari'],
]

export function uaFamily(ua: string | null | undefined): string | null {
  if (!ua || !ua.trim()) return null
  for (const [re, name] of RULES) {
    const m = re.exec(ua)
    if (!m) continue
    return name === 'Bot' ? 'Bot' : `${name} ${m[1]}`
  }
  return 'Other'
}

/** Already minimised (what uaFamily returns)? A backfill can then skip it. */
export function isUaFamily(v: string): boolean {
  return /^(Bot|Other|[A-Za-z ]+ \d{1,4})$/.test(v)
}
