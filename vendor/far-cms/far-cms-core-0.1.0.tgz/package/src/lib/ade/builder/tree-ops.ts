/**
 * Layers tree operations for the page builder's left pane (brief 5988ec0c:
 * v0-style Layers). Generic over any node with an id and optional children,
 * so the same code serves the lab's mock tree and real Block[].
 *
 * Pure and immutable: every operation returns a new tree; inputs are never
 * changed. Asserted by tree-ops.assert.ts.
 */

export interface TreeNode {
  id: string
  children?: readonly TreeNode[]
}

// One drop shape for the canvas, Layers and the Library (the builder store's contract).
import type { DropTarget } from '../blocks/builder-tree'
export type { DropTarget } from '../blocks/builder-tree'
export type DropPlace = DropTarget['place']

/** One visible row of the tree (depth-first, collapsed branches skipped). */
export interface TreeRow<N extends TreeNode> {
  node: N
  depth: number
  parentId: string | null
  index: number
  hasChildren: boolean
}

/** The rows the Layers pane shows, in order, skipping the children of collapsed nodes. */
export function visibleRows<N extends TreeNode>(nodes: readonly N[], collapsed: ReadonlySet<string>, depth = 0, parentId: string | null = null): TreeRow<N>[] {
  return nodes.flatMap((node, index) => {
    const kids = (node.children ?? []) as readonly N[]
    const row: TreeRow<N> = { node, depth, parentId, index, hasChildren: kids.length > 0 }
    return collapsed.has(node.id) || !kids.length ? [row] : [row, ...visibleRows(kids, collapsed, depth + 1, node.id)]
  })
}

/** The ids from the root down to `id` (inclusive); [] when absent. */
export function pathTo(nodes: readonly TreeNode[], id: string): string[] {
  for (const n of nodes) {
    if (n.id === id) return [n.id]
    const sub = pathTo(n.children ?? [], id)
    if (sub.length) return [n.id, ...sub]
  }
  return []
}

/** The node with this id, or null. */
export function findNode<N extends TreeNode>(nodes: readonly N[], id: string): N | null {
  for (const n of nodes) {
    if (n.id === id) return n
    const hit = findNode((n.children ?? []) as readonly N[], id)
    if (hit) return hit
  }
  return null
}

/**
 * Collapsed ids with every ancestor of `id` opened — canvas selection reveals its
 * row in the tree (the node itself keeps its own state).
 */
export function expandTo(collapsed: ReadonlySet<string>, nodes: readonly TreeNode[], id: string): Set<string> {
  const ancestors = pathTo(nodes, id).slice(0, -1)
  const next = new Set(collapsed)
  for (const a of ancestors) next.delete(a)
  return next
}

/** A copy of the tree with `fn` applied to the node `id` (unchanged when absent). */
export function updateNode<N extends TreeNode>(nodes: readonly N[], id: string, fn: (n: N) => N): N[] {
  return nodes.map((n) => {
    if (n.id === id) return fn(n)
    if (!n.children?.length) return n
    return { ...n, children: updateNode(n.children as readonly N[], id, fn) }
  })
}

/** The tree without `id` and the removed node (null when absent). */
export function removeNode<N extends TreeNode>(nodes: readonly N[], id: string): { tree: N[]; removed: N | null } {
  let removed: N | null = null
  const walk = (list: readonly N[]): N[] =>
    list.flatMap((n) => {
      if (n.id === id) {
        removed = n
        return []
      }
      return n.children?.length ? [{ ...n, children: walk(n.children as readonly N[]) }] : [n]
    })
  const tree = walk(nodes)
  return { tree, removed }
}

/** `node` placed at the drop target (unchanged tree when the target is missing). */
export function insertAt<N extends TreeNode>(nodes: readonly N[], node: N, drop: DropTarget): N[] {
  if (drop.targetId === null) return [...nodes, node]
  let placed = false
  const walk = (list: readonly N[]): N[] =>
    list.flatMap((n) => {
      if (n.id === drop.targetId) {
        placed = true
        if (drop.place === 'before') return [node, n]
        if (drop.place === 'after') return [n, node]
        return [{ ...n, children: [...((n.children ?? []) as readonly N[]), node] }]
      }
      return n.children?.length ? [{ ...n, children: walk(n.children as readonly N[]) }] : [n]
    })
  const out = walk(nodes)
  return placed ? out : [...nodes]
}

/**
 * Can `id` move to this drop target? Never into itself or its own descendants,
 * and never "inside" a node that can't hold children.
 */
export function canMove(nodes: readonly TreeNode[], id: string, drop: DropTarget, canHold: (targetId: string) => boolean = () => true): boolean {
  if (drop.targetId === null) return true
  if (drop.targetId === id) return false
  if (pathTo(nodes, drop.targetId).includes(id)) return false
  return drop.place !== 'inside' || canHold(drop.targetId)
}

/** Move `id` to the drop target (drag to reorder in Layers). Invalid moves leave the tree as it was. */
export function moveNode<N extends TreeNode>(nodes: readonly N[], id: string, drop: DropTarget, canHold?: (targetId: string) => boolean): N[] {
  if (!canMove(nodes, id, drop, canHold)) return [...nodes]
  const { tree, removed } = removeNode(nodes, id)
  return removed ? insertAt(tree, removed, drop) : [...nodes]
}

/** A display name cleaned for a rename: trimmed, single spaces, at most 60 characters; empty → null (keep the old one). */
export function cleanName(raw: string): string | null {
  const s = raw.replace(/\s+/g, ' ').trim().slice(0, 60)
  return s || null
}

/**
 * Where a MOVE lands, as { parentId, index } in the tree AFTER the node is taken out — what an editor that
 * removes first and then inserts needs (moving down within the same parent must not land one too far).
 */
export function resolveMove(nodes: readonly TreeNode[], id: string, drop: DropTarget): { parentId: string | null; index: number } | null {
  if (!canMove(nodes, id, drop)) return null
  const { tree, removed } = removeNode(nodes, id)
  if (!removed) return null
  if (drop.targetId === null) return { parentId: null, index: tree.length }
  const walk = (list: readonly TreeNode[], parentId: string | null): { parentId: string | null; index: number } | null => {
    for (let i = 0; i < list.length; i++) {
      const n = list[i]
      if (n.id === drop.targetId) return drop.place === 'inside' ? { parentId: n.id, index: n.children?.length ?? 0 } : { parentId, index: drop.place === 'before' ? i : i + 1 }
      const hit = n.children?.length ? walk(n.children, n.id) : null
      if (hit) return hit
    }
    return null
  }
  return walk(tree, null)
}

/** Keyboard reorder (Alt+↑ / Alt+↓): before the previous sibling / after the next one; null at the ends. */
export function siblingMove(nodes: readonly TreeNode[], id: string, dir: 'up' | 'down'): DropTarget | null {
  const path = pathTo(nodes, id)
  if (!path.length) return null
  const parent = path.length > 1 ? findNode(nodes, path[path.length - 2]) : null
  const list = parent ? parent.children ?? [] : nodes
  const i = list.findIndex((n) => n.id === id)
  const j = dir === 'up' ? i - 1 : i + 1
  if (j < 0 || j >= list.length) return null
  return { targetId: list[j].id, place: dir === 'up' ? 'before' : 'after' }
}

/** Keyboard focus in the tree: the next / previous visible row id (stays put at the ends). */
export function stepRow(rowIds: readonly string[], current: string | null, dir: 'up' | 'down'): string | null {
  if (!rowIds.length) return null
  const i = current ? rowIds.indexOf(current) : -1
  if (i < 0) return rowIds[0]
  return rowIds[Math.max(0, Math.min(rowIds.length - 1, dir === 'up' ? i - 1 : i + 1))]
}
