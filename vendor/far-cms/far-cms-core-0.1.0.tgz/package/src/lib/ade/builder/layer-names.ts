/**
 * How a block reads in Layers: a name a person recognises (its own label, its
 * component, else a plain word for its tag) and a kind that picks its icon.
 * Pure; asserted by tree-ops.assert.ts.
 */

export type LayerKind = 'section' | 'box' | 'heading' | 'text' | 'image' | 'video' | 'button' | 'link' | 'list' | 'form' | 'component'

export interface LayerLike {
  tag: string
  label?: string
  componentName?: string
  partialId?: string
  textContent?: string
}

const TAG_WORDS: Readonly<Record<string, string>> = {
  section: 'Section', header: 'Header', footer: 'Footer', main: 'Main', nav: 'Navigation', article: 'Article', aside: 'Sidebar',
  div: 'Box', span: 'Text', p: 'Paragraph', h1: 'Heading 1', h2: 'Heading 2', h3: 'Heading 3', h4: 'Heading 4', h5: 'Heading 5', h6: 'Heading 6',
  img: 'Image', video: 'Video', button: 'Button', a: 'Link', ul: 'List', ol: 'List', li: 'List item', form: 'Form', input: 'Input',
}

/** Tags that can hold other blocks (drop "inside" in Layers and on the canvas). */
export const CONTAINER_TAGS: ReadonlySet<string> = new Set(['section', 'header', 'footer', 'main', 'nav', 'article', 'aside', 'div', 'ul', 'ol', 'li', 'form', 'a', 'button'])

export function layerKind(b: LayerLike): LayerKind {
  if (b.partialId || b.componentName) return 'component'
  const t = b.tag.toLowerCase()
  if (['section', 'header', 'footer', 'main', 'nav', 'article', 'aside'].includes(t)) return 'section'
  if (/^h[1-6]$/.test(t)) return 'heading'
  if (t === 'p' || t === 'span') return 'text'
  if (t === 'img') return 'image'
  if (t === 'video') return 'video'
  if (t === 'button') return 'button'
  if (t === 'a') return 'link'
  if (t === 'ul' || t === 'ol' || t === 'li') return 'list'
  if (t === 'form' || t === 'input') return 'form'
  return 'box'
}

/** The row's name: label → component → a text snippet for text tags → the tag's plain word. */
export function layerName(b: LayerLike): string {
  if (b.label?.trim()) return b.label.trim().slice(0, 60)
  if (b.componentName) return b.componentName.replace(/([a-z])([A-Z])/g, '$1 $2')
  const kind = layerKind(b)
  const text = (b.textContent ?? '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
  if ((kind === 'heading' || kind === 'text' || kind === 'button' || kind === 'link') && text) return text.length > 32 ? `${text.slice(0, 31).trimEnd()}…` : text
  return TAG_WORDS[b.tag.toLowerCase()] ?? b.tag
}

export const canHoldChildren = (b: Pick<LayerLike, 'tag' | 'componentName' | 'partialId'>): boolean => !b.componentName && !b.partialId && CONTAINER_TAGS.has(b.tag.toLowerCase())
