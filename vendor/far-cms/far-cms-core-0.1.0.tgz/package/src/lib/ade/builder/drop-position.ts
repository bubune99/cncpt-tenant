/**
 * Drop-position maths for dragging a block (from the Library onto the canvas,
 * or a row within Layers): where the pointer is → which gap the block goes
 * into, and where to draw the drop indicator. Pure (rects in, answer out);
 * the DOM code only measures. Asserted by drop-position.assert.ts.
 */

import type { DropPlace, DropTarget } from './tree-ops'

export interface Rect {
  top: number
  bottom: number
  left: number
  right: number
}

/** A candidate block on screen: its id, its rect, and whether it can take children. */
export interface Slot {
  id: string
  rect: Rect
  container?: boolean
}

/** The indicator: a horizontal line at `y` across [left, right], or a box around the container being dropped into. */
export type Indicator =
  | { kind: 'line'; y: number; left: number; right: number }
  | { kind: 'box'; rect: Rect }

export interface DropAnswer {
  drop: DropTarget
  indicator: Indicator
}

/** The middle band of a container (as a share of its height) that means "inside" rather than before/after. */
export const INSIDE_BAND = 0.5

/**
 * Which gap a pointer at `y` means among sibling blocks laid out top to bottom.
 * - Above the first block's middle → before it; below the last's middle → after it.
 * - Over a container's middle band → inside it (when `allowInside`).
 * - Otherwise the nearer edge of the block under (or nearest to) the pointer.
 * Empty list → the end of the root list.
 */
export function dropAt(slots: readonly Slot[], y: number, opts: { allowInside?: boolean } = {}): DropAnswer {
  const list = [...slots].sort((a, b) => a.rect.top - b.rect.top)
  if (!list.length) return { drop: { targetId: null, place: 'after' }, indicator: { kind: 'line', y, left: 0, right: 0 } }
  // The block under the pointer, else the nearest one by vertical distance.
  const under = list.find((s) => y >= s.rect.top && y <= s.rect.bottom)
  const slot = under ?? list.reduce((best, s) => (distance(s.rect, y) < distance(best.rect, y) ? s : best), list[0])
  const { top, bottom } = slot.rect
  const h = Math.max(1, bottom - top)
  const rel = (y - top) / h
  if (opts.allowInside && slot.container && under && Math.abs(rel - 0.5) <= INSIDE_BAND / 2) {
    return { drop: { targetId: slot.id, place: 'inside' }, indicator: { kind: 'box', rect: slot.rect } }
  }
  const place: DropPlace = rel < 0.5 ? 'before' : 'after'
  return { drop: { targetId: slot.id, place }, indicator: lineFor(list, slot, place) }
}

function distance(r: Rect, y: number): number {
  return y < r.top ? r.top - y : y > r.bottom ? y - r.bottom : 0
}

/** The line sits in the gap: halfway between this block and its neighbour on that side (or on the edge at the ends). */
function lineFor(list: readonly Slot[], slot: Slot, place: DropPlace): Indicator {
  const i = list.indexOf(slot)
  const left = Math.min(...list.map((s) => s.rect.left))
  const right = Math.max(...list.map((s) => s.rect.right))
  if (place === 'before') {
    const prev = list[i - 1]
    return { kind: 'line', y: prev ? (prev.rect.bottom + slot.rect.top) / 2 : slot.rect.top, left, right }
  }
  const next = list[i + 1]
  return { kind: 'line', y: next ? (slot.rect.bottom + next.rect.top) / 2 : slot.rect.bottom, left, right }
}

/** A Layers row drop: top quarter → before, bottom quarter → after, middle → inside (when the row can hold children). */
export function rowDropPlace(rowTop: number, rowHeight: number, y: number, canHold: boolean): DropPlace {
  const rel = (y - rowTop) / Math.max(1, rowHeight)
  if (!canHold) return rel < 0.5 ? 'before' : 'after'
  return rel < 0.25 ? 'before' : rel > 0.75 ? 'after' : 'inside'
}

/** Click or keyboard insert: after the selected block, else at the end. */
export function insertAfterSelection(selectedId: string | null): DropTarget {
  return selectedId ? { targetId: selectedId, place: 'after' } : { targetId: null, place: 'after' }
}
