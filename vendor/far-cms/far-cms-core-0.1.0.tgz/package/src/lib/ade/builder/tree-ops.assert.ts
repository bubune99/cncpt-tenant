/** Layers tree operations + drop-position maths. Run: npx -y tsx@4.23.15 src/lib/ade/builder/tree-ops.assert.ts */
import assert from 'node:assert/strict'
import { canMove, cleanName, resolveMove, siblingMove, stepRow, expandTo, findNode, insertAt, moveNode, pathTo, removeNode, updateNode, visibleRows, type TreeNode } from './tree-ops'
import { dropAt, insertAfterSelection, rowDropPlace, type Slot } from './drop-position'
import { canHoldChildren, layerKind, layerName } from './layer-names'
import { resolveDrop } from '../blocks/builder-tree'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

interface B extends TreeNode { id: string; name: string; children?: B[] }
const tree: B[] = [
  { id: 'header', name: 'Header', children: [{ id: 'nav', name: 'Nav' }] },
  { id: 'main', name: 'Main', children: [{ id: 'hero', name: 'Hero', children: [{ id: 'h1', name: 'Title' }] }, { id: 'about', name: 'About' }] },
  { id: 'footer', name: 'Footer' },
]
const ids = (t: readonly B[]): string[] => t.flatMap((x) => [x.id, ...ids(x.children ?? [])])
const frozen = JSON.stringify(tree)

check('rows: depth-first, collapsed branches hidden; parent and index kept', () => {
  const rows = visibleRows(tree, new Set(['header']))
  assert.deepEqual(rows.map((r) => `${'-'.repeat(r.depth)}${r.node.id}`), ['header', 'main', '-hero', '--h1', '-about', 'footer'])
  assert.equal(rows.find((r) => r.node.id === 'about')?.parentId, 'main')
  assert.equal(rows.find((r) => r.node.id === 'about')?.index, 1)
  assert.equal(rows[0].hasChildren, true)
})

check('canvas selection reveals its row: ancestors open, path and find', () => {
  assert.deepEqual(pathTo(tree, 'h1'), ['main', 'hero', 'h1'])
  assert.deepEqual(pathTo(tree, 'nope'), [])
  assert.deepEqual([...expandTo(new Set(['main', 'hero', 'header']), tree, 'h1')], ['header'])
  assert.equal(findNode(tree, 'about')?.name, 'About')
})

check('rename (double-click): cleaned; empty keeps the old name; immutable', () => {
  assert.equal(cleanName('  Big   hero  '), 'Big hero')
  assert.equal(cleanName('   '), null)
  assert.equal(cleanName('x'.repeat(80))?.length, 60)
  const renamed = updateNode(tree, 'hero', (b) => ({ ...b, name: 'Big hero' }))
  assert.equal(findNode(renamed, 'hero')?.name, 'Big hero')
  assert.equal(JSON.stringify(tree), frozen, 'the input tree is unchanged')
})

check('reorder (drag in Layers): before / after / inside; never into itself or a descendant', () => {
  assert.deepEqual(ids(moveNode(tree, 'footer', { targetId: 'header', place: 'before' })), ['footer', 'header', 'nav', 'main', 'hero', 'h1', 'about'])
  assert.deepEqual(ids(moveNode(tree, 'nav', { targetId: 'about', place: 'after' })), ['header', 'main', 'hero', 'h1', 'about', 'nav', 'footer'])
  assert.deepEqual(ids(moveNode(tree, 'footer', { targetId: 'hero', place: 'inside' })), ['header', 'nav', 'main', 'hero', 'h1', 'footer', 'about'])
  assert.equal(canMove(tree, 'main', { targetId: 'h1', place: 'after' }), false, 'not into its own descendant')
  assert.equal(canMove(tree, 'main', { targetId: 'main', place: 'before' }), false)
  assert.deepEqual(ids(moveNode(tree, 'main', { targetId: 'h1', place: 'inside' })), ids(tree), 'an invalid move changes nothing')
  assert.equal(canMove(tree, 'footer', { targetId: 'h1', place: 'inside' }, (id) => id !== 'h1'), false, 'a leaf takes no children')
  assert.equal(JSON.stringify(tree), frozen)
})

check('insert (Library drop / click): at the target, or the end; a missing target changes nothing', () => {
  const card: B = { id: 'cta', name: 'Call to action' }
  assert.deepEqual(ids(insertAt(tree, card, { targetId: 'about', place: 'after' })), ['header', 'nav', 'main', 'hero', 'h1', 'about', 'cta', 'footer'])
  assert.deepEqual(ids(insertAt(tree, card, { targetId: null, place: 'after' })).slice(-1), ['cta'])
  assert.deepEqual(ids(insertAt(tree, card, { targetId: 'ghost', place: 'after' })), ids(tree))
  assert.equal(removeNode(tree, 'hero').removed?.id, 'hero')
  assert.deepEqual(insertAfterSelection('about'), { targetId: 'about', place: 'after' })
  assert.deepEqual(insertAfterSelection(null), { targetId: null, place: 'after' })
})

const r = (top: number, bottom: number) => ({ top, bottom, left: 0, right: 800 })
const slots: Slot[] = [
  { id: 'hero', rect: r(0, 400), container: true },
  { id: 'about', rect: r(420, 620) },
  { id: 'footer', rect: r(640, 700) },
]

check('drop on the canvas: the gap under the pointer, with the line between blocks', () => {
  assert.deepEqual(dropAt(slots, 10).drop, { targetId: 'hero', place: 'before' })
  assert.deepEqual(dropAt(slots, 10).indicator, { kind: 'line', y: 0, left: 0, right: 800 })
  assert.deepEqual(dropAt(slots, 600).drop, { targetId: 'about', place: 'after' })
  assert.deepEqual(dropAt(slots, 600).indicator, { kind: 'line', y: 630, left: 0, right: 800 }, 'halfway between about and footer')
  assert.deepEqual(dropAt(slots, 410).drop, { targetId: 'hero', place: 'after' }, 'in the gap: the nearest block’s edge')
  assert.deepEqual(dropAt(slots, 900).drop, { targetId: 'footer', place: 'after' }, 'below everything → after the last')
  assert.deepEqual(dropAt([...slots].reverse(), 600).drop, { targetId: 'about', place: 'after' }, 'order-independent')
  assert.deepEqual(dropAt([], 50).drop, { targetId: null, place: 'after' })
})

check('drop inside a container: its middle band, box indicator — only when allowed', () => {
  assert.deepEqual(dropAt(slots, 200, { allowInside: true }).drop, { targetId: 'hero', place: 'inside' })
  assert.equal(dropAt(slots, 200, { allowInside: true }).indicator.kind, 'box')
  assert.deepEqual(dropAt(slots, 200).drop, { targetId: 'hero', place: 'after' }, 'off by default')
  assert.deepEqual(dropAt(slots, 520, { allowInside: true }).drop.place, 'after', 'not a container')
})

check('Layers row drop: quarters for before/after, middle for inside (only rows that hold children)', () => {
  assert.equal(rowDropPlace(100, 24, 102, true), 'before')
  assert.equal(rowDropPlace(100, 24, 112, true), 'inside')
  assert.equal(rowDropPlace(100, 24, 122, true), 'after')
  assert.equal(rowDropPlace(100, 24, 112, false), 'after')
  assert.equal(rowDropPlace(100, 24, 105, false), 'before')
})

check('a move resolves in the tree WITHOUT the moved node (remove-then-insert editors): down within a parent lands right', () => {
  const flat: B[] = [{ id: 'a', name: 'A' }, { id: 'b', name: 'B' }, { id: 'c', name: 'C' }]
  assert.deepEqual(resolveMove(flat, 'a', { targetId: 'b', place: 'after' }), { parentId: null, index: 1 }, 'a after b → [b, a, c]')
  assert.deepEqual(resolveDrop(flat, { targetId: 'b', place: 'after' }), { parentId: null, index: 2 }, 'resolveDrop counts a, so remove-then-insert would give [b, c, a]')
  assert.deepEqual(resolveMove(flat, 'c', { targetId: 'a', place: 'before' }), { parentId: null, index: 0 })
  assert.deepEqual(resolveMove(tree, 'footer', { targetId: 'hero', place: 'inside' }), { parentId: 'hero', index: 1 })
  assert.equal(resolveMove(tree, 'main', { targetId: 'h1', place: 'after' }), null, 'never into itself')
  // Same result as the pure moveNode.
  const viaIndex = (t0: B[], id: string, at: { targetId: string | null; place: 'before' | 'after' | 'inside' }) => ids(moveNode(t0, id, at))
  assert.deepEqual(viaIndex(flat, 'a', { targetId: 'b', place: 'after' }), ['b', 'a', 'c'])
})

check('keyboard: Alt+arrows move among siblings; arrows step through visible rows', () => {
  assert.deepEqual(siblingMove(tree, 'about', 'up'), { targetId: 'hero', place: 'before' })
  assert.deepEqual(siblingMove(tree, 'header', 'down'), { targetId: 'main', place: 'after' })
  assert.equal(siblingMove(tree, 'header', 'up'), null)
  assert.equal(siblingMove(tree, 'h1', 'down'), null, 'only child')
  const rowIds = ['header', 'main', 'hero', 'about', 'footer']
  assert.equal(stepRow(rowIds, 'hero', 'down'), 'about')
  assert.equal(stepRow(rowIds, 'header', 'up'), 'header')
  assert.equal(stepRow(rowIds, null, 'down'), 'header')
})

check('layer names and kinds: label, component, text snippet, else a plain word', () => {
  assert.equal(layerName({ tag: 'section', label: 'Hero' }), 'Hero')
  assert.equal(layerName({ tag: 'div', componentName: 'ProductGrid' }), 'Product Grid')
  assert.equal(layerName({ tag: 'h2', textContent: 'Our <b>impact</b> in the Volta Region this year' }), 'Our impact in the Volta Region…')
  assert.equal(layerName({ tag: 'div' }), 'Box')
  assert.equal(layerName({ tag: 'custom-x' }), 'custom-x')
  assert.equal(layerKind({ tag: 'header' }), 'section')
  assert.equal(layerKind({ tag: 'img' }), 'image')
  assert.equal(layerKind({ tag: 'div', partialId: 'p1' }), 'component')
  assert.equal(canHoldChildren({ tag: 'section' }), true)
  assert.equal(canHoldChildren({ tag: 'img' }), false)
  assert.equal(canHoldChildren({ tag: 'div', componentName: 'ProductGrid' }), false)
})

console.log(`\n${n} checks passed`)
