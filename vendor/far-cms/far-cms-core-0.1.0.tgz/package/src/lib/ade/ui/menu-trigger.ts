/**
 * The ☰ menu trigger's words (owner: "Menu hamburger could possibly say
 * menu and the Forms would become bold for page location"):
 *   "☰ Menu · **Forms**"  — the section is the breadcrumb's section crumb
 *   "☰ Menu"              — when no section is known
 * The accessible name and tooltip say the same in a sentence. Pure;
 * asserted by menu-trigger.assert.ts.
 */

import { SHORTCUTS, keyLabel, type KeyPlatform } from './keys'

export interface MenuTriggerLabel {
  /** Bold part after "Menu · ", or null. */
  section: string | null
  /** Accessible name. */
  ariaLabel: string
  /** Tooltip (kept when the trigger collapses to the icon). */
  title: string
}

export function menuTrigger(section: string | null | undefined, opts: { open?: boolean; platform?: KeyPlatform } = {}): MenuTriggerLabel {
  const s = section?.trim() ? section.trim().replace(/\s+/g, ' ') : null
  if (opts.open) return { section: s, ariaLabel: 'Close menu', title: 'Close menu' }
  const ariaLabel = s ? `Open menu — current section: ${s}` : 'Open menu'
  const k = keyLabel(SHORTCUTS.menu, opts.platform ?? 'other')
  return { section: s, ariaLabel, title: s ? `${ariaLabel} (${k})` : `Open menu (${k})` }
}
