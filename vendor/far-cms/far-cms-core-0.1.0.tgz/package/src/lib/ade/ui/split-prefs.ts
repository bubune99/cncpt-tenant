/**
 * Remembered divider positions, per divider per person (server-side prefs).
 *
 * Each divider declares its panels, a default layout and clamps (percent of
 * the group). A saved layout is only accepted when it names exactly those
 * panels, sums to ~100 and sits inside the clamps — anything else falls back
 * to the default, so a stale or hand-edited pref can never break a screen.
 */

export type SplitLayout = Record<string, number>

export interface DividerSpec {
  panels: readonly string[]
  defaults: SplitLayout
  /** Percent clamps per panel. */
  min: SplitLayout
  max: SplitLayout
}

export const DIVIDERS = {
  /** Chat ↕ editing tools in the assistant column. */
  'agent.tools': { panels: ['chat', 'tools'], defaults: { chat: 55, tools: 45 }, min: { chat: 20, tools: 20 }, max: { chat: 80, tools: 80 } },
  /** To-do list | detail. */
  'todo.list': { panels: ['list', 'detail'], defaults: { list: 30, detail: 70 }, min: { list: 20, detail: 35 }, max: { list: 65, detail: 80 } },
  /** Page editor | the tools tray under it. */
  'editor.tray': { panels: ['canvas', 'tray'], defaults: { canvas: 70, tray: 30 }, min: { canvas: 40, tray: 15 }, max: { canvas: 85, tray: 60 } },
  /** Page editor | the tools placed right of the page (owner 2026-10-19). */
  'editor.right': { panels: ['page', 'right'], defaults: { page: 72, right: 28 }, min: { page: 45, right: 16 }, max: { page: 84, right: 55 } },
  /** To-do board | detail. */
  'todo.board': { panels: ['board', 'detail'], defaults: { board: 58, detail: 42 }, min: { board: 30, detail: 25 }, max: { board: 75, detail: 70 } },
  /** Form builder: the form ↕ the selected field's properties. */
  'forms.field': { panels: ['canvas', 'props'], defaults: { canvas: 62, props: 38 }, min: { canvas: 30, props: 18 }, max: { canvas: 82, props: 70 } },
  /** Submissions list | detail. */
  'forms.inbox': { panels: ['list', 'detail'], defaults: { list: 60, detail: 40 }, min: { list: 35, detail: 25 }, max: { list: 75, detail: 65 } },
  /** Record page canvas ↕ its Details panel (records). */
  'record.details': { panels: ['canvas', 'details'], defaults: { canvas: 62, details: 38 }, min: { canvas: 30, details: 18 }, max: { canvas: 82, details: 70 } },
  /** Blog post canvas ↕ its Details panel. */
  'post.details': { panels: ['canvas', 'details'], defaults: { canvas: 62, details: 38 }, min: { canvas: 30, details: 18 }, max: { canvas: 82, details: 70 } },
} as const satisfies Record<string, DividerSpec>

export type DividerKey = keyof typeof DIVIDERS

export function isDividerKey(k: unknown): k is DividerKey {
  return typeof k === 'string' && Object.prototype.hasOwnProperty.call(DIVIDERS, k)
}

/** A safe layout for `key`: the saved one when valid, else the default. */
export function normalizeSplitLayout(key: DividerKey, layout: unknown): SplitLayout {
  const spec: DividerSpec = DIVIDERS[key]
  if (!layout || typeof layout !== 'object') return { ...spec.defaults }
  const entries = Object.entries(layout as Record<string, unknown>)
  if (entries.length !== spec.panels.length) return { ...spec.defaults }
  const out: SplitLayout = {}
  for (const id of spec.panels) {
    const v = (layout as Record<string, unknown>)[id]
    if (typeof v !== 'number' || !Number.isFinite(v)) return { ...spec.defaults }
    if (v < spec.min[id] - 0.5 || v > spec.max[id] + 0.5) return { ...spec.defaults }
    out[id] = Math.round(v * 100) / 100
  }
  const sum = Object.values(out).reduce((a, b) => a + b, 0)
  return Math.abs(sum - 100) <= 1 ? out : { ...spec.defaults }
}

/** The saved map with one divider updated (unknown keys dropped). */
export function withSplit(map: unknown, key: DividerKey, layout: unknown): Record<string, SplitLayout> {
  const base = (map && typeof map === 'object' ? map : {}) as Record<string, unknown>
  const next: Record<string, SplitLayout> = {}
  for (const [k, v] of Object.entries(base)) if (isDividerKey(k) && k !== key) next[k] = normalizeSplitLayout(k, v)
  next[key] = normalizeSplitLayout(key, layout)
  return next
}

export function splitsFrom(map: unknown): Record<string, SplitLayout> {
  const base = (map && typeof map === 'object' ? map : {}) as Record<string, unknown>
  const out: Record<string, SplitLayout> = {}
  for (const [k, v] of Object.entries(base)) if (isDividerKey(k)) out[k] = normalizeSplitLayout(k, v)
  return out
}
