/**
 * The menu entry that best matches a path (longest prefix; /admin only
 * exact). Pure and app-agnostic — the mega menu and the action bar's
 * breadcrumb both use it. Asserted via lib/admin-nav-access.assert.ts.
 */

export interface MatchableGroup<I extends { href: string } = { href: string; name: string }> {
  items: ReadonlyArray<I>
}

export function matchMenuItem<I extends { href: string }>(groups: ReadonlyArray<MatchableGroup<I>>, pathname: string | null): I | null {
  if (!pathname) return null
  let best: I | null = null
  for (const g of groups)
    for (const i of g.items) {
      const hit = i.href === '/admin' ? pathname === '/admin' : pathname === i.href || pathname.startsWith(`${i.href}/`)
      if (hit && (!best || i.href.length > best.href.length)) best = i
    }
  return best
}
