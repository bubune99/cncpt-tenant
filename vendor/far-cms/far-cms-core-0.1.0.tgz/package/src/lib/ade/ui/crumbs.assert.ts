/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/crumbs.assert.ts
 */
import assert from 'node:assert/strict'
import { resolveCrumbs } from './crumbs'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const initiatives = { label: 'Initiatives', href: '/admin/records/initiative' }
const menuRecords = { name: 'Initiatives', href: '/admin/records' }

check('a screen that knows its parent is right on the first render (menu not loaded)', () => {
  assert.deepEqual(resolveCrumbs({ title: 'Test initiative (temp)', parent: initiatives, matched: null, menuReady: false }), [
    { label: 'Initiatives', href: '/admin/records/initiative' },
    { label: 'Test initiative (temp)' },
  ])
})

check('never "Admin" while the menu is still loading', () => {
  const c = resolveCrumbs({ title: 'Test initiative (temp)', parent: null, matched: null, menuReady: false })
  assert.deepEqual(c, [{ label: 'Test initiative (temp)' }])
  assert.deepEqual(resolveCrumbs({ title: null, parent: null, matched: null, menuReady: false }), [])
})

check('the menu match is used when there is no declared parent', () => {
  assert.deepEqual(resolveCrumbs({ title: 'About', parent: null, matched: { name: 'Pages', href: '/admin/pages' }, menuReady: true }), [
    { label: 'Pages', href: '/admin/pages' },
    { label: 'About' },
  ])
})

check('a renamed menu item keeps its new name over the screen’s default label', () => {
  const c = resolveCrumbs({ title: 'Test post (temp)', parent: { label: 'Blog', href: '/admin/blog' }, matched: { name: 'News', href: '/admin/blog' }, menuReady: true })
  assert.deepEqual(c[0], { label: 'News', href: '/admin/blog' })
  // …and the parent's own (deeper) link is kept.
  assert.deepEqual(resolveCrumbs({ title: 'X', parent: initiatives, matched: menuRecords, menuReady: true })[0], { label: 'Initiatives', href: '/admin/records/initiative' })
})

check('a parent elsewhere than the menu match wins (header editor → Settings)', () => {
  const c = resolveCrumbs({ title: 'Header', parent: { label: 'Settings', href: '/admin/settings' }, matched: { name: 'Dashboard', href: '/admin' }, menuReady: true })
  assert.deepEqual(c, [{ label: 'Settings', href: '/admin/settings' }, { label: 'Header' }])
})

check('a screen outside the menu shows only its title — never "Admin ›"', () => {
  assert.deepEqual(resolveCrumbs({ title: 'Tours', parent: null, matched: null, menuReady: true }), [{ label: 'Tours' }])
  assert.deepEqual(resolveCrumbs({ title: 'Odd screen', parent: null, matched: null, menuReady: true }), [{ label: 'Odd screen' }])
  // The fallback alone only when there's no title at all (and the menu has loaded).
  assert.deepEqual(resolveCrumbs({ title: null, parent: null, matched: null, menuReady: true }), [{ label: 'Admin' }])
  assert.deepEqual(resolveCrumbs({ title: null, parent: null, matched: null, menuReady: false }), [])
  for (const t of ['Tours', 'Workflows', 'Plugins']) {
    const c = resolveCrumbs({ title: t, parent: null, matched: null, menuReady: true })
    assert.ok(!c.some((x) => x.label === 'Admin'), t)
  }
  assert.deepEqual(resolveCrumbs({ title: null, parent: null, matched: { name: 'Media', href: '/admin/media' }, menuReady: true }), [{ label: 'Media' }])
  assert.deepEqual(resolveCrumbs({ title: 'Media', parent: null, matched: { name: 'Media', href: '/admin/media' }, menuReady: true }), [{ label: 'Media' }])
})

check('a list titled like its menu item shows one crumb, whatever the case', () => {
  assert.deepEqual(resolveCrumbs({ title: 'Email marketing', parent: null, matched: { name: 'Email Marketing', href: '/admin/email-marketing' }, menuReady: true }), [{ label: 'Email marketing' }])
  assert.deepEqual(resolveCrumbs({ title: 'Users', parent: null, matched: { name: 'Users', href: '/admin/users' }, menuReady: true }), [{ label: 'Users' }])
})

console.log(`\n${n} checks passed`)
