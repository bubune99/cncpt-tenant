/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/split-prefs.assert.ts
 */
import assert from 'node:assert/strict'
import { normalizeSplitLayout, splitsFrom, withSplit } from './split-prefs'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('a valid saved layout is kept; garbage falls back to the default', () => {
  assert.deepEqual(normalizeSplitLayout('todo.list', { list: 40, detail: 60 }), { list: 40, detail: 60 })
  assert.deepEqual(normalizeSplitLayout('todo.list', null), { list: 30, detail: 70 })
  assert.deepEqual(normalizeSplitLayout('todo.list', { list: 'x', detail: 60 }), { list: 30, detail: 70 })
  assert.deepEqual(normalizeSplitLayout('todo.list', { list: 40, other: 60 }), { list: 30, detail: 70 })
  assert.deepEqual(normalizeSplitLayout('todo.list', { list: 40, detail: 60, extra: 1 }), { list: 30, detail: 70 })
})

check('clamps: outside min/max or not summing to 100 is refused', () => {
  assert.deepEqual(normalizeSplitLayout('todo.list', { list: 5, detail: 95 }), { list: 30, detail: 70 })
  assert.deepEqual(normalizeSplitLayout('agent.tools', { chat: 50, tools: 30 }), { chat: 55, tools: 45 })
  assert.deepEqual(normalizeSplitLayout('agent.tools', { chat: 49.996, tools: 50.004 }), { chat: 50, tools: 50 })
})

check('one divider updates without touching the others; unknown keys are dropped', () => {
  const m = withSplit({ 'todo.board': { board: 60, detail: 40 }, junk: { a: 1 } }, 'todo.list', { list: 35, detail: 65 })
  assert.deepEqual(m, { 'todo.board': { board: 60, detail: 40 }, 'todo.list': { list: 35, detail: 65 } })
  assert.deepEqual(splitsFrom({ junk: 1, 'agent.tools': { chat: 70, tools: 30 } }), { 'agent.tools': { chat: 70, tools: 30 } })
})

check('form builder dividers: field properties and the submissions inbox', () => {
  assert.deepEqual(normalizeSplitLayout('forms.field', { canvas: 70, props: 30 }), { canvas: 70, props: 30 })
  assert.deepEqual(normalizeSplitLayout('forms.field', { canvas: 95, props: 5 }), { canvas: 62, props: 38 })
  assert.deepEqual(normalizeSplitLayout('forms.inbox', null), { list: 60, detail: 40 })
})

console.log(`\n${n} checks passed`)
