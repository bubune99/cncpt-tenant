/**
 * The action bar's breadcrumb, decided in one place. Pure; asserted by
 * crumbs.assert.ts. App-agnostic: the host passes the open screen's title,
 * the parent the screen declared (WorkspaceTitle `parent`), the menu item the
 * path matches, and whether the menu has loaded yet.
 *
 * Rules:
 *   - A screen that knows its parent wins from the first render (no waiting
 *     for the menu). If the menu later matches the same place, its label is
 *     used (so a renamed menu item shows its new name).
 *   - No declared parent → the matched menu item.
 *   - Nothing matched yet because the menu hasn't loaded → NO section crumb
 *     (never the generic fallback while a real answer is pending).
 *   - Menu loaded and still nothing (a screen that isn't in the menu) →
 *     ONLY the title; the fallback ("Admin") alone only when there's no
 *     title either. Never "Admin › <title>".
 */

export interface Crumb {
  label: string
  href?: string
}

export interface CrumbInput {
  title: string | null
  parent: { label: string; href: string } | null
  matched: { name: string; href: string } | null
  /** The menu has loaded (permissions resolved); an empty menu means "not yet". */
  menuReady: boolean
  fallback?: string
}

const sameLabel = (a: string, b: string) => a.trim().replace(/\s+/g, ' ').toLowerCase() === b.trim().replace(/\s+/g, ' ').toLowerCase()

function under(href: string, base: string): boolean {
  return href === base || href.startsWith(`${base}/`) || href.startsWith(`${base}?`)
}

/**
 * The section you're in — the breadcrumb's linked section crumb (also the
 * ☰ menu trigger's "Menu · <section>"). null when nothing is known.
 */
export function crumbSection({ parent, matched }: Pick<CrumbInput, 'parent' | 'matched'>): Crumb | null {
  if (parent) return matched && matched.href !== '/admin' && under(parent.href, matched.href) ? { label: matched.name, href: parent.href } : { label: parent.label, href: parent.href }
  if (matched) return { label: matched.name, href: matched.href }
  return null
}

export function resolveCrumbs({ title, parent, matched, menuReady, fallback = 'Admin' }: CrumbInput): Crumb[] {
  const section = crumbSection({ parent, matched })

  if (!section) return title ? [{ label: title }] : menuReady ? [{ label: fallback }] : []
  // A list screen titled like its menu item ("Email Marketing" vs "Email marketing") is one crumb — the screen's own title.
  if (title && sameLabel(title, section.label)) return [{ label: title }]
  return title ? [section, { label: title }] : [{ label: section.label }]
}
