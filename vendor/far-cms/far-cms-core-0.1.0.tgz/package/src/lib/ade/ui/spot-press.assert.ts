/** Executable checks for the spotlight press contract. Run: pnpm console:spot-press */
import assert from 'node:assert/strict'

import { autoplayMayAdvance, escapeDismisses, pressOutcome } from './spot-press'

let n = 0
const eq = <T>(a: T, b: T, m: string) => { assert.deepEqual(a, b, m); n++ }

// the card
eq(pressOutcome({ region: 'card' }), 'keep', 'a press on the card is the card’s own: nothing underneath changes')
eq(pressOutcome({ region: 'card', persistent: true }), 'keep', 'in a persistent walk too')

// the highlighted thing
eq(pressOutcome({ region: 'target' }), 'pass', 'pressing the highlighted thing just works as normal when nothing was asked of you')
eq(pressOutcome({ region: 'target', clickToContinue: true }), 'advance', 'when the step asked for the click, it also moves the walk on')
eq(pressOutcome({ region: 'target', clickToContinue: true, last: true }), 'finish', 'on the last step it ends the walk')
eq(pressOutcome({ region: 'target', clickToContinue: false, last: true }), 'pass', 'a look-only last step is not ended by pressing it')

// anywhere else
eq(pressOutcome({ region: 'outside' }), 'dismiss', 'the first press outside dismisses the spotlight and card')
eq(pressOutcome({ region: 'outside', clickToContinue: true }), 'dismiss', 'even when the step asked for a click')
eq(pressOutcome({ region: 'outside', persistent: true }), 'ignore', 'a persistent walk is not dismissed by a press outside')

// keys and the clock
eq(escapeDismisses(false), true, 'Escape dismisses a normal walk')
eq(escapeDismisses(true), false, 'but not a persistent one')
eq(autoplayMayAdvance({ clickToContinue: true }), false, 'the countdown never moves on a step that waits for your click')
eq(autoplayMayAdvance({}), true, 'but does move on an ordinary step')
eq(autoplayMayAdvance(undefined), true, 'and a missing step is not blocked')

console.log(`spot press assertions passed: ${n} checks`)
