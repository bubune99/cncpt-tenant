/**
 * The visibility policy (lib/ade/governance/visibility) as the screen tools
 * apply it, in the browser, before anything leaves the page:
 *  - a blocked screen returns only that it is private (and why);
 *  - metadata-only keeps the layout (labels, roles, counts), never values;
 *  - data-ade-private markers follow their field rule for the viewer's role
 *    (an unknown marker is metadata-only);
 *  - every refusal or mask is reported in the output's `blocked` list
 *    (labels only) so agent activity and the audit log record it.
 *
 * Pure. Asserted with Dzidzor's rules in lib/ade-bindings/view-policy.assert.ts
 */

import { BLOCKED_GUIDANCE, blockedResult, matchField, resolveField, resolveRoute, type Resolution, type ViewerRole, type Visibility, type VisibilityRule } from '../governance/visibility'
import type { AreaAccess, PrivacyArea } from '../governance/access'

export interface ViewPolicy {
  role: ViewerRole
  rules: readonly VisibilityRule[]
  /** Protected areas (with the owner's switches) and this person's access to them. */
  areas?: readonly PrivacyArea[]
  access?: readonly AreaAccess[]
}

/**
 * Which privacy markers may reach the model as raw text: only areas whose
 * "Assistant follows the person" switch is on (agentByDefault) AND whose
 * assistant access is readable for this person. Everything else that is
 * readable by the rules is still redacted like any tool output — the safer
 * default (lead/owner, 2026-10-11). Unknown → redact.
 */
export function showRawFor(policy: ViewPolicy): (marker: string) => boolean {
  const open = (policy.areas ?? []).filter((a) => a.agentByDefault && policy.access?.find((x) => x.area === a.id)?.agent === 'readable')
  return (marker) => open.some((a) => a.targets.some((t) => t.kind === 'field' && matchField(t.name, marker)))
}

/** What agent activity records about a refusal (lib/ade/observability blockedFromOutput). */
export interface ViewReport {
  mode: 'blocked' | 'masked' | 'metadata-only'
  target: string
  fields?: string[]
  reason?: string
}

export { BLOCKED_GUIDANCE }

/** The screen's level: pathname + search, so ?section=mcp is matched. */
export function screenLevel(policy: ViewPolicy, url: string): Resolution {
  return resolveRoute(policy.rules, url, policy.role)
}

/** A privacy marker's level for this viewer; markers no rule names stay private (metadata-only). */
export function markerLevel(policy: ViewPolicy): (marker: string) => Visibility {
  return (marker) => {
    const known = policy.rules.some((r) => r.target.kind === 'field' && matchField(r.target.name, marker))
    return known ? resolveField(policy.rules, marker, policy.role).level : 'metadata-only'
  }
}

/** The whole answer for a blocked screen: nothing about it but that it's private. */
export function blockedScreen(res: Resolution, what: string, route: string) {
  const b = blockedResult(res.rule, what || 'This screen')
  return {
    ok: false as const,
    private: true as const,
    route,
    reason: b.reason,
    canGuide: b.canGuide,
    message: b.message,
    // `blocked` is the agent-activity report list (observability blockedFromOutput).
    blocked: [{ mode: 'blocked', target: what || route, reason: b.reason }] as ViewReport[],
  }
}

/** One withheld thing as the screen reader notes it (lib/ade/ui/view-units MaskNote). */
export interface MaskNoteLike {
  target: string
  field: string
  marker?: string
  kind: 'policy' | 'redaction'
}

/**
 * Reports for a read that was allowed but masked, grouped by place and
 * reason: { mode: 'masked', target: 'Submissions', fields: ['Email'],
 * reason: 'pii.contact' }. A marker's reason is its rule id for this viewer;
 * redaction (emails/phones redacted like any tool output) is 'redaction'.
 * Empty when nothing was withheld. At most 20 (agent activity's cap).
 */
export function maskReports(res: Resolution | null, what: string, notes: readonly MaskNoteLike[], policy: ViewPolicy | null = null): ViewReport[] {
  const out: ViewReport[] = []
  if (res?.level === 'metadata-only') out.push({ mode: 'metadata-only', target: what, ...(res.rule ? { reason: res.rule.id } : {}) })
  const reasonOf = (n: MaskNoteLike): string => {
    if (n.kind === 'redaction') return 'redaction'
    if (n.marker && policy) {
      const r = resolveField(policy.rules, n.marker, policy.role)
      if (r.rule) return r.rule.id
      return 'private-marker'
    }
    return res?.rule?.id ?? 'policy'
  }
  const groups = new Map<string, ViewReport & { fields: string[] }>()
  for (const n of notes) {
    const reason = reasonOf(n)
    const key = `${n.target}\u0000${reason}`
    const g = groups.get(key) ?? { mode: 'masked' as const, target: n.target, fields: [], reason }
    if (!g.fields.includes(n.field) && g.fields.length < 20) g.fields.push(n.field)
    groups.set(key, g)
  }
  return [...out, ...groups.values()].slice(0, 20)
}

/** Until the rules load (or if they can't), the strictest view: floor + defaults as staff. */
export function fallbackPolicy(floor: readonly VisibilityRule[], defaults: readonly VisibilityRule[]): ViewPolicy {
  return { role: 'staff', rules: [...floor, ...defaults] }
}
