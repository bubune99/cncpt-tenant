/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/admin-theme.assert.ts
 */
import assert from 'node:assert/strict'
import { contrast } from './color'
import { ADMIN_THEMES, BRAND_SCHEME, SCHEMES, adminThemeCss, checkScheme, componentTokens, normalizeChoice, schemeTokens, normalizeAdminThemeId, resolveAdminTheme, type AdminTheme } from './admin-theme'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('colour maths: known WCAG pairs', () => {
  assert.ok(Math.abs(contrast('#ffffff', '#000000') - 21) < 0.01)
  assert.ok(Math.abs(contrast('oklch(1 0 0)', 'oklch(0 0 0)') - 21) < 0.05)
  assert.ok(Math.abs(contrast('#777777', '#ffffff') - 4.48) < 0.05)
})

check('EVERY scheme × mode × high-contrast passes WCAG AA (Studio theme)', () => {
  for (const s of [...SCHEMES.map((x) => x.id)]) {
    for (const mode of ['light', 'dark'] as const) {
      for (const hc of [false, true]) {
        const r = checkScheme({ scheme: s, highContrast: hc }, mode, ADMIN_THEMES.studio)
        assert.ok(r.ok, `${s} ${mode}${hc ? ' HC' : ''}: ${r.checks.filter((c) => c.ratio < c.need).map((c) => `${c.what} ${c.ratio.toFixed(2)} < ${c.need}`).join('; ')}`)
      }
    }
  }
})

check('"Match my brand" passes for light, dark and very light/very dark brand colours', () => {
  for (const brand of ['#022b39', '#088cbc', '#ffd23f', '#d88535', 'oklch(0.29 0.05 235)', '#ffffff', '#000000']) {
    for (const mode of ['light', 'dark'] as const) {
      for (const hc of [false, true]) {
        const r = checkScheme({ scheme: BRAND_SCHEME, highContrast: hc }, mode, ADMIN_THEMES.studio, brand)
        assert.ok(r.ok, `${brand} ${mode}${hc ? ' HC' : ''}`)
      }
    }
  }
})

check('the Atlas theme is just another definition and passes too', () => {
  for (const s of SCHEMES.map((x) => x.id)) for (const mode of ['light', 'dark'] as const) assert.ok(checkScheme({ scheme: s, highContrast: false }, mode, ADMIN_THEMES.atlas).ok, `atlas ${s} ${mode}`)
  const css = adminThemeCss(ADMIN_THEMES.atlas, { scheme: 'neutral', highContrast: false })
  // No monospace (owner, 2026-10-24): Atlas eyebrows are uppercase sans, weight 600, tracked.
  assert.doesNotMatch(css, /mono/i)
  assert.match(css, /--admin-eyebrow-transform:uppercase;--admin-eyebrow-weight:600;--admin-eyebrow-tracking:0\.08em/)
})

check('only accent-bearing tokens change (layout/type untouched)', () => {
  const allowed = new Set(['--primary', '--primary-foreground', '--ring', '--sidebar-primary', '--sidebar-primary-foreground', '--accent', '--muted', '--sidebar', '--border', '--input', '--muted-foreground'])
  for (const s of SCHEMES) for (const mode of ['light', 'dark'] as const) for (const hc of [false, true]) {
    for (const k of Object.keys(schemeTokens({ scheme: s.id, highContrast: hc }, mode))) assert.ok(allowed.has(k), `${s.id}: ${k}`)
  }
  // Neutral without HC changes nothing at all (the Studio look).
  assert.deepEqual(schemeTokens({ scheme: 'neutral', highContrast: false }, 'light'), {})
})

check('stored choices are validated', () => {
  assert.deepEqual(normalizeChoice({ scheme: 'violet', highContrast: true }), { scheme: 'violet', highContrast: true })
  assert.deepEqual(normalizeChoice({ scheme: 'neon' }), { scheme: 'neutral', highContrast: false })
  assert.deepEqual(normalizeChoice(null, { scheme: 'blue', highContrast: false }), { scheme: 'blue', highContrast: false })
})

check('the theme comes from settings, else the APP default id (the library assumes none)', () => {
  assert.equal(resolveAdminTheme('atlas', 'studio').id, 'atlas')
  assert.equal(resolveAdminTheme('nope', 'atlas').id, 'atlas')
  assert.equal(resolveAdminTheme(undefined, 'studio').id, 'studio')
  assert.equal(resolveAdminTheme('nope', 'also-nope').id, Object.keys(ADMIN_THEMES)[0])
  assert.equal(normalizeAdminThemeId(42, 'atlas'), 'atlas')
  assert.equal(resolveAdminTheme('__proto__', 'studio').id, 'studio')
})

const SPOT_TOKENS = ['--spot-scrim', '--spot-ring', '--spot-card-bg', '--spot-card-fg', '--spot-card-border', '--spot-radius', '--spot-ask-bg']

check('design-system component: every theme × mode emits the spotlight tokens, mapped to the theme', () => {
  for (const theme of Object.values(ADMIN_THEMES)) {
    for (const mode of ['light', 'dark'] as const) {
      const css = adminThemeCss(theme, { scheme: 'neutral', highContrast: false })
      for (const t of SPOT_TOKENS) assert.ok(css.includes(`${t}:`), `${theme.id} ${mode} lacks ${t}`)
      const tok = componentTokens(theme, mode)
      assert.equal(tok['--spot-card-bg'], 'var(--popover)', 'card follows the theme (light and dark)')
      assert.equal(tok['--spot-ask-bg'], 'var(--muted)')
    }
  }
  // Dark gets its own scrim; light and dark both live in the stylesheet.
  const css = adminThemeCss(ADMIN_THEMES.studio, { scheme: 'neutral', highContrast: false })
  assert.ok(/:root\{[^}]*--spot-scrim:rgb\(15 23 42 \/ 0\.42\)/.test(css) && /\.dark\{[^}]*--spot-scrim:rgb\(0 0 0 \/ 0\.55\)/.test(css))
})

check('a theme can restyle the spotlight (design-system switch)', () => {
  const custom: AdminTheme = { ...ADMIN_THEMES.studio, id: 'x', components: { spot: { light: { '--spot-card-bg': 'oklch(0.97 0.02 85)' } } } }
  assert.equal(componentTokens(custom, 'light')['--spot-card-bg'], 'oklch(0.97 0.02 85)')
  assert.equal(componentTokens(custom, 'dark')['--spot-card-bg'], 'var(--popover)', 'only what it overrides')
})

console.log(`\n${n} checks passed`)
