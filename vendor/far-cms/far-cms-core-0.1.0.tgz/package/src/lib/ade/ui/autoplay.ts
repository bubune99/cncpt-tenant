/**
 * Autoplay for a walkthrough: steps advance by themselves so a person can watch without clicking, with a countdown.
 * Pure and app-agnostic (no React, no DOM, no clock): the caller feeds it elapsed time, so every rule here can be asserted.
 * Shared by every app that has an assistant; each app stores the `Pace` setting and passes it in.
 *
 * Rules, in the order a person would notice them:
 *   - how long a step stays is set by PACE: reading time (the default), a fixed number of seconds, or reading time with
 *     a floor ("at least N seconds"). Most specific wins: the step's own `seconds`, then the walkthrough's pace, then the
 *     app's default pace. The person's speed (0.75x to 1.5x) applies on top of all of them.
 *   - hovering or focusing the card, a hidden tab, or pressing Pause freezes the countdown (a moving target that
 *     cannot be stopped is not acceptable)
 *   - Back and Next restart the countdown on the new step and keep autoplay as it was
 *   - the last step is held, never closed for you: the person chooses Replay or Got it
 */

export const MIN_DWELL_MS = 4500
export const MAX_DWELL_MS = 14000
const BASE_MS = 2200
export const SPEEDS = [1, 1.5, 0.75] as const

/** A fixed time is never shorter than can be read, nor long enough to look like a hang. */
export const MIN_SECONDS = 2
export const MAX_SECONDS = 60
export const MIN_WPM = 100
export const MAX_WPM = 400

export type PaceMethod = 'reading' | 'fixed' | 'floor'

/**
 * How long steps stay. The setting every app stores (admin-editable) and every walkthrough may override.
 *   reading  by the amount of text (the default)
 *   fixed    exactly `seconds`
 *   floor    reading time, but never less than `seconds`
 */
export interface Pace {
  method: PaceMethod
  seconds: number
  wordsPerMinute: number
}

export const DEFAULT_PACE: Pace = { method: 'reading', seconds: 5, wordsPerMinute: 200 }

export interface StepText {
  title?: string
  sentence?: string
  /** This step's own fixed time. Beats every pace. */
  seconds?: number
}

const words = (s: string | undefined) => (s ? s.trim().split(/\s+/).filter(Boolean).length : 0)
const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n))
const num = (v: unknown, fallback: number) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback)

/** Anything stored or received is untrusted: a bad value becomes the default, an out-of-range one is clamped. */
export function sanitizePace(input: unknown): Pace {
  const o = (input && typeof input === 'object' ? input : {}) as Partial<Record<keyof Pace, unknown>>
  const method: PaceMethod = o.method === 'fixed' || o.method === 'floor' || o.method === 'reading' ? o.method : DEFAULT_PACE.method
  return {
    method,
    seconds: clamp(num(o.seconds, DEFAULT_PACE.seconds), MIN_SECONDS, MAX_SECONDS),
    wordsPerMinute: clamp(num(o.wordsPerMinute, DEFAULT_PACE.wordsPerMinute), MIN_WPM, MAX_WPM),
  }
}

/** Reading time for a step at a reading speed, kept within sensible bounds. */
export function readingMs(step: StepText, wordsPerMinute: number = DEFAULT_PACE.wordsPerMinute): number {
  const perWord = 60000 / clamp(wordsPerMinute, MIN_WPM, MAX_WPM)
  return Math.round(clamp(BASE_MS + (words(step.title) + words(step.sentence)) * perWord, MIN_DWELL_MS, MAX_DWELL_MS))
}

/**
 * How long a step stays, in ms, at the person's speed. Precedence: the step's own `seconds`, then the walkthrough's pace
 * (when the assistant or author set one), then the app's default pace.
 */
export function dwellMs(step: StepText, speed: number = 1, pace: Pace = DEFAULT_PACE): number {
  const p = sanitizePace(pace)
  let ms: number
  if (typeof step.seconds === 'number' && Number.isFinite(step.seconds)) ms = clamp(step.seconds, MIN_SECONDS, MAX_SECONDS) * 1000
  else if (p.method === 'fixed') ms = p.seconds * 1000
  else if (p.method === 'floor') ms = Math.max(readingMs(step, p.wordsPerMinute), p.seconds * 1000)
  else ms = readingMs(step, p.wordsPerMinute)
  return Math.round(ms / (speed > 0 ? speed : 1))
}

export interface PlayState {
  index: number
  total: number
  /** Time spent on this step, at the current speed's scale (compared with its dwell). */
  elapsed: number
  /** The person's choice: playing or paused. */
  playing: boolean
  /** Frozen right now by hover, focus or a hidden tab. Not a choice, so it does not change `playing`. */
  held: boolean
  /** The last step has had its time; waiting for Replay or Got it. */
  done: boolean
  speed: number
}

export type PlayEvent =
  | { type: 'tick'; dt: number }
  | { type: 'play' }
  | { type: 'pause' }
  | { type: 'hold'; held: boolean }
  | { type: 'next' }
  | { type: 'prev' }
  | { type: 'goto'; index: number }
  | { type: 'replay' }
  | { type: 'speed'; speed: number }

export function initial(total: number, opts: { autoplay: boolean; reducedMotion?: boolean; speed?: number }): PlayState {
  // Someone who asked their system for less motion gets a still walkthrough unless they press Play.
  const playing = opts.autoplay && total > 1 && !opts.reducedMotion
  return { index: 0, total, elapsed: 0, playing, held: false, done: false, speed: opts.speed ?? 1 }
}

const clampIndex = (i: number, total: number) => Math.max(0, Math.min(total - 1, i))

export function reduce(s: PlayState, e: PlayEvent, dwellAt: (index: number) => number): PlayState {
  switch (e.type) {
    case 'tick': {
      if (!s.playing || s.held || s.done || s.total < 1 || !(e.dt > 0)) return s
      const elapsed = s.elapsed + e.dt
      if (elapsed < dwellAt(s.index)) return { ...s, elapsed }
      if (s.index < s.total - 1) return { ...s, index: s.index + 1, elapsed: 0 }
      return { ...s, elapsed: dwellAt(s.index), done: true }
    }
    case 'play':
      // Pressing Play after the end starts it again; otherwise it just resumes where it was.
      return s.done ? { ...s, index: 0, elapsed: 0, done: false, playing: true } : { ...s, playing: true }
    case 'pause':
      return { ...s, playing: false }
    case 'hold':
      return s.held === e.held ? s : { ...s, held: e.held }
    case 'next':
      return { ...s, index: clampIndex(s.index + 1, s.total), elapsed: 0, done: false }
    case 'prev':
      return { ...s, index: clampIndex(s.index - 1, s.total), elapsed: 0, done: false }
    case 'goto':
      return { ...s, index: clampIndex(e.index, s.total), elapsed: 0, done: false }
    case 'replay':
      return { ...s, index: 0, elapsed: 0, done: false, playing: true }
    case 'speed':
      return e.speed > 0 ? { ...s, speed: e.speed } : s
  }
}

/** 0 to 1: how far through the current step the countdown is. */
export const progress = (s: PlayState, dwell: number): number => (dwell > 0 ? Math.min(1, Math.max(0, s.elapsed / dwell)) : 0)

/** Whole seconds left on this step, for a quiet "Next in 4s". */
export const secondsLeft = (s: PlayState, dwell: number): number => Math.max(0, Math.ceil((dwell - s.elapsed) / 1000))

/** The next speed in the cycle 1x, 1.5x, 0.75x. */
export const nextSpeed = (speed: number): number => SPEEDS[(SPEEDS.indexOf(speed as (typeof SPEEDS)[number]) + 1) % SPEEDS.length] ?? 1
