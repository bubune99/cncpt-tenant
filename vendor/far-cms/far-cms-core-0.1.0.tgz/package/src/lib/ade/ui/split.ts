/**
 * Split-pane ratio rules — pure. The agent pane's share of the width.
 */

/**
 * The assistant column is sized by what the CMS needs (owner, smaller screens):
 * clamp(320px, 30vw, 480px); 340px below 1280px; a slide-over below 1100px
 * (the CMS gets the full width); a bottom sheet on phones.
 */
export const DEFAULT_SPLIT_RATIO = 0.3
export const MIN_AGENT_PX = 320
export const MAX_AGENT_PX = 480
export const NARROW_AGENT_PX = 340
export const OVERLAY_BELOW = 1100
export const NARROW_BELOW = 1280
/** Phones (lib/ade/mobile PHONE_BELOW): the assistant is always a pull-up sheet there. */
export const SHEET_BELOW = 768
/** The CMS never gets narrower than this when the person widens the assistant. */
export const MIN_CMS_PX = 560
// Wide enough a range that a drag reaches 320px on a 3440px screen and the
// CMS minimum on a laptop (the pixel limits below do the real clamping).
export const MIN_SPLIT_RATIO = 0.05
export const MAX_SPLIT_RATIO = 0.7

/** Clamp a stored or dragged ratio; anything unusable falls back to the default. */
export function clampSplitRatio(value: unknown): number {
  const n = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN
  if (!Number.isFinite(n)) return DEFAULT_SPLIT_RATIO
  return Math.min(MAX_SPLIT_RATIO, Math.max(MIN_SPLIT_RATIO, n))
}

/** Ratio from a pointer position inside a container of `width` px. */
export function ratioFromPointer(pointerX: number, containerLeft: number, width: number): number {
  if (width <= 0) return DEFAULT_SPLIT_RATIO
  return clampSplitRatio((pointerX - containerLeft) / width)
}

export type AgentLayoutMode = 'column' | 'overlay' | 'sheet'

/**
 * Home / End on the divider (the separator pattern): Home = the narrowest assistant (320px),
 * End = the widest that still leaves the CMS MIN_CMS_PX. Null for any other key.
 */
export function keyWidthEdge(key: string, viewportPx: number): number | null {
  if (key === 'Home') return MIN_AGENT_PX
  if (key === 'End') return Math.max(MIN_AGENT_PX, Math.round(viewportPx - MIN_CMS_PX))
  return null
}

/** A width the person dragged to, as stored: a sane pixel number, or null (never chose). */
export function clampAgentWidth(value: unknown): number | null {
  const n = typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN
  if (!Number.isFinite(n)) return null
  return Math.round(Math.min(4000, Math.max(MIN_AGENT_PX, n)))
}

/**
 * Where the assistant sits for a viewport width, and how much room the CMS
 * keeps. `chosenPx` = the width the person dragged the divider to (pixels):
 * honoured from 320px up to leaving the CMS MIN_CMS_PX. Without a choice the
 * default applies: clamp(320, 30vw, 480), 340 below 1280. (A ratio-based
 * choice froze the divider on wide screens and old stored ratios came back
 * huge, so choices are pixels and old ratios don't count as choices.)
 */
export function agentLayout(
  viewportWidth: number,
  chosenPx: number | null = null,
  /** The app's default before anyone drags (share of the viewport, capped); the CMS keeps MIN_CMS_PX either way. */
  defaults: { ratio?: number; maxPx?: number } = {},
): { mode: AgentLayoutMode; width: number; offset: number } {
  const vw = Math.max(0, Math.round(viewportWidth))
  if (vw < SHEET_BELOW) return { mode: 'sheet', width: vw, offset: 0 }
  if (vw < OVERLAY_BELOW) {
    const width = Math.min(420, vw - 48)
    return { mode: 'overlay', width, offset: 0 }
  }
  const chosen = clampAgentWidth(chosenPx)
  const width = chosen !== null
    ? Math.min(Math.max(MIN_AGENT_PX, vw - MIN_CMS_PX), chosen)
    : vw < NARROW_BELOW
      ? NARROW_AGENT_PX
      : Math.round(
          Math.min(
            defaults.maxPx ?? MAX_AGENT_PX,
            Math.max(MIN_AGENT_PX, vw - MIN_CMS_PX),
            Math.max(MIN_AGENT_PX, (defaults.ratio ?? DEFAULT_SPLIT_RATIO) * vw),
          ),
        )
  return { mode: 'column', width, offset: width }
}

/**
 * Whether entering a slide-over/sheet width closes the assistant. Shrinking from a column closes it
 * (the CMS gets the screen), and so does an open state restored from storage at load. An assistant
 * opened during this page's life (a press of Assistant or Open workspace) stays open: at 1068px the
 * first press after a load used to close itself at once (staging 2026-11-17).
 */
export function closesOnFloating(s: { split: boolean; floating: boolean; phoneShell: boolean; prev: AgentLayoutMode | null; openedThisPage: boolean }): boolean {
  if (!s.split || !s.floating || s.phoneShell) return false
  return s.prev === 'column' || (s.prev === null && !s.openedThisPage)
}
