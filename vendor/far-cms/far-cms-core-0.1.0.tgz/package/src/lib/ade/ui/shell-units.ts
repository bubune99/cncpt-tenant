/**
 * Shell units: the admin chrome around the screen — the sidebar, the ☰ menu
 * and the top bar — as things the assistant can point at in every layout.
 *
 * The assistant points at one layout-free selector per thing:
 *   [data-ui="shell.nav.<href>"]  a menu section (the sidebar link or the ☰ entry)
 *   [data-ui="shell.top.<id>"]    a top-bar control (the app lists them, ShellUnit)
 * and code does the rest (aimShellSpot): it picks the element this layout
 * shows and says what to open first — the ☰ menu, the classic drawer, a
 * collapsed sidebar group, or the bar's More menu. The highlight never
 * navigates.
 *
 * Pure and app-agnostic (the app passes its top-bar units). Asserted by
 * shell-units.assert.ts.
 */

/**
 * sidebar = Classic with the sidebar shown; drawer = Classic on a narrow
 * window (the sidebar slides in from ☰); menu = the workspace's ☰ menu, no
 * sidebar; phone = the phone shell (handled by lib/ade/mobile/phone-map).
 */
export type ShellLayout = 'sidebar' | 'drawer' | 'menu' | 'phone'

/** What code opens before the spot can show. */
export type ShellReveal =
  | { kind: 'menu' }
  | { kind: 'drawer'; group?: string }
  | { kind: 'group'; group: string }
  | { kind: 'more' }

/** Where a top-bar control lives in one layout: its selector, and the menu it sits in, if any. */
export interface ShellPlace {
  selector: string
  inside?: 'menu' | 'drawer' | 'more'
}

/** A top-bar control the app registers (lib/ade-bindings/shell-units). */
export interface ShellUnit {
  /** Stable id ("todo"); the assistant points at [data-ui="shell.top.<id>"]. */
  id: string
  /** Its name on screen ("To-do"). */
  label: string
  /** Places tried in order: the first one on screen wins, else the first inside a menu (opened first). */
  places: Partial<Record<Exclude<ShellLayout, 'phone'>, ReadonlyArray<ShellPlace>>>
}

export interface ShellMenuGroup {
  name: string
  items: ReadonlyArray<{ name: string; href: string }>
}

/** The chrome as it is right now (components/ade/shell-spots reads it from the page). */
export interface ShellSnapshot {
  layout: ShellLayout
  menuOpen: boolean
  drawerOpen: boolean
  /** The menu this person sees (permissions, features and relabels applied). */
  groups: ReadonlyArray<ShellMenuGroup>
  /** Menu hrefs rendered in the page right now (a collapsed sidebar group renders none). */
  rendered: ReadonlyArray<string>
  /** Top-bar selectors visible right now (registry selectors only). */
  shown: ReadonlyArray<string>
}

/** The window event the shell listens to (AdminShell: drawer + groups; the ☰ menu: itself). */
export const SHELL_REVEAL_EVENT = 'ade:shell-reveal'
/** The spot that needed it has ended: close what SHELL_REVEAL_EVENT opened (only if code opened it). */
export const SHELL_CONCEAL_EVENT = 'ade:shell-conceal'

export const SHELL_NAV_PREFIX = 'shell.nav.'
export const SHELL_TOP_PREFIX = 'shell.top.'

/** The data-ui value a menu link carries ("shell.nav./admin/media"). */
export const shellNavId = (href: string) => `${SHELL_NAV_PREFIX}${normHref(href)}`
export const shellNavSelector = (href: string) => `[data-ui="${shellNavId(href)}"]`
export const shellTopSelector = (id: string) => `[data-ui="${SHELL_TOP_PREFIX}${id}"]`

function normHref(p: string): string {
  return (p.split(/[?#]/)[0].replace(/\/+$/, '') || '/').toLowerCase()
}

/**
 * The menu section a selector means: the shell form, the sidebar's
 * [data-tour-id="nav-x"], or a link / nav-rail button to an admin path.
 * Anything else: null.
 */
export function shellHrefFromSelector(target: string): string | null {
  const t = target.trim()
  const shell = /^\[data-ui=["']?shell\.nav\.(\/admin[^"'\]\s]*)["']?\]$/i.exec(t)
  if (shell) return normHref(shell[1])
  const tour = /^\[data-tour-id=["']?nav-([a-z0-9-]+)["']?\]$/i.exec(t)
  if (tour) return tour[1] === 'dashboard' ? '/admin' : `/admin/${tour[1].toLowerCase()}`
  const href = /^(?:a|button)?\[(?:href|data-agent-nav-path)=["']?(\/admin[^"'\]\s]*)["']?\]$/i.exec(t)
  if (href) return normHref(href[1])
  return null
}

/** The menu item (and its group) for an href: exact, else the item whose first path segment matches (nav-x ids). */
function findItem(groups: ReadonlyArray<ShellMenuGroup>, href: string): { group: string; href: string; name: string } | null {
  const want = normHref(href)
  for (const g of groups) for (const i of g.items) if (normHref(i.href) === want) return { group: g.name, href: normHref(i.href), name: i.name }
  const seg = want.split('/')[2]
  if (!seg) return null
  for (const g of groups) for (const i of g.items) if (normHref(i.href).split('/')[2] === seg) return { group: g.name, href: normHref(i.href), name: i.name }
  return null
}

function topUnitFor(target: string, units: ReadonlyArray<ShellUnit>): ShellUnit | null {
  const t = target.trim()
  const m = /^\[data-ui=["']?shell\.top\.([\w-]+)["']?\]$/i.exec(t)
  if (m) return units.find((u) => u.id === m[1]) ?? null
  // A real selector of a registered control (the model copied one) is that control too.
  return units.find((u) => Object.values(u.places).some((ps) => ps?.some((p) => p.selector === t))) ?? null
}

export interface ShellAim {
  /** The element to ring in this layout. */
  target: string
  /** What to open first; null when it is already on screen. */
  reveal: ShellReveal | null
  /** Its name on screen, for the card's title when the agent gave none. */
  name: string
}

/**
 * A spot aimed at the chrome, for this layout: the element to ring and what
 * to open first. Not a chrome selector, a phone, a section this person
 * doesn't have, or a control this layout lacks: null (left as it is, so the
 * spotlight says honestly that it isn't there).
 */
export function aimShellSpot(target: string, snap: ShellSnapshot, units: ReadonlyArray<ShellUnit>): ShellAim | null {
  if (snap.layout === 'phone') return null
  const href = shellHrefFromSelector(target)
  if (href) {
    const item = findItem(snap.groups, href)
    if (!item) return null
    const selector = shellNavSelector(item.href)
    const rendered = snap.rendered.map(normHref).includes(item.href)
    let reveal: ShellReveal | null = null
    if (snap.layout === 'menu') reveal = snap.menuOpen ? null : { kind: 'menu' }
    else if (snap.layout === 'drawer') reveal = !snap.drawerOpen ? { kind: 'drawer', ...(rendered ? {} : { group: item.group }) } : rendered ? null : { kind: 'group', group: item.group }
    else reveal = rendered ? null : { kind: 'group', group: item.group }
    return { target: selector, reveal, name: item.name }
  }
  const unit = topUnitFor(target, units)
  if (!unit) return null
  const places = unit.places[snap.layout] ?? []
  const onScreen = places.find((p) => snap.shown.includes(p.selector))
  if (onScreen) return { target: onScreen.selector, reveal: null, name: unit.label }
  const tucked = places.find((p) => p.inside)
  if (!tucked) return null
  const open = tucked.inside === 'menu' ? snap.menuOpen : tucked.inside === 'drawer' ? snap.drawerOpen : false
  return { target: tucked.selector, reveal: open ? null : { kind: tucked.inside! }, name: unit.label }
}

// ── What the assistant is told ───────────────────────────────────────

const LAYOUT_WORDS: Record<ShellLayout, string> = {
  sidebar: 'Classic: the sidebar menu is on the left',
  drawer: 'Classic on a narrow window: the sidebar is behind the ☰ Menu button',
  menu: 'Workspace: no sidebar; every section is in the ☰ Menu at the top left',
  phone: 'Phone: bottom tabs, no sidebar',
}

export interface ShellPictureOptions {
  /** Size cap for the whole bundle (characters). */
  maxChars: number
}

/**
 * The "where things are" bundle: the layout, then the menu's sections and
 * the top bar by name, each marked shown or hidden (and where it is hidden).
 * Names and paths only; capped.
 */
export function shellPicture(snap: ShellSnapshot, units: ReadonlyArray<ShellUnit>, opts: ShellPictureOptions): string {
  const lines = [`Layout: ${LAYOUT_WORDS[snap.layout]}.`]
  if (snap.layout !== 'phone') {
    const rendered = new Set(snap.rendered.map(normHref))
    const hiddenIn = snap.layout === 'menu' ? (snap.menuOpen ? '' : 'in the closed ☰ menu') : snap.layout === 'drawer' && !snap.drawerOpen ? 'behind ☰' : ''
    const sections = snap.groups.map((g) => {
      const anyShown = g.items.some((i) => rendered.has(normHref(i.href)))
      const where = hiddenIn || (anyShown ? '' : 'group collapsed')
      return `${g.name}${where ? ` (${where})` : ''}: ${g.items.map((i) => `${i.name} ${normHref(i.href)}`).join(', ')}`
    })
    if (sections.length) lines.push(`Menu sections — point with [data-ui="shell.nav.<path>"]:`, ...sections.map((s) => `- ${s}`))
    const top = units.flatMap((u) => {
      const places = u.places[snap.layout as Exclude<ShellLayout, 'phone'>] ?? []
      if (!places.length) return []
      const shown = places.some((p) => snap.shown.includes(p.selector))
      const tucked = places.find((p) => p.inside)
      const state = shown ? 'shown' : tucked ? `in ${tucked.inside === 'more' ? 'More' : tucked.inside === 'menu' ? 'the ☰ menu' : 'the drawer'}` : 'not shown now'
      return [`${u.label} (${u.id}, ${state})`]
    })
    if (top.length) lines.push(`Top bar — point with [data-ui="shell.top.<id>"]: ${top.join('; ')}.`)
  }
  return clipLines(lines, opts.maxChars)
}

/** Whole lines up to the cap, then "…". */
export function clipLines(lines: ReadonlyArray<string>, max: number): string {
  const out: string[] = []
  let size = 0
  for (const l of lines) {
    if (size + l.length + 1 > max) {
      out.push('…')
      break
    }
    out.push(l)
    size += l.length + 1
  }
  return out.join('\n')
}
