/**
 * What a platform-manager-only screen (the viewport harness) shows while it
 * finds out who you are. Pure; asserted by harness-gate.assert.ts.
 *
 * "Only for platform managers" is said only when permissions
 * actually loaded and say no — never while they load, and never when the
 * check itself failed (e.g. the permissions endpoint is rate-limited after
 * many quick loads): then it's "couldn't check", with a retry.
 */

export type GateState = 'loading' | 'error' | 'denied' | 'allowed'

export function gateState(p: { isLoading: boolean; error: unknown; allowed: boolean }): GateState {
  if (p.isLoading) return 'loading'
  if (p.allowed) return 'allowed'
  if (p.error) return 'error'
  return 'denied'
}
