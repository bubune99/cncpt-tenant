/**
 * Preview sizes (/admin/viewport-harness): the sizing and scaling rules for
 * showing one admin screen at real device sizes, scaled to fit the window.
 * Pure; asserted by preview-sizes.assert.ts.
 *
 * A size's height may be null: "as tall as the space allows" (in fit mode the
 * frame then fills the stage at whatever scale its width needs).
 */

export const PREVIEW_SIZES_PATH = '/admin/viewport-harness'

/** The admin shell steps aside on this page (full-bleed; the real admin runs in its frames). */
export function isPreviewSizesPath(pathname: string | null | undefined): boolean {
  return pathname === PREVIEW_SIZES_PATH || pathname === `${PREVIEW_SIZES_PATH}/`
}

export interface PreviewSize {
  w: number
  h: number | null
}

export type DeviceId = 'phone' | 'tablet' | 'laptop' | 'desktop' | 'wide'

export const DEVICES: ReadonlyArray<{ id: DeviceId; label: string; w: number; h: number }> = [
  { id: 'phone', label: 'Phone', w: 390, h: 844 },
  { id: 'tablet', label: 'Tablet', w: 820, h: 1180 },
  { id: 'laptop', label: 'Laptop', w: 1068, h: 772 },
  { id: 'desktop', label: 'Desktop', w: 1920, h: 1080 },
  { id: 'wide', label: 'Wide', w: 2560, h: 1440 },
]

export const MIN_SIZE = { w: 320, h: 480 } as const
export const MAX_SIZE = { w: 3840, h: 2400 } as const
export const MAX_FRAMES = 8
/** Zoom: 'fit' scales to the stage; a number is a fixed scale (1 = 100%, the stage scrolls). */
export type Zoom = 'fit' | number

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n))

/** Keeps a custom size within 320×480 … 3840×2400 (a null height stays "fill"). */
export function clampSize(s: PreviewSize): PreviewSize {
  return { w: Math.round(clamp(s.w, MIN_SIZE.w, MAX_SIZE.w)), h: s.h === null ? null : Math.round(clamp(s.h, MIN_SIZE.h, MAX_SIZE.h)) }
}

/** Which device a size is, else 'custom'. */
export function deviceFor(s: PreviewSize): DeviceId | 'custom' {
  const d = DEVICES.find((x) => x.w === s.w && (s.h === null || x.h === s.h))
  return d ? d.id : 'custom'
}

/** Stage box available to frames (px, after padding). */
export interface Box {
  w: number
  h: number
}

/** Scale that fits one frame in the box, never above 100%. */
export function fitScale(s: PreviewSize, box: Box): number {
  const byW = box.w / s.w
  const byH = s.h === null ? Infinity : box.h / s.h
  return clamp(Math.min(1, byW, byH), 0.05, 1)
}

/**
 * Several frames side by side at one shared scale (so they compare honestly):
 * their widths plus the gaps share the box width; explicit heights must fit
 * the box height less each frame's label.
 */
export function multiFitScale(sizes: ReadonlyArray<PreviewSize>, box: Box, gap: number, labelH: number): number {
  if (sizes.length === 0) return 1
  const totalW = sizes.reduce((sum, s) => sum + s.w, 0)
  const byW = (box.w - gap * (sizes.length - 1)) / totalW
  const tallest = Math.max(0, ...sizes.map((s) => s.h ?? 0))
  const byH = tallest > 0 ? (box.h - labelH) / tallest : Infinity
  return clamp(Math.min(1, byW, byH), 0.05, 1)
}

/** The frame's real (unscaled) height: its own, or whatever fills the box at this scale. */
export function frameHeight(s: PreviewSize, boxH: number, scale: number): number {
  if (s.h !== null) return s.h
  return Math.round(clamp(boxH / scale, MIN_SIZE.h, MAX_SIZE.h))
}

/** Dragging a frame edge by a screen-pixel delta at a given scale (keyboard nudges use scale 1). */
export function resizeBy(s: PreviewSize, axis: 'w' | 'h', deltaScreen: number, scale: number, currentH: number): PreviewSize {
  const d = deltaScreen / scale
  return axis === 'w' ? clampSize({ w: s.w + d, h: s.h }) : clampSize({ w: s.w, h: (s.h ?? currentH) + d })
}

/**
 * A page of this site: admin screens and the public site (same origin only —
 * a path, never a URL or //host), but not APIs, build files, or this page
 * inside itself. Anything else: the admin home.
 */
export function safePreviewPath(path: string | null | undefined): string {
  const p = (path ?? '').trim()
  const samePage = /^\/(?![\/\\])[^\s\\]*$/.test(p)
  const notAPage = /^\/(?:api|_next)(?:[/?#]|$)/i.test(p) || p.startsWith(PREVIEW_SIZES_PATH)
  return samePage && !notAPage ? p : '/admin'
}

export interface PreviewState {
  path: string
  sizes: PreviewSize[]
  zoom: Zoom
  /** Show spotlights / walk-throughs inside the frames (default on; ?spot=0 turns it off). */
  spots?: boolean
}

/**
 * URL params → initial state. Back-compatible with the old harness:
 *   path=/admin/todo  w=1068x772,1920x1080  scale=0.4
 * `w` items may also be a bare width ("1068") meaning "fill the height".
 * No `w` → one laptop-width frame filling the stage.
 */
export function parsePreviewParams(get: (k: string) => string | null): PreviewState {
  const sizes = (get('w') ?? '')
    .split(',')
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean)
    .map((item) => {
      const [w, h] = item.split('x').map(Number)
      return { w, h: h === undefined ? null : h }
    })
    .filter((s) => Number.isFinite(s.w) && s.w > 0 && (s.h === null || (Number.isFinite(s.h) && s.h > 0)))
    .map(clampSize)
    .slice(0, MAX_FRAMES)
  const rawScale = get('scale')
  const scale = rawScale === null || rawScale === '' ? NaN : Number(rawScale)
  return {
    path: safePreviewPath(get('path')),
    sizes: sizes.length > 0 ? sizes : [{ w: 1068, h: null }],
    zoom: Number.isFinite(scale) && scale > 0 ? clamp(scale, 0.1, 1) : 'fit',
    spots: get('spot') !== '0',
  }
}

/** State → query string, so the address bar can be copied as-is. */
export function previewQuery(st: PreviewState): string {
  const q = new URLSearchParams()
  q.set('path', st.path)
  q.set('w', st.sizes.map((s) => (s.h === null ? String(s.w) : `${s.w}x${s.h}`)).join(','))
  if (st.zoom !== 'fit') q.set('scale', String(st.zoom))
  if (st.spots === false) q.set('spot', '0')
  return q.toString()
}

/** The harness's frames: overlays inside them can tell they're a preview (and skip mounting). */
export const PREVIEW_FRAME_NAME = 'ade-preview-frame'

/** The phone page editor frames the real page as a preview too (no visit counted, no overlays). */
const PHONE_PAGE_PREVIEW = /^\/admin\/m\/pages\/[^/]+\/edit\/?$/

/**
 * Is this document a Preview sizes frame? Only when framed AND the parent is
 * the harness (or the phone page editor's live preview). The parent's path is null when it can't be read (another
 * origin); then the frame's name decides.
 */
export function isPreviewFrame(p: { isTop: boolean; frameName: string; parentPath: string | null }): boolean {
  if (p.isTop) return false
  if (p.parentPath !== null) return isPreviewSizesPath(p.parentPath) || PHONE_PAGE_PREVIEW.test(p.parentPath)
  return p.frameName === PREVIEW_FRAME_NAME
}

/** isPreviewFrame for the current window (false on the server). */
export function previewFrameNow(): boolean {
  if (typeof window === 'undefined') return false
  let parentPath: string | null = null
  try {
    parentPath = window.parent.location.pathname
  } catch {
    parentPath = null
  }
  return isPreviewFrame({ isTop: window === window.top, frameName: window.name, parentPath })
}

/**
 * Layout prefs (sidebar, mode, dock side, widths, dividers) are never written
 * from a Preview sizes frame: the frame shares the person's storage and
 * account, and a capture must not change how their admin looks.
 */
export function layoutWriteAllowed(inPreviewFrame: boolean): boolean {
  return !inPreviewFrame
}

/** The frame flag the harness sets on each iframe: whether spotlights mount inside it. */
export const PREVIEW_SPOTLIGHTS_ATTR = 'data-ade-spotlights'

/**
 * What mounts in this document. Outside a preview: everything. Inside one:
 * never the visit counters (beacon, analytics); spotlights / walk-throughs
 * unless the harness turned them off ("0") — walk-throughs render in the
 * harness (owner), so a missing flag means on.
 */
export function previewMounts(p: { inFrame: boolean; spotlightsFlag: string | null }): { spotlights: boolean; counters: boolean } {
  if (!p.inFrame) return { spotlights: true, counters: true }
  return { spotlights: p.spotlightsFlag !== '0', counters: false }
}
