/** Executable checks for walkthrough autoplay. Run: pnpm console:autoplay */
import assert from 'node:assert/strict'

import { DEFAULT_PACE, dwellMs, initial, MAX_DWELL_MS, MAX_SECONDS, MIN_DWELL_MS, MIN_SECONDS, nextSpeed, progress, readingMs, reduce, sanitizePace, secondsLeft, type Pace, type PlayEvent, type PlayState } from './autoplay'

let n = 0
const ok = (c: unknown, m: string) => { assert.ok(c, m); n++ }
const eq = <T>(a: T, b: T, m: string) => { assert.deepEqual(a, b, m); n++ }

// ---------- how long a step stays ----------
eq(dwellMs({}), MIN_DWELL_MS, 'an empty step still stays long enough to be seen')
eq(dwellMs({ title: 'Orders' }), MIN_DWELL_MS, 'a short step stays the minimum')
ok(dwellMs({ title: 'Orders', sentence: 'This link opens the full list of Orders; the Create new Orders link just above it starts a new one.' }) > MIN_DWELL_MS, 'a longer sentence stays longer')
eq(dwellMs({ sentence: 'word '.repeat(200) }), MAX_DWELL_MS, 'a very long one is capped')
ok(dwellMs({ sentence: 'a b c d e f g h i j k l' }, 1.5) < dwellMs({ sentence: 'a b c d e f g h i j k l' }, 1), 'faster speed shortens it')
ok(dwellMs({ sentence: 'a b c d e f g h i j k l' }, 0.75) > dwellMs({ sentence: 'a b c d e f g h i j k l' }, 1), 'slower speed lengthens it')
eq(dwellMs({ title: 'x' }, 0), MIN_DWELL_MS, 'a nonsense speed falls back to normal')

// ---------- pace: reading time, a fixed number of seconds, or reading time with a floor ----------
const LONG = { title: 'Orders', sentence: 'This link opens the full list of Orders; the Create new Orders link just above it starts a new one.' }
const SHORT = { title: 'Orders' }
const fixed = (seconds: number): Pace => ({ method: 'fixed', seconds, wordsPerMinute: 200 })
const floor = (seconds: number): Pace => ({ method: 'floor', seconds, wordsPerMinute: 200 })

eq(dwellMs(LONG), dwellMs(LONG, 1, DEFAULT_PACE), 'reading time is the default pace')
eq(DEFAULT_PACE.method, 'reading', 'and reading is the default method')
eq(dwellMs(SHORT, 1, fixed(6)), 6000, 'a fixed pace is exactly that many seconds, however little there is to read')
eq(dwellMs(LONG, 1, fixed(6)), 6000, 'and however much')
eq(dwellMs(SHORT, 1, floor(8)), 8000, 'a floor lifts a short step up to it')
eq(dwellMs(LONG, 1, floor(3)), dwellMs(LONG, 1, DEFAULT_PACE), 'and leaves a long step at its reading time')
ok(dwellMs(LONG, 1, floor(8)) >= 8000, 'a floor is never undercut')
eq(dwellMs({ ...SHORT, seconds: 9 }, 1, fixed(4)), 9000, 'a step\u2019s own seconds beat a fixed pace')
eq(dwellMs({ ...LONG, seconds: 3 }, 1, floor(12)), 3000, 'and a floor')
eq(dwellMs({ ...LONG, seconds: 3 }), 3000, 'and reading time')
eq(dwellMs({ seconds: 1 }), MIN_SECONDS * 1000, 'an explicit time shorter than can be read is raised to the minimum')
eq(dwellMs({ seconds: 5000 }), MAX_SECONDS * 1000, 'and one that would look like a hang is capped')
eq(dwellMs(SHORT, 1, fixed(1)), MIN_SECONDS * 1000, 'a fixed pace obeys the same bounds')
eq(dwellMs(SHORT, 1, fixed(999)), MAX_SECONDS * 1000, 'both ends')
eq(dwellMs(SHORT, 2, fixed(10)), 5000, 'the person\u2019s speed applies on top of a fixed time')
eq(dwellMs({ ...SHORT, seconds: 10 }, 0.75), Math.round(10000 / 0.75), 'and on top of a step\u2019s own time')
eq(dwellMs(SHORT, 1, floor(8)) > dwellMs(SHORT, 1.5, floor(8)), true, 'and on top of a floor')
ok(readingMs(LONG, 300) < readingMs(LONG, 200) && readingMs(LONG, 200) < readingMs(LONG, 120), 'a faster reading speed shortens reading time, a slower one lengthens it')
eq(readingMs(LONG, 200), dwellMs(LONG), 'reading time at 200 words a minute is the default')
eq(readingMs({ sentence: 'word '.repeat(400) }, 200), MAX_DWELL_MS, 'reading time stays capped')
eq(dwellMs(LONG, 1, { method: 'reading', seconds: 5, wordsPerMinute: 9999 }), readingMs(LONG, 400), 'a reading speed beyond the limit is clamped')

// ---------- untrusted settings ----------
eq(sanitizePace(undefined), DEFAULT_PACE, 'nothing stored means the default')
eq(sanitizePace(null), DEFAULT_PACE, 'null means the default')
eq(sanitizePace('fast'), DEFAULT_PACE, 'a string means the default')
eq(sanitizePace({ method: 'turbo', seconds: 'x', wordsPerMinute: NaN }), DEFAULT_PACE, 'garbage fields fall back to the default')
eq(sanitizePace({ method: 'fixed', seconds: 1000, wordsPerMinute: 5 }), { method: 'fixed', seconds: MAX_SECONDS, wordsPerMinute: 100 }, 'out-of-range numbers are clamped, a valid method is kept')
eq(sanitizePace({ method: 'floor', seconds: 7, wordsPerMinute: 250 }), { method: 'floor', seconds: 7, wordsPerMinute: 250 }, 'a valid pace passes through unchanged')
eq(sanitizePace({ method: 'fixed', seconds: Infinity }).seconds, DEFAULT_PACE.seconds, 'infinity is not a number we trust')

// ---------- the clock ----------
const D = 5000
const dwellAt = () => D
const run = (s: PlayState, ...events: PlayEvent[]) => events.reduce((acc, e) => reduce(acc, e, dwellAt), s)

const s0 = initial(3, { autoplay: true })
ok(s0.playing && s0.index === 0 && !s0.done, 'a walkthrough of several steps starts playing')
ok(!initial(1, { autoplay: true }).playing, 'a single step never autoplays')
ok(!initial(3, { autoplay: false }).playing, 'autoplay can be off')
ok(!initial(3, { autoplay: true, reducedMotion: true }).playing, 'someone who asked for less motion gets it still')

eq(run(s0, { type: 'tick', dt: 2000 }).elapsed, 2000, 'time accumulates on a step')
eq(run(s0, { type: 'tick', dt: 4999 }).index, 0, 'it does not advance early')
const adv = run(s0, { type: 'tick', dt: 5000 })
ok(adv.index === 1 && adv.elapsed === 0, 'it advances when the time is up, with a fresh countdown')
eq(run(s0, { type: 'tick', dt: 5000 }, { type: 'tick', dt: 5000 }).index, 2, 'and again')
const end = run(s0, { type: 'tick', dt: 5000 }, { type: 'tick', dt: 5000 }, { type: 'tick', dt: 5000 })
ok(end.done && end.index === 2, 'after the last step it holds there, done')
eq(run(end, { type: 'tick', dt: 60000 }).index, 2, 'and stays held however long it waits: it never closes or loops by itself')
eq(run(s0, { type: 'tick', dt: -5 }), s0, 'negative time is ignored')
eq(run(s0, { type: 'tick', dt: 0 }), s0, 'zero time is ignored')

// ---------- pause, hold ----------
const paused = run(s0, { type: 'pause' })
eq(run(paused, { type: 'tick', dt: 99999 }).index, 0, 'paused, nothing moves however much time passes')
eq(run(paused, { type: 'play' }, { type: 'tick', dt: 5000 }).index, 1, 'play resumes it')
const held = run(s0, { type: 'hold', held: true })
eq(run(held, { type: 'tick', dt: 99999 }).index, 0, 'hovering the card freezes it')
ok(held.playing, 'but does not turn autoplay off: it is not the person’s choice')
eq(run(held, { type: 'hold', held: false }, { type: 'tick', dt: 5000 }).index, 1, 'and it carries on when they move away')
eq(run(s0, { type: 'hold', held: false }), s0, 'a repeated hold state changes nothing')
eq(run(paused, { type: 'hold', held: true }, { type: 'hold', held: false }).playing, false, 'a pause survives hover coming and going')

// ---------- the person drives it ----------
eq(run(s0, { type: 'tick', dt: 3000 }, { type: 'next' }), { ...s0, index: 1, elapsed: 0 }, 'Next moves on and restarts the countdown')
ok(run(s0, { type: 'next' }).playing, 'and keeps autoplay as it was')
ok(!run(paused, { type: 'next' }).playing, 'and keeps a pause as it was')
eq(run(s0, { type: 'prev' }).index, 0, 'Back stops at the first step')
eq(run(s0, { type: 'next' }, { type: 'next' }, { type: 'next' }, { type: 'next' }).index, 2, 'Next stops at the last step')
eq(run(s0, { type: 'goto', index: 99 }).index, 2, 'goto is clamped')
eq(run(end, { type: 'prev' }).done, false, 'going back from the end clears done')
const replay = run(end, { type: 'replay' })
ok(replay.index === 0 && replay.playing && !replay.done, 'Replay starts again from the first step, playing')
ok(run(end, { type: 'play' }).index === 0, 'Play after the end also starts again')
eq(run(s0, { type: 'speed', speed: 1.5 }).speed, 1.5, 'speed can change')
eq(run(s0, { type: 'speed', speed: 0 }).speed, 1, 'a zero speed is refused')
eq([1, 1.5, 0.75].map(nextSpeed), [1.5, 0.75, 1], 'speed cycles 1x, 1.5x, 0.75x')

// ---------- the countdown display ----------
eq(progress({ ...s0, elapsed: 2500 }, 5000), 0.5, 'halfway through is 0.5')
eq(progress({ ...s0, elapsed: 99999 }, 5000), 1, 'never past 1')
eq(progress({ ...s0, elapsed: 10 }, 0), 0, 'a zero length step does not divide by zero')
eq(secondsLeft({ ...s0, elapsed: 0 }, 5000), 5, 'five seconds left at the start')
eq(secondsLeft({ ...s0, elapsed: 4100 }, 5000), 1, 'rounds up so it never shows 0 while there is time')
eq(secondsLeft({ ...s0, elapsed: 5000 }, 5000), 0, 'zero at the end')

console.log(`autoplay assertions passed: ${n} checks`)
