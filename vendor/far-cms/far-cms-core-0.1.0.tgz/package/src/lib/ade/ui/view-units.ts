/**
 * Functional units: how the assistant reads a screen and how pointing at it
 * snaps. A screen is described as the units a person would name: sections
 * and cards, forms, dialogs, tables and their rows, then buttons, links,
 * tabs and fields (each field with its label). Never a lone icon, span or
 * svg.
 *
 * One tree serves both sides:
 *  - read_view walks it to describe the visible screen to the model;
 *  - pick mode / spotlight snap a pointed-at element to its unit and climb
 *    to the parent unit.
 *
 * Pure and host-agnostic: it reads nodes through a small accessor, so the
 * browser passes real Elements and the assert passes plain objects. Secret
 * fields (passwords, hidden inputs, tokens/keys) never appear, not even
 * their labels.
 *
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/view-units.assert.ts
 */

import { redactText } from '../privacy/redact'
import { PRIVATE_VALUE, type Visibility } from '../governance/visibility'

/** Read access to a DOM-like tree (real Elements in the browser, objects in the assert). */
export interface NodeAccess<N> {
  /** Lower-case tag name. */
  tag(n: N): string
  attr(n: N, name: string): string | null
  /** Element children; a same-origin iframe yields its body's children. */
  children(n: N): readonly N[]
  parent(n: N): N | null
  /** Rendered text (innerText-like). */
  text(n: N): string
  /** Rendered and not hidden (display/visibility/size). */
  visible(n: N): boolean
  /** Current value of a form control. */
  value(n: N): string | null
  /** Checked state of a checkbox/radio (null when not applicable). */
  checked(n: N): boolean | null
  /** Label elements associated with a control (label[for] and wrapping label). */
  labels(n: N): readonly N[]
  /** Element by id in the same document. */
  byId(id: string, near: N): N | null
  /** How far (px) the node sits below the visible part of its scroll container; 0/null when in view. */
  below?(n: N): number | null
}

export type UnitRole =
  | 'section'
  | 'card'
  | 'form'
  | 'dialog'
  | 'table'
  | 'row'
  | 'tabs'
  | 'tab'
  | 'menu'
  | 'option'
  | 'button'
  | 'link'
  | 'field'
  | 'block'
  | 'frame'

/** Why something on the screen isn't showing right now (it still exists). */
export type HiddenKind = 'collapsed' | 'inactive-tab' | 'menu' | 'below-fold'
/** The view-only actions that reveal it (the navigation tools of the same names). */
export type RevealAction = 'open_tab' | 'expand' | 'collapse' | 'open_menu' | 'scroll_to'

export interface ViewUnit {
  /** Stable for this snapshot; the browser stamps it as data-ade-unit. */
  id: string
  role: UnitRole
  label: string
  /** Comma-separated: selected, open, disabled, on/off, required, invalid… */
  state?: string
  /** Field value, or a card's short text. */
  value?: string
  /** A container's own plain text outside its units (messages, answers, notes, empty states). */
  text?: string
  /** Tables: columns and how many rows exist. */
  columns?: string[]
  rows?: { shown: number; total: number }
  children?: ViewUnit[]
  /** Children left out: a long list's later items, or to fit the size cap. */
  more?: number
  /** Something here is out of sight: a closed accordion, an inactive tab, a closed menu, or below the fold. */
  hidden?: HiddenKind
  /** What acting on it shows (the tab's panel, the section it expands). */
  reveals?: string
  /** The safe view-only action available on this unit. */
  action?: RevealAction
  /** Below the fold: px below the visible area of its scroll container. */
  below?: number
  /** A selector that outlives this snapshot (for replayable tours); absent when the unit has no stable name. */
  stable?: string
  /** Marked private (data-ade-private): values withheld. */
  private?: true
  /** Private at the blocked level: nothing but its label. */
  blocked?: true
}

export interface UnitMarkers {
  /** Attribute marking the page canvas (fine picking inside it). */
  canvas: string
  /** Attribute holding a page block id. */
  block: string
  /** Attributes naming controls, best first (used for labels of icon-only controls). */
  controls: readonly string[]
  /** Attribute marking a card (beyond article / data-slot="card"). */
  card?: string
}

export interface BuildOptions {
  markers: UnitMarkers
  maxUnits?: number
  maxDepth?: number
  rowsPerTable?: number
  /** Same-role items kept per container (a list of conversations, options, cards); the rest are counted in "more". */
  itemsPerList?: number
  /** Cap on a container's plain text. */
  textMax?: number
  /** Selector-free subtree skip (the assistant's own UI, overlays). */
  skip?: (n: unknown) => boolean
  /** Walked before the root's children (open dialogs portaled outside it). */
  before?: readonly unknown[]
  /** The screen's visibility (lib/ade/governance/visibility): metadata-only keeps labels, never values, row text or card text. */
  level?: Exclude<Visibility, 'blocked'>
  /** The level for a privacy marker value (data-ade-private="contact"…); unknown → metadata-only. */
  privacy?: (marker: string) => Visibility
  /** Attribute carrying privacy markers. */
  privateAttr?: string
  /** Readable markers whose raw text may reach the model (else redacted like any tool output). Default: none. */
  showRaw?: (marker: string) => boolean
}

export interface UnitTree<N> {
  units: ViewUnit[]
  /** Unit id → node, so the browser can stamp them. */
  nodes: Map<string, N>
  count: number
  truncated: boolean
  /** The screen's own plain text outside any unit. */
  text?: string
  /** What was masked or left out (for agent activity): labels only, never values. */
  masked: MaskNote[]
}

/** One withheld thing: where (a table/section label), which field (a column, a field label), and why. */
export interface MaskNote {
  target: string
  field: string
  /** The privacy marker that hid it (its rule is looked up by the host); absent for whole-screen levels. */
  marker?: string
  /** policy = the visibility rules; redaction = emails/phones/long numbers redacted like any tool output. */
  kind: 'policy' | 'redaction'
}

const NEVER = new Set(['script', 'style', 'template', 'noscript', 'svg', 'path', 'meta', 'link', 'head', 'br', 'hr'])
const LEAF_ROLES: ReadonlySet<UnitRole> = new Set(['button', 'link', 'field', 'tab', 'option', 'frame'])
/** Roles that repeat as the items of a list (conversations, to-dos, results); a long run is capped per container. */
const ITEM_ROLES: ReadonlySet<UnitRole> = new Set(['button', 'link', 'option', 'card'])
/** Containers whose own plain text is read (a thread's messages, a submission's answers). */
const TEXT_ROLES: ReadonlySet<UnitRole> = new Set(['section', 'card', 'dialog', 'form'])
const FIELD_ROLES = new Set(['textbox', 'combobox', 'switch', 'checkbox', 'radio', 'slider', 'spinbutton', 'searchbox'])
const BUTTON_INPUTS = new Set(['button', 'submit', 'reset', 'image'])
// Names/labels of secret fields. "Daily token budget" is not a secret; "access token" is.
const SECRET_NAME = /(password|passcode|passphrase|secret|api[\s_-]?key|private[\s_-]?key|(access|auth|refresh|bearer|api)[\s_-]?token|bearer|credential|one[\s_-]?time[\s_-]?code|otp\b|signing[\s_-]?key)/i
const SECRET_AUTOCOMPLETE = /(current-password|new-password|one-time-code)/i
// Values shaped like keys (Stripe/Slack/GitHub/AWS prefixes, or a long unbroken token).
const SECRET_VALUE = /^(?:(?:sk|rk|pk|whsec|xox[abpr]|ghp|gho|github_pat|AKIA|re|SG)[._-][A-Za-z0-9._-]{8,}|[A-Za-z0-9+/_=-]{40,})$/

const squash = (s: string) => s.replace(/\s+/g, ' ').trim()
export function clip(s: string, max: number): string {
  const t = squash(s)
  return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t
}

/** True for inputs whose existence or value must never be shared. */
export function isSecretField<N>(n: N, a: NodeAccess<N>): boolean {
  const tag = a.tag(n)
  if (tag !== 'input' && tag !== 'textarea' && a.attr(n, 'contenteditable') !== 'true') return false
  const type = (a.attr(n, 'type') ?? '').toLowerCase()
  if (type === 'password' || type === 'hidden') return true
  if (SECRET_AUTOCOMPLETE.test(a.attr(n, 'autocomplete') ?? '')) return true
  if (a.attr(n, 'data-secret') !== null) return true
  const names = [a.attr(n, 'name'), a.attr(n, 'id'), a.attr(n, 'aria-label'), a.attr(n, 'placeholder'), ...a.labels(n).map((l) => a.text(l))]
  if (names.some((v) => !!v && SECRET_NAME.test(v.replace(/([a-z])([A-Z])/g, '$1 $2')))) return true
  const value = tag === 'input' || tag === 'textarea' ? a.value(n) : null
  return !!value && SECRET_VALUE.test(value.trim())
}

function hiddenByAttr<N>(n: N, a: NodeAccess<N>): boolean {
  return a.attr(n, 'hidden') !== null || a.attr(n, 'aria-hidden') === 'true' || a.attr(n, 'inert') !== null
}

/** Inside the page canvas (where fine element picking is kept)? */
export function inCanvas<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): boolean {
  for (let c: N | null = n; c; c = a.parent(c)) if (a.attr(c, markers.canvas) !== null) return true
  return false
}

/** The unit role of a node, or null when it's structure, text or decoration. */
export function unitRole<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): UnitRole | null {
  const tag = a.tag(n)
  if (NEVER.has(tag)) return null
  const role = (a.attr(n, 'role') ?? '').toLowerCase()
  if (a.attr(n, markers.block) !== null && inCanvas(n, a, markers)) return 'block'
  if (role === 'dialog' || role === 'alertdialog' || (tag === 'dialog' && a.attr(n, 'open') !== null)) return 'dialog'
  if (tag === 'iframe') return 'frame'
  if (tag === 'form' || role === 'form') return 'form'
  if (tag === 'table' || role === 'table' || role === 'grid' || role === 'treegrid') return 'table'
  if (tag === 'tr' || role === 'row') return 'row'
  if (role === 'tablist') return 'tabs'
  if (role === 'tab') return 'tab'
  if (role === 'menu' || role === 'listbox' || role === 'menubar') return 'menu'
  if (role === 'menuitem' || role === 'menuitemcheckbox' || role === 'menuitemradio' || role === 'option') return 'option'
  // An explicit control role wins over the tag (<button role="switch"> is a field).
  if (FIELD_ROLES.has(role)) return 'field'
  if (tag === 'button' || role === 'button' || tag === 'summary') return 'button'
  if (tag === 'input') {
    const type = (a.attr(n, 'type') ?? 'text').toLowerCase()
    if (type === 'hidden') return null
    return BUTTON_INPUTS.has(type) ? 'button' : 'field'
  }
  if (tag === 'textarea' || tag === 'select' || FIELD_ROLES.has(role) || a.attr(n, 'contenteditable') === 'true') return 'field'
  if ((tag === 'a' && a.attr(n, 'href') !== null) || role === 'link') return 'link'
  if (tag === 'article' || a.attr(n, 'data-slot') === 'card' || (markers.card && a.attr(n, markers.card) !== null)) return 'card'
  if (tag === 'section' || tag === 'aside' || tag === 'nav' || tag === 'fieldset' || role === 'region' || role === 'navigation' || role === 'complementary') return 'section'
  if (role === 'group' && (a.attr(n, 'aria-label') || a.attr(n, 'aria-labelledby'))) return 'section'
  // Lists, logs and feeds hold the content (conversations, messages, activity): a container like a section.
  if (role === 'list' || role === 'log' || role === 'feed' || role === 'tree') return 'section'
  return null
}

function byIds<N>(ids: string, near: N, a: NodeAccess<N>): string {
  return ids
    .split(/\s+/)
    .map((id) => a.byId(id, near))
    .filter((x): x is N => !!x)
    .map((x) => a.text(x))
    .join(' ')
}

/** First heading-like text inside a container (a few levels deep, skipping nested units). */
function headingOf<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers, depth = 0): string {
  if (depth > 5) return ''
  for (const c of a.children(n)) {
    if (hiddenByAttr(c, a)) continue
    const tag = a.tag(c)
    if (/^h[1-6]$/.test(tag) || tag === 'legend' || tag === 'caption' || a.attr(c, 'role') === 'heading' || a.attr(c, 'data-slot') === 'card-title') {
      const t = squash(a.text(c))
      if (t) return t
    }
    // Don't borrow a nested card's or button's title.
    if (unitRole(c, a, markers)) continue
    const found = headingOf(c, a, markers, depth + 1)
    if (found) return found
  }
  return ''
}

const humanize = (id: string) => squash(id.replace(/^.*[.:/]/, '').replace(/[-_]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2')).toLowerCase()

/** What a person would call this unit. */
export function unitLabel<N>(n: N, role: UnitRole, a: NodeAccess<N>, markers: UnitMarkers): string {
  const aria = a.attr(n, 'aria-label')
  if (aria && squash(aria)) return clip(aria, 80)
  const by = a.attr(n, 'aria-labelledby')
  if (by) {
    const t = byIds(by, n, a)
    if (squash(t)) return clip(t, 80)
  }
  const named = () => {
    for (const m of markers.controls) {
      const v = a.attr(n, m)
      if (v) return humanize(v)
    }
    return ''
  }
  switch (role) {
    case 'field': {
      const fromLabels = a.labels(n).map((l) => a.text(l)).join(' ')
      return clip(fromLabels || a.attr(n, 'placeholder') || a.attr(n, 'title') || a.attr(n, 'name') || named() || 'Field', 80)
    }
    case 'button':
    case 'link':
    case 'tab':
    case 'option': {
      const t = a.tag(n) === 'input' ? a.attr(n, 'value') ?? '' : a.text(n)
      return clip(t || a.attr(n, 'title') || a.attr(n, 'alt') || named() || role, 80)
    }
    case 'row':
      return clip(a.children(n).map((c) => squash(a.text(c))).filter(Boolean).join(' · '), 140)
    case 'frame':
      return clip(a.attr(n, 'title') || 'Embedded view', 80)
    case 'block':
      return clip(a.attr(n, 'data-block-label') || a.attr(n, 'data-block-kind') || a.text(n) || 'Block', 60)
    default:
      return clip(headingOf(n, a, markers) || a.attr(n, 'title') || named() || '', 80)
  }
}

/** Comma-separated state words, or undefined. */
export function unitState<N>(n: N, role: UnitRole, a: NodeAccess<N>): string | undefined {
  const s: string[] = []
  const on = (attr: string) => a.attr(n, attr) === 'true'
  if (on('aria-selected') || a.attr(n, 'data-state') === 'active') s.push('selected')
  const cur = a.attr(n, 'aria-current')
  if (cur && cur !== 'false') s.push('current')
  if (a.attr(n, 'aria-expanded') === 'true' || (role !== 'tab' && a.attr(n, 'data-state') === 'open')) s.push('open')
  if (on('aria-pressed')) s.push('pressed')
  const checked = a.attr(n, 'aria-checked') ?? (a.checked(n) === null ? null : String(a.checked(n)))
  if (checked === 'true') s.push('on')
  else if (checked === 'false' && role === 'field') s.push('off')
  if (a.attr(n, 'disabled') !== null || on('aria-disabled')) s.push('disabled')
  if (a.attr(n, 'required') !== null || on('aria-required')) s.push('required')
  if (on('aria-invalid')) s.push('invalid')
  if (a.attr(n, 'readonly') !== null || on('aria-readonly')) s.push('read-only')
  return s.length ? s.join(', ') : undefined
}

function fieldValue<N>(n: N, a: NodeAccess<N>): string | undefined {
  const type = (a.attr(n, 'type') ?? '').toLowerCase()
  if (type === 'checkbox' || type === 'radio' || a.attr(n, 'aria-checked') !== null) return undefined
  if (type === 'file') return undefined
  const raw = a.tag(n) === 'input' || a.tag(n) === 'textarea' || a.tag(n) === 'select' ? a.value(n) : a.text(n)
  const v = raw ? clip(redactText(raw), 120) : ''
  return v || undefined
}

const quote = (v: string) => `"${v.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`

/**
 * A selector that survives re-renders and later visits: the host's control
 * names in marker order (e.g. data-ui, data-tour-id, data-help-key), else
 * the aria-label scoped to its role/tag; null when there's none.
 */
export function stableSelector<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): string | null {
  for (const m of markers.controls) {
    const v = a.attr(n, m)
    if (v) return `[${m}=${quote(v)}]`
  }
  const aria = a.attr(n, 'aria-label')
  if (!aria) return null
  const role = a.attr(n, 'role')
  return role ? `[role=${quote(role)}][aria-label=${quote(aria)}]` : `${a.tag(n)}[aria-label=${quote(aria)}]`
}

// Labels that must never be pressed by a view-only action.
const DESTRUCTIVE = /\b(delete|remove|discard|archive|trash|publish|unpublish|send|save|submit|pay|refund|charge|cancel|unsubscribe|log ?out|sign ?out|reset|clear|revoke|deactivate|disable|approve|reject|confirm|apply|import|upload|duplicate|create|add)\b/i

/**
 * True when pressing it could change something or leave the screen:
 * submit buttons (an untyped <button> in a form submits), links, and
 * anything labelled like an action (Delete, Save, Publish…).
 */
export function isUnsafeTrigger<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): boolean {
  const tag = a.tag(n)
  const type = (a.attr(n, 'type') ?? '').toLowerCase()
  if (type === 'submit' || type === 'reset' || type === 'image') return true
  if (tag === 'a' && a.attr(n, 'href') !== null) return true
  if (tag === 'input' && type !== 'button') return true
  if (tag === 'button' && !type) {
    for (let p = a.parent(n); p; p = a.parent(p)) if (a.tag(p) === 'form') return true
  }
  if (a.attr(n, 'disabled') !== null || a.attr(n, 'aria-disabled') === 'true') return true
  const role = unitRole(n, a, markers)
  const label = role ? unitLabel(n, role, a, markers) : a.text(n)
  return DESTRUCTIVE.test(label) || DESTRUCTIVE.test(a.attr(n, 'title') ?? '')
}

/**
 * The view-only action a unit offers in its current state, or null. Only
 * these are ever actionable: a tab, a disclosure (button/summary with
 * aria-expanded or aria-controls), a menu/popover trigger.
 */
export function revealAction<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): RevealAction | null {
  const role = unitRole(n, a, markers)
  if (role !== 'tab' && role !== 'button') return null
  if (isUnsafeTrigger(n, a, markers)) return null
  if (role === 'tab') return a.attr(n, 'aria-selected') === 'true' || a.attr(n, 'data-state') === 'active' ? null : 'open_tab'
  const popup = (a.attr(n, 'aria-haspopup') ?? '').toLowerCase()
  const expanded = a.attr(n, 'aria-expanded')
  const open = expanded === 'true' || a.attr(n, 'data-state') === 'open'
  if (popup && popup !== 'false') return open ? null : 'open_menu'
  if (a.tag(n) === 'summary') {
    const details = a.parent(n)
    return details && a.attr(details, 'open') !== null ? 'collapse' : 'expand'
  }
  // A panel switcher (a section list whose buttons swap one shared panel): like a tab.
  if (isSwitcher(n, a)) return isCurrent(n, a) ? null : 'open_tab'
  if (expanded !== null || a.attr(n, 'aria-controls') !== null) return open ? 'collapse' : 'expand'
  return null
}

/** A button that controls a panel without opening/closing it (no aria-expanded): it switches what the panel shows. */
function isSwitcher<N>(n: N, a: NodeAccess<N>): boolean {
  return a.attr(n, 'aria-controls') !== null && a.attr(n, 'aria-expanded') === null && a.attr(n, 'aria-haspopup') === null
}
function isCurrent<N>(n: N, a: NodeAccess<N>): boolean {
  const cur = a.attr(n, 'aria-current')
  return (cur !== null && cur !== 'false') || a.attr(n, 'aria-pressed') === 'true' || a.attr(n, 'aria-selected') === 'true'
}

/** What a trigger shows: its controlled region's name, else the trigger's own words. */
function revealsLabel<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): string {
  const ctl = a.attr(n, 'aria-controls')
  const target = ctl ? a.byId(ctl.split(/\s+/)[0], n) : null
  if (target) {
    const role = unitRole(target, a, markers) ?? 'section'
    const label = unitLabel(target, role, a, markers)
    if (label) return label
  }
  return ''
}

/**
 * Build the unit tree under `root`. Non-unit wrappers are flattened; a
 * container with no label and a single child unit collapses into it; tables
 * keep their first `rowsPerTable` body rows. Stops at `maxUnits`.
 */
export function buildUnitTree<N>(root: N, a: NodeAccess<N>, opts: BuildOptions): UnitTree<N> {
  const maxUnits = opts.maxUnits ?? 160
  const maxDepth = opts.maxDepth ?? 7
  const rowsPerTable = opts.rowsPerTable ?? 8
  const itemsPerList = opts.itemsPerList ?? 12
  const textMax = opts.textMax ?? 600
  const privateAttr = opts.privateAttr ?? 'data-ade-private'
  const nodes = new Map<string, N>()
  const masked: MaskNote[] = []
  let count = 0
  let truncated = false

  type Lvl = Visibility
  const RANK: Record<Lvl, number> = { readable: 0, 'metadata-only': 1, blocked: 2 }
  const stricter = (x: Lvl, y: Lvl): Lvl => (RANK[x] >= RANK[y] ? x : y)
  /** The level at a node: inherited, or stricter when it carries a privacy marker. */
  /**
   * A marked element's text reaches the model only when its level is
   * readable AND its area lets the assistant follow the person (showRaw).
   * Anything else is withheld — the same rule capture_view paints over by,
   * so the text and the picture agree on the stricter side.
   */
  const withheld = (marker: string | null, lvl: Lvl): boolean => marker !== null && (lvl !== 'readable' || !(opts.showRaw?.(marker) ?? false))
  const levelAt = (n: N, inherited: Lvl): Lvl => {
    const marker = a.attr(n, privateAttr)
    if (marker === null) return inherited
    return stricter(inherited, opts.privacy?.(marker) ?? 'metadata-only')
  }
  const note = (target: string, field: string, marker?: string | null, kind: MaskNote['kind'] = 'policy') => {
    const t = clip(target || 'Screen', 60)
    const f = clip(field || 'value', 60)
    if (masked.length >= 40 || masked.some((m) => m.target === t && m.field === f && m.kind === kind)) return
    masked.push({ target: t, field: f, kind, ...(marker ? { marker } : {}) })
  }
  /** redactText, noting what it hid (no values). */
  const redacted = (raw: string, target: string, field: string): string => {
    const out = redactText(raw)
    if (out !== raw) note(target, field, null, 'redaction')
    return out
  }

  const make = (n: N, role: UnitRole, lvl: Lvl, ctx = ''): ViewUnit => {
    count++
    const id = `u${count}`
    nodes.set(id, n)
    const u: ViewUnit = { id, role, label: unitLabel(n, role, a, opts.markers) }
    if (a.attr(n, privateAttr) !== null) {
      u.private = true
      if (withheld(a.attr(n, privateAttr), lvl)) note(ctx, u.label || role, a.attr(n, privateAttr))
    }
    if (lvl === 'blocked') {
      u.blocked = true
      return u
    }
    const stable = stableSelector(n, a, opts.markers)
    if (stable) u.stable = stable
    const act = revealAction(n, a, opts.markers)
    if (act) {
      u.action = act
      if (act !== 'collapse') u.hidden = act === 'open_tab' ? 'inactive-tab' : act === 'expand' ? 'collapsed' : 'menu'
      // A switcher's panel shows the CURRENT section, so its label says nothing about this one.
      const reveals = role !== 'tab' && isSwitcher(n, a) ? '' : revealsLabel(n, a, opts.markers)
      if (reveals && reveals !== u.label) u.reveals = reveals
    }
    const below = a.below?.(n) ?? 0
    if (below > 0) {
      u.below = Math.round(below)
      u.hidden ??= 'below-fold'
      u.action ??= 'scroll_to'
    }
    const state = unitState(n, role, a)
    if (state) u.state = state
    if (role === 'field') {
      if (lvl === 'readable') {
        const raw = a.value(n)
        const fm = a.attr(n, privateAttr)
        if (fm !== null && raw && !withheld(fm, lvl)) {
          // Marked, readable, and its area lets the assistant follow the person: the value itself.
          u.value = clip(raw, 120)
        } else if (fm !== null) {
          // Marked but withheld for this viewer: that it holds something, never what (reported under its rule).
          if (raw) u.state = u.state ? `${u.state}, filled` : 'filled'
        } else {
          const v = fieldValue(n, a)
          if (v) u.value = v
          if (raw && redactText(raw) !== raw) note(ctx, u.label, null, 'redaction')
        }
      } else if (fieldValue(n, a)) {
        // metadata-only: that it holds something, never what.
        u.state = u.state ? `${u.state}, filled` : 'filled'
      }
    }
    return u
  }

  const skipNode = (n: N) => hiddenByAttr(n, a) || NEVER.has(a.tag(n)) || !a.visible(n) || (opts.skip?.(n) ?? false) || isSecretField(n, a)

  /** Per container: how many items of each role were kept, and how many were left out. */
  interface Bag { seen: Map<UnitRole, number>; skipped: number }
  const newBag = (): Bag => ({ seen: new Map(), skipped: 0 })
  const walk = (n: N, depth: number, out: ViewUnit[], lvl: Lvl, ctx = '', bag: Bag = newBag()) => walkList(a.children(n), depth, out, lvl, ctx, bag)
  const walkList = (list: readonly N[], depth: number, out: ViewUnit[], inherited: Lvl, ctx = '', bag: Bag = newBag()) => {
    for (const c of list) {
      if (count >= maxUnits) {
        truncated = true
        return
      }
      if (skipNode(c)) continue
      const lvl = levelAt(c, inherited)
      const role = unitRole(c, a, opts.markers)
      if (!role) {
        // A private wrapper that isn't a unit: blocked → its content is left out entirely.
        if (lvl === 'blocked') {
          note(ctx, headingOf(c, a, opts.markers) || 'Private content', a.attr(c, privateAttr))
          continue
        }
        // Marked text withheld from the model (scrubbed from labels/values): say so under its rule.
        // (Table cells are reported per column by rowLabel.)
        if (withheld(a.attr(c, privateAttr), lvl) && a.tag(c) !== 'td' && a.tag(c) !== 'th') note(ctx, headingOf(c, a, opts.markers) || 'Private text', a.attr(c, privateAttr))
        // Wrappers are flattened, so their items count toward the same container's list.
        walk(c, depth, out, lvl, ctx, bag)
        continue
      }
      // A long run of items (conversations, to-dos, results) keeps its first ones and the current one;
      // the rest are counted, so one list can't use up the budget meant for the rest of the screen.
      if (ITEM_ROLES.has(role)) {
        const k = (bag.seen.get(role) ?? 0) + 1
        bag.seen.set(role, k)
        if (k > itemsPerList && !/\b(selected|current)\b/.test(unitState(c, role, a) ?? '')) {
          bag.skipped++
          continue
        }
      }
      if (role === 'table') {
        out.push(table(c, depth, lvl))
        continue
      }
      const u = make(c, role, lvl, ctx)
      // Notes inside a labelled container name it as their place.
      const here = !LEAF_ROLES.has(role) && u.label ? u.label : ctx
      if (!u.blocked && !LEAF_ROLES.has(role) && depth < maxDepth) {
        const kids: ViewUnit[] = []
        const inner = newBag()
        walk(c, depth + 1, kids, lvl, here, inner)
        if (kids.length) u.children = kids
        if (inner.skipped) u.more = inner.skipped
      }
      // (A card with no units inside already reads its words as its value, below.)
      if (TEXT_ROLES.has(role) && lvl === 'readable' && !u.blocked && (u.children || role !== 'card')) {
        const t = ownText(c, lvl, u.label)
        if (t) u.text = clip(redacted(scrub(t), u.label || ctx, 'text'), textMax)
      }
      if (role === 'card' && !u.children && lvl === 'readable') {
        const rest = squash(a.text(c)).replace(u.label, '').trim()
        // Scrub withheld text BEFORE cutting to length: a value cut mid-way could leave a fragment the scrub no longer recognises.
        if (rest) u.value = clip(redacted(scrub(rest), u.label || ctx, 'text'), 120)
      }
      // Unlabelled containers add nothing: keep their content, drop the shell.
      if ((role === 'section' || role === 'card' || role === 'menu') && !u.label && !u.private) {
        if (!u.children && !u.value && !u.text) {
          nodes.delete(u.id)
          continue
        }
        if (u.children && u.children.length === 1 && !u.value && !u.text && !u.more) {
          nodes.delete(u.id)
          out.push(u.children[0])
          continue
        }
      }
      out.push(u)
    }
  }

  /**
   * Whether a subtree must be walked piece by piece rather than read whole:
   * it holds a unit (whose text is its own), a label, something skipped
   * (a secret field, hidden or excluded UI) or a privacy marker.
   */
  const mixedMemo = new Map<N, boolean>()
  const mixed = (n: N, depth = 0): boolean => {
    if (depth > 12) return true
    const known = mixedMemo.get(n)
    if (known !== undefined) return known
    let out = false
    for (const c of a.children(n)) {
      if (skipNode(c) || a.tag(c) === 'label' || a.attr(c, privateAttr) !== null || unitRole(c, a, opts.markers) || mixed(c, depth + 1)) {
        out = true
        break
      }
    }
    mixedMemo.set(n, out)
    return out
  }
  /**
   * A container's plain text outside its units: the messages in a thread,
   * a submission's answers, an empty state. Withheld marked text reads
   * [private]; blocked parts are left out. Its own label is not repeated.
   */
  const ownText = (n: N, inherited: Lvl, label = ''): string => {
    const parts: string[] = []
    const visit = (x: N, lvl: Lvl, depth: number) => {
      for (const c of a.children(x)) {
        if (parts.length >= 200 || skipNode(c)) continue
        const cl = levelAt(c, lvl)
        if (cl === 'blocked') continue
        if (withheld(a.attr(c, privateAttr), cl)) {
          parts.push(PRIVATE_VALUE)
          continue
        }
        // A label's words belong to its field (and a secret field's label is never said at all).
        if (unitRole(c, a, opts.markers) || a.tag(c) === 'label') continue
        if (depth < 12 && mixed(c)) visit(c, cl, depth + 1)
        else {
          const t = squash(a.text(c))
          if (t) parts.push(t)
        }
      }
    }
    visit(n, inherited, 0)
    let out = parts.join(' · ')
    if (label && out.startsWith(label)) out = out.slice(label.length).replace(/^\s*·\s*/, '')
    return out.trim()
  }

  /**
   * A row named by its cells. Below readable: "Row N". A private cell (or a
   * cell in a column whose header is private) reads [private]; every
   * withheld or redacted cell is noted under its column's name.
   */
  const rowLabel = (r: N, lvl: Lvl, i: number, tableLabel: string, columns: readonly string[], privateCols: ReadonlySet<number>, colMarkers: ReadonlyMap<number, string>): string => {
    if (lvl !== 'readable') return `Row ${i + 1}`
    const parts: string[] = []
    a.children(r).forEach((cell, ci) => {
      const col = columns[ci] || `column ${ci + 1}`
      const marker = a.attr(cell, privateAttr) ?? colMarkers.get(ci) ?? null
      if (privateCols.has(ci) || levelAt(cell, lvl) !== 'readable') {
        parts.push(PRIVATE_VALUE)
        note(tableLabel, col, marker)
        return
      }
      const t = squash(a.text(cell))
      if (!t) return
      // A marked cell is shown only when the assistant may follow the person there; otherwise
      // it's withheld and reported under its rule (area.contact…), not as plain redaction.
      if (marker !== null && withheld(marker, levelAt(cell, lvl))) {
        parts.push(PRIVATE_VALUE)
        note(tableLabel, col, marker)
        return
      }
      parts.push(marker !== null ? t : redacted(scrub(t), tableLabel, col))
    })
    return clip(parts.join(' · '), 140)
  }

  const table = (n: N, depth: number, lvl: Lvl): ViewUnit => {
    const u = make(n, 'table', lvl)
    if (u.blocked) return u
    const rows: N[] = []
    const columns: string[] = []
    const privateCols = new Set<number>()
    const colMarkers = new Map<number, string>()
    const collect = (x: N) => {
      for (const c of a.children(x)) {
        if (skipNode(c)) continue
        if (unitRole(c, a, opts.markers) === 'row') {
          const cells = a.children(c)
          const header = cells.length > 0 && cells.every((cell) => a.tag(cell) === 'th' || a.attr(cell, 'role') === 'columnheader')
          if (header && !columns.length) {
            cells.forEach((cell, i) => {
              columns.push(clip(a.text(cell), 40))
              if (levelAt(cell, 'readable') !== 'readable') privateCols.add(i)
              const m = a.attr(cell, privateAttr)
              if (m) colMarkers.set(i, m)
            })
          } else if (!header) rows.push(c)
        } else collect(c)
      }
    }
    collect(n)
    if (!u.label) u.label = a.attr(n, 'aria-label') ? clip(a.attr(n, 'aria-label')!, 80) : 'Table'
    if (columns.some(Boolean)) u.columns = columns.filter(Boolean)
    for (const i of privateCols) note(u.label, columns[i] || `column ${i + 1}`, colMarkers.get(i))
    u.rows = { shown: Math.min(rows.length, rowsPerTable), total: rows.length }
    if (lvl !== 'readable') note(u.label, 'rows')
    const kids: ViewUnit[] = []
    rows.slice(0, rowsPerTable).forEach((r, i) => {
      if (count >= maxUnits) {
        truncated = true
        return
      }
      const rl = levelAt(r, lvl)
      const ru = make(r, 'row', rl, u.label)
      ru.label = rowLabel(r, rl, i, u.label, columns, privateCols, colMarkers)
      // A row's own controls (Edit, a checkbox) — not every cell link again; none below readable (their names are data).
      if (rl === 'readable' && !ru.blocked) {
        const inner: ViewUnit[] = []
        if (depth < maxDepth) walk(r, depth + 1, inner, rl, u.label)
        const controls = inner.filter((x) => x.role === 'button' || x.role === 'field' || x.role === 'link')
        if (controls.length) ru.children = controls.slice(0, 6)
      }
      kids.push(ru)
    })
    if (kids.length) u.children = kids
    return u
  }

  // Text of every private element below readable: a card's value or a link's label is built from
  // its whole text, so these strings are replaced wherever they'd otherwise show up.
  const privateTexts: string[] = []
  const gather = (list: readonly N[], inherited: Lvl) => {
    for (const c of list) {
      const lvl = levelAt(c, inherited)
      if (withheld(a.attr(c, privateAttr), lvl)) {
        const t = squash(a.text(c))
        if (t.length >= 3 && privateTexts.length < 500) privateTexts.push(t)
        continue
      }
      gather(a.children(c), lvl)
    }
  }
  gather([...((opts.before ?? []) as N[]), ...a.children(root)], opts.level ?? 'readable')
  privateTexts.sort((x, y) => y.length - x.length)
  const scrub = (t: string) => {
    let out = privateTexts.reduce((acc, p) => (acc.includes(p) ? acc.split(p).join(PRIVATE_VALUE) : acc), t)
    // A label already cut to length ("…") may end in the START of a private text: drop that fragment too.
    if (out.endsWith('…')) {
      const body = out.slice(0, -1)
      for (const p of privateTexts) {
        for (let k = Math.min(p.length, body.length); k >= 3; k--) {
          if (body.endsWith(p.slice(0, k))) {
            out = `${body.slice(0, body.length - k)}${PRIVATE_VALUE}`
            return out
          }
        }
      }
    }
    return out
  }
  const scrubPrivate = (list: ViewUnit[]) => {
    if (!privateTexts.length) return
    for (const u of list) {
      u.label = scrub(u.label)
      if (u.value) u.value = scrub(u.value)
      if (u.text) u.text = scrub(u.text)
      if (u.reveals) u.reveals = scrub(u.reveals)
      if (u.children) scrubPrivate(u.children)
    }
  }

  const units: ViewUnit[] = []
  const top = newBag()
  walkList([...((opts.before ?? []) as N[]), ...a.children(root)], 0, units, opts.level ?? 'readable', '', top)
  if (top.skipped) truncated = true
  const rootText = (opts.level ?? 'readable') === 'readable' && a.attr(root, privateAttr) === null ? ownText(root, 'readable') : ''
  const text = rootText ? clip(redacted(scrub(rootText), 'Screen', 'text'), textMax) : ''
  // Below the fold is said once, on the outermost unit; what's inside it comes along when it scrolls in.
  const unfold = (list: ViewUnit[], inherited: boolean) => {
    for (const u of list) {
      const folded = inherited || u.below !== undefined
      if (inherited && u.below !== undefined) {
        delete u.below
        if (u.hidden === 'below-fold') delete u.hidden
        if (u.action === 'scroll_to') delete u.action
      }
      if (u.children) unfold(u.children, folded)
    }
  }
  unfold(units, false)
  scrubPrivate(units)
  return { units, nodes, count, truncated, masked, ...(text ? { text } : {}) }
}

/** Whether a node is a functional unit for pointing (outside the canvas, rows and fields included). */
function pointable<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): UnitRole | null {
  const role = unitRole(n, a, markers)
  if (!role || role === 'block') return null
  // A row only counts when it has content (not an empty spacer).
  if (role === 'row' && !squash(a.text(n))) return null
  return role
}

/** The control a <label> names (for= or the control inside it). */
function controlOfLabel<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): N | null {
  const f = a.attr(n, 'for')
  if (f) return a.byId(f, n)
  const stack = [...a.children(n)]
  while (stack.length) {
    const c = stack.shift()!
    if (unitRole(c, a, markers) === 'field') return c
    stack.push(...a.children(c))
  }
  return null
}

export interface Snap<N> {
  /** The unit element (for keys and names). */
  node: N
  /** What to outline: a field together with its label, else the unit itself. */
  box: N
  role: UnitRole | 'element'
  label: string
}

/**
 * The box to outline for a field: the smallest wrapper (≤3 levels up) that
 * holds the field and its label and no other field.
 */
export function fieldBox<N>(n: N, a: NodeAccess<N>, markers: UnitMarkers): N {
  const labels = a.labels(n)
  if (!labels.length) return n
  const contains = (outer: N, inner: N) => {
    for (let c: N | null = inner; c; c = a.parent(c)) if (c === outer) return true
    return false
  }
  const fieldsIn = (x: N): number => {
    let k = 0
    const stack = [...a.children(x)]
    while (stack.length && k < 2) {
      const c = stack.shift()!
      if (unitRole(c, a, markers) === 'field' && !isSecretField(c, a)) k++
      stack.push(...a.children(c))
    }
    return k
  }
  let box: N = n
  for (let up = a.parent(n), i = 0; up && i < 3; up = a.parent(up), i++) {
    if (pointable(up, a, markers) && unitRole(up, a, markers) !== 'field') break
    if (fieldsIn(up) > 1) break
    box = up
    if (labels.every((l) => contains(up!, l))) return box
  }
  return labels.every((l) => contains(box, l)) ? box : n
}

function snapOf<N>(node: N, role: UnitRole | 'element', a: NodeAccess<N>, markers: UnitMarkers): Snap<N> {
  const label = role === 'element' ? clip(a.text(node), 60) : unitLabel(node, role, a, markers)
  return { node, box: role === 'field' ? fieldBox(node, a, markers) : node, role, label }
}

/**
 * Snap a pointed-at element. In the page canvas: the block (fine picking
 * stays). Elsewhere: the nearest functional unit — a label snaps to its
 * field, a cell to its row, an icon to its button — never a lone icon,
 * span or svg. Falls back to the element only when nothing up to `stop`
 * is a unit.
 */
export function snapToUnit<N>(target: N, a: NodeAccess<N>, markers: UnitMarkers, stop?: N | null): Snap<N> {
  if (inCanvas(target, a, markers)) {
    for (let c: N | null = target; c; c = a.parent(c)) {
      if (a.attr(c, markers.block) !== null) return { node: c, box: c, role: 'block', label: unitLabel(c, 'block', a, markers) }
      if (a.attr(c, markers.canvas) !== null) break
    }
    return snapOf(target, 'element', a, markers)
  }
  for (let c: N | null = target; c && c !== stop; c = a.parent(c)) {
    if (a.tag(c) === 'label') {
      const ctl = controlOfLabel(c, a, markers)
      if (ctl && !isSecretField(ctl, a)) return snapOf(ctl, 'field', a, markers)
    }
    const role = pointable(c, a, markers)
    if (role) return snapOf(c, role, a, markers)
  }
  return snapOf(target, 'element', a, markers)
}

/** The parent unit of a snapped unit (Alt / click again), or null at the top. */
export function climbUnit<N>(from: Snap<N>, a: NodeAccess<N>, markers: UnitMarkers, stop?: N | null): Snap<N> | null {
  if (from.role === 'block') {
    for (let c = a.parent(from.node); c; c = a.parent(c)) {
      if (a.attr(c, markers.canvas) !== null) return null
      if (a.attr(c, markers.block) !== null) return { node: c, box: c, role: 'block', label: unitLabel(c, 'block', a, markers) }
    }
    return null
  }
  // Start above the outlined box so a field's own wrapper isn't "the parent".
  for (let c = a.parent(from.box); c && c !== stop; c = a.parent(c)) {
    const role = pointable(c, a, markers)
    if (!role || role === 'field') continue
    // An unlabelled container is skipped: climbing should land somewhere nameable.
    if ((role === 'section' || role === 'card' || role === 'menu') && !unitLabel(c, role, a, markers)) continue
    return snapOf(c, role, a, markers)
  }
  return null
}

const ROLE_NAMES: Record<UnitRole | 'element', string> = {
  section: 'Section',
  card: 'Card',
  form: 'Form',
  dialog: 'Dialog',
  table: 'Table',
  row: 'Row',
  tabs: 'Tabs',
  tab: 'Tab',
  menu: 'Menu',
  option: 'Option',
  button: 'Button',
  link: 'Link',
  field: 'Field',
  block: 'Block',
  frame: 'Embedded view',
  element: 'Element',
}

/** The hover name: "Button · Save", "Row · Clean water · Draft". */
export function unitName(snap: Pick<Snap<unknown>, 'role' | 'label'>): string {
  const label = clip(snap.label, 48)
  return label ? `${ROLE_NAMES[snap.role]} · ${label}` : ROLE_NAMES[snap.role]
}

/** Cap the serialized snapshot: drop rows, then deepest children, until it fits. */
export function capUnits(units: ViewUnit[], maxChars: number): { units: ViewUnit[]; trimmed: boolean } {
  let current = units
  let trimmed = false
  const size = (u: ViewUnit[]) => JSON.stringify(u).length
  // First shorten long plain text (a thread, answers); structure goes only if that isn't enough.
  let base = units
  if (size(current) > maxChars) {
    const shorten = (list: ViewUnit[]): ViewUnit[] =>
      list.map((u) => ({ ...u, ...(u.text && u.text.length > 240 ? { text: clip(u.text, 240) } : {}), ...(u.children ? { children: shorten(u.children) } : {}) }))
    base = current = shorten(units)
    trimmed = true
  }
  for (let depth = 6; size(current) > maxChars && depth >= 1; depth--) {
    trimmed = true
    const cut = (list: ViewUnit[], d: number): ViewUnit[] =>
      list.map((u) => (u.children ? (d >= depth ? { ...u, children: undefined, more: u.children.length + (u.more ?? 0) } : { ...u, children: cut(u.children, d + 1) }) : u))
    current = cut(base, 1)
  }
  while (size(current) > maxChars && current.length > 1) {
    trimmed = true
    current = current.slice(0, Math.max(1, Math.floor(current.length * 0.75)))
  }
  return { units: current, trimmed }
}

export interface WalkStep {
  action: Exclude<RevealAction, 'collapse'>
  /** The unit id from the snapshot (data-ade-unit). */
  unit: string
  label: string
  role: UnitRole
  hidden: HiddenKind
  reveals?: string
  /** The unit's stable selector, when it has one (replayable tours). */
  stable?: string
  /** Plain words for the person: what this step shows. */
  why: string
}

const WHY: Record<WalkStep['action'], (label: string, reveals?: string) => string> = {
  open_tab: (l, r) => `Open the “${l}” tab to see ${r ? `“${r}”` : 'what it holds'}`,
  expand: (l, r) => `Expand “${l}” to see ${r ? `“${r}”` : 'what it holds'}`,
  open_menu: (l) => `Open the “${l}” menu to see its choices`,
  scroll_to: (l) => `Scroll down to “${l}”`,
}

/**
 * Every reveal needed to see the whole screen, in screen order, from one
 * snapshot. A walk runs a step, reads the fresh view the tool returns, and
 * plans again (opening a tab replaces what's below it).
 */
export function walkPlan(units: readonly ViewUnit[]): WalkStep[] {
  const out: WalkStep[] = []
  const visit = (list: readonly ViewUnit[]) => {
    for (const u of list) {
      if (u.hidden && u.action && u.action !== 'collapse') {
        out.push({ action: u.action, unit: u.id, label: u.label, role: u.role, hidden: u.hidden, ...(u.reveals ? { reveals: u.reveals } : {}), ...(u.stable ? { stable: u.stable } : {}), why: WHY[u.action](u.label || u.role, u.reveals) })
      }
      if (u.children) visit(u.children)
    }
  }
  visit(units)
  return out
}
