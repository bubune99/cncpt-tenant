/** Executable checks for how a walkthrough advances. Run: pnpm console:advance */
import assert from 'node:assert/strict'

import { ADVANCE_OPTIONS, ADVANCE_QUESTION_ID, advanceGuidance, assistantDecides, resolveAdvance, sanitizeAdvance, sanitizeAdvanceRule } from './advance'

let n = 0
const ok = (c: unknown, m: string) => { assert.ok(c, m); n++ }
const eq = <T>(a: T, b: T, m: string) => { assert.deepEqual(a, b, m); n++ }

// untrusted values
eq(sanitizeAdvance('timer'), 'timer', 'timer is a value')
eq(sanitizeAdvance('manual'), 'manual', 'manual is a value')
for (const bad of ['', 'TIMER', 'auto', null, undefined, 1, {}, ['timer']]) eq(sanitizeAdvance(bad), null, `${JSON.stringify(bad)} is not a preference`)
eq(sanitizeAdvanceRule('assistant'), 'assistant', 'assistant is a rule')
eq(sanitizeAdvanceRule('timer'), 'timer', 'timer is a rule')
eq(sanitizeAdvanceRule('whatever'), 'assistant', 'an unknown rule means the assistant decides')
eq(sanitizeAdvanceRule(undefined), 'assistant', 'no rule means the assistant decides')

// precedence: person > admin > assistant > default
eq(resolveAdvance({ steps: 4, person: 'manual', admin: 'timer', assistant: 'timer' }), { advance: 'manual', source: 'person' }, 'the person’s choice beats the admin and the assistant')
eq(resolveAdvance({ steps: 4, person: 'timer', admin: 'manual', assistant: 'manual' }), { advance: 'timer', source: 'person' }, 'in both directions')
eq(resolveAdvance({ steps: 4, admin: 'manual', assistant: 'timer' }), { advance: 'manual', source: 'admin' }, 'an admin’s rule beats the assistant')
eq(resolveAdvance({ steps: 4, admin: 'timer', assistant: 'manual' }), { advance: 'timer', source: 'admin' }, 'in both directions')
eq(resolveAdvance({ steps: 4, admin: 'assistant', assistant: 'manual' }), { advance: 'manual', source: 'assistant' }, 'when the admin leaves it to the assistant, its choice counts')
eq(resolveAdvance({ steps: 4, assistant: 'timer' }), { advance: 'timer', source: 'assistant' }, 'and with no admin rule at all')
eq(resolveAdvance({ steps: 4 }), { advance: 'timer', source: 'default' }, 'with nobody deciding, a timer')
eq(resolveAdvance({ steps: 4, person: 'sideways', admin: 'nonsense', assistant: 'later' }), { advance: 'timer', source: 'default' }, 'garbage from everyone is ignored')
eq(resolveAdvance({ steps: 1, person: 'timer', admin: 'timer', assistant: 'timer' }), { advance: 'manual', source: 'single' }, 'a single spot has nothing to advance, whoever asks')
eq(resolveAdvance({ steps: 0 }).source, 'single', 'no steps is also nothing to advance')
eq(resolveAdvance({ steps: 2, assistant: 'manual' }).advance, 'manual', 'two steps is enough to choose')

// who still decides
ok(assistantDecides({}), 'with no preference and no rule, the assistant decides')
ok(!assistantDecides({ person: 'timer' }), 'a person’s choice settles it')
ok(!assistantDecides({ admin: 'manual' }), 'and so does an admin’s rule')
ok(assistantDecides({ person: 'nonsense', admin: 'assistant' }), 'a nonsense preference does not')

// what the assistant is told
const open = advanceGuidance({})
ok(open.length === 2 && /Show me around/.test(open[0]) && /ask_user/.test(open[1]), 'with nothing decided it is told how to choose and when to ask')
ok(open[1].includes(`id "${ADVANCE_QUESTION_ID}"`) && open[1].includes('never ask twice'), 'with the exact question and never to ask twice')
ok(open[1].includes(ADVANCE_OPTIONS[0].label) && open[1].includes(ADVANCE_OPTIONS[1].label), 'and the two options')
ok(/Do not ask/.test(advanceGuidance({ person: 'timer' })[0]) && /"timer"/.test(advanceGuidance({ person: 'timer' })[0]), 'a person who chose a timer: told not to ask, and to use it')
ok(/"manual"/.test(advanceGuidance({ person: 'manual' })[0]), 'and one who chose to click')
ok(/Do not ask/.test(advanceGuidance({ admin: 'manual' })[0]) && /"manual"/.test(advanceGuidance({ admin: 'manual' })[0]), 'an admin’s rule: told not to ask')
eq(advanceGuidance({ person: 'manual', admin: 'timer' }), advanceGuidance({ person: 'manual' }), 'and the person’s choice is what it is told, not the admin’s')
ok(!advanceGuidance({ person: 'timer' }).some((l) => /ask_user/.test(l)), 'it is never offered the question once someone has decided')

console.log(`advance assertions passed: ${n} checks`)
