/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/menu-trigger.assert.ts
 */
import assert from 'node:assert/strict'
import { menuTrigger } from './menu-trigger'
import { crumbSection, resolveCrumbs } from './crumbs'

assert.deepEqual(menuTrigger('Forms'), { section: 'Forms', ariaLabel: 'Open menu — current section: Forms', title: 'Open menu — current section: Forms (Ctrl+K)' })
assert.deepEqual(menuTrigger(null), { section: null, ariaLabel: 'Open menu', title: 'Open menu (Ctrl+K)' })
assert.equal(menuTrigger(null, { platform: 'mac' }).title, 'Open menu (\u2318K)', 'a Mac sees its own key')
assert.equal(menuTrigger('   ').section, null)
assert.equal(menuTrigger('Roles  &  Permissions').section, 'Roles & Permissions')
assert.equal(menuTrigger('Forms', { open: true }).ariaLabel, 'Close menu')

// The trigger names the SAME section as the breadcrumb's section crumb.
const forms = { name: 'Forms', href: '/admin/forms' }
assert.equal(crumbSection({ parent: null, matched: forms })?.label, 'Forms')
assert.deepEqual(resolveCrumbs({ title: 'Contact us', parent: null, matched: forms, menuReady: true })[0], crumbSection({ parent: null, matched: forms }))
// A renamed menu item and a screen-declared parent resolve the same way in both.
const renamed = { name: 'News', href: '/admin/blog' }
const parent = { label: 'Blog', href: '/admin/blog' }
assert.equal(crumbSection({ parent, matched: renamed })?.label, 'News')
assert.deepEqual(resolveCrumbs({ title: 'Post', parent, matched: renamed, menuReady: true })[0], crumbSection({ parent, matched: renamed }))
// Header editor → Settings (no menu match).
assert.equal(crumbSection({ parent: { label: 'Settings', href: '/admin/settings' }, matched: null })?.label, 'Settings')
assert.equal(crumbSection({ parent: null, matched: null }), null)
console.log('12 assertions passed')
