/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/view-units.assert.ts
 */
import assert from 'node:assert/strict'
import { buildUnitTree, capUnits, climbUnit, isSecretField, isUnsafeTrigger, revealAction, snapToUnit, unitName, walkPlan, type NodeAccess, type UnitMarkers, type ViewUnit } from './view-units'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// A tiny DOM stand-in: elements with attrs, children (elements or text).
interface El { tag: string; attrs: Record<string, string>; kids: Array<El | string>; parent: El | null }
const h = (tag: string, attrs: Record<string, string> | null, ...kids: Array<El | string>): El => {
  const el: El = { tag, attrs: attrs ?? {}, kids, parent: null }
  for (const k of kids) if (typeof k !== 'string') k.parent = el
  return el
}
const rootOf = (e: El) => { let r = e; while (r.parent) r = r.parent; return r }
const all = (e: El): El[] => [e, ...e.kids.flatMap((k) => (typeof k === 'string' ? [] : all(k)))]
const textOf = (e: El): string => e.kids.map((k) => (typeof k === 'string' ? k : textOf(k))).join(' ')
const A: NodeAccess<El> = {
  tag: (e) => e.tag,
  attr: (e, name) => (name in e.attrs ? e.attrs[name] : null),
  children: (e) => e.kids.filter((k): k is El => typeof k !== 'string'),
  parent: (e) => e.parent,
  text: (e) => textOf(e).replace(/\s+/g, ' ').trim(),
  visible: (e) => !('data-invisible' in e.attrs),
  value: (e) => e.attrs.value ?? null,
  checked: (e) => (e.attrs.type === 'checkbox' ? 'checked' in e.attrs : null),
  labels: (e) => {
    const out: El[] = []
    if (e.attrs.id) out.push(...all(rootOf(e)).filter((x) => x.tag === 'label' && x.attrs.for === e.attrs.id))
    for (let p = e.parent; p; p = p.parent) if (p.tag === 'label') out.push(p)
    return out
  },
  byId: (id, near) => all(rootOf(near)).find((x) => x.attrs.id === id) ?? null,
  below: (e) => (e.attrs['data-below'] ? Number(e.attrs['data-below']) : null),
}
const M: UnitMarkers = { canvas: 'data-site-canvas', block: 'data-block-id', controls: ['data-ui', 'data-help-key'] }
const flat = (us: ViewUnit[]): ViewUnit[] => us.flatMap((u) => [u, ...flat(u.children ?? [])])

// A settings-like screen: a section with a form, a secret, a list table, a card, and icon-only controls.
const saveIcon = h('svg', { 'aria-hidden': 'true' }, h('path', null))
const saveBtn = h('button', { 'data-ui': 'settings.save' }, saveIcon, h('span', null, 'Save'))
const nameLabel = h('label', { for: 'site-name' }, 'Site name')
const nameInput = h('input', { id: 'site-name', value: 'Dzidzor Project' })
const nameRow = h('div', { class: 'grid gap-1' }, nameLabel, nameInput)
const emailInput = h('input', { id: 'contact', value: 'hello@example.org', required: '' })
const pw = h('input', { type: 'password', id: 'smtp-pass', value: 'hunter2' })
const hidden = h('input', { type: 'hidden', name: 'csrf', value: 'abc' })
const apiKey = h('input', { id: 'resend', value: 're_9f8a7b6c5d4e3f2a1b0c' })
const tokenBudget = h('input', { id: 'dailyTokenBudget', value: '200000' })
const budgetLabel = h('label', { for: 'dailyTokenBudget' }, 'Daily token budget')
const toggle = h('button', { role: 'switch', 'aria-checked': 'true', 'aria-label': 'Maintenance mode' })
const form = h('form', { 'aria-label': 'General' },
  nameRow,
  h('div', null, h('label', { for: 'contact' }, 'Contact email'), emailInput),
  h('div', null, h('label', { for: 'smtp-pass' }, 'SMTP password'), pw),
  hidden,
  h('div', null, h('label', { for: 'resend' }, 'Provider'), apiKey),
  h('div', null, budgetLabel, tokenBudget),
  toggle,
  saveBtn,
)
const cell = h('span', { class: 'truncate' }, 'Clean water')
const row1 = h('tr', null, h('td', null, cell), h('td', null, 'Draft'), h('td', null, h('a', { href: '/admin/initiatives/1' }, h('svg', null), 'Edit')))
const rows = [row1, ...Array.from({ length: 11 }, (_, i) => h('tr', null, h('td', null, `Item ${i + 2}`), h('td', null, 'Published'), h('td', null, h('a', { href: `/x/${i}` }, 'Edit'))))]
const table = h('table', null, h('thead', null, h('tr', null, h('th', null, 'Name'), h('th', null, 'Status'), h('th', null, ''))), h('tbody', null, ...rows))
const kpi = h('div', { 'data-slot': 'card' }, h('div', { 'data-slot': 'card-title' }, 'Donations'), h('p', null, '$1,200 this month'))
const section = h('section', null, h('h2', null, 'Site settings'), h('div', null, h('div', null, form)))
const hiddenPanel = h('div', { hidden: '' }, h('button', null, 'Ghost'))
const invisible = h('div', { 'data-invisible': '' }, h('button', null, 'Collapsed'))
const tabs = h('div', { role: 'tablist' }, h('button', { role: 'tab', 'aria-selected': 'true' }, 'General'), h('button', { role: 'tab', 'aria-selected': 'false' }, 'Privacy'))
const wrapper = h('div', null, h('div', null, h('div', null, kpi)))
const screen = h('main', { 'data-ade-screen': '' }, h('h1', null, 'Settings'), tabs, section, h('section', { 'aria-label': 'Initiatives' }, table), wrapper, hiddenPanel, invisible)

const tree = buildUnitTree(screen, A, { markers: M })
const units = flat(tree.units)

check('the screen reads as functional units, in visual order, with ids mapped to nodes', () => {
  assert.deepEqual(tree.units.map((u) => u.role), ['tabs', 'section', 'section', 'card'])
  assert.equal(tree.units[1].label, 'Site settings')
  assert.equal(tree.units[2].label, 'Initiatives')
  for (const u of units) assert.ok(tree.nodes.has(u.id), u.id)
  assert.equal(tree.nodes.get(units.find((u) => u.label === 'Save')!.id), saveBtn)
  assert.equal(new Set(units.map((u) => u.id)).size, units.length, 'ids are unique')
})

check('fields carry their label, value and state; a switch reads on/off', () => {
  const f = units.filter((u) => u.role === 'field')
  const name = f.find((u) => u.label === 'Site name')!
  assert.equal(name.value, 'Dzidzor Project')
  const email = f.find((u) => u.label === 'Contact email')!
  assert.equal(email.value, '[email]', 'personal details redacted')
  assert.equal(email.state, 'required')
  const sw = f.find((u) => u.label === 'Maintenance mode')!
  assert.equal(sw.state, 'on')
  assert.equal(f.find((u) => u.label === 'Daily token budget')?.value, '200000', '"token budget" is not a secret')
})

check('NEVER: password, hidden and key-shaped inputs are absent (not even their labels)', () => {
  const json = JSON.stringify(tree.units)
  for (const bad of ['hunter2', 'SMTP password', 'csrf', 'abc', 're_9f8a7b6c5d4e3f2a1b0c', 'Provider']) assert.ok(!json.includes(bad), bad)
  assert.ok(isSecretField(pw, A) && isSecretField(hidden, A) && isSecretField(apiKey, A))
  assert.ok(!isSecretField(tokenBudget, A) && !isSecretField(nameInput, A))
  assert.ok(isSecretField(h('input', { name: 'apiKey', value: 'x' }), A), 'camelCase apiKey')
  assert.ok(isSecretField(h('input', { autocomplete: 'one-time-code' }), A))
})

check('hidden / aria-hidden / invisible things and lone icons never become units', () => {
  const labels = units.map((u) => u.label)
  assert.ok(!labels.includes('Ghost') && !labels.includes('Collapsed'))
  assert.ok(!units.some((u) => /svg|span|path/.test(u.role)))
})

check('tables: columns, first 8 rows of 12, each row named by its cells with its own controls', () => {
  const t = units.find((u) => u.role === 'table')!
  assert.deepEqual(t.columns, ['Name', 'Status'])
  assert.deepEqual(t.rows, { shown: 8, total: 12 })
  assert.equal(t.children!.length, 8)
  assert.equal(t.children![0].label, 'Clean water · Draft · Edit')
  assert.deepEqual(t.children![0].children!.map((c) => `${c.role}:${c.label}`), ['link:Edit'])
})

check('tabs keep their selected state; a card with only text carries it as value; an unlabelled wrapper collapses', () => {
  const t = tree.units[0]
  assert.deepEqual(t.children!.map((c) => [c.label, c.state ?? '']), [['General', 'selected'], ['Privacy', '']])
  const card = tree.units[3]
  assert.equal(card.label, 'Donations')
  assert.equal(card.value, '$1,200 this month')
})

check('maxUnits caps the walk and says so', () => {
  const small = buildUnitTree(screen, A, { markers: M, maxUnits: 5 })
  assert.ok(small.truncated)
  assert.ok(flat(small.units).length <= 5)
})

check('capUnits trims to a size budget (drops depth first, then trailing units)', () => {
  const full = JSON.stringify(tree.units).length
  const capped = capUnits(tree.units, Math.floor(full / 2))
  assert.ok(capped.trimmed)
  assert.ok(JSON.stringify(capped.units).length <= Math.floor(full / 2))
  assert.ok(flat(capped.units).some((u) => u.more), 'trimmed parents say how many children were left out')
  assert.deepEqual(capUnits(tree.units, full + 10), { units: tree.units, trimmed: false })
})

// ---- Snapping ----
check('snap: an icon inside a button snaps to the button; text in a cell snaps to the row', () => {
  const s = snapToUnit(saveIcon, A, M)
  assert.equal(s.node, saveBtn)
  assert.equal(unitName(s), 'Button · Save')
  const r = snapToUnit(cell, A, M)
  assert.equal(r.node, row1)
  assert.equal(r.role, 'row')
})

check('snap: a field (or its label) outlines the field together with its label', () => {
  const s = snapToUnit(nameInput, A, M)
  assert.equal(s.node, nameInput)
  assert.equal(s.box, nameRow, 'box = wrapper holding label + input')
  assert.equal(unitName(s), 'Field · Site name')
  const viaLabel = snapToUnit(nameLabel, A, M)
  assert.equal(viaLabel.node, nameInput)
})

check('snap: never a secret field — its label snaps past it to the form', () => {
  const pwLabel = pw.parent!.kids[0] as El
  const s = snapToUnit(pwLabel, A, M)
  assert.notEqual(s.node, pw)
  assert.equal(s.role, 'form')
})

check('climb (Alt / click again): button → form → section → null at the screen', () => {
  const s = snapToUnit(saveIcon, A, M)
  const up1 = climbUnit(s, A, M, screen)!
  assert.equal(up1.role, 'form')
  assert.equal(unitName(up1), 'Form · General')
  const up2 = climbUnit(up1, A, M, screen)!
  assert.equal(up2.label, 'Site settings')
  assert.equal(climbUnit(up2, A, M, screen), null)
  // A field climbs from its label box, not to its own wrapper.
  const f = climbUnit(snapToUnit(nameInput, A, M), A, M, screen)!
  assert.equal(f.role, 'form')
  // A row climbs to its labelled section (the table itself is a unit too).
  assert.equal(climbUnit(snapToUnit(cell, A, M), A, M, screen)!.role, 'table')
})

check('page canvas keeps fine picking: the block (nested blocks climb block by block)', () => {
  const inner = h('h2', { 'data-block-id': 'b2' }, h('span', null, 'Our story'))
  const outer = h('section', { 'data-block-id': 'b1', 'data-block-label': 'Hero' }, inner)
  const canvas = h('div', { 'data-site-canvas': '' }, outer)
  h('main', null, canvas)
  const span = inner.kids[0] as El
  const s = snapToUnit(span, A, M)
  assert.equal(s.node, inner)
  assert.equal(s.role, 'block')
  const up = climbUnit(s, A, M)!
  assert.equal(up.node, outer)
  assert.equal(unitName(up), 'Block · Hero')
  assert.equal(climbUnit(up, A, M), null)
  // Inside the canvas a <section> is a block, not a functional section.
  assert.equal(buildUnitTree(canvas, A, { markers: M }).units[0].role, 'block')
})

check('dialogs, frames and nothing-to-snap fallbacks', () => {
  const dlg = h('div', { role: 'dialog', 'aria-labelledby': 'dt' }, h('h2', { id: 'dt' }, 'Delete page?'), h('button', null, 'Cancel'), h('button', null, 'Delete'))
  h('body', null, dlg)
  const d = buildUnitTree(h('div', null, dlg), A, { markers: M }).units[0]
  assert.equal(d.role, 'dialog')
  assert.equal(d.label, 'Delete page?')
  assert.deepEqual(d.children!.map((c) => c.label), ['Cancel', 'Delete'])
  const lone = h('span', null, 'just text')
  h('div', null, lone)
  assert.equal(snapToUnit(lone, A, M).role, 'element')
  assert.equal(buildUnitTree(h('div', null, h('iframe', { title: 'Preview' })), A, { markers: M }).units[0].label, 'Preview')
})

// ---- Hidden UI + reveal actions + walk plan ----
{
  const tabGeneral = h('button', { role: 'tab', type: 'button', 'aria-selected': 'true', 'aria-controls': 'p-general' }, 'General')
  const tabPrivacy = h('button', { role: 'tab', type: 'button', 'aria-selected': 'false', 'aria-controls': 'p-privacy' }, 'Privacy')
  const panelPrivacy = h('div', { role: 'tabpanel', id: 'p-privacy', 'aria-label': 'Privacy & cookies', hidden: '' })
  const accTrigger = h('button', { type: 'button', 'aria-expanded': 'false', 'aria-controls': 'r-email' }, 'Email')
  const accRegion = h('section', { id: 'r-email', 'aria-label': 'Email delivery', hidden: '' })
  const openAcc = h('button', { type: 'button', 'aria-expanded': 'true', 'aria-controls': 'r-site' }, 'Site')
  const more = h('button', { type: 'button', 'aria-haspopup': 'menu', 'aria-expanded': 'false', 'aria-label': 'More options' })
  const deleteMenu = h('button', { type: 'button', 'aria-haspopup': 'dialog', 'aria-expanded': 'false' }, 'Delete site')
  const formToggle = h('button', { 'aria-expanded': 'false' }, 'Advanced')
  const submit = h('button', { type: 'submit', 'aria-expanded': 'false' }, 'Details')
  const link = h('a', { href: '/admin/settings/privacy', 'aria-expanded': 'false' }, 'Privacy page')
  const details = h('details', null, h('summary', null, 'Show raw JSON'), h('pre', null, '{}'))
  const deep = h('button', { type: 'button', 'data-below': '40' }, 'Deep button')
  const farSection = h('section', { 'aria-label': 'Danger zone', 'data-below': '620' }, h('h2', null, 'Danger zone'), deep)
  const settings = h('main', null,
    h('div', { role: 'tablist', 'aria-label': 'Settings tabs' }, tabGeneral, tabPrivacy), panelPrivacy,
    h('section', { 'aria-label': 'General' }, accTrigger, accRegion, openAcc, more, deleteMenu, details, h('form', { 'aria-label': 'Site form' }, formToggle, submit), link),
    farSection,
  )
  const t = buildUnitTree(settings, A, { markers: M })
  const u = flat(t.units)
  const by = (label: string) => u.find((x) => x.label === label)!

  check('hidden UI is marked, not dropped: inactive tab, closed accordion, closed menu, below the fold', () => {
    assert.deepEqual([by('Privacy').hidden, by('Privacy').action, by('Privacy').reveals], ['inactive-tab', 'open_tab', 'Privacy & cookies'])
    assert.equal(by('General').hidden, undefined, 'the selected tab is not hidden')
    assert.deepEqual([by('Email').hidden, by('Email').action, by('Email').reveals], ['collapsed', 'expand', 'Email delivery'])
    assert.deepEqual([by('Site').hidden, by('Site').action], [undefined, 'collapse'], 'an open accordion can be collapsed, nothing is hidden')
    assert.deepEqual([by('More options').hidden, by('More options').action], ['menu', 'open_menu'])
    assert.equal(by('Show raw JSON').action, 'expand', '<summary> of a closed <details>')
    const far = by('Danger zone')
    assert.deepEqual([far.hidden, far.action, far.below], ['below-fold', 'scroll_to', 620])
    assert.equal(by('Deep button').hidden, undefined, 'below the fold is said once, on the outer unit')
    assert.equal(by('Deep button').below, undefined)
  })

  check('only safe triggers are actionable: never submit, links, untyped form buttons or destructive labels', () => {
    for (const x of [deleteMenu, formToggle, submit, link]) assert.equal(revealAction(x, A, M), null, A.text(x))
    for (const x of [deleteMenu, formToggle, submit, link]) assert.ok(isUnsafeTrigger(x, A, M), A.text(x))
    assert.ok(isUnsafeTrigger(h('button', { type: 'button', 'aria-expanded': 'false' }, 'Save changes'), A, M))
    assert.ok(isUnsafeTrigger(h('button', { type: 'button', 'aria-expanded': 'false', disabled: '' }, 'More'), A, M))
    assert.equal(revealAction(h('button', { type: 'button' }, 'Plain'), A, M), null, 'a plain button reveals nothing')
    for (const x of [tabPrivacy, accTrigger, more]) assert.ok(!isUnsafeTrigger(x, A, M), A.text(x))
    assert.equal(by('Delete site').action, undefined)
    assert.equal(by('Details').action, undefined)
  })

  check('walkPlan lists every reveal in screen order, with plain reasons (no collapse steps)', () => {
    const plan = walkPlan(t.units)
    assert.deepEqual(plan.map((p) => [p.action, p.label]), [
      ['open_tab', 'Privacy'], ['expand', 'Email'], ['open_menu', 'More options'], ['expand', 'Show raw JSON'], ['scroll_to', 'Danger zone'],
    ])
    assert.equal(plan[0].why, 'Open the “Privacy” tab to see “Privacy & cookies”')
    assert.equal(plan[0].unit, by('Privacy').id)
    assert.deepEqual(Object.keys(plan[0]).sort(), ['action', 'hidden', 'label', 'reveals', 'role', 'unit', 'why'])
    assert.deepEqual(walkPlan([]), [])
  })
}

check('panel switchers (a section list swapping one panel) open like tabs; the current one offers nothing', () => {
  const panel = h('main', { id: 'settings-section', 'aria-label': 'Identity & brand' }, h('h2', null, 'Identity & brand'))
  const cur = h('button', { type: 'button', 'aria-controls': 'settings-section', 'aria-current': 'page', 'data-ui': 'settings.nav.identity' }, 'Identity & brand')
  const other = h('button', { type: 'button', 'aria-controls': 'settings-section', 'data-ui': 'settings.nav.privacy' }, 'Cookie & privacy banner')
  const ext = h('a', { href: '/admin/site-settings/header', 'data-ui': 'settings.nav.header' }, 'Header')
  const screen2 = h('div', null, h('aside', { 'aria-label': 'Settings sections' }, h('nav', null, h('ul', null, h('li', null, cur), h('li', null, other), h('li', null, ext)))), panel)
  const t2 = flat(buildUnitTree(screen2, A, { markers: M }).units)
  const o = t2.find((x) => x.label === 'Cookie & privacy banner')!
  assert.deepEqual([o.hidden, o.action, o.reveals], ['inactive-tab', 'open_tab', undefined], 'no misleading "reveals" (the panel shows the current section)')
  assert.equal(t2.find((x) => x.label === 'Identity & brand' && x.role === 'button')!.action, undefined)
  assert.equal(t2.find((x) => x.label === 'Header')!.action, undefined, 'a link to another editor is navigation, never a reveal')
  assert.deepEqual(walkPlan(buildUnitTree(screen2, A, { markers: M }).units).map((p) => p.label), ['Cookie & privacy banner'])
})

check('the switch has LANDED only when the pressed button becomes current (what open_tab waits for)', () => {
  const cur = h('button', { type: 'button', 'aria-controls': 'p', 'aria-current': 'page' }, 'Identity & brand')
  const other = h('button', { type: 'button', 'aria-controls': 'p' }, 'Cookie & privacy banner')
  h('nav', null, cur, other, h('main', { id: 'p' }))
  assert.equal(revealAction(other, A, M), 'open_tab')
  // router.replace has run but the section hasn't committed yet: still not landed.
  assert.equal(revealAction(other, A, M), 'open_tab')
  // The panel commits: aria-current moves.
  delete cur.attrs['aria-current']
  other.attrs['aria-current'] = 'page'
  assert.equal(revealAction(other, A, M), null, 'landed: nothing left to open')
  assert.equal(revealAction(cur, A, M), 'open_tab')
})

check('stable selectors: control names first, then aria-label scoped to role/tag, else none', () => {
  const MK: UnitMarkers = { ...M, controls: ['data-ui', 'data-tour-id', 'data-help-key'] }
  const sel = (attrs: Record<string, string>, tag = 'button') => buildUnitTree(h('div', null, h(tag, attrs, 'x')), A, { markers: MK }).units[0].stable
  assert.equal(sel({ 'data-ui': 'settings.save', 'data-tour-id': 't', 'aria-label': 'Save' }), '[data-ui="settings.save"]')
  assert.equal(sel({ 'data-tour-id': 'nav-forms', 'data-help-key': 'k' }), '[data-tour-id="nav-forms"]')
  assert.equal(sel({ 'data-help-key': 'admin.kpi' }), '[data-help-key="admin.kpi"]')
  assert.equal(sel({ role: 'tab', 'aria-label': 'Privacy "beta"' }), '[role="tab"][aria-label="Privacy \\"beta\\""]')
  assert.equal(sel({ 'aria-label': 'More options' }), 'button[aria-label="More options"]')
  assert.equal(sel({}), undefined)
})

// ---- Visibility policy: masking inside the builder ----
{
  // privacy(marker): secret blocked; contact masked for this viewer; unknown → (builder default) metadata-only.
  const privacy = (m: string) => (m === 'secret' ? 'blocked' : m === 'contact' ? 'metadata-only' : m === 'ok' ? 'readable' : 'metadata-only') as 'blocked' | 'metadata-only' | 'readable'
  const emailTh = h('th', { 'data-ade-private': 'contact' }, 'Email')
  const subs = h('table', { 'aria-label': 'Submissions' },
    h('thead', null, h('tr', null, h('th', null, 'Name'), emailTh, h('th', null, 'Message'))),
    h('tbody', null,
      h('tr', null, h('td', null, 'Ama Mensah'), h('td', null, 'ama@example.org'), h('td', null, 'Can I volunteer?')),
      h('tr', null, h('td', null, 'Kofi'), h('td', { 'data-ade-private': 'contact' }, '+233 20 000 0000'), h('td', null, h('a', { href: '/x' }, 'Open')))))
  const keyField = h('div', { 'data-ade-private': 'secret' }, h('label', { for: 'k' }, 'Resend key'), h('input', { id: 'k', value: 'abc' }))
  const phone = h('input', { id: 'ph', value: '0201234567', 'data-ade-private': 'contact', 'aria-label': 'Phone' })
  const kpi = h('div', { 'data-slot': 'card' }, h('div', { 'data-slot': 'card-title' }, 'Total donors'), h('p', null, '1,204'))
  const scr = h('main', null, h('section', { 'aria-label': 'Inbox' }, subs, keyField, phone, kpi))

  check('privacy markers: blocked content is left out, contact cells/columns read [private], masked list says what (labels only)', () => {
    const t = buildUnitTree(scr, A, { markers: M, privacy })
    const json = JSON.stringify(t.units)
    for (const leak of ['ama@example.org', '+233', 'abc', 'Resend key']) assert.ok(!json.includes(leak), leak)
    const rows = flat(t.units).filter((u) => u.role === 'row')
    assert.equal(rows[0].label, 'Ama Mensah · [private] · Can I volunteer?', 'a private column header hides that cell in every row')
    assert.equal(rows[1].label, 'Kofi · [private] · Open')
    const ph = flat(t.units).find((u) => u.label === 'Phone')!
    assert.deepEqual([ph.private, ph.value, ph.state], [true, undefined, 'filled'])
    assert.equal(flat(t.units).find((u) => u.label === 'Total donors')!.value, '1,204', 'unmarked content stays readable')
    assert.deepEqual(t.masked, [
      { target: 'Submissions', field: 'Email', kind: 'policy', marker: 'contact' },
      { target: 'Inbox', field: 'Private content', kind: 'policy', marker: 'secret' },
      { target: 'Inbox', field: 'Phone', kind: 'policy', marker: 'contact' },
    ])
    assert.ok(!JSON.stringify(t.masked).match(/ama@|abc|\+233/), 'labels only, never values')
  })

  check('metadata-only screen: labels, roles and counts only — no values, row text, row links or card text', () => {
    const t = buildUnitTree(scr, A, { markers: M, privacy, level: 'metadata-only' })
    const u = flat(t.units)
    const json = JSON.stringify(t.units)
    for (const leak of ['Ama', 'Kofi', 'volunteer', '1,204', '0201234567']) assert.ok(!json.includes(leak), leak)
    const table = u.find((x) => x.role === 'table')!
    assert.deepEqual([table.label, table.columns, table.rows], ['Submissions', ['Name', 'Email', 'Message'], { shown: 2, total: 2 }])
    assert.deepEqual(table.children!.map((r) => [r.label, r.children]), [['Row 1', undefined], ['Row 2', undefined]])
    assert.ok(t.masked.some((m) => m.target === 'Submissions' && m.field === 'rows'))
  })

  check('a viewer allowed to see contact (owner) sees it; a marker the rules allow is plain', () => {
    // Readable by the rules but the area doesn't let the assistant follow the person: withheld,
    // exactly as capture_view paints it over (the stricter side), and reported under its rule.
    const t = buildUnitTree(scr, A, { markers: M, privacy: (m) => (m === 'secret' ? 'blocked' : 'readable') })
    const rows = flat(t.units).filter((x) => x.role === 'row')
    assert.equal(rows[0].label, 'Ama Mensah · [private] · Can I volunteer?')
    assert.ok(t.masked.some((m) => m.kind === 'policy' && m.marker === 'contact'), 'reported as the contact rule, not as redaction')
    // The owner switched "Assistant follows the person" on for contact: raw.
    const on = buildUnitTree(scr, A, { markers: M, privacy: (m) => (m === 'secret' ? 'blocked' : 'readable'), showRaw: (m) => m === 'contact' })
    assert.equal(flat(on.units).filter((x) => x.role === 'row')[0].label, 'Ama Mensah · ama@example.org · Can I volunteer?')
    assert.ok(!JSON.stringify(t.units).includes('abc'), 'secrets stay out for everyone')
  })

  check('cell-marked columns are masked even when the header is NOT marked', () => {
    const t2 = h('table', { 'aria-label': 'Registrations' },
      h('thead', null, h('tr', null, h('th', null, 'Name'), h('th', null, 'Email'))),
      h('tbody', null,
        h('tr', null, h('td', null, 'Esi'), h('td', { 'data-ade-private': 'contact' }, 'esi@example.org')),
        h('tr', null, h('td', null, 'Yaw'), h('td', { 'data-ade-private': 'contact' }, 'yaw@example.org'))))
    const t = buildUnitTree(h('main', null, t2), A, { markers: M, privacy })
    const rows = flat(t.units).filter((u) => u.role === 'row')
    assert.deepEqual(rows.map((r) => r.label), ['Esi · [private]', 'Yaw · [private]'])
    assert.ok(!JSON.stringify(t.units).includes('@example.org'))
    assert.deepEqual(flat(t.units).find((u) => u.role === 'table')!.columns, ['Name', 'Email'], 'column names are layout, not data')
  })

  check('private text never leaks through a card value or a link label built from whole text', () => {
    const card = h('article', null, h('h3', null, 'Kwame Boateng'), h('p', { 'data-ade-private': 'contact' }, 'K-77 Ring Road'), h('p', null, '3 orders'))
    const link = h('a', { href: '/admin/customers/1' }, 'Open ', h('span', { 'data-ade-private': 'contact' }, 'K-77 Ring Road'))
    const t = buildUnitTree(h('main', null, card, link), A, { markers: M, privacy })
    const json = JSON.stringify(t.units)
    assert.ok(!json.includes('Ring Road'), json)
    assert.ok(json.includes('3 orders'))
  })

  check('owner + readable marker: withheld + reported under its rule unless the area follows the person; unmarked emails redacted (run bc981ea7)', () => {
    const t3 = h('table', { 'aria-label': 'Submissions' },
      h('thead', null, h('tr', null, h('th', null, 'Name'), h('th', null, 'Email'))),
      h('tbody', null, h('tr', null, h('td', null, 'Esi'), h('td', { 'data-ade-private': 'contact' }, 'esi@example.org'))))
    // Marked + readable for the owner, area switch off (default): withheld under its rule (area.contact), not "redaction".
    const t = buildUnitTree(h('main', null, t3), A, { markers: M, privacy: () => 'readable' })
    assert.equal(flat(t.units).find((u) => u.role === 'row')!.label, 'Esi · [private]')
    assert.deepEqual(t.masked, [{ target: 'Submissions', field: 'Email', kind: 'policy', marker: 'contact' }])
    // Switch on ("Assistant follows the person"): shown, nothing masked.
    const sw = buildUnitTree(h('main', null, t3), A, { markers: M, privacy: () => 'readable', showRaw: () => true })
    assert.equal(flat(sw.units).find((u) => u.role === 'row')!.label, 'Esi · esi@example.org')
    assert.deepEqual(sw.masked, [])
    // An UNMARKED email column is still redacted like any tool output — and that is reported.
    const t4 = h('table', { 'aria-label': 'Registrations' },
      h('thead', null, h('tr', null, h('th', null, 'Name'), h('th', null, 'Email'))),
      h('tbody', null, h('tr', null, h('td', null, 'Esi'), h('td', null, 'esi@example.org'))))
    const u4 = buildUnitTree(h('main', null, t4), A, { markers: M, privacy: () => 'readable' })
    assert.equal(flat(u4.units).find((u) => u.role === 'row')!.label, 'Esi · [email]')
    assert.deepEqual(u4.masked, [{ target: 'Registrations', field: 'Email', kind: 'redaction' }])
  })

  check('panes read with the screen (editor Blocks/Properties beside the chat, passed as `before`) are masked the same way', () => {
    const props = h('aside', { 'aria-label': 'Properties' },
      h('label', { for: 'pe' }, 'Contact email'), h('input', { id: 'pe', value: 'esi@example.org', 'data-ade-private': 'contact' }),
      h('label', { for: 'pk' }, 'API key'), h('input', { id: 'pk', value: 'sk_live_abcdefghijklmnop', 'data-ade-private': 'secret' }),
      h('p', { 'data-ade-private': 'contact' }, '+233 20 111 2222'))
    const screenRoot = h('main', null, h('h1', null, 'Editor'))
    const t = buildUnitTree(screenRoot, A, { markers: M, privacy, before: [props] })
    const json = JSON.stringify(t.units)
    for (const leak of ['esi@example.org', 'sk_live', '+233', 'API key']) assert.ok(!json.includes(leak), leak)
    const field = flat(t.units).find((u) => u.label === 'Contact email')!
    assert.deepEqual([field.private, field.value, field.state], [true, undefined, 'filled'])
    assert.ok(t.masked.some((m) => m.target === 'Properties' && m.field === 'Contact email' && m.marker === 'contact'))
    // A layout-only screen applies to the pane too.
    const meta = buildUnitTree(screenRoot, A, { markers: M, privacy: () => 'readable', level: 'metadata-only', before: [props] })
    assert.ok(!JSON.stringify(meta.units).includes('esi@example.org'))
  })

  check('read_view agrees with capture_view: a granted role with the switch off gets no marked address in card text', () => {
    // Customers card: the address is marked contact; the rules let this person read it, the area's switch is off.
    const card = h('article', null, h('h3', null, 'Kwame Boateng'), h('p', { 'data-ade-private': 'contact' }, 'K-77 Ring Road, Accra'), h('p', null, '3 orders'))
    const off = buildUnitTree(h('main', null, card), A, { markers: M, privacy: () => 'readable' })
    assert.ok(!JSON.stringify(off.units).includes('Ring Road'), 'stricter side: like the screenshot, which paints it over')
    assert.ok(off.masked.some((m) => m.kind === 'policy' && m.marker === 'contact'))
    const on = buildUnitTree(h('main', null, card), A, { markers: M, privacy: () => 'readable', showRaw: () => true })
    assert.ok(JSON.stringify(on.units).includes('Ring Road'), 'switch on: shown')
  })

  check('scrub before cutting: a long card value never leaks the start of a withheld text', () => {
    const filler = 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna'
    const card = h('article', null, h('h3', null, 'Donor'), h('p', null, filler), h('p', { 'data-ade-private': 'contact' }, 'Private Road 99, Kumasi Ghana'))
    const t = buildUnitTree(h('main', null, card), A, { markers: M, privacy: () => 'metadata-only' })
    const json = JSON.stringify(t.units)
    for (const frag of ['Private Road', 'Priv', 'Kumasi']) assert.ok(!json.includes(frag), frag)
    // A label already cut ("…") that ends in the start of a withheld text loses that fragment too.
    const link = h('a', { href: '/x' }, `${'x'.repeat(70)} `, h('span', { 'data-ade-private': 'contact' }, 'Secret Street 12'))
    const l = buildUnitTree(h('main', null, link), A, { markers: M, privacy: () => 'metadata-only' })
    assert.ok(!/Secr|Secret/.test(JSON.stringify(l.units)), JSON.stringify(l.units))
  })

  check('no policy given: unknown markers are private by default (fail closed)', () => {
    const t = buildUnitTree(scr, A, { markers: M })
    assert.equal(flat(t.units).find((x) => x.label === 'Phone')!.value, undefined)
  })
}

// ── Lists and threads (BYB Messages; Dzidzor To-do and submissions have the same shape) ──
{
  const thread = (i: number, current = false) =>
    h('div', { role: 'button', tabindex: '0', ...(current ? { 'aria-current': 'true' } : {}) }, h('div', null, h('b', null, `Person ${i}`), h('div', null, `Subject ${i}`), h('div', null, `Preview ${i}`)), h('span', null, '2h'))
  const inbox = (count: number, currentAt = 0) =>
    h('section', { 'aria-label': 'Conversations' },
      h('div', null, h('input', { type: 'search', 'aria-label': 'Search people' }), h('div', { role: 'group', 'aria-label': 'Channel' }, ...['All', 'Email', 'SMS'].map((c) => h('button', { 'aria-pressed': 'false' }, c)))),
      h('div', null, ...Array.from({ length: count }, (_, i) => thread(i, i === currentAt))))
  const conversation = (...extra: El[]) =>
    h('section', { 'aria-label': 'Conversation: Order 1042' },
      h('div', null, h('button', { 'aria-label': 'Back to the list' }), h('h2', null, 'Order 1042'), h('button', null, 'Done')),
      h('div', null,
        h('div', null, h('div', null, 'Hi, can I swap the hoodie for a large?'), h('div', null, h('span', null, 'Email · 10:01'))),
        h('div', null, h('div', null, 'Of course, I have changed it to large.'), h('div', null, h('span', null, 'Email · 10:05'), h('button', null, 'Resend'))),
        ...extra))
  const messages = (count: number, currentAt = 0, ...extra: El[]) => h('main', null, h('h1', null, 'Messages'), h('div', null, inbox(count, currentAt), conversation(...extra)))

  check('Messages: the filter strip, the conversation list AND the open thread are all read', () => {
    const t = buildUnitTree(messages(5), A, { markers: M })
    const all = flat(t.units)
    const list = all.find((u) => u.label === 'Conversations')!
    assert.ok(list.children!.some((u) => u.label === 'Search people'), 'filter strip')
    assert.equal(list.children!.filter((u) => u.role === 'button' && /^Person/.test(u.label)).length, 5, 'every conversation')
    assert.match(list.children!.find((u) => u.label.startsWith('Person 0'))!.state!, /current/)
    const convo = all.find((u) => u.label === 'Conversation: Order 1042')!
    assert.match(convo.text!, /swap the hoodie for a large/)
    assert.match(convo.text!, /changed it to large/)
    assert.match(convo.text!, /Email · 10:05/)
    assert.ok(!/Resend|Done/.test(convo.text!), 'controls are units, not text')
    assert.ok(convo.children!.some((u) => u.label === 'Resend'))
  })

  check('a long list keeps its first items and the current one, counts the rest, and leaves room for the thread', () => {
    const t = buildUnitTree(messages(200, 150), A, { markers: M })
    const list = flat(t.units).find((u) => u.label === 'Conversations')!
    const rows = list.children!.filter((u) => /^Person/.test(u.label))
    assert.equal(rows.length, 13, '12 + the current one')
    assert.ok(rows.some((u) => u.label.startsWith('Person 150')), 'the open conversation stays')
    assert.equal(list.more, 187)
    assert.ok(list.children!.filter((u) => u.label !== 'Channel' && !/^Person/.test(u.label)).length >= 1, 'search survives')
    assert.equal(flat(list.children!).filter((u) => ['All', 'Email', 'SMS'].includes(u.label)).length, 3, 'chips are not list items of the same run')
    assert.match(flat(t.units).find((u) => u.label === 'Conversation: Order 1042')!.text!, /swap the hoodie/)
    assert.equal(t.truncated, false)
    // Under the size cap too: the thread is not the part that goes.
    const capped = capUnits(t.units, 3000).units
    assert.ok(JSON.stringify(capped).includes('Conversation: Order 1042'))
  })

  check('a focused read lifts the list cap (itemsPerList), so "more" can always be seen', () => {
    const t = buildUnitTree(messages(40), A, { markers: M, itemsPerList: 80 })
    const list = flat(t.units).find((u) => u.label === 'Conversations')!
    assert.equal(list.children!.filter((u) => /^Person/.test(u.label)).length, 40)
    assert.equal(list.more, undefined)
  })

  check('role=list/log/feed are containers; a To-do listbox of options is capped the same way', () => {
    const log = h('div', { role: 'log', 'aria-label': 'Activity' }, h('p', null, 'Ama approved the page'), h('p', null, 'Kofi sent a reply'))
    const t = buildUnitTree(h('main', null, log, h('button', null, 'Refresh')), A, { markers: M })
    const act = t.units.find((u) => u.label === 'Activity')
    assert.ok(act, JSON.stringify(t.units))
    assert.equal(act!.text, 'Ama approved the page · Kofi sent a reply', 'a labelled log with no controls still says what it holds')
    const todo = h('ul', { role: 'listbox', 'aria-label': 'Items' }, ...Array.from({ length: 30 }, (_, i) => h('li', { role: 'option', 'aria-selected': i === 20 ? 'true' : 'false' }, `To-do ${i}`)))
    const tt = buildUnitTree(h('main', null, todo), A, { markers: M })
    const items = tt.units.find((u) => u.label === 'Items')!
    assert.equal(items.children!.length, 13)
    assert.ok(items.children!.some((u) => u.label === 'To-do 20'), 'the selected one stays')
    assert.equal(items.more, 17)
  })

  check('container text follows the privacy rules: withheld → [private] + a note; metadata-only → none; secret labels never', () => {
    const withAddr = messages(2, 0, h('div', null, h('span', { 'data-ade-private': 'contact' }, 'ama@example.org'), h('span', null, ' wrote in')))
    const t = buildUnitTree(withAddr, A, { markers: M, privacy: () => 'readable' })
    const json = JSON.stringify(t.units)
    assert.ok(!json.includes('ama@example.org'), json)
    assert.match(flat(t.units).find((u) => u.label === 'Conversation: Order 1042')!.text!, /\[private\]/)
    assert.ok(t.masked.some((m) => m.marker === 'contact'))
    const meta = buildUnitTree(messages(2), A, { markers: M, level: 'metadata-only' })
    assert.ok(!flat(meta.units).some((u) => u.text), 'no text below readable')
    assert.equal(meta.text, undefined)
    const plain = buildUnitTree(h('main', null, h('section', { 'aria-label': 'Thread' }, h('button', null, 'Reply'), h('p', null, 'Call me on +233 24 123 4567'))), A, { markers: M })
    assert.ok(!JSON.stringify(plain.units).includes('123 4567'), 'redacted like any tool output')
    assert.ok(plain.masked.some((m) => m.kind === 'redaction'))
  })

  check('a submission-style detail (answers in a <dl>, no section) is read as the screen text', () => {
    const dl = h('dl', null, h('dt', null, 'Message'), h('dd', null, 'I would like to volunteer on Saturdays'), h('dt', null, 'Tickets'), h('dd', null, '2'))
    const t = buildUnitTree(h('main', null, h('div', null, h('button', null, 'Star'), dl)), A, { markers: M })
    assert.match(t.text!, /volunteer on Saturdays/)
    assert.ok(!t.text!.includes('Star'))
  })

  check('the size cap shortens long text before dropping structure', () => {
    const long = 'word '.repeat(400)
    const t = buildUnitTree(h('main', null, h('section', { 'aria-label': 'Thread' }, h('button', null, 'Reply'), h('p', null, long))), A, { markers: M, textMax: 5000 })
    const before = JSON.stringify(t.units).length
    const { units: capped, trimmed } = capUnits(t.units, before - 500)
    assert.ok(trimmed)
    assert.ok(capped[0].children && capped[0].children[0].label === 'Reply', 'structure kept')
    assert.ok(capped[0].text!.length <= 240)
  })
}

// ── Cost: the walk stays linear on a big builder (a freeze on the form builder was suspected) ──
{
  const wrap = (depth: number, el: El): El => (depth ? h('div', null, wrap(depth - 1, el)) : el)
  const builder = (fields: number, pad: number) =>
    h('main', null,
      h('aside', { 'aria-label': 'Fields' }, ...Array.from({ length: 30 }, (_, i) => h('button', { 'data-ui': `forms.add.${i}` }, `Type ${i}`))),
      h('nav', { 'aria-label': 'Outline' }, h('ul', { role: 'listbox', 'aria-label': 'Questions' }, ...Array.from({ length: fields }, (_, i) => h('li', { role: 'option' }, `Question ${i}`)))),
      h('section', { 'aria-label': 'Form canvas' }, ...Array.from({ length: fields }, (_, i) => wrap(pad, h('div', { 'data-slot': 'card' }, h('label', { for: `q${i}` }, `Question ${i}`), h('input', { id: `q${i}`, value: '' }), h('p', null, `Help for ${i}`))))),
      h('div', null, h('fieldset', null, ...Array.from({ length: 12 }, (_, i) => h('div', null, h('label', { for: `p${i}` }, `Prop ${i}`), h('input', { id: `p${i}`, value: 'x' }))))))
  const cost = (fields: number, pad: number) => {
    const root = builder(fields, pad)
    const nodes = all(root).length
    const calls = { visible: 0, children: 0, text: 0 }
    const C: NodeAccess<El> = { ...A, visible: (e) => (calls.visible++, A.visible(e)), children: (e) => (calls.children++, A.children(e)), text: (e) => (calls.text++, A.text(e)) }
    const t0 = performance.now()
    const t = buildUnitTree(root, C, { markers: M })
    capUnits(t.units, 14_000)
    return { nodes, ms: performance.now() - t0, ...calls }
  }
  check('read_view cost grows linearly with the DOM (no per-unit re-walks): 4× the nodes ≈ 4× the work', () => {
    const small = cost(80, 8)
    const big = cost(320, 8)
    for (const c of [small, big]) {
      assert.ok(c.visible <= 3 * c.nodes, `visible() ${c.visible} for ${c.nodes} nodes`)
      assert.ok(c.children <= 4 * c.nodes, `children() ${c.children} for ${c.nodes} nodes`)
      assert.ok(c.text <= 400, `text() ${c.text} (innerText forces layout in the browser)`)
    }
    const ratio = big.children / small.children
    assert.ok(ratio < 4.6, `work ratio ${ratio.toFixed(2)} for ${(big.nodes / small.nodes).toFixed(2)}× nodes`)
    assert.ok(cost(1280, 8).ms < 3000, 'a 17k-node builder reads in well under the settle window')
  })
}

console.log(`\n${n} checks passed`)
