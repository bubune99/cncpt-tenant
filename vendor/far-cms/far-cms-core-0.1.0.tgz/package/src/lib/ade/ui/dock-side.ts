/**
 * Which side the assistant docks on, and the preview-only layout override.
 *
 * - agentSide: a per-person pref ('left' default), stored with agentWidth.
 *   Everything that depends on the side (the column's edge, its divider,
 *   drag and keyboard resizing, the room the CMS gives up) reads it here so
 *   left and right are exact mirrors.
 * - The override (?ade=classic|workspace, ?ade-side=left|right) only counts
 *   inside a Preview sizes frame, so captures can show any layout without
 *   touching the person's saved prefs — and while it is on, nothing persists.
 *
 * Pure. Run: npx -y tsx@4.23.15 src/lib/ade/ui/dock-side.assert.ts
 */

export type AgentSide = 'left' | 'right'
export const DEFAULT_AGENT_SIDE: AgentSide = 'left'

export function normalizeAgentSide(v: unknown, fallback: AgentSide = DEFAULT_AGENT_SIDE): AgentSide {
  return v === 'left' || v === 'right' ? v : fallback
}

/** The column's width from a pointer x while dragging its divider (the divider faces the CMS). */
export function widthFromPointer(side: AgentSide, clientX: number, viewportWidth: number): number {
  return side === 'left' ? clientX : viewportWidth - clientX
}

/** Arrow keys on the divider: the arrow pointing INTO the CMS widens the assistant. */
export function keyWidthDelta(side: AgentSide, key: string, step: number): number {
  if (key !== 'ArrowLeft' && key !== 'ArrowRight') return 0
  const towardCms = side === 'left' ? 'ArrowRight' : 'ArrowLeft'
  return key === towardCms ? step : -step
}

/** Where the CMS gives up room for the column: padding on the column's side. */
export function cmsInset(side: AgentSide, offsetVar = 'var(--ade-agent-offset, 0px)'): { paddingLeft?: string; paddingRight?: string } {
  return side === 'left' ? { paddingLeft: offsetVar } : { paddingRight: offsetVar }
}

/** The bottom tray/strip spans the CMS only. */
export function trayInset(side: AgentSide, offsetVar = 'var(--ade-agent-offset, 0px)'): { left: string; right: string } {
  return side === 'left' ? { left: offsetVar, right: '0px' } : { left: '0px', right: offsetVar }
}

/** Slide-in direction for the column (from its own edge). */
export function slideFrom(side: AgentSide): '-100%' | '100%' {
  return side === 'left' ? '-100%' : '100%'
}

/**
 * One assistant layout (lead/owner 2026-10-11): the old right-hand drawer
 * ('side', 'full') and its minimized strip are retired — opening the
 * assistant anywhere means the agent-first column on the person's side.
 * Stored modes from before are migrated through this too.
 */
export type ChatModeLike = 'collapsed' | 'minimized' | 'side' | 'full' | 'split'
export function retireDrawerMode(mode: ChatModeLike): 'collapsed' | 'split' {
  return mode === 'collapsed' || mode === 'minimized' ? 'collapsed' : 'split'
}

export type AdminLayoutOverride = { mode?: 'classic' | 'workspace'; side?: AgentSide }

/**
 * ?ade=classic|workspace and ?ade-side=left|right — only inside a Preview
 * sizes frame (anywhere else: null, the saved prefs rule).
 */
export function parseLayoutOverride(search: string, inPreviewFrame: boolean): AdminLayoutOverride | null {
  if (!inPreviewFrame) return null
  const q = new URLSearchParams(search.startsWith('?') ? search.slice(1) : search)
  const out: AdminLayoutOverride = {}
  const mode = q.get('ade')
  if (mode === 'classic' || mode === 'workspace') out.mode = mode
  const side = q.get('ade-side')
  if (side === 'left' || side === 'right') out.side = side
  return out.mode || out.side ? out : null
}

/** While an override is on, layout changes are for the capture only: never saved (server or browser). */
export function mayPersistLayout(override: AdminLayoutOverride | null): boolean {
  return override === null
}
