/**
 * Colour maths for admin themes — oklch / hex → sRGB, WCAG contrast.
 * Pure and app-agnostic. Asserted via admin-theme.assert.ts.
 */

export type RGB = [number, number, number] // 0..1
export interface Oklch {
  l: number
  c: number
  h: number
}

export function parseOklch(v: string): Oklch | null {
  const m = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)\s+([\d.]+)\s*(?:\/\s*[\d.%]+\s*)?\)$/i.exec(v.trim())
  if (!m) return null
  const l = Number(m[1]) / (m[2] ? 100 : 1)
  return { l, c: Number(m[3]), h: Number(m[4]) }
}

export function formatOklch({ l, c, h }: Oklch): string {
  const r = (n: number, d: number) => Number(n.toFixed(d))
  return `oklch(${r(l, 3)} ${r(c, 3)} ${r(h, 3)})`
}

export function hexToRgb(hex: string): RGB | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return null
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1]
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255) as RGB
}

const clamp01 = (n: number) => Math.min(1, Math.max(0, n))

/** oklch → gamma-encoded sRGB 0..1 (clamped into gamut). */
export function oklchToRgb({ l, c, h }: Oklch): RGB {
  const hr = (h * Math.PI) / 180
  const a = c * Math.cos(hr)
  const b = c * Math.sin(hr)
  const l_ = l + 0.3963377774 * a + 0.2158037573 * b
  const m_ = l - 0.1055613458 * a - 0.0638541728 * b
  const s_ = l - 0.0894841775 * a - 1.291485548 * b
  const L = l_ ** 3
  const M = m_ ** 3
  const S = s_ ** 3
  const lin: RGB = [
    4.0767416621 * L - 3.3077115913 * M + 0.2309699292 * S,
    -1.2684380046 * L + 2.6097574011 * M - 0.3413193965 * S,
    -0.0041960863 * L - 0.7034186147 * M + 1.707614701 * S,
  ]
  return lin.map((x) => {
    const v = clamp01(x)
    return v <= 0.0031308 ? 12.92 * v : 1.055 * v ** (1 / 2.4) - 0.055
  }) as RGB
}

/** sRGB 0..1 → oklch (for "match my brand" from a hex site colour). */
export function rgbToOklch([r, g, b]: RGB): Oklch {
  const lin = [r, g, b].map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4))
  const L = 0.4122214708 * lin[0] + 0.5363325363 * lin[1] + 0.0514459929 * lin[2]
  const M = 0.2119034982 * lin[0] + 0.6806995451 * lin[1] + 0.1073969566 * lin[2]
  const S = 0.0883024619 * lin[0] + 0.2817188376 * lin[1] + 0.6299787005 * lin[2]
  const l_ = Math.cbrt(L)
  const m_ = Math.cbrt(M)
  const s_ = Math.cbrt(S)
  const l = 0.2104542553 * l_ + 0.793617785 * m_ - 0.0040720468 * s_
  const a = 1.9779984951 * l_ - 2.428592205 * m_ + 0.4505937099 * s_
  const bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.808675766 * s_
  const c = Math.sqrt(a * a + bb * bb)
  const h = ((Math.atan2(bb, a) * 180) / Math.PI + 360) % 360
  return { l, c, h }
}

/** Any supported colour string → sRGB. */
export function toRgb(v: string): RGB | null {
  const o = parseOklch(v)
  if (o) return oklchToRgb(o)
  return hexToRgb(v)
}

function lum([r, g, b]: RGB): number {
  const ch = (v: number) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)
  return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)
}

/** WCAG contrast ratio (1..21). */
export function contrast(a: string | RGB, b: string | RGB): number {
  const ra = typeof a === 'string' ? toRgb(a) : a
  const rb = typeof b === 'string' ? toRgb(b) : b
  if (!ra || !rb) return 0
  const [x, y] = [lum(ra), lum(rb)].sort((p, q) => q - p)
  return (x + 0.05) / (y + 0.05)
}
