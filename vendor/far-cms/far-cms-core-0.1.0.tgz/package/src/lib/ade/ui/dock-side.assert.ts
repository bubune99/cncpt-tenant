/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/dock-side.assert.ts
 */
import assert from 'node:assert/strict'
import { cmsInset, keyWidthDelta, mayPersistLayout, normalizeAgentSide, parseLayoutOverride, retireDrawerMode, slideFrom, trayInset, widthFromPointer } from './dock-side'
import { scrimRect } from './spots'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the side pref: left by default, only left/right accepted', () => {
  assert.equal(normalizeAgentSide(undefined), 'left')
  assert.equal(normalizeAgentSide('right'), 'right')
  assert.equal(normalizeAgentSide('top'), 'left')
  assert.equal(normalizeAgentSide(null, 'right'), 'right')
})

check('dragging the divider: left = pointer x; right = distance from the right edge (exact mirror)', () => {
  assert.equal(widthFromPointer('left', 400, 1600), 400)
  assert.equal(widthFromPointer('right', 1200, 1600), 400)
})

check('keyboard: the arrow pointing into the CMS widens the assistant, on either side', () => {
  assert.equal(keyWidthDelta('left', 'ArrowRight', 32), 32)
  assert.equal(keyWidthDelta('left', 'ArrowLeft', 32), -32)
  assert.equal(keyWidthDelta('right', 'ArrowLeft', 32), 32)
  assert.equal(keyWidthDelta('right', 'ArrowRight', 32), -32)
  assert.equal(keyWidthDelta('right', 'Enter', 32), 0)
})

check('the CMS gives up room on the column side; the tray spans the CMS only; slide in from its own edge', () => {
  assert.deepEqual(cmsInset('left', 'X'), { paddingLeft: 'X' })
  assert.deepEqual(cmsInset('right', 'X'), { paddingRight: 'X' })
  assert.deepEqual(trayInset('left', 'X'), { left: 'X', right: '0px' })
  assert.deepEqual(trayInset('right', 'X'), { left: '0px', right: 'X' })
  assert.equal(slideFrom('left'), '-100%')
  assert.equal(slideFrom('right'), '100%')
})

check('the spotlight scrim always covers the CMS side — the column on the right leaves the left area', () => {
  const vp = { width: 1600, height: 900 }
  assert.deepEqual(scrimRect(vp, { left: 0, top: 0, width: 400, height: 900 }), { left: 400, top: 0, width: 1200, height: 900 })
  assert.deepEqual(scrimRect(vp, { left: 1200, top: 0, width: 400, height: 900 }), { left: 0, top: 0, width: 1200, height: 900 })
})

check('the override only counts inside a Preview sizes frame', () => {
  assert.equal(parseLayoutOverride('?ade=classic&ade-side=right', false), null, 'never in the real admin')
  assert.deepEqual(parseLayoutOverride('?ade=classic', true), { mode: 'classic' })
  assert.deepEqual(parseLayoutOverride('ade-side=right&ade=workspace', true), { mode: 'workspace', side: 'right' })
  assert.equal(parseLayoutOverride('?ade=sideways&ade-side=up', true), null, 'junk is ignored')
  assert.equal(parseLayoutOverride('', true), null)
})

check('while an override is on, nothing about the layout is saved', () => {
  assert.equal(mayPersistLayout(parseLayoutOverride('?ade-side=right', true)), false)
  assert.equal(mayPersistLayout(parseLayoutOverride('?ade-side=right', false)), true)
  assert.equal(mayPersistLayout(null), true)
})

check('one assistant layout: the old drawer modes (and stored prefs) become the column; minimized becomes closed', () => {
  assert.equal(retireDrawerMode('side'), 'split')
  assert.equal(retireDrawerMode('full'), 'split')
  assert.equal(retireDrawerMode('split'), 'split')
  assert.equal(retireDrawerMode('minimized'), 'collapsed')
  assert.equal(retireDrawerMode('collapsed'), 'collapsed')
})

console.log(`\n${n} checks passed`)
