/**
 * What a press does while a spotlight is showing (owner rules, 2026-10-23). Pure and app-agnostic; every app with a
 * spotlight follows the same contract so the person never has to learn a second one.
 *
 *  - On the card: the card handles it (Play, Next, typing). It never closes the menu or panel underneath.
 *  - On the highlighted thing: it works as normal. If the step ASKED the person to click it, that click also moves
 *    the walk on to the next step (and on the last step, ends it). The countdown never moves such a step on by itself.
 *  - Anywhere else: the first press only dismisses the spotlight and its card, and is not passed on. Menus and the
 *    page stay as they were. The next press then works normally.
 *  - A persistent walk (later; forces a click somewhere, ends only at its own deliberate X) ignores presses outside
 *    and Escape; only the card's X ends it.
 */

export type PressRegion = 'card' | 'target' | 'outside'
export type PressOutcome = 'keep' | 'pass' | 'advance' | 'finish' | 'dismiss' | 'ignore'

export interface PressInput {
  region: PressRegion
  /** The step asked the person to click the highlighted thing to continue. */
  clickToContinue?: boolean
  /** True on the last step of the walk. */
  last?: boolean
  /** A persistent walk: only its own X ends it. */
  persistent?: boolean
}

export function pressOutcome(i: PressInput): PressOutcome {
  if (i.region === 'card') return 'keep'
  if (i.region === 'target') return i.clickToContinue ? (i.last ? 'finish' : 'advance') : 'pass'
  return i.persistent ? 'ignore' : 'dismiss'
}

/** Does Escape end the spotlight? Not in a persistent walk. */
export const escapeDismisses = (persistent?: boolean): boolean => !persistent

/** Should the countdown move this step on by itself? Never when it is waiting for the person's click. */
export const autoplayMayAdvance = (step: { clickToContinue?: boolean } | undefined): boolean => !step?.clickToContinue
