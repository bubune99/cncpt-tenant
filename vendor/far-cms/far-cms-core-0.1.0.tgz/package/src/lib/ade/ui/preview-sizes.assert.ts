/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/preview-sizes.assert.ts
 */
import assert from 'node:assert/strict'
import {
  clampSize,
  deviceFor,
  fitScale,
  isPreviewFrame,
  layoutWriteAllowed,
  previewMounts,
  isPreviewSizesPath,
  PREVIEW_FRAME_NAME,
  frameHeight,
  multiFitScale,
  parsePreviewParams,
  previewQuery,
  resizeBy,
  safePreviewPath,
} from './preview-sizes'

let n = 0
const ok = (fn: () => void) => {
  fn()
  n++
}
const params = (q: string) => {
  const u = new URLSearchParams(q)
  return (k: string) => u.get(k)
}

// Fit scale: frame vs container
ok(() => assert.equal(fitScale({ w: 2000, h: 1000 }, { w: 1000, h: 1000 }), 0.5, 'width-bound'))
ok(() => assert.equal(fitScale({ w: 1000, h: 2000 }, { w: 1000, h: 1000 }), 0.5, 'height-bound'))
ok(() => assert.equal(fitScale({ w: 390, h: 844 }, { w: 1600, h: 900 }), 1, 'never upscales a phone'))
ok(() => assert.equal(fitScale({ w: 1920, h: null }, { w: 960, h: 300 }), 0.5, 'fill height ignores the box height'))
ok(() => assert.equal(frameHeight({ w: 1920, h: null }, 800, 0.5), 1600, 'fill height = box height at this scale'))
ok(() => assert.equal(frameHeight({ w: 1920, h: 1080 }, 800, 0.5), 1080))

// Multi-frame width split (one shared scale)
ok(() => assert.equal(multiFitScale([{ w: 1000, h: null }, { w: 1000, h: null }], { w: 1010, h: 900 }, 10, 20), 0.5, 'two frames + gap share the width'))
ok(() => assert.equal(multiFitScale([{ w: 1068, h: 772 }, { w: 1920, h: 1080 }], { w: 3000, h: 560 }, 16, 20), 0.5, 'tallest frame + label bounds it'))
ok(() => assert.equal(multiFitScale([{ w: 390, h: 844 }], { w: 2000, h: 2000 }, 16, 20), 1))

// Clamping custom sizes
ok(() => assert.deepEqual(clampSize({ w: 100, h: 100 }), { w: 320, h: 480 }))
ok(() => assert.deepEqual(clampSize({ w: 9000, h: 9000 }), { w: 3840, h: 2400 }))
ok(() => assert.deepEqual(clampSize({ w: 1000.4, h: null }), { w: 1000, h: null }))
ok(() => assert.deepEqual(resizeBy({ w: 1000, h: null }, 'w', 50, 0.5, 700), { w: 1100, h: null }, 'screen px / scale'))
ok(() => assert.deepEqual(resizeBy({ w: 1000, h: null }, 'h', 10, 1, 700), { w: 1000, h: 710 }, 'bottom drag starts from the shown height'))
ok(() => assert.deepEqual(resizeBy({ w: 330, h: 500 }, 'w', -100, 1, 500), { w: 320, h: 500 }, 'clamped while dragging'))

// Devices
ok(() => assert.equal(deviceFor({ w: 1068, h: null }), 'laptop'))
ok(() => assert.equal(deviceFor({ w: 390, h: 844 }), 'phone'))
ok(() => assert.equal(deviceFor({ w: 1000, h: 700 }), 'custom'))

// URL params — back-compat with the old harness
ok(() => {
  const st = parsePreviewParams(params('path=/admin/todo&w=1068x772,1920x1080&scale=0.4'))
  assert.deepEqual(st, { path: '/admin/todo', sizes: [{ w: 1068, h: 772 }, { w: 1920, h: 1080 }], zoom: 0.4, spots: true })
})
ok(() => assert.deepEqual(parsePreviewParams(params('')), { path: '/admin', sizes: [{ w: 1068, h: null }], zoom: 'fit', spots: true }, 'defaults: one laptop frame, fit'))
ok(() => assert.deepEqual(parsePreviewParams(params('w=1366')).sizes, [{ w: 1366, h: null }], 'bare width = fill height'))
ok(() => assert.deepEqual(parsePreviewParams(params('w=abc,0x10,100x100')).sizes, [{ w: 320, h: 480 }], 'junk dropped, tiny clamped'))
ok(() => assert.equal(parsePreviewParams(params('w=' + Array(12).fill('800x600').join(','))).sizes.length, 8, 'at most 8 frames'))
ok(() => assert.equal(parsePreviewParams(params('scale=5')).zoom, 1))
ok(() => assert.equal(parsePreviewParams(params('scale=0.01')).zoom, 0.1))
ok(() => assert.equal(parsePreviewParams(params('scale=x')).zoom, 'fit'))
ok(() => assert.equal(safePreviewPath('https://evil.example/admin'), '/admin', 'off-site rejected'))
ok(() => assert.equal(safePreviewPath('/admin/viewport-harness?w=1'), '/admin', 'never itself'))
ok(() => assert.equal(safePreviewPath('/initiatives/akuse-hospital'), '/initiatives/akuse-hospital', 'the public site too (same origin)'))
ok(() => assert.equal(safePreviewPath('/'), '/', 'the home page'))
ok(() => assert.deepEqual(['//evil.example/x', '/\\evil.example', 'javascript:alert(1)', '/api/admin/users', '/_next/static/x.js', ' /a b'].map(safePreviewPath), ['/admin', '/admin', '/admin', '/admin', '/admin', '/admin'], 'never another site, an API or a build file'))
ok(() => {
  const st = parsePreviewParams(params('path=/admin/todo&w=1068x772,1920&scale=0.4'))
  assert.deepEqual(parsePreviewParams(params(previewQuery(st))), st, 'query round-trips')
})
ok(() => assert.equal(previewQuery({ path: '/admin', sizes: [{ w: 1068, h: null }], zoom: 'fit' }), 'path=%2Fadmin&w=1068'))

// Shell bypass is for this route only
ok(() => assert.equal(isPreviewSizesPath('/admin/viewport-harness'), true))
ok(() => assert.equal(isPreviewSizesPath('/admin/viewport-harness-x'), false))
ok(() => assert.equal(isPreviewSizesPath('/admin'), false))

// A frame is a preview only when framed AND its parent is the harness (name decides only when the parent can't be read).
ok(() => assert.equal(isPreviewFrame({ isTop: true, frameName: PREVIEW_FRAME_NAME, parentPath: null }), false, 'top window never'))
ok(() => assert.equal(isPreviewFrame({ isTop: false, frameName: '', parentPath: '/admin/viewport-harness' }), true))
ok(() => assert.equal(isPreviewFrame({ isTop: false, frameName: PREVIEW_FRAME_NAME, parentPath: '/admin/pages/x/editor' }), false, 'other framers (editor canvas) are not previews'))
ok(() => assert.equal(isPreviewFrame({ isTop: false, frameName: PREVIEW_FRAME_NAME, parentPath: null }), true, 'cross-origin parent: the name decides'))
ok(() => assert.equal(isPreviewFrame({ isTop: false, frameName: 'other', parentPath: null }), false))
// The phone page editor's live preview: no visit counted, no overlays (owner capture 2026-10-11).
ok(() => assert.equal(isPreviewFrame({ isTop: false, frameName: '', parentPath: '/admin/m/pages/abc/edit' }), true))
ok(() => assert.equal(isPreviewFrame({ isTop: false, frameName: '', parentPath: '/admin/m/pages' }), false))
ok(() => assert.equal(PREVIEW_FRAME_NAME, 'ade-preview-frame'))
// A capture in a preview frame never writes the person's layout prefs (sidebar, mode, side, widths, dividers).
ok(() => assert.equal(layoutWriteAllowed(true), false))
ok(() => assert.equal(layoutWriteAllowed(false), true))

// What mounts: counters never in a preview; spotlights unless the harness turned them off (walk-throughs render in the harness).
ok(() => assert.deepEqual(previewMounts({ inFrame: false, spotlightsFlag: '0' }), { spotlights: true, counters: true }, 'not a preview: everything'))
ok(() => assert.deepEqual(previewMounts({ inFrame: true, spotlightsFlag: '1' }), { spotlights: true, counters: false }))
ok(() => assert.deepEqual(previewMounts({ inFrame: true, spotlightsFlag: null }), { spotlights: true, counters: false }, 'no flag = on'))
ok(() => assert.deepEqual(previewMounts({ inFrame: true, spotlightsFlag: '0' }), { spotlights: false, counters: false }))
ok(() => assert.equal(parsePreviewParams(() => null).spots, true, 'Show spotlights defaults on'))
ok(() => assert.equal(parsePreviewParams((k) => (k === 'spot' ? '0' : null)).spots, false))
ok(() => assert.ok(!previewQuery({ path: '/admin', sizes: [{ w: 1068, h: 772 }], zoom: 'fit', spots: true }).includes('spot')))
ok(() => assert.ok(previewQuery({ path: '/admin', sizes: [{ w: 1068, h: 772 }], zoom: 'fit', spots: false }).includes('spot=0')))

console.log(`${n} assertions passed`)
