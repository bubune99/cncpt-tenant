/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/spots.assert.ts
 */
import assert from 'node:assert/strict'
import { dropSpotNarration,
  areaFor,
  needsNavigation,
  placeCard,
  resumeStep,
  sameBox,
  scrimRect,
  screenQuery,
  routeDiffers,
  spotRoute,
  PRIVATE_SPOT_SENTENCE,
  spotReady,
  spotsFromMetadata,
  spotsFromParts,
  stepNav,
  widgetState,
  type SpotSet,
} from './spots'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}

const ITEMS = [
  { name: 'Dashboard', href: '/admin' },
  { name: 'Settings', href: '/admin/settings' },
  { name: 'Initiatives', href: '/admin/records' },
]

// Footer: n of N, arrows disabled at the ends; one spot → nothing
eq(stepNav(0, 1), { counter: null, canPrev: false, canNext: false })
eq(stepNav(0, 3), { counter: '1 of 3', canPrev: false, canNext: true })
eq(stepNav(1, 3), { counter: '2 of 3', canPrev: true, canNext: true })
eq(stepNav(2, 3), { counter: '3 of 3', canPrev: true, canNext: false })
eq(stepNav(9, 3).counter, '3 of 3', 'clamped')

// Widget
const set: SpotSet = { id: 't1', route: '/admin/settings', area: 'Settings', steps: [{ target: '[data-ui="settings.privacy"]', title: 'Cookie & privacy banner' }] }
eq(widgetState(set, true), { title: 'Pointed at Cookie & privacy banner', sub: 'Settings · 1 spot · showing now', live: true, button: 'Hide' })
eq(widgetState({ ...set, steps: [...set.steps, set.steps[0], set.steps[0]] }, false), { title: 'Pointed at Cookie & privacy banner', sub: 'Settings · 3 spots', live: false, button: 'Show again' })
eq(resumeStep({ ...set, steps: [set.steps[0], set.steps[0]] }, 1), 1, 'same step again')
eq(resumeStep(set, 4), 0, 'out of range → first')
eq(resumeStep(set, undefined), 0)
eq(needsNavigation(set, '/admin/settings/'), false)
eq(needsNavigation(set, '/admin/forms'), true)
eq(needsNavigation({ ...set, route: null }, '/admin/forms'), false, 'unknown route: show here')
// Show again keeps the section: a stored ?section is navigated to; a route without one never drops yours
eq(needsNavigation({ ...set, route: '/admin/settings?section=privacy' }, '/admin/settings'), true, 'go to the section')
eq(needsNavigation({ ...set, route: '/admin/settings?section=privacy' }, '/admin/settings?section=privacy'), false)
eq(needsNavigation({ ...set, route: '/admin/settings?section=privacy' }, '/admin/settings?section=spam'), true)
eq(needsNavigation({ ...set, route: '/admin/settings' }, '/admin/settings?section=privacy'), false, 'older reply (no query): stay on your section')
eq(screenQuery('?section=privacy&q=jane@example.com&ade=workspace'), '?section=privacy', 'only view-choosing keys; never search terms')
eq(screenQuery('?q=x'), '')
eq(routeDiffers('/admin/settings', '/admin/settings?section=privacy'), false, 'same screen: a navigation never resets the section')
eq(routeDiffers('/admin/settings/', '/admin/settings'), false)
eq(routeDiffers('/admin/forms', '/admin/settings?section=privacy'), true)
eq(screenQuery('?section=<script>'), '', 'odd values dropped')
eq(spotRoute('/admin/settings', '?ade-side=right&section=privacy'), '/admin/settings?section=privacy')

// Widget phases: only a measured spot says "showing now"; finding / not found are said plainly
eq(widgetState(set, 'finding').sub, 'Settings · 1 spot · finding it…')
eq(widgetState(set, 'finding').live, false, 'not "showing now" until measured')
eq(widgetState(set, 'finding').button, 'Hide')
eq(widgetState(set, { missing: 'Cookie & privacy banner' }), { title: 'Pointed at Cookie & privacy banner', sub: 'Settings · 1 spot · couldn’t find “Cookie & privacy banner” on this screen', live: false, button: 'Show again' })

// Areas
eq(areaFor('/admin/settings', ITEMS), 'Settings')
eq(areaFor('/admin/records/abc/edit', ITEMS), 'Initiatives')
eq(areaFor('/admin', ITEMS), 'Dashboard')
eq(areaFor('/admin/email-marketing', ITEMS), 'Email marketing', 'not in the menu: segment in words')
eq(areaFor(null, ITEMS), 'This screen')

// From a reply's parts: read → stable selector + label; last pointing wins
const read = (route: string, units: unknown[]) => ({ type: 'tool-read_view', state: 'output-available', toolCallId: 'r', output: { ok: true, route, units } })
const units = [{ id: 'u1', role: 'section', label: 'Settings menu', children: [{ id: 'u7', role: 'tab', label: 'Cookie & privacy banner', stable: '[data-ui="settings.section.privacy"]' }, { id: 'u8', role: 'field', label: 'Title' }] }]
const spot = (steps: unknown[]) => ({ type: 'tool-spotlight_steps', state: 'output-available', toolCallId: 'sp1', input: { steps }, output: { __requires_client_execution: true, name: 'spotlight_steps', arguments: { steps } } })
const got = spotsFromParts(
  [
    { type: 'text', text: 'Opening…' },
    { type: 'tool-navigate_to_route', state: 'output-available', toolCallId: 'n', output: { __requires_client_execution: true, name: 'navigate_to_route', arguments: { path: '/admin/settings' } } },
    read('/admin/settings', units),
    spot([
      { target: '[data-ade-unit="u7"]', title: 'Cookie & privacy banner', sentence: 'This is where you set what first-time visitors see.' },
      { target: '[data-ade-unit="u8"]', title: 'Wording', sentence: 'The title is empty, so the banner shows only the message.' },
      { target: '#x' },
    ]),
  ],
  '/admin/forms',
  ITEMS
)
eq(got, {
  id: 'sp1',
  route: '/admin/settings',
  area: 'Settings',
  steps: [
    { target: '[data-ui="settings.section.privacy"]', label: 'Cookie & privacy banner', title: 'Cookie & privacy banner', sentence: 'This is where you set what first-time visitors see.' },
    { target: '[data-ade-unit="u8"]', label: 'Title', title: 'Wording', sentence: 'The title is empty, so the banner shows only the message.' },
  ],
}, 'stable selector swapped in; a step with no words dropped')
eq(spotsFromParts([spot([{ target: '#a', caption: 'Old caption' }])], '/admin', ITEMS)?.steps, [{ target: '#a', title: 'This', sentence: 'Old caption' }], 'legacy caption → sentence')
eq(spotsFromParts([{ type: 'text', text: 'hi' }], '/admin', ITEMS), null, 'no pointing → no widget')
eq(spotsFromParts([spot([{ target: '#a', title: 'A' }]), { ...spot([{ target: '#a', title: 'A' }]), state: 'input-streaming' }], null, ITEMS)?.route, null, 'route unknown')
const nav = spotsFromParts(
  [read('/admin/settings', units), { type: 'tool-open_tab', state: 'output-available', toolCallId: 'o1', input: { unit: 'u7' }, output: { ok: true, did: 'Opened the tab “Cookie & privacy banner”', view: { ok: true, route: '/admin/settings', units: [] } } }],
  null,
  ITEMS
)
// A read that carried the section keeps it in the stored route
eq(spotsFromParts([{ ...read('/admin/settings', units), output: { ok: true, route: '/admin/settings', search: '?section=privacy', units } }, spot([{ target: '[data-ade-unit="u7"]', title: 'Banner' }])], null, ITEMS)?.route, '/admin/settings?section=privacy')
// Private / blocked spots get a line, not just a title
const priv = [{ id: 'u4', role: 'field', label: 'Email', private: true }]
eq(spotsFromParts([read('/admin/customers', priv), spot([{ target: '[data-ade-unit="u4"]', title: 'Email' }])], null, ITEMS)?.steps[0].sentence, PRIVATE_SPOT_SENTENCE)
eq(spotsFromParts([{ type: 'tool-read_view', state: 'output-available', toolCallId: 'r', output: { ok: true, private: true, route: '/admin/customers' } }, spot([{ target: '#c', title: 'Customers' }])], null, ITEMS)?.steps[0].sentence, PRIVATE_SPOT_SENTENCE, 'private screen')
eq(spotsFromParts([read('/admin/customers', priv), spot([{ target: '[data-ade-unit="u4"]', title: 'Email', sentence: 'Hidden on purpose.' }])], null, ITEMS)?.steps[0].sentence, 'Hidden on purpose.', 'the agent’s own sentence wins')
eq(spotsFromParts([read('/admin/customers', priv), { type: 'tool-scroll_to', state: 'output-available', toolCallId: 's', input: { unit: 'u4' }, output: { ok: true, view: { ok: true, route: '/admin/customers', units: priv } } }], null, ITEMS)?.steps[0].sentence, PRIVATE_SPOT_SENTENCE, 'nav tool on a private unit')
// The Environment case: a plain tab opens a PRIVATE section (refused reads are ok:false, private:true)
const plainTab = [{ id: 'u5', role: 'tab', label: 'Environment', stable: '[data-ui="settings.nav.environment"]' }]
const refused = { ok: false, private: true, route: '/admin/settings', message: 'This screen is private.' }
eq(spotsFromParts([read('/admin/settings', plainTab), { type: 'tool-open_tab', state: 'output-available', toolCallId: 'e1', input: { unit: 'u5' }, output: { ok: true, view: refused } }], null, ITEMS)?.steps[0], { target: '[data-ui="settings.nav.environment"]', label: 'Environment', title: 'Environment', sentence: PRIVATE_SPOT_SENTENCE }, 'nav tool into a private section')
eq(spotsFromParts([read('/admin/settings', plainTab), { type: 'tool-read_view', state: 'output-available', toolCallId: 'r2', output: refused }, spot([{ target: '[data-ui="settings.nav.environment"]', title: 'Environment' }])], null, ITEMS)?.steps[0].sentence, PRIVATE_SPOT_SENTENCE, 'a refused read, then pointing with a title only')
eq(spotsFromParts([{ type: 'tool-read_view', state: 'output-available', toolCallId: 'r3', output: refused }, read('/admin/settings', plainTab), spot([{ target: '[data-ade-unit="u5"]', title: 'Environment' }])], null, ITEMS)?.steps[0].sentence, undefined, 'a later readable read clears it')
eq(nav?.steps, [{ target: '[data-ui="settings.section.privacy"]', label: 'Cookie & privacy banner', title: 'Cookie & privacy banner' }], 'nav tools point with the unit name, no “is now open” sentence')
const unstable = [{ id: 'u3', role: 'tab', label: 'Spam protection' }]
eq(
  spotsFromParts([read('/admin/settings', unstable), { type: 'tool-open_tab', state: 'output-available', toolCallId: 'o2', input: { unit: 'u3' }, output: { ok: true, view: { ok: true, route: '/admin/settings', units: [{ id: 'u9', role: 'tab', label: 'Spam protection' }, { id: 'u3', role: 'field', label: 'Other' }] } } }], null, ITEMS)?.steps[0].target,
  '[data-ade-unit="u9"]',
  'no stable name: its id in the fresh read, not the old one'
)
eq(spotsFromParts([read('/admin/settings', units), { type: 'tool-open_tab', state: 'output-available', toolCallId: 'o1', input: { unit: 'u7' }, output: { ok: false, error: 'x' } }], null, ITEMS), null, 'failed nav: nothing')
const long = 'x'.repeat(500)
const clipped = spotsFromParts([spot([{ target: '#a', title: long, sentence: long }])], null, ITEMS)!.steps[0]
eq([clipped.title.length, clipped.sentence!.length], [80, 240], 'clipped')
eq(spotsFromParts([spot(Array.from({ length: 20 }, (_, i) => ({ target: `#s${i}`, title: `S${i}` })))], null, ITEMS)!.steps.length, 12, 'at most 12')

// Metadata round-trip (untrusted JSON)
eq(spotsFromMetadata({ spots: got }), got)
eq(spotsFromMetadata({ spots: { steps: [{ target: '#a' }] } }), null, 'a step needs a title')
eq(spotsFromMetadata({ spots: { id: 'x', route: 'javascript:alert(1)', steps: [{ target: '#a', title: 'A' }] } })?.route, null, 'bad route dropped')
eq(spotsFromMetadata({ runId: 'r' }), null)
eq(spotsFromMetadata(null), null)

// Scrim: CMS side only
eq(scrimRect({ width: 1600, height: 900 }, { left: 0, top: 0, width: 560, height: 900 }), { left: 560, top: 0, width: 1040, height: 900 }, 'assistant on the left')
eq(scrimRect({ width: 1600, height: 900 }, { left: 1120, top: 0, width: 480, height: 900 }), { left: 0, top: 0, width: 1120, height: 900 }, 'assistant on the right (classic)')
eq(scrimRect({ width: 800, height: 900 }, { left: 0, top: 200, width: 800, height: 700 }), { left: 0, top: 0, width: 800, height: 200 }, 'bottom sheet')
eq(scrimRect({ width: 1600, height: 900 }, null), { left: 0, top: 0, width: 1600, height: 900 })
eq(scrimRect({ width: 1600, height: 900 }, { left: 0, top: 0, width: 1600, height: 900 }), { left: 0, top: 0, width: 0, height: 0 }, 'assistant full page: no scrim')

// Inside a Preview sizes frame (the frame's own window): measured → shown; unmeasured → nothing, never a full dim
const frame = { width: 2560, height: 1440 }
const frameArea = scrimRect(frame, { left: 2080, top: 0, width: 480, height: 1440 })
eq(frameArea, { left: 0, top: 0, width: 2080, height: 1440 }, 'assistant on the right in the frame')
eq(spotReady(frameArea, { width: 120, height: 32 }), true)
eq(spotReady(null, { width: 120, height: 32 }), false, 'area not measured yet → no scrim')
eq(spotReady(frameArea, undefined), false, 'spot not measured yet')
eq(spotReady(frameArea, { width: 0, height: 0 }), false, '0×0 cutout → nothing')
eq(spotReady(scrimRect(frame, { left: 0, top: 0, width: 2560, height: 1440 }), { width: 10, height: 10 }), false, 'assistant fills the frame → nothing')

// Card placement: below, pointer at the spot; flips; stays inside the CMS side
const area = { left: 560, top: 0, width: 1040, height: 900 }
const card = { width: 340, height: 170 }
eq(placeCard({ left: 600, top: 140, width: 220, height: 36 }, card, area), { left: 592, top: 190, side: 'top', pointer: 118 })
eq(placeCard({ left: 600, top: 800, width: 220, height: 36 }, card, area).side, 'bottom', 'no room below → above')
eq(placeCard({ left: 560, top: 140, width: 220, height: 36 }, card, area).left, 568, 'never over the assistant column')
eq(placeCard({ left: 1500, top: 140, width: 90, height: 36 }, card, area), { left: 1252, top: 190, side: 'top', pointer: 293 }, 'slid left; pointer still on the spot')
eq(placeCard({ left: 600, top: 20, width: 100, height: 860 }, card, area).side, 'left', 'tall spot → beside it')

// The spotlight stores a rect/area only when it moved (an equal one re-ran the resolve loop).
eq(sameBox({ left: 10, top: 20, width: 100, height: 40 }, { left: 10.2, top: 19.8, width: 100.4, height: 40 }), true, 'sub-pixel jitter is the same box')
eq(sameBox({ left: 10, top: 20, width: 100, height: 40 }, { left: 10, top: 60, width: 100, height: 40 }), false)
eq(sameBox(null, null), true)
eq(sameBox(null, { left: 0, top: 0, width: 1, height: 1 }), false)

// The reply beside a spot never narrates the pointing (staging 85a313d0: a repeat ask said "I've pointed at it again")
{
  const d = dropSpotNarration
  assert.equal(d("I've pointed at it again. It's under Content in the menu."), "It's under Content in the menu.")
  assert.equal(d('I have highlighted the Media library for you. Every image lives there.'), 'Every image lives there.')
  assert.equal(d('Here it is once more. Media holds your uploads.'), 'Media holds your uploads.')
  assert.equal(d('Again, it is under Content.'), 'It is under Content.')
  assert.equal(d('It is under Content. The highlight may not be showing on your screen.'), 'It is under Content.')
  assert.equal(d("If you can't see the highlight, look at the top left. Media is under Content."), 'Media is under Content.')
  assert.equal(d("I'm pointing at it again for you."), '', 'nothing left: no text part')
  assert.equal(d('Media is under Content.\n\n- Upload photos there\n- I\'ve pointed at Upload.'), 'Media is under Content.\n\n- Upload photos there', 'lines and lists kept')
  assert.equal(d('Point at the Upload button to add photos. Show me the folder you want again.'), 'Point at the Upload button to add photos. Show me the folder you want again.', 'not about the spot: kept')
  assert.equal(d("It's under Content."), "It's under Content.", 'first and repeat ask read the same')
  assert.equal(d('Click the Details button to open it. My highlight landed on the Dashboard menu instead.'), 'Click the Details button to open it.', 'staging 8d3df748: no narrating where the highlight went')
  assert.equal(d('The spotlight missed it. The start date is under Details.'), 'The start date is under Details.')
}
{
  const step = (out: Record<string, unknown>) => ({ type: 'tool-spotlight_step', state: 'output-available', toolCallId: 'ws1', input: { target: '[data-ui="record.details"]', title: 'Details', sentence: 'Dates and stage live here.' }, output: out })
  const got = spotsFromParts([step({ acknowledged: true, action: 'got_it' })], '/admin/initiatives/x', [])
  assert.equal(got?.steps.length, 1, 'an acknowledged walk-through step is the reply\'s spot')
  assert.equal(got?.steps[0].target, '[data-ui="record.details"]')
  assert.equal(spotsFromParts([step({ acknowledged: false, shown: false })], null, []), null, 'a step that was never shown is no spot')
  n += 2
}
{
  // clickToContinue survives the set tool's call, a wait step's call and stored metadata; only a literal true counts
  const call = (steps: unknown[]) => [{ type: 'tool-spotlight_steps', state: 'output-available', toolCallId: 'c1', input: { steps }, output: { arguments: { steps } } }]
  const got = spotsFromParts(call([{ target: '#a', title: 'A', clickToContinue: true }, { target: '#b', title: 'B', clickToContinue: 'true' }, { target: '#c', title: 'C' }]), '/admin', [])
  assert.deepEqual(got?.steps.map((x) => x.clickToContinue), [true, undefined, undefined])
  assert.equal(spotsFromMetadata({ spots: { id: 'c1', steps: [{ target: '#a', title: 'A', clickToContinue: true }, { target: '#b', title: 'B', clickToContinue: 1 }] } })?.steps.map((x) => x.clickToContinue).join(), 'true,')
  n += 2
}
console.log(`${n} assertions passed`)
