/**
 * The spotlight press contract (lib/ade/ui/spot-press) turned into what the page does with one press: which region it
 * landed in, whether it is consumed, and what the walk does. Pure; the DOM side is components/spotlight/spot-press-host.
 * Same decisions as BYB's walkthrough-pace decidePress (Dzidzor has no autoplay pacing, so only the press part).
 */

import { pressOutcome, type PressOutcome, type PressRegion } from './spot-press'

export interface PressFacts {
  /** On the spotlight card (or the phone sheet it sits in). */
  inCard: boolean
  /** In the assistant: it stays usable while a spotlight shows, so a press there is the assistant's own. */
  inAssistant: boolean
  /** On the highlighted thing. */
  onTarget: boolean
}

export const pressRegion = (f: PressFacts): PressRegion => (f.inCard || f.inAssistant ? 'card' : f.onTarget ? 'target' : 'outside')

export type PressAct = 'none' | 'dismiss' | 'stop' | 'advance' | 'finish'

export interface PressDecision {
  outcome: PressOutcome
  /** Stop the press here: nothing underneath (menus, the page) sees it. Only the first press outside, and only that. */
  consume: boolean
  /** What the walk does. Never a click: the system only reacts to the person's press. */
  act: PressAct
}

export interface PressInput extends PressFacts {
  clickToContinue?: boolean
  last?: boolean
  /** A step the assistant is parked on (lib/ade/chat/waits): dismissing it is a clean Stop, so the run does not stay parked. */
  waiting: boolean
}

export function decidePress(i: PressInput): PressDecision {
  const outcome = pressOutcome({ region: pressRegion(i), clickToContinue: i.clickToContinue, last: i.last })
  if (outcome === 'dismiss') return { outcome, consume: true, act: i.waiting ? 'stop' : 'dismiss' }
  if (outcome === 'advance' || outcome === 'finish') return { outcome, consume: false, act: outcome }
  return { outcome, consume: false, act: 'none' }
}

/** The events of one press, after its first event was consumed: they are swallowed too, so nothing underneath fires. */
const PRESS_EVENTS = new Set(['mousedown', 'touchstart', 'pointerup', 'mouseup', 'touchend', 'click', 'auxclick', 'contextmenu'])
const GATE_MS = 1000

export function createPressGate() {
  let armedAt: number | null = null
  return {
    /** The first event of a press was consumed. */
    arm(now: number) {
      armedAt = now
    },
    /** Should this later event of the same press be swallowed? A click ends the press; so does time. */
    swallows(type: string, now: number): boolean {
      if (armedAt === null) return false
      if (now - armedAt > GATE_MS) {
        armedAt = null
        return false
      }
      // A new press starts: it is judged on its own.
      if (type === 'pointerdown') {
        armedAt = null
        return false
      }
      if (!PRESS_EVENTS.has(type)) return false
      if (type === 'click' || type === 'contextmenu' || type === 'auxclick') armedAt = null
      return true
    },
  }
}

/** One answer per wait step: a step already answered by a press is never answered again (bounded memory). */
export function createAnswered(max = 200) {
  const seen = new Set<string>()
  return {
    /** True the first time for this wait id, false after. */
    take(id: string): boolean {
      if (seen.has(id)) return false
      if (seen.size >= max) seen.clear()
      seen.add(id)
      return true
    },
  }
}
