/** Executable checks for the press wiring. Run: node scripts/run-asserts.mjs src/lib/ade/ui */
import assert from 'node:assert/strict'

import { createAnswered, createPressGate, decidePress } from './spot-press-wire'

let n = 0
const eq = <T>(a: T, b: T, m: string) => { assert.deepEqual(a, b, m); n++ }
const ok = (v: boolean, m: string) => { assert.ok(v, m); n++ }

{
  const f = { inCard: false, inAssistant: false, onTarget: false, waiting: false }
  eq(decidePress({ ...f, inCard: true }), { outcome: 'keep', consume: false, act: 'none' }, 'a press on the card is the card\'s own')
  eq(decidePress({ ...f, inAssistant: true }).act, 'none', 'the assistant stays usable: not a press outside')
  eq(decidePress({ ...f, onTarget: true }), { outcome: 'pass', consume: false, act: 'none' }, 'a press on the target is passed through when nothing was asked')
  eq(decidePress({ ...f, onTarget: true, clickToContinue: true }), { outcome: 'advance', consume: false, act: 'advance' }, 'on the target of a click step: advance, not consumed')
  eq(decidePress({ ...f, onTarget: true, clickToContinue: true, last: true }).act, 'finish', 'on the last step it ends the walk')
  eq(decidePress({ ...f, onTarget: true, last: true }).act, 'none', 'a look-only last step is not ended by pressing it')
  eq(decidePress(f), { outcome: 'dismiss', consume: true, act: 'dismiss' }, 'the first press elsewhere dismisses and is consumed')
  eq(decidePress({ ...f, clickToContinue: true }).act, 'dismiss', 'even when the step asked for a click')
  eq(decidePress({ ...f, waiting: true }), { outcome: 'dismiss', consume: true, act: 'stop' }, 'on a parked step the first press elsewhere is a clean Stop, consumed')
  ok(decidePress({ ...f, inCard: true, waiting: true }).act === 'none' && decidePress({ ...f, inAssistant: true, waiting: true }).act === 'none', 'a press on the card or in the assistant sends nothing')
  eq(decidePress({ ...f, waiting: true, onTarget: true, clickToContinue: true }).act, 'advance', 'the target press of a click step answers the wait')
}
{
  const g = createPressGate()
  ok(!g.swallows('click', 0), 'idle: nothing is swallowed')
  g.arm(1000)
  ok(g.swallows('mousedown', 1010) && g.swallows('pointerup', 1020) && g.swallows('mouseup', 1030), 'the rest of the consumed press is swallowed')
  ok(g.swallows('click', 1040), 'including its click')
  ok(!g.swallows('click', 1050), 'and the next press is normal')
  g.arm(2000)
  ok(!g.swallows('pointerdown', 2100) && !g.swallows('click', 2110), 'a new press before any click is judged on its own')
  g.arm(3000)
  ok(!g.swallows('click', 4500), 'a press whose click never came expires')
  g.arm(5000)
  ok(!g.swallows('keydown', 5010) && !g.swallows('mousemove', 5010), 'only press events are swallowed')
}
{
  const a = createAnswered(2)
  ok(a.take('w1') && !a.take('w1'), 'one answer per wait step')
  ok(a.take('w2') && a.take('w3'), 'memory stays bounded')
}

console.log(`spot-press-wire: ${n} checks passed`)
