/**
 * Admin themes & colour schemes (owner, all CMSs) — two layers, admin chrome
 * only (the site canvas keeps the site's tokens):
 *
 *   1. ORG ADMIN THEME — palette + UI font + eyebrow style + radius (no
 *      monospace anywhere: owner, 2026-10-24). Data, so another app's theme (BYB's "Atlas") is just
 *      another definition.
 *   2. PERSONAL COLOUR SCHEME on top — Neutral · Slate · Stone · Blue · Green
 *      · Violet · Rose · Orange · "Match my brand" × light/dark + high
 *      contrast. Only accent-bearing tokens change (primary, ring, selection,
 *      active states, badges, a subtle muted tint), so layout and type stay
 *      the same and screenshots/training stay valid.
 *
 * Every combination is contrast-checked against WCAG AA: primaries are
 * DERIVED (lightness searched until the text on them passes), not hand-picked.
 * Pure and app-agnostic; asserted by admin-theme.assert.ts.
 */

import { contrast, formatOklch, hexToRgb, parseOklch, rgbToOklch, type Oklch } from './color'

export type TokenMap = Record<string, string>
export type Mode = 'light' | 'dark'

export interface AdminTheme {
  id: string
  name: string
  /** Palette overrides on top of the base shadcn tokens (empty = neutral Studio). */
  light: TokenMap
  dark: TokenMap
  fonts: { ui: string }
  /** 'upper' = uppercase sans, weight 600, letter-spacing .08em. */
  eyebrow: 'plain' | 'upper'
  radius: string
  /** Design-system components this theme restyles beyond the defaults (e.g. spot: the spotlight). */
  components?: Partial<Record<ComponentId, { light?: TokenMap; dark?: TokenMap }>>
}

/**
 * Design-system components: their tokens default to the theme's own colours,
 * so a theme or scheme switch restyles them; a theme may override any.
 */
export type ComponentId = 'spot'

export const COMPONENT_TOKENS: Readonly<Record<ComponentId, { light: TokenMap; dark: TokenMap }>> = {
  // Spotlight: scrim over the CMS side, the ring, the card and the chat widget.
  spot: {
    light: {
      '--spot-scrim': 'rgb(15 23 42 / 0.42)',
      '--spot-ring': 'hsl(174 72% 44%)',
      '--spot-card-bg': 'var(--popover)',
      '--spot-card-fg': 'var(--popover-foreground)',
      '--spot-card-border': 'var(--border)',
      '--spot-radius': 'calc(var(--radius) + 2px)',
      '--spot-ask-bg': 'var(--muted)',
    },
    dark: {
      '--spot-scrim': 'rgb(0 0 0 / 0.55)',
      '--spot-ring': 'hsl(174 72% 44%)',
      '--spot-card-bg': 'var(--popover)',
      '--spot-card-fg': 'var(--popover-foreground)',
      '--spot-card-border': 'var(--border)',
      '--spot-radius': 'calc(var(--radius) + 2px)',
      '--spot-ask-bg': 'var(--muted)',
    },
  },
}

/** Every component's tokens for this theme and mode (defaults, then the theme's overrides). */
export function componentTokens(theme: AdminTheme, mode: Mode): TokenMap {
  const out: TokenMap = {}
  for (const id of Object.keys(COMPONENT_TOKENS) as ComponentId[]) Object.assign(out, COMPONENT_TOKENS[id][mode], theme.components?.[id]?.[mode])
  return out
}

export const ADMIN_THEMES: Readonly<Record<string, AdminTheme>> = {
  studio: {
    id: 'studio',
    name: 'Studio (neutral)',
    light: {},
    dark: {},
    fonts: { ui: 'var(--font-geist-sans), system-ui, sans-serif' },
    eyebrow: 'plain',
    radius: '0.625rem',
  },
  // BYB's admin theme — cream, maroon, terracotta; the BYB port refines the values.
  atlas: {
    id: 'atlas',
    name: 'Atlas',
    light: {
      '--background': 'oklch(0.975 0.012 85)',
      '--card': 'oklch(0.985 0.01 85)',
      '--popover': 'oklch(0.985 0.01 85)',
      '--foreground': 'oklch(0.22 0.02 30)',
      '--muted': 'oklch(0.94 0.015 80)',
      '--muted-foreground': 'oklch(0.47 0.03 40)',
      '--border': 'oklch(0.88 0.02 75)',
      '--input': 'oklch(0.88 0.02 75)',
    },
    dark: {
      '--background': 'oklch(0.2 0.015 30)',
      '--card': 'oklch(0.24 0.018 30)',
      '--popover': 'oklch(0.24 0.018 30)',
      '--foreground': 'oklch(0.95 0.012 80)',
      '--muted': 'oklch(0.3 0.02 30)',
      '--muted-foreground': 'oklch(0.78 0.02 60)',
      '--border': 'oklch(1 0 0 / 12%)',
      '--input': 'oklch(1 0 0 / 15%)',
    },
    fonts: { ui: "'Instrument Sans', 'Hanken Grotesk', system-ui, sans-serif" },
    eyebrow: 'upper',
    radius: '0.5rem',
  },
}

/** Base foregrounds the scheme is checked against (shadcn neutral; a theme may override). */
const BASE: Record<Mode, { foreground: string; background: string; mutedForeground: string }> = {
  light: { foreground: 'oklch(0.145 0 0)', background: 'oklch(1 0 0)', mutedForeground: 'oklch(0.556 0 0)' },
  dark: { foreground: 'oklch(0.985 0 0)', background: 'oklch(0.145 0 0)', mutedForeground: 'oklch(0.708 0 0)' },
}

export interface SchemeDef {
  id: string
  name: string
  /** The accent in light mode (prototype values); dark mode and HC are derived. */
  primary: string
  tint: string
}

export const SCHEMES: ReadonlyArray<SchemeDef> = [
  { id: 'neutral', name: 'Neutral', primary: 'oklch(0.205 0 0)', tint: 'oklch(0.97 0 0)' },
  { id: 'slate', name: 'Slate', primary: 'oklch(0.279 0.041 260.031)', tint: 'oklch(0.968 0.007 247.896)' },
  { id: 'stone', name: 'Stone', primary: 'oklch(0.216 0.006 56.043)', tint: 'oklch(0.97 0.001 106.424)' },
  { id: 'blue', name: 'Blue', primary: 'oklch(0.488 0.243 264.376)', tint: 'oklch(0.97 0.014 254.604)' },
  { id: 'green', name: 'Green', primary: 'oklch(0.527 0.154 150.069)', tint: 'oklch(0.982 0.018 155.826)' },
  { id: 'violet', name: 'Violet', primary: 'oklch(0.491 0.27 292.581)', tint: 'oklch(0.969 0.016 293.756)' },
  { id: 'rose', name: 'Rose', primary: 'oklch(0.514 0.222 16.935)', tint: 'oklch(0.969 0.015 12.422)' },
  { id: 'orange', name: 'Orange', primary: 'oklch(0.553 0.195 38.402)', tint: 'oklch(0.98 0.016 73.684)' },
]

export const BRAND_SCHEME = 'brand'

export interface SchemeChoice {
  scheme: string
  highContrast: boolean
}

export const DEFAULT_CHOICE: SchemeChoice = { scheme: 'neutral', highContrast: false }

export function normalizeChoice(raw: unknown, fallback: SchemeChoice = DEFAULT_CHOICE): SchemeChoice {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const known = typeof o.scheme === 'string' && (o.scheme === BRAND_SCHEME || SCHEMES.some((s) => s.id === o.scheme))
  return { scheme: known ? (o.scheme as string) : fallback.scheme, highContrast: o.highContrast === true }
}

const AA = 4.5
const LIGHT_FG = 'oklch(0.985 0 0)'
const DARK_FG = 'oklch(0.205 0 0)'

/** Move lightness (keeping hue/chroma) until `fg` on it passes `target`. */
function fitLightness(base: Oklch, fg: string, target: number, direction: -1 | 1): Oklch {
  let o = { ...base }
  for (let i = 0; i < 80 && contrast(formatOklch(o), fg) < target; i++) {
    o = { ...o, l: Math.min(0.98, Math.max(0.05, o.l + direction * 0.01)) }
  }
  return o
}

/** The scheme's accent as oklch (brand: derived from the site's primary colour). */
function accentOf(scheme: string, brandPrimary?: string | null): { primary: Oklch; tint: Oklch } {
  if (scheme === BRAND_SCHEME && brandPrimary) {
    const o = parseOklch(brandPrimary) ?? (hexToRgb(brandPrimary) ? rgbToOklch(hexToRgb(brandPrimary)!) : null)
    if (o) return { primary: o, tint: { l: 0.97, c: Math.min(0.016, o.c * 0.25), h: o.h } }
  }
  const def = SCHEMES.find((s) => s.id === scheme) ?? SCHEMES[0]
  return { primary: parseOklch(def.primary)!, tint: parseOklch(def.tint)! }
}

/**
 * The accent tokens for a scheme in a mode (only these change). Light: dark
 * primary with light text; dark: light primary with dark text; high contrast
 * pushes both further and strengthens borders and secondary text.
 */
export function schemeTokens(choice: SchemeChoice, mode: Mode, brandPrimary?: string | null): TokenMap {
  const { primary, tint } = accentOf(choice.scheme, brandPrimary)
  const neutral = choice.scheme === 'neutral'
  const target = choice.highContrast ? 7 : AA
  if (mode === 'light') {
    const p = fitLightness(choice.highContrast ? { ...primary, l: primary.l - 0.06 } : primary, LIGHT_FG, target, -1)
    const tokens: TokenMap = neutral && !choice.highContrast
      ? {}
      : {
          '--primary': formatOklch(p),
          '--primary-foreground': LIGHT_FG,
          '--ring': formatOklch(p),
          '--sidebar-primary': formatOklch(p),
          '--sidebar-primary-foreground': LIGHT_FG,
          '--accent': formatOklch(tint),
          '--muted': formatOklch(tint),
          '--sidebar': formatOklch({ ...tint, l: Math.min(0.99, tint.l + 0.01) }),
        }
    if (choice.highContrast) Object.assign(tokens, { '--border': 'oklch(0.62 0 0)', '--input': 'oklch(0.62 0 0)', '--muted-foreground': 'oklch(0.4 0 0)' })
    return tokens
  }
  // Dark: a lighter version of the accent carries dark text.
  const start: Oklch = neutral ? { l: 0.922, c: 0, h: 0 } : { ...primary, l: Math.max(primary.l, 0.68) }
  const p = fitLightness(choice.highContrast ? { ...start, l: start.l + 0.05 } : start, DARK_FG, target, 1)
  const darkTint: Oklch = { l: 0.27, c: Math.min(0.04, tint.c * 2.5 + (neutral ? 0 : 0.01)), h: tint.h }
  const tokens: TokenMap = neutral && !choice.highContrast
    ? {}
    : {
        '--primary': formatOklch(p),
        '--primary-foreground': DARK_FG,
        '--ring': formatOklch(p),
        '--sidebar-primary': formatOklch(p),
        '--sidebar-primary-foreground': DARK_FG,
        '--accent': formatOklch(darkTint),
        '--muted': formatOklch(darkTint),
        '--sidebar': formatOklch({ ...darkTint, l: 0.22 }),
      }
  if (choice.highContrast) Object.assign(tokens, { '--border': 'oklch(1 0 0 / 35%)', '--input': 'oklch(1 0 0 / 40%)', '--muted-foreground': 'oklch(0.85 0 0)' })
  return tokens
}

/** The theme's own tokens (fonts, radius, palette) for a mode. */
export function themeTokens(theme: AdminTheme, mode: Mode): TokenMap {
  return {
    ...(mode === 'light' ? theme.light : theme.dark),
    '--admin-font-ui': theme.fonts.ui,
    '--admin-eyebrow-transform': theme.eyebrow === 'upper' ? 'uppercase' : 'none',
    '--admin-eyebrow-weight': theme.eyebrow === 'upper' ? '600' : 'inherit',
    '--admin-eyebrow-tracking': theme.eyebrow === 'upper' ? '0.08em' : '0.06em',
    '--radius': theme.radius,
    ...componentTokens(theme, mode),
  }
}

/** CSS for the admin: theme + scheme, light under :root, dark under .dark. */
export function adminThemeCss(theme: AdminTheme, choice: SchemeChoice, brandPrimary?: string | null): string {
  const decl = (t: TokenMap) => Object.entries(t).map(([k, v]) => `${k}:${v}`).join(';')
  const light = { ...themeTokens(theme, 'light'), ...schemeTokens(choice, 'light', brandPrimary) }
  const dark = { ...themeTokens(theme, 'dark'), ...schemeTokens(choice, 'dark', brandPrimary) }
  return `:root{${decl(light)}}.dark{${decl(dark)}}`
}

/**
 * The theme for an id from settings, else the APP's default id (supplied by
 * the host app — this library never assumes one), else the first theme.
 */
export function resolveAdminTheme(id: unknown, appDefaultId: string, themes: Readonly<Record<string, AdminTheme>> = ADMIN_THEMES): AdminTheme {
  if (typeof id === 'string' && Object.hasOwn(themes, id)) return themes[id]
  if (Object.hasOwn(themes, appDefaultId)) return themes[appDefaultId]
  return Object.values(themes)[0]
}

/** A stored theme id if it's a known theme, else the app default id. */
export function normalizeAdminThemeId(id: unknown, appDefaultId: string, themes: Readonly<Record<string, AdminTheme>> = ADMIN_THEMES): string {
  return resolveAdminTheme(id, appDefaultId, themes).id
}

export interface ContrastReport {
  ok: boolean
  checks: Array<{ what: string; ratio: number; need: number }>
}

/** WCAG AA checks for one combination (what the asserts and the picker use). */
/** `theme` is the org theme in use (the host app resolves it — see resolveAdminTheme). */
export function checkScheme(choice: SchemeChoice, mode: Mode, theme: AdminTheme, brandPrimary?: string | null): ContrastReport {
  const t = { ...themeTokens(theme, mode), ...schemeTokens(choice, mode, brandPrimary) }
  const base = BASE[mode]
  const fg = t['--foreground'] ?? base.foreground
  const bg = t['--background'] ?? base.background
  const primary = t['--primary'] ?? (mode === 'light' ? 'oklch(0.205 0 0)' : 'oklch(0.922 0 0)')
  const onPrimary = t['--primary-foreground'] ?? (mode === 'light' ? LIGHT_FG : DARK_FG)
  const tint = t['--accent'] ?? (mode === 'light' ? 'oklch(0.97 0 0)' : 'oklch(0.269 0 0)')
  const mutedFg = t['--muted-foreground'] ?? base.mutedForeground
  const need = choice.highContrast ? 7 : AA
  const checks = [
    { what: 'text on primary buttons', ratio: contrast(onPrimary, primary), need },
    { what: 'text on tinted rows', ratio: contrast(fg, tint), need },
    { what: 'secondary text on the page', ratio: contrast(mutedFg, bg), need: AA },
    { what: 'focus ring against the page', ratio: contrast(t['--ring'] ?? primary, bg), need: 3 },
  ]
  return { ok: checks.every((c) => c.ratio >= c.need), checks }
}
