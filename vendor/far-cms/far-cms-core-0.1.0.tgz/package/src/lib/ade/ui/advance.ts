/**
 * How a walkthrough advances: by itself on a timer, or when the person presses Next. Pure and app-agnostic; shared by every
 * app with an assistant (alongside autoplay.ts, which says how long a step stays once it is on a timer).
 *
 * Who decides, most authoritative first:
 *   1. the person's own saved preference ("always play it for me", "always let me click")
 *   2. an admin's rule for the site ("always timer", "always manual")
 *   3. the assistant's choice, from what the person asked for, or from asking them with a short question
 *   4. otherwise a timer (a single spot is never timed)
 * The person's choice always wins over the assistant's; the assistant is told which applies, and code enforces it, so a
 * model cannot talk its way past a preference.
 */

export type Advance = 'timer' | 'manual'
/** An admin's setting: let the assistant decide, or fix it for the site. */
export type AdvanceRule = 'assistant' | Advance
export const ADVANCE_RULES: readonly AdvanceRule[] = ['assistant', 'timer', 'manual']

export type AdvanceSource = 'single' | 'person' | 'admin' | 'assistant' | 'default'

/** Anything stored or sent from a browser is untrusted: only the two known values count. */
export const sanitizeAdvance = (v: unknown): Advance | null => (v === 'timer' || v === 'manual' ? v : null)
export const sanitizeAdvanceRule = (v: unknown): AdvanceRule => (v === 'timer' || v === 'manual' || v === 'assistant' ? v : 'assistant')

export interface AdvanceInput {
  steps: number
  /** The person's saved preference, if any. */
  person?: unknown
  /** The admin's rule. */
  admin?: unknown
  /** What the assistant asked for. */
  assistant?: unknown
}

export function resolveAdvance(i: AdvanceInput): { advance: Advance; source: AdvanceSource } {
  // One thing to point at has nothing to advance.
  if (i.steps < 2) return { advance: 'manual', source: 'single' }
  const person = sanitizeAdvance(i.person)
  if (person) return { advance: person, source: 'person' }
  const admin = sanitizeAdvanceRule(i.admin)
  if (admin !== 'assistant') return { advance: admin, source: 'admin' }
  const assistant = sanitizeAdvance(i.assistant)
  if (assistant) return { advance: assistant, source: 'assistant' }
  return { advance: 'timer', source: 'default' }
}

/** Does the assistant still get to choose (and may it ask)? Only when neither the person nor an admin has decided. */
export const assistantDecides = (i: { person?: unknown; admin?: unknown }): boolean => !sanitizeAdvance(i.person) && sanitizeAdvanceRule(i.admin) === 'assistant'

/** The question the assistant asks when it cannot tell. Fixed wording and ids, so the answer can be remembered. */
export const ADVANCE_QUESTION_ID = 'advance'
export const ADVANCE_OPTIONS = [
  { value: 'timer', label: 'Play it for me', description: 'Each step moves on by itself, and you can pause.' },
  { value: 'manual', label: 'I’ll click through', description: 'You press Next when you are ready.' },
] as const

/** The line(s) for the assistant's instructions, by who has decided. */
export function advanceGuidance(i: { person?: unknown; admin?: unknown }): string[] {
  const person = sanitizeAdvance(i.person)
  const admin = sanitizeAdvanceRule(i.admin)
  if (person) {
    return [person === 'timer' ? 'This person has chosen to have walkthroughs play by themselves. Do not ask; use advance "timer".' : 'This person has chosen to click through walkthroughs themselves. Do not ask; use advance "manual".']
  }
  if (admin !== 'assistant') {
    return [admin === 'timer' ? 'This site plays walkthroughs by themselves. Do not ask; use advance "timer".' : 'This site has people click through walkthroughs. Do not ask; use advance "manual".']
  }
  return [
    'Choose how a walkthrough advances. "Show me around", "give me a tour" or "walk me through" mean advance "timer" (it plays by itself). "Step by step", "one at a time", "let me click" or "at my own pace" mean advance "manual" (they press Next).',
    `If you cannot tell and the walkthrough has three or more steps, ask once with ask_user: one question, id "${ADVANCE_QUESTION_ID}", type single, options "${ADVANCE_OPTIONS[0].label}" (value timer) and "${ADVANCE_OPTIONS[1].label}" (value manual). Then wait for the answer. Do not ask for one or two steps, and never ask twice.`,
  ]
}
