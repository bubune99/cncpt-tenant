/**
 * Shortcut labels for the computer in front of you (owner 2026-10-19: no Mac-only labels — the client
 * and owner use Windows). Write a shortcut once as "Mod+Shift+G": it reads "Ctrl+Shift+G" on Windows and
 * Linux, "⌘⇧G" on a Mac. Anything unknown (and the server's first render) gets the Ctrl form.
 * The key handlers already accept either key (metaKey || ctrlKey). Pure; asserted by keys.assert.ts.
 */

export type KeyPlatform = 'mac' | 'other'

export interface NavigatorLike {
  platform?: string
  userAgent?: string
  userAgentData?: { platform?: string }
}

/** Mac (or iPad / iPhone) → 'mac'; everything else, or nothing known → 'other'. */
export function platformOf(nav?: NavigatorLike | null): KeyPlatform {
  const p = `${nav?.userAgentData?.platform ?? ''} ${nav?.platform ?? ''} ${nav?.userAgent ?? ''}`
  return /mac|iphone|ipad|ipod/i.test(p) ? 'mac' : 'other'
}

const MAC: Record<string, string> = { Mod: '⌘', Shift: '⇧', Alt: '⌥', Enter: '⏎' }
const OTHER: Record<string, string> = { Mod: 'Ctrl' }

/** "Mod+Shift+G" → "Ctrl+Shift+G" (Windows / Linux) or "⌘⇧G" (Mac). */
export function keyLabel(combo: string, platform: KeyPlatform): string {
  const parts = combo.split('+').map((k) => k.trim()).filter(Boolean)
  return platform === 'mac' ? parts.map((k) => MAC[k] ?? k).join('') : parts.map((k) => OTHER[k] ?? k).join('+')
}

/** The label for this browser (event handlers and other client-only code). */
export function keyHere(combo: string): string {
  return keyLabel(combo, platformOf(typeof navigator === 'undefined' ? null : (navigator as NavigatorLike)))
}

/** The shortcuts the editor shows. */
export const SHORTCUTS = {
  group: 'Mod+G',
  ungroup: 'Mod+Shift+G',
  lock: 'Mod+Shift+L',
  inspect: 'Mod+I',
  menu: 'Mod+K',
  accept: 'Mod+Enter',
} as const
