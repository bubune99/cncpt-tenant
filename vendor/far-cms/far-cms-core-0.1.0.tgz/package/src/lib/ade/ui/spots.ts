/**
 * Spots: what the assistant points at on the CMS screen, and how the pop-up
 * and the "Pointed at …" chat widget behave. Pure and host-agnostic;
 * asserted by spots.assert.ts.
 *
 * A spot set comes from one assistant reply: its spotlight_steps call (or a
 * navigation tool that pointed at what it opened). It is kept on the reply's
 * metadata — unit references, titles, sentences and the route — so the
 * widget can show it again after a reload or from history.
 */

import { MAX_SECONDS, MIN_SECONDS } from './autoplay'

export interface SpotStep {
  /** CSS selector; a stable one (data-ui, aria-label…) whenever the screen read offered it. */
  target: string
  /** The unit's own name on screen, for finding it again when the selector is gone. */
  label?: string
  /** Bold title on the card ("Wording"). */
  title: string
  /** One useful sentence from the agent ("The title is empty, so the banner shows only the message."). */
  sentence?: string
  /** The step asked the person to click the highlighted thing: that click also moves the walk on (lib/ade/ui/spot-press). */
  clickToContinue?: boolean
  /** This step's own time when the walk-through plays itself (lib/ade/ui/autoplay; 2–60 s, else dropped). */
  seconds?: number
}

/** A step's own time, if it is a number within the autoplay bounds (stored or model input is untrusted). */
export const stepSeconds = (v: unknown): number | undefined => (typeof v === 'number' && Number.isFinite(v) && v >= MIN_SECONDS && v <= MAX_SECONDS ? v : undefined)

export interface SpotSet {
  /** The tool call that made it. */
  id: string
  /** Where the spots are (pathname + search); null when the reply never said. */
  route: string | null
  /** The screen's plain name ("Settings"). */
  area: string
  steps: SpotStep[]
}

export const MAX_SPOTS = 12
const MAX_TITLE = 80
const MAX_SENTENCE = 240
const ROUTE = /^\/[^\s]*$/

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s)
const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '')

// ── Card footer ──────────────────────────────────────────────────────

export interface StepNav {
  /** "2 of 3"; null for a single spot (no counter, no arrows). */
  counter: string | null
  canPrev: boolean
  canNext: boolean
}

export function stepNav(index: number, total: number): StepNav {
  if (total <= 1) return { counter: null, canPrev: false, canNext: false }
  const i = Math.min(Math.max(index, 0), total - 1)
  return { counter: `${i + 1} of ${total}`, canPrev: i > 0, canNext: i < total - 1 }
}

// ── Chat widget ──────────────────────────────────────────────────────

export interface WidgetState {
  title: string
  sub: string
  live: boolean
  button: 'Hide' | 'Show again'
}

/**
 * Where a set is: on screen (ring + card measured), being looked for (after
 * Show again, while the screen opens), closed, or not found ("missing", with
 * the title of the spot that couldn't be found). Only 'showing' says
 * "showing now".
 */
export type SpotPhase = 'showing' | 'finding' | 'closed' | { missing: string }

export function widgetState(set: SpotSet, phase: SpotPhase | boolean): WidgetState {
  const p: SpotPhase = phase === true ? 'showing' : phase === false ? 'closed' : phase
  const n = set.steps.length
  const count = n === 1 ? '1 spot' : `${n} spots`
  const note = p === 'showing' ? ' · showing now' : p === 'finding' ? ' · finding it…' : typeof p === 'object' ? ` · couldn’t find “${p.missing}” on this screen` : ''
  const open = p === 'showing' || p === 'finding'
  return {
    title: `Pointed at ${set.steps[0]?.title ?? 'this'}`,
    sub: `${set.area} · ${count}${note}`,
    live: p === 'showing',
    button: open ? 'Hide' : 'Show again',
  }
}

/** Where Show again starts: the step it was closed on, if still in range. */
export function resumeStep(set: SpotSet, last: number | undefined): number {
  return last !== undefined && last >= 0 && last < set.steps.length ? last : 0
}

const normRoute = (r: string) => {
  const [p, q] = r.split('?')
  return `${p.replace(/\/+$/, '') || '/'}${q ? `?${q}` : ''}`
}

/**
 * Show again on another screen navigates there first — to the route with
 * its query (?section=privacy). A route kept without one (older replies)
 * only compares the path, so it never drops the section you're on.
 */
export function needsNavigation(set: SpotSet, here: string): boolean {
  return !!set.route && routeDiffers(set.route, here)
}

/**
 * Whether going to `target` would change the screen. A target without a
 * query only compares paths: "go to /admin/settings" while on
 * /admin/settings?section=privacy stays put rather than resetting the section.
 */
export function routeDiffers(target: string, here: string): boolean {
  const want = normRoute(target)
  const now = normRoute(here)
  return want.includes('?') ? want !== now : want !== now.split('?')[0]
}

/** Where the person is, as spots store routes: path + the view-choosing query only. */
export function spotRoute(pathname: string, search: string): string {
  return `${pathname}${screenQuery(search)}`
}

/** Query keys that choose what a screen shows — never search terms, ids or tokens. */
const SCREEN_KEYS = ['section', 'tab', 'view']

/** The part of a query that picks the screen's view (?section=privacy), else ''. */
export function screenQuery(search: string): string {
  const q = new URLSearchParams(search)
  const keep = new URLSearchParams()
  for (const k of SCREEN_KEYS) {
    const v = q.get(k)
    if (v && /^[\w-]{1,40}$/.test(v)) keep.set(k, v)
  }
  const out = keep.toString()
  return out ? `?${out}` : ''
}

/** A private (or blocked) unit's card says this when the agent gave no sentence. */
export const PRIVATE_SPOT_SENTENCE = 'Private. I can’t read this, but you can open it here.'

// ── Screen names ─────────────────────────────────────────────────────

export interface AreaItem {
  name: string
  href: string
}

/** The menu item a route belongs to (longest href prefix), else its first segment in words. */
export function areaFor(route: string | null, items: readonly AreaItem[]): string {
  if (!route) return 'This screen'
  const path = normRoute(route).split('?')[0]
  let best: AreaItem | null = null
  for (const it of items) {
    const h = normRoute(it.href)
    // An item other items live under (the dashboard at /admin) owns only itself.
    const parent = items.some((o) => o !== it && normRoute(o.href).startsWith(`${h}/`))
    const under = !parent && path.startsWith(`${h}/`)
    if ((path === h || under) && (!best || h.length > normRoute(best.href).length)) best = it
  }
  if (best) return best.name
  const seg = path.replace(/^\/admin\/?/, '').split('/')[0]
  return seg ? seg.replace(/[-_]+/g, ' ').replace(/^./, (c) => c.toUpperCase()) : 'Dashboard'
}

// ── From a reply's tool parts ────────────────────────────────────────

interface UnitLike {
  id?: unknown
  label?: unknown
  stable?: unknown
  private?: unknown
  blocked?: unknown
  children?: unknown
}

interface UnitInfo {
  stable?: string
  label?: string
  private?: true
}

function indexUnits(units: unknown, into: Map<string, UnitInfo>) {
  if (!Array.isArray(units)) return
  for (const u of units as UnitLike[]) {
    if (u && typeof u.id === 'string') into.set(u.id, { stable: str(u.stable) || undefined, label: str(u.label) || undefined, ...(u.private === true || u.blocked === true ? { private: true as const } : {}) })
    indexUnits(u?.children, into)
  }
}

/** A read's route with the query that picks its view (?section=…), when it reported one. */
function readRoute(out: Record<string, unknown>): string | null {
  const path = str(out.route)
  if (!ROUTE.test(path)) return null
  return `${path}${screenQuery(str(out.search))}`
}

const UNIT_TARGET = /^\[data-ade-unit=["']?(u\d+)["']?\]$/

/** A sentence about the assistant itself (its earlier card, a correction, counting its way along), not the thing. */
const SELF_TALK = /\b(?:my (?:earlier |last |previous )?(?:card|answer|message|reply|spot)|i (?:said|wrote|mentioned|pointed|counted|miscounted)|correction|i was wrong|actually it'?s|(?:first|second|third|fourth|fifth|\d+(?:st|nd|rd|th)) from the (?:left|right))\b/i

/**
 * A spot's sentence keeps only what it says about the thing on screen: any
 * sentence of self-talk ("My card said it was third from the left, but it's
 * fourth.") is dropped. Nothing left: no sentence.
 */
export function cleanSpotSentence(text: string): string {
  return text
    .split(/(?<=[.!?])\s+/)
    .filter((s) => s.trim() && !SELF_TALK.test(s))
    .join(' ')
    .trim()
}

// ── The reply beside a spot ──────────────────────────────────────────

/** A sentence narrating the pointing itself — the "Pointed at …" row already says it. */
const POINT_NARRATION = [
  /\b(?:i'?ve|i have|i)\s+(?:just\s+|now\s+)?(?:pointed|highlighted|spotlighted|ringed|marked)\b/i,
  /\b(?:i'?m|i am|i'?ll|i will|let me)\s+(?:point(?:ing)?|highlight(?:ing)?|show(?:ing)?)\b[^.!?]*\b(?:again|once more)\b/i,
  /\b(?:here|there) it is\b[^.!?]*\b(?:again|once more)\b/i,
  /\b(?:pointed at|highlighted|showing|showed|shown)\b[^.!?]*\b(?:again|once more)\b/i,
  /\bhighlight\b[^.!?]*\b(?:may|might|could)\s+not\s+be\b/i,
  /\bif you (?:can'?t|cannot|don'?t|do not) see (?:the |it )?(?:highlight|ring|spot)/i,
  /\bmy (?:highlight|spot|pointer|ring|spotlight)\b/i,
  /\b(?:highlight|spot|spotlight|ring)\b[^.!?]*\b(?:landed|ended up|went to|missed)\b/i,
]

/**
 * A reply that pointed at something, without the narration: sentences about
 * the pointing ("I've pointed at it again.", "The highlight may not be
 * showing.") are dropped and a leading "Again," goes, so a repeat ask reads
 * the same as the first (staging 85a313d0). Line breaks and lists are kept.
 */
export function dropSpotNarration(text: string): string {
  const cleanLine = (line: string) => {
    const lead = /^(\s*(?:[-*]|\d+\.)\s+)?/.exec(line)?.[0] ?? ''
    const kept = line
      .slice(lead.length)
      .split(/(?<=[.!?])\s+/)
      .filter((s) => !s.trim() || !POINT_NARRATION.some((r) => r.test(s)))
      .map((s) => s.replace(/^(?:again|once more),?\s+(\w)/i, (_, c: string) => c.toUpperCase()))
      .join(' ')
      .trim()
    return kept ? `${lead}${kept}` : ''
  }
  return text
    .split('\n')
    .map((l) => (l.trim() ? cleanLine(l) : l))
    .filter((l, i, all) => l !== '' || (all[i - 1] ?? '') !== '')
    .join('\n')
    .trim()
}

/** A step as stored: stable selector when the read offered one; clipped words. */
function toStep(raw: Record<string, unknown>, units: Map<string, UnitInfo>, screenPrivate: boolean): SpotStep | null {
  const target = str(raw.target)
  if (!target) return null
  const unitId = UNIT_TARGET.exec(target)?.[1]
  const unit = unitId ? units.get(unitId) : undefined
  // Older calls had only a caption: it becomes the sentence.
  const sentence = cleanSpotSentence(str(raw.sentence) || str(raw.caption)) || (unit?.private || screenPrivate ? PRIVATE_SPOT_SENTENCE : '')
  const title = str(raw.title) || unit?.label || ''
  if (!title && !sentence) return null
  return {
    target: unit?.stable ?? target,
    ...(unit?.label ? { label: clip(unit.label, MAX_TITLE) } : {}),
    title: clip(title || 'This', MAX_TITLE),
    ...(sentence ? { sentence: clip(sentence, MAX_SENTENCE) } : {}),
    ...(raw.clickToContinue === true ? { clickToContinue: true as const } : {}),
    ...(stepSeconds(raw.seconds) !== undefined ? { seconds: stepSeconds(raw.seconds) } : {}),
  }
}

const REVEAL_TOOLS = new Set(['open_tab', 'expand', 'collapse', 'scroll_to', 'open_menu'])

/**
 * The spot set a reply made, from its parts in order: screen reads (route,
 * unit ids → stable selectors and names), navigations, then the LAST
 * pointing — a spotlight_steps call, or a navigation tool that pointed at
 * what it opened (titled with the unit's name, no sentence).
 */
export function spotsFromParts(parts: readonly unknown[], startRoute: string | null, items: readonly AreaItem[]): SpotSet | null {
  let route = startRoute && ROUTE.test(startRoute) ? startRoute : null
  const units = new Map<string, UnitInfo>()
  // The last read was of a private screen (nothing but "private: true").
  let screenPrivate = false
  let found: SpotSet | null = null
  for (const p of parts) {
    const part = (p ?? {}) as Record<string, unknown>
    const type = str(part.type)
    if (!type.startsWith('tool-') || part.state !== 'output-available') continue
    const name = type.slice(5)
    const out = (part.output ?? {}) as Record<string, unknown>
    const input = (part.input ?? {}) as Record<string, unknown>
    const id: string = str(part.toolCallId) || name
    if (name === 'read_view' && out.private === true) {
      // A refused read (the screen or section is private) is ok:false — it still says where, and that it's private.
      route = readRoute(out) ?? route
      screenPrivate = true
      units.clear()
    } else if (name === 'read_view' && out.ok !== false) {
      route = readRoute(out) ?? route
      screenPrivate = false
      units.clear()
      indexUnits(out.units, units)
    } else if (name === 'navigate_to_route' || name === 'navigateTo') {
      const args = (out.arguments ?? {}) as Record<string, unknown>
      const path = str(args.path) || str(out.path)
      if (ROUTE.test(path)) route = path
    } else if (name === 'show_unit' && out.ok === true && typeof out.selector === 'string' && typeof out.shown === 'string') {
      // A part of the screen, revealed and checked in the browser (lib/ade/ui/control): one spot on it.
      const sentence = cleanSpotSentence(str(out.sentence) || str(input.sentence))
      found = { id, route, area: areaFor(route, items), steps: [{ target: out.selector, label: clip(out.shown, MAX_TITLE), title: clip(out.shown, MAX_TITLE), ...(sentence ? { sentence: clip(sentence, MAX_SENTENCE) } : {}) }] }
    } else if (name === 'spotlight_step' && out.shown !== false) {
      // One walk-through step (lib/ade/chat/waits): its input is the spot (never one that was not shown).
      const step = toStep(input, units, screenPrivate)
      if (step) found = { id, route, area: areaFor(route, items), steps: [step] }
    } else if (name === 'spotlight_steps') {
      const args = (out.arguments ?? input) as Record<string, unknown>
      const raw = Array.isArray(args.steps) ? (args.steps as Record<string, unknown>[]) : []
      const steps = raw.flatMap((s) => toStep(s ?? {}, units, screenPrivate) ?? []).slice(0, MAX_SPOTS)
      if (steps.length) found = { id, route, area: areaFor(route, items), steps }
    } else if (REVEAL_TOOLS.has(name) && out.ok === true) {
      const unit = units.get(str(input.unit))
      const view = (out.view ?? {}) as Record<string, unknown>
      // The fresh read that came back carries the new ids — or says what it opened is private.
      if (view.private === true) {
        route = readRoute(view) ?? route
        screenPrivate = true
      } else if (view.ok !== false && Array.isArray(view.units)) {
        route = readRoute(view) ?? route
        screenPrivate = false
        units.clear()
        indexUnits(view.units, units)
      }
      if (unit?.label) {
        // Re-find it in the fresh read (old ids now name other units).
        const fresh = [...units.entries()].find(([, u]) => u.label === unit.label)
        const target = unit.stable ?? fresh?.[1].stable ?? (fresh ? `[data-ade-unit="${fresh[0]}"]` : null)
        // The unit itself is private, or what opening it showed is (a private section behind a plain tab).
        const sentence = unit.private || screenPrivate ? { sentence: PRIVATE_SPOT_SENTENCE } : {}
        if (target) found = { id, route, area: areaFor(route, items), steps: [{ target, label: unit.label, title: clip(unit.label, MAX_TITLE), ...sentence }] }
      }
    }
  }
  return found
}

/** A spot set read back from stored metadata (untrusted JSON): checked and clipped, else null. */
export function spotsFromMetadata(meta: unknown): SpotSet | null {
  const s = (meta as { spots?: unknown } | null | undefined)?.spots as Record<string, unknown> | undefined
  if (!s || typeof s !== 'object' || !Array.isArray(s.steps)) return null
  const steps = (s.steps as Record<string, unknown>[]).flatMap((x) => {
    const target = str(x?.target)
    const title = str(x?.title)
    if (!target || !title) return []
    const sentence = cleanSpotSentence(str(x?.sentence))
    const label = str(x?.label)
    return [{ target, title: clip(title, MAX_TITLE), ...(label ? { label: clip(label, MAX_TITLE) } : {}), ...(sentence ? { sentence: clip(sentence, MAX_SENTENCE) } : {}), ...(x?.clickToContinue === true ? { clickToContinue: true as const } : {}), ...(stepSeconds(x?.seconds) !== undefined ? { seconds: stepSeconds(x?.seconds) } : {}) }]
  }).slice(0, MAX_SPOTS)
  if (!steps.length) return null
  const route = str(s.route)
  return { id: str(s.id) || 'spots', route: ROUTE.test(route) ? route : null, area: str(s.area) || 'This screen', steps }
}

// ── Layout ───────────────────────────────────────────────────────────

export interface Box {
  left: number
  top: number
  width: number
  height: number
}

/**
 * Same box to the pixel (rounding sub-pixel jitter). The spotlight only
 * stores a new rect/area when it actually moved: storing an equal one made
 * a new step object, which re-ran the resolve effect (scroll into view →
 * scroll events → measure → store …) and pegged the tab.
 */
export function sameBox(a: Pick<Box, 'left' | 'top' | 'width' | 'height'> | null | undefined, b: Pick<Box, 'left' | 'top' | 'width' | 'height'> | null | undefined): boolean {
  if (!a || !b) return a === b
  const r = Math.round
  return r(a.left) === r(b.left) && r(a.top) === r(b.top) && r(a.width) === r(b.width) && r(a.height) === r(b.height)
}

/**
 * The scrim covers the CMS side only: the viewport minus the assistant
 * column (left or right), or above a bottom sheet. No assistant → all of it.
 */
export function scrimRect(viewport: { width: number; height: number }, assistant: Box | null): Box {
  const full = { left: 0, top: 0, width: viewport.width, height: viewport.height }
  if (!assistant || assistant.width <= 0 || assistant.height <= 0) return full
  const right = assistant.left + assistant.width
  const bottom = assistant.top + assistant.height
  const options: Box[] = [
    { left: right, top: 0, width: viewport.width - right, height: viewport.height },
    { left: 0, top: 0, width: assistant.left, height: viewport.height },
    { left: 0, top: 0, width: viewport.width, height: assistant.top },
    { left: 0, top: bottom, width: viewport.width, height: viewport.height - bottom },
  ].filter((b) => b.width > 0 && b.height > 0)
  if (!options.length) return { left: 0, top: 0, width: 0, height: 0 }
  return options.reduce((a, b) => (b.width * b.height > a.width * a.height ? b : a))
}

/**
 * Show the scrim and card only once both the area and the spot are measured
 * with a real size. An unmeasured spot (0×0, or no area yet — e.g. inside a
 * Preview sizes frame before it settles) shows nothing rather than dimming
 * everything, assistant included.
 */
/**
 * A spot that was found but still isn't on screen after this long (clipped,
 * hidden, in a layout that isn't showing) is given up on — the reply says it
 * couldn't be found — instead of "finding it…" forever.
 */
export const SPOT_READY_MS = 3000

export function spotGivesUp(foundAt: number | null, now: number, ready: boolean, ms = SPOT_READY_MS): boolean {
  return !ready && foundAt !== null && now - foundAt >= ms
}

/**
 * On a phone the card is a sheet at the bottom — except when the spot itself
 * is down there (the bottom tabs, a last row): then the sheet goes to the top
 * so it never covers what it points at.
 */
export function sheetAtTop(spot: { top: number; height: number } | null | undefined, viewportHeight: number): boolean {
  return !!spot && viewportHeight > 0 && spot.top + spot.height > viewportHeight * 0.6
}

export function spotReady(area: Box | null | undefined, spot: { width: number; height: number } | null | undefined): area is Box {
  return !!area && area.width > 0 && area.height > 0 && !!spot && spot.width > 0 && spot.height > 0
}

export type Side = 'bottom' | 'top' | 'right' | 'left'

export interface CardPlace {
  left: number
  top: number
  /** The card's edge facing the spot (the pointer sits on it). */
  side: Side
  /** Pointer position along that edge, px from the card's left (top/bottom) or top (left/right). */
  pointer: number
}

/**
 * The card beside the spot, inside the scrim area: below if it fits, else
 * above, right, left; slid along to stay inside; the pointer aims at the
 * spot's centre (kept off the rounded corners).
 */
export function placeCard(spot: Box, card: { width: number; height: number }, area: Box, gap = 14, inset = 8, corner = 18): CardPlace {
  const minL = area.left + inset
  const maxL = area.left + area.width - inset - card.width
  const minT = area.top + inset
  const maxT = area.top + area.height - inset - card.height
  const slide = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v))
  const below = spot.top + spot.height + gap
  const above = spot.top - gap - card.height
  const rightX = spot.left + spot.width + gap
  const leftX = spot.left - gap - card.width
  const cx = spot.left + spot.width / 2
  const cy = spot.top + spot.height / 2
  const along = (start: number, size: number, centre: number) => slide(centre - start, corner, size - corner)
  let side: Side
  let left: number
  let top: number
  if (below <= maxT) [side, top, left] = ['top', below, slide(spot.left - 8, minL, Math.max(minL, maxL))]
  else if (above >= minT) [side, top, left] = ['bottom', above, slide(spot.left - 8, minL, Math.max(minL, maxL))]
  else if (rightX <= maxL) [side, left, top] = ['left', rightX, slide(cy - card.height / 2, minT, Math.max(minT, maxT))]
  else if (leftX >= minL) [side, left, top] = ['right', leftX, slide(cy - card.height / 2, minT, Math.max(minT, maxT))]
  else [side, top, left] = ['top', slide(below, minT, Math.max(minT, maxT)), slide(spot.left - 8, minL, Math.max(minL, maxL))]
  const pointer = side === 'top' || side === 'bottom' ? along(left, card.width, cx) : along(top, card.height, cy)
  return { left: Math.round(left), top: Math.round(top), side, pointer: Math.round(pointer) }
}
