/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/ui/harness-gate.assert.ts
 */
import assert from 'node:assert/strict'
import { gateState } from './harness-gate'

assert.equal(gateState({ isLoading: true, error: null, allowed: false }), 'loading', 'never "only for owners" while loading')
assert.equal(gateState({ isLoading: true, error: null, allowed: true }), 'loading')
assert.equal(gateState({ isLoading: false, error: new Error('Failed to fetch permissions (429)'), allowed: false }), 'error', 'a failed check is not a no')
assert.equal(gateState({ isLoading: false, error: null, allowed: false }), 'denied')
assert.equal(gateState({ isLoading: false, error: null, allowed: true }), 'allowed')
assert.equal(gateState({ isLoading: false, error: new Error('x'), allowed: true }), 'allowed', 'stale error, but access known')
console.log('6 assertions passed')
