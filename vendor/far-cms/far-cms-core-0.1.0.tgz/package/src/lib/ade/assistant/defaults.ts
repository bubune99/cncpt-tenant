/**
 * Every default of the assistant's awareness and pointing, in one place.
 * Fixed presets for now (owner 2026-10-17: per-user or per-site settings
 * come later); keeping them here makes that a small change.
 *
 * App-agnostic: no app names, no app routes. Used by playbook.ts (the
 * pointing ladder and playbook in the prompt) and context-card.ts (what the
 * assistant is told each turn).
 */

export type CardIntent = 'where' | 'go' | 'todo' | 'changes' | 'edit' | 'count' | 'budget'

export const ASSISTANT_DEFAULTS = {
  pointing: {
    /** Navigate only when the person asks to go there ("take me", "go to", "open"); otherwise point. */
    navigateOnlyWhenAsked: true,
    /** How many spots a "how do I" walk-through uses at most. */
    howToMaxSteps: 3,
  },
  card: {
    /** The core block's cap (characters): mode, route, assistant, menu layout, viewport, selection, role. */
    coreMaxChars: 480,
    /** Each bundle's cap (characters). Counts and labels only — bodies are fetched by tools. */
    bundleMaxChars: {
      where: 1800,
      todo: 700,
      changes: 700,
      edit: 600,
      budget: 240,
    } satisfies Partial<Record<CardIntent, number>>,
    /** The open plan's line (labels and the current step) in the core part of the card; only while a plan is open. */
    planMaxChars: 420,
    /** Bundles that stay on for follow-ups: a to-do answer's numbers stay in view for the next turns. */
    sticky: ['todo'] as ReadonlyArray<CardIntent>,
    /** How many earlier questions make a bundle sticky. */
    stickyLookback: 2,
    /** To-do bundle: how many items, by title, age and kind. */
    todoTopN: 5,
    /** Changes bundle: how many recent changes and how many of the last run's steps. */
    changesTopN: 5,
    lastRunSteps: 8,
    /** Words that stand for a field the page didn't report (never guessed). */
    unknown: 'unknown',
    /** Viewport by window width (px): phone up to phoneMax, tablet up to tabletMax, else desktop. */
    viewport: { phoneMax: 767, tabletMax: 1023 },
    /** Below this share of the daily budget, the budget bundle says it is low. */
    budgetLowShare: 0.1,
  },
  /**
   * The To-do walk-through (owner 2026-10-17): it points at things and names them — no opened
   * details, no brief or preview moves; for more it goes to the To-do page. Each move says ONE
   * short plain line (speech reads the same string later). Phrases are guesses, like the intents.
   */
  walkthrough: {
    /** Words per narration line at most. */
    maxNarrationWords: 25,
    /** Characters of an item title quoted in "more detail". */
    itemTitleChars: 50,
    /** Typed (or the briefing link) to start the walk. */
    startPhrases: ['walk me through my to-do', 'walk me through the to-do', 'walk me through my todo', 'walk me through the todo', 'walk me through my to do', 'walk me through the to do', 'walk through my to-do', 'go through my to-do'],
    /** While a walk is on screen: fewer stops. */
    fasterPhrases: ['faster', 'quicker', 'speed up', 'shorter', 'just the summary'],
    /** While a walk is on screen: go to the To-do page and point at the items there. */
    detailPhrases: ['more detail', 'more details', 'show me', 'show me more', 'in detail'],
  },
  /**
   * Which bundle a question needs: keyword rules, no model call. Guessed
   * phrases (owner 2026-10-17: use the brief's guesses until the team's real
   * ones come in). Lower case; a phrase matches on word boundaries.
   */
  intents: {
    go: ['take me', 'go to', 'bring me', 'open', 'navigate to', 'jump to', 'head to'],
    where: ['where', 'show me', 'find', 'locate', 'point', 'which menu', 'how do i get', 'how do i find', 'can’t find', "can't find", 'cant find', 'how do i'],
    todo: ['to-do', 'todo', 'to do', 'needs me', 'need me', 'needs my', 'approve', 'approval', 'approvals', 'waiting on me', 'pending', 'what’s waiting', "what's waiting", 'review queue'],
    changes: ['what changed', 'what has changed', "what's changed", 'what’s changed', 'what did you do', 'what have you done', 'what happened', 'since', 'anything new', 'latest changes'],
    edit: ['add', 'edit', 'update', 'change', 'rename', 'publish', 'unpublish', 'delete', 'remove', 'send', 'fix', 'replace', 'create', 'make a'],
    count: ['how many', 'list', 'count', 'number of'],
    budget: ['budget', 'limit', 'limits', 'tokens', 'quota', 'how much can you', 'run out'],
  } satisfies Record<CardIntent, ReadonlyArray<string>>,
} as const
