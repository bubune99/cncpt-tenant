/**
 * The context card: what the assistant knows about the person's situation
 * before it answers, built by code from the page and the server — never
 * guessed by the model. Sized to the question (owner 2026-10-17): a tiny core
 * every turn, and a bundle only when the question needs it (keyword rules,
 * no model call). Unknown fields say so, so the model asks instead of guessing.
 *
 * Pure: question + state in, card out. Defaults (caps, phrases) live in
 * defaults.ts. Asserted by context-card.assert.ts.
 */

import { ASSISTANT_DEFAULTS, type CardIntent } from './defaults'
import { clipLines, type ShellLayout } from '../ui/shell-units'

// ── Intent ───────────────────────────────────────────────────────────

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const phraseRe = (p: string) => new RegExp(`(?:^|[^\\p{L}\\p{N}])${esc(p.trim())}(?:$|[^\\p{L}\\p{N}])`, 'iu')

const INTENT_RULES: ReadonlyArray<[CardIntent, ReadonlyArray<RegExp>]> = (Object.entries(ASSISTANT_DEFAULTS.intents) as Array<[CardIntent, ReadonlyArray<string>]>).map(([k, ps]) => [k, ps.map(phraseRe)])

/** Which bundles a question needs, in a fixed order. "General or unclear": none (core only). */
export function classifyIntents(question: string): CardIntent[] {
  const q = question.replace(/[’‘]/g, "'").slice(0, 2000)
  const hit = INTENT_RULES.filter(([, res]) => res.some((r) => r.test(q) || r.test(question))).map(([k]) => k)
  return hit
}

/**
 * The intents a turn's card serves: this question's, plus sticky ones from the
 * last few questions — a follow-up after a to-do answer keeps the to-do facts
 * in view (staging C3: the model "corrected" a right count from dashboard tiles).
 */
export function cardIntents(question: string, recentQuestions: ReadonlyArray<string> = []): CardIntent[] {
  const now = classifyIntents(question)
  const { sticky, stickyLookback } = ASSISTANT_DEFAULTS.card
  const recent = recentQuestions.slice(-stickyLookback).flatMap(classifyIntents)
  return [...now, ...sticky.filter((i) => recent.includes(i) && !now.includes(i))]
}

/** Bundles each intent brings ("go" needs the menu too, to pick the place). */
const BUNDLES_FOR: Record<CardIntent, ReadonlyArray<BundleKey>> = {
  where: ['where'],
  go: ['where'],
  todo: ['todo'],
  changes: ['changes'],
  edit: ['edit'],
  count: [],
  budget: ['budget'],
}

export type BundleKey = 'where' | 'todo' | 'changes' | 'edit' | 'budget'
const BUNDLE_ORDER: ReadonlyArray<BundleKey> = ['where', 'todo', 'changes', 'edit', 'budget']

export function bundlesFor(intents: ReadonlyArray<CardIntent>): BundleKey[] {
  const want = new Set(intents.flatMap((i) => BUNDLES_FOR[i]))
  return BUNDLE_ORDER.filter((b) => want.has(b))
}

// ── Core ─────────────────────────────────────────────────────────────

export type AdminModeName = 'Workspace' | 'Classic'
export type AssistantState = 'closed' | 'docked left' | 'docked right' | 'full page' | 'side panel' | 'overlay' | 'sheet'
export type Viewport = 'phone' | 'tablet' | 'desktop'

export interface CardCore {
  mode: AdminModeName | null
  route: string | null
  assistant: AssistantState | null
  /** How the menu is shown (shell-units ShellLayout). */
  layout: ShellLayout | null
  viewport: Viewport | null
  /** "block b12" / "record initiative:abc" — ids only; null when nothing is selected. */
  selection: string | null
  /** Their role(s) by name. */
  role: string | null
}

/** The chat panel's state in the words of the card. */
export function assistantStateOf(input: { mode: string | null | undefined; agentFull?: boolean; agentSide?: 'left' | 'right'; phone?: boolean }): AssistantState | null {
  switch (input.mode) {
    case 'collapsed':
    case 'minimized':
      return 'closed'
    case 'split':
      return input.phone ? 'sheet' : input.agentFull ? 'full page' : input.agentSide === 'right' ? 'docked right' : 'docked left'
    case 'side':
      return 'side panel'
    case 'full':
      return 'full page'
    default:
      return null
  }
}

export function viewportOf(width: number | null | undefined, phone?: boolean): Viewport | null {
  if (phone) return 'phone'
  if (typeof width !== 'number' || !Number.isFinite(width) || width <= 0) return null
  const { phoneMax, tabletMax } = ASSISTANT_DEFAULTS.card.viewport
  return width <= phoneMax ? 'phone' : width <= tabletMax ? 'tablet' : 'desktop'
}

const LAYOUT_SHORT: Record<ShellLayout, string> = { sidebar: 'sidebar shown', drawer: 'sidebar behind ☰', menu: '☰ menu, no sidebar', phone: 'phone tabs' }

function coreText(c: CardCore): { text: string; unknown: string[] } {
  const u = ASSISTANT_DEFAULTS.card.unknown
  const unknown: string[] = []
  const f = (name: string, v: string | null) => {
    if (v === null || v === '') unknown.push(name)
    return `${name} ${v === null || v === '' ? u : v}`
  }
  const parts = [
    f('mode', c.mode),
    f('route', c.route),
    f('assistant', c.assistant),
    f('menu', c.layout ? LAYOUT_SHORT[c.layout] : null),
    f('viewport', c.viewport),
    `selection ${c.selection ?? 'none'}`,
    f('role', c.role),
  ]
  return { text: parts.join(' · '), unknown }
}

// ── Bundles ──────────────────────────────────────────────────────────

export interface TodoBundleInput {
  /** The To-do page's "N need you" (same source, so the answer equals the page). */
  needYou: number
  /** Counts by kind, as the To-do names them ("to approve", "messages"…); zeros left out. */
  counts: ReadonlyArray<{ label: string; n: number }>
  /** The top items: title, kind, age in days. */
  top: ReadonlyArray<{ title: string; kind: string; ageDays: number | null }>
}

export interface ChangesBundleInput {
  /** Recent changes, newest first ("About page edit approved, 1h ago"). */
  items: ReadonlyArray<string>
  /** The last run's step labels, in order. */
  lastRun: ReadonlyArray<string>
}

export interface EditBundleInput {
  /** What "this" is ("page About", "block Hero heading"). */
  target: string
  /** draft / live / unknown. */
  status: string | null
  /** Current values, short. */
  values: ReadonlyArray<[string, string]>
  /** Who may approve a change to it, or whether this person may. */
  approver: string | null
}

export interface BudgetBundleInput {
  tokensLeft: number
  /** The daily budget, when there is one (0 / null: none). */
  daily: number | null
}

export interface CardInput {
  question: string
  /** The working screen's facts (lib/ade/ui/screen-context screenCardLines): every turn while it is open, capped there. */
  screen?: string | null
  /** The person's previous messages in this conversation, newest last: sticky bundles (defaults.card.sticky) stay on for follow-ups. */
  recentQuestions?: ReadonlyArray<string>
  /** The section the question names (lib/ade/assistant/pointing askedSection) and whether they are on it. */
  asked?: { name: string; href: string; here: boolean } | null
  core: CardCore
  /** The open plan as one line of labels (step N of M, done, now, still to do); null/absent when no plan is open. */
  plan?: string | null
  /** The "where things are" text (shell-units shellPicture), when the page reported its chrome. */
  where?: string | null
  todo?: TodoBundleInput | null
  changes?: ChangesBundleInput | null
  edit?: EditBundleInput | null
  budget?: BudgetBundleInput | null
}

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s)
/** Text from records: one line, no markup that could pass for an instruction header. */
const plain = (s: string, n: number) => clip(s.replace(/[\r\n\t]+/g, ' ').replace(/[[\]`]/g, '').replace(/\s{2,}/g, ' ').trim(), n)

const age = (d: number | null) => (d === null ? '' : d < 1 ? 'today' : d < 2 ? '1 day' : `${Math.floor(d)} days`)

function todoText(t: TodoBundleInput): string[] {
  const counts = t.counts.filter((c) => c.n > 0).map((c) => `${c.n} ${c.label}`)
  const lines = [`To-do: ${t.needYou} ${t.needYou === 1 ? 'thing needs' : 'things need'} them${counts.length ? ` (${counts.join(', ')})` : ''} — the same numbers as the To-do page.`]
  const top = t.top.slice(0, ASSISTANT_DEFAULTS.card.todoTopN)
  if (top.length) lines.push(`Top ${top.length}: ${top.map((i) => `“${plain(i.title, 60)}” (${[i.kind, age(i.ageDays)].filter(Boolean).join(', ')})`).join('; ')}.`)
  lines.push('Answer with one line of counts and offer the walk-through; never list every item in chat. These are the To-do\'s numbers (settled: dashboard tiles count differently).')
  return lines
}

function changesText(c: ChangesBundleInput): string[] {
  const d = ASSISTANT_DEFAULTS.card
  const lines: string[] = []
  if (c.items.length) lines.push(`Changes since: ${c.items.slice(0, d.changesTopN).map((s) => plain(s, 90)).join('; ')}.`)
  if (c.lastRun.length) lines.push(`Your last run's steps: ${c.lastRun.slice(0, d.lastRunSteps).map((s) => plain(s, 50)).join(' → ')}.`)
  if (!lines.length) lines.push('Changes: nothing recorded since the last turn.')
  return lines
}

function editText(e: EditBundleInput): string[] {
  const vals = e.values.slice(0, 6).map(([k, v]) => `${plain(k, 30)}: ${plain(v, 60)}`)
  return [
    `Editing: ${plain(e.target, 80)} — ${e.status ?? ASSISTANT_DEFAULTS.card.unknown}${vals.length ? `; now ${vals.join(', ')}` : ''}.`,
    `Approves: ${e.approver ?? ASSISTANT_DEFAULTS.card.unknown}. Draft first; never change it live.`,
  ]
}

function budgetText(b: BudgetBundleInput): string[] {
  const left = Math.max(0, Math.round(b.tokensLeft))
  const of = b.daily && b.daily > 0 ? ` of ${b.daily.toLocaleString('en-US')}` : ''
  const low = b.daily && b.daily > 0 && left / b.daily < ASSISTANT_DEFAULTS.card.budgetLowShare
  return [`Budget: about ${left.toLocaleString('en-US')} tokens left today${of}.${low ? ' It is low: say so plainly; short answers and pointing still work.' : ''}`]
}

// ── The card ─────────────────────────────────────────────────────────

export interface ContextCard {
  intents: CardIntent[]
  /** Bundles actually included (intent matched AND data present). */
  bundles: BundleKey[]
  /** Bundles the question needed but the page/server had no data for. */
  missing: BundleKey[]
  /** Core fields nobody reported. */
  unknown: string[]
  text: string
  size: { core: number; plan: number; total: number; bundles: Partial<Record<BundleKey, number>> }
}

/**
 * Build the card. The core is always there and stays under its cap; a bundle
 * is added only when its intent matched and its data was given, each under
 * its own cap. A needed bundle without data is named, never filled in.
 */
export function buildContextCard(input: CardInput): ContextCard {
  const d = ASSISTANT_DEFAULTS.card
  const intents = cardIntents(input.question, input.recentQuestions)
  const core = coreText(input.core)
  const coreLine = clip(`[Context card] ${core.text}`, d.coreMaxChars)
  const sections: string[] = [coreLine]
  // The screen the person is working on (R4): page, state, its own checklist, selection, device.
  if (input.screen?.trim()) sections.push(input.screen.trim())
  // The open plan travels with the core, every turn it is open — labels only, capped.
  const planLine = input.plan?.trim() ? clip(`[Plan] ${input.plan.replace(/[\r\n]+/g, ' ').trim()}`, d.planMaxChars) : null
  if (planLine) sections.push(planLine)
  if (core.unknown.length) sections.push(`Not reported: ${core.unknown.join(', ')} — if the answer depends on it, ask one short question; never guess.`)
  const bundles: BundleKey[] = []
  const missing: BundleKey[] = []
  const sizes: Partial<Record<BundleKey, number>> = {}
  for (const b of bundlesFor(intents)) {
    const askedLine = input.asked
      ? input.asked.here
        ? `They mean ${input.asked.name}, the screen they are on: point at its content, not its menu entry.`
        : `They mean ${input.asked.name}: point at [data-ui="shell.nav.${input.asked.href}"] (code corrects other targets and adds the Take me there link).`
      : null
    const lines =
      b === 'where' ? (input.where || askedLine ? [`[Where things are]`, ...(askedLine ? [askedLine] : []), ...(input.where ? [input.where] : [])] : null)
      : b === 'todo' ? (input.todo ? todoText(input.todo) : null)
      : b === 'changes' ? (input.changes ? changesText(input.changes) : null)
      : b === 'edit' ? (input.edit ? editText(input.edit) : null)
      : input.budget ? budgetText(input.budget) : null
    if (!lines) {
      missing.push(b)
      continue
    }
    const text = clipLines(lines.join('\n').split('\n'), d.bundleMaxChars[b])
    sizes[b] = text.length
    bundles.push(b)
    sections.push(text)
  }
  if (missing.length) sections.push(`No ${missing.join(', ')} details came with this turn: use your tools for them, and never guess.`)
  if (intents.includes('count')) sections.push('Counts and lists come from tools, never from this card or memory; link each name.')
  const text = sections.join('\n')
  return { intents, bundles, missing, unknown: core.unknown, text, size: { core: coreLine.length, plan: planLine?.length ?? 0, total: text.length, bundles: sizes } }
}
