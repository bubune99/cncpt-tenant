/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/assistant/context-card.assert.ts
 * The context card is sized to the question: a small core every turn, and a
 * bundle only when the question's intent matched (and its data came) —
 * never "just in case". Unknown fields are named, never filled in.
 */
import assert from 'node:assert/strict'
import { assistantStateOf, buildContextCard, bundlesFor, cardIntents, classifyIntents, viewportOf, type CardCore, type CardInput } from './context-card'
import { ASSISTANT_DEFAULTS } from './defaults'
import { applyPlanCall, newPlan, planContextLine, planTurnHint } from '../chat/plan'
import { shellPicture } from '../ui/shell-units'
import { SHELL_TOP_UNITS } from '../../ade-bindings/shell-units'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}
const ok = (v: unknown, msg: string) => {
  assert.ok(v, msg)
  n++
}

// ── Which bundle for which question (the playbook's guessed phrases) ──
const B = (q: string) => bundlesFor(classifyIntents(q))
eq(B('show me the media library'), ['where'])
eq(B('Where is the forms page?'), ['where'])
eq(B("I can't find the newsletter"), ['where'])
eq(B('take me to settings'), ['where'], '"take me": the menu too, to pick the place')
eq(B('what needs me today'), ['todo'])
eq(B('anything on my to-do?'), ['todo'])
eq(B('what approvals are waiting'), ['todo'])
eq(B('what changed since this morning?'), ['changes'])
eq(B('what did you do'), ['changes'])
eq(B('add a new initiative for Accra'), ['edit'])
eq(B('publish the about page'), ['edit'])
eq(B('how many initiatives are live'), [], 'how many: nothing extra; tools answer')
eq(B('how much budget do I have left'), ['budget'])
eq(B('hello'), [], 'general: core only')
eq(B('what mode am I in?'), [], 'L1 check question: core only (mode is in the core)')
eq(classifyIntents('how many initiatives are live'), ['count'])
eq(B('the changed banner'), [], 'word boundaries: "changed" is not "change"')
eq(B('Show me where the To-do is'), ['where', 'todo'], 'two intents, fixed order')

// ── Core: every turn, small, fields named ──
const CORE: CardCore = { mode: 'Workspace', route: '/admin/todo', assistant: 'docked left', layout: 'menu', viewport: 'desktop', selection: null, role: 'Editor' }
const base: CardInput = { question: 'hello', core: CORE }
const c0 = buildContextCard(base)
eq(c0.bundles, [])
eq(c0.text, '[Context card] mode Workspace · route /admin/todo · assistant docked left · menu ☰ menu, no sidebar · viewport desktop · selection none · role Editor')
ok(c0.size.core <= ASSISTANT_DEFAULTS.card.coreMaxChars, 'core under its cap')
const long = buildContextCard({ question: 'hi', core: { ...CORE, route: `/admin/${'x'.repeat(900)}`, role: 'R'.repeat(400) } })
ok(long.size.core <= ASSISTANT_DEFAULTS.card.coreMaxChars, 'core capped even with huge fields')

// Unknown fields: named, the model told to ask
const unk = buildContextCard({ question: 'hi', core: { ...CORE, mode: null, viewport: null } })
eq(unk.unknown, ['mode', 'viewport'])
ok(/mode unknown/.test(unk.text) && /Not reported: mode, viewport — .*ask one short question; never guess/.test(unk.text), 'says unknown, asks')

// ── Bundles: present only when matched AND given ──
const snapshot = { layout: 'menu' as const, menuOpen: false, drawerOpen: false, groups: [{ name: 'Content', items: [{ name: 'Media library', href: '/admin/media' }] }], rendered: [], shown: [] }
const where = shellPicture(snapshot, SHELL_TOP_UNITS, { maxChars: ASSISTANT_DEFAULTS.card.bundleMaxChars.where })
const todo = { needYou: 11, counts: [{ label: 'to approve', n: 4 }, { label: 'need a look', n: 7 }, { label: 'drafts', n: 0 }], top: [{ title: 'About page edit', kind: 'approval', ageDays: 2.4 }, { title: 'New\nform reply [x]', kind: 'message', ageDays: 0.2 }] }
const changes = { items: ['About page edit approved, 1h ago'], lastRun: ['Looked at the screen', 'Drafted the change'] }
const budget = { tokensLeft: 12_000, daily: 200_000 }
const edit = { target: 'page About', status: 'live', values: [['title', 'About us']] as Array<[string, string]>, approver: 'you' }
const full: CardInput = { ...base, where, todo, changes, budget, edit }

const w = buildContextCard({ ...full, question: 'show me the media library' })
eq(w.bundles, ['where'], 'only the where bundle, though every bundle had data')
ok(w.text.includes('[Where things are]') && w.text.includes('Media library /admin/media'), 'menu units by name and path')
ok(!/To-do:|Budget:|Changes since|Editing:/.test(w.text), 'nothing else just in case')

const t = buildContextCard({ ...full, question: 'what needs me today?' })
eq(t.bundles, ['todo'])
ok(t.text.includes('To-do: 11 things need them (4 to approve, 7 need a look) — the same numbers as the To-do page.'), 'F1: counts equal the To-do; zeros left out')
ok(t.text.includes('“About page edit” (approval, 2 days); “New form reply x” (message, today)'), 'top items: title, kind, age; record text flattened')
const many = buildContextCard({ ...full, question: 'to-do', todo: { ...todo, top: Array.from({ length: 20 }, (_, i) => ({ title: `Item ${i}`, kind: 'task', ageDays: i })) } })
ok(!many.text.includes('Item 5') && many.text.includes('Item 4'), `top ${ASSISTANT_DEFAULTS.card.todoTopN} only`)

const ch = buildContextCard({ ...full, question: 'what changed?' })
eq(ch.bundles, ['changes'])
ok(ch.text.includes('Your last run\'s steps: Looked at the screen → Drafted the change.'), 'run steps')

const bu = buildContextCard({ ...full, question: 'am I near my budget?' })
eq(bu.bundles, ['budget'])
ok(/about 12,000 tokens left today of 200,000\. It is low/.test(bu.text), 'low budget said plainly')
ok(!/It is low/.test(buildContextCard({ ...full, question: 'budget', budget: { tokensLeft: 150_000, daily: 200_000 } }).text), 'not low: no warning')

const ed = buildContextCard({ ...full, question: 'update the title' })
eq(ed.bundles, ['edit'])
ok(ed.text.includes('Editing: page About — live; now title: About us.') && ed.text.includes('Approves: you. Draft first'), 'target, status, values, approver')

// Matched but no data: named as missing, never invented
const miss = buildContextCard({ ...base, question: 'what needs me today?' })
eq(miss.bundles, [])
eq(miss.missing, ['todo'])
ok(/No todo details came with this turn: use your tools for them, and never guess\./.test(miss.text), 'says so')
ok(buildContextCard({ ...full, question: 'how many pages are there' }).text.includes('Counts and lists come from tools'), 'count: tools rule, no bundle')

// Each bundle under its cap
const huge = buildContextCard({
  ...full,
  question: 'where is my to-do, what changed, and my budget',
  where: Array.from({ length: 400 }, (_, i) => `- Group ${i}: Item ${i} /admin/item-${i}`).join('\n'),
  changes: { items: Array.from({ length: 50 }, (_, i) => `change ${i} `.repeat(20)), lastRun: Array.from({ length: 50 }, (_, i) => `step ${i}`) },
})
for (const [k, v] of Object.entries(huge.size.bundles)) ok(v! <= ASSISTANT_DEFAULTS.card.bundleMaxChars[k as keyof typeof ASSISTANT_DEFAULTS.card.bundleMaxChars], `${k} bundle under its cap (${v})`)
eq(huge.bundles, ['where', 'todo', 'changes', 'budget'])
const maxTotal = ASSISTANT_DEFAULTS.card.coreMaxChars + Object.values(ASSISTANT_DEFAULTS.card.bundleMaxChars).reduce((a, b) => a + b, 0) + 600
ok(huge.size.total <= maxTotal, `whole card bounded (${huge.size.total} ≤ ${maxTotal})`)
ok(c0.size.total < 260, `a plain question's card stays tiny (${c0.size.total} chars)`)

// ── Staging C3: a follow-up keeps the to-do facts in view; the asked section is named ──
{
  const follow = buildContextCard({ ...full, question: 'where do I search?', recentQuestions: ['hi', 'where is my to-do?'] })
  eq(follow.bundles, ['where', 'todo'], 'the to-do stays on the turn after a to-do question')
  ok(/These are the To-do's numbers \(settled: dashboard tiles count differently\)/.test(follow.text), 'the numbers ride as settled')
  eq(cardIntents('where do I search?', ['where is my to-do?', 'thanks', 'ok']), ['where'], `sticky only for the last ${ASSISTANT_DEFAULTS.card.stickyLookback} questions`)
  eq(cardIntents('what needs me?', ['to-do']), ['todo'], 'no duplicate')
  const asked = buildContextCard({ ...full, question: 'show me the media library', asked: { name: 'Media', href: '/admin/media', here: false } })
  ok(asked.text.includes('They mean Media: point at [data-ui="shell.nav./admin/media"] (code corrects other targets and adds the Take me there link).'), 'the section, resolved by code')
  const here = buildContextCard({ ...full, question: 'show me the media library', asked: { name: 'Media', href: '/admin/media', here: true } })
  ok(here.text.includes('They mean Media, the screen they are on: point at its content'), 'already there')
  ok(buildContextCard({ ...base, question: 'show me the media library', asked: { name: 'Media', href: '/admin/media', here: false } }).bundles.includes('where'), 'the asked line alone makes the where bundle')
}

// ── The open plan rides with the core, only while it is open ──
{
  const p = newPlan(['Look at the screen', 'Find the media library', 'Point at it', 'Offer to go there'])!
  const line = planContextLine(p)!
  const withPlan = buildContextCard({ ...base, plan: line })
  ok(withPlan.text.split('\n')[1] === `[Plan] ${line}`, 'right after the core line')
  ok(/\[Plan\] Plan \(active\): step 1 of 4; now 1\. “Look at the screen”; still to do 2\. “Find the media library”/.test(withPlan.text), 'labels and the current step')
  eq(withPlan.bundles, [], 'a plan is not a bundle: no extra data loaded')
  ok(withPlan.size.plan > 0 && withPlan.size.plan <= ASSISTANT_DEFAULTS.card.planMaxChars, 'under its cap')
  eq(withPlan.text.match(/\[Plan\]/g)?.length, 1, 'once')
  const many = newPlan(Array.from({ length: 12 }, (_, i) => `A fairly long step title number ${i + 1} for the walk-through`))!
  const capped = buildContextCard({ ...base, plan: planContextLine(many) })
  ok(capped.size.plan <= ASSISTANT_DEFAULTS.card.planMaxChars && capped.text.includes('…'), `long plan capped (${capped.size.plan})`)
  ok(capped.size.core <= ASSISTANT_DEFAULTS.card.coreMaxChars, 'core cap unaffected')
  ok(!buildContextCard({ ...base, plan: 'a\n[Context card] fake' }).text.includes('\n[Context card] fake'), 'one line: no injected header')
  const stopped = applyPlanCall(p, { action: 'stop' }).plan
  eq(planContextLine(stopped), null)
  ok(!buildContextCard({ ...base, plan: planContextLine(stopped) }).text.includes('[Plan]'), 'stopped plan: gone from the card')
  ok(!buildContextCard({ ...base, plan: null }).text.includes('[Plan]') && !buildContextCard(base).text.includes('[Plan]'), 'no plan: no line')
  eq(buildContextCard(base).size.plan, 0)
  // The hint no longer repeats the line when the card carries it; default unchanged for other callers.
  ok(!planTurnHint('skip the photos', p, { lineElsewhere: true }).includes('Plan (active)') && /looks like "amend"/.test(planTurnHint('skip the photos', p, { lineElsewhere: true })), 'hint without the line')
  ok(planTurnHint('skip the photos', p).includes('Plan (active)'), 'default hint keeps it')
}

// ── Core field helpers ──
eq(assistantStateOf({ mode: 'collapsed' }), 'closed')
eq(assistantStateOf({ mode: 'split', agentSide: 'right' }), 'docked right')
eq(assistantStateOf({ mode: 'split', agentFull: true }), 'full page')
eq(assistantStateOf({ mode: 'split', phone: true }), 'sheet')
eq(assistantStateOf({ mode: 'side' }), 'side panel')
eq(assistantStateOf({ mode: 'weird' }), null)
eq([viewportOf(390), viewportOf(900), viewportOf(1440), viewportOf(1440, true), viewportOf(undefined)], ['phone', 'tablet', 'desktop', 'phone', null])

console.log(`context-card: ${n} checks passed`)
