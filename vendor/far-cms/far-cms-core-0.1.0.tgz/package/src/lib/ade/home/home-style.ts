/**
 * Home screen styles: which whole home design a person sees, how a new person is started on one, and how a
 * style is judged (owner decision 2026-11-20, planner 1b8076d7: "Both" choice, "Random start, free to switch",
 * measured by "Which style people keep"). Pure: the random source and the time are passed in.
 * The styles a site offers come from the site (BYB: studio + focused; one style = no choice, nothing stored).
 * Check: home-style.assert.ts.
 */

export interface HomeStyleSwitch { from: string; to: string; at: string }
export interface HomeStyleRecord {
  /** What the person sees now. */
  style: string
  /** What they were started on (the A/B arm). */
  assigned: string
  assignedAt: string
  /** Most recent last, at most MAX_SWITCHES. */
  switches: HomeStyleSwitch[]
}

const MAX_SWITCHES = 50
const isIso = (v: unknown): v is string => typeof v === 'string' && !Number.isNaN(Date.parse(v))
const isName = (v: unknown): v is string => typeof v === 'string' && /^[a-z][a-z0-9-]{0,31}$/.test(v)

/** A stored record, or null when it is missing or malformed. */
export function parseHomeStyle(raw: unknown): HomeStyleRecord | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as Record<string, unknown>
  if (!isName(r.style) || !isName(r.assigned) || !isIso(r.assignedAt)) return null
  const switches = (Array.isArray(r.switches) ? r.switches : [])
    .filter((s): s is HomeStyleSwitch => !!s && typeof s === 'object' && isName((s as HomeStyleSwitch).from) && isName((s as HomeStyleSwitch).to) && isIso((s as HomeStyleSwitch).at))
    .slice(-MAX_SWITCHES)
  return { style: r.style, assigned: r.assigned, assignedAt: r.assignedAt, switches }
}

export interface HomeStyleResolution {
  style: string
  /** The record to keep (null when the site offers only one style). */
  record: HomeStyleRecord | null
  /** True when the record was made just now and must be saved. */
  isNew: boolean
  /** Whether a choice is shown at all. */
  offered: boolean
}

/** The style to show. A person with no record is started on one at random, once. */
export function homeStyleFor(stored: HomeStyleRecord | null, styles: readonly string[], random: () => number, now: Date): HomeStyleResolution {
  if (styles.length === 0) throw new Error('a site offers at least one home style')
  if (styles.length === 1) return { style: styles[0], record: null, isNew: false, offered: false }
  if (stored) return { style: styles.includes(stored.style) ? stored.style : styles[0], record: stored, isNew: false, offered: true }
  const pick = styles[Math.min(styles.length - 1, Math.floor(random() * styles.length))]
  return { style: pick, record: { style: pick, assigned: pick, assignedAt: now.toISOString(), switches: [] }, isNew: true, offered: true }
}

/** The person chose `to`. Returns a new record (the old one is not changed); the same style returns it as is. */
export function switchHomeStyle(stored: HomeStyleRecord | null, to: string, styles: readonly string[], now: Date, showing?: string): HomeStyleRecord {
  if (!styles.includes(to)) throw new Error(`unknown home style: ${to}`)
  const base: HomeStyleRecord = stored ?? { style: showing ?? styles[0], assigned: showing ?? styles[0], assignedAt: now.toISOString(), switches: [] }
  if (base.style === to) return base
  return { ...base, style: to, switches: [...base.switches, { from: base.style, to, at: now.toISOString() }].slice(-MAX_SWITCHES) }
}

/** The style someone was on at a moment: where they started, then each switch up to then. */
function styleAt(r: HomeStyleRecord, at: number): string {
  let s = r.assigned
  for (const w of r.switches) if (Date.parse(w.at) <= at) s = w.to
  return s
}

export interface KeptRow { style: string; started: number; due7: number; kept7: number; due30: number; kept30: number; switchedAway: number; onNow: number }

/**
 * Per style: how many were started on it, of those far enough along how many were still on it after 7 and 30
 * days, how many ever switched away from it, and how many are on it now (started there or switched to it).
 */
export function keptReport(records: readonly HomeStyleRecord[], styles: readonly string[], now: Date): KeptRow[] {
  const t = now.getTime()
  return styles.map((style) => {
    const arm = records.filter((r) => r.assigned === style)
    const after = (days: number) => arm.filter((r) => Date.parse(r.assignedAt) + days * 86_400_000 <= t)
    const d7 = after(7), d30 = after(30)
    return {
      style,
      started: arm.length,
      due7: d7.length,
      kept7: d7.filter((r) => styleAt(r, Date.parse(r.assignedAt) + 7 * 86_400_000) === style).length,
      due30: d30.length,
      kept30: d30.filter((r) => styleAt(r, Date.parse(r.assignedAt) + 30 * 86_400_000) === style).length,
      switchedAway: arm.filter((r) => r.switches.some((w) => w.from === style)).length,
      onNow: records.filter((r) => r.style === style).length,
    }
  })
}
