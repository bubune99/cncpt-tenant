/**
 * The home styles this site offers (app-config homeStyles), with the built-in single home when it names none.
 * Pure data; check: home-style.assert.ts covers the rule, site-styles is covered there too.
 */
import { APP_ADE_DEFAULTS, type HomeStyleOption } from '../../ade-bindings/app-config'

export const DEFAULT_HOME_STYLE: HomeStyleOption = { id: 'focused', label: 'Focused', description: 'What needs you first, as a list.' }

export function siteHomeStyles(config: { homeStyles?: ReadonlyArray<HomeStyleOption> } = APP_ADE_DEFAULTS): readonly HomeStyleOption[] {
  const list = (config.homeStyles ?? []).filter((o, i, all) => /^[a-z][a-z0-9-]{0,31}$/.test(o.id) && all.findIndex((x) => x.id === o.id) === i)
  return list.length ? list : [DEFAULT_HOME_STYLE]
}
