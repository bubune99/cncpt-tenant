/**
 * Home screen styles (owner decision 2026-11-20, planner 1b8076d7): a person picks a whole home style and
 * adjusts its sections; new staff start on one at random and may switch any time; a style is judged by
 * whether people keep it. Run: node_modules/.bin/tsx src/lib/ade/home/home-style.assert.ts
 */
import assert from 'node:assert/strict'
import { homeStyleFor, keptReport, parseHomeStyle, switchHomeStyle, type HomeStyleRecord } from './home-style'

const STYLES = ['studio', 'focused'] as const
const t0 = new Date('2026-11-20T12:00:00Z')
const day = 86_400_000
let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log('ok', n, '-', name) }

ok('a site with one style offers no choice and stores nothing', () => {
  const r = homeStyleFor(null, ['focused'], () => 0.9, t0)
  assert.equal(r.style, 'focused'); assert.equal(r.record, null); assert.equal(r.offered, false)
})
ok('no record: a random style, kept as assigned, never flips by itself', () => {
  const a = homeStyleFor(null, STYLES, () => 0.1, t0)
  const b = homeStyleFor(null, STYLES, () => 0.9, t0)
  assert.equal(a.style, 'studio'); assert.equal(b.style, 'focused')
  assert.deepEqual(a.record, { style: 'studio', assigned: 'studio', assignedAt: t0.toISOString(), switches: [] })
  assert.equal(a.isNew, true)
  const again = homeStyleFor(a.record, STYLES, () => 0.9, new Date(t0.getTime() + day))
  assert.equal(again.style, 'studio'); assert.equal(again.isNew, false)
})
ok('a stored style the site no longer offers falls back to the first, keeping the record', () => {
  const r = homeStyleFor({ style: 'gone', assigned: 'gone', assignedAt: t0.toISOString(), switches: [] }, STYLES, () => 0.9, t0)
  assert.equal(r.style, 'studio'); assert.equal(r.record?.assigned, 'gone')
})
ok('switching records from, to and when; the same style is no switch; unknown is refused', () => {
  const a = homeStyleFor(null, STYLES, () => 0.1, t0).record!
  const s = switchHomeStyle(a, 'focused', STYLES, new Date(t0.getTime() + day))
  assert.equal(s.style, 'focused')
  assert.deepEqual(s.switches, [{ from: 'studio', to: 'focused', at: new Date(t0.getTime() + day).toISOString() }])
  assert.equal(a.switches.length, 0, 'the old record is not changed')
  assert.equal(switchHomeStyle(s, 'focused', STYLES, t0), s)
  assert.throws(() => switchHomeStyle(s, 'bento', STYLES, t0))
})
ok('a switch before any record starts one, assigned to what was showing', () => {
  const s = switchHomeStyle(null, 'focused', STYLES, t0, 'studio')
  assert.equal(s.assigned, 'studio'); assert.equal(s.style, 'focused'); assert.equal(s.switches.length, 1)
})
ok('switches are capped at the last 50', () => {
  let r: HomeStyleRecord = homeStyleFor(null, STYLES, () => 0.1, t0).record!
  for (let i = 0; i < 60; i++) r = switchHomeStyle(r, r.style === 'studio' ? 'focused' : 'studio', STYLES, new Date(t0.getTime() + i * 1000))
  assert.equal(r.switches.length, 50)
})
ok('parse refuses junk and keeps only well-formed switches', () => {
  assert.equal(parseHomeStyle(null), null); assert.equal(parseHomeStyle({ style: 3 }), null)
  const p = parseHomeStyle({ style: 'studio', assigned: 'studio', assignedAt: t0.toISOString(), switches: [{ from: 'a', to: 'b', at: 'x' }, 7, { from: 'studio', to: 'focused', at: t0.toISOString() }] })
  assert.equal(p?.switches.length, 1)
})
ok('kept report: per assigned style, started, still on it at 7 and 30 days, switched away', () => {
  const at = (d: number) => new Date(t0.getTime() + d * day).toISOString()
  const recs: HomeStyleRecord[] = [
    { style: 'studio', assigned: 'studio', assignedAt: at(0), switches: [] },                                   // kept 7 and 30
    { style: 'focused', assigned: 'studio', assignedAt: at(0), switches: [{ from: 'studio', to: 'focused', at: at(3) }] }, // left before 7
    { style: 'focused', assigned: 'focused', assignedAt: at(0), switches: [{ from: 'focused', to: 'studio', at: at(10) }, { from: 'studio', to: 'focused', at: at(12) }] }, // on focused at 7 and 30
    { style: 'focused', assigned: 'focused', assignedAt: at(25), switches: [] },                                // too new for 30 days
  ]
  const r = keptReport(recs, STYLES, new Date(t0.getTime() + 40 * day))
  assert.deepEqual(r.find((x) => x.style === 'studio'), { style: 'studio', started: 2, due7: 2, kept7: 1, due30: 2, kept30: 1, switchedAway: 1, onNow: 1 })
  assert.deepEqual(r.find((x) => x.style === 'focused'), { style: 'focused', started: 2, due7: 2, kept7: 2, due30: 1, kept30: 1, switchedAway: 1, onNow: 3 })
})

// The site's list (lib/ade/home/site-styles).
import { siteHomeStyles } from './site-styles'
ok('a site naming no styles has the one built-in home; bad and repeated ids are dropped', () => {
  assert.deepEqual(siteHomeStyles({}).map((o) => o.id), ['focused'])
  assert.deepEqual(siteHomeStyles({ homeStyles: [{ id: 'studio', label: 'S', description: '' }, { id: 'Bad Id', label: 'x', description: '' }, { id: 'studio', label: 'again', description: '' }, { id: 'focused', label: 'F', description: '' }] }).map((o) => o.id), ['studio', 'focused'])
})
console.log(`${n} checks passed`)
