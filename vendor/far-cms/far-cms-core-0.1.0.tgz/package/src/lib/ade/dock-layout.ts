/**
 * Dock layouts — where each workspace tool panel lives, remembered per user
 * and per screen. Pure; asserted by dock-layout.assert.ts.
 */

/**
 * Where the editing tools (Sections · Outline) sit — owner: drag them to
 *   tabs  — the top of the assistant column, toggling with Chat
 *   split — under the chat (the column splits)
 *   tray  — a bottom tray under the page/block editor
 */
export type DockZone = 'tabs' | 'split' | 'tray'

export interface DockLayout {
  agentTools: DockZone
  add: 'agent' | 'tray'
  style: 'agent' | 'strip'
  /**
   * Owner 2026-10-19 — each tool moves on its own: where Blocks, Templates, Outline and Style each sit. Only present once someone moves one tab by itself; otherwise every tool follows
   * agentTools (the group). 'column' = the assistant column (tabs or under the chat, per agentTools).
   */
  place?: Partial<Record<ToolSlotId, ToolZone>>
}

/** The movable tools, one per tab (lib/ade/ui/tray-tabs ToolSlot). */
export type ToolSlotId = 'blocks' | 'add' | 'outline' | 'style'
/** Where one tool sits: the assistant column, the tray under the page, or a column right of the page. */
export type ToolZone = 'column' | 'tray' | 'right'
export const TOOL_SLOT_IDS: readonly ToolSlotId[] = ['blocks', 'add', 'outline', 'style']
const TOOL_ZONES: readonly ToolZone[] = ['column', 'tray', 'right']

/** The group's zone: the column unless the whole group went under the page. */
const groupZone = (d: DockLayout): ToolZone => (d.agentTools === 'tray' ? 'tray' : 'column')

/** Where this tool sits now. */
export function zoneOfTool(d: DockLayout, slot: ToolSlotId): ToolZone {
  return d.place?.[slot] ?? groupZone(d)
}

/** The tools in a zone, in tab order (only those the screen offers, when given). */
export function toolsIn(d: DockLayout, zone: ToolZone, offered: readonly string[] = TOOL_SLOT_IDS): ToolSlotId[] {
  return TOOL_SLOT_IDS.filter((s) => offered.includes(s) && zoneOfTool(d, s) === zone)
}

/** Drag one tab by its name: just that tool moves. Into the column, the column keeps its tabs/split look. */
export function moveTool(d: DockLayout, slot: ToolSlotId, zone: ToolZone, columnAs?: 'tabs' | 'split'): DockLayout {
  const place = Object.fromEntries(TOOL_SLOT_IDS.map((s) => [s, zoneOfTool(d, s)])) as Record<ToolSlotId, ToolZone>
  place[slot] = zone
  const agentTools = zone === 'column' ? columnAs ?? (d.agentTools === 'tray' ? 'split' : d.agentTools) : d.agentTools
  return tidy({ ...d, agentTools, place })
}

/** Drag a zone's grip: every tool there moves together. */
export function moveGroup(d: DockLayout, from: ToolZone, to: ToolZone, columnAs?: 'tabs' | 'split'): DockLayout {
  let next = d
  for (const s of TOOL_SLOT_IDS) if (zoneOfTool(d, s) === from) next = moveTool(next, s, to, columnAs)
  if (to === 'column' && columnAs) next = { ...next, agentTools: columnAs }
  return tidy(next)
}

/** Back to one group (no per-tool places) when every tool sits with the group anyway. */
function tidy(d: DockLayout): DockLayout {
  const place = d.place ?? {}
  const zones = TOOL_SLOT_IDS.map((s) => place[s] ?? groupZone(d))
  if (zones.every((z) => z === 'column') && d.agentTools !== 'tray') return withoutPlace(d)
  if (zones.every((z) => z === 'tray')) return withoutPlace({ ...d, agentTools: 'tray' })
  return { ...d, place: Object.fromEntries(TOOL_SLOT_IDS.map((s, i) => [s, zones[i]])) as Record<ToolSlotId, ToolZone> }
}
function withoutPlace(d: DockLayout): DockLayout {
  const { place: _drop, ...rest } = d
  void _drop
  return rest
}

/** Owner, 2026-10-09: tools as a split below the chat; Style in the column. */
export const DEFAULT_DOCK: DockLayout = { agentTools: 'split', add: 'agent', style: 'agent' }

/** Screens of the same kind share a layout: ids in the path become '*'. */
export function screenKey(pathname: string): string {
  return (
    pathname
      .split('?')[0]
      .split('/')
      .map((seg) => (/^[0-9]+$|^c[a-z0-9]{20,}$|^[0-9a-f-]{32,36}$/i.test(seg) ? '*' : seg))
      .join('/')
      .replace(/\/+$/, '') || '/'
  )
}

/** Validate a stored layout; unknown or partial values fall back to defaults. */
export function normalizeDock(raw: unknown): DockLayout {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  return {
    agentTools: o.agentTools === 'tabs' || o.agentTools === 'tray' ? o.agentTools : 'split',
    // The bottom section tray was retired (owner): sections always dock in the column.
    add: 'agent',
    style: o.style === 'strip' ? 'strip' : 'agent',
    ...placeFrom(o.place),
  }
}

/** A stored per-tool place, kept only when it is well formed. */
function placeFrom(raw: unknown): { place?: Partial<Record<ToolSlotId, ToolZone>> } {
  if (!raw || typeof raw !== 'object') return {}
  const out: Partial<Record<ToolSlotId, ToolZone>> = {}
  for (const s of TOOL_SLOT_IDS) {
    const z = (raw as Record<string, unknown>)[s]
    if (typeof z === 'string' && (TOOL_ZONES as readonly string[]).includes(z)) out[s] = z as ToolZone
  }
  return Object.keys(out).length ? { place: out } : {}
}

const MAX_SCREENS = 50

/** Merge one screen's layout into the stored map (bounded). */
export function withDock(map: unknown, key: string, layout: unknown): Record<string, DockLayout> {
  const base = (map && typeof map === 'object' ? map : {}) as Record<string, unknown>
  const next: Record<string, DockLayout> = {}
  for (const [k, v] of Object.entries(base)) if (k !== key) next[k] = normalizeDock(v)
  next[key] = normalizeDock(layout)
  const keys = Object.keys(next)
  for (const k of keys.slice(0, Math.max(0, keys.length - MAX_SCREENS))) delete next[k]
  return next
}

/** Narrow screens default the tools to tabs at the top of the column (owner); wide ones to the split. */
export function defaultDockFor(viewportWidth: number): DockLayout {
  return viewportWidth < 1280 ? { ...DEFAULT_DOCK, agentTools: 'tabs' } : DEFAULT_DOCK
}
