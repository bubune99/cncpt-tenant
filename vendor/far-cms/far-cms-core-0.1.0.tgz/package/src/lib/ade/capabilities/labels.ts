/**
 * ADE capability labels — pure, no app imports.
 *
 * Every registered capability (agent tool, workflow, block action) carries two
 * labels that decide where it may run and how much ceremony it needs:
 *
 *   exposure — who can reach it
 *     internal      server-side only (workflows, jobs); never offered to a model
 *     in-app        the signed-in admin's agent (chat)
 *     external-mcp  also external AI clients over the MCP endpoint
 *
 *   effect — what it does to persistent state
 *     read          nothing
 *     draft         a content edit that can be held as a ChangeSet for review
 *     write         a reversible change applied directly
 *     irreversible  can't be undone (delete, refund, cancel) — explicit approval
 *
 * A composite (a workflow, a button wired to several steps) takes the MOST
 * restrictive label of its steps on both axes.
 */

export const EXPOSURES = ['external-mcp', 'in-app', 'internal'] as const
export type Exposure = (typeof EXPOSURES)[number]

export const EFFECTS = ['read', 'draft', 'write', 'irreversible'] as const
export type Effect = (typeof EFFECTS)[number]

export interface CapabilityLabels {
  exposure: Exposure
  effect: Effect
}

/** Surfaces a capability can be invoked from. */
export type Surface = 'mcp' | 'chat' | 'server'

/**
 * Restrictiveness ranks: higher = more restrictive. Exposure narrows the
 * audience (internal reaches fewest callers); effect raises the ceremony.
 */
const EXPOSURE_RANK: Record<Exposure, number> = { 'external-mcp': 0, 'in-app': 1, internal: 2 }
const EFFECT_RANK: Record<Effect, number> = { read: 0, draft: 1, write: 2, irreversible: 3 }

/** Labels used when nothing is known about a capability — fail closed. */
export const UNKNOWN_LABELS: CapabilityLabels = { exposure: 'internal', effect: 'irreversible' }

export function isExposure(v: unknown): v is Exposure {
  return typeof v === 'string' && (EXPOSURES as readonly string[]).includes(v)
}

export function isEffect(v: unknown): v is Effect {
  return typeof v === 'string' && (EFFECTS as readonly string[]).includes(v)
}

export function moreRestrictiveExposure(a: Exposure, b: Exposure): Exposure {
  return EXPOSURE_RANK[a] >= EXPOSURE_RANK[b] ? a : b
}

export function moreRestrictiveEffect(a: Effect, b: Effect): Effect {
  return EFFECT_RANK[a] >= EFFECT_RANK[b] ? a : b
}

/**
 * Labels of a composite: the most restrictive exposure and effect across its
 * steps. An empty composite does nothing and is reachable wherever its
 * container is, so it is the least restrictive pair. A step whose labels are
 * unknown (undefined) poisons the composite to UNKNOWN_LABELS.
 */
export function compositeLabels(steps: ReadonlyArray<CapabilityLabels | undefined>): CapabilityLabels {
  let exposure: Exposure = 'external-mcp'
  let effect: Effect = 'read'
  for (const step of steps) {
    const s = step ?? UNKNOWN_LABELS
    exposure = moreRestrictiveExposure(exposure, s.exposure)
    effect = moreRestrictiveEffect(effect, s.effect)
  }
  return { exposure, effect }
}

/** Whether a capability with this exposure may be offered on a surface. */
export function exposedOn(exposure: Exposure, surface: Surface): boolean {
  switch (surface) {
    case 'mcp':
      return exposure === 'external-mcp'
    case 'chat':
      return exposure === 'external-mcp' || exposure === 'in-app'
    case 'server':
      return true
  }
}
