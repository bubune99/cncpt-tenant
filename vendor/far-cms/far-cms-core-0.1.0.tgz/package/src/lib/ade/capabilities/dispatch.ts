/**
 * ADE dispatcher decision — pure, asserted by capabilities.assert.ts.
 *
 * Every surface (chat agent, MCP endpoint, server workflows) asks this ONE
 * function what to do with a capability call before running it. The caller
 * supplies the facts (labels, RBAC result, budget, policy); this decides:
 *
 *   deny     — not exposed here / no permission / over budget / read-only /
 *              irreversible with no way to get explicit approval
 *   draft    — hold it as a ChangeSet item for human review instead of writing
 *   execute  — run it, with or without an explicit approval prompt
 */

import { exposedOn, type CapabilityLabels, type Surface } from './labels'

/** How agent content edits land: held for review (draft) or applied (direct). */
export type ChangeMode = 'draft' | 'direct'

/** Mirrors the governance execution mode (readonly | ask | auto). */
export type ExecutionMode = 'readonly' | 'ask' | 'auto'

export interface DispatchFacts {
  labels: CapabilityLabels
  surface: Surface
  changeMode: ChangeMode
  executionMode: ExecutionMode
  /** RBAC (and key scope, on MCP) allowed this call. */
  permitted: boolean
  /** Budget left for this caller. */
  budgetOk: boolean
  /** A drafter exists that can turn this call into a ChangeSet item. */
  canDraft: boolean
  /** Admin listed this capability in alwaysConfirm, or it is flagged high-risk. */
  forceConfirm?: boolean
  /** Server surface only: a human approved this exact call out of band. */
  approved?: boolean
}

export type DenyReason =
  | 'not-exposed'
  | 'permission'
  | 'budget'
  | 'readonly'
  | 'needs-approval'

export type DispatchDecision =
  | { kind: 'deny'; reason: DenyReason }
  | { kind: 'draft' }
  | { kind: 'execute'; needsApproval: boolean }

/** Surfaces that can show a human an approve/deny prompt mid-call. */
function canPrompt(surface: Surface): boolean {
  return surface === 'chat'
}

export function decideDispatch(f: DispatchFacts): DispatchDecision {
  const { effect, exposure } = f.labels

  if (!exposedOn(exposure, f.surface)) return { kind: 'deny', reason: 'not-exposed' }
  if (!f.permitted) return { kind: 'deny', reason: 'permission' }
  if (!f.budgetOk) return { kind: 'deny', reason: 'budget' }

  if (effect === 'read') return { kind: 'execute', needsApproval: false }

  if (f.executionMode === 'readonly') return { kind: 'deny', reason: 'readonly' }

  if (effect === 'irreversible') {
    if (canPrompt(f.surface)) return { kind: 'execute', needsApproval: true }
    if (f.surface === 'server' && f.approved) return { kind: 'execute', needsApproval: false }
    return { kind: 'deny', reason: 'needs-approval' }
  }

  // Draft mode: the review queue IS the approval, so no prompt.
  if (effect === 'draft' && f.changeMode === 'draft' && f.canDraft) return { kind: 'draft' }

  // write (or a draftable edit applied directly)
  const wantsApproval = f.executionMode === 'ask' || Boolean(f.forceConfirm)
  if (!wantsApproval) return { kind: 'execute', needsApproval: false }
  if (canPrompt(f.surface)) return { kind: 'execute', needsApproval: true }
  // MCP has no prompt; a write-scoped key is the standing approval for
  // reversible writes (matches the pre-ADE MCP behaviour). Server workflows
  // need an explicit approval.
  if (f.surface === 'mcp') return { kind: 'execute', needsApproval: false }
  return f.approved ? { kind: 'execute', needsApproval: false } : { kind: 'deny', reason: 'needs-approval' }
}

/** Human-readable refusal for a deny decision (shown to the model / client). */
export function denyMessage(reason: DenyReason, capability: string): string {
  switch (reason) {
    case 'not-exposed':
      return `'${capability}' is not available here.`
    case 'permission':
      return `Permission denied: your account can't run '${capability}'.`
    case 'budget':
      return `'${capability}' was refused: the usage budget for this account is used up.`
    case 'readonly':
      return `'${capability}' changes data, and the assistant is in read-only mode.`
    case 'needs-approval':
      return `'${capability}' can't be undone and needs explicit approval in the admin.`
  }
}
