/**
 * External (MCP) tool list — GENERATED from the capability registry, so a
 * capability labelled `internal` or `in-app` can never be published to an
 * external client by someone forgetting to update a hand-written list.
 */

import type { CapabilityLabels } from './labels'

/**
 * Names of capabilities that may be offered over MCP: exposure
 * `external-mcp`, and not `irreversible` (MCP has no approval prompt).
 * Sorted for a stable tool list.
 */
export function externalToolNames(registry: Readonly<Record<string, CapabilityLabels>>): string[] {
  return Object.entries(registry)
    .filter(([, l]) => l.exposure === 'external-mcp' && l.effect !== 'irreversible')
    .map(([name]) => name)
    .sort()
}
