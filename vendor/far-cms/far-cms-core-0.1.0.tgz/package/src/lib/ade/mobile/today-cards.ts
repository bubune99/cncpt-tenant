/**
 * Today on a phone: "Needs you" cards. Any lane (or app) registers a card
 * source; Today loads them all, keeps what came back, and orders them.
 * Pure registry + ordering; asserted by today-cards.assert.ts.
 */

export type CardTone = 'urgent' | 'attention' | 'info'

export interface TodayAction {
  label: string
  /** Open a screen… */
  href?: string
  /** …or ask the assistant this… */
  ask?: string
  /** …or queue an offline action (lib/ade/offline/queue: a registered type). */
  queue?: { type: string; payload: unknown; label: string }
  primary?: boolean
}

export interface TodayCard {
  id: string
  title: string
  detail?: string
  tone?: CardTone
  /** A picture on the card (a product photo, the page's hero). */
  media?: { src: string; alt: string }
  actions: TodayAction[]
}

export interface TodayCardContext {
  /** Permission check for the person on the phone. */
  can: (permission: string) => boolean
  roles: readonly string[]
  /** Now (injected so ordering and "waited 3 days" text are testable). */
  now: Date
}

export interface TodayCardSource {
  id: string
  /** Lower comes first among sources (orders 10, approvals 20, …). */
  priority: number
  /** Only for people with this permission… */
  permission?: string
  /** …and/or these roles (role-based home: a production helper sees the print queue). */
  roles?: readonly string[]
  load: (ctx: TodayCardContext) => Promise<TodayCard[]>
}

const sources = new Map<string, TodayCardSource>()

export function registerTodayCard(source: TodayCardSource): void {
  sources.set(source.id, source)
}

/** Sources this person gets (permission / roles), by priority. */
export function todayCardSources(ctx?: Pick<TodayCardContext, 'can' | 'roles'>): TodayCardSource[] {
  return [...sources.values()]
    .filter((s) => !ctx || ((!s.permission || ctx.can(s.permission)) && (!s.roles?.length || s.roles.some((r) => ctx.roles.includes(r)))))
    .sort((a, b) => a.priority - b.priority || a.id.localeCompare(b.id))
}

const TONE_RANK: Record<CardTone, number> = { urgent: 0, attention: 1, info: 2 }

/**
 * Every source's cards in one list: urgent first, then by source priority,
 * then as the source gave them; at most `max`. A source that failed is
 * reported, not fatal.
 */
export function orderCards(results: ReadonlyArray<{ source: TodayCardSource; cards?: readonly TodayCard[]; error?: unknown }>, max = 12): { cards: TodayCard[]; failed: string[] } {
  const rows = results.flatMap((r, si) => (r.cards ?? []).map((c, ci) => ({ c, si, ci, p: r.source.priority })))
  rows.sort((a, b) => TONE_RANK[a.c.tone ?? 'info'] - TONE_RANK[b.c.tone ?? 'info'] || a.p - b.p || a.si - b.si || a.ci - b.ci)
  const seen = new Set<string>()
  const cards: TodayCard[] = []
  for (const r of rows) {
    if (seen.has(r.c.id) || cards.length >= max) continue
    seen.add(r.c.id)
    cards.push(r.c)
  }
  return { cards, failed: results.filter((r) => r.error !== undefined).map((r) => r.source.id) }
}

/** "Good morning, Bubune." — by the hour on the phone's clock. */
export function greeting(now: Date, firstName?: string | null): string {
  const h = now.getHours()
  const part = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'
  return firstName ? `${part}, ${firstName}.` : `${part}.`
}

/** "3 things need you." / "1 thing needs you." / "Nothing needs you right now." */
export function needsYouLine(n: number): string {
  if (n <= 0) return 'Nothing needs you right now.'
  return n === 1 ? '1 thing needs you.' : `${n} things need you.`
}

// ── The numbers at the top of Today ("4 to approve", "26 visitors · 30d") ──

export interface TodayStat {
  id: string
  value: number
  /** Under the number: "to approve", "visitors · 30d". */
  label: string
  /** Its line in the briefing ("26 people visited the site in the last 30 days."); none = tile only. */
  sentence?: string
  /** This is the count of changes waiting for the person's OK (the greeting says it). */
  needsOk?: boolean
}

export interface TodayStatSource {
  id: string
  /** Lower comes first (tiles left to right). */
  priority: number
  permission?: string
  roles?: readonly string[]
  /** null: no tile (couldn't be read — never a made-up number). */
  load: (ctx: TodayCardContext) => Promise<TodayStat | null>
}

const statSources = new Map<string, TodayStatSource>()

export function registerTodayStat(source: TodayStatSource): void {
  statSources.set(source.id, source)
}

/** Stat sources this person gets, by priority. */
export function todayStatSources(ctx?: Pick<TodayCardContext, 'can' | 'roles'>): TodayStatSource[] {
  return [...statSources.values()]
    .filter((s) => !ctx || ((!s.permission || ctx.can(s.permission)) && (!s.roles?.length || s.roles.some((r) => ctx.roles.includes(r)))))
    .sort((a, b) => a.priority - b.priority || a.id.localeCompare(b.id))
}

/**
 * "Good afternoon, Bubune. 4 changes need your OK." — the count from the
 * stat marked needsOk; unknown (not loaded / not allowed) says nothing about it.
 */
export function todayHeadline(now: Date, firstName: string | null, stats: readonly TodayStat[]): string {
  const { hello, need } = todayHeadlineParts(now, firstName, stats)
  return need ? `${hello} ${need}` : hello
}

/** The headline's two sentences (Today shows the second on its own line, as in the mock-up). */
export function todayHeadlineParts(now: Date, firstName: string | null, stats: readonly TodayStat[]): { hello: string; need: string | null } {
  const hello = greeting(now, firstName)
  const ok = stats.find((s) => s.needsOk)
  if (!ok) return { hello, need: null }
  if (ok.value === 0) return { hello, need: 'Nothing needs your OK.' }
  return { hello, need: `${ok.value} ${ok.value === 1 ? 'change needs' : 'changes need'} your OK.` }
}

/** The briefing line: each stat's sentence, in tile order. */
export function todaySummary(stats: readonly TodayStat[]): string {
  return stats
    .map((s) => s.sentence?.trim())
    .filter(Boolean)
    .join(' ')
}

/** Header line under the brand: "Today · Sun Oct 11". */
export function todayDateLabel(now: Date, locale = 'en-US'): string {
  const d = now.toLocaleDateString(locale, { weekday: 'short', month: 'short', day: 'numeric' }).replace(/,/g, '')
  return `Today · ${d}`
}
