/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/inbox.assert.ts
 */
import assert from 'node:assert/strict'
import { groupInbox, inboxSummary, inboxTabs, messageKind, replyAssistAsk, replyProblem, replySubject, segmentFromParam, segmentItems, type InboxItem } from './inbox'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const now = new Date(2026, 9, 11, 15, 0) // Sun 11 Oct 2026, 15:00 local
const at = (d: number, h = 9) => new Date(2026, 9, d, h, 0).toISOString()
const item = (o: Partial<InboxItem>): InboxItem => ({
  id: 'x', segment: 'customers', sourceLabel: 'Contact form', from: 'Ama', subject: 'Hello', preview: 'Hi', at: at(11), unread: true, needsReply: false, canReply: true, ...o,
})

const items = [
  item({ id: 'a', at: at(11, 9), needsReply: true }),
  item({ id: 'b', at: at(11, 14) }),
  item({ id: 'c', at: at(10, 20) }),
  item({ id: 'd', at: at(6) }),
  item({ id: 'e', at: at(1) }),
  item({ id: 'm', segment: 'email', sourceLabel: 'Gmail', at: at(11, 8), needsReply: true }),
]

check('grouped Today / Yesterday / This week / Earlier, newest first, empty groups dropped', () => {
  const g = groupInbox(segmentItems(items, 'customers'), now)
  assert.deepEqual(g.map((x) => [x.label, x.items.map((i) => i.id)]), [['Today', ['b', 'a']], ['Yesterday', ['c']], ['This week', ['d']], ['Earlier', ['e']]])
  assert.deepEqual(groupInbox([], now), [])
  assert.deepEqual(groupInbox([item({ id: 'z', at: at(4) })], now).map((x) => x.label), ['Earlier'], '7+ days back is Earlier')
})

check('segments keep customers and the mailbox apart', () => {
  assert.deepEqual(segmentItems(items, 'email').map((i) => i.id), ['m'])
  assert.equal(segmentItems(items, 'customers').length, 5)
})

check('the email tab only exists when the app enables it; the site’s own tab is "Form replies"', () => {
  assert.deepEqual(inboxTabs(items, false).map((t) => t.id), ['customers'])
  const t = inboxTabs(items, true)
  assert.deepEqual(t.map((x) => [x.id, x.label, x.count]), [['customers', 'Form replies', 5], ['email', 'My email', 1]])
})

check('the assistant line names what is new and what it drafted (mock 4)', () => {
  const two = [item({ id: 'v', sourceLabel: 'Volunteer With Us' }), item({ id: 'c', sourceLabel: 'Contact Us' })]
  assert.equal(inboxSummary(two, 2), '2 new replies. One volunteer, one general question. I drafted both answers.')
  assert.equal(inboxSummary(two, 0), '2 new replies. One volunteer, one general question.')
  assert.equal(inboxSummary(two, 1), '2 new replies. One volunteer, one general question. I drafted one of the answers.')
  assert.equal(inboxSummary([item({ sourceLabel: 'Volunteer With Us' })], 1), '1 new reply. One volunteer. I drafted the answer.')
  assert.equal(inboxSummary([item({ id: 'a', sourceLabel: 'Volunteer' }), item({ id: 'b', sourceLabel: 'Volunteer' }), item({ id: 'c', sourceLabel: 'Donate' })], 3), '3 new replies. Two volunteers, one donation question. I drafted all three answers.')
  assert.equal(inboxSummary([item({ unread: false, needsReply: true })]), 'No new replies. One still waits for an answer.')
  assert.equal(inboxSummary([]), 'Nothing new. Everyone has an answer.')
  assert.equal(messageKind('Newsletter sign-up').one, 'sign-up')
  assert.equal(messageKind('Something else').one, 'message')
})

check('C-17: drafting with the assistant passes a reference, never the sender, subject or words', () => {
  const it = item({ id: 'submission:f1:s1', from: 'Ama ama@x.org', subject: 'Volunteer', preview: 'Call me at kofi@x.org' })
  const all = JSON.stringify(replyAssistAsk(it))
  assert.ok(all.includes('inbox:submission:f1:s1'))
  for (const leak of ['@', 'Ama', 'Volunteer', 'Call me']) assert.ok(!all.includes(leak), `no ${leak}`)
})

check('replies: Re: once; Send needs an address and words', () => {
  assert.equal(replySubject('Club kit sizes'), 'Re: Club kit sizes')
  assert.equal(replySubject('RE: Club kit sizes'), 'RE: Club kit sizes')
  assert.equal(replySubject('  '), 'Re: Your message')
  assert.equal(replyProblem({ to: 'ama@example.org', body: 'Thanks!' }), null)
  assert.match(replyProblem({ to: 'not an address', body: 'Thanks' })!, /no email address/)
  assert.match(replyProblem({ to: 'ama@example.org', body: ' ' })!, /Write a reply/)
})

check('a link opens on My email only when the app has it on', () => {
  assert.equal(segmentFromParam('email', true), 'email')
  assert.equal(segmentFromParam('email', false), 'customers')
  assert.equal(segmentFromParam('customers', true), 'customers')
  assert.equal(segmentFromParam(undefined, true), 'customers')
  assert.equal(segmentFromParam('junk', true), 'customers')
})

console.log(`\n${n} checks passed`)
