/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/mobile.assert.ts
 */
import assert from 'node:assert/strict'
import { continueHref, pickupHeadline, type Handoff } from './handoff'
import { fitSize, jpegName, missingShots, needsConversion, nextShot, orderedPhotos, type Shot } from './photos'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const h = (over: Partial<Handoff>): Handoff => ({ id: 'h', kind: 'initiative', title: 'T', device: 'phone', changeSetId: 'cs', conversationId: 'c1', href: '/admin/records/initiative?draft=cs', status: 'open', createdAt: '2026-10-11T00:00:00Z', ...over })

check('pickup headline counts open phone handoffs only', () => {
  assert.equal(pickupHeadline([]), null)
  assert.equal(pickupHeadline([h({})]), 'You started 1 initiative on your phone')
  assert.equal(pickupHeadline([h({}), h({ id: 'b' }), h({ id: 'c', status: 'picked' })]), 'You started 2 initiatives on your phone')
  assert.equal(pickupHeadline([h({}), h({ id: 'b', kind: 'listing' })]), 'You started 2 things on your phone')
})

check('continue opens the same draft with the same conversation', () => {
  assert.equal(continueHref(h({})), '/admin/records/initiative?draft=cs&thread=c1')
  assert.equal(continueHref(h({ href: '/x', conversationId: null })), '/x')
})

check('HEIC is converted; sizes fit without upscaling', () => {
  assert.equal(needsConversion({ name: 'IMG_1.HEIC', type: '' }), true)
  assert.equal(needsConversion({ name: 'a.jpg', type: 'image/heif' }), true)
  assert.equal(needsConversion({ name: 'a.jpg', type: 'image/jpeg' }), false)
  assert.deepEqual(fitSize(4032, 3024), { width: 2400, height: 1800 })
  assert.deepEqual(fitSize(800, 600), { width: 800, height: 600 })
  assert.equal(jpegName('IMG_1234.HEIC'), 'IMG_1234.jpg')
})

check('shot checklist: next shot, missing required, cover-first order', () => {
  const shots: Shot[] = [{ id: 'cover', label: 'Cover photo', required: true }, { id: 'people', label: 'People' }, { id: 'place', label: 'The place' }]
  assert.equal(nextShot(shots, { taken: {} })!.id, 'cover')
  assert.equal(nextShot(shots, { taken: { cover: ['a'] } })!.id, 'people')
  assert.deepEqual(missingShots(shots, { taken: { people: ['p'] } }).map((s) => s.id), ['cover'])
  assert.deepEqual(orderedPhotos(shots, { taken: { place: ['z'], cover: ['a'], extra: ['q'] } }), ['a', 'z', 'q'])
})

console.log(`\n${n} checks passed`)
