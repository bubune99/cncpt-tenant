/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/page-edit.assert.ts
 */
import assert from 'node:assert/strict'
import { actionsFor, agentContext, hiddenOnPhoneBlocks, draftTarget, isHiddenOnPhone, moveAmongSiblings, pathTo, scopeNotice, setHiddenOnPhone, setPhoto, setText, type PhoneBlock } from './page-edit'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const page: PhoneBlock[] = [
  { id: 'hero', tag: 'section', children: [
    { id: 'h1', tag: 'h1', textContent: 'The people behind every print' },
    { id: 'p1', tag: 'p', textContent: 'Small crew, big press days.' },
    { id: 'img1', tag: 'img', attrs: { src: '/a.jpg', alt: 'Team' } },
  ] },
  { id: 'band', tag: 'section', background: { url: '/bg.jpg' }, responsive: { hidden: { desktop: true } }, children: [{ id: 'cta', tag: 'a', textContent: 'Donate', attrs: { href: '/give' } }] },
  { id: 'locked', tag: 'section', locked: true, children: [{ id: 'lt', tag: 'p', textContent: 'Fixed' }] },
]
const P = { kind: 'page', id: 'pg1' } as const
const freeze = JSON.stringify(page)

check('actions: text, photo, move among siblings, hide — by block kind and position', () => {
  assert.deepEqual(actionsFor(page, 'h1', P), ['text', 'move-down', 'hide'])
  assert.deepEqual(actionsFor(page, 'p1', P), ['text', 'move-up', 'move-down', 'hide'])
  assert.deepEqual(actionsFor(page, 'img1', P), ['photo', 'move-up', 'hide'])
  assert.deepEqual(actionsFor(page, 'band', P), ['photo', 'move-up', 'move-down', 'hide'])
  assert.deepEqual(actionsFor(page, 'cta', P), ['text', 'hide'])
  assert.deepEqual(actionsFor(page, 'lt', P), [], 'locked blocks offer nothing')
  assert.deepEqual(actionsFor(page, 'nope', P), [])
})

check('inside a shared section or the header/footer: only hide/show on phone', () => {
  assert.deepEqual(actionsFor(page, 'h1', { kind: 'partial', id: 'pt' }), ['hide'])
  assert.deepEqual(actionsFor(page, 'cta', { kind: 'layout', id: 'footer' }), ['hide'])
  assert.equal(draftTarget({ kind: 'layout', id: 'header' }), 'layout:header')
  assert.equal(draftTarget({ kind: 'partial', id: 'pt' }), 'partial:pt')
  assert.equal(draftTarget(P), 'page:pg1')
  assert.equal(scopeNotice(P), null)
  assert.match(scopeNotice({ kind: 'partial', id: 'pt' })!, /every page that uses it/)
  assert.match(scopeNotice({ kind: 'layout', id: 'footer' })!, /site footer.*every page/)
})

check('hide on phone writes only responsive.hidden.mobile; show removes it; other devices kept; input untouched', () => {
  const a = setHiddenOnPhone(page, 'p1', true)
  assert.equal(isHiddenOnPhone(pathTo(a, 'p1')!.at(-1)!), true)
  assert.deepEqual(pathTo(a, 'p1')!.at(-1)!.responsive, { hidden: { mobile: true } })
  const b = setHiddenOnPhone(a, 'p1', false)
  assert.equal(pathTo(b, 'p1')!.at(-1)!.responsive, undefined, 'no empty responsive left behind')
  const c = setHiddenOnPhone(page, 'band', true)
  assert.deepEqual(pathTo(c, 'band')!.at(-1)!.responsive, { hidden: { desktop: true, mobile: true } })
  assert.deepEqual(pathTo(setHiddenOnPhone(c, 'band', false), 'band')!.at(-1)!.responsive, { hidden: { desktop: true } })
  assert.equal(JSON.stringify(page), freeze)
})

check('move swaps with a sibling only; edges are refused; nesting kept', () => {
  const up = moveAmongSiblings(page, 'p1', 'up')!
  assert.deepEqual(up[0].children!.map((b) => b.id), ['p1', 'h1', 'img1'])
  assert.equal(moveAmongSiblings(page, 'h1', 'up'), null)
  assert.equal(moveAmongSiblings(page, 'img1', 'down'), null)
  assert.equal(moveAmongSiblings(page, 'cta', 'up'), null, 'an only child cannot move (never out of its section)')
  assert.deepEqual(moveAmongSiblings(page, 'hero', 'down')!.map((b) => b.id), ['band', 'hero', 'locked'])
  assert.equal(JSON.stringify(page), freeze)
})

check('text and photo edits', () => {
  assert.equal(pathTo(setText(page, 'h1', '  Our crew  ')!, 'h1')!.at(-1)!.textContent, 'Our crew')
  assert.equal(setText(page, 'h1', '   '), null)
  const img = pathTo(setPhoto(page, 'img1', '/b.jpg', 'New')!, 'img1')!.at(-1)!
  assert.deepEqual(img.attrs, { src: '/b.jpg', alt: 'New' })
  assert.equal(pathTo(setPhoto(page, 'band', 'https://x/y.jpg')!, 'band')!.at(-1)!.background!.url, 'https://x/y.jpg')
  assert.equal(setPhoto(page, 'img1', 'javascript:alert(1)'), null)
  assert.equal(JSON.stringify(page), freeze)
})

check('the assistant gets the block, its words and that it is a draft', () => {
  const c = agentContext(P, pathTo(page, 'p1')!.at(-1)!)
  assert.match(c, /page:pg1/)
  assert.match(c, /paragraph p1/)
  assert.match(c, /Small crew/)
  assert.match(c, /draft for review/)
})

check('hidden-on-phone blocks are listed (outermost only) so they can be shown again', () => {
  assert.deepEqual(hiddenOnPhoneBlocks(page), [])
  const h = setHiddenOnPhone(setHiddenOnPhone(page, 'p1', true), 'hero', true)
  assert.deepEqual(hiddenOnPhoneBlocks(h), [{ id: 'hero', name: 'Section' }])
  assert.deepEqual(hiddenOnPhoneBlocks(setHiddenOnPhone(page, 'p1', true)), [{ id: 'p1', name: 'Paragraph: “Small crew, big press days.”' }])
})

console.log(`\n${n} checks passed`)
