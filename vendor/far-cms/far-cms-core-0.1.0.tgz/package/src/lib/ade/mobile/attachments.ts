/**
 * What came with a draft from the phone — its photos and voice notes —
 * kept beside the change set so Review and the desktop To-do show them
 * (pure; asserted by attachments.assert.ts). Stored as a change comment of
 * kind ATTACHMENTS_KIND whose body is this JSON.
 */

export const ATTACHMENTS_KIND = 'attachments'

export interface PhoneAttachments {
  photos: string[]
  voice: Array<{ url: string | null; seconds: number; transcript: string }>
}

const safeUrl = (u: unknown): string | null => (typeof u === 'string' && (/^https:\/\//i.test(u) || /^\/(?!\/)/.test(u)) && u.length <= 2000 ? u : null)

/** Clean and bound what the phone sent (links only to https or this site; at most 12 photos, 5 voice notes). */
export function cleanAttachments(raw: unknown): PhoneAttachments | null {
  if (!raw || typeof raw !== 'object') return null
  const o = raw as { photos?: unknown; voice?: unknown }
  const photos = Array.isArray(o.photos) ? o.photos.map(safeUrl).filter((u): u is string => !!u).slice(0, 12) : []
  const voice = Array.isArray(o.voice)
    ? o.voice
        .filter((v): v is Record<string, unknown> => !!v && typeof v === 'object')
        .map((v) => ({ url: safeUrl(v.url), seconds: typeof v.seconds === 'number' && v.seconds >= 0 ? Math.min(v.seconds, 3600) : 0, transcript: typeof v.transcript === 'string' ? v.transcript.trim().slice(0, 4000) : '' }))
        .filter((v) => v.url || v.transcript)
        .slice(0, 5)
    : []
  return photos.length || voice.length ? { photos, voice } : null
}

/** Read a stored attachments comment back (anything malformed → null). */
export function parseAttachments(body: string | null | undefined): PhoneAttachments | null {
  if (!body) return null
  try {
    return cleanAttachments(JSON.parse(body))
  } catch {
    return null
  }
}

/** "3 photos · voice note 0:24" */
export function attachmentsLine(a: PhoneAttachments): string {
  const parts: string[] = []
  if (a.photos.length) parts.push(`${a.photos.length} photo${a.photos.length === 1 ? '' : 's'}`)
  if (a.voice.length) parts.push(a.voice.length === 1 ? 'voice note' : `${a.voice.length} voice notes`)
  return parts.join(' · ')
}
