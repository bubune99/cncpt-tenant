/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/nav.assert.ts
 */
import assert from 'node:assert/strict'
import {
  activeTab,
  allowedScreens,
  cleanPins,
  isPhoneWidth,
  isPhoneViewport,
  PHONE_MEDIA_QUERY,
  manageGroups,
  mobileTabs,
  resolvePins,
  searchManage,
  togglePin,
  askOpensSheet,
  pullRefreshHere,
  tabHrefs,
  mobileActions,
  arrangeManage,
  SITE_ROW,
  registerManageCount,
  manageCounts,
  type MobileAction,
  type MobileScreen,
} from './nav'
import { keyboardInset } from './viewport'
import { greeting, needsYouLine, orderCards, registerTodayCard, registerTodayStat, todayCardSources, todayDateLabel, todayHeadline, todayHeadlineParts, todayStatSources, todaySummary, type TodayCardSource, type TodayStat } from './today-cards'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}

const HREFS = { today: '/admin/today', review: '/admin/todo', inbox: '/admin/forms', manage: '/admin/manage' }

// Phone width and tabs
eq([isPhoneWidth(390), isPhoneWidth(767), isPhoneWidth(768), isPhoneWidth(1440), isPhoneWidth(0)], [true, true, false, false, false])
eq([isPhoneViewport(390, 844), isPhoneViewport(844, 390), isPhoneViewport(932, 430)], [true, true, true], 'a phone on its side stays the phone admin')
eq([isPhoneViewport(1068, 772), isPhoneViewport(1440, 900), isPhoneViewport(1024, 768)], [false, false, false], 'laptops and tablets: the workspace')
eq([isPhoneViewport(600, 400), isPhoneViewport(0, 0)], [true, false])
eq(PHONE_MEDIA_QUERY, '(max-width: 767px), (max-height: 500px) and (orientation: landscape)')
eq(mobileTabs(HREFS).map((t) => t.id), ['today', 'review', 'ask', 'inbox', 'manage'], 'Ask in the centre')
eq(mobileTabs(HREFS)[2].href, null, 'no Ask route: Ask opens the sheet')
eq(mobileTabs({ ...HREFS, ask: '/admin/m/ask' })[2].href, '/admin/m/ask', 'the Ask tab can be the full-screen chat')
eq(activeTab('/admin/m/ask', { ...HREFS, ask: '/admin/m/ask' }), 'ask')
const WITH_ASK = { ...HREFS, ask: '/admin/m/ask' }
eq([askOpensSheet('/admin/settings', WITH_ASK), askOpensSheet('/admin/pages/abc/editor', WITH_ASK)], [true, true], 'on a CMS screen: the sheet over it')
eq([askOpensSheet('/admin/today', WITH_ASK), askOpensSheet('/admin/manage', WITH_ASK), askOpensSheet('/admin/todo', WITH_ASK)], [false, false, false], 'on a tab screen: the full-screen Ask')
eq(askOpensSheet('/admin/today', HREFS), true, 'no Ask route: always the sheet')
eq(activeTab('/admin/today', HREFS), 'today')
eq(activeTab('/admin/todo?tab=approvals', HREFS), 'review')
eq(activeTab('/admin/forms/abc/submissions', HREFS), 'inbox')
eq(activeTab('/admin/settings', HREFS), 'manage', 'other CMS screens belong to Manage')
eq(activeTab('/shop', HREFS), null)

// Manage hub
const MENU = [
  { name: 'Main', items: [{ name: 'Dashboard', href: '/admin', icon: 'LayoutDashboard' }, { name: 'To-do', href: '/admin/todo', icon: 'ListChecks' }] },
  { name: 'Content', items: [{ name: 'Initiatives', href: '/admin/records', icon: 'Target' }, { name: 'Pages', href: '/admin/pages', icon: 'Layers' }, { name: 'Media', href: '/admin/media', icon: 'Image' }] },
  { name: 'System', items: [{ name: 'Workflows', href: '/admin/workflows', icon: 'Workflow' }, { name: 'Settings', href: '/admin/settings', icon: 'Settings' }] },
]
const SCREENS: MobileScreen[] = [
  { id: 'inventory', label: 'Inventory & supplies', href: '/admin/inventory', group: 'Make', icon: 'Boxes', keywords: ['stock', 'write off'], permission: 'inventory.view' },
  { id: 'dup', label: 'Pages again', href: '/admin/pages', group: 'Content' },
  { id: 'helper', label: 'Print queue', href: '/admin/print', group: 'Make', roles: ['production'] },
]
const groups = manageGroups(MENU, SCREENS, ['/admin/workflows'], ['/admin/manage'])
eq(groups.map((g) => g.name), ['Main', 'Content', 'System', 'Make'], 'menu groups, then new groups from registered screens')
eq(groups.find((g) => g.name === 'Content')!.items.map((i) => i.name), ['Initiatives', 'Pages', 'Media'], 'one entry per href; the menu label wins')
eq(groups.find((g) => g.name === 'System')!.items.find((i) => i.href === '/admin/workflows')!.desktopOnly, true, 'desktop-only marked, not hidden')
eq(groups.find((g) => g.name === 'System')!.items.find((i) => i.href === '/admin/settings')!.desktopOnly, false)
eq(allowedScreens(SCREENS, (p) => p !== 'inventory.view', ['owner']).map((s) => s.id), ['dup'], 'permission and role gates')
eq(allowedScreens(SCREENS, () => true, ['production']).map((s) => s.id), ['inventory', 'dup', 'helper'])

eq(searchManage(groups, 'set').map((i) => i.name), ['Settings'])
eq(searchManage(groups, 'write off').map((i) => i.name), ['Inventory & supplies'], 'registered keywords')
eq(searchManage(groups, 'projects', { '/admin/records': ['projects', 'programmes'] }).map((i) => i.name), ['Initiatives'], "the owner's words")
eq(searchManage(groups, 'zzz'), [], 'no match → the shell offers to ask')
eq(searchManage(groups, '  '), [])
eq(searchManage(groups, 'MÉDIA').map((i) => i.name), ['Media'], 'case and accents fold')

// Pins
eq(resolvePins(null, groups, ['/admin/records', '/admin/pages', '/admin/media', '/admin/forms']).map((i) => i.href), ['/admin/records', '/admin/pages', '/admin/media', '/admin'], 'defaults that exist, topped up to four')
eq(resolvePins(['/admin/settings', '/admin/gone'], groups, ['/admin/records']).map((i) => i.href), ['/admin/settings', '/admin/records', '/admin', '/admin/todo'], 'own pins first; vanished areas dropped')
eq(togglePin(['/admin/a', '/admin/b'], '/admin/a'), ['/admin/b'])
eq(togglePin(['/admin/a', '/admin/b', '/admin/c', '/admin/d'], '/admin/e'), ['/admin/b', '/admin/c', '/admin/d', '/admin/e'], 'a fifth drops the oldest')
eq(cleanPins(['/admin/pages', '/admin/pages/', 'https://evil', 42, '/admin/x?y=1', '/admin/a', '/admin/b', '/admin/c']), ['/admin/pages', '/admin/a', '/admin/b', '/admin/c'])
eq(cleanPins('nope'), [])

// Today cards
const src = (id: string, priority: number): TodayCardSource => ({ id, priority, load: async () => [] })
const ordered = orderCards([
  { source: src('approvals', 20), cards: [{ id: 'a1', title: 'Approve page edit', tone: 'attention', actions: [] }] },
  { source: src('orders', 10), cards: [{ id: 'o1', title: 'Fulfil order', tone: 'attention', actions: [] }, { id: 'o2', title: 'Order waited 22 days', tone: 'urgent', actions: [] }] },
  { source: src('broken', 5), error: new Error('x') },
  { source: src('info', 30), cards: [{ id: 'a1', title: 'dup id', actions: [] }] },
])
eq(ordered.cards.map((c) => c.id), ['o2', 'o1', 'a1'], 'urgent first, then source priority; duplicate ids once')
eq(ordered.failed, ['broken'], 'a failed source is reported, not fatal')
eq(orderCards([{ source: src('x', 1), cards: Array.from({ length: 20 }, (_, i) => ({ id: `c${i}`, title: 't', actions: [] })) }], 5).cards.length, 5)
eq(greeting(new Date(2026, 9, 11, 9), 'Bubune'), 'Good morning, Bubune.')
eq(greeting(new Date(2026, 9, 11, 15)), 'Good afternoon.')
eq(greeting(new Date(2026, 9, 11, 20), 'B'), 'Good evening, B.')
eq([needsYouLine(0), needsYouLine(1), needsYouLine(4)], ['Nothing needs you right now.', '1 thing needs you.', '4 things need you.'])

// Pull to refresh: the four tab screens only
const PULL_HREFS = { ...HREFS, ask: '/admin/m/ask' }
eq(['/admin/today', '/admin/todo/', '/admin/forms', '/admin/manage'].map((p) => pullRefreshHere(p, PULL_HREFS)), [true, true, true, true])
eq(['/admin/m/ask', '/admin/settings', '/admin/pages/x/editor', '/admin/manage/x'].map((p) => pullRefreshHere(p, PULL_HREFS)), [false, false, false, false], 'not the chat, not CMS screens')

// Tab-root screens take their tab and stay out of Manage's list
const inbox: MobileScreen = { id: 'inbox', label: 'Inbox', href: '/admin/m/inbox', group: 'Main', tab: 'inbox' }
eq(tabHrefs(HREFS, [inbox]).inbox, '/admin/m/inbox')
eq(tabHrefs(HREFS, []).inbox, '/admin/forms')
eq(manageGroups(MENU, [inbox], []).flatMap((g) => g.items).some((i) => i.href === '/admin/m/inbox'), false)

// Actions by placement, permission and role
const ACTIONS: MobileAction[] = [
  { id: 'new-initiative', label: 'New initiative', href: '/admin/m/initiatives/new', placement: 'manage-hero', permission: 'blog.create' },
  { id: 'snap', label: 'New product from a photo', href: '/admin/m/snap', placement: 'manage-hero', roles: ['owner'] },
  { id: 'brief', label: 'What changed today?', askText: 'What changed today?', placement: 'today' },
]
eq(mobileActions('manage-hero', () => true, ['owner'], ACTIONS).map((a) => a.id), ['new-initiative', 'snap'])
eq(mobileActions('manage-hero', (p) => p !== 'blog.create', ['editor'], ACTIONS).map((a) => a.id), [], 'permission and role gates')
eq(mobileActions('today', () => false, [], ACTIONS).map((a) => a.id), ['brief'])

// Today sources gated by permission / role
registerTodayCard({ id: 'print-queue', priority: 5, roles: ['production'], load: async () => [] })
registerTodayCard({ id: 'orders', priority: 10, permission: 'orders.view', load: async () => [] })
eq(todayCardSources({ can: () => true, roles: ['production'] }).map((s) => s.id), ['print-queue', 'orders'])
eq(todayCardSources({ can: () => false, roles: ['owner'] }).map((s) => s.id), [], 'nobody sees what they may not')

// iOS keyboard (VisualViewport): lift the sheet by what it covers; ignore toolbar jitter
eq(keyboardInset(844, { height: 844, offsetTop: 0 }), 0)
eq(keyboardInset(844, { height: 508, offsetTop: 0 }), 336, 'keyboard up')
eq(keyboardInset(844, { height: 508, offsetTop: 40 }), 296, 'page scrolled under the keyboard')
eq(keyboardInset(844, { height: 800, offsetTop: 0 }), 0, 'Safari toolbar, not a keyboard')
eq(keyboardInset(844, null), 0, 'no VisualViewport API')

// A phone screen standing in for a menu area takes its row (label + group), not a second row
const PHONE_ANALYTICS: MobileScreen = { id: 'analytics', label: 'Analytics', href: '/admin/m/analytics', group: 'Site', replaces: '/admin/analytics', permission: 'analytics.view' }
const MENU2 = [
  { name: 'Main', items: [{ name: 'Dashboard', href: '/admin' }, { name: 'Analytics', href: '/admin/analytics' }] },
  { name: 'Content', items: [{ name: 'Pages', href: '/admin/pages' }, { name: 'Initiatives', href: '/admin/records' }, { name: 'Media', href: '/admin/media' }] },
  { name: 'System', items: [{ name: 'Users', href: '/admin/users' }, { name: 'Settings', href: '/admin/settings' }] },
]
const g2 = manageGroups(MENU2, [PHONE_ANALYTICS], ['/admin/settings'])
eq(g2.flatMap((g) => g.items).filter((i) => i.name === 'Analytics').map((i) => i.href), ['/admin/m/analytics'], 'the menu row opens the phone screen')
eq(g2.flatMap((g) => g.items).some((i) => i.href === '/admin/analytics'), false)

// The app's short list: its groups and order, the rest under More, View the site where the layout says
const LAYOUT = [
  { name: 'Content', hrefs: ['/admin/records', '/admin/pages', '/admin/blog', '/admin/media'] },
  { name: 'People', hrefs: ['/admin/forms', '/admin/email-marketing'] },
  { name: 'Site', hrefs: ['/admin/m/analytics', SITE_ROW, '/admin/settings'] },
]
const SITE = { label: 'View the site', href: '/' }
const arranged = arrangeManage(g2, LAYOUT, { more: 'More', site: SITE })
eq(arranged.map((g) => g.name), ['Content', 'Site', 'More'], 'a group with none of its areas (People: no access) is left out')
eq(arranged[0].items.map((i) => i.name), ['Initiatives', 'Pages', 'Media'], "the layout's order, only what this person has")
eq(arranged[1].items.map((i) => i.name), ['Analytics', 'View the site', 'Settings'])
eq([arranged[1].items[1].external, arranged[1].items[2].desktopOnly], [true, true], 'site row opens outside; desktop marks kept')
eq(arranged[2].items.map((i) => i.name), ['Dashboard', 'Users'], 'nothing dropped: the rest under More')
eq(arrangeManage(g2, [], { more: 'More', site: SITE }).map((g) => g.name), ['Main', 'Content', 'System', 'Site'], 'no layout: the menu, then the site row')
eq(arrangeManage(g2, [{ name: 'Content', hrefs: ['/admin/pages'] }], { more: 'More' }).some((g) => g.items.some((i) => i.external)), false, 'no site configured: no row')
eq(searchManage(arranged, 'website').map((i) => i.name), ['View the site'], 'search finds the site row')

// Counts on rows, gated by permission
registerManageCount({ href: '/admin/records/', permission: 'pages.view', load: async () => 5 })
eq(manageCounts(() => true).map((c) => c.href), ['/admin/records/'])
eq(manageCounts(() => false).length, 0)

// Today: greeting from the needs-OK stat, the briefing from the sentences, tiles by priority
const afternoon = new Date(2026, 9, 11, 14, 0)
const STATS: TodayStat[] = [
  { id: 'approve', value: 4, label: 'to approve', needsOk: true },
  { id: 'visitors', value: 26, label: 'visitors · 30d', sentence: '26 people visited the site in the last 30 days (190 page views).' },
  { id: 'initiatives', value: 5, label: 'initiatives', sentence: '5 initiatives are on the site.' },
]
eq(todayHeadline(afternoon, 'Bubune', STATS), 'Good afternoon, Bubune. 4 changes need your OK.')
eq(todayHeadline(afternoon, 'Bubune', [{ ...STATS[0], value: 1 }]), 'Good afternoon, Bubune. 1 change needs your OK.')
eq(todayHeadline(afternoon, null, [{ ...STATS[0], value: 0 }]), 'Good afternoon. Nothing needs your OK.')
eq(todayHeadline(new Date(2026, 9, 11, 9), 'Ama', STATS.slice(1)), 'Good morning, Ama.', 'count unknown: say nothing about it')
eq(todaySummary(STATS), '26 people visited the site in the last 30 days (190 page views). 5 initiatives are on the site.')
eq(todayHeadlineParts(afternoon, 'Bubune', STATS), { hello: 'Good afternoon, Bubune.', need: '4 changes need your OK.' }, 'two sentences, two lines')
eq(todayDateLabel(afternoon), 'Today · Sun Oct 11')
registerTodayStat({ id: 'visitors', priority: 20, permission: 'analytics.view', load: async () => null })
registerTodayStat({ id: 'approve', priority: 10, load: async () => null })
eq(todayStatSources({ can: () => true, roles: [] }).map((s) => s.id), ['approve', 'visitors'])
eq(todayStatSources({ can: () => false, roles: [] }).map((s) => s.id), ['approve'], 'no analytics permission: no visitors tile')

console.log(`${n} assertions passed`)
