/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/phone-draft.assert.ts
 */
import assert from 'node:assert/strict'
import { ApiError, classifyApiError, draftQueueKey, knownUploads, liveNote, newSession, parseSession, photoQueueKey, saveQueueKey, uploadedPhotos } from './phone-draft'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const NOW = 1_760_000_000_000

check('a session survives a reload as typed: notes, photos in order, the step', () => {
  const s = { ...newSession('initiative', NOW, () => 0.5), notes: 'Borehole in Ada, raising $3,000', photos: [{ key: 'a1', shotId: 'cover' }, { key: 'b2', shotId: 'people' }], step: 'drafting' as const }
  const back = parseSession(JSON.stringify(s), 'initiative', NOW + 60_000)!
  assert.deepEqual(back, s)
  assert.match(s.draftKey, /^initiative-[a-z0-9]+-[a-z0-9]{6}$/)
  assert.equal(draftQueueKey(s.draftKey), `${s.draftKey}/draft`)
  assert.equal(saveQueueKey(s.draftKey), `${s.draftKey}/save`)
  assert.equal(photoQueueKey(s.draftKey, 'a1'), `${s.draftKey}/p/a1`)
})

check('garbage, another type, a stale session or a bad key start fresh', () => {
  const s = newSession('initiative', NOW)
  assert.equal(parseSession('{nope', 'initiative', NOW), null)
  assert.equal(parseSession(null, 'initiative', NOW), null)
  assert.equal(parseSession(JSON.stringify(s), 'event', NOW), null)
  assert.equal(parseSession(JSON.stringify(s), 'initiative', NOW + 8 * 86_400_000), null)
  assert.equal(parseSession(JSON.stringify({ ...s, draftKey: '../x' }), 'initiative', NOW), null)
})

check('a step that needs a draft (or a save) it doesn’t have falls back safely', () => {
  const s = newSession('initiative', NOW)
  assert.equal(parseSession(JSON.stringify({ ...s, step: 'review' }), 'initiative', NOW)!.step, 'capture')
  assert.equal(parseSession(JSON.stringify({ ...s, step: 'saved', draft: { data: { name: 'A' }, story: [] } }), 'initiative', NOW)!.step, 'review')
  assert.equal(parseSession(JSON.stringify({ ...s, step: 'weird' }), 'initiative', NOW)!.step, 'capture')
})

check('the draft sees the uploaded photos in order; ones still waiting are left out', () => {
  const k = 'initiative-x-abcdef'
  const results: Record<string, unknown> = { [photoQueueKey(k, 'b')]: { id: 'm2', url: 'https://r2/2.jpg' }, [photoQueueKey(k, 'a')]: { id: 'm1', url: 'https://r2/1.jpg' } }
  assert.deepEqual(uploadedPhotos(k, ['a', 'c', 'b'], (key) => results[key]), [{ url: 'https://r2/1.jpg', mediaId: 'm1' }, { url: 'https://r2/2.jpg', mediaId: 'm2' }])
})

check('voice notes and the rounded place survive a reload; a preview needs its draft', () => {
  const s = { ...newSession('initiative', NOW), voices: [{ key: 'v1', seconds: 24, transcript: 'Two-day clinic', url: 'https://r2/v.m4a', mediaId: 'mv' }], near: 'near 6.6°N, 0.47°E' }
  const back = parseSession(JSON.stringify(s), 'initiative', NOW)!
  assert.deepEqual(back.voices, s.voices)
  assert.equal(back.near, s.near)
  assert.equal(parseSession(JSON.stringify({ ...s, step: 'preview' }), 'initiative', NOW)!.step, 'capture')
})

check('a finished upload the queue has since cleared is still known from the session', () => {
  const s = { ...newSession('initiative', NOW), photos: [{ key: 'a', shotId: 'cover', url: 'https://r2/1.jpg', mediaId: 'm1' }, { key: 'b', shotId: 'people' }] }
  const back = parseSession(JSON.stringify(s), 'initiative', NOW)!
  assert.deepEqual(knownUploads(back), { a: { url: 'https://r2/1.jpg', mediaId: 'm1' } })
  assert.deepEqual(uploadedPhotos(back.draftKey, ['a', 'b'], () => undefined, knownUploads(back)), [{ url: 'https://r2/1.jpg', mediaId: 'm1' }])
})

check('errors: no signal / 5xx / 429 retry; a refusal fails for good; 409 needs a person', () => {
  assert.equal(classifyApiError(new TypeError('Failed to fetch')), 'retry')
  assert.equal(classifyApiError(new ApiError('x', 503)), 'retry')
  assert.equal(classifyApiError(new ApiError('x', 429)), 'retry')
  assert.equal(classifyApiError(new ApiError('No name yet', 400)), 'fail')
  assert.equal(classifyApiError(new ApiError('x', 403)), 'fail')
  assert.equal(classifyApiError(new ApiError('x', 409)), 'conflict')
})

check('the list says “Not on the site yet” only for records that aren’t published (staging: Akuse live, six not)', () => {
  assert.equal(liveNote('PUBLISHED'), null)
  assert.equal(liveNote('DRAFT'), 'Not on the site yet')
  assert.equal(liveNote('ARCHIVED'), 'Archived')
  assert.equal(liveNote(undefined), 'Not on the site yet')
})

console.log(`\n${n} checks passed`)
