/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/attachments.assert.ts
 */
import assert from 'node:assert/strict'
import { attachmentsLine, cleanAttachments, parseAttachments } from './attachments'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('photos and voice notes round-trip; only https or this site’s links', () => {
  const a = cleanAttachments({ photos: ['https://r2/1.jpg', 'javascript:alert(1)', '//evil/x.jpg', '/media/2.jpg'], voice: [{ url: 'https://r2/v.m4a', seconds: 24.4, transcript: ' Two-day clinic ' }, { url: 'data:x', transcript: '' }] })!
  assert.deepEqual(a.photos, ['https://r2/1.jpg', '/media/2.jpg'])
  assert.deepEqual(a.voice, [{ url: 'https://r2/v.m4a', seconds: 24.4, transcript: 'Two-day clinic' }])
  assert.deepEqual(parseAttachments(JSON.stringify(a)), a)
})

check('nothing useful or garbage → null', () => {
  assert.equal(cleanAttachments({ photos: [], voice: [] }), null)
  assert.equal(cleanAttachments('x'), null)
  assert.equal(parseAttachments('{bad'), null)
})

check('the one-line summary', () => {
  assert.equal(attachmentsLine({ photos: ['a', 'b', 'c'], voice: [{ url: null, seconds: 1, transcript: 'x' }] }), '3 photos · voice note')
})

console.log(`\n${n} checks passed`)
