/**
 * "My email" in the Inbox: the signed-in person's OWN mailbox through their
 * email connector (Gmail / Outlook). Shared core: the shapes, the state the
 * tab is in, and the pure mapping from the connector API (settings-n's
 * contract) to Inbox items. Each app plugs in a MailboxSource.
 *
 * Mail is untrusted: it's carried as plain text and rendered as text only
 * (never HTML, never auto-linked). Replies are drafts in the person's own
 * mailbox; sending is their click on an approval card. Pure; asserted by
 * mailbox.assert.ts.
 */

import type { InboxItem } from './inbox'
import type { ElementRef } from '../chat/references'

export type MailProvider = 'google' | 'microsoft'

export interface MailAddress {
  name: string
  email: string
}

export interface MailThreadSummary {
  id: string
  subject: string
  from: MailAddress
  snippet: string
  date: string
  unread: boolean
  messageCount: number
}

export interface MailMessage {
  id: string
  from: MailAddress
  to: MailAddress[]
  cc: MailAddress[]
  date: string
  /** Plain text (the server trims it). */
  text: string
}

export interface MailThread {
  id: string
  subject: string
  messages: MailMessage[]
}

/** One provider as GET /api/connectors reports it. */
export interface ConnectorInfo {
  provider: string
  label?: string
  configured?: boolean
  connected?: boolean
  status?: string
  account?: string | null
}

export type MailboxState =
  /** No provider is configured on this site (env missing): no connect button. */
  | { kind: 'not-set-up' }
  | { kind: 'not-connected'; providers: Array<{ provider: MailProvider; label: string; connectHref: string }> }
  | { kind: 'reconnect'; provider: MailProvider; label: string; account: string | null; connectHref: string }
  | { kind: 'ready'; provider: MailProvider; label: string; account: string | null }

/** A mailbox call that didn't return mail. */
export type MailProblem = 'not-connected' | 'reconnect' | 'signed-out' | 'error'

export type MailResult<T> = { ok: true; value: T } | { ok: false; problem: MailProblem; message: string }

export interface MailboxSource {
  state(returnTo: string): Promise<MailboxState>
  threads(provider: MailProvider, opts?: { q?: string; cursor?: string | null }): Promise<MailResult<{ threads: MailThreadSummary[]; next: string | null }>>
  thread(provider: MailProvider, id: string): Promise<MailResult<MailThread>>
  /** Saves a draft in the person's own mailbox. Never sends. */
  saveDraft(provider: MailProvider, draft: MailDraft): Promise<MailResult<{ id: string }>>
  /** Sends a saved draft — only after the person approved it. */
  sendDraft(provider: MailProvider, draftId: string): Promise<MailResult<true>>
}

export interface MailDraft {
  to: string[]
  cc?: string[]
  subject: string
  text: string
  replyTo?: { threadId: string; messageId: string }
}

const PROVIDERS: MailProvider[] = ['google', 'microsoft']
const isProvider = (p: unknown): p is MailProvider => PROVIDERS.includes(p as MailProvider)
const DEFAULT_LABEL: Record<MailProvider, string> = { google: 'Gmail', microsoft: 'Outlook' }

/** Where the connect form POSTs (settings-n ca444f59: connect is POST-only; GET is 405). */
export function connectHref(provider: MailProvider, returnTo: string): string {
  const back = returnTo.startsWith('/admin') ? returnTo : '/admin'
  return `/api/connectors/${provider}/connect?return=${encodeURIComponent(back)}`
}

/** A grant that must be connected again (settings-n: status 'needs-reconnect'). */
const needsReconnect = (c: ConnectorInfo) => c.status === 'needs-reconnect'

/** Which state the tab is in, from GET /api/connectors ({ providers }). A working connection wins; then one needing reconnect. */
export function mailboxState(list: readonly ConnectorInfo[], returnTo: string): MailboxState {
  const mail = list.filter((c) => isProvider(c.provider)) as Array<ConnectorInfo & { provider: MailProvider }>
  const label = (c: ConnectorInfo & { provider: MailProvider }) => c.label || DEFAULT_LABEL[c.provider]
  const ready = mail.find((c) => c.connected && !needsReconnect(c))
  if (ready) return { kind: 'ready', provider: ready.provider, label: label(ready), account: ready.account ?? null }
  const stale = mail.find((c) => needsReconnect(c) && c.configured !== false)
  if (stale) return { kind: 'reconnect', provider: stale.provider, label: label(stale), account: stale.account ?? null, connectHref: connectHref(stale.provider, returnTo) }
  const usable = mail.filter((c) => c.configured)
  if (!usable.length) return { kind: 'not-set-up' }
  return { kind: 'not-connected', providers: usable.map((c) => ({ provider: c.provider, label: label(c), connectHref: connectHref(c.provider, returnTo) })) }
}

/** ?connector_error=<code> after connecting (settings-n: a code, never words) → words for the person. */
export function connectErrorMessage(code: string): string {
  switch (code) {
    case 'denied':
      return 'Connecting was cancelled. Nothing was connected.'
    case 'state_expired':
      return 'Connecting took too long. Please try again.'
    default:
      return 'Connecting your email didn’t finish. Please try again.'
  }
}

/** What an HTTP answer from the mail routes means. */
export function mailProblem(status: number, body: { error?: unknown } | null | undefined): MailProblem {
  if (status === 401) return 'signed-out'
  if (status === 404 && body?.error === 'not-connected') return 'not-connected'
  if (status === 409 || body?.error === 'reconnect') return 'reconnect'
  return 'error'
}

export function problemMessage(p: MailProblem, label = 'your email'): string {
  switch (p) {
    case 'signed-out':
      return 'Your session ended. Sign in again to see your email.'
    case 'not-connected':
      return `Connect ${label} to see it here.`
    case 'reconnect':
      return `${label} needs to be connected again.`
    default:
      return 'Your email couldn’t be loaded just now.'
  }
}

const MAIL_ID = /^mail:(google|microsoft):(.+)$/

export function mailItemId(provider: MailProvider, threadId: string): string {
  return `mail:${provider}:${threadId}`
}

export function parseMailItemId(id: string): { provider: MailProvider; threadId: string } | null {
  const m = MAIL_ID.exec(id)
  return m ? { provider: m[1] as MailProvider, threadId: m[2] } : null
}

export const isMailItem = (id: string) => MAIL_ID.test(id)

const oneLine = (s: string) => s.replace(/\s+/g, ' ').trim()

/** A thread as an Inbox row (segment 'email'). Text only; nothing here is markup. */
export function threadItem(provider: MailProvider, t: MailThreadSummary, label: string): InboxItem {
  const from = oneLine(t.from?.name || t.from?.email || 'Unknown sender')
  return {
    id: mailItemId(provider, t.id),
    segment: 'email',
    from,
    subject: oneLine(t.subject || '(no subject)'),
    preview: oneLine(t.snippet || '').slice(0, 280),
    at: t.date,
    unread: !!t.unread,
    needsReply: !!t.unread,
    sourceLabel: label,
    canReply: !!t.from?.email,
  }
}

/** Reply-to-all minus me: the sender of the last message not from me, plus everyone else on it. */
export function replyRecipients(thread: MailThread, me: string | null): { to: string[]; cc: string[]; replyTo: { threadId: string; messageId: string } | null } {
  const mine = (a: MailAddress) => !!me && a.email.toLowerCase() === me.toLowerCase()
  const last = [...thread.messages].reverse().find((m) => !mine(m.from)) ?? thread.messages.at(-1)
  if (!last) return { to: [], cc: [], replyTo: null }
  const to = mine(last.from) ? last.to.filter((a) => !mine(a)).map((a) => a.email) : [last.from.email]
  const seen = new Set(to.map((e) => e.toLowerCase()))
  const cc = [...last.to, ...last.cc].filter((a) => !mine(a) && !seen.has(a.email.toLowerCase()) && (seen.add(a.email.toLowerCase()), true)).map((a) => a.email)
  return { to: to.filter(Boolean), cc, replyTo: { threadId: thread.id, messageId: last.id } }
}

/** The assistant's line for My email (mock 4's card, mailbox words). */
export function mailSummary(items: readonly InboxItem[], drafted = 0): string {
  const unread = items.filter((i) => i.unread).length
  if (!items.length) return 'Your inbox is empty.'
  if (!unread) return 'No unread email. You’re caught up.'
  const head = `${unread} unread ${unread === 1 ? 'email' : 'emails'}.`
  const d = Math.min(drafted, unread)
  return d ? `${head} I drafted ${d === unread ? (d === 1 ? 'the reply' : d === 2 ? 'both replies' : `all ${d} replies`) : `${d} ${d === 1 ? 'reply' : 'replies'}`}; nothing is sent without you.` : head
}

/**
 * Asking the assistant about a mail thread (C-17): the request carries a
 * reference to the thread — never its subject, sender, addresses or text,
 * because whatever is in the person's own message counts as typed by them
 * (the send recipient check trusts typed addresses). The assistant reads the
 * thread with its email tools.
 */
export function mailAssistAsk(provider: MailProvider, threadId: string): { prompt: string; refs: ElementRef[] } {
  return {
    prompt: 'Draft a reply to this email thread. Read it with your email tools, then put the reply in the reply box (inbox.set_reply_draft). Don’t send it.',
    refs: [{ kind: 'element', key: `mail-thread:${provider}:${threadId}`, label: 'Email thread in my mailbox', tag: 'mail-thread', text: '', screen: 'inbox' }],
  }
}
