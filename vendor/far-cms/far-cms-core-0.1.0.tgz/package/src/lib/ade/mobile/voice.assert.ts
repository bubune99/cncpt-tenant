/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/voice.assert.ts
 */
import assert from 'node:assert/strict'
import { audioExt, audioMime, captureChips, formatClock, liveTranscript, nearText, notesWithVoice } from './voice'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the recording clock', () => {
  assert.equal(formatClock(0), '0:00')
  assert.equal(formatClock(24.9), '0:24')
  assert.equal(formatClock(65), '1:05')
})

check('the live transcript: final phrases, then the one being spoken', () => {
  assert.equal(liveTranscript(['a two-day mobile clinic in Volta', ' in November. '], 'we need about'), 'A two-day mobile clinic in Volta in November. we need about')
  assert.equal(liveTranscript([], ''), '')
})

check('the format the browser can record (Safari MP4 first)', () => {
  assert.equal(audioMime((t) => t === 'audio/mp4' || t === 'audio/webm'), 'audio/mp4')
  assert.equal(audioMime((t) => t.startsWith('audio/webm')), 'audio/webm;codecs=opus')
  assert.equal(audioMime(() => false), null)
  assert.equal(audioExt('audio/mp4'), 'm4a')
  assert.equal(audioExt('audio/webm;codecs=opus'), 'webm')
})

check('the draft reads typed notes and every voice note, quoted', () => {
  assert.equal(notesWithVoice('  ', ['Two-day clinic', '']), 'Voice note: "Two-day clinic"')
  assert.equal(notesWithVoice('Volta', ['Ten volunteers']), 'Volta\n\nVoice note: "Ten volunteers"')
})

check('chips say what the capture has', () => {
  assert.deepEqual(captureChips(3, 1, false).map((c) => [c.label, c.done]), [['3 photos', true], ['Voice note', true], ['Location', false]])
  assert.equal(captureChips(1, 0, true)[0].label, '1 photo')
})

check('location is rounded (~1 km), never the exact spot', () => {
  assert.equal(nearText(6.60321, 0.47011), 'near 6.6°N, 0.47°E')
  assert.equal(nearText(-1.2864, -36.8172), 'near 1.29°S, 36.82°W')
})

console.log(`\n${n} checks passed`)
