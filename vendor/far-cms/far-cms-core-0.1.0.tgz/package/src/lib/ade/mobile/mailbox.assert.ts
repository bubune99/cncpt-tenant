/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/mailbox.assert.ts
 */
import assert from 'node:assert/strict'
import { connectErrorMessage, connectHref, mailAssistAsk, isMailItem, mailProblem, mailSummary, mailboxState, parseMailItemId, replyRecipients, threadItem, type MailThread } from './mailbox'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const R = '/admin/m/inbox'

check('C-17: asking the assistant about a thread carries a reference, never the mail', () => {
  const a = mailAssistAsk('google', 'thr-9')
  const all = JSON.stringify(a)
  assert.ok(all.includes('mail-thread:google:thr-9'))
  for (const leak of ['@', 'Hello', 'Ama', 'Re:']) assert.ok(!all.includes(leak), `no ${leak}`)
  assert.equal(a.refs[0].text, '')
})

check('the tab state: not set up (no env) hides the connect button; not connected offers the configured providers', () => {
  assert.deepEqual(mailboxState([], R), { kind: 'not-set-up' })
  assert.deepEqual(mailboxState([{ provider: 'google', configured: false }, { provider: 'microsoft', configured: false }], R), { kind: 'not-set-up' })
  const s = mailboxState([{ provider: 'google', label: 'Gmail', configured: true, connected: false }, { provider: 'microsoft', configured: false }, { provider: 'stripe', configured: true }], R)
  assert.equal(s.kind, 'not-connected')
  assert.deepEqual(s.kind === 'not-connected' && s.providers, [{ provider: 'google', label: 'Gmail', connectHref: '/api/connectors/google/connect?return=%2Fadmin%2Fm%2Finbox' }])
})

check('active wins; needs-reconnect (settings-n status) asks to reconnect', () => {
  assert.deepEqual(mailboxState([{ provider: 'microsoft', configured: true, connected: true, status: 'active', account: 'me@x.org' }], R), { kind: 'ready', provider: 'microsoft', label: 'Outlook', account: 'me@x.org' })
  const s = mailboxState([{ provider: 'google', configured: true, connected: true, status: 'needs-reconnect', account: 'me@x.org' }], R)
  assert.equal(s.kind, 'reconnect')
  assert.match(s.kind === 'reconnect' ? s.connectHref : '', /^\/api\/connectors\/google\/connect\?return=/)
})

check('connect error codes become words; unknown codes never echo', () => {
  assert.match(connectErrorMessage('denied'), /cancelled/)
  assert.match(connectErrorMessage('state_expired'), /too long/)
  assert.ok(!connectErrorMessage('<script>').includes('<'))
})

check('the return path stays inside the admin', () => {
  assert.equal(connectHref('google', 'https://evil.example'), '/api/connectors/google/connect?return=%2Fadmin')
})

check('HTTP answers map to what the tab says', () => {
  assert.equal(mailProblem(401, {}), 'signed-out')
  assert.equal(mailProblem(404, { error: 'not-connected' }), 'not-connected')
  assert.equal(mailProblem(409, { error: 'reconnect' }), 'reconnect')
  assert.equal(mailProblem(500, null), 'error')
})

check('threads become text-only Inbox rows with their own id space', () => {
  const it = threadItem('google', { id: 't1', subject: '  Hello\nthere ', from: { name: '<b>Ama</b>', email: 'ama@x.org' }, snippet: 'Hi <script>x</script>', date: '2026-10-11T10:00:00Z', unread: true, messageCount: 2 }, 'Gmail')
  assert.equal(it.id, 'mail:google:t1')
  assert.equal(it.segment, 'email')
  assert.equal(it.subject, 'Hello there')
  assert.equal(it.from, '<b>Ama</b>', 'kept as text; the screen renders it as text, never markup')
  assert.ok(it.unread && it.needsReply && it.canReply)
  assert.deepEqual(parseMailItemId(it.id), { provider: 'google', threadId: 't1' })
  assert.ok(isMailItem(it.id) && !isMailItem('submission:f:s'))
  assert.equal(threadItem('microsoft', { id: 'x', subject: '', from: { name: '', email: '' }, snippet: '', date: '', unread: false, messageCount: 1 }, 'Outlook').canReply, false)
})

check('reply goes to the last sender who isn’t me; others on it are cc’d once', () => {
  const t: MailThread = { id: 't', subject: 's', messages: [
    { id: 'm1', from: { name: 'Ama', email: 'ama@x.org' }, to: [{ name: 'Me', email: 'me@x.org' }], cc: [{ name: 'Kofi', email: 'kofi@x.org' }], date: '', text: '' },
    { id: 'm2', from: { name: 'Me', email: 'ME@x.org' }, to: [{ name: 'Ama', email: 'ama@x.org' }], cc: [], date: '', text: '' },
  ] }
  assert.deepEqual(replyRecipients(t, 'me@x.org'), { to: ['ama@x.org'], cc: ['kofi@x.org'], replyTo: { threadId: 't', messageId: 'm1' } })
  assert.deepEqual(replyRecipients({ id: 'e', subject: '', messages: [] }, null), { to: [], cc: [], replyTo: null })
})

check('the assistant line for My email', () => {
  const u = (id: string, unread = true) => threadItem('google', { id, subject: 's', from: { name: 'A', email: 'a@x' }, snippet: '', date: '', unread, messageCount: 1 }, 'Gmail')
  assert.equal(mailSummary([]), 'Your inbox is empty.')
  assert.equal(mailSummary([u('a', false)]), 'No unread email. You’re caught up.')
  assert.equal(mailSummary([u('a'), u('b')], 2), '2 unread emails. I drafted both replies; nothing is sent without you.')
  assert.equal(mailSummary([u('a'), u('b'), u('c')], 1), '3 unread emails. I drafted 1 reply; nothing is sent without you.')
  assert.equal(mailSummary([u('a')]), '1 unread email.')
})

console.log(`\n${n} checks passed`)
