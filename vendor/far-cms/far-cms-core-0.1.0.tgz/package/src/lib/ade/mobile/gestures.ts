/**
 * Phone gestures, one shared module (owner 2026-10-11: "double click or hold
 * and press to understand when we may want to edit, open a menu, send a
 * prompt"). Pure state machines with the clock injected — the React layer
 * (components/ade/mobile/use-gestures) feeds them pointer events and timers.
 *
 * | Gesture        | Unit (card, row, block) | Page preview  | Chat / composer        |
 * | tap            | select / point at it    | point at it   | open a card            |
 * | double-tap     | edit in place           | zoom to it    | —                      |
 * | long-press     | context sheet           | context sheet | message sheet          |
 * | long-press mic | hold to talk; up = lock, left = cancel   |                        |
 * | swipe          | approve / reject (Review cards)          | message right = reply  |
 * | pinch          | —                       | zoom          | —                      |
 * | pull down      | refresh lists           |               |                        |
 *
 * Rules: every gesture has a visible button equivalent; a first-time hint;
 * browser defaults off on units only (text stays selectable in editors); a
 * haptic tick on long-press where supported; no gesture does anything
 * irreversible by itself (sending / publishing still go through the
 * approval card). Asserted by gestures.assert.ts.
 */

// ── Timings and distances ────────────────────────────────────────────

/** A second tap within this window is a double-tap. */
export const DOUBLE_TAP_MS = 300
/** Held this long without moving: a long-press. */
export const LONG_PRESS_MS = 450
/** Movement (px) that turns a press into a drag (no tap, no long-press). */
export const MOVE_SLOP = 10
/** Taps further apart than this (px) are two single taps, not a double. */
export const DOUBLE_TAP_SLOP = 24
/** Drag distance (px) before the axis is decided (scroll vs horizontal swipe). */
export const AXIS_LOCK = 10

// ── Tap / double-tap / long-press ────────────────────────────────────

export type PressGesture = 'tap' | 'double-tap' | 'long-press'

export interface PressOptions {
  /** Something listens for double-taps here: a single tap waits DOUBLE_TAP_MS to be sure. */
  double?: boolean
  /** Something listens for long-presses here. */
  long?: boolean
}

export type PressState =
  | { kind: 'idle' }
  | { kind: 'down'; t: number; x: number; y: number; moved: boolean; fired: boolean }
  /** Released once; waiting to see whether a second tap comes. */
  | { kind: 'waiting'; until: number; x: number; y: number }
  /** Second press of a double-tap. */
  | { kind: 'down2'; t: number; x: number; y: number; moved: boolean }

export type PressEvent =
  | { type: 'down'; t: number; x: number; y: number }
  | { type: 'move'; t: number; x: number; y: number }
  | { type: 'up'; t: number; x: number; y: number }
  | { type: 'cancel' }
  /** A timer the host set (LONG_PRESS_MS after down, DOUBLE_TAP_MS after up) fired. */
  | { type: 'tick'; t: number }

export interface PressStep {
  state: PressState
  emit: PressGesture | null
  /** When the host should send the next tick (absolute ms), or null for none. */
  wakeAt: number | null
}

const far = (ax: number, ay: number, bx: number, by: number, d: number) => Math.hypot(ax - bx, ay - by) > d

/**
 * One step of the press recogniser. Conflict rules: a tap is emitted at once
 * unless a double-tap handler exists (then after DOUBLE_TAP_MS without a
 * second tap); a long-press, once fired, swallows the release; moving past
 * MOVE_SLOP makes it a drag (nothing emitted — scroll or swipe takes over).
 */
export function pressStep(state: PressState, e: PressEvent, opts: PressOptions = {}): PressStep {
  const none = (s: PressState, wakeAt: number | null = null): PressStep => ({ state: s, emit: null, wakeAt })
  if (e.type === 'cancel') return none({ kind: 'idle' })
  switch (state.kind) {
    case 'idle':
      if (e.type !== 'down') return none(state)
      return none({ kind: 'down', t: e.t, x: e.x, y: e.y, moved: false, fired: false }, opts.long ? e.t + LONG_PRESS_MS : null)
    case 'down': {
      if (e.type === 'move') {
        const moved = state.moved || far(e.x, e.y, state.x, state.y, MOVE_SLOP)
        return none({ ...state, moved }, moved ? null : opts.long && !state.fired ? state.t + LONG_PRESS_MS : null)
      }
      if (e.type === 'tick') {
        if (opts.long && !state.moved && !state.fired && e.t >= state.t + LONG_PRESS_MS) {
          return { state: { ...state, fired: true }, emit: 'long-press', wakeAt: null }
        }
        return none(state, opts.long && !state.moved && !state.fired ? state.t + LONG_PRESS_MS : null)
      }
      if (e.type === 'up') {
        if (state.fired || state.moved) return none({ kind: 'idle' })
        // A slow press without a long-press handler is still a tap.
        if (!opts.double) return { state: { kind: 'idle' }, emit: 'tap', wakeAt: null }
        return none({ kind: 'waiting', until: e.t + DOUBLE_TAP_MS, x: state.x, y: state.y }, e.t + DOUBLE_TAP_MS)
      }
      return none(state)
    }
    case 'waiting': {
      if (e.type === 'tick' && e.t >= state.until) return { state: { kind: 'idle' }, emit: 'tap', wakeAt: null }
      if (e.type === 'down') {
        if (e.t <= state.until && !far(e.x, e.y, state.x, state.y, DOUBLE_TAP_SLOP)) return none({ kind: 'down2', t: e.t, x: e.x, y: e.y, moved: false })
        // Too late or too far: the first was a tap, this starts a new press.
        return { state: { kind: 'down', t: e.t, x: e.x, y: e.y, moved: false, fired: false }, emit: 'tap', wakeAt: opts.long ? e.t + LONG_PRESS_MS : null }
      }
      return none(state, state.until)
    }
    case 'down2': {
      if (e.type === 'move') return none({ ...state, moved: state.moved || far(e.x, e.y, state.x, state.y, MOVE_SLOP) })
      if (e.type === 'up') return state.moved ? none({ kind: 'idle' }) : { state: { kind: 'idle' }, emit: 'double-tap', wakeAt: null }
      return none(state)
    }
  }
}

// ── A recogniser with its own timers (any event source) ──────────────

export interface PressCallbacks {
  onTap?: () => void
  onDoubleTap?: () => void
  onLongPress?: () => void
}

export interface PressClock {
  now: () => number
  setTimer: (fn: () => void, ms: number) => unknown
  clearTimer: (id: unknown) => void
}

const realClock = (): PressClock => ({
  now: () => (typeof performance !== 'undefined' ? performance.now() : Date.now()),
  setTimer: (fn, ms) => setTimeout(fn, ms),
  clearTimer: (id) => clearTimeout(id as ReturnType<typeof setTimeout>),
})

/**
 * pressStep wired to timers, for any event source — React pointer events
 * (usePress) or listeners on an iframe's document (the page preview). Feed
 * it down / move / up / cancel; it calls back tap / double-tap / long-press.
 * Callbacks are read at fire time, so they can change between presses.
 */
export function createPressRecognizer(callbacks: PressCallbacks, clock: PressClock = realClock()) {
  const cb: PressCallbacks = { ...callbacks }
  let state: PressState = { kind: 'idle' }
  let timer: unknown = null
  const opts = (): PressOptions => ({ double: !!cb.onDoubleTap, long: !!cb.onLongPress })
  const feed = (e: PressEvent) => {
    const r = pressStep(state, e, opts())
    state = r.state
    if (timer !== null) clock.clearTimer(timer)
    timer = null
    if (r.wakeAt !== null) {
      const at = r.wakeAt
      timer = clock.setTimer(() => {
        timer = null
        feed({ type: 'tick', t: Math.max(at, clock.now()) })
      }, Math.max(0, at - clock.now()))
    }
    if (r.emit === 'tap') cb.onTap?.()
    else if (r.emit === 'double-tap') cb.onDoubleTap?.()
    else if (r.emit === 'long-press') cb.onLongPress?.()
  }
  return {
    down: (x: number, y: number) => feed({ type: 'down', t: clock.now(), x, y }),
    move: (x: number, y: number) => {
      if (state.kind === 'down' || state.kind === 'down2') feed({ type: 'move', t: clock.now(), x, y })
    },
    up: (x: number, y: number) => feed({ type: 'up', t: clock.now(), x, y }),
    cancel: () => feed({ type: 'cancel' }),
    /** Swap the callbacks (a re-render with new handlers). */
    set: (next: PressCallbacks) => {
      cb.onTap = next.onTap
      cb.onDoubleTap = next.onDoubleTap
      cb.onLongPress = next.onLongPress
    },
    dispose: () => {
      if (timer !== null) clock.clearTimer(timer)
      timer = null
      state = { kind: 'idle' }
    },
  }
}

// ── Scroll vs swipe ──────────────────────────────────────────────────

export type DragAxis = 'x' | 'y' | null

/** Which way a drag is going, once it has gone AXIS_LOCK px: mostly sideways = a swipe, else a scroll. */
export function dragAxis(dx: number, dy: number): DragAxis {
  if (Math.hypot(dx, dy) < AXIS_LOCK) return null
  return Math.abs(dx) > Math.abs(dy) ? 'x' : 'y'
}

/** Share of the element's width a release must travel to count as a swipe. */
export const SWIPE_DISTANCE = 0.35
/** A fast flick counts from a shorter travel (px per ms), at least FLICK_MIN of the width. */
export const SWIPE_VELOCITY = 0.6
export const FLICK_MIN = 0.15

/** A released horizontal drag → 'right' / 'left' / null (snap back). Vertical drags never swipe. */
export function swipeDirection(end: { dx: number; dy: number; width: number; vx?: number }): 'right' | 'left' | null {
  if (!(end.width > 0) || Math.abs(end.dy) > Math.abs(end.dx)) return null
  const share = end.dx / end.width
  const vx = end.vx ?? 0
  const fast = Math.abs(vx) >= SWIPE_VELOCITY && Math.sign(vx) === Math.sign(end.dx)
  if (Math.abs(share) < SWIPE_DISTANCE && !(fast && Math.abs(share) >= FLICK_MIN)) return null
  return share > 0 ? 'right' : 'left'
}

// ── Pinch ────────────────────────────────────────────────────────────

export const PINCH_MIN = 1
export const PINCH_MAX = 4

/** The zoom after a pinch: the starting zoom times how far the fingers moved apart, kept in range. */
export function pinchZoom(startZoom: number, startDistance: number, distance: number, min = PINCH_MIN, max = PINCH_MAX): number {
  if (!(startDistance > 0) || !(distance > 0)) return startZoom
  return Math.min(max, Math.max(min, startZoom * (distance / startDistance)))
}

export const fingerDistance = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y)

// ── Pull down to refresh ─────────────────────────────────────────────

/** Pulled this far (after resistance) and released: refresh. */
export const PULL_TRIGGER = 64
const PULL_MAX = 96

/**
 * A downward drag at the top of a list → how far the indicator shows and
 * whether a release refreshes. Only from the very top (a list scrolled down
 * just scrolls), with resistance so it never runs away.
 */
export function pullState(dy: number, scrollTop: number): { offset: number; ready: boolean } {
  if (scrollTop > 0 || dy <= 0) return { offset: 0, ready: false }
  const offset = Math.min(PULL_MAX, dy * 0.5)
  return { offset, ready: offset >= PULL_TRIGGER }
}

// ── Mic: hold to talk ────────────────────────────────────────────────

/** Slide up this far while holding: keep recording hands-free. */
export const MIC_LOCK_DY = -60
/** Slide left this far while holding: throw the recording away. */
export const MIC_CANCEL_DX = -80

export type MicState = 'idle' | 'holding' | 'locked' | 'cancelled'
export type MicEvent = { type: 'down' } | { type: 'move'; dx: number; dy: number } | { type: 'up' } | { type: 'tap-stop' }
/** What the host does: start / stop listening, keep the words or not, and whether to send. */
export type MicEffect = 'start' | 'send' | 'discard' | null

/**
 * Hold the mic to talk; release sends (a prompt to the assistant — it
 * drafts, it never publishes). Slide up to lock (release no longer stops;
 * tap stop sends), slide left to cancel (nothing is sent).
 */
export function micStep(state: MicState, e: MicEvent): { state: MicState; effect: MicEffect } {
  if (state === 'idle') return e.type === 'down' ? { state: 'holding', effect: 'start' } : { state, effect: null }
  if (state === 'holding') {
    if (e.type === 'move') {
      if (e.dx <= MIC_CANCEL_DX) return { state: 'cancelled', effect: 'discard' }
      if (e.dy <= MIC_LOCK_DY) return { state: 'locked', effect: null }
      return { state, effect: null }
    }
    if (e.type === 'up') return { state: 'idle', effect: 'send' }
    return { state, effect: null }
  }
  if (state === 'locked') return e.type === 'tap-stop' ? { state: 'idle', effect: 'send' } : { state, effect: null }
  // Cancelled: wait for the finger to lift, then back to idle.
  return e.type === 'up' ? { state: 'idle', effect: null } : { state, effect: null }
}

// ── First-time hints ─────────────────────────────────────────────────

export type GestureHint = 'review-swipe' | 'long-press' | 'double-tap' | 'mic-hold' | 'message-swipe' | 'pull-refresh' | 'pinch'

const HINT_KEY = 'ade:gesture-hints'

interface HintStore {
  getItem(k: string): string | null
  setItem(k: string, v: string): void
}

const read = (store: HintStore | null): string[] => {
  try {
    const v = JSON.parse(store?.getItem(HINT_KEY) ?? '[]')
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []
  } catch {
    return []
  }
}

/** Show this hint? Once per browser; storage that fails (private mode) means no hint rather than one every time. */
export function shouldShowHint(id: GestureHint, store: HintStore | null): boolean {
  if (!store) return false
  try {
    store.getItem(HINT_KEY)
  } catch {
    return false
  }
  return !read(store).includes(id)
}

export function markHintShown(id: GestureHint, store: HintStore | null): void {
  try {
    const seen = read(store)
    if (!seen.includes(id)) store?.setItem(HINT_KEY, JSON.stringify([...seen, id]))
  } catch {
    /* hints are a nicety */
  }
}

export const HINT_TEXT: Record<GestureHint, string> = {
  'review-swipe': 'Swipe right to approve, left to reject — or use the buttons.',
  'long-press': 'Press and hold for more options.',
  'double-tap': 'Double-tap to edit in place.',
  'mic-hold': 'Hold to talk. Slide up to keep recording, left to cancel.',
  'message-swipe': 'Swipe a message right to reply to it.',
  'pull-refresh': 'Pull down to refresh.',
  pinch: 'Pinch to zoom.',
}

// ── Units ────────────────────────────────────────────────────────────

/**
 * Browser defaults off on gesture units only: no double-tap zoom, no iOS
 * callout or text selection on a long-press. Editors and message text keep
 * normal selection (they don't get the attribute).
 */
export const UNIT_GESTURE_ATTR = 'data-ade-gesture-unit'
export const UNIT_GESTURE_CSS = `[${UNIT_GESTURE_ATTR}]{touch-action:manipulation;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}[${UNIT_GESTURE_ATTR}] input,[${UNIT_GESTURE_ATTR}] textarea,[${UNIT_GESTURE_ATTR}] [contenteditable="true"]{-webkit-user-select:text;user-select:text;-webkit-touch-callout:default}`
