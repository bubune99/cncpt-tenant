/**
 * Photos from the phone (pure, app-agnostic): which files need converting,
 * how big to make them, and the shot checklist ("Cover photo", "People",
 * "The place"). The component does the pixels; this decides. Asserted by
 * mobile.assert.ts.
 */

/** HEIC/HEIF (iPhone default) can't be shown or stored as-is: convert to JPEG. */
export function needsConversion(file: { name: string; type: string }): boolean {
  return /image\/hei[cf]/i.test(file.type) || /\.(heic|heif)$/i.test(file.name)
}

/** Fit within `max` on the long side, never upscale. */
export function fitSize(w: number, h: number, max = 2400): { width: number; height: number } {
  if (w <= 0 || h <= 0) return { width: 0, height: 0 }
  const s = Math.min(1, max / Math.max(w, h))
  return { width: Math.round(w * s), height: Math.round(h * s) }
}

/** "IMG_1234.HEIC" → "IMG_1234.jpg" */
export function jpegName(name: string): string {
  return `${name.replace(/\.[^.]+$/, '') || 'photo'}.jpg`
}

export interface Shot {
  id: string
  label: string
  hint?: string
  required?: boolean
}

export interface ShotState {
  /** shot id → photo keys taken for it */
  taken: Record<string, string[]>
}

/** The next shot to take: the first required one without a photo, then any without. */
export function nextShot(shots: readonly Shot[], state: ShotState): Shot | null {
  const empty = (s: Shot) => !(state.taken[s.id]?.length)
  return shots.find((s) => s.required && empty(s)) ?? shots.find(empty) ?? null
}

/** Required shots still missing (for "Add a cover photo" before saving). */
export function missingShots(shots: readonly Shot[], state: ShotState): Shot[] {
  return shots.filter((s) => s.required && !(state.taken[s.id]?.length))
}

/** All photos in shot order (cover first) — the order a draft uses them. */
export function orderedPhotos(shots: readonly Shot[], state: ShotState): string[] {
  const known = shots.flatMap((s) => state.taken[s.id] ?? [])
  const extra = Object.entries(state.taken).filter(([id]) => !shots.some((s) => s.id === id)).flatMap(([, keys]) => keys)
  return [...new Set([...known, ...extra])]
}
