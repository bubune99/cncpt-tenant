/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/review-deck.assert.ts
 */
import assert from 'node:assert/strict'
import { afterDecision, askPrompt, buildDeck, cardDate, cardHeading, deckButtons, deckSummary, keyDecision, ownerLabel, proposer, swipeDecision, swipeLean, type DeckCard } from './review-deck'
import type { ChangeView } from '../chat/change-widgets'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const view = (over: Partial<ChangeView> = {}): ChangeView => ({
  key: 'cs:x', status: 'pending', entityType: 'Form', entityName: 'Volunteer', href: '/admin/todo/review/x', fields: [], more: 0,
  version: null, revisionId: null, canRestore: false, itemIds: ['i1'], canApprove: true, error: null, ...over,
})
const card = (id: string, at: string, over: Partial<ChangeView> = {}): DeckCard => ({ id, who: 'Assistant', at, why: null, view: view({ key: `cs:${id}`, ...over }) })

check('swipes: right approves, left rejects, short or vertical drags snap back', () => {
  assert.equal(swipeDecision({ dx: 140, dy: 10, width: 360 }, true), 'approve')
  assert.equal(swipeDecision({ dx: -140, dy: 10, width: 360 }, true), 'reject')
  assert.equal(swipeDecision({ dx: 80, dy: 0, width: 360 }, true), null, 'too short')
  assert.equal(swipeDecision({ dx: 80, dy: 0, width: 360, vx: 0.9 }, true), 'approve', 'a fast flick decides sooner')
  assert.equal(swipeDecision({ dx: 80, dy: 0, width: 360, vx: -0.9 }, true), null, 'flicked back the other way')
  assert.equal(swipeDecision({ dx: 30, dy: 0, width: 360, vx: 2 }, true), null, 'a twitch is not a flick')
  assert.equal(swipeDecision({ dx: 150, dy: 200, width: 360 }, true), null, 'mostly vertical = scrolling')
  assert.equal(swipeDecision({ dx: 300, dy: 0, width: 0 }, true), null)
})

check('someone who cannot review never decides by swiping or keys (read-only cards)', () => {
  assert.equal(swipeDecision({ dx: 300, dy: 0, width: 360 }, false), null)
  assert.deepEqual(swipeLean(300, 360, false), { lean: 0, hint: null })
  assert.equal(keyDecision('ArrowRight', false), null)
  assert.equal(keyDecision('ArrowLeft', false), null)
  assert.equal(keyDecision('l', false), 'later', 'saving for later is still theirs')
  assert.deepEqual(deckButtons({ view: view({ canApprove: false }) }).map((b) => b.decision), ['later', 'ask'])
})

check('every swipe has a key and a button', () => {
  assert.equal(keyDecision('ArrowRight', true), 'approve')
  assert.equal(keyDecision('A', true), 'approve')
  assert.equal(keyDecision('ArrowLeft', true), 'reject')
  assert.equal(keyDecision('c', true), 'ask')
  assert.equal(keyDecision('Enter', true), null, 'Enter does not approve by accident')
  assert.deepEqual(deckButtons({ view: view() }).map((b) => b.decision), ['reject', 'later', 'ask', 'approve'])
  assert.deepEqual(deckButtons({ view: view({ status: 'applied' }) }).map((b) => b.decision), ['later', 'ask'])
})

check('the lean hint appears only past the decision point', () => {
  assert.deepEqual(swipeLean(60, 360, true).hint, null)
  assert.equal(swipeLean(130, 360, true).hint, 'Approve')
  assert.equal(swipeLean(-130, 360, true).hint, 'Reject')
  assert.equal(swipeLean(1000, 360, true).lean, 1)
})

check('the deck: reviewable first, oldest first; decisions take the card out', () => {
  const d = buildDeck([
    card('ro', '2026-10-11T08:00:00Z', { canApprove: false }),
    card('new', '2026-10-11T10:00:00Z'),
    card('old', '2026-10-11T09:00:00Z'),
  ])
  assert.deepEqual(d.queue.map((c) => c.id), ['old', 'new', 'ro'])
  assert.equal(deckSummary(d), '3 waiting · swipe or tap')
  const a = afterDecision(d, 'old', 'approve')
  const b = afterDecision(a, 'new', 'later')
  assert.deepEqual(b.queue.map((c) => c.id), ['ro'])
  assert.deepEqual(b.later, ['new'])
  assert.equal(deckSummary(b), '1 waiting · swipe or tap · 1 saved')
  assert.equal(afterDecision(b, 'ro', 'ask'), b, 'asking for a change decides nothing: the card stays')
  assert.equal(deckSummary({ queue: [], later: [] }), 'Nothing waiting')
  assert.equal(afterDecision(b, 'new', 'later').later.length, 1, 'no duplicates')
})

check('the card reads like the mock-up: "Your assistant · Oct 9", "Page edit · Heading"', () => {
  assert.equal(proposer('chat', 'Bubune', true), 'Your assistant')
  assert.equal(proposer('mcp', 'Bubune', true), 'Your connected tool')
  assert.equal(cardDate('2026-10-09T15:00:00Z'), 'Oct 9')
  assert.equal(cardDate('nope'), '')
  assert.equal(cardHeading({ entityType: 'Page', fields: [{ field: 'Heading', label: 'Heading', before: 'a', after: 'b' }] }), 'Page edit · Heading')
  assert.equal(cardHeading({ entityType: 'Form', fields: [] }), 'Form edit')
})

check('who proposed it, in words', () => {
  assert.equal(proposer('chat', 'Ama'), 'Assistant for Ama')
  assert.equal(proposer('chat', null), 'Assistant')
  assert.equal(proposer('mcp', 'Kofi'), 'Connected tool for Kofi')
  assert.equal(proposer('workflow', 'x'), 'Automation')
  // Seen on staging: "Assistant for bubuneo99" (the email's first part) — the name comes first.
  assert.equal(proposer('chat', ownerLabel('Bubune O.', 'bubuneo99@gmail.com')), 'Assistant for Bubune O.')
  assert.equal(ownerLabel('  ', 'ama@x.org'), 'ama')
  assert.equal(ownerLabel(null, null), null)
})

check('Ask for a change starts the request in the assistant, naming the draft', () => {
  assert.equal(askPrompt({ id: 'cs9', title: 'Drafted a change to Form “Volunteer”' }), 'Rework the draft “Form “Volunteer”” (change set cs9): ')
})

console.log(`\n${n} checks passed`)
