/**
 * "Send link to my computer" (mobile brief, screens 7 and 15): something
 * that is easier on a desktop (a layout, a template, settings) becomes a
 * phone → desktop handoff (lib/ade/mobile/handoff) — the desktop's "You
 * started … on your phone" card — with a deep link back to exactly where the
 * person was. Only for the person who sent it; sending the same link again
 * refreshes the card instead of adding another.
 *
 * Pure and app-agnostic. Asserted by send-to-desktop.assert.ts.
 */

export interface PickupInput {
  /** What to pick up, in plain words ("Finish the About page layout"). */
  title: string
  /** An admin path to open on the desktop. */
  href: string
  /** The handoff kind (its noun on the desktop card); defaults to 'link'. */
  kind?: string
}

export interface PickupHandoff {
  kind: string
  title: string
  href: string
  device: 'phone'
}

/** Only links inside the admin, without a host — never an open redirect. */
export function safeAdminHref(href: string): string | null {
  const h = href.trim()
  if (!/^\/admin(\/|\?|#|$)/.test(h) || h.startsWith('//') || /[\s<>"']/.test(h) || h.length > 500) return null
  return h
}

/** Validate and build the handoff, or say what's wrong. */
export function pickupHandoff(input: PickupInput, userId: string): { ok: true; handoff: PickupHandoff } | { ok: false; error: string } {
  const href = safeAdminHref(input.href ?? '')
  if (!href) return { ok: false, error: 'That link isn’t an admin screen.' }
  const title = (input.title ?? '').replace(/\s+/g, ' ').trim().slice(0, 140)
  if (!title) return { ok: false, error: 'Say what to pick up.' }
  if (!userId) return { ok: false, error: 'Sign in first.' }
  const kind = /^[a-z][a-z0-9-]{0,39}$/.test(input.kind ?? '') ? input.kind! : 'link'
  return { ok: true, handoff: { kind, title, href, device: 'phone' } }
}
