/**
 * Mobile Review: open change sets as a deck of cards. Swipe right approves,
 * left rejects; Save for later and Ask for a change are buttons; every swipe
 * has a button and a key, and someone who can't review gets no decisions at
 * all (read-only cards). Pure; asserted by review-deck.assert.ts.
 */

import type { ChangeView } from '../chat/change-widgets'
import { SWIPE_DISTANCE, swipeDirection } from './gestures'

export type Decision = 'approve' | 'reject' | 'later' | 'ask'

export interface DeckCard {
  /** The change set. */
  id: string
  /** Who (or what) proposed it: "Assistant for Ama", "MCP · ci-bot". */
  who: string
  /** When it was proposed (ISO). */
  at: string
  /** Why, in the proposer's words; null when none was given. */
  why: string | null
  /** The change itself, as the chat's change card shows it (masked for the viewer). */
  view: ChangeView
  /** Sent from a phone (a new initiative from the field): its photos, voice notes and one-line facts. */
  phone?: {
    photos: string[]
    voice: Array<{ url: string | null; seconds: number; transcript: string }>
    facts: string
    /** This person may approve and publish in one step. */
    canPublish: boolean
    /** The app's approve-and-publish endpoint (POST { changeSetId, acknowledgeLocks? }); null = not offered. */
    publishEndpoint: string | null
    /** What can wait (not blocking): to fill in on the web after publishing. */
    later: string[]
  }
}

// ── Swipes ───────────────────────────────────────────────────────────

export { SWIPE_DISTANCE, SWIPE_VELOCITY } from './gestures'

export interface SwipeEnd {
  dx: number
  dy: number
  width: number
  /** Release speed along x, px/ms (signed). */
  vx?: number
}

/**
 * A released drag → a decision, or null (snap back): the shared swipe rule
 * (lib/ade/mobile/gestures — vertical drags are scrolling), right approves,
 * left rejects. A card that can't be reviewed never decides; swipes only
 * ever approve or reject (nothing irreversible beyond what Approve means).
 */
export function swipeDecision(end: SwipeEnd, canReview: boolean): 'approve' | 'reject' | null {
  if (!canReview) return null
  const d = swipeDirection(end)
  return d === 'right' ? 'approve' : d === 'left' ? 'reject' : null
}

/** How a card leans while dragged: -1…1 and the hint shown under the finger. */
export function swipeLean(dx: number, width: number, canReview: boolean): { lean: number; hint: 'Approve' | 'Reject' | null } {
  if (!canReview || !(width > 0)) return { lean: 0, hint: null }
  const lean = Math.max(-1, Math.min(1, dx / (width * SWIPE_DISTANCE)))
  return { lean, hint: lean >= 1 ? 'Approve' : lean <= -1 ? 'Reject' : null }
}

// ── Keys and buttons (the same decisions, without swiping) ───────────

const KEYS: Record<string, Decision> = {
  ArrowRight: 'approve',
  a: 'approve',
  ArrowLeft: 'reject',
  r: 'reject',
  l: 'later',
  s: 'later',
  c: 'ask',
}

/** A key pressed on the focused card → a decision; reviewers only for approve / reject. */
export function keyDecision(key: string, canReview: boolean): Decision | null {
  const d = KEYS[key] ?? KEYS[key.toLowerCase()] ?? null
  if (!d) return null
  if ((d === 'approve' || d === 'reject') && !canReview) return null
  return d
}

/** The buttons a card shows, in order (they mirror the swipes and keys). */
export function deckButtons(card: Pick<DeckCard, 'view'>): Array<{ decision: Decision; label: string; key: string }> {
  const review = card.view.status === 'pending' && card.view.canApprove
  return [
    ...(review ? [{ decision: 'reject' as const, label: 'Reject', key: '←' }] : []),
    { decision: 'later' as const, label: 'Save for later', key: 'L' },
    { decision: 'ask' as const, label: 'Ask for a change', key: 'C' },
    ...(review ? [{ decision: 'approve' as const, label: 'Approve', key: '→' }] : []),
  ]
}

// ── The deck ─────────────────────────────────────────────────────────

export interface Deck {
  /** Still to decide, in order. */
  queue: DeckCard[]
  /** Saved for later this session (back at the end of the deck next time). */
  later: string[]
}

/** Open sets → a deck: pending and reviewable first, oldest first; read-only ones after. */
export function buildDeck(cards: readonly DeckCard[]): Deck {
  const rank = (c: DeckCard) => (c.view.status === 'pending' ? (c.view.canApprove ? 0 : 1) : 2)
  const queue = [...cards].sort((a, b) => rank(a) - rank(b) || a.at.localeCompare(b.at))
  return { queue, later: [] }
}

/**
 * After a decision on the top card it leaves the deck; "later" also
 * remembers it. "Ask for a change" opens the assistant with the request
 * started and decides nothing, so the card stays until it is reworked.
 */
export function afterDecision(deck: Deck, id: string, d: Decision): Deck {
  if (d === 'ask') return deck
  return {
    queue: deck.queue.filter((c) => c.id !== id),
    later: d === 'later' && !deck.later.includes(id) ? [...deck.later, id] : deck.later,
  }
}

/** "4 waiting · swipe or tap" — the line above the deck; "Nothing waiting" when empty (the mock-up's words). */
export function deckSummary(deck: Deck): string {
  const n = deck.queue.length
  const saved = deck.later.length ? ` · ${deck.later.length} saved` : ''
  return n ? `${n} waiting · swipe or tap${saved}` : `Nothing waiting${saved}`
}

/** The card's heading: "Page edit · Heading" (what kind of thing, and the first thing changed). */
export function cardHeading(view: Pick<ChangeView, 'entityType' | 'fields'>): string {
  const first = view.fields[0]?.label
  return first ? `${view.entityType} edit · ${first}` : `${view.entityType} edit`
}

/** The date on the card: "Oct 9". */
export function cardDate(iso: string, locale = 'en-US'): string {
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString(locale, { month: 'short', day: 'numeric', timeZone: 'UTC' })
}

/** Who proposed it, in words: "Your assistant" for your own, "Assistant for Ama" for someone else's. */
export function proposer(source: string, ownerName: string | null, mine = false): string {
  const name = ownerName?.trim() || null
  if (source === 'workflow') return 'Automation'
  if (source === 'mcp') return mine ? 'Your connected tool' : name ? `Connected tool for ${name}` : 'Connected tool'
  return mine ? 'Your assistant' : name ? `Assistant for ${name}` : 'Assistant'
}

/** What "Ask for a change" puts in the assistant's composer (not sent: the person finishes the sentence). */
export function askPrompt(card: Pick<DeckCard, 'id'> & { title: string }): string {
  return `Rework the draft “${card.title.replace(/^Drafted a change to /, '')}” (change set ${card.id}): `
}

/** What to call the person behind a change: their name; their email's first part only when the account has none. */
export function ownerLabel(name: string | null | undefined, email: string | null | undefined): string | null {
  return name?.trim() || email?.split('@')[0]?.trim() || null
}
