/**
 * Voice notes on a phone (pure; asserted by voice.assert.ts): the clock,
 * the live transcript as the browser's speech recognition hears it (final
 * phrases plus the one still being spoken), the recording format the
 * browser supports, and the capture chips.
 */

/** "0:24", "1:05". */
export function formatClock(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

/** Final phrases joined, then the phrase still being heard; tidy spacing, first letter up. */
export function liveTranscript(finals: readonly string[], interim = ''): string {
  const text = [...finals, interim].map((p) => p.trim()).filter(Boolean).join(' ').replace(/\s+/g, ' ')
  return text ? text[0].toUpperCase() + text.slice(1) : ''
}

/** Safari records MP4/AAC, Chrome and Firefox WebM/Opus; the first the browser supports. */
export function audioMime(isTypeSupported: (t: string) => boolean): string | null {
  for (const t of ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus']) if (isTypeSupported(t)) return t
  return null
}

/** File extension for a recorded audio type. */
export function audioExt(mime: string): string {
  return mime.startsWith('audio/mp4') ? 'm4a' : mime.startsWith('audio/ogg') ? 'ogg' : 'webm'
}

/** The notes the draft reads: what was typed, then each voice note's words. */
export function notesWithVoice(typed: string, transcripts: readonly string[]): string {
  return [typed.trim(), ...transcripts.map((t) => t.trim()).filter(Boolean).map((t) => `Voice note: "${t}"`)].filter(Boolean).join('\n\n')
}

export interface CaptureChip {
  key: 'photos' | 'voice' | 'location'
  label: string
  done: boolean
}

/** "✓ 3 photos" · "✓ Voice note" · "Location" — what the capture has so far. */
export function captureChips(photos: number, voiceNotes: number, located: boolean): CaptureChip[] {
  return [
    { key: 'photos', label: photos ? `${photos} photo${photos === 1 ? '' : 's'}` : 'Photos', done: photos > 0 },
    { key: 'voice', label: voiceNotes > 1 ? `${voiceNotes} voice notes` : 'Voice note', done: voiceNotes > 0 },
    { key: 'location', label: 'Location', done: located },
  ]
}

/** Rounded coordinates for the draft ("near 6.6°N, 0.47°E") — about a kilometre, never an exact spot. */
export function nearText(lat: number, lng: number): string {
  const r = (n: number) => Math.round(Math.abs(n) * 100) / 100
  return `near ${r(lat)}°${lat >= 0 ? 'N' : 'S'}, ${r(lng)}°${lng >= 0 ? 'E' : 'W'}`
}
