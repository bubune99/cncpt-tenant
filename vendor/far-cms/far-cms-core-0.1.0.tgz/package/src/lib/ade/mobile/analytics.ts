/**
 * Analytics on a phone: three tiles, page views per day, top pages and one
 * suggestion — from the site's own first-party numbers (the summary and the
 * daily series the dashboard already serves). Measured numbers only: what
 * couldn't be read shows as unknown, never as zero or an example.
 *
 * Pure; asserted by analytics.assert.ts.
 */

export interface AnalyticsSummaryIn {
  pageViews?: unknown
  uniqueVisitors?: unknown
  topPages?: unknown
}

export interface DayIn {
  date?: unknown
  value?: unknown
}

/** The app's goal page ("donate views"): which paths count, and what to call it. */
export interface AnalyticsGoal {
  /** Paths containing this ('/donate'). */
  path: string
  /** Tile label ("donate views"). */
  label: string
  /** What visitors reach ("Donate"). */
  name: string
}

export interface AnalyticsView {
  visitors: number | null
  pageViews: number | null
  goalViews: number | null
  days: Array<{ date: string; value: number }>
  /** Highest day (bar scale); 0 when nothing was recorded. */
  peak: number
  topPages: Array<{ url: string; views: number }>
  suggestion: { text: string; ask: string | null } | null
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? Math.round(v) : null)

/** Admin, editor previews and query-string variants aren't visits to the site. */
export function isSitePage(url: string): boolean {
  return !/^\/admin(\/|$)|ade-preview|[?&]preview=/.test(url)
}

/** Strip query and hash, so "/?utm=x" and "/" are one page. */
function pagePath(url: string): string {
  return url.split(/[?#]/)[0] || '/'
}

export function analyticsView(summary: AnalyticsSummaryIn | null, series: readonly DayIn[] | null, goal: AnalyticsGoal | null, topN = 3): AnalyticsView {
  const pages = new Map<string, number>()
  if (summary && Array.isArray(summary.topPages)) {
    for (const p of summary.topPages as Array<{ url?: unknown; views?: unknown }>) {
      const views = num(p?.views)
      if (typeof p?.url !== 'string' || views === null || !isSitePage(p.url)) continue
      const path = pagePath(p.url)
      pages.set(path, (pages.get(path) ?? 0) + views)
    }
  }
  const all = [...pages.entries()].map(([url, views]) => ({ url, views })).sort((a, b) => b.views - a.views || a.url.localeCompare(b.url))
  const visitors = summary ? num(summary.uniqueVisitors) : null
  const pageViews = summary ? num(summary.pageViews) : null
  // Only from the top pages the summary lists, so it's a floor; null when there's no summary to count from.
  const goalViews = goal && summary ? all.filter((p) => p.url.includes(goal.path)).reduce((n, p) => n + p.views, 0) : null
  const days = (series ?? []).map((d) => ({ date: typeof d.date === 'string' ? d.date : '', value: num(d.value) ?? 0 }))
  const peak = days.reduce((m, d) => Math.max(m, d.value), 0)
  return { visitors, pageViews, goalViews, days, peak, topPages: all.slice(0, topN), suggestion: suggest(all, pageViews, goalViews, goal) }
}

/** One observation from the numbers, with what to ask the assistant to do about it. */
export function suggest(pages: ReadonlyArray<{ url: string; views: number }>, pageViews: number | null, goalViews: number | null, goal: AnalyticsGoal | null): AnalyticsView['suggestion'] {
  if (pageViews === null) return null
  if (pageViews === 0) return { text: 'No visits recorded in the last 30 days yet. Once people visit, I can tell you which pages they read.', ask: null }
  const top = pages[0]
  if (!top) return null
  if (goal && goalViews !== null && top.url === '/' && goalViews < pageViews * 0.1) {
    return {
      text: `Most visits land on the home page, but few reach ${goal.name}. Want me to draft a clearer ${goal.name.toLowerCase()} button on the home page, as a change for review?`,
      ask: `Draft a clearer ${goal.name.toLowerCase()} button on the home page, as a change for review.`,
    }
  }
  return {
    text: `${top.url === '/' ? 'The home page' : top.url} is your most visited page (${top.views} ${top.views === 1 ? 'view' : 'views'}). Want me to suggest one change that helps visitors take the next step?`,
    ask: `Look at ${top.url === '/' ? 'the home page' : top.url} and suggest one change, as a draft for review, that helps visitors take the next step.`,
  }
}

/** Bar height in px for a day (at least 2px for a recorded day, so it isn't lost). */
export function barHeight(value: number, peak: number, max = 90): number {
  if (!peak || value <= 0) return 0
  return Math.max(2, Math.round((value / peak) * max))
}
