/**
 * Waiting for the assistant's draft on a phone (pure; asserted by
 * draft-wait.assert.ts). The person always sees what's happening, from what
 * has actually arrived — "Reading your notes…", "Filling in the details…",
 * "Writing the story…" — and after a soft timeout is offered "Keep waiting"
 * or "Fill it in myself" (prefilled with whatever is already drafted). The
 * wait never blocks: choosing to fill it in ends it at once.
 */

export const SOFT_TIMEOUT_MS = 30_000

export type DraftPhase = 'photos' | 'notes' | 'details' | 'story'

export interface DraftWait {
  startedAt: number
  /** The choice is offered once now passes this; "Keep waiting" moves it on. */
  patientUntil: number
}

/** What has been drafted so far. */
export interface PartialDraft {
  fields?: Record<string, unknown>
  story?: unknown[]
}

export interface WaitView {
  phase: DraftPhase
  message: string
  /** Show "Keep waiting" / "Fill it in myself". */
  offerChoice: boolean
  seconds: number
}

export function startWait(now: number, softMs = SOFT_TIMEOUT_MS): DraftWait {
  return { startedAt: now, patientUntil: now + softMs }
}

export function keepWaiting(w: DraftWait, now: number, softMs = SOFT_TIMEOUT_MS): DraftWait {
  return { ...w, patientUntil: now + softMs }
}

const filled = (v: unknown) => v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && v.length === 0)

/** The phase from what has really arrived (never a timer pretending). */
export function draftPhase(partial: PartialDraft | null | undefined, photosWaiting = 0): DraftPhase {
  if (photosWaiting > 0) return 'photos'
  if (partial?.story?.some((p) => typeof p === 'string' && p.trim())) return 'story'
  if (partial?.fields && Object.values(partial.fields).some(filled)) return 'details'
  return 'notes'
}

const MESSAGES: Record<DraftPhase, string> = {
  photos: 'Sending your photos…',
  notes: 'Reading your notes…',
  details: 'Filling in the details…',
  story: 'Writing the story…',
}

export function waitView(w: DraftWait, now: number, partial: PartialDraft | null | undefined, opts: { online?: boolean; photosWaiting?: number } = {}): WaitView {
  const phase = draftPhase(partial, opts.photosWaiting)
  const seconds = Math.max(0, Math.floor((now - w.startedAt) / 1000))
  const offerChoice = now >= w.patientUntil
  if (opts.online === false) {
    return { phase, message: 'No signal — the draft will be made when you’re back online. Your notes are kept on this phone.', offerChoice: true, seconds }
  }
  return { phase, message: offerChoice ? `${MESSAGES[phase]} This is taking longer than usual.` : MESSAGES[phase], offerChoice, seconds }
}
