/**
 * The phone admin's navigation (shared ADE core; the host app supplies the
 * hrefs): five bottom tabs — Today · Review · Ask (centre) · Inbox · Manage —
 * and the Manage hub (every admin area this person may open, grouped from
 * the nav manifest plus screens the app registers, four pins, search).
 *
 * Pure; asserted by nav.assert.ts. RBAC is applied before items reach here
 * (the shell passes the already-filtered menu), so nothing here decides access.
 */

/** Phones: below this width the admin uses the phone shell. */
export const PHONE_BELOW = 768

export function isPhoneWidth(width: number): boolean {
  return width > 0 && width < PHONE_BELOW
}

/** A phone turned sideways (844×390) is wide but short: still the phone admin. */
export const PHONE_LANDSCAPE_MAX_H = 500

/** Phone layout for this viewport: narrow, or short and landscape (a phone on its side). */
export function isPhoneViewport(width: number, height: number): boolean {
  return isPhoneWidth(width) || (height > 0 && height <= PHONE_LANDSCAPE_MAX_H && width > height)
}

/** The same rule as a media query (useIsPhone, CSS). */
export const PHONE_MEDIA_QUERY = `(max-width: ${PHONE_BELOW - 1}px), (max-height: ${PHONE_LANDSCAPE_MAX_H}px) and (orientation: landscape)`

export type TabId = 'today' | 'review' | 'ask' | 'inbox' | 'manage'

/** Where each tab goes in this app (Ask opens the assistant sheet, so it has none). */
export interface MobileTabHrefs {
  today: string
  review: string
  inbox: string
  manage: string
  /** The Ask tab's full-screen chat; without one, Ask opens the sheet. Elsewhere the assistant is always the sheet. */
  ask?: string
}

export interface MobileTab {
  id: TabId
  label: string
  /** null: Ask opens the assistant sheet (no full-screen Ask route configured). */
  href: string | null
  /** Lucide icon name (the host maps names to icons). */
  icon: string
}

export function mobileTabs(hrefs: MobileTabHrefs): MobileTab[] {
  return [
    { id: 'today', label: 'Today', href: hrefs.today, icon: 'House' },
    { id: 'review', label: 'Review', href: hrefs.review, icon: 'ClipboardCheck' },
    { id: 'ask', label: 'Ask', href: hrefs.ask ?? null, icon: 'Sparkles' },
    { id: 'inbox', label: 'Inbox', href: hrefs.inbox, icon: 'Inbox' },
    { id: 'manage', label: 'Manage', href: hrefs.manage, icon: 'LayoutGrid' },
  ]
}

const norm = (p: string) => (p.split(/[?#]/)[0].replace(/\/+$/, '') || '/').toLowerCase()
const under = (path: string, href: string) => path === href || path.startsWith(`${href}/`)

/**
 * The tab a screen belongs to: its own tab, else Manage (every other admin
 * screen is reached from there). Outside the admin: none.
 */
export function activeTab(pathname: string, hrefs: MobileTabHrefs, adminRoot = '/admin'): TabId | null {
  const path = norm(pathname)
  for (const id of ['today', 'review', 'inbox', 'manage', 'ask'] as const) {
    const h = hrefs[id]
    if (h && under(path, norm(h))) return id
  }
  return under(path, norm(adminRoot)) ? 'manage' : null
}

/**
 * What the Ask tab does here: on a CMS screen (anything that isn't a tab's
 * own screen) it pulls the assistant up as a sheet OVER that screen, so it
 * can see and point at it; on the tab screens it opens the full-screen Ask.
 * Without an Ask route it is always the sheet.
 */
export function askOpensSheet(pathname: string, hrefs: MobileTabHrefs): boolean {
  if (!hrefs.ask) return true
  const t = activeTab(pathname, hrefs)
  return t === 'manage' && norm(pathname) !== norm(hrefs.manage)
}

/**
 * Pull down to refresh: only on the four tab screens themselves (Today,
 * Review, Inbox, Manage) — not the Ask chat, not a CMS screen (Safari keeps
 * its own pull there).
 */
export function pullRefreshHere(pathname: string, hrefs: MobileTabHrefs): boolean {
  const path = norm(pathname)
  return (['today', 'review', 'inbox', 'manage'] as const).some((id) => norm(hrefs[id]) === path)
}

// ── Screens the app registers (Manage lists them with the menu) ──────

/** What a badge loader gets (the shell supplies the person's checks). */
export interface MobileContext {
  can: (permission: string) => boolean
  roles: readonly string[]
}

/**
 * A phone screen an app or lane adds. Screens are ROUTES (convention:
 * /admin/m/<id>); the phone shell wraps every admin route, so a page there
 * is full-screen under the tabs automatically. Listed in Manage unless it
 * is a tab's root.
 */
export interface MobileScreen {
  id: string
  label: string
  href: string
  /** This screen is a tab's root (Review deck, Inbox…): the tab opens it instead of the app-config href. */
  tab?: TabId
  /** A count on the tab / Manage row (null or 0 = none). */
  badge?: (ctx: MobileContext) => Promise<number | null>
  /** Manage group heading ("Sell", "Make", "Site"…); a new group when the menu has none of that name. */
  group: string
  icon?: string
  /** Shown with a laptop mark: it opens, but works best on a computer. */
  desktopOnly?: boolean
  /** Permission needed to see it (checked by the shell with the person's RBAC). */
  permission?: string
  /** Roles it is for (role-based home); none = everyone who passes `permission`. */
  roles?: readonly string[]
  /** Extra words search should match ("stock", "write off"). */
  keywords?: readonly string[]
  /** A menu area this screen stands in for on a phone (Analytics → the phone's Analytics): Manage's row opens this instead. */
  replaces?: string
}

const registry = new Map<string, MobileScreen>()

/** Called by an app (e.g. BYB: inventory, fulfil, photo-to-listing) at module load. Same id replaces. */
export function registerMobileScreen(screen: MobileScreen): void {
  registry.set(screen.id, screen)
}

export function mobileScreens(): MobileScreen[] {
  return [...registry.values()]
}

/** The tab hrefs: the app's, with any registered tab-root screen taking its tab. */
export function tabHrefs(defaults: MobileTabHrefs, screens: readonly MobileScreen[]): MobileTabHrefs {
  const out = { ...defaults }
  for (const s of screens) if (s.tab) out[s.tab] = s.href
  return out
}

// ── Actions (a hero button in Manage, a quick action on Today, a suggestion in Ask) ──

export type ActionPlacement = 'manage-hero' | 'today' | 'ask-suggestion'

export interface MobileAction {
  id: string
  label: string
  icon?: string
  /** Open a screen… */
  href?: string
  /** …or ask the assistant this (opens the sheet). */
  askText?: string
  permission?: string
  roles?: readonly string[]
  placement: ActionPlacement
}

const actionRegistry = new Map<string, MobileAction>()

/** e.g. Dzidzor: { id: 'new-initiative', label: 'New initiative', href: '/admin/m/initiatives/new', placement: 'manage-hero' }. */
export function registerMobileAction(action: MobileAction): void {
  actionRegistry.set(action.id, action)
}

/** Actions for a place that this person may use, in registration order. */
export function mobileActions(placement: ActionPlacement, can: (p: string) => boolean, roles: readonly string[], all: readonly MobileAction[] = [...actionRegistry.values()]): MobileAction[] {
  return all.filter((a) => a.placement === placement && (!a.permission || can(a.permission)) && (!a.roles?.length || a.roles.some((r) => roles.includes(r))))
}

/** Registered screens this person may open (the shell passes its RBAC check). */
export function allowedScreens(screens: readonly MobileScreen[], can: (permission: string) => boolean, roles: readonly string[]): MobileScreen[] {
  return screens.filter((s) => (!s.permission || can(s.permission)) && (!s.roles?.length || s.roles.some((r) => roles.includes(r))))
}

// ── Manage hub ───────────────────────────────────────────────────────

export interface MenuGroupIn {
  name: string
  items: ReadonlyArray<{ name: string; href: string; icon?: unknown }>
}

export interface ManageItem {
  name: string
  href: string
  /** Lucide icon name when known. */
  icon?: string
  group: string
  desktopOnly: boolean
  keywords: readonly string[]
  /** Opens outside the admin (the live site), in a new tab. */
  external?: boolean
}

export interface ManageGroup {
  name: string
  items: ManageItem[]
}

/**
 * Every area this person may open: the (already permission-filtered,
 * relabelled) menu, then registered screens — into their named group, or a
 * new one. Each href appears once (the menu's label wins). Desktop-only
 * areas are marked, not hidden.
 */
export function manageGroups(menu: readonly MenuGroupIn[], screens: readonly MobileScreen[], desktopOnly: readonly string[], hide: readonly string[] = []): ManageGroup[] {
  const desk = new Set(desktopOnly.map(norm))
  const hidden = new Set(hide.map(norm))
  const seen = new Set<string>()
  // Phone screens standing in for a menu area take its row (the menu's label and place).
  const swap = new Map(screens.filter((s) => s.replaces).map((s) => [norm(s.replaces!), s] as const))
  const groups: ManageGroup[] = []
  const groupFor = (name: string) => {
    let g = groups.find((x) => x.name === name)
    if (!g) groups.push((g = { name, items: [] }))
    return g
  }
  for (const mg of menu) {
    for (const it of mg.items) {
      const sub = swap.get(norm(it.href))
      const href = sub ? sub.href : it.href
      const key = norm(href)
      if (seen.has(key) || hidden.has(key)) continue
      seen.add(key)
      groupFor(mg.name).items.push({ name: it.name, href, icon: typeof it.icon === 'string' ? it.icon : undefined, group: mg.name, desktopOnly: !!sub?.desktopOnly || (!sub && desk.has(key)), keywords: sub?.keywords ?? [] })
    }
  }
  for (const s of screens) {
    if (s.tab) continue
    const key = norm(s.href)
    if (seen.has(key) || hidden.has(key)) continue
    seen.add(key)
    groupFor(s.group).items.push({ name: s.label, href: s.href, icon: s.icon, group: s.group, desktopOnly: !!s.desktopOnly || desk.has(key), keywords: s.keywords ?? [] })
  }
  return groups.filter((g) => g.items.length > 0)
}

/** The app's own short list for Manage: groups in order, each naming its areas in order. */
export interface ManageLayoutGroup {
  name: string
  /** Area hrefs; SITE_ROW places "View your site". */
  hrefs: readonly string[]
}

/** Stands for the "View your site" row in a layout. */
export const SITE_ROW = '@site'

/**
 * Manage in the app's order: each layout group lists the areas it names that
 * this person has (in that order), then every other area goes under `more`
 * (nothing is dropped). "View your site" sits where the layout puts SITE_ROW,
 * else in a last group of its own. No layout: the menu's own groups.
 */
export function arrangeManage(
  groups: readonly ManageGroup[],
  layout: readonly ManageLayoutGroup[],
  opts: { more: string; site?: { label: string; href: string; group?: string } }
): ManageGroup[] {
  const site = (group: string): ManageItem | null =>
    opts.site ? { name: opts.site.label, href: opts.site.href, group, desktopOnly: false, keywords: ['site', 'live', 'website', 'view'], external: true } : null
  const all = groups.flatMap((g) => g.items)
  const byHref = new Map(all.map((it) => [norm(it.href), it] as const))
  const used = new Set<string>()
  const out: ManageGroup[] = []
  let placedSite = false
  for (const lg of layout) {
    const items: ManageItem[] = []
    for (const h of lg.hrefs) {
      if (h === SITE_ROW) {
        const it = site(lg.name)
        if (it && !placedSite) items.push(it)
        placedSite = true
        continue
      }
      const it = byHref.get(norm(h))
      if (!it || used.has(norm(h))) continue
      used.add(norm(h))
      items.push({ ...it, group: lg.name })
    }
    if (items.length) out.push({ name: lg.name, items })
  }
  if (!layout.length) out.push(...groups.map((g) => ({ name: g.name, items: [...g.items] })))
  else {
    const rest = all.filter((it) => !used.has(norm(it.href))).map((it) => ({ ...it, group: opts.more }))
    if (rest.length) out.push({ name: opts.more, items: rest })
  }
  if (!placedSite) {
    const name = opts.site?.group ?? 'Site'
    const it = site(name)
    if (it) out.push({ name, items: [it] })
  }
  return out
}

// ── Counts on Manage rows ("Initiatives 5") ──────────────────────────

export interface ManageCount {
  href: string
  permission?: string
  load: (ctx: MobileContext) => Promise<number | null>
}

const countRegistry = new Map<string, ManageCount>()

/** e.g. Dzidzor: the number of initiatives on the Initiatives row. Same href replaces. */
export function registerManageCount(count: ManageCount): void {
  countRegistry.set(norm(count.href), count)
}

/** Count loaders this person may run. */
export function manageCounts(can: (permission: string) => boolean): ManageCount[] {
  return [...countRegistry.values()].filter((c) => !c.permission || can(c.permission))
}

/** A row's count key (the same normalising the registry uses). */
export const manageKey = norm

const fold = (s: string) => s.normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase()

/**
 * "Go to… or ask": areas whose name, group, keywords or the owner's own
 * words (vocabulary) contain every word typed. No match → the shell offers
 * to ask the assistant with the same words.
 */
export function searchManage(groups: readonly ManageGroup[], query: string, vocabulary: Readonly<Record<string, readonly string[]>> = {}): ManageItem[] {
  const words = fold(query).split(/\s+/).filter(Boolean)
  if (!words.length) return []
  const all = groups.flatMap((g) => g.items)
  return all.filter((it) => {
    const hay = fold([it.name, it.group, ...it.keywords, ...(vocabulary[it.href] ?? [])].join(' '))
    return words.every((w) => hay.includes(w))
  })
}

export const MAX_PINS = 4

/**
 * The four pinned areas: the person's own pins that still exist for them,
 * topped up from the app's defaults (then the first areas), never more than four.
 */
export function resolvePins(saved: readonly unknown[] | null | undefined, groups: readonly ManageGroup[], defaults: readonly string[]): ManageItem[] {
  const byHref = new Map(groups.flatMap((g) => g.items).map((it) => [norm(it.href), it] as const))
  const out: ManageItem[] = []
  const add = (href: unknown) => {
    if (typeof href !== 'string' || out.length >= MAX_PINS) return
    const it = byHref.get(norm(href))
    if (it && !out.includes(it)) out.push(it)
  }
  ;(saved ?? []).forEach(add)
  defaults.forEach(add)
  for (const it of byHref.values()) add(it.href)
  return out
}

/** Pin or unpin an area (newest pin last); at most four — pinning a fifth drops the oldest. */
export function togglePin(pins: readonly string[], href: string): string[] {
  const key = norm(href)
  if (pins.some((p) => norm(p) === key)) return pins.filter((p) => norm(p) !== key)
  return [...pins, href].slice(-MAX_PINS)
}

/** Stored pins (untrusted JSON): admin paths only, de-duplicated, at most four. */
export function cleanPins(raw: unknown): string[] {
  if (!Array.isArray(raw)) return []
  const out: string[] = []
  for (const p of raw) {
    if (typeof p !== 'string' || !/^\/admin(\/[\w\-/]*)?$/.test(p) || p.length > 120) continue
    if (!out.some((o) => norm(o) === norm(p))) out.push(p)
  }
  return out.slice(0, MAX_PINS)
}
