/**
 * What Ask opens with on a phone: ONE short card — a greeting and the single
 * most useful next action — never the full briefing (that lives on Today).
 * Order: a change waiting for your approval, then something that needs a
 * look, then a draft to decide, then a message; nothing open → just the
 * greeting and an invitation. Pure; asserted by ask-opener.assert.ts.
 */

export interface OpenerItem {
  kind: 'approval' | 'task'
  /** To-do lane: approve · attention · drafts · messages · done… */
  lane: string
  title: string
  href?: string | null
  /** Higher first among tasks. */
  priority?: number
}

export interface AskOpener {
  greeting: string
  /** The one thing to do next, or null when nothing is waiting. */
  action: { label: string; href: string } | null
  /** What the card says under the greeting. */
  line: string
}

export function greetingFor(name: string | null, hour: number): string {
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'
  return name ? `${greet}, ${name}.` : `${greet}.`
}

const clip = (s: string, n = 60) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s)

/** `reviewHref`: where approvals are decided on this device (the Review tab). */
export function askOpener(name: string | null, hour: number, items: readonly OpenerItem[], reviewHref: string): AskOpener {
  const greeting = greetingFor(name, hour)
  const open = items.filter((i) => i.lane !== 'done')
  const approvals = open.filter((i) => i.kind === 'approval' && i.lane === 'approve')
  if (approvals.length) {
    const more = approvals.length - 1
    return {
      greeting,
      line: more ? `${clip(approvals[0]!.title)} is waiting for your OK (and ${more} more).` : `${clip(approvals[0]!.title)} is waiting for your OK.`,
      action: { label: approvals.length === 1 ? 'Review it' : `Review ${approvals.length} changes`, href: reviewHref },
    }
  }
  const byPriority = (a: OpenerItem, b: OpenerItem) => (b.priority ?? 0) - (a.priority ?? 0)
  for (const lane of ['attention', 'drafts', 'messages'] as const) {
    const next = open.filter((i) => i.lane === lane && i.href).sort(byPriority)[0]
    if (next) return { greeting, line: `${clip(next.title)}.`, action: { label: 'Open it', href: next.href! } }
  }
  return { greeting, line: 'Nothing is waiting on you. Ask me anything about your site.', action: null }
}
