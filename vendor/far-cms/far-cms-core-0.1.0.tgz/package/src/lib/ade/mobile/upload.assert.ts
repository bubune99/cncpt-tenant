/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/upload.assert.ts
 */
import assert from 'node:assert/strict'
import { runPhotoUpload, UploadError, type UploadState } from './upload'

let n = 0
const check = async (name: string, fn: () => Promise<void>) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }
const E = { presign: '/api/media', complete: '/api/media' }
const res = (status: number, body: unknown = {}) => new Response(JSON.stringify(body), { status })

;(async () => {
  await check('a dropped PUT resumes at PUT with the same address; complete runs once', async () => {
    const calls: string[] = []
    let putFails = 1
    const fakeFetch = async (url: string, init?: RequestInit) => {
      const body = typeof init?.body === 'string' ? JSON.parse(init.body) : null
      calls.push(`${init?.method} ${body?.action ?? url}`)
      if (body?.action === 'presign') return res(200, { uploadUrl: 'https://r2/put/abc', publicUrl: 'https://cdn/abc.jpg', key: 'uploads/abc.jpg' })
      if (url === 'https://r2/put/abc') return putFails-- > 0 ? res(503) : res(200)
      if (body?.action === 'complete') return res(201, { id: 'm1', url: 'https://cdn/abc.jpg' })
      return res(404)
    }
    let saved: UploadState = { step: 'presign' }
    const job = { file: new Blob(['x']), name: 'a.jpg', type: 'image/jpeg' }
    await assert.rejects(runPhotoUpload(job, saved, (s) => { saved = s }, E, fakeFetch as never), (e: unknown) => e instanceof UploadError && e.retryable)
    assert.equal(saved.step, 'put')
    const media = await runPhotoUpload(job, saved, (s) => { saved = s }, E, fakeFetch as never)
    assert.deepEqual(media, { id: 'm1', url: 'https://cdn/abc.jpg' })
    assert.deepEqual(calls, ['POST presign', 'PUT https://r2/put/abc', 'PUT https://r2/put/abc', 'POST complete'])
  })

  await check('a 4xx is not retryable (the queue stops and says why)', async () => {
    const fakeFetch = async () => res(413)
    await assert.rejects(runPhotoUpload({ file: new Blob(['x']), name: 'a.jpg', type: 'image/jpeg' }, { step: 'presign' }, () => {}, E, fakeFetch as never), (e: unknown) => e instanceof UploadError && !e.retryable)
  })

  await check('a finished upload is never redone', async () => {
    const fakeFetch = async () => { throw new Error('no network calls expected') }
    const done: UploadState = { step: 'done', media: { id: 'm9', url: 'u' } }
    assert.deepEqual(await runPhotoUpload({ file: new Blob(['x']), name: 'a', type: 'image/jpeg' }, done, () => {}, E, fakeFetch as never), { id: 'm9', url: 'u' })
  })

  console.log(`\n${n} checks passed`)
})()
