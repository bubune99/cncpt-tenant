/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/analytics.assert.ts
 */
import assert from 'node:assert/strict'
import { analyticsView, barHeight, isSitePage, suggest } from './analytics'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}

const GOAL = { path: '/donate', label: 'donate views', name: 'Donate' }
const SUMMARY = {
  pageViews: 203,
  uniqueVisitors: 26,
  topPages: [
    { url: '/', views: 14 },
    { url: '/initiatives/akuse-hospital', views: 9 },
    { url: '/?utm_source=ig', views: 2 },
    { url: '/admin/pages', views: 40 },
    { url: '/about?ade-preview=1', views: 5 },
    { url: '/initiatives', views: 4 },
    { url: '/donate', views: 4 },
  ],
}

const v = analyticsView(SUMMARY, [{ date: 'Oct 1', value: 3 }, { date: 'Oct 2', value: 12 }, { date: 'Oct 3', value: 0 }], GOAL)
eq([v.visitors, v.pageViews, v.goalViews], [26, 203, 4])
eq(v.topPages, [{ url: '/', views: 16 }, { url: '/initiatives/akuse-hospital', views: 9 }, { url: '/donate', views: 4 }], 'admin + previews out; query variants are one page')
eq(v.peak, 12)
eq(v.days.length, 3)
eq(v.suggestion?.ask, 'Draft a clearer donate button on the home page, as a change for review.', 'home page busiest, few reach Donate')

// Unknown stays unknown — never zero or an example
const none = analyticsView(null, null, GOAL)
eq([none.visitors, none.pageViews, none.goalViews, none.peak, none.topPages.length, none.suggestion], [null, null, null, 0, 0, null])
eq(analyticsView({ pageViews: 'x', uniqueVisitors: -1, topPages: 'nope' }, [], GOAL).visitors, null, 'bad numbers are unknown')

// Suggestions
eq(suggest([], 0, 0, GOAL)?.ask, null, 'nothing recorded: say so, ask nothing')
eq(suggest([{ url: '/', views: 10 }], 100, 50, GOAL)?.text.startsWith('The home page is your most visited page (10 views)'), true, 'enough reach Donate: the generic note')
eq(suggest([{ url: '/blog/x', views: 1 }], 1, null, null)?.text.startsWith('/blog/x is your most visited page (1 view)'), true)

// Bars and filters
eq([barHeight(0, 10), barHeight(10, 10), barHeight(1, 1000), barHeight(5, 0)], [0, 90, 2, 0])
eq([isSitePage('/'), isSitePage('/admin'), isSitePage('/x?preview=1'), isSitePage('/admin-tips')], [true, false, false, true])

console.log(`${n} assertions passed`)
