/**
 * Phone → desktop handoff (pure, app-agnostic): work started on the phone
 * shows on desktop as "You started 1 initiative on your phone", opening the
 * same draft and the same conversation. The host stores handoffs (Dzidzor:
 * ade_handoffs) keyed by draft (change set) + conversation. Asserted by
 * mobile.assert.ts.
 */

export interface Handoff {
  id: string
  kind: string
  title: string
  device: 'phone' | 'desktop'
  changeSetId: string | null
  conversationId: string | null
  href: string | null
  status: 'open' | 'picked' | 'dismissed'
  createdAt: string
}

/** Noun per kind, singular/plural (the host can add its own). */
export const HANDOFF_NOUNS: Record<string, [string, string]> = {
  initiative: ['initiative', 'initiatives'],
  listing: ['listing', 'listings'],
  'page-edit': ['page edit', 'page edits'],
  link: ['thing to finish', 'things to finish'],
}

/** The card's headline: "You started 2 initiatives on your phone" (open phone handoffs only). */
export function pickupHeadline(handoffs: readonly Handoff[], nouns: Record<string, [string, string]> = HANDOFF_NOUNS): string | null {
  const open = handoffs.filter((h) => h.status === 'open' && h.device === 'phone')
  if (!open.length) return null
  const kinds = [...new Set(open.map((h) => h.kind))]
  if (kinds.length === 1) {
    const [one, many] = nouns[kinds[0]] ?? [kinds[0], `${kinds[0]}s`]
    return `You started ${open.length === 1 ? `1 ${one}` : `${open.length} ${many}`} on your phone`
  }
  return `You started ${open.length} things on your phone`
}

/** Where "Continue" goes: the draft, with ?thread= so the same conversation opens in the assistant. */
export function continueHref(h: Pick<Handoff, 'href' | 'conversationId'>): string | null {
  if (!h.href) return null
  if (!h.conversationId) return h.href
  const sep = h.href.includes('?') ? '&' : '?'
  return `${h.href}${sep}thread=${encodeURIComponent(h.conversationId)}`
}
