/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/ask-opener.assert.ts
 */
import assert from 'node:assert/strict'
import { askOpener, greetingFor, type OpenerItem } from './ask-opener'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const R = '/admin/m/review'

check('one card: a greeting and ONE next action — a waiting change first (seen: the full briefing, 7 things + a grid)', () => {
  const items: OpenerItem[] = [
    { kind: 'task', lane: 'attention', title: 'Ship order #12', href: '/admin/orders/12', priority: 9 },
    { kind: 'approval', lane: 'approve', title: 'Page edit · Heading' },
    { kind: 'approval', lane: 'approve', title: 'Initiative update' },
    { kind: 'task', lane: 'messages', title: '2 new replies', href: '/admin/m/inbox' },
  ]
  const o = askOpener('Bubune', 15, items, R)
  assert.equal(o.greeting, 'Good afternoon, Bubune.')
  assert.equal(o.line, 'Page edit · Heading is waiting for your OK (and 1 more).')
  assert.deepEqual(o.action, { label: 'Review 2 changes', href: R })
  assert.deepEqual(Object.keys(o).sort(), ['action', 'greeting', 'line'], 'nothing else: no counts, no grid, no list')
})

check('no approvals: the most important thing that needs a look, then drafts, then messages', () => {
  const o = askOpener(null, 9, [
    { kind: 'task', lane: 'messages', title: '2 new replies', href: '/admin/m/inbox' },
    { kind: 'task', lane: 'attention', title: 'Low stock', href: '/admin/products', priority: 2 },
    { kind: 'task', lane: 'attention', title: 'Ship order #12', href: '/admin/orders/12', priority: 9 },
  ], R)
  assert.equal(o.greeting, 'Good morning.')
  assert.deepEqual([o.line, o.action], ['Ship order #12.', { label: 'Open it', href: '/admin/orders/12' }])
  assert.deepEqual(askOpener(null, 9, [{ kind: 'task', lane: 'messages', title: '2 new replies', href: '/admin/m/inbox' }], R).action, { label: 'Open it', href: '/admin/m/inbox' })
})

check('nothing open: just the greeting and an invitation, no button', () => {
  const o = askOpener('Ama', 20, [{ kind: 'approval', lane: 'done', title: 'old' }, { kind: 'task', lane: 'attention', title: 'no link', href: null }], R)
  assert.deepEqual(o, { greeting: 'Good evening, Ama.', line: 'Nothing is waiting on you. Ask me anything about your site.', action: null })
  assert.equal(greetingFor(null, 11), 'Good morning.')
})

console.log(`\n${n} checks passed`)
