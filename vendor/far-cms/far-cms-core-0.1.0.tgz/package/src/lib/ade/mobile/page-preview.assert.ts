/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/page-preview.assert.ts
 */
import assert from 'node:assert/strict'
import { DEVICE_WIDTH, fitScale, isLandscapePhone, partKind, pinchZoom, previewSrc, selectionLabel, zoomLabel } from './page-preview'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('After is the proposed version (all waiting drafts); Before is live, or nothing for a page not live yet', () => {
  assert.equal(previewSrc({ slug: '/about', status: 'published' }, 'after'), '/ade-preview/about')
  assert.equal(previewSrc({ slug: 'about', status: 'published' }, 'before'), '/about')
  assert.equal(previewSrc({ slug: '/', status: 'published' }, 'after'), '/ade-preview')
  assert.equal(previewSrc({ slug: '/new-page', status: 'draft' }, 'before'), null)
})

check('the real widths, fitted to the room (sideways: the 1440 desktop page in ~800px ≈ 56%)', () => {
  assert.deepEqual(DEVICE_WIDTH, { phone: 390, tablet: 820, desktop: 1440 })
  assert.equal(fitScale('phone', 358), 358 / 390)
  assert.equal(fitScale('phone', 500), 1, 'never above 100%')
  assert.equal(Math.round(fitScale('desktop', 806) * 100), 56)
  assert.equal(zoomLabel(fitScale('desktop', 806), 1), '56%')
  assert.equal(fitScale('tablet', 0), 1)
})

check('pinch keeps the zoom between fit and 4× (the shared gesture rule)', () => {
  assert.equal(pinchZoom(1, 100, 200), 2)
  assert.equal(pinchZoom(2, 100, 400), 4)
  assert.equal(pinchZoom(1.5, 100, 20), 1)
  assert.equal(pinchZoom(1.5, 0, 50), 1.5)
})

check('sideways on a phone vs a tablet or desktop', () => {
  assert.equal(isLandscapePhone(844, 390), true)
  assert.equal(isLandscapePhone(390, 844), false)
  assert.equal(isLandscapePhone(1180, 820), false, 'a tablet in landscape is not a phone')
})

check('the selected part’s chip and label', () => {
  assert.equal(partKind('h1', false, true), 'Text')
  assert.equal(partKind('img', true, false), 'Photo')
  assert.equal(partKind('a', false, true), 'Button')
  assert.equal(partKind('section', true, true), 'Section')
  assert.equal(partKind('div', false, true), 'Text')
  assert.equal(selectionLabel('About Project Dzidzor', 'Section'), '“About Project Dzidzor” section selected')
  assert.equal(selectionLabel('  ', 'Photo'), 'Photo selected')
  assert.match(selectionLabel('Care, supplies and people for communities across Ghana.', 'Text'), /^“Care, supplies and people for…” text selected$/)
})

console.log(`\n${n} checks passed`)
