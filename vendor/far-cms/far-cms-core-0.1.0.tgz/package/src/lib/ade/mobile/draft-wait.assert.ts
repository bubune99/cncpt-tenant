/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/draft-wait.assert.ts
 */
import assert from 'node:assert/strict'
import { draftPhase, keepWaiting, SOFT_TIMEOUT_MS, startWait, waitView } from './draft-wait'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const T = 1_760_000_000_000

check('the message follows what has really arrived: photos → notes → details → story', () => {
  assert.equal(draftPhase(null, 2), 'photos')
  assert.equal(draftPhase(null), 'notes')
  assert.equal(draftPhase({ fields: { name: '' } }), 'notes', 'an empty field is not progress')
  assert.equal(draftPhase({ fields: { name: 'Water for Ada' } }), 'details')
  assert.equal(draftPhase({ fields: { name: 'Water for Ada' }, story: ['Families walk an hour'] }), 'story')
  const w = startWait(T)
  assert.equal(waitView(w, T + 2_000, null).message, 'Reading your notes…')
  assert.equal(waitView(w, T + 4_000, { story: ['x'] }).message, 'Writing the story…')
})

check('no choice before the soft timeout; at 30 s "Keep waiting" / "Fill it in myself" appear', () => {
  const w = startWait(T)
  assert.equal(waitView(w, T + SOFT_TIMEOUT_MS - 1, null).offerChoice, false)
  const v = waitView(w, T + SOFT_TIMEOUT_MS, { fields: { name: 'A' } })
  assert.equal(v.offerChoice, true)
  assert.equal(v.message, 'Filling in the details… This is taking longer than usual.')
  assert.equal(v.seconds, 30)
})

check('"Keep waiting" hides the choice for another 30 s, then offers it again', () => {
  const w = keepWaiting(startWait(T), T + 31_000)
  assert.equal(waitView(w, T + 40_000, null).offerChoice, false)
  assert.equal(waitView(w, T + 61_000, null).offerChoice, true)
  assert.equal(waitView(w, T + 61_000, null).seconds, 61, 'time counts from the start, not the last choice')
})

check('offline: says so and offers filling it in straight away (the notes stay on the phone)', () => {
  const v = waitView(startWait(T), T + 1_000, null, { online: false })
  assert.equal(v.offerChoice, true)
  assert.match(v.message, /No signal/)
})

console.log(`\n${n} checks passed`)
