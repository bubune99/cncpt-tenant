/**
 * The mobile Inbox (owner-approved mobile brief, screen 4): two segments
 * side by side — Customers (the site's own messages: form submissions,
 * shop messages, assistant threads that report back) and My email (the
 * person's mailbox through the email connector, when one is connected).
 * The assistant summarises and drafts replies; a person approves before
 * anything is sent.
 *
 * Pure and app-agnostic; each app supplies its own sources. Asserted by
 * inbox.assert.ts.
 */

export type InboxSegment = 'customers' | 'email'

export interface InboxItem {
  id: string
  segment: InboxSegment
  /** Where it came from, in plain words for the row ("Contact form", "Assistant", "Gmail"). */
  sourceLabel: string
  /** Who it's from (name, else the part of the address before @). */
  from: string
  subject: string
  preview: string
  /** ISO time. */
  at: string
  unread: boolean
  /** Someone is waiting for an answer from you. */
  needsReply: boolean
  /** A reply address exists (a reply can be drafted and sent). */
  canReply: boolean
  href?: string
  /** Some of it is hidden from this person (a confidential area): the screen says names and emails stay private. */
  private?: boolean
}

export interface InboxGroup {
  label: 'Today' | 'Yesterday' | 'This week' | 'Earlier'
  items: InboxItem[]
}

const DAY = 86_400_000

/** Local midnight of `now` (the person's day), as epoch ms. */
function startOfDay(now: Date): number {
  return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()
}

/** Newest first, grouped Today / Yesterday / This week (7 days) / Earlier; empty groups dropped. */
export function groupInbox(items: readonly InboxItem[], now: Date): InboxGroup[] {
  const today = startOfDay(now)
  const order: InboxGroup['label'][] = ['Today', 'Yesterday', 'This week', 'Earlier']
  const buckets = new Map<InboxGroup['label'], InboxItem[]>(order.map((l) => [l, []]))
  const sorted = [...items].sort((a, b) => Date.parse(b.at) - Date.parse(a.at) || a.id.localeCompare(b.id))
  for (const it of sorted) {
    const t = Date.parse(it.at)
    const label: InboxGroup['label'] = t >= today ? 'Today' : t >= today - DAY ? 'Yesterday' : t >= today - 6 * DAY ? 'This week' : 'Earlier'
    buckets.get(label)!.push(it)
  }
  return order.map((label) => ({ label, items: buckets.get(label)! })).filter((g) => g.items.length > 0)
}

export function segmentItems(items: readonly InboxItem[], segment: InboxSegment): InboxItem[] {
  return items.filter((i) => i.segment === segment)
}


const WORDS = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']
const word = (n: number) => WORDS[n] ?? String(n)
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

/** What kind of message this is, from where it came in ("Volunteer With Us" → a volunteer). */
export function messageKind(sourceLabel: string): { one: string; many: string } {
  if (/volunteer/i.test(sourceLabel)) return { one: 'volunteer', many: 'volunteers' }
  if (/donat|give|giving/i.test(sourceLabel)) return { one: 'donation question', many: 'donation questions' }
  if (/contact|question|enquir|inquir|ask/i.test(sourceLabel)) return { one: 'general question', many: 'general questions' }
  if (/newsletter|subscribe/i.test(sourceLabel)) return { one: 'sign-up', many: 'sign-ups' }
  return { one: 'message', many: 'messages' }
}

/**
 * The assistant's line above the list (mock 4): "2 new replies. One
 * volunteer, one general question. I drafted both answers." `draftedByAssistant`
 * = how many of the new ones have a draft the assistant wrote.
 */
export function inboxSummary(items: readonly InboxItem[], draftedByAssistant = 0): string {
  const fresh = items.filter((i) => i.unread)
  const waiting = items.filter((i) => i.needsReply).length
  if (!fresh.length) return waiting ? `No new replies. ${cap(word(waiting))} still ${waiting === 1 ? 'waits' : 'wait'} for an answer.` : 'Nothing new. Everyone has an answer.'
  const head = `${fresh.length} new ${fresh.length === 1 ? 'reply' : 'replies'}.`
  const kinds = new Map<string, { n: number; one: string; many: string }>()
  for (const i of fresh) {
    const k = messageKind(i.sourceLabel)
    const cur = kinds.get(k.one) ?? { n: 0, ...k }
    kinds.set(k.one, { ...cur, n: cur.n + 1 })
  }
  const what = [...kinds.values()].map((k) => `${word(k.n)} ${k.n === 1 ? k.one : k.many}`).join(', ')
  const d = Math.min(draftedByAssistant, fresh.length)
  const drafted = !d ? '' : d === fresh.length ? (d === 1 ? ' I drafted the answer.' : d === 2 ? ' I drafted both answers.' : ` I drafted all ${word(d)} answers.`) : ` I drafted ${word(d)} of the answers.`
  return `${head} ${cap(what)}.${drafted}`
}

/** The two segment tabs, with counts of what needs you. The email tab is shown only when the app enables it. */
/**
 * The segment a link opens on (?tab=email from "my inbox"): My email only
 * when the app has it on; anything else is Customers.
 */
export function segmentFromParam(value: string | null | undefined, emailEnabled: boolean): InboxSegment {
  return value === 'email' && emailEnabled ? 'email' : 'customers'
}

export function inboxTabs(items: readonly InboxItem[], emailEnabled: boolean): Array<{ id: InboxSegment; label: string; count: number }> {
  const needs = (s: InboxSegment) => items.filter((i) => i.segment === s && (i.needsReply || i.unread)).length
  const tabs: Array<{ id: InboxSegment; label: string; count: number }> = [{ id: 'customers', label: 'Form replies', count: needs('customers') }]
  if (emailEnabled) tabs.push({ id: 'email', label: 'My email', count: needs('email') })
  return tabs
}

/** A reply is a draft until a person approves sending it. */
export interface ReplyDraft {
  itemId: string
  to: string
  subject: string
  body: string
  /** Who wrote the draft: the person, or the assistant (the card says so). */
  by: 'you' | 'assistant'
}

/** "Re: <subject>", never "Re: Re:". */
export function replySubject(subject: string): string {
  const s = subject.trim() || 'Your message'
  return /^re:/i.test(s) ? s : `Re: ${s}`
}

/** The words of a reply, checked on their own (the screen doesn't see addresses). */
export function replyBodyProblem(body: string): string | null {
  if (body.trim().length < 2) return 'Write a reply first.'
  if (body.length > 20_000) return 'That reply is too long to send from here.'
  return null
}

/** Checks before a reply can be sent. Returns the problem, or null when it may be sent. */
export function replyProblem(d: Pick<ReplyDraft, 'to' | 'body'>): string | null {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.to.trim())) return 'There’s no email address to reply to.'
  return replyBodyProblem(d.body)
}

/**
 * Asking the assistant to draft a reply to a form reply (C-17): a reference
 * to the message, never its sender, subject or text in the person's own
 * message (addresses in it would count as typed by them). The assistant
 * reads the submission with its forms tools.
 */
export function replyAssistAsk(item: Pick<InboxItem, 'id'>): { prompt: string; refs: Array<{ kind: 'element'; key: string; label: string; tag: string; text: string; screen: string }> } {
  return {
    prompt: 'Draft a reply to this message. Read it with your tools, then put the reply in the reply box (inbox.set_reply_draft). Don’t send it.',
    refs: [{ kind: 'element', key: `inbox:${item.id}`, label: 'Message in the Inbox', tag: 'inbox-message', text: '', screen: 'inbox' }],
  }
}
