/**
 * Mobile Safari in a browser tab (the owner's phone, no installed app):
 * the on-screen keyboard shrinks the VISUAL viewport, not the layout one,
 * so fixed bottom UI (the assistant sheet, the Ask bar) would sit under it.
 * The shell measures the keyboard with the VisualViewport API and lifts
 * that UI by the inset. Pure; asserted in nav.assert.ts.
 */

/** Below this it's Safari's toolbar settling, not a keyboard. */
const KEYBOARD_MIN_PX = 80

/** How far the keyboard covers the bottom of the layout viewport (0 when closed). */
export function keyboardInset(innerHeight: number, visual: { height: number; offsetTop: number } | null): number {
  if (!visual) return 0
  const inset = Math.round(innerHeight - visual.height - visual.offsetTop)
  return inset >= KEYBOARD_MIN_PX ? inset : 0
}
