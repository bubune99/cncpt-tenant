/**
 * Editing a page on a phone by asking (owner, mock 13): a live preview of the
 * real page at Phone / Tablet / Desktop width, Before (live) or After (with
 * the waiting drafts), scaled to fit the room; turned sideways it's the
 * desktop page scaled to fit, scrollable, with pinch to zoom. Tapping a part
 * selects it for the assistant. Pure; asserted by page-preview.assert.ts.
 */

export type PreviewDevice = 'phone' | 'tablet' | 'desktop'
export type PreviewSide = 'before' | 'after'

/** The widths visitors get (desktop as a regular laptop/desktop page). */
export const DEVICE_WIDTH: Record<PreviewDevice, number> = { phone: 390, tablet: 820, desktop: 1440 }

/** Where each side comes from: After = the page with every waiting draft (the proposed version), Before = live. */
export function previewSrc(page: { slug: string; status: string }, side: PreviewSide): string | null {
  const slug = page.slug.startsWith('/') ? page.slug : `/${page.slug}`
  if (side === 'after') return slug === '/' ? '/ade-preview' : `/ade-preview${slug}`
  return page.status === 'published' ? slug : null
}

/** Scale that fits a device's width into the room (never above 100%). */
export function fitScale(device: PreviewDevice, roomWidth: number): number {
  if (!(roomWidth > 0)) return 1
  return Math.min(1, roomWidth / DEVICE_WIDTH[device])
}

/** Pinch uses the shared gesture rule (fit … 4×): lib/ade/mobile/gestures pinchZoom. */
export { pinchZoom } from './gestures'

/** "Pinch to zoom · 56%" — the page's real size shown as a percentage. */
export function zoomLabel(fit: number, zoom: number): string {
  return `${Math.round(fit * zoom * 100)}%`
}

/** Sideways on a phone: wider than tall and short (the shell's phone rule for landscape). */
export function isLandscapePhone(width: number, height: number): boolean {
  return width > height && height > 0 && height <= 500
}

/** The chip on a selected part: what kind of thing it is. */
export function partKind(tag: string, hasImage: boolean, hasText: boolean): 'Text' | 'Photo' | 'Button' | 'Video' | 'Form' | 'Section' {
  const t = tag.toLowerCase()
  if (t === 'img' || t === 'picture' || t === 'figure') return 'Photo'
  if (t === 'video' || t === 'iframe') return 'Video'
  if (t === 'a' || t === 'button') return 'Button'
  if (t === 'form') return 'Form'
  if (/^(h[1-6]|p|span|li|blockquote|label)$/.test(t)) return 'Text'
  if (hasText && !hasImage) return 'Text'
  if (hasImage && !hasText) return 'Photo'
  return 'Section'
}

/** "“About Project Dzidzor” section selected", from the part's heading or first words. */
export function selectionLabel(text: string, kind: string): string {
  const words = text.replace(/\s+/g, ' ').trim()
  if (!words) return `${kind} selected`
  const short = words.length > 32 ? `${words.slice(0, 30).replace(/\s+\S*$/, '')}…` : words
  return `“${short}” ${kind === 'Section' ? 'section' : kind.toLowerCase()} selected`
}
