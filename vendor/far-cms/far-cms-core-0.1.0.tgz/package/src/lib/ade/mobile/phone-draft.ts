/**
 * A record started on the phone, kept on the device so nothing typed or
 * taken is lost to a reload or a dropped signal (pure; asserted by
 * phone-draft.assert.ts). The work itself runs on the offline queue in one
 * group per draft: each photo ('media.upload'), then the assistant's draft,
 * then the save — so the draft always sees every photo that made it.
 *
 *   draftKey            the group, and the save's idempotency key on the server
 *   <draftKey>/p/<key>  a photo
 *   <draftKey>/draft    the assistant's draft (carries the notes)
 *   <draftKey>/save     save as a draft change set
 */

export type PhoneStep = 'capture' | 'drafting' | 'review' | 'preview' | 'saving' | 'saved'

export interface PhoneSession {
  v: 1
  draftKey: string
  type: string
  notes: string
  /** Photos in the order taken, by shot; url/mediaId once uploaded (kept here too — the queue clears finished items). */
  photos: Array<{ key: string; shotId: string; url?: string; mediaId?: string }>
  step: PhoneStep
  /** Voice notes in the order recorded: the words (as transcribed live) and, once uploaded, the audio. */
  voices?: Array<{ key: string; seconds: number; transcript: string; url?: string; mediaId?: string }>
  /** Where the photos were taken, rounded ("near 6.6°N, 0.47°E"), when the person shared it. */
  near?: string
  /** The reviewed draft (fields + story) once there is one. */
  draft?: { data: Record<string, unknown>; story: string[]; suggestions: string[] }
  saved?: { changeSetId: string; path: string }
  updatedAt: number
}

const STEPS: ReadonlySet<string> = new Set(['capture', 'drafting', 'review', 'preview', 'saving', 'saved'])
const KEY = /^[A-Za-z0-9_-]{6,80}$/

/** Device storage key for a type's session (one open draft per kind of record). */
export const sessionStorageKey = (type: string) => `ade.phone-draft.${type}`

export function newDraftKey(type: string, now: number, rand: () => number = Math.random): string {
  return `${type.replace(/[^a-z0-9]/gi, '').slice(0, 20)}-${now.toString(36)}-${Math.floor(rand() * 36 ** 6).toString(36).padStart(6, '0')}`
}

export const photoQueueKey = (draftKey: string, photoKey: string) => `${draftKey}/p/${photoKey}`
export const draftQueueKey = (draftKey: string) => `${draftKey}/draft`
export const saveQueueKey = (draftKey: string) => `${draftKey}/save`
export const voiceQueueKey = (draftKey: string, voiceKey: string) => `${draftKey}/v/${voiceKey}`

export function newSession(type: string, now: number, rand?: () => number): PhoneSession {
  return { v: 1, draftKey: newDraftKey(type, now, rand), type, notes: '', photos: [], step: 'capture', updatedAt: now }
}

/** Read a stored session back; anything malformed, for another type, or older than maxAgeMs starts fresh (null). */
export function parseSession(raw: string | null, type: string, now: number, maxAgeMs = 7 * 86_400_000): PhoneSession | null {
  if (!raw) return null
  let s: unknown
  try {
    s = JSON.parse(raw)
  } catch {
    return null
  }
  if (!s || typeof s !== 'object') return null
  const o = s as Record<string, unknown>
  if (o.v !== 1 || o.type !== type || typeof o.draftKey !== 'string' || !KEY.test(o.draftKey)) return null
  if (typeof o.updatedAt !== 'number' || now - o.updatedAt > maxAgeMs) return null
  const photos = Array.isArray(o.photos)
    ? o.photos
        .filter((p): p is { key: string; shotId: string; url?: unknown; mediaId?: unknown } => !!p && typeof p === 'object' && typeof (p as { key?: unknown }).key === 'string' && typeof (p as { shotId?: unknown }).shotId === 'string')
        .map((p) => ({ key: p.key, shotId: p.shotId, ...(typeof p.url === 'string' && typeof p.mediaId === 'string' ? { url: p.url, mediaId: p.mediaId } : {}) }))
    : []
  const step = typeof o.step === 'string' && STEPS.has(o.step) ? (o.step as PhoneStep) : 'capture'
  const d = o.draft as PhoneSession['draft'] | undefined
  const draft = d && typeof d === 'object' && d.data && typeof d.data === 'object' ? { data: d.data, story: Array.isArray(d.story) ? d.story.filter((x) => typeof x === 'string') : [], suggestions: Array.isArray(d.suggestions) ? d.suggestions.filter((x) => typeof x === 'string') : [] } : undefined
  const sv = o.saved as PhoneSession['saved'] | undefined
  const saved = sv && typeof sv.changeSetId === 'string' && typeof sv.path === 'string' ? { changeSetId: sv.changeSetId, path: sv.path } : undefined
  const voices = Array.isArray(o.voices)
    ? o.voices
        .filter((v): v is { key: string; seconds?: unknown; transcript?: unknown; url?: unknown; mediaId?: unknown } => !!v && typeof v === 'object' && typeof (v as { key?: unknown }).key === 'string')
        .map((v) => ({ key: v.key, seconds: typeof v.seconds === 'number' ? v.seconds : 0, transcript: typeof v.transcript === 'string' ? v.transcript.slice(0, 4000) : '', ...(typeof v.url === 'string' && typeof v.mediaId === 'string' ? { url: v.url, mediaId: v.mediaId } : {}) }))
    : []
  // A review, preview or save step without its draft can't be shown: back to capture.
  const safeStep: PhoneStep = (step === 'review' || step === 'preview' || step === 'saving') && !draft ? 'capture' : step === 'saved' && !saved ? (draft ? 'review' : 'capture') : step
  return { v: 1, draftKey: o.draftKey, type, notes: typeof o.notes === 'string' ? o.notes.slice(0, 6000) : '', photos, ...(voices.length && { voices }), ...(typeof o.near === 'string' && o.near.length < 60 && { near: o.near }), step: safeStep, ...(draft && { draft }), ...(saved && { saved }), updatedAt: o.updatedAt }
}

/**
 * The uploaded photos, in the order given, from the queue's results — or
 * from what the session remembered once the queue has cleared a finished
 * upload; ones not (yet) uploaded are left out.
 */
export function uploadedPhotos(draftKey: string, photoKeys: readonly string[], resultOf: (key: string) => unknown, known: Readonly<Record<string, { url: string; mediaId: string }>> = {}): Array<{ url: string; mediaId: string }> {
  const out: Array<{ url: string; mediaId: string }> = []
  for (const k of photoKeys) {
    const r = resultOf(photoQueueKey(draftKey, k)) as { id?: unknown; url?: unknown } | undefined
    if (r && typeof r.url === 'string' && typeof r.id === 'string') out.push({ url: r.url, mediaId: r.id })
    else if (known[k]) out.push(known[k])
  }
  return out
}

/** What the session knows was uploaded, by photo key. */
export function knownUploads(session: Pick<PhoneSession, 'photos'>): Record<string, { url: string; mediaId: string }> {
  return Object.fromEntries(session.photos.filter((p) => p.url && p.mediaId).map((p) => [p.key, { url: p.url!, mediaId: p.mediaId! }]))
}

/** An HTTP failure from the app's API, with what the queue should do about it. */
export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'ApiError'
  }
}

/** Network trouble, timeouts, rate limits and server errors wait and retry; a refusal (4xx) won't change by retrying. */
export function classifyApiError(e: unknown): 'retry' | 'fail' | 'conflict' {
  if (!(e instanceof ApiError)) return 'retry'
  if (e.status === 409) return 'conflict'
  if (e.status === 408 || e.status === 429 || e.status >= 500) return 'retry'
  return 'fail'
}

/**
 * A row's "is it on the site?" note in the phone's Initiatives list: only
 * a record that isn't PUBLISHED gets one, and it says what it means — the
 * page isn't public yet (a word like "Draft" read as "has a draft change").
 */
export function liveNote(status: string | null | undefined): string | null {
  return status === 'PUBLISHED' ? null : status === 'ARCHIVED' ? 'Archived' : 'Not on the site yet'
}
