/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/send-to-desktop.assert.ts
 */
import assert from 'node:assert/strict'
import { pickupHandoff, safeAdminHref } from './send-to-desktop'
import { pickupHeadline, HANDOFF_NOUNS } from './handoff'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('only admin paths, never another host or a script', () => {
  assert.equal(safeAdminHref('/admin/pages/p1/editor'), '/admin/pages/p1/editor')
  assert.equal(safeAdminHref('/admin?thread=t1'), '/admin?thread=t1')
  assert.equal(safeAdminHref('/admin'), '/admin')
  for (const bad of ['//evil.example/admin', 'https://evil.example/admin', '/administrator', 'javascript:alert(1)', '/admin/x"onload', '/shop']) assert.equal(safeAdminHref(bad), null, bad)
})

check('a phone handoff with a kind the desktop card can name', () => {
  const a = pickupHandoff({ title: '  Finish the   About page layout ', href: '/admin/pages/p1/editor', kind: 'page-edit' }, 'u1')
  assert.deepEqual(a, { ok: true, handoff: { kind: 'page-edit', title: 'Finish the About page layout', href: '/admin/pages/p1/editor', device: 'phone' } })
  const b = pickupHandoff({ title: 'x', href: '/admin', kind: 'Bad Kind!' }, 'u1')
  assert.ok(b.ok && b.handoff.kind === 'link')
  assert.ok(HANDOFF_NOUNS['page-edit'] && HANDOFF_NOUNS.link)
  const card = (kind: string) => pickupHeadline([{ id: '1', kind, title: 't', device: 'phone', changeSetId: null, conversationId: null, href: '/admin', status: 'open', createdAt: '' }])
  assert.equal(card('page-edit'), 'You started 1 page edit on your phone')
  assert.equal(card('link'), 'You started 1 thing to finish on your phone')
})

check('bad input is refused with a plain reason', () => {
  assert.deepEqual(pickupHandoff({ title: 'x', href: 'https://evil.example' }, 'u1'), { ok: false, error: 'That link isn’t an admin screen.' })
  assert.deepEqual(pickupHandoff({ title: '   ', href: '/admin' }, 'u1'), { ok: false, error: 'Say what to pick up.' })
  assert.deepEqual(pickupHandoff({ title: 'x', href: '/admin' }, ''), { ok: false, error: 'Sign in first.' })
})

console.log(`\n${n} checks passed`)
