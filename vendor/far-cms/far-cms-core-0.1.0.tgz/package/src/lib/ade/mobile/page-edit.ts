/**
 * Editing a page on a phone, in its phone layout (owner-approved mobile
 * brief, screen 10): tap a block → Edit text · Photo · Move (among its
 * siblings) · Hide on phone. New sections and layout stay on desktop.
 * Every edit is a draft for review (the screen saves through the editor
 * draft API). Inside a shared section (a partial, or the site header/footer)
 * only "Hide on phone" is offered, and it changes every page that uses it.
 *
 * Pure and app-agnostic: works on the block tree's shape only (the CMS Block
 * type satisfies it). Every function returns a NEW tree; nothing mutates.
 * Asserted by page-edit.assert.ts.
 */

export interface PhoneBlock {
  id: string
  tag: string
  textContent?: string
  attrs?: Record<string, string>
  children?: readonly PhoneBlock[]
  responsive?: { hidden?: { desktop?: boolean; tablet?: boolean; mobile?: boolean } }
  background?: { url: string }
  partialId?: string
  label?: string
  locked?: boolean
}

/** Where the tapped block lives: the page itself, a shared section, or the site header/footer. */
export type EditScope = { kind: 'page'; id: string } | { kind: 'partial'; id: string } | { kind: 'layout'; id: 'header' | 'footer' }

export type PhoneAction = 'text' | 'photo' | 'move-up' | 'move-down' | 'hide' | 'show'

/** The editor-draft API's target key for a scope. */
export function draftTarget(scope: EditScope): string {
  return scope.kind === 'layout' ? `layout:${scope.id}` : `${scope.kind}:${scope.id}`
}

/** Shared sections change every page that uses them; the card must say so. */
export function scopeNotice(scope: EditScope): string | null {
  if (scope.kind === 'page') return null
  const what = scope.kind === 'layout' ? `the site ${scope.id}` : 'this shared section'
  return `This is ${what}: hiding it on phones changes every page that uses it, after review.`
}

const TEXT_TAGS = new Set(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'a', 'button', 'li', 'blockquote', 'figcaption', 'label', 'strong', 'em', 'small', 'cite', 'q', 'dt', 'dd', 'td', 'th'])

export function isHiddenOnPhone(b: PhoneBlock): boolean {
  return b.responsive?.hidden?.mobile === true
}

/** The path of blocks from the root to `id` (inclusive), or null. */
export function pathTo<B extends PhoneBlock>(blocks: readonly B[], id: string): B[] | null {
  for (const b of blocks) {
    if (b.id === id) return [b]
    const sub = b.children ? pathTo(b.children as readonly B[], id) : null
    if (sub) return [b, ...sub]
  }
  return null
}

/** The siblings list that holds `id` (the root list for top-level blocks). */
function siblingsOf(blocks: readonly PhoneBlock[], id: string): readonly PhoneBlock[] | null {
  if (blocks.some((b) => b.id === id)) return blocks
  for (const b of blocks) {
    const s = b.children ? siblingsOf(b.children, id) : null
    if (s) return s
  }
  return null
}

const isText = (b: PhoneBlock) => typeof b.textContent === 'string' && (TEXT_TAGS.has(b.tag) || !b.children?.length)
const isPhoto = (b: PhoneBlock) => b.tag === 'img' || !!b.background?.url

/** What a tapped block offers on a phone, in this scope. */
export function actionsFor(blocks: readonly PhoneBlock[], id: string, scope: EditScope): PhoneAction[] {
  const path = pathTo(blocks, id)
  if (!path) return []
  const b = path[path.length - 1]
  if (path.some((p) => p.locked)) return []
  const hideToggle: PhoneAction = isHiddenOnPhone(b) ? 'show' : 'hide'
  // Shared sections and the header/footer: only visibility on phones.
  if (scope.kind !== 'page') return [hideToggle]
  const out: PhoneAction[] = []
  if (isText(b)) out.push('text')
  if (isPhoto(b)) out.push('photo')
  const sibs = siblingsOf(blocks, id) ?? []
  const i = sibs.findIndex((s) => s.id === id)
  if (i > 0) out.push('move-up')
  if (i >= 0 && i < sibs.length - 1) out.push('move-down')
  out.push(hideToggle)
  return out
}

/** Copy the tree, replacing the block `id` with `fn(block)`. Unknown id → the same tree (by value). */
function mapBlock<B extends PhoneBlock>(blocks: readonly B[], id: string, fn: (b: B) => B): B[] {
  return blocks.map((b) => (b.id === id ? fn(b) : b.children ? { ...b, children: mapBlock(b.children as readonly B[], id, fn) } : b))
}

/** Hide (or show again) a block on phones only; desktop and tablet are untouched. */
export function setHiddenOnPhone<B extends PhoneBlock>(blocks: readonly B[], id: string, hidden: boolean): B[] {
  return mapBlock(blocks, id, (b) => {
    const { mobile: _was, ...others } = b.responsive?.hidden ?? {}
    void _was
    const nextHidden: NonNullable<NonNullable<PhoneBlock['responsive']>['hidden']> = hidden ? { ...others, mobile: true } : others
    const { responsive, ...rest } = b
    const { hidden: _old, ...otherResponsive } = responsive ?? {}
    void _old
    const nextResponsive = Object.keys(nextHidden).length ? { ...otherResponsive, hidden: nextHidden } : otherResponsive
    return (Object.keys(nextResponsive).length ? { ...rest, responsive: nextResponsive } : rest) as B
  })
}

/** Swap a block with its neighbour among the same siblings. At an edge → null (nothing to do). */
export function moveAmongSiblings<B extends PhoneBlock>(blocks: readonly B[], id: string, dir: 'up' | 'down'): B[] | null {
  const swapIn = (list: readonly B[]): B[] | null => {
    const i = list.findIndex((b) => b.id === id)
    if (i >= 0) {
      const j = dir === 'up' ? i - 1 : i + 1
      if (j < 0 || j >= list.length) return null
      const out = [...list]
      ;[out[i], out[j]] = [out[j], out[i]]
      return out
    }
    for (let k = 0; k < list.length; k++) {
      const kids = list[k].children as readonly B[] | undefined
      if (!kids) continue
      const moved = swapIn(kids)
      if (moved) return list.map((b, n) => (n === k ? { ...b, children: moved } : b))
      if (pathTo(kids, id)) return null // found at an edge deeper down
    }
    return null
  }
  return swapIn(blocks)
}

/** New words for a text block (trimmed; empty is refused → null). */
export function setText<B extends PhoneBlock>(blocks: readonly B[], id: string, text: string): B[] | null {
  const t = text.replace(/\s+\n/g, '\n').trim()
  if (!t) return null
  return mapBlock(blocks, id, (b) => ({ ...b, textContent: t }))
}

/** A new photo: an <img> gets src (+ alt when given); a block with a background image gets its url. */
export function setPhoto<B extends PhoneBlock>(blocks: readonly B[], id: string, url: string, alt?: string): B[] | null {
  if (!/^(https?:\/\/|\/)/.test(url)) return null
  return mapBlock(blocks, id, (b) => {
    if (b.tag === 'img') return { ...b, attrs: { ...(b.attrs ?? {}), src: url, ...(alt !== undefined ? { alt } : {}) } }
    if (b.background) return { ...b, background: { ...b.background, url } }
    return b
  })
}

/** A short plain name for the tapped block ("Heading", "Photo", the editor label when set). */
export function blockName(b: PhoneBlock): string {
  if (b.label) return b.label
  if (/^h[1-6]$/.test(b.tag)) return 'Heading'
  if (b.tag === 'img') return 'Photo'
  if (b.tag === 'p') return 'Paragraph'
  if (b.tag === 'a' || b.tag === 'button') return 'Button'
  if (b.tag === 'section') return 'Section'
  return 'Block'
}

/** What the assistant gets for "make this shorter for phones": the block, its words, and that the edit is a draft. */
export function agentContext(scope: EditScope, b: PhoneBlock): string {
  const words = b.textContent ? ` Its text: “${b.textContent.slice(0, 280)}”.` : ''
  return `On the phone layout of ${draftTarget(scope)}, the ${blockName(b).toLowerCase()} ${b.id} is selected.${words} Any change is a draft for review.`
}

/** Blocks hidden on phones (they don't render in the phone layout), so the screen can list them with "Show on phone". */
export function hiddenOnPhoneBlocks(blocks: readonly PhoneBlock[]): Array<{ id: string; name: string }> {
  const out: Array<{ id: string; name: string }> = []
  const walk = (list: readonly PhoneBlock[]) => {
    for (const b of list) {
      if (isHiddenOnPhone(b)) out.push({ id: b.id, name: b.textContent ? `${blockName(b)}: “${b.textContent.slice(0, 40)}”` : blockName(b) })
      else if (b.children) walk(b.children)
    }
  }
  walk(blocks)
  return out
}
