/**
 * The approval card: how an irreversible action asks first (send an email,
 * publish, delete…). It states the consequence in plain words and needs an
 * explicit tap on a labelled button — never a swipe, never a default.
 * Pure; asserted by approval.assert.ts.
 */

export type IrreversibleKind = 'send-email' | 'publish' | 'unpublish' | 'delete' | 'refund' | 'charge' | 'cancel-order'

export interface ApprovalRequest {
  kind: IrreversibleKind
  /** What it acts on: "Volunteer sign-up", "Order #1042", "ama@example.com". */
  target: string
  /** How many (recipients, items); 1 when omitted. */
  count?: number
  /** A money amount already formatted ("$24.00"), for refunds and charges. */
  amount?: string
}

export interface ApprovalCopy {
  title: string
  /** The consequence, said plainly — what happens and that it can't be taken back. */
  consequence: string
  confirmLabel: string
  cancelLabel: string
  destructive: boolean
}

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`

export function approvalCopy(r: ApprovalRequest): ApprovalCopy {
  const n = r.count && r.count > 0 ? Math.floor(r.count) : 1
  const t = r.target.trim() || 'this'
  const base = { cancelLabel: 'Not now' }
  switch (r.kind) {
    case 'send-email':
      return { ...base, title: `Send to ${n === 1 ? t : plural(n, 'person', 'people')}?`, consequence: `It goes out from your mailbox now and can't be unsent.`, confirmLabel: n === 1 ? 'Send' : `Send to ${n}`, destructive: false }
    case 'publish':
      return { ...base, title: `Publish ${t}?`, consequence: 'Everyone visiting the site sees it straight away.', confirmLabel: 'Publish', destructive: false }
    case 'unpublish':
      return { ...base, title: `Take ${t} off the site?`, consequence: 'Visitors stop seeing it straight away; links to it stop working.', confirmLabel: 'Unpublish', destructive: true }
    case 'delete':
      return { ...base, title: `Delete ${n === 1 ? t : plural(n, 'item')}?`, consequence: "It's removed for everyone and can't be brought back from here.", confirmLabel: n === 1 ? 'Delete' : `Delete ${n}`, destructive: true }
    case 'refund':
      return { ...base, title: `Refund ${r.amount ?? 'this order'}?`, consequence: `The money goes back to the customer for ${t}. A refund can't be reversed.`, confirmLabel: `Refund${r.amount ? ` ${r.amount}` : ''}`, destructive: true }
    case 'cancel-order':
      return { ...base, title: `Cancel ${t}?`, consequence: 'The customer is told it is cancelled; this can\'t be undone.', confirmLabel: 'Cancel order', cancelLabel: 'Keep it', destructive: true }
    case 'charge':
      return { ...base, title: `Charge ${r.amount ?? 'this amount'}?`, consequence: `The card on ${t} is charged now.`, confirmLabel: `Charge${r.amount ? ` ${r.amount}` : ''}`, destructive: true }
  }
}

/** The only way to confirm: an explicit press of the confirm button (no swipe, no Enter on the card, no timer). */
export function isExplicitConfirm(e: { type: string; target: 'confirm' | 'cancel' | 'card' }): boolean {
  return (e.type === 'click' || e.type === 'keydown-enter' || e.type === 'keydown-space') && e.target === 'confirm'
}

const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '')

/** What an email-sending tool is about to send, as the approval card shows it. */
export interface EmailPreview {
  from?: string
  to: string[]
  cc: string[]
  bcc: string[]
  subject: string
  /** Plain text (HTML is turned into text — never rendered): the WHOLE body the person approves. */
  body: string
  /** Only for inputs that aren't the signed preview: longer than PREVIEW_BODY_MAX (the signed one can't be). */
  truncated: boolean
  /** File names of attachments that go with it (C-3). */
  attachments: string[]
  /** The sender being answered, when it is a reply (C-3: "Reply to …"). */
  replyTo: string | null
}

/**
 * Everything the core will send is shown: the card's limit equals the core's
 * own (connectors/preview PREVIEW_TEXT_CAP — a longer body can't be
 * prepared), so nothing is approved unseen (C-18). Not imported: that module
 * signs with node:crypto and this one runs in the browser; the assert keeps
 * the two equal.
 */
export const PREVIEW_BODY_MAX = 20_000

const addresses = (v: unknown): string[] =>
  (Array.isArray(v) ? v : typeof v === 'string' ? v.split(/[,;]/) : [])
    .map((x) => (typeof x === 'string' ? x : x && typeof x === 'object' && 'email' in x ? String((x as { email: unknown }).email) : ''))
    .map((x) => x.trim())
    .filter(Boolean)

/** HTML → readable text: line breaks for blocks, no tags, basic entities. */
export function htmlToText(html: string): string {
  return html
    .replace(/<(script|style)[\s\S]*?<\/\1>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi, '\n')
    .replace(/<li[^>]*>/gi, '• ')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
}

/**
 * The email in a send / reply tool call: the tool's own `preview` when it
 * gives one (the connector's send tool does), else its input. Null when the
 * call carries no recipient.
 */
export function emailPreviewForTool(toolName: string, input: Record<string, unknown>): EmailPreview | null {
  const signed = input.preview && typeof input.preview === 'object' ? (input.preview as Record<string, unknown>) : null
  // email_send_draft: the server-signed preview is what gets sent (or nothing) — never read anything else.
  if (toolName === 'email_send_draft' && !signed) return null
  const src = signed ?? input
  const to = addresses(src.to)
  const cc = addresses(src.cc)
  const bcc = addresses(src.bcc)
  // Any recipient makes it an email — a Bcc-only draft too (C-27).
  if (!(to.length || cc.length || bcc.length) || !/send|reply|email|mail/i.test(toolName)) return null
  // email_send_draft's signed preview carries textBody; other tools text / body / html.
  const raw = str(src.textBody) || str(src.text) || str(src.body) || (str(src.html) ? htmlToText(str(src.html)) : '')
  // The signed body is shown exactly as it will be sent (line endings aside); other tools' text is tidied.
  const text = signed && toolName === 'email_send_draft' ? raw.replace(/\r\n/g, '\n') : raw.replace(/\r\n/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim()
  return {
    ...(str(src.from) ? { from: str(src.from) } : {}),
    to,
    cc,
    bcc,
    subject: str(src.subject),
    body: text.length > PREVIEW_BODY_MAX ? `${text.slice(0, PREVIEW_BODY_MAX).trimEnd()}…` : text,
    truncated: text.length > PREVIEW_BODY_MAX,
    attachments: (Array.isArray(src.attachments) ? src.attachments : []).map((a) => (typeof a === 'string' ? a : a && typeof a === 'object' && 'name' in a ? String((a as { name: unknown }).name) : '')).map((a) => a.trim()).filter(Boolean),
    replyTo: src.replyTo && typeof src.replyTo === 'object' ? str((src.replyTo as Record<string, unknown>).from) || null : null,
  }
}

/** The email's header lines, the same on desktop and phone: From, Reply to, To, Cc, Bcc, Subject, Attachments. */
export function emailRows(p: EmailPreview): Array<[label: string, value: string]> {
  const rows: Array<[string, string]> = [
    ['From', p.from ?? ''],
    ['Reply to', p.replyTo ?? ''],
    ['To', p.to.join(', ')],
    ['Cc', p.cc.join(', ')],
    ['Bcc', p.bcc.join(', ')],
    ['Subject', p.subject || '(no subject)'],
    ['Attachments', p.attachments.join(', ')],
  ]
  return rows.filter(([, v]) => v)
}
const money = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? `$${v.toFixed(2)}` : undefined)

/**
 * An agent tool call waiting for approval → its approval card, when the
 * tool is irreversible; null otherwise (the generic approval shows). The
 * target is named from the call's own input, never from the reply.
 */
export function approvalForTool(toolName: string, input: Record<string, unknown>): ApprovalRequest | null {
  const name = str(input.title) || str(input.name) || str(input.slug) || str(input.orderNumber) || str(input.id) || str(input.pageId) || str(input.postId) || str(input.productId) || str(input.orderId)
  const to = Array.isArray(input.to) ? input.to.length : str(input.to) ? 1 : 0
  if (/^send(Email|Campaign|Test)/.test(toolName) || toolName === 'sendEmail') {
    return { kind: 'send-email', target: str(input.to) || str(input.subject) || 'this email', count: to || undefined }
  }
  // Any other send / reply tool that carries an email (the person's connected mailbox).
  const mail = /send|reply/i.test(toolName) ? emailPreviewForTool(toolName, input) : null
  if (mail) {
    const all = [...mail.to, ...mail.cc, ...mail.bcc]
    return { kind: 'send-email', target: all.length === 1 ? all[0]! : mail.subject || 'this email', count: all.length || undefined }
  }
  if (/^publish/.test(toolName)) return { kind: input.publish === false || input.status === 'DRAFT' ? 'unpublish' : 'publish', target: name || 'this' }
  if (/^delete|^vmcp_delete/.test(toolName)) return { kind: 'delete', target: name || 'this' }
  if (toolName === 'refundOrder') return { kind: 'refund', target: name ? `order ${name}` : 'this order', amount: money(input.amount) }
  if (toolName === 'cancelOrder') return { kind: 'cancel-order', target: name ? `order ${name}` : 'this order' }
  return null
}

const BADGE: Record<IrreversibleKind, string> = {
  'send-email': "Send email · can't be undone",
  publish: 'Publish · goes live now',
  unpublish: 'Unpublish · leaves the site now',
  delete: "Delete · can't be undone",
  refund: "Refund · can't be undone",
  charge: "Charge · can't be undone",
  'cancel-order': "Cancel order · can't be undone",
}

/** The band across the top of an approval card (the mock-up: "Send email · can't be undone"). */
export function approvalBadge(kind: IrreversibleKind): string {
  return BADGE[kind]
}

/** The phone card's confirm: says what happens ("Approve and send"). */
export function phoneConfirmLabel(kind: IrreversibleKind, fallback: string): string {
  return kind === 'send-email' ? 'Approve and send' : kind === 'publish' ? 'Approve and publish' : fallback
}


/** Feedback kinds in the person's words (lib/ade/feedback FEEDBACK_KIND_LABEL; kept here so this file stays dependency-free). */
const FEEDBACK_KIND_WORDS: Record<string, string> = { bug: 'Something is broken', confusing: 'This is confusing', idea: 'An idea', praise: 'I like this' }

/** Edits to pages, posts, records and the site layout: held for approval only when the run read outside text. */
const CONTENT_EDIT_TOOLS = new Set([
  'updateBlock', 'insertBlock', 'add_block', 'save_block', 'updatePage', 'createPage', 'duplicatePage',
  'overridePlacementField', 'resetPlacementField', 'updateRecord', 'createRecordWithPage',
  'createBlogPost', 'updateBlogPost', 'updateSiteLayoutBlock', 'insertSiteLayoutBlock',
])

const ROW_MAX = 200
/**
 * What a content change changes, in the person's words: new text, title, address and why.
 * Ids, field names and class lists are never shown (walk 2026-11-16).
 */
export function plainChangeRows(input: Record<string, unknown>): Array<[string, string]> {
  const str = (v: unknown) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, ROW_MAX) : null)
  const rows: Array<[string, string]> = []
  const text = str(input.textContent) ?? str(input.text) ?? str(input.content)
  if (text) rows.push(['New text', text])
  const title = str(input.title)
  if (title) rows.push(['Title', title])
  const slug = str(input.slug)
  if (slug) rows.push(['Address', slug.startsWith('/') ? slug : `/${slug}`])
  const why = str(input.why)
  if (why) rows.push(['Why', why])
  return rows
}

export interface ApprovalCardModel {
  /** Desktop title / phone band. */
  title: string
  consequence: string
  /** The email, when it is one: header rows and the whole body. */
  email: { rows: Array<[string, string]>; body: string; truncated: boolean } | null
  /** A content change: what it changes, in plain words (no ids, no field names). */
  rows?: Array<[string, string]>
  confirmLabel: string
  cancelLabel: string
  /**
   * The email can't be shown (email_send_draft without its signed preview):
   * no Approve button at all — nothing is approved unseen (C-25).
   */
  blind: boolean
}

/**
 * What an approval card shows, for both variants — the desktop chat and the
 * phone card render this, so they can't drift apart (C-25). Null: not an
 * irreversible action we know (the generic approval shows), except an
 * unreadable email send, which is `blind`.
 */
export function approvalCardModel(toolName: string, input: Record<string, unknown>, variant: 'panel' | 'phone'): ApprovalCardModel | null {
  // Feedback to the site's builder: the person sees the whole note before it leaves (F-3).
  if (toolName === 'send_feedback_to_owner') {
    const note = typeof input.note === 'string' ? input.note : ''
    const kind = typeof input.kind === 'string' ? (FEEDBACK_KIND_WORDS[input.kind] ?? input.kind) : ''
    return {
      title: variant === 'phone' ? 'Send feedback · check the note' : 'Send this feedback?',
      consequence: 'It goes to the person who built this site, with the screen you are on. Nothing else is attached.',
      email: { rows: kind ? [['Kind', kind]] : [], body: note.slice(0, PREVIEW_BODY_MAX), truncated: note.length > PREVIEW_BODY_MAX },
      confirmLabel: 'Send',
      cancelLabel: 'Don’t send',
      blind: !note.trim(),
    }
  }
  const req = approvalForTool(toolName, input)
  if (!req && CONTENT_EDIT_TOOLS.has(toolName)) {
    return {
      title: 'Make this change?',
      consequence: 'It changes the content shown below. Nothing goes live until it is published.',
      email: null,
      rows: plainChangeRows(input),
      confirmLabel: 'Make the change',
      cancelLabel: 'Not now',
      blind: false,
    }
  }
  if (!req) {
    if (toolName !== 'email_send_draft') return null
    return { title: 'Send email?', consequence: "This email can't be shown, so it can't be approved here. Ask the assistant to prepare it again.", email: null, confirmLabel: '', cancelLabel: 'Not now', blind: true }
  }
  const copy = approvalCopy(req)
  const mail = req.kind === 'send-email' ? emailPreviewForTool(toolName, input) : null
  return {
    title: variant === 'phone' ? approvalBadge(req.kind) : copy.title,
    consequence: copy.consequence,
    email: mail ? { rows: emailRows(mail), body: mail.body, truncated: mail.truncated } : null,
    confirmLabel: variant === 'phone' ? phoneConfirmLabel(req.kind, copy.confirmLabel) : copy.confirmLabel,
    cancelLabel: copy.cancelLabel,
    blind: false,
  }
}

/**
 * What became of an approved email_send_draft, in our words (never the
 * server's error text). A refusal — the draft changed, or the 30-minute
 * approval expired — reads the same way: prepare it again.
 */
export function sendOutcome(toolName: string, output: unknown): { ok: boolean; text: string } | null {
  if (toolName !== 'email_send_draft' || !output || typeof output !== 'object') return null
  const o = output as Record<string, unknown>
  if (o.success === true && o.sent === true) return { ok: true, text: 'Sent from your mailbox.' }
  if (o.refused === true) return { ok: false, text: 'Not sent — the draft changed or the approval expired (approvals last 30 minutes). Ask me to prepare it again.' }
  if (o.held === true) return { ok: false, text: 'Not sent — sending is held on this site.' }
  return { ok: false, text: 'Not sent — something went wrong. Nothing left your mailbox.' }
}
