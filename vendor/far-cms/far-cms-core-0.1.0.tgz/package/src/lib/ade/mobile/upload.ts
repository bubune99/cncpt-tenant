/**
 * Resumable photo upload into the media library — the offline queue's
 * 'media.upload' handler (app-agnostic: the host gives it its endpoints).
 * Three steps, each remembered once done, so a retry after a dropped signal
 * picks up where it stopped (it never presigns or PUTs twice once that step
 * succeeded):
 *   presign → PUT the bytes to storage (R2/S3) → complete (the media row)
 * Asserted by upload.assert.ts with a fake network.
 */

export interface UploadEndpoints {
  /** POST { action: 'presign', filename, mimeType, size } → { uploadUrl, publicUrl, key, bucket, provider } */
  presign: string
  /** POST { action: 'complete', … } → the media row ({ id, url }) */
  complete: string
}

export interface UploadState {
  step: 'presign' | 'put' | 'complete' | 'done'
  presigned?: { uploadUrl: string; publicUrl: string; key: string; bucket?: string; provider?: string }
  media?: { id: string; url: string }
}

export interface UploadJob {
  file: Blob
  name: string
  type: string
  /** Extra fields for the media row (title, alt…). */
  meta?: Record<string, unknown>
}

type Fetch = (url: string, init?: RequestInit) => Promise<Response>

export class UploadError extends Error {
  constructor(message: string, readonly retryable: boolean) {
    super(message)
  }
}

/**
 * Run (or resume) one upload. `state` is what a previous attempt saved;
 * `save` persists progress after each step (the queue stores it).
 */
export async function runPhotoUpload(job: UploadJob, state: UploadState, save: (s: UploadState) => void | Promise<void>, endpoints: UploadEndpoints, fetchFn: Fetch = fetch): Promise<{ id: string; url: string }> {
  let s: UploadState = { ...state, step: state.step ?? 'presign' }
  const json = async (r: Response) => (await r.json().catch(() => ({}))) as Record<string, unknown>
  const fail = (r: Response, what: string) => new UploadError(`${what} failed (${r.status})`, r.status >= 500 || r.status === 408 || r.status === 429)

  if (s.step === 'presign') {
    const r = await fetchFn(endpoints.presign, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'presign', filename: job.name, mimeType: job.type, size: job.file.size }) })
    if (!r.ok) throw fail(r, 'Getting an upload address')
    const j = await json(r)
    if (typeof j.uploadUrl !== 'string' || typeof j.publicUrl !== 'string' || typeof j.key !== 'string') throw new UploadError('The upload address was incomplete', true)
    s = { step: 'put', presigned: { uploadUrl: j.uploadUrl, publicUrl: j.publicUrl, key: j.key, bucket: j.bucket as string | undefined, provider: j.provider as string | undefined } }
    await save(s)
  }
  if (s.step === 'put') {
    const r = await fetchFn(s.presigned!.uploadUrl, { method: 'PUT', body: job.file, headers: { 'content-type': job.type } })
    if (!r.ok) throw fail(r, 'Sending the photo')
    s = { ...s, step: 'complete' }
    await save(s)
  }
  if (s.step === 'complete') {
    const p = s.presigned!
    const r = await fetchFn(endpoints.complete, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action: 'complete', filename: job.name, originalName: job.name, mimeType: job.type, size: job.file.size, url: p.publicUrl, key: p.key, bucket: p.bucket, provider: p.provider, ...(job.meta ?? {}) }),
    })
    if (!r.ok) throw fail(r, 'Saving the photo')
    const j = await json(r)
    const media = { id: String(j.id ?? ''), url: String(j.url ?? p.publicUrl) }
    if (!media.id) throw new UploadError('The media library did not return the photo', true)
    s = { ...s, step: 'done', media }
    await save(s)
  }
  return s.media!
}
