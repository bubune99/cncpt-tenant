/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/mobile/gestures.assert.ts
 */
import assert from 'node:assert/strict'
import {
  DOUBLE_TAP_MS,
  LONG_PRESS_MS,
  MIC_CANCEL_DX,
  MIC_LOCK_DY,
  UNIT_GESTURE_CSS,
  createPressRecognizer,
  dragAxis,
  markHintShown,
  micStep,
  pinchZoom,
  pressStep,
  pullState,
  shouldShowHint,
  swipeDirection,
  type PressEvent,
  type PressGesture,
  type PressOptions,
  type PressState,
} from './gestures'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

/** Feed events (with timer ticks the host would send) and collect what fired. */
function run(events: PressEvent[], opts: PressOptions): PressGesture[] {
  let s: PressState = { kind: 'idle' }
  let wake: number | null = null
  const out: PressGesture[] = []
  const step = (e: PressEvent) => {
    const r = pressStep(s, e, opts)
    s = r.state
    wake = r.wakeAt
    if (r.emit) out.push(r.emit)
  }
  for (const e of events) {
    // Any timer due before this event fires first.
    const t = 't' in e ? e.t : Infinity
    while (wake !== null && wake <= t) step({ type: 'tick', t: wake })
    step(e)
  }
  while (wake !== null) step({ type: 'tick', t: wake })
  return out
}
const down = (t: number, x = 0, y = 0): PressEvent => ({ type: 'down', t, x, y })
const up = (t: number, x = 0, y = 0): PressEvent => ({ type: 'up', t, x, y })
const move = (t: number, x: number, y = 0): PressEvent => ({ type: 'move', t, x, y })

check('timings are the agreed ones (≈300 ms double-tap, ≈450 ms long-press)', () => {
  assert.equal(DOUBLE_TAP_MS, 300)
  assert.equal(LONG_PRESS_MS, 450)
})

check('a tap fires at once when nothing listens for double-taps', () => {
  assert.deepEqual(run([down(0), up(80)], { long: true }), ['tap'])
  assert.deepEqual(run([down(0), up(600)], {}), ['tap'], 'a slow press with no long-press handler is still a tap')
})

check('with a double-tap handler a tap waits, and two quick taps are one double-tap (no stray tap)', () => {
  assert.deepEqual(run([down(0), up(60)], { double: true }), ['tap'])
  assert.deepEqual(run([down(0), up(60), down(200), up(260)], { double: true, long: true }), ['double-tap'])
  assert.deepEqual(run([down(0), up(60), down(500), up(560)], { double: true }), ['tap', 'tap'], 'too slow: two taps')
  assert.deepEqual(run([down(0), up(60), down(150, 100, 0), up(200, 100, 0)], { double: true }), ['tap', 'tap'], 'too far apart: two taps')
})

check('long-press fires at 450 ms and swallows the release; moving cancels it', () => {
  assert.deepEqual(run([down(0), up(700)], { long: true, double: true }), ['long-press'])
  assert.deepEqual(run([down(0), up(400)], { long: true }), ['tap'], 'released before 450 ms')
  assert.deepEqual(run([down(0), move(100, 30), up(700, 30)], { long: true }), [], 'a drag is not a tap or a long-press')
  assert.deepEqual(run([down(0), move(100, 4), up(700, 4)], { long: true }), ['long-press'], 'a tremor within the slop is still a hold')
  assert.deepEqual(run([down(0), up(60), down(200), move(250, 40), up(300, 40)], { double: true }), [], 'a second press that drags is not a double-tap')
})

check('cancel (another finger, scroll took over) resets everything', () => {
  let r = pressStep({ kind: 'idle' }, down(0), { long: true })
  r = pressStep(r.state, { type: 'cancel' }, { long: true })
  assert.equal(r.state.kind, 'idle')
  assert.equal(r.wakeAt, null)
})

check('scroll vs swipe: the axis is decided after 10 px; vertical drags never swipe', () => {
  assert.equal(dragAxis(4, 3), null)
  assert.equal(dragAxis(20, 5), 'x')
  assert.equal(dragAxis(5, 20), 'y')
  assert.equal(swipeDirection({ dx: 140, dy: 10, width: 360 }), 'right')
  assert.equal(swipeDirection({ dx: -140, dy: 10, width: 360 }), 'left')
  assert.equal(swipeDirection({ dx: 80, dy: 0, width: 360 }), null)
  assert.equal(swipeDirection({ dx: 80, dy: 0, width: 360, vx: 0.9 }), 'right', 'a flick decides sooner')
  assert.equal(swipeDirection({ dx: 150, dy: 200, width: 360 }), null)
})

check('pinch zooms by the finger spread, within range', () => {
  assert.equal(pinchZoom(1, 100, 200), 2)
  assert.equal(pinchZoom(2, 100, 50), 1)
  assert.equal(pinchZoom(1, 100, 1000), 4)
  assert.equal(pinchZoom(1.5, 0, 50), 1.5)
})

check('pull to refresh only from the top, with resistance', () => {
  assert.deepEqual(pullState(100, 0), { offset: 50, ready: false })
  assert.equal(pullState(140, 0).ready, true)
  assert.deepEqual(pullState(140, 12), { offset: 0, ready: false }, 'a list scrolled down just scrolls')
  assert.equal(pullState(1000, 0).offset, 96)
  assert.deepEqual(pullState(-20, 0), { offset: 0, ready: false })
})

check('mic: hold to talk, release sends; slide up locks; slide left cancels (nothing sent)', () => {
  let s = micStep('idle', { type: 'down' })
  assert.deepEqual(s, { state: 'holding', effect: 'start' })
  assert.deepEqual(micStep('holding', { type: 'up' }), { state: 'idle', effect: 'send' })
  // Lock: release no longer stops; tapping stop sends.
  s = micStep('holding', { type: 'move', dx: 0, dy: MIC_LOCK_DY - 1 })
  assert.equal(s.state, 'locked')
  assert.deepEqual(micStep('locked', { type: 'up' }), { state: 'locked', effect: null })
  assert.deepEqual(micStep('locked', { type: 'tap-stop' }), { state: 'idle', effect: 'send' })
  // Cancel: discard, then the lift does nothing.
  s = micStep('holding', { type: 'move', dx: MIC_CANCEL_DX - 1, dy: 0 })
  assert.deepEqual(s, { state: 'cancelled', effect: 'discard' })
  assert.deepEqual(micStep('cancelled', { type: 'up' }), { state: 'idle', effect: null })
  assert.deepEqual(micStep('holding', { type: 'move', dx: -20, dy: -20 }), { state: 'holding', effect: null }, 'small slides do nothing')
})

check('hints show once; broken storage means no hint (not one every time)', () => {
  const mem = new Map<string, string>()
  const store = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => void mem.set(k, v) }
  assert.equal(shouldShowHint('long-press', store), true)
  markHintShown('long-press', store)
  assert.equal(shouldShowHint('long-press', store), false)
  assert.equal(shouldShowHint('mic-hold', store), true)
  const broken = { getItem: () => { throw new Error('denied') }, setItem: () => { throw new Error('denied') } }
  assert.equal(shouldShowHint('long-press', broken), false)
  assert.doesNotThrow(() => markHintShown('long-press', broken))
  assert.equal(shouldShowHint('long-press', null), false)
})

check('browser defaults are off on units only; text in editors stays selectable', () => {
  assert.match(UNIT_GESTURE_CSS, /touch-action:manipulation/)
  assert.match(UNIT_GESTURE_CSS, /-webkit-touch-callout:none/)
  assert.match(UNIT_GESTURE_CSS, /\[data-ade-gesture-unit\] textarea[^{]*\{-webkit-user-select:text;user-select:text/)
  assert.ok(!/^\s*(body|html|\*)/.test(UNIT_GESTURE_CSS), 'never page-wide')
})

check('the recogniser runs its own timers (for an iframe\'s listeners): tap, double-tap, long-press', () => {
  let now = 0
  const timers: Array<{ at: number; fn: () => void; id: number }> = []
  let seq = 0
  const clock = {
    now: () => now,
    setTimer: (fn: () => void, ms: number) => { const id = ++seq; timers.push({ at: now + ms, fn, id }); return id },
    clearTimer: (id: unknown) => { const i = timers.findIndex((t) => t.id === id); if (i >= 0) timers.splice(i, 1) },
  }
  const advance = (to: number) => {
    for (;;) {
      timers.sort((a, b) => a.at - b.at)
      const t = timers[0]
      if (!t || t.at > to) break
      timers.shift()
      now = t.at
      t.fn()
    }
    now = to
  }
  const got: string[] = []
  const r = createPressRecognizer({ onTap: () => got.push('tap'), onDoubleTap: () => got.push('double'), onLongPress: () => got.push('long') }, clock)
  r.down(0, 0); advance(60); r.up(0, 0); advance(400)
  r.down(0, 0); advance(60); r.up(0, 0); advance(150); r.down(0, 0); advance(200); r.up(0, 0); advance(800)
  r.down(0, 0); advance(1500); r.up(0, 0); advance(2000)
  assert.deepEqual(got, ['tap', 'double', 'long'])
  r.dispose()
  assert.equal(timers.length, 0)
})

console.log(`\n${n} checks passed`)
