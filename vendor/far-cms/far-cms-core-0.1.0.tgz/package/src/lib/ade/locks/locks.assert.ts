/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/locks/locks.assert.ts
 */
import assert from 'node:assert/strict'
import { LOCK_TTL_MS, agentMayEdit, approvalWarning, canEditView, decideAcquire, gateEdit, lockKeyFor, lockStateFor, type EditLock } from './logic'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const t0 = new Date('2026-10-10T10:00:00Z')
const later = (ms: number) => new Date(t0.getTime() + ms)
const ama = { userId: 'u1', userName: 'Ama', tabId: 'tA' }
const kofi = { userId: 'u2', userName: 'Kofi', tabId: 'tK' }
const held = (by = ama, at = t0): EditLock => ({ targetKey: 'page:p1', userId: by.userId, userName: by.userName, tabId: by.tabId, heartbeatAt: at })

check('first in gets it; the second person is read-only and can only ask', () => {
  const a = decideAcquire(null, ama, t0)
  assert.ok(a.granted)
  const k = decideAcquire(held(), kofi, later(1000))
  assert.ok(!k.granted)
  if (!k.granted) assert.deepEqual(k.state, { kind: 'other-user', holder: 'Ama', holderId: 'u1', requested: false })
})

check('the same person in a second tab is told; they may move the claim there', () => {
  const second = { ...ama, tabId: 'tB' }
  const r = decideAcquire(held(), second, later(1000))
  assert.ok(!r.granted)
  if (!r.granted) assert.equal(r.state.kind, 'other-tab')
  const moved = decideAcquire(held(), second, later(1000), { moveFromOtherTab: true })
  assert.ok(moved.granted)
  if (moved.granted) assert.equal(moved.lock.tabId, 'tB')
  // …but nobody can "move" someone else's claim.
  assert.ok(!decideAcquire(held(), kofi, later(1000), { moveFromOtherTab: true }).granted)
})

check('heartbeats renew; silence past the TTL frees the page', () => {
  assert.ok(decideAcquire(held(), ama, later(LOCK_TTL_MS - 1)).granted)
  assert.ok(!decideAcquire(held(), kofi, later(LOCK_TTL_MS - 1)).granted)
  const after = decideAcquire(held(), kofi, later(LOCK_TTL_MS + 1))
  assert.ok(after.granted)
  assert.equal(lockStateFor(held(), kofi, later(LOCK_TTL_MS + 1)).kind, 'free')
})

check('the assistant acts for its user: their page yes, someone else’s no', () => {
  assert.deepEqual(agentMayEdit(held(), 'u1', later(1000)), { ok: true })
  assert.deepEqual(agentMayEdit(held(), 'u2', later(1000)), { ok: false, holder: 'Ama' })
  assert.deepEqual(agentMayEdit(held(), null, later(1000)), { ok: false, holder: 'Ama' })
  assert.deepEqual(agentMayEdit(held(), 'u2', later(LOCK_TTL_MS + 1)), { ok: true })
  assert.deepEqual(agentMayEdit(null, 'u2', t0), { ok: true })
})

check('approving while someone else edits warns; your own page or a free page does not', () => {
  assert.match(approvalWarning(held(), 'u2', later(1000)) ?? '', /^Ama is editing/)
  assert.equal(approvalWarning(held(), 'u1', later(1000)), null)
  assert.equal(approvalWarning(held(), 'u2', later(LOCK_TTL_MS + 1)), null)
})

check('a request is remembered for the person who asked; renewing keeps it', () => {
  const asked: EditLock = { ...held(), requestedById: 'u2', requestedByName: 'Kofi' }
  const s = lockStateFor(asked, kofi, later(1000))
  assert.equal(s.kind === 'other-user' && s.requested, true)
  const renewed = decideAcquire(asked, ama, later(2000))
  assert.ok(renewed.granted && renewed.lock.requestedByName === 'Kofi')
})

check('change targets map to the right lock', () => {
  assert.equal(lockKeyFor('page-content', 'p1'), 'page:p1')
  assert.equal(lockKeyFor('page-status', 'p1'), 'page:p1')
  assert.equal(lockKeyFor('form', 'f1'), 'form:f1')
  assert.equal(lockKeyFor('record', 'r1'), 'record:r1')
  assert.equal(lockKeyFor('site-layout', 'header'), 'layout:header')
  assert.equal(lockKeyFor('blog-post', 'b1'), 'post:b1')
  assert.equal(lockKeyFor('blog-status', 'b1'), 'post:b1')
  assert.equal(lockKeyFor('blog-category', 'c1'), null)
  assert.equal(lockKeyFor('page', null), null)
})

check('read-only unless this tab holds the claim (or nobody does); loading counts as read-only', () => {
  assert.equal(canEditView('form:f1', 'mine'), true)
  assert.equal(canEditView('form:f1', 'free'), true)
  for (const k of ['loading', 'other-tab', 'other-user']) assert.equal(canEditView('form:f1', k), false, k)
  assert.equal(canEditView(null, 'other-tab'), true, 'no lock on this screen')
})

check('a gated edit is a no-op under someone else\'s lock, and works again once the claim is back', () => {
  let held = false
  const doc: string[] = []
  const edit = gateEdit(() => held, (x: string) => doc.push(x))
  edit('typed while locked')
  assert.deepEqual(doc, [])
  held = true
  edit('typed after Edit here instead')
  assert.deepEqual(doc, ['typed after Edit here instead'])
})

console.log(`\n${n} checks passed`)
