/**
 * One person edits a page (or record) at a time — pure rules, asserted by
 * locks.assert.ts. App-agnostic: the host app stores the claims.
 *
 * A claim names who holds a target and from which browser tab, and when they
 * were last active. Claims are kept alive by heartbeats while the person is
 * active; one that hasn't heard from them for LOCK_TTL_MS is free to take, so
 * a closed laptop never locks a page for good. The assistant acts FOR its
 * user: it may edit what that user holds (from any tab), never what someone
 * else holds.
 */

export const LOCK_TTL_MS = 90_000
export const HEARTBEAT_MS = 30_000
/** Stop heartbeating after this long without keyboard/mouse activity. */
export const IDLE_MS = 5 * 60_000

export interface EditLock {
  targetKey: string
  userId: string
  userName: string | null
  tabId: string
  heartbeatAt: Date
  requestedById?: string | null
  requestedByName?: string | null
}

export interface Claimant {
  userId: string
  userName: string | null
  tabId: string
}

export type LockState =
  | { kind: 'mine'; lock: EditLock }
  | { kind: 'other-user'; holder: string; holderId: string; requested: boolean }
  | { kind: 'other-tab'; lock: EditLock }

export function isLive(lock: EditLock | null | undefined, now: Date): lock is EditLock {
  return !!lock && now.getTime() - lock.heartbeatAt.getTime() < LOCK_TTL_MS
}

function holderName(lock: EditLock): string {
  return lock.userName?.trim() || 'Someone else'
}

/** How the target looks to `me` (a person in one tab). */
export function lockStateFor(lock: EditLock | null, me: Claimant, now: Date): LockState | { kind: 'free' } {
  if (!isLive(lock, now)) return { kind: 'free' }
  if (lock.userId !== me.userId) return { kind: 'other-user', holder: holderName(lock), holderId: lock.userId, requested: lock.requestedById === me.userId }
  return lock.tabId === me.tabId ? { kind: 'mine', lock } : { kind: 'other-tab', lock }
}

/**
 * Taking a claim. Free (or expired) → granted. Mine → renewed. My other tab →
 * only when I choose to move it here ("Edit here instead"). Someone else's
 * live claim → refused; I can only ask.
 */
export function decideAcquire(
  lock: EditLock | null,
  me: Claimant,
  now: Date,
  opts: { moveFromOtherTab?: boolean } = {}
): { granted: true; lock: EditLock } | { granted: false; state: LockState } {
  const state = lockStateFor(lock, me, now)
  const fresh = (keepRequest: boolean): EditLock => ({
    targetKey: lock?.targetKey ?? '',
    userId: me.userId,
    userName: me.userName,
    tabId: me.tabId,
    heartbeatAt: now,
    requestedById: keepRequest ? lock?.requestedById ?? null : null,
    requestedByName: keepRequest ? lock?.requestedByName ?? null : null,
  })
  if (state.kind === 'free') return { granted: true, lock: fresh(false) }
  if (state.kind === 'mine') return { granted: true, lock: fresh(true) }
  if (state.kind === 'other-tab' && opts.moveFromOtherTab) return { granted: true, lock: fresh(true) }
  return { granted: false, state }
}

/** The assistant acting for `userId`: allowed unless someone else holds the target. */
export function agentMayEdit(lock: EditLock | null, userId: string | null, now: Date): { ok: true } | { ok: false; holder: string } {
  if (!isLive(lock, now)) return { ok: true }
  if (userId && lock.userId === userId) return { ok: true }
  return { ok: false, holder: holderName(lock) }
}

/** Approving a change to a target someone else is editing → warn first. */
export function approvalWarning(lock: EditLock | null, reviewerId: string | null, now: Date): string | null {
  if (!isLive(lock, now) || (reviewerId && lock.userId === reviewerId)) return null
  return `${holderName(lock)} is editing this right now. Approving may change what they are working on.`
}

/** The lock key for a change target, or null when the target isn't editable content. */
export function lockKeyFor(targetType: string, targetId: string | null): string | null {
  if (!targetId) return null
  if (targetType === 'page-content' || targetType === 'page' || targetType === 'page-status') return `page:${targetId}`
  if (targetType === 'record' || targetType === 'record-status') return `record:${targetId}`
  if (targetType === 'site-layout') return `layout:${targetId}`
  if (targetType === 'partial') return `partial:${targetId}`
  if (targetType === 'form') return `form:${targetId}`
  if (targetType === 'blog-post' || targetType === 'blog-status') return `post:${targetId}`
  return null
}

/** The refusal the assistant gives when someone else is editing. */
export function agentRefusal(holder: string): string {
  return `${holder} is editing this page right now, so I won't change it. I can draft it once they're done, or you can ask them to hand it over.`
}

/**
 * May this tab edit? Only while it holds the claim or nobody does (or the
 * screen has no lock). Still loading, held by someone else, or held by my
 * other tab: read-only.
 */
export function canEditView(target: string | null, kind: string): boolean {
  return !target || kind === 'mine' || kind === 'free'
}

/**
 * An edit function that does nothing while editing isn't allowed — the guard
 * behind every way a screen changes its document (typing, the canvas, undo,
 * the assistant), so a disabled input is not the only thing in the way.
 */
export function gateEdit<A extends unknown[]>(allowed: () => boolean, fn: (...args: A) => void): (...args: A) => void {
  return (...args: A) => {
    if (allowed()) fn(...args)
  }
}
