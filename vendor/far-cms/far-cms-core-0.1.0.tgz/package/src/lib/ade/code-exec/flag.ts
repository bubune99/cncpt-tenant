/**
 * DB-stored code execution gate — pure, asserted by code-exec.assert.ts.
 *
 * vMCP tool handlers, workflow expressions and plugin primitives are code
 * stored in the database and run with new Function / AsyncFunction. Anyone
 * who can write those rows can run code on the server, so execution is OFF
 * unless a super admin explicitly turns it on.
 *
 * The flag is read through an injected loader and cached briefly. Callers
 * that are synchronous (workflow expression evaluation) read the cached
 * value, which is OFF when cold, failed or older than the TTL: they fail
 * closed until something async refreshes it (the workflow engine does,
 * before every run).
 */

export class CodeExecutionDisabledError extends Error {
  constructor(what: string) {
    super(
      `${what} is disabled: running code stored in the database is turned off. ` +
        'A super admin can enable it in Admin → To-do → Assistant settings.'
    )
    this.name = 'CodeExecutionDisabledError'
  }
}

/**
 * Who asked for stored code to run. Absent for a background run (a stored
 * workflow firing) — that code was stored by a super admin (storing is
 * owner-only). With the flag on, a person-triggered run still needs a super
 * admin: the sandbox is not an isolation boundary, so running code is
 * server-code authority.
 */
export interface CodeActor {
  isSuperAdmin: boolean
}

export class CodeActorRefusedError extends Error {
  constructor(what: string) {
    super(`${what} is limited to the site owner (super admin).`)
    this.name = 'CodeActorRefusedError'
  }
}

/** Throw unless the run is a background run or the person is a super admin. */
export function assertCodeActor(what: string, actor: CodeActor | null | undefined): void {
  if (actor && actor.isSuperAdmin !== true) throw new CodeActorRefusedError(what)
}

export interface CodeExecGate {
  /** Async, authoritative (refreshes the cache when stale). */
  isEnabled(): Promise<boolean>
  /** Sync, last known value — false until loaded and once older than the TTL. */
  isEnabledCached(): boolean
  /** Throw CodeExecutionDisabledError unless enabled. */
  assertEnabled(what: string): Promise<void>
  /** Forget the cached value (after the setting changes). */
  invalidate(): void
}

export function createCodeExecGate(opts: {
  load: () => Promise<boolean>
  ttlMs?: number
  now?: () => number
}): CodeExecGate {
  const ttl = opts.ttlMs ?? 30_000
  const now = opts.now ?? (() => Date.now())
  let value = false
  let loadedAt = -Infinity

  async function isEnabled(): Promise<boolean> {
    if (now() - loadedAt < ttl) return value
    try {
      value = (await opts.load()) === true
    } catch {
      value = false
    }
    loadedAt = now()
    return value
  }

  return {
    isEnabled,
    isEnabledCached: () => value && now() - loadedAt < ttl,
    async assertEnabled(what: string) {
      if (!(await isEnabled())) throw new CodeExecutionDisabledError(what)
    },
    invalidate() {
      loadedAt = -Infinity
    },
  }
}
