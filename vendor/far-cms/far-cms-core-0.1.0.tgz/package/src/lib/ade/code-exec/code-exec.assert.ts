/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/code-exec/code-exec.assert.ts
 * The DB-code execution gate fails closed: off until loaded, off on a failed
 * or non-boolean read, off again once the cache is stale.
 */
import assert from 'node:assert/strict'
import { CodeActorRefusedError, CodeExecutionDisabledError, assertCodeActor, createCodeExecGate } from './flag'

let n = 0
const check = async (name: string, fn: () => void | Promise<void>) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }

async function main() {
  await check('off before anything loads (the synchronous path fails closed)', () => {
    const g = createCodeExecGate({ load: async () => true })
    assert.equal(g.isEnabledCached(), false)
  })

  await check('off when the setting is off, unreadable, or anything but literal true', async () => {
    for (const load of [async () => false, async () => { throw new Error('db down') }, async () => 'true' as unknown as boolean, async () => 1 as unknown as boolean]) {
      const g = createCodeExecGate({ load })
      assert.equal(await g.isEnabled(), false)
      assert.equal(g.isEnabledCached(), false)
      await assert.rejects(g.assertEnabled('Running vMCP tools'), CodeExecutionDisabledError)
    }
  })

  await check('on only after a super admin turns it on — and the cached "on" expires with the TTL', async () => {
    let t = 0
    const g = createCodeExecGate({ load: async () => true, ttlMs: 30_000, now: () => t })
    assert.equal(await g.isEnabled(), true)
    assert.equal(g.isEnabledCached(), true)
    t = 30_001
    assert.equal(g.isEnabledCached(), false, 'stale → off until re-read')
  })

  await check('turning it off takes effect on invalidate (no waiting out the cache)', async () => {
    let on = true
    let loads = 0
    const g = createCodeExecGate({ load: async () => { loads++; return on }, now: () => 0 })
    assert.equal(await g.isEnabled(), true)
    on = false
    assert.equal(await g.isEnabled(), true, 'cached within the TTL')
    g.invalidate()
    assert.equal(await g.isEnabled(), false)
    assert.equal(loads, 2)
  })

  await check('the refusal says what was blocked and who can change it', () => {
    const e = new CodeExecutionDisabledError('Evaluating workflow expressions')
    assert.match(e.message, /^Evaluating workflow expressions is disabled/)
    assert.match(e.message, /super admin/)
  })

  await check('with the flag on, a person-started run needs a super admin; a background run (no actor) does not', () => {
    assert.throws(() => assertCodeActor('Running plugin code', { isSuperAdmin: false }), CodeActorRefusedError)
    assert.doesNotThrow(() => assertCodeActor('Running plugin code', { isSuperAdmin: true }))
    assert.doesNotThrow(() => assertCodeActor('Running plugin code', undefined))
    // Anything but a literal true is not a super admin.
    assert.throws(() => assertCodeActor('x', { isSuperAdmin: 'yes' as unknown as boolean }), CodeActorRefusedError)
  })
}

main().then(() => console.log(`\n${n} checks passed`)).catch((e) => { console.error(e); process.exit(1) })
