/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/briefing.assert.ts
 */
import assert from 'node:assert/strict'
import { countThings, leadText } from './briefing'
import { screenFor } from './screens'

assert.equal(countThings(2), 'Two things')
assert.equal(countThings(1), 'One thing')
assert.equal(countThings(0), 'No things')
assert.equal(countThings(11), '11 things')
assert.equal(leadText(['You’re writing the ', { strong: 'October update' }, ' to 1,284 subscribers.']), 'You’re writing the October update to 1,284 subscribers.')
// The manifest names a briefing per screen (email editor) and none elsewhere.
assert.equal(screenFor('/admin/email-marketing/cmp_1').briefing, 'email-editor')
assert.equal(screenFor('/admin/email-marketing/new').briefing, undefined)
assert.equal(screenFor('/admin/email-marketing').briefing, undefined)
assert.equal(screenFor('/admin').briefing, undefined)
console.log('9 assertions passed')
