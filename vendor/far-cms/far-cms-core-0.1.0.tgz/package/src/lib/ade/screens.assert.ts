/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/screens.assert.ts
 */
import assert from 'node:assert/strict'
import { screenFor, screenHasAction, screenHasPanel } from './screens'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('editing tools only while editing', () => {
  const editor = screenFor('/admin/pages/cmv13e31n000106l5x0lnqvqo/editor')
  assert.equal(editor.kind, 'editing')
  for (const p of ['add', 'outline', 'style'] as const) assert.ok(screenHasPanel(editor, p))
  for (const a of ['undo', 'redo', 'submit', 'beforeAfter', 'devices', 'revisions'] as const) assert.ok(screenHasAction(editor, a))
  const media = screenFor('/admin/media')
  assert.equal(media.kind, 'screen')
  assert.equal(media.panels.length, 0)
  assert.ok(!screenHasAction(media, 'undo'))
  assert.ok(screenHasAction(media, 'upload'))
})

check('other screens fall back to plain chat', () => {
  for (const p of ['/admin', '/admin/pages', '/admin/forms', '/admin/pages/abc', '', null]) {
    const s = screenFor(p)
    assert.equal(s.kind, 'screen')
    assert.equal(s.panels.length, 0)
  }
})

check('partials and header/footer are editing screens without page-only actions', () => {
  const partial = screenFor('/admin/partials/p1/editor/')
  assert.equal(partial.kind, 'editing')
  assert.ok(!screenHasAction(partial, 'revisions'))
  assert.equal(screenFor('/admin/site-settings/footer/editor').kind, 'editing')
  assert.ok(screenHasAction(screenFor('/admin/todo/review/x1'), 'beforeAfter'))
})

check('records: list is a screen, one record is an editor without page-only tools', () => {
  assert.equal(screenFor('/admin/records/initiative').key, 'records')
  const rec = screenFor('/admin/records/initiative/cmabc123')
  assert.equal(rec.key, 'record')
  assert.equal(rec.kind, 'editing')
  assert.ok(screenHasAction(rec, 'fullView') && !screenHasAction(rec, 'revisions'))
  assert.equal(rec.panels.length, 0)
  assert.notEqual(screenFor('/admin/records/initiative/new').key, 'record')
})

check('blog: list is a screen; one post is an editor; sub-pages are neither', () => {
  assert.equal(screenFor('/admin/blog').key, 'blog')
  assert.equal(screenFor('/admin/blog/cm123').key, 'post')
  for (const p of ['/admin/blog/new', '/admin/blog/categories', '/admin/blog/tags', '/admin/blog/initiatives']) assert.notEqual(screenFor(p).key, 'post')
})

console.log(`\n${n} checks passed`)
