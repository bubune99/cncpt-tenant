/**
 * The platform map — what each admin area is, what the owner calls it, where
 * it lives and what the assistant can do there. Built from the host app's own
 * sources of truth (its nav, settings sections, record types and tool groups)
 * plus its vocabulary: the words owners use ("projects", "newsletter") for the
 * real thing ("Initiatives", "Email Marketing").
 *
 * Pure and app-agnostic: the host passes everything in (Dzidzor:
 * lib/ade-bindings/platform-map). Asserted by
 * lib/ade-bindings/platform-map.assert.ts.
 */

export interface PlatformNavInput {
  /** The name the owner sees (relabels already applied). */
  name: string
  href: string
  /** The nav group ("Content", "System"). */
  group: string
  /** One-line help text for the item, when the app has one. */
  about?: string
  /** False when the item exists but is kept out of the menu (hidden or unfinished). */
  inMenu?: boolean
}

export interface PlatformSectionInput {
  id: string
  label: string
  description: string
  href: string
  /** Extra words people search with (space separated). */
  keywords?: string
}

export interface PlatformRecordTypeInput {
  key: string
  plural: string
  /** The admin list for this type. */
  href: string
  /** Where published records live on the site ("/initiatives"). */
  pathPrefix?: string
}

/** Something a person does in an area ("Publish", "Add field"), and the assistant tools that do it. */
export interface PlatformAction {
  /** Stable id, snake_case ('publish', 'add_field'). */
  verb: string
  /** The words on the button. */
  label: string
  /** Other labels / phrasings for the same action. */
  synonyms?: ReadonlyArray<string>
  /** Tool names (the app's tool registry keys) that perform it; [] = people only, no assistant tool yet. */
  tools: ReadonlyArray<string>
}

/** The app's words for one entry, keyed by the entry id (an href, `settings:<id>` or `records:<key>`). */
export interface VocabularyEntry {
  /** Words and phrases owners use for it ("projects", "form responses"). */
  synonyms?: ReadonlyArray<string>
  /** Replaces the generated one-liner when the app's help text is stale or missing. */
  about?: string
  /** Extra tool groups, on top of the ones the area's screen loads. */
  tools?: ReadonlyArray<string>
  /** Data models behind it (for the assistant, never shown to the owner). */
  models?: ReadonlyArray<string>
  /**
   * Words that are NOT this feature but whose closest real thing here it is
   * ("projects" → Initiatives), with why. Never matched as the feature — only
   * offered as a suggestion when the site has no such thing.
   */
  closeTo?: ReadonlyArray<{ words: ReadonlyArray<string>; why: string }>
  /** What people do there (buttons / jobs) → the tools that do it. */
  actions?: ReadonlyArray<PlatformAction>
}

export type PlatformVocabulary = Readonly<Record<string, VocabularyEntry>>

export interface PlatformEntry {
  id: string
  /** What the owner sees in the menu or on the Settings screen. */
  name: string
  kind: 'area' | 'records' | 'settings'
  about: string
  href: string
  /** Assistant tool groups for it (load_tools keys); [] = it can only open the screen. */
  tools: string[]
  synonyms: string[]
  models?: string[]
  /** Not-this-feature words → why it is still the nearest thing (see VocabularyEntry.closeTo). */
  closeTo?: Array<{ words: string[]; why: string }>
  actions?: PlatformAction[]
  /** Set when it exists but is not in the menu. */
  inMenu?: false
}

export interface PlatformMapInput {
  nav: ReadonlyArray<PlatformNavInput>
  sections: ReadonlyArray<PlatformSectionInput>
  recordTypes: ReadonlyArray<PlatformRecordTypeInput>
  vocabulary: PlatformVocabulary
  /** Tool groups an admin screen loads (the app's route → group rules). */
  groupsFor: (href: string) => readonly string[]
  /** Areas that do not exist on this site (commerce off): left out of the map. */
  exclude?: (href: string) => boolean
}

const pathOf = (href: string) => href.split('?')[0]

function merge(base: PlatformEntry, words: VocabularyEntry | undefined, extra: string[] = []): PlatformEntry {
  const synonyms = [...new Set([...extra, ...(words?.synonyms ?? [])].map((s) => s.toLowerCase().trim()).filter(Boolean))]
  const tools = [...new Set([...base.tools, ...(words?.tools ?? [])])]
  return {
    ...base,
    about: words?.about ?? base.about,
    tools,
    synonyms,
    ...(words?.models?.length ? { models: [...words.models] } : {}),
    ...(words?.actions?.length ? { actions: words.actions.map((a) => ({ ...a, synonyms: [...(a.synonyms ?? [])], tools: [...a.tools] })) } : {}),
    ...(words?.closeTo?.length ? { closeTo: words.closeTo.map((c) => ({ words: c.words.map((w) => w.toLowerCase()), why: c.why })) } : {}),
  }
}

/**
 * One entry per admin area, record type and settings section, in that order.
 * A record type absorbs the nav item that leads to it (same name, or the nav
 * href is its list's parent path) — the owner's label wins, the more specific href
 * wins. A settings section that only opens a nav screen (Users) folds into
 * that screen's entry as extra words.
 */
export function buildPlatformMap(input: PlatformMapInput): PlatformEntry[] {
  const excluded = (href: string) => input.exclude?.(pathOf(href)) ?? false
  const nav = input.nav.filter((n) => !excluded(n.href))
  // record type key → the nav item that leads to it
  const ownerOf = new Map<string, PlatformNavInput>()
  for (const rt of input.recordTypes) {
    const parent = rt.href.slice(0, rt.href.lastIndexOf('/'))
    const owner = nav.find((n) => n.name.toLowerCase() === rt.plural.toLowerCase()) ?? nav.find((n) => n.href === parent)
    if (owner) ownerOf.set(rt.key, owner)
  }
  const absorbed = new Set([...ownerOf.values()].map((n) => n.href))
  const folded = new Map<string, string[]>()
  const sections = input.sections.filter((s) => {
    if (excluded(s.href)) return false
    const target = nav.find((n) => n.href === s.href)
    if (!target) return true
    folded.set(target.href, [...(folded.get(target.href) ?? []), s.label, ...(s.keywords ?? '').split(/\s+/)])
    return false
  })

  const out: PlatformEntry[] = []
  for (const n of nav) {
    if (absorbed.has(n.href)) continue
    const base: PlatformEntry = {
      id: n.href,
      name: n.name,
      kind: 'area',
      about: n.about ?? `${n.name} (${n.group})`,
      href: n.href,
      tools: [...input.groupsFor(n.href)],
      synonyms: [],
      ...(n.inMenu === false ? { inMenu: false as const } : {}),
    }
    out.push(merge(base, input.vocabulary[n.href], folded.get(n.href)))
  }
  for (const rt of input.recordTypes) {
    if (excluded(rt.href)) continue
    const id = `records:${rt.key}`
    const owner = ownerOf.get(rt.key)
    const base: PlatformEntry = {
      id,
      name: owner?.name ?? rt.plural,
      kind: 'records',
      about: `${rt.plural}: records that each get their own page${rt.pathPrefix ? ` under ${rt.pathPrefix}` : ''}.`,
      href: rt.href,
      tools: [...input.groupsFor(rt.href)],
      synonyms: [],
      ...(owner?.inMenu === false ? { inMenu: false as const } : {}),
    }
    // The owner's label and the type's own name both count as words for it.
    const own = [rt.plural, rt.key, owner?.name ?? ''].filter((w) => w.toLowerCase() !== base.name.toLowerCase())
    out.push(merge(base, input.vocabulary[id] ?? (owner ? input.vocabulary[owner.href] : undefined), own))
  }
  for (const s of sections) {
    const id = `settings:${s.id}`
    const base: PlatformEntry = {
      id,
      name: s.label,
      kind: 'settings',
      about: s.description,
      href: s.href,
      tools: [...input.groupsFor(pathOf(s.href))],
      synonyms: [],
    }
    out.push(merge(base, input.vocabulary[id], (s.keywords ?? '').split(/\s+/)))
  }
  return out
}

// ── Lookup ──────────────────────────────────────────────────────────

const STOP = new Set([
  'a', 'an', 'the', 'to', 'of', 'and', 'or', 'in', 'on', 'for', 'at', 'by', 'with', 'from', 'about', 'into',
  'i', 'me', 'my', 'we', 'our', 'us', 'you', 'your', 'it', 'its', 'this', 'that', 'there', 'these', 'those',
  'is', 'are', 'was', 'be', 'am', 'do', 'does', 'did', 'can', 'could', 'should', 'would', 'will', 'have', 'has', 'get', 'getting',
  'what', 'whats', 'where', 'wheres', 'how', 'who', 'which', 'when', 'why',
  'show', 'see', 'find', 'open', 'go', 'take', 'make', 'add', 'new', 'create', 'change', 'edit', 'update', 'set', 'manage', 'send', 'write', 'list', 'view', 'put', 'use', 'want', 'need',
  'all', 'any', 'some', 'up', 'out', 'site', 'website', 'admin', 'page', 'screen', 'thing', 'things', 'stuff', 'please', 'much', 'many',
])

/** Lowercase, plural → singular ("programs" → "program", "categories" → "category"; "news", "class" stay). */
export function stemWord(w: string): string {
  if (w.length > 4 && w.endsWith('ies')) return `${w.slice(0, -3)}y`
  if (w.length > 4 && w.endsWith('s') && !/(ss|us|is)$/.test(w)) return w.slice(0, -1)
  return w
}

function words(text: string): string[] {
  return text.toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9\s-]/g, ' ').split(/[\s]+/).flatMap((w) => [w, ...(w.includes('-') ? [w.replace(/-/g, '')] : [])]).filter(Boolean)
}

const terms = (text: string) => words(text).filter((w) => !STOP.has(w)).map(stemWord)

export interface PlatformMatch {
  entry: PlatformEntry
  score: number
  /** The owner's words that matched. */
  matched: string[]
}

/**
 * Entries for a plain-language question, best first. Scoring per query word:
 * part of the name 4, a one-word synonym 4, a word of a longer synonym 2, the
 * about line 1; a whole multi-word synonym found in the question ("form
 * responses") adds 3 more. Ties keep map
 * order. Words like "where / how / change" are ignored.
 */
export function findPlatformEntries(map: ReadonlyArray<PlatformEntry>, query: string, limit = 3): PlatformMatch[] {
  const q = terms(query)
  if (!q.length) return []
  const qPhrase = ` ${words(query).map(stemWord).join(' ')} `
  const scored = map.map((entry, order) => {
    const name = new Set(terms(entry.name))
    const syn = new Set(entry.synonyms.filter((x) => words(x).length === 1).flatMap(terms))
    const synPart = new Set(entry.synonyms.flatMap(terms))
    const about = new Set(terms(entry.about))
    let score = 0
    const matched = new Set<string>()
    for (const w of q) {
      const s = name.has(w) || syn.has(w) ? 4 : synPart.has(w) ? 2 : about.has(w) ? 1 : 0
      if (s) { score += s; if (s > 1) matched.add(w) }
    }
    for (const phrase of entry.synonyms) {
      const p = words(phrase).map(stemWord)
      if (p.length > 1 && qPhrase.includes(` ${p.join(' ')} `)) { score += 3; matched.add(phrase) }
    }
    return { entry, score, matched: [...matched], order }
  })
  return scored
    .filter((x) => x.score > 1)
    .sort((a, b) => b.score - a.score || a.order - b.order)
    .slice(0, limit)
    .map(({ entry, score, matched }) => ({ entry, score, matched }))
}

/** One line per entry — what describe_platform returns when asked for everything. */
export function platformIndex(map: ReadonlyArray<PlatformEntry>): string {
  return map.map((e) => `${e.name} — ${e.href}${e.synonyms.length ? ` (also: ${e.synonyms.slice(0, 4).join(', ')})` : ''}`).join('\n')
}

/**
 * The entry a screen belongs to: exact href first (query included, for
 * `?section=` links), else the longest entry path that is a parent of the
 * pathname. `/admin` only matches itself, never every admin screen.
 */
export function entryForRoute(map: ReadonlyArray<PlatformEntry>, route: string | null | undefined): PlatformEntry | null {
  const r = (route ?? '').trim().replace(/\/+(?=\?|$)/, '')
  if (!r) return null
  const exact = map.find((e) => e.href === r)
  if (exact) return exact
  const path = pathOf(r)
  let best: PlatformEntry | null = null
  for (const e of map) {
    const p = pathOf(e.href)
    if (e.href.includes('?') || p === '/admin') continue
    if ((path === p || path.startsWith(`${p}/`)) && (!best || p.length > pathOf(best.href).length)) best = e
  }
  return best ?? (path === '/admin' ? map.find((e) => e.href === '/admin') ?? null : null)
}

/** The question's own content words, in their original form ("what are projects?" → "projects"). */
export function queryTerm(query: string): string {
  const raw = query.toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/)
  return [...new Set(raw.filter((w) => w && !STOP.has(w)))].join(' ')
}

function editDistance(a: string, b: string): number {
  if (Math.abs(a.length - b.length) > 2) return 3
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i)
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]
    for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1))
    prev = cur
  }
  return prev[b.length]
}

export interface PlatformSuggestion {
  entry: PlatformEntry
  why: string
}

/**
 * For a question that matched nothing: the nearest REAL features, as
 * suggestions only. First the app's own closeTo words ("projects" →
 * Initiatives), then near-spellings of a name or one-word synonym (a typo
 * like "inititives"). Never a substitute — the caller must say the site has
 * no such thing.
 */
export function closestEntries(map: ReadonlyArray<PlatformEntry>, query: string, limit = 2): PlatformSuggestion[] {
  const q = terms(query)
  if (!q.length) return []
  const out: PlatformSuggestion[] = []
  const add = (entry: PlatformEntry, why: string) => { if (out.length < limit && !out.some((x) => x.entry === entry)) out.push({ entry, why }) }
  for (const e of map) for (const c of e.closeTo ?? []) if (c.words.some((w) => terms(w).every((t) => q.includes(t)))) add(e, c.why)
  for (const e of map) {
    const own = [...terms(e.name), ...e.synonyms.filter((x) => words(x).length === 1).flatMap(terms)]
    // Same first letter, 1 edit (2 for long words): "inititives" yes, "donor" → "color" no.
    const near = q.find((w) => w.length >= 5 && own.some((o) => o.length >= 5 && o[0] === w[0] && editDistance(w, o) <= (w.length >= 8 ? 2 : 1)))
    if (near) add(e, `similar spelling to "${e.name}"`)
  }
  return out
}

const phrase = (text: string) => ` ${text.toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean).map(stemWord).join(' ')} `

/**
 * The action a UI label stands for in an entry ("Submit for review" →
 * submit_review): the label or a synonym equals the label, else the longest
 * label / synonym found inside it ("Publish now" → publish). null = unknown.
 */
export function findAction(entry: PlatformEntry, label: string): PlatformAction | null {
  const l = phrase(label)
  if (!l.trim()) return null
  let best: { action: PlatformAction; len: number } | null = null
  for (const action of entry.actions ?? []) {
    for (const p of [action.label, ...(action.synonyms ?? [])].map(phrase)) {
      if (!p.trim()) continue
      if (p === l) return action
      if (l.includes(p) && (!best || p.length > best.len)) best = { action, len: p.length }
    }
  }
  return best?.action ?? null
}

