/**
 * ChangeSet service — propose / review / apply, over injected storage and
 * per-target adapters. No app imports: the Prisma store and the page/blog
 * adapters live in the host app (src/lib/ade-bindings for Dzidzor).
 */

import { canReview, claimableFrom, deriveSetStatus, isStale, statusAfter } from './logic'
import type {
  Actor,
  ChangeSetItemRecord,
  ChangeSetRecord,
  ChangeSource,
  Drafter,
  ItemStatus,
  ProposedBundle,
  ProposedChange,
  ReviewAction,
  SetStatus,
  TargetAdapter,
} from './types'

export interface ChangeSetStore {
  /** Most recent still-open set for this owner+source touched since `since`. */
  findOpenSet(ownerId: string | null, source: ChangeSource, since: Date): Promise<ChangeSetRecord | null>
  createSet(data: { ownerId: string | null; source: ChangeSource; title: string }): Promise<ChangeSetRecord>
  setStatus(id: string, status: SetStatus): Promise<void>
  /** Record why the assistant proposed this change set (shown on the review card). Optional for older stores. */
  noteWhy?(id: string, why: string): Promise<void>
  /** The pending item for this target in this set, if any. */
  findPendingItem(changeSetId: string, targetType: string, targetId: string): Promise<ChangeSetItemRecord | null>
  createItem(data: Omit<ChangeSetItemRecord, 'id' | 'status' | 'error' | 'resultId'>): Promise<ChangeSetItemRecord>
  /**
   * Atomically move an item from one of `from` to `to`; false if another
   * reviewer (or a concurrent request) got there first.
   */
  claimItem(id: string, from: ItemStatus[], to: ItemStatus, decidedById?: string | null): Promise<boolean>
  /** Fold an edit into an item only while it is still pending; null if it no longer is. */
  foldIntoPending(
    id: string,
    patch: Pick<ChangeSetItemRecord, 'input' | 'after' | 'blockIds' | 'rationale' | 'category'>
  ): Promise<ChangeSetItemRecord | null>
  updateItem(
    id: string,
    patch: Partial<Pick<ChangeSetItemRecord, 'input' | 'after' | 'blockIds' | 'rationale' | 'status' | 'error' | 'resultId'>> & {
      decidedById?: string | null
      /** The version the apply recorded (adapter.apply's revisionId). */
      revisionId?: string | null
    }
  ): Promise<ChangeSetItemRecord>
  getItems(ids: string[]): Promise<ChangeSetItemRecord[]>
  /** Items still open (pending / saved / stale / failed) that edit any of these targets. Optional for older stores. */
  findOpenItemsForTargets?(targets: ReadonlyArray<{ targetType: string; targetId: string }>): Promise<ChangeSetItemRecord[]>
  listItemStatuses(changeSetId: string): Promise<ItemStatus[]>
  addComment(data: {
    changeSetId: string
    itemId: string | null
    actor: Actor
    kind: 'comment' | 'revise'
    body: string
  }): Promise<void>
}

export interface ChangeSetServiceDeps {
  store: ChangeSetStore
  drafters: Readonly<Record<string, Drafter>>
  adapters: Readonly<Record<string, TargetAdapter>>
  /** A set keeps collecting an agent's calls while it was touched this recently. */
  groupWindowMs?: number
  now?: () => Date
}

export interface ProposeRequest {
  ownerId: string | null
  source: ChangeSource
  toolName: string
  input: Record<string, unknown>
  /** One short sentence: why the assistant proposes it, in the person's terms (owner 2026-10-17). */
  why?: string
}

export type ProposeResult =
  | { ok: true; changeSetId: string; itemId: string; merged: boolean; change: ProposedChange; itemIds?: string[] }
  | { ok: false; error: string }

export interface ReviewOutcome {
  itemId: string
  status: ItemStatus
  error?: string
  resultId?: string
  revisionId?: string
}

const DEFAULT_GROUP_WINDOW_MS = 30 * 60 * 1000

/** A "why" as shown: one line, trimmed, at most WHY_MAX characters. */
/** Why a change was closed when its target was deleted (kept on the item and noted on the set). */
export const TARGET_DELETED_REASON = 'Target deleted'

export const WHY_MAX = 240
export function cleanWhy(why: unknown): string | null {
  if (typeof why !== 'string') return null
  const t = why.replace(/\s+/g, ' ').trim()
  return t ? t.slice(0, WHY_MAX) : null
}

/** Several edits in one set: each distinct reason once, in order. */
export function joinWhy(prev: string | null, next: string): string {
  if (!prev) return next
  return prev.split(' · ').includes(next) ? prev : `${prev} · ${next}`.slice(0, 600)
}

export function createChangeSetService(deps: ChangeSetServiceDeps) {
  const { store, drafters, adapters } = deps
  const now = deps.now ?? (() => new Date())
  const windowMs = deps.groupWindowMs ?? DEFAULT_GROUP_WINDOW_MS

  function canDraft(toolName: string): boolean {
    return Object.hasOwn(drafters, toolName)
  }

  async function refreshSetStatus(changeSetId: string): Promise<SetStatus> {
    const status = deriveSetStatus(await store.listItemStatuses(changeSetId))
    await store.setStatus(changeSetId, status)
    return status
  }

  /** Turn an agent tool call into (or fold it into) a pending ChangeSet item, with its "why" on the set. */
  async function propose(req: ProposeRequest): Promise<ProposeResult> {
    const r = await proposeItem(req)
    const why = cleanWhy(req.why)
    if (r.ok && why && store.noteWhy) await store.noteWhy(r.changeSetId, why)
    return r
  }

  async function proposeItem(req: ProposeRequest): Promise<ProposeResult> {
    const drafter = drafters[req.toolName]
    if (!drafter) return { ok: false, error: `'${req.toolName}' can't be drafted.` }

    const since = new Date(now().getTime() - windowMs)
    let set = await store.findOpenSet(req.ownerId, req.source, since)

    // Resolve the target first so a second edit to the same page folds into
    // the existing item — and is drafted on top of it (its `after`).
    const target = await drafter.target(req.input)
    if (target && 'error' in target) return { ok: false, error: target.error }

    let pending: ChangeSetItemRecord | null = null
    if (set && target) {
      pending = await store.findPendingItem(set.id, target.targetType, target.targetId)
    }
    const drafted = await drafter.draft(req.input, pending)
    if ('error' in drafted) return { ok: false, error: drafted.error }
    if ('bundle' in drafted) return proposeBundle(req, drafted)
    const change = drafted

    if (!set) {
      set = await store.createSet({
        ownerId: req.ownerId,
        source: req.source,
        title: change.summary,
      })
    }

    if (pending) {
      const item = await store.foldIntoPending(pending.id, {
        input: change.input,
        after: change.after,
        blockIds: change.blockIds,
        rationale: joinSummary(pending.rationale, change.summary),
        // The drafter decides (e.g. an edit that publishes moves the item to 'publish').
        category: change.category,
      })
      if (item) {
        await refreshSetStatus(set.id)
        return { ok: true, changeSetId: set.id, itemId: item.id, merged: true, change }
      }
      // It was approved/rejected meanwhile: this edit becomes its own item,
      // drafted against the live target.
      const fresh = await drafter.draft(req.input, null)
      if ('error' in fresh) return { ok: false, error: fresh.error }
      if ('bundle' in fresh) return proposeBundle(req, fresh)
      return proposeFresh(set.id, req, fresh)
    }

    return proposeFresh(set.id, req, change)
  }

  /** A bundle is its own change set; items are created (and later applied) in order. */
  async function proposeBundle(req: ProposeRequest, b: ProposedBundle): Promise<ProposeResult> {
    if (b.bundle.length === 0) return { ok: false, error: 'Nothing to propose' }
    const set = await store.createSet({ ownerId: req.ownerId, source: req.source, title: b.title })
    const itemIds: string[] = []
    for (const change of b.bundle) {
      const item = await store.createItem({
        changeSetId: set.id,
        targetType: change.targetType,
        targetId: change.targetId,
        operation: change.operation,
        category: change.category,
        toolName: req.toolName,
        input: change.input,
        before: change.before,
        after: change.after,
        blockIds: change.blockIds,
        rationale: change.summary,
      })
      itemIds.push(item.id)
    }
    await refreshSetStatus(set.id)
    return { ok: true, changeSetId: set.id, itemId: itemIds[0], merged: false, change: b.bundle[0], itemIds }
  }

  async function proposeFresh(changeSetId: string, req: ProposeRequest, change: ProposedChange): Promise<ProposeResult> {
    const item = await store.createItem({
      changeSetId,
      targetType: change.targetType,
      targetId: change.targetId,
      operation: change.operation,
      category: change.category,
      toolName: req.toolName,
      input: change.input,
      before: change.before,
      after: change.after,
      blockIds: change.blockIds,
      rationale: change.summary,
    })
    await refreshSetStatus(changeSetId)
    return { ok: true, changeSetId, itemId: item.id, merged: false, change }
  }

  async function applyOne(item: ChangeSetItemRecord, actor: Actor): Promise<ReviewOutcome> {
    const adapter = adapters[item.targetType]
    if (!adapter) {
      await store.updateItem(item.id, { status: 'failed', error: `No adapter for ${item.targetType}`, decidedById: actor.id })
      return { itemId: item.id, status: 'failed', error: `No adapter for ${item.targetType}` }
    }
    if (item.operation === 'update' && item.targetId) {
      const live = await adapter.snapshot(item.targetId)
      if (isStale(item.operation, item.before, live)) {
        const error = 'The target changed after the agent drafted this — review the live version and ask the agent to redo it.'
        await store.updateItem(item.id, { status: 'stale', error, decidedById: actor.id })
        return { itemId: item.id, status: 'stale', error }
      }
    }
    try {
      const { resultId, revisionId } = await adapter.apply(item, actor)
      // Keep the version it recorded: the chat's change card shows it (Version / Compare / Restore).
      await store.updateItem(item.id, { status: 'approved', error: null, resultId: resultId ?? item.targetId, revisionId: revisionId ?? null, decidedById: actor.id })
      return { itemId: item.id, status: 'approved', resultId: resultId ?? item.targetId ?? undefined, ...(revisionId ? { revisionId } : {}) }
    } catch (e) {
      const error = e instanceof Error ? e.message : 'Apply failed'
      await store.updateItem(item.id, { status: 'failed', error, decidedById: actor.id })
      return { itemId: item.id, status: 'failed', error }
    }
  }

  /** Approve / reject / save-for-later a batch of items. */
  async function review(itemIds: string[], action: ReviewAction, actor: Actor): Promise<ReviewOutcome[]> {
    const items = await store.getItems(itemIds)
    const outcomes: ReviewOutcome[] = []
    const touchedSets = new Set<string>()
    for (const item of items) {
      touchedSets.add(item.changeSetId)
      if (!canReview(item.status, action)) {
        outcomes.push({ itemId: item.id, status: item.status, error: `Item is already ${item.status}.` })
        continue
      }
      // Claim first, so a double click or a racing request can't apply twice.
      const to = action === 'approve' ? 'applying' : statusAfter(action)
      if (!(await store.claimItem(item.id, claimableFrom(action), to, actor.id))) {
        outcomes.push({ itemId: item.id, status: item.status, error: 'Someone else is already reviewing this change.' })
        continue
      }
      if (action !== 'approve') {
        outcomes.push({ itemId: item.id, status: to })
        continue
      }
      // Re-read after the claim: a fold may have landed before it.
      const [claimed] = await store.getItems([item.id])
      outcomes.push(await applyOne(claimed ?? item, actor))
    }
    for (const id of touchedSets) await refreshSetStatus(id)
    return outcomes
  }

  async function comment(
    changeSetId: string,
    itemId: string | null,
    actor: Actor,
    body: string,
    kind: 'comment' | 'revise' = 'comment'
  ): Promise<void> {
    const text = body.trim()
    if (!text) throw new Error('Comment is empty')
    await store.addComment({ changeSetId, itemId, actor, kind, body: text.slice(0, 4000) })
  }

  /**
   * The target was deleted: its open changes can never land, so close them —
   * discarded (rejected) with the reason kept on the item and a note on the set.
   * Never deleted: the audit trail stays. Creates are left alone (nothing to land on yet).
   */
  async function closeForDeletedTargets(
    targets: ReadonlyArray<{ targetType: string; targetId: string }>,
    actor: Actor,
    reason: string = TARGET_DELETED_REASON
  ): Promise<{ closed: string[] }> {
    if (!targets.length || !store.findOpenItemsForTargets) return { closed: [] }
    const items = await store.findOpenItemsForTargets(targets)
    const closed: string[] = []
    const sets = new Set<string>()
    for (const item of items) {
      if (item.operation === 'create' || !(item.targetId && targets.some((t) => t.targetType === item.targetType && t.targetId === item.targetId))) continue
      if (!(await store.claimItem(item.id, claimableFrom('reject'), 'rejected', actor.id))) continue
      await store.updateItem(item.id, { error: reason })
      closed.push(item.id)
      sets.add(item.changeSetId)
    }
    for (const id of sets) {
      await store.addComment({ changeSetId: id, itemId: null, actor, kind: 'comment', body: reason })
      await refreshSetStatus(id)
    }
    return { closed }
  }

  return { canDraft, propose, review, comment, refreshSetStatus, closeForDeletedTargets }
}

export type ChangeSetService = ReturnType<typeof createChangeSetService>

function joinSummary(prev: string | null, next: string): string {
  if (!prev) return next
  const lines = prev.split('\n')
  return lines.includes(next) ? prev : [...lines, next].slice(-20).join('\n')
}
