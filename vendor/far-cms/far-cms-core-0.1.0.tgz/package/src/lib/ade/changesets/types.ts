/**
 * ChangeSet types — the draft/review queue's vocabulary. No app imports.
 */

// admin = a person editing through an admin form (still reviewed)
export type ChangeSource = 'chat' | 'mcp' | 'workflow' | 'admin'

// applying = claimed by one reviewer while its change is written (never shown long)
export const ITEM_STATUSES = ['pending', 'applying', 'approved', 'rejected', 'saved', 'stale', 'failed'] as const
export type ItemStatus = (typeof ITEM_STATUSES)[number]

// done = nothing left to act on, but the outcomes were mixed
export type SetStatus = 'pending' | 'partial' | 'approved' | 'rejected' | 'saved' | 'done'

/** resume = bring a saved-for-later item back to waiting (undo "Not now"). */
export type ReviewAction = 'approve' | 'reject' | 'save' | 'resume'

export type Operation = 'create' | 'update'

/** What a drafter produces from one agent tool call. */
export interface ProposedChange {
  targetType: string
  /** null for creates */
  targetId: string | null
  operation: Operation
  /** Earned-autonomy bucket; bulk approve works per category. */
  category: string
  /** Snapshot of the target as the agent saw it (null for creates). */
  before: unknown
  /** The target as it would be after applying. */
  after: unknown
  /** Tool input to replay on apply (merged across calls for one target). */
  input: Record<string, unknown>
  /** Block ids touched — the preview spotlights these. */
  blockIds: string[]
  /** One-line summary shown on the review card. */
  summary: string
}

export interface ChangeSetItemRecord {
  id: string
  changeSetId: string
  targetType: string
  targetId: string | null
  operation: Operation
  category: string
  toolName: string
  input: Record<string, unknown>
  before: unknown
  after: unknown
  blockIds: string[]
  rationale: string | null
  status: ItemStatus
  error: string | null
  resultId: string | null
}

export interface ChangeSetRecord {
  id: string
  ownerId: string | null
  source: ChangeSource
  title: string
  status: SetStatus
  updatedAt: Date
}

export interface Actor {
  id?: string | null
  email?: string | null
}

/**
 * Turns one tool call into a ProposedChange. `target` resolves which entity
 * the call edits (null for creates) WITHOUT drafting, so the service can find
 * a pending item for it first; `draft` then builds on that item's `after`
 * (an edit may depend on an earlier draft, e.g. nesting in a drafted block).
 */
export interface Drafter {
  target(input: Record<string, unknown>): Promise<{ targetType: string; targetId: string } | null | { error: string }>
  draft(input: Record<string, unknown>, pending: ChangeSetItemRecord | null): Promise<ProposedChange | ProposedBundle | { error: string }>
}

/**
 * Several changes that only make sense together (a new record + its page +
 * publishing both). Always a NEW change set; items apply in this order.
 */
export interface ProposedBundle {
  bundle: ProposedChange[]
  title: string
}

/** Knows how to read the live state of, and apply changes to, one target type. */
export interface TargetAdapter {
  /** Live state in the same shape as ProposedChange.before (null if gone). */
  snapshot(targetId: string): Promise<unknown>
  /**
   * Apply the item; returns the id of the created/updated entity and, when
   * the host versions it (lib/ade/history), the revision the apply recorded.
   */
  apply(item: ChangeSetItemRecord, actor: Actor): Promise<{ resultId?: string; revisionId?: string | null; version?: number | null }>
}
