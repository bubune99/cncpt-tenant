/**
 * ChangeSet pure logic — status derivation, staleness, diffs.
 * Asserted by changesets.assert.ts.
 */

import type { ItemStatus, ReviewAction, SetStatus } from './types'

/** Statuses a reviewer can still act on. */
export function isOpen(status: ItemStatus): boolean {
  return status === 'pending' || status === 'saved'
}

/** Whether `action` is allowed on an item in `status`. */
export function canReview(status: ItemStatus, action: ReviewAction): boolean {
  // Only something parked can be brought back.
  if (action === 'resume') return status === 'saved'
  if (status === 'pending') return true
  // Saved-for-later can be approved or rejected later, not re-saved.
  if (status === 'saved') return action !== 'save'
  // An out-of-date or failed item can only be cleared away (rejected).
  if (status === 'stale' || status === 'failed') return action === 'reject'
  return false
}

/** Statuses an item may be claimed from for `action` (the atomic guard). */
export function claimableFrom(action: ReviewAction): ItemStatus[] {
  return (['pending', 'saved', 'stale', 'failed'] as const).filter((s) => canReview(s, action))
}

/** Item status after a review action (approve's final status is set by apply). */
export function statusAfter(action: ReviewAction): ItemStatus {
  return action === 'reject' ? 'rejected' : action === 'save' ? 'saved' : action === 'resume' ? 'pending' : 'approved'
}

/**
 * A set's status from its items:
 *   any pending/applying     → pending (or partial if something was decided)
 *   none pending, some saved → saved
 *   all approved             → approved;  all rejected → rejected
 *   any other decided mix    → done (nothing left to act on)
 */
export function deriveSetStatus(items: ReadonlyArray<ItemStatus>): SetStatus {
  if (items.length === 0) return 'pending'
  const open = items.filter((s) => s === 'pending' || s === 'applying').length
  const saved = items.filter((s) => s === 'saved').length
  if (open > 0) return open === items.length ? 'pending' : 'partial'
  if (saved > 0) return 'saved'
  if (items.every((s) => s === 'approved')) return 'approved'
  if (items.every((s) => s === 'rejected')) return 'rejected'
  return 'done'
}

/** Deterministic JSON: object keys sorted, so equal data compares equal. */
export function stableStringify(value: unknown): string {
  return JSON.stringify(value, (_k, v) => {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      return Object.keys(v as Record<string, unknown>)
        .sort()
        .reduce<Record<string, unknown>>((acc, k) => {
          acc[k] = (v as Record<string, unknown>)[k]
          return acc
        }, {})
    }
    return v
  })
}

export function stableEqual(a: unknown, b: unknown): boolean {
  return stableStringify(a ?? null) === stableStringify(b ?? null)
}

/**
 * An update is stale when the live target no longer matches the `before`
 * the agent drafted against — applying it would silently overwrite a
 * human's edit made in the meantime.
 */
export function isStale(operation: 'create' | 'update', before: unknown, live: unknown): boolean {
  if (operation === 'create') return false
  if (live === null || live === undefined) return true
  return !stableEqual(before, live)
}

// ---------------------------------------------------------------------------
// Diffs (for the review card)
// ---------------------------------------------------------------------------

export interface FieldChange {
  field: string
  before: unknown
  after: unknown
}

/** Top-level field changes between two flat records. */
export function diffFields(before: unknown, after: unknown): FieldChange[] {
  const b = (before && typeof before === 'object' ? before : {}) as Record<string, unknown>
  const a = (after && typeof after === 'object' ? after : {}) as Record<string, unknown>
  const keys = Array.from(new Set([...Object.keys(b), ...Object.keys(a)])).sort()
  return keys
    .filter((k) => !stableEqual(b[k], a[k]))
    .map((k) => ({ field: k, before: b[k] ?? null, after: a[k] ?? null }))
}

export interface DiffBlock {
  id?: string
  tag?: string
  className?: string
  textContent?: string
  attrs?: Record<string, string>
  label?: string
  hidden?: boolean
  children?: DiffBlock[]
}

export interface BlockChange {
  blockId: string
  kind: 'added' | 'removed' | 'changed' | 'moved'
  tag?: string
  label?: string
  fields: FieldChange[]
}

interface FlatBlock {
  block: DiffBlock
  parentId: string | null
  index: number
}

function flatten(blocks: DiffBlock[] | undefined, parentId: string | null, out: Map<string, FlatBlock>): void {
  ;(blocks || []).forEach((block, index) => {
    if (block.id) out.set(block.id, { block, parentId, index })
    flatten(block.children, block.id ?? parentId, out)
  })
}

const BLOCK_FIELDS = ['tag', 'className', 'textContent', 'attrs', 'label', 'hidden'] as const

/**
 * Blocks whose order changed among the siblings they kept in the same parent: the fewest blocks
 * that explain the new order (those outside the longest run that kept its relative order).
 */
function reorderedInPlace(b: Map<string, FlatBlock>, a: Map<string, FlatBlock>): Set<string> {
  const byParent = new Map<string | null, Array<{ id: string; before: number; after: number }>>()
  for (const [id, cur] of a) {
    const prev = b.get(id)
    if (!prev || prev.parentId !== cur.parentId) continue
    const list = byParent.get(cur.parentId) ?? []
    list.push({ id, before: prev.index, after: cur.index })
    byParent.set(cur.parentId, list)
  }
  const moved = new Set<string>()
  for (const list of byParent.values()) {
    const seq = [...list].sort((x, y) => x.after - y.after)
    // Longest increasing subsequence of the 'before' positions, in 'after' order.
    const len: number[] = []
    const prevOf: number[] = []
    let best = -1
    seq.forEach((x, i) => {
      len[i] = 1
      prevOf[i] = -1
      for (let j = 0; j < i; j++) {
        if (seq[j].before < x.before && len[j] + 1 > len[i]) {
          len[i] = len[j] + 1
          prevOf[i] = j
        }
      }
      if (best < 0 || len[i] > len[best]) best = i
    })
    const keep = new Set<number>()
    for (let i = best; i >= 0; i = prevOf[i]) keep.add(i)
    seq.forEach((x, i) => { if (!keep.has(i)) moved.add(x.id) })
  }
  return moved
}

/** Block-level diff of two Block[] trees, keyed by block id. */
export function diffBlocks(before: DiffBlock[] | undefined, after: DiffBlock[] | undefined): BlockChange[] {
  const b = new Map<string, FlatBlock>()
  const a = new Map<string, FlatBlock>()
  flatten(before, null, b)
  flatten(after, null, a)
  const changes: BlockChange[] = []
  const reordered = reorderedInPlace(b, a)

  for (const [id, cur] of a) {
    const prev = b.get(id)
    if (!prev) {
      changes.push({
        blockId: id,
        kind: 'added',
        tag: cur.block.tag,
        label: cur.block.label,
        fields: BLOCK_FIELDS.filter((f) => cur.block[f] !== undefined).map((f) => ({
          field: f,
          before: null,
          after: cur.block[f],
        })),
      })
      continue
    }
    const fields = BLOCK_FIELDS.filter((f) => !stableEqual(prev.block[f], cur.block[f])).map((f) => ({
      field: f,
      before: prev.block[f] ?? null,
      after: cur.block[f] ?? null,
    }))
    if (fields.length > 0) {
      changes.push({ blockId: id, kind: 'changed', tag: cur.block.tag, label: cur.block.label, fields })
    } else if (prev.parentId !== cur.parentId || reordered.has(id)) {
      // A different parent is a move; so is a change of order among the siblings kept in the same
      // parent. Index shifts from a sibling added or removed are not (reorderedInPlace).
      changes.push({ blockId: id, kind: 'moved', tag: cur.block.tag, label: cur.block.label, fields: [] })
    }
  }
  for (const [id, prev] of b) {
    if (!a.has(id)) {
      changes.push({ blockId: id, kind: 'removed', tag: prev.block.tag, label: prev.block.label, fields: [] })
    }
  }
  return changes
}

/** Merge two block-id lists, keeping first-seen order. */
export function mergeIds(a: ReadonlyArray<string>, b: ReadonlyArray<string>): string[] {
  return Array.from(new Set([...a, ...b]))
}

export interface TokenDiff {
  removed: string[]
  added: string[]
  kept: string[]
}

/** Whitespace-token diff (Tailwind className changes on review cards). */
export function diffTokens(before: unknown, after: unknown): TokenDiff {
  const split = (v: unknown) => (typeof v === 'string' ? v.split(/\s+/).filter(Boolean) : [])
  const b = split(before)
  const a = split(after)
  const bs = new Set(b)
  const as = new Set(a)
  return {
    removed: b.filter((t) => !as.has(t)),
    added: a.filter((t) => !bs.has(t)),
    kept: a.filter((t) => bs.has(t)),
  }
}

/**
 * "Not now" snoozes until tomorrow: a set whose open items were all set
 * aside since the start of the viewer's day stays out of Today's focus
 * (it is still listed under Everything, marked snoozed). New edits that
 * fold into it reopen it.
 */
export function isSnoozed(items: ReadonlyArray<{ status: string; decidedAt: string | Date | null }>, dayStart: Date): boolean {
  const open = items.filter((i) => i.status === 'pending' || i.status === 'saved')
  if (!open.length || open.some((i) => i.status !== 'saved')) return false
  return open.every((i) => i.decidedAt !== null && new Date(i.decidedAt).getTime() >= dayStart.getTime())
}

// ── Orphans: a pending change whose target was deleted ───────────────

/** What an orphan check needs from an item. */
export interface OrphanCandidate {
  id: string
  changeSetId: string
  targetType: string
  targetId: string | null
  operation: string
  status: string
}

export const targetKey = (targetType: string, targetId: string) => `${targetType}:${targetId}`

/**
 * The targets to look up: open items that change something that already
 * exists (not a create), of a type the host says can be deleted. A target
 * that an open item in the same set creates is skipped (it doesn't exist yet,
 * by design).
 */
export function orphanChecks(items: readonly OrphanCandidate[], deletable: (targetType: string) => boolean): Array<{ targetType: string; targetId: string }> {
  const created = new Set(items.filter((i) => i.operation === 'create' && i.targetId && isOpen(i.status as ItemStatus)).map((i) => `${i.changeSetId}|${i.targetId}`))
  const out = new Map<string, { targetType: string; targetId: string }>()
  for (const i of items) {
    if (!i.targetId || i.operation === 'create' || !isOpen(i.status as ItemStatus) || !deletable(i.targetType)) continue
    if (created.has(`${i.changeSetId}|${i.targetId}`)) continue
    out.set(targetKey(i.targetType, i.targetId), { targetType: i.targetType, targetId: i.targetId })
  }
  return [...out.values()]
}

/**
 * Open items whose target is gone. They can never be applied — only
 * discarded (rejected). `exists` answers for the keys orphanChecks asked
 * about; anything it wasn't asked about counts as present.
 */
export function orphanedItemIds(items: readonly OrphanCandidate[], deletable: (targetType: string) => boolean, exists: (key: string) => boolean): Set<string> {
  const asked = new Set(orphanChecks(items, deletable).map((c) => targetKey(c.targetType, c.targetId)))
  const out = new Set<string>()
  for (const i of items) {
    if (!i.targetId) continue
    const key = targetKey(i.targetType, i.targetId)
    if (asked.has(key) && i.operation !== 'create' && isOpen(i.status as ItemStatus) && !exists(key)) out.add(i.id)
  }
  return out
}
