/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/changesets/orphans.assert.ts
 */
import assert from 'node:assert/strict'
import { orphanChecks, orphanedItemIds, targetKey, type OrphanCandidate } from './logic'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const item = (id: string, over: Partial<OrphanCandidate> = {}): OrphanCandidate => ({ id, changeSetId: 's1', targetType: 'page-content', targetId: 'p1', operation: 'update', status: 'pending', ...over })
const deletable = (t: string) => t !== 'site-layout'

check('only open edits of deletable targets are looked up, once each', () => {
  const items = [
    item('a'),
    item('b', { targetType: 'page-status' }),
    item('c'), // same target as a → one lookup
    item('d', { status: 'approved' }),
    item('e', { operation: 'create', targetId: null, targetType: 'page' }),
    item('f', { targetType: 'site-layout', targetId: 'header' }),
    item('g', { status: 'saved', targetId: 'p2' }),
  ]
  assert.deepEqual(orphanChecks(items, deletable), [
    { targetType: 'page-content', targetId: 'p1' },
    { targetType: 'page-status', targetId: 'p1' },
    { targetType: 'page-content', targetId: 'p2' },
  ])
})

check('a deleted page orphans every open item that edits it; others are left alone', () => {
  const items = [item('a'), item('b', { targetType: 'page-status' }), item('c', { targetId: 'p2' }), item('d', { status: 'rejected' })]
  const gone = new Set([targetKey('page-content', 'p1'), targetKey('page-status', 'p1')])
  assert.deepEqual([...orphanedItemIds(items, deletable, (k) => !gone.has(k))].sort(), ['a', 'b'])
})

check('a target created in the same set is not an orphan (it does not exist YET)', () => {
  const items = [item('new', { targetType: 'record', targetId: 'r9', operation: 'create' }), item('pub', { targetType: 'record-status', targetId: 'r9' })]
  assert.deepEqual(orphanChecks(items, deletable), [])
  assert.equal(orphanedItemIds(items, deletable, () => false).size, 0)
  // …but once the create was decided (rejected), its follow-up has nothing to land on.
  const after = [{ ...items[0], status: 'rejected' }, items[1]]
  assert.deepEqual([...orphanedItemIds(after, deletable, () => false)], ['pub'])
})

check('unknown or non-deletable targets are never called orphans (fail safe: still reviewable)', () => {
  const items = [item('h', { targetType: 'site-layout', targetId: 'footer' })]
  assert.equal(orphanedItemIds(items, deletable, () => false).size, 0)
})

console.log(`\n${n} checks passed`)
