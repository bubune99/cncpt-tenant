/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/offline/runner.assert.ts
 * The runner itself (memory store: Node has no IndexedDB): a discard while
 * the action is sending stops it and the item is never written back.
 */
import assert from 'node:assert/strict'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}

// The runner starts only in a browser: give it a window to listen on.
;(globalThis as unknown as { window: EventTarget }).window = new EventTarget()
// Node 21+ has a navigator without onLine: say we're online.
if (typeof navigator !== 'undefined') Object.defineProperty(navigator, 'onLine', { value: true, configurable: true })
setTimeout(() => {
  console.error('runner.assert: timed out (the action never ran)')
  process.exit(1)
}, 10_000).unref()

async function main() {
const { registerQueueAction } = await import('./queue')
const { enqueue, discardItem, subscribeQueue, stopOfflineQueue, queueIsPersistent, setQueueUser, clearOfflineQueue } = await import('./runner')

let aborted: unknown = null
let progressAfterDiscard: Promise<void> | null = null
let started!: () => void
const running = new Promise<void>((r) => (started = r))
registerQueueAction({
  type: 'test.slow',
  run: (item, ctx) =>
    new Promise((resolve, reject) => {
      started()
      ctx.signal?.addEventListener('abort', () => {
        aborted = ctx.signal?.reason
        // A run that still saves progress a moment after the discard (the bug forms-pkg found).
        progressAfterDiscard = new Promise<void>((done) =>
          setTimeout(() => {
            void ctx.save({ stage: 'late' } as never).then(done)
            reject(ctx.signal?.reason)
          }, 0)
        )
      })
      setTimeout(() => resolve('done'), 5_000)
    }),
})

await setQueueUser('user-a')
const seen: string[][] = []
const off = subscribeQueue((items) => seen.push(items.map((i) => `${i.type}:${i.state}`)))
const id = await enqueue({ type: 'test.slow', label: 'Slow', payload: {} })
eq(queueIsPersistent(), false, 'no IndexedDB: memory store')
await running
await discardItem(id)
await new Promise((r) => setTimeout(r, 5))
await progressAfterDiscard
await new Promise((r) => setTimeout(r, 20))
eq((aborted as Error)?.name, 'AbortError', 'discarding stops the run in flight')
const last = seen[seen.length - 1]
eq(last.some((s) => s.startsWith('test.slow')), false, 'discarded while sending: never written back')
off()

// Per person (audit R2-10): A's queued work is dropped (and stopped) when B signs in on the same phone
let holdAborted = false
registerQueueAction({
  type: 'test.hold',
  run: (_item, ctx) =>
    new Promise((_resolve, reject) => {
      ctx.signal?.addEventListener('abort', () => {
        holdAborted = true
        reject(ctx.signal?.reason)
      })
    }),
})
let latest: Array<{ label: string; userId?: string }> = []
const off2 = subscribeQueue((items) => (latest = items.map((i) => ({ label: i.label, userId: i.userId }))))
await enqueue({ type: 'test.hold', label: 'A draft', payload: {} })
eq(latest.map((i) => i.userId), ['user-a'], 'stamped with the signed-in person')
await new Promise((r) => setTimeout(r, 10))
await setQueueUser('user-b')
await new Promise((r) => setTimeout(r, 10))
eq([latest.length, holdAborted], [0, true], "B signs in: A's item is gone and its run stopped")
await enqueue({ type: 'test.hold', label: 'B draft', payload: {} })
eq(latest.map((i) => i.userId), ['user-b'])

// Sign-out clears everything; nothing can be queued until someone signs in
await clearOfflineQueue()
eq(latest.length, 0, 'signed out: the queue is empty')
const pending = enqueue({ type: 'test.hold', label: 'Too early', payload: {} })
const early = await Promise.race([pending.then(() => 'queued'), new Promise((r) => setTimeout(() => r('waiting'), 30))])
eq(early, 'waiting', 'nothing is queued before someone signs in')
await setQueueUser('user-c')
await pending
eq(latest.map((i) => [i.label, i.userId]), [['Too early', 'user-c']], 'then it is theirs')
off2()
stopOfflineQueue()
console.log(`${n} assertions passed`)
  process.exit(0)
}

void main().catch((e) => {
  console.error(e)
  process.exit(1)
})
