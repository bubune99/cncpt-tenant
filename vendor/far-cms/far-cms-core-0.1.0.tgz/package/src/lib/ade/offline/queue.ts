/**
 * Offline queue (shared ADE core): actions taken on a phone with weak or no
 * signal — counts, write-offs, ticks, photo uploads — wait on the device and
 * go when the connection allows. Each action type is registered once by the
 * lane or app that owns it; the queue keeps order, retries with backoff,
 * resumes uploads from the last finished stage, and summarises itself for
 * the status chip.
 *
 * Pure (no IndexedDB, no fetch); the browser side is idb.ts + runner.ts.
 * Asserted by queue.assert.ts.
 */

/** 'conflict': the server refused because the data changed meanwhile — needs a person (never retried on its own). */
export type ItemState = 'queued' | 'sending' | 'failed' | 'conflict' | 'done'

export interface QueueItem {
  id: string
  type: string
  /** Plain words for the chip and the list ("Write off 2 × Boxy Tee M"). */
  label: string
  payload: unknown
  /** A file waiting to upload is stored beside the item (idb blobs store) under this key. */
  blobKey?: string
  /** Idempotency: while an item with this key is open, enqueueing the same key again returns it instead. */
  dedupeKey?: string
  /** Items of one group run strictly in order: a later one waits until the earlier ones are done (photos before "save draft"). */
  group?: string
  /** What the action returned (e.g. { id, url } of an uploaded photo) — later items in the group can read it. */
  result?: unknown
  /** When it stopped trying on its own (done, failed for good, conflict) — finished items are cleared an hour later. */
  settledAt?: number
  createdAt: number
  attempts: number
  state: ItemState
  /** Not before this time (ms) — set by the backoff after a failure. */
  nextAt: number
  error?: string
  /** Resumable work: the stages finished so far and what they produced (upload URL, object key…). */
  progress?: { stage: string; data?: Record<string, unknown>; sentBytes?: number; totalBytes?: number }
  /** Who queued it. Only that person's session ever sends it (a shared phone never replays one person's work as another). */
  userId?: string
}

export interface RetryPolicy {
  /** Attempts before the item is left as failed (the person can retry it). */
  max: number
  baseMs: number
  capMs: number
}

export const DEFAULT_RETRY: RetryPolicy = { max: 6, baseMs: 2_000, capMs: 5 * 60_000 }

/** What a registered action type does when its turn comes (browser side). */
export interface QueueRunContext {
  blob: Blob | null
  /** Results of items already done, by dedupeKey (or id) — e.g. the media ids of a draft's photos. */
  resultOf: (key: string) => unknown
  /** Report resumable progress; kept so a retry resumes from here. */
  save: (progress: QueueItem['progress']) => Promise<void>
  /** Upload progress for the chip (bytes). */
  onBytes: (sent: number, total: number) => void
  signal: AbortSignal
}

export type ErrorClass = 'retry' | 'fail' | 'conflict'

export interface QueueActionDef {
  type: string
  /** Do it. What it returns is kept as the item's result. */
  run: (item: QueueItem, ctx: QueueRunContext) => Promise<unknown>
  retry?: Partial<RetryPolicy>
  /** How an error counts: 'retry' (default: wait and try again), 'fail' (never — e.g. 403), 'conflict' (needs a person). */
  classify?: (error: unknown) => ErrorClass
  /** @deprecated use classify — true = 'fail'. */
  permanent?: (error: unknown) => boolean
  /** Called once the item is done, failed for good, or in conflict (e.g. refresh a list, notify). */
  onSettled?: (item: QueueItem) => void
}

/** The class of an error for a type (classify, else permanent, else retry). */
export function classifyError(type: string, error: unknown): ErrorClass {
  const def = actions.get(type)
  if (def?.classify) return def.classify(error)
  return def?.permanent?.(error) ? 'fail' : 'retry'
}

const actions = new Map<string, QueueActionDef>()

/** Lanes/apps register their action types (BYB: inventory.count, inventory.writeoff, order.tick_piece…). */
export function registerQueueAction(def: QueueActionDef): void {
  actions.set(def.type, def)
}

export function queueAction(type: string): QueueActionDef | undefined {
  return actions.get(type)
}

export function retryPolicy(type: string): RetryPolicy {
  return { ...DEFAULT_RETRY, ...(actions.get(type)?.retry ?? {}) }
}

let seq = 0
/** A new queued item (id unique on this device). */
export interface EnqueueInput {
  type: string
  label: string
  payload: unknown
  blobKey?: string
  dedupeKey?: string
  group?: string
  /** The signed-in person (the runner stamps it). */
  userId?: string
}

export function newItem(input: EnqueueInput, now: number, rand = Math.random): QueueItem {
  return {
    id: `q${now.toString(36)}${(seq++).toString(36)}${Math.floor(rand() * 1e6).toString(36)}`,
    type: input.type,
    label: input.label.slice(0, 120),
    payload: input.payload,
    ...(input.blobKey ? { blobKey: input.blobKey } : {}),
    ...(input.dedupeKey ? { dedupeKey: input.dedupeKey.slice(0, 200) } : {}),
    ...(input.group ? { group: input.group.slice(0, 200) } : {}),
    ...(input.userId ? { userId: input.userId } : {}),
    createdAt: now,
    attempts: 0,
    state: 'queued',
    nextAt: now,
  }
}

/**
 * A device's queue split by person: `mine` is what this signed-in person
 * queued; `others` is everything else — another person's, or an item from
 * before items were stamped (whose owner can't be known) — and is dropped,
 * never sent. Nobody signed in: nothing is anyone's.
 */
export function partitionByUser(items: readonly QueueItem[], userId: string | null): { mine: QueueItem[]; others: QueueItem[] } {
  const mine: QueueItem[] = []
  const others: QueueItem[] = []
  for (const i of items) (userId && i.userId === userId ? mine : others).push(i)
  return { mine, others }
}

/** Exponential backoff, capped: base × 2^(attempts−1), with a fixed jitter fraction (0–0.25) injected for tests. */
export function backoffMs(attempts: number, policy: RetryPolicy, jitter = 0): number {
  const raw = policy.baseMs * 2 ** Math.max(0, attempts - 1)
  return Math.min(policy.capMs, Math.round(raw * (1 + Math.min(0.25, Math.max(0, jitter)))))
}

/** An open item with this dedupe key (enqueue returns it instead of adding a second). */
export function findOpen(items: readonly QueueItem[], dedupeKey: string | undefined): QueueItem | null {
  if (!dedupeKey) return null
  return items.find((i) => i.dedupeKey === dedupeKey && i.state !== 'done') ?? null
}

/**
 * The next item to send: the oldest due one (queued, or a failed one whose
 * wait is over and still has tries). FIFO keeps order per device; within a
 * group, nothing runs while an earlier item of that group isn't done.
 */
export function nextDue(items: readonly QueueItem[], now: number): QueueItem | null {
  const ordered = [...items].sort((a, b) => a.createdAt - b.createdAt)
  const blocked = new Set<string>()
  for (const i of ordered) {
    const ready = (i.state === 'queued' || i.state === 'failed') && i.nextAt <= now && i.attempts < retryPolicy(i.type).max
    if (i.group && blocked.has(i.group)) continue
    if (ready) return i
    if (i.group && i.state !== 'done') blocked.add(i.group)
  }
  return null
}

export function markSending(item: QueueItem): QueueItem {
  return { ...item, state: 'sending', attempts: item.attempts + 1, error: undefined }
}

export function markDone(item: QueueItem, result?: unknown, now: number = Date.now()): QueueItem {
  return { ...item, state: 'done', error: undefined, settledAt: now, ...(result !== undefined ? { result } : {}) }
}

/**
 * The connection dropped (offline, a failed fetch, the page going away): not
 * the action's fault, so it doesn't use up a try — it waits a moment (and
 * for the device to come back online) and goes again.
 */
export function markInterrupted(item: QueueItem, now: number, waitMs = 2_000): QueueItem {
  return { ...item, state: 'queued', attempts: Math.max(0, item.attempts - 1), nextAt: now + waitMs, error: undefined }
}

/** A network error rather than a server answer: fetch's TypeError, an XHR network error, or an abort for going offline / leaving. */
export function isNetworkError(error: unknown, online = true): boolean {
  if (!online) return true
  const e = error as { name?: unknown; message?: unknown } | null
  const name = typeof e?.name === 'string' ? e.name : ''
  const msg = typeof e?.message === 'string' ? e.message : String(error ?? '')
  if (name === 'AbortError') return /offline|pagehide|navigat|leaving/i.test(msg)
  return (name === 'TypeError' && /fetch|network|load failed|connection/i.test(msg)) || /^Network error/i.test(msg)
}

/** After a failed attempt: wait longer (or give up after `max`, or at once for a permanent error). Progress is kept, so the next try resumes. */
export function markFailed(item: QueueItem, error: unknown, now: number, opts: { permanent?: boolean; conflict?: boolean; jitter?: number } = {}): QueueItem {
  const policy = retryPolicy(item.type)
  const message = (error instanceof Error ? error.message : String(error ?? 'Failed')).slice(0, 200)
  if (opts.conflict) return { ...item, state: 'conflict', error: message, nextAt: Number.POSITIVE_INFINITY, settledAt: now }
  const exhausted = opts.permanent || item.attempts >= policy.max
  return { ...item, state: 'failed', error: message, nextAt: exhausted ? Number.POSITIVE_INFINITY : now + backoffMs(item.attempts, policy, opts.jitter), ...(exhausted ? { settledAt: now } : {}) }
}

/** Settled = no more automatic tries: done, failed for good, or in conflict. */
export function isSettled(item: QueueItem): boolean {
  return item.state === 'done' || item.state === 'conflict' || (item.state === 'failed' && item.nextAt === Number.POSITIVE_INFINITY)
}

/** The person taps Retry: tries again now, with a fresh set of attempts. */
export function retryNow(item: QueueItem, now: number): QueueItem {
  return { ...item, state: 'queued', attempts: 0, nextAt: now, error: undefined }
}

/** An item left "sending" when the page closed goes back to the queue (its progress resumes it). */
export function recoverInterrupted(items: readonly QueueItem[], now: number): QueueItem[] {
  return items.map((i) => (i.state === 'sending' ? { ...i, state: 'queued' as const, nextAt: now } : i))
}

/** Stages finished, in order: a resumed run skips the ones already done. */
export function stageDone(item: QueueItem, stages: readonly string[], stage: string): boolean {
  const at = item.progress ? stages.indexOf(item.progress.stage) : -1
  return at >= 0 && stages.indexOf(stage) <= at
}

export interface QueueSummary {
  /** "All sent", "3 waiting", "Uploading 40% · 2 waiting", "1 didn't send — tap to retry", "1 needs attention", "Offline · 2 waiting". */
  text: string
  tone: 'idle' | 'busy' | 'offline' | 'error' | 'attention'
  waiting: number
  failed: number
  /** Items in conflict (need a person to look). */
  attention?: number
  /** Kept in memory only (no IndexedDB here): lost on reload. */
  volatile?: true
}

export interface GroupSummary {
  total: number
  done: number
  failed: number
  sending: boolean
  /** "All 3 photos up", "2 of 3 photos up", "1 photo didn't send", "Waiting for 3 photos". */
  text: string
  complete: boolean
}

/** One group's progress (a draft's photos), in plain words; `noun` is singular/plural ("photo", "photos"). */
export function groupSummary(items: readonly QueueItem[], group: string, noun: [string, string] = ['item', 'items'], verb = 'up'): GroupSummary {
  const g = items.filter((i) => i.group === group)
  const total = g.length
  const done = g.filter((i) => i.state === 'done').length
  const failed = g.filter((i) => isSettled(i) && i.state !== 'done').length
  const sending = g.some((i) => i.state === 'sending')
  const n = (k: number) => `${k} ${k === 1 ? noun[0] : noun[1]}`
  let text: string
  if (!total) text = `No ${noun[1]}`
  else if (failed) text = `${n(failed)} didn’t send`
  else if (done === total) text = total === 1 ? `${noun[0][0].toUpperCase()}${noun[0].slice(1)} ${verb}` : `All ${n(total)} ${verb}`
  else if (done === 0 && !sending) text = `Waiting for ${n(total)}`
  else text = `${done} of ${n(total)} ${verb}`
  return { total, done, failed, sending, text, complete: total > 0 && done === total }
}

/**
 * The status chip. Done items don't count; failed ones that ran out of tries
 * do. `persistent: false` (no IndexedDB — a private window) adds that the
 * queue won't survive a reload.
 */
export function queueSummary(items: readonly QueueItem[], online: boolean, opts: { persistent?: boolean } = {}): QueueSummary {
  const s = baseSummary(items, online)
  if (opts.persistent === false && s.waiting + s.failed + (s.attention ?? 0) > 0) return { ...s, text: `${s.text} · won’t survive a reload`, volatile: true }
  return s
}

function baseSummary(items: readonly QueueItem[], online: boolean): QueueSummary {
  const open = items.filter((i) => i.state !== 'done')
  const conflicts = open.filter((i) => i.state === 'conflict')
  const failed = open.filter((i) => i.state === 'failed' && i.nextAt === Number.POSITIVE_INFINITY)
  const waiting = open.length - failed.length - conflicts.length
  if (conflicts.length) return { text: `${conflicts.length} need${conflicts.length === 1 ? 's' : ''} attention`, tone: 'attention', waiting, failed: failed.length, attention: conflicts.length }
  const sending = open.find((i) => i.state === 'sending')
  const pct = sending?.progress?.totalBytes ? Math.min(99, Math.floor(((sending.progress.sentBytes ?? 0) / sending.progress.totalBytes) * 100)) : null
  if (failed.length) return { text: `${failed.length} didn’t send — tap to retry`, tone: 'error', waiting, failed: failed.length }
  if (!waiting) return { text: 'All sent', tone: 'idle', waiting: 0, failed: 0 }
  const rest = waiting - (sending ? 1 : 0)
  const restText = rest > 0 ? `${rest} waiting` : ''
  if (!online) return { text: `Offline · ${waiting} waiting`, tone: 'offline', waiting, failed: 0 }
  if (sending) return { text: [pct !== null ? `Uploading ${pct}%` : 'Sending…', restText].filter(Boolean).join(' · '), tone: 'busy', waiting, failed: 0 }
  return { text: `${waiting} waiting`, tone: 'busy', waiting, failed: 0 }
}

/** Finished items are cleared an hour after they settle, and never more than the newest `keepLast` are kept. */
export function prune(items: readonly QueueItem[], now: number, opts: { keepDoneMs?: number; keepLast?: number } = {}): QueueItem[] {
  const keepDoneMs = opts.keepDoneMs ?? 3_600_000
  const keepLast = opts.keepLast ?? 20
  const doneRecent = items
    .filter((i) => i.state === 'done' && now - (i.settledAt ?? i.createdAt) < keepDoneMs)
    .sort((a, b) => (b.settledAt ?? b.createdAt) - (a.settledAt ?? a.createdAt))
    .slice(0, keepLast)
  const keep = new Set(doneRecent.map((i) => i.id))
  return items.filter((i) => i.state !== 'done' || keep.has(i.id))
}
