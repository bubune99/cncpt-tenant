/**
 * Run: npx -y tsx@4.23.15 src/lib/ade/offline/queue.assert.ts
 */
import assert from 'node:assert/strict'
import {
  partitionByUser,
  DEFAULT_RETRY,
  backoffMs,
  markDone,
  markFailed,
  markSending,
  newItem,
  nextDue,
  prune,
  queueSummary,
  recoverInterrupted,
  registerQueueAction,
  classifyError,
  findOpen,
  isSettled,
  isNetworkError,
  markInterrupted,
  groupSummary,
  retryNow,
  stageDone,
  type QueueItem,
} from './queue'

let n = 0
const eq = (a: unknown, b: unknown, msg?: string) => {
  assert.deepEqual(a, b, msg)
  n++
}

registerQueueAction({ type: 'inventory.count', run: async () => {}, retry: { max: 3 } })
const T = 1_000_000
const a = newItem({ type: 'inventory.count', label: 'Count Boxy Tee M', payload: { sku: 'x', qty: 4 } }, T, () => 0.1)
const b = newItem({ type: 'media.upload', label: 'Photo 1', payload: {}, blobKey: 'b1' }, T + 10, () => 0.2)

// New items, order
eq([a.state, a.attempts, a.nextAt], ['queued', 0, T])
assert.notEqual(a.id, b.id)
n++
eq(nextDue([b, a], T + 20)?.id, a.id, 'oldest first (FIFO per device)')

// Backoff
eq([backoffMs(1, DEFAULT_RETRY), backoffMs(2, DEFAULT_RETRY), backoffMs(3, DEFAULT_RETRY)], [2000, 4000, 8000])
eq(backoffMs(30, DEFAULT_RETRY), DEFAULT_RETRY.capMs, 'capped')
eq(backoffMs(1, DEFAULT_RETRY, 0.25), 2500, 'jitter at most 25%')
eq(backoffMs(1, DEFAULT_RETRY, 9), 2500)

// Failure → wait → retry; exhausted → stays failed until the person retries
const s = markSending(a)
eq([s.state, s.attempts], ['sending', 1])
let f = markFailed(s, new Error('Network down'), T + 100)
eq([f.state, f.error, f.nextAt], ['failed', 'Network down', T + 100 + 2000])
eq(nextDue([f], T + 1000), null, 'still waiting')
eq(nextDue([f], T + 2100)?.id, a.id, 'due again')
f = markFailed(markSending(markFailed(markSending(f), 'x', T)), 'y', T) // attempts → 3 (max for this type)
eq([f.attempts, f.nextAt], [3, Number.POSITIVE_INFINITY], 'out of tries')
eq(nextDue([f], T + 1e9), null)
eq(markFailed(markSending(b), new Error('403'), T, { permanent: true }).nextAt, Number.POSITIVE_INFINITY, 'permanent errors fail at once')
const r = retryNow(f, T + 5)
eq([r.state, r.attempts, r.nextAt, r.error], ['queued', 0, T + 5, undefined])
eq(markDone(s).state, 'done')

// Resume: interrupted items go back; finished stages are skipped
const mid: QueueItem = { ...markSending(b), progress: { stage: 'uploaded', data: { key: 'k' } } }
eq(recoverInterrupted([mid], T + 7)[0].state, 'queued')
eq(recoverInterrupted([mid], T + 7)[0].progress?.stage, 'uploaded', 'progress kept')
const STAGES = ['presigned', 'uploaded', 'completed']
eq([stageDone(mid, STAGES, 'presigned'), stageDone(mid, STAGES, 'uploaded'), stageDone(mid, STAGES, 'completed')], [true, true, false])
eq(stageDone(b, STAGES, 'presigned'), false)

// Status chip
eq(queueSummary([], true).text, 'All sent')
eq(queueSummary([a, b], true), { text: '2 waiting', tone: 'busy', waiting: 2, failed: 0 })
eq(queueSummary([a, b], false).text, 'Offline · 2 waiting')
const up: QueueItem = { ...markSending(b), progress: { stage: 'presigned', sentBytes: 400, totalBytes: 1000 } }
eq(queueSummary([up, a], true).text, 'Uploading 40% · 1 waiting')
eq(queueSummary([{ ...markSending(a) }], true).text, 'Sending…')
eq(queueSummary([f, a], true), { text: '1 didn’t send — tap to retry', tone: 'error', waiting: 1, failed: 1 })
eq(queueSummary([markDone(a)], true).text, 'All sent', 'done items do not count')

// Prune
eq(prune([markDone(a, undefined, T), b], T + 2 * 3_600_000).map((i) => i.id), [b.id], 'finished items go an hour after they settle')
eq(prune([markDone(a, undefined, T), b], T + 30 * 60_000).map((i) => i.id), [a.id, b.id], 'kept within the hour')
{
  const many = Array.from({ length: 30 }, (_, i) => markDone(newItem({ type: 't', label: `d${i}`, payload: null }, T + i), undefined, T + i))
  const kept = prune([...many, b], T + 100, { keepLast: 20 })
  eq([kept.length, kept.includes(b), kept.some((i) => i.label === 'd29'), kept.some((i) => i.label === 'd0')], [21, true, true, false], 'only the newest 20 finished are kept; open items always')
}
eq(newItem({ type: 't', label: 'x'.repeat(500), payload: null }, T).label.length, 120)

// Groups: strictly in order (photos before "save draft"); other groups and loose items aren't held up
const g1 = newItem({ type: 'media.upload', label: 'p1', payload: {}, group: 'draft-1', dedupeKey: 'draft-1/p1' }, T + 100)
const g2 = newItem({ type: 'initiative.draft', label: 'save', payload: {}, group: 'draft-1' }, T + 200)
const other = newItem({ type: 'inventory.count', label: 'c', payload: {} }, T + 300)
eq(nextDue([g2, g1, other], T + 400)?.id, g1.id)
const g1waiting = markFailed(markSending(g1), 'net', T + 400)
eq(nextDue([g1waiting, g2, other], T + 500)?.id, other.id, 'the group waits for its failed photo; others go')
eq(nextDue([markDone(g1, { id: 'm1' }), g2], T + 500)?.id, g2.id, 'photo done → save draft')
eq(markDone(g1, { id: 'm1' }).result, { id: 'm1' }, 'results kept for later items')
// Dedupe
eq(findOpen([g1, g2], 'draft-1/p1')?.id, g1.id)
eq(findOpen([markDone(g1)], 'draft-1/p1'), null, 'a done item does not block a new one')
eq(findOpen([g1], undefined), null)
// Classify + conflict ("needs attention")
registerQueueAction({ type: 'x.classified', run: async () => {}, classify: (e) => (String(e).includes('409') ? 'conflict' : String(e).includes('403') ? 'fail' : 'retry') })
eq([classifyError('x.classified', '409'), classifyError('x.classified', '403'), classifyError('x.classified', 'timeout'), classifyError('media.upload', 'x')], ['conflict', 'fail', 'retry', 'retry'])
const c = markFailed(markSending(other), 'HTTP 409', T, { conflict: true })
eq([c.state, c.nextAt, isSettled(c)], ['conflict', Number.POSITIVE_INFINITY, true])
eq(queueSummary([c, b], true), { text: '1 needs attention', tone: 'attention', waiting: 1, failed: 0, attention: 1 })
eq(nextDue([c], T + 1e12), null, 'a conflict waits for a person')
eq([isSettled(a), isSettled(markDone(a)), isSettled(f)], [false, true, true])

// Network drops don't use up tries (BYB finding 5)
{
  const s1 = markSending(markSending(a)) // attempts 2
  const back = markInterrupted(s1, T, 2000)
  eq([back.state, back.attempts, back.nextAt, back.error], ['queued', 1, T + 2000, undefined])
  eq([isNetworkError(new TypeError('Failed to fetch')), isNetworkError(new TypeError('Load failed')), isNetworkError(new Error('Network error during upload'))], [true, true, true])
  eq([isNetworkError(new Error('HTTP 500')), isNetworkError(new Error('x'), false)], [false, true], 'a server answer is not; offline always is')
  const ab = new Error('Stopped: offline'); ab.name = 'AbortError'
  const ab2 = new Error('Discarded'); ab2.name = 'AbortError'
  eq([isNetworkError(ab), isNetworkError(ab2)], [true, false], 'going offline/leaving is a drop; a discard is not')
}
// Per-group summary (BYB finding 3)
{
  const P = (k: number, st: QueueItem['state']): QueueItem => ({ ...newItem({ type: 'media.upload', label: `p${k}`, payload: {}, group: 'd1' }, T + k), state: st, ...(st === 'failed' ? { nextAt: Number.POSITIVE_INFINITY } : {}) })
  const noun: [string, string] = ['photo', 'photos']
  eq(groupSummary([P(1, 'done'), P(2, 'done'), P(3, 'done')], 'd1', noun).text, 'All 3 photos up')
  eq(groupSummary([P(1, 'done'), P(2, 'sending'), P(3, 'queued')], 'd1', noun), { total: 3, done: 1, failed: 0, sending: true, text: '1 of 3 photos up', complete: false })
  eq(groupSummary([P(1, 'queued'), P(2, 'queued')], 'd1', noun).text, 'Waiting for 2 photos')
  eq(groupSummary([P(1, 'done'), P(2, 'failed')], 'd1', noun).text, '1 photo didn’t send')
  eq(groupSummary([P(1, 'done')], 'd1', noun).text, 'Photo up')
  eq(groupSummary([], 'd1', noun).text, 'No photos')
}
// No IndexedDB (private window): the chip says it won't survive a reload (BYB finding 1)
eq(queueSummary([a], true, { persistent: false }).text, '1 waiting · won’t survive a reload')
eq(queueSummary([], true, { persistent: false }).text, 'All sent', 'nothing waiting: nothing to warn about')

// Per person (audit R2-10): a shared phone never replays one person's queue as another
const ua = newItem({ type: 'record.phone-save', label: 'Save draft', payload: {}, userId: 'user-a' }, T)
const ub = newItem({ type: 'media.upload', label: 'Photo', payload: {}, userId: 'user-b' }, T + 1)
const old = newItem({ type: 'media.upload', label: 'Photo from before', payload: {} }, T + 2)
eq(ua.userId, 'user-a', 'items are stamped with who queued them')
eq(partitionByUser([ua, ub, old], 'user-a').mine.map((i) => i.label), ['Save draft'])
eq(partitionByUser([ua, ub, old], 'user-a').others.map((i) => i.label), ['Photo', 'Photo from before'], "another person's and unstamped items are dropped, not sent")
eq(partitionByUser([ua, ub], null).mine.length, 0, 'signed out: nothing is anyone\'s')

console.log(`${n} assertions passed`)
