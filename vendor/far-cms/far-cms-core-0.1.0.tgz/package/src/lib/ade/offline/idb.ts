/**
 * The offline queue's storage on the device: IndexedDB, two stores — the
 * items (small JSON) and the files waiting to upload (blobs). No library;
 * each call opens, does one transaction, closes. Browser only.
 */

import type { QueueItem } from './queue'

const DB = 'ade-offline'
const VERSION = 1
const ITEMS = 'items'
const BLOBS = 'blobs'

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(ITEMS)) db.createObjectStore(ITEMS, { keyPath: 'id' })
      if (!db.objectStoreNames.contains(BLOBS)) db.createObjectStore(BLOBS)
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T | undefined> {
  const db = await open()
  try {
    return await new Promise<T | undefined>((resolve, reject) => {
      const t = db.transaction(store, mode)
      const req = fn(t.objectStore(store))
      t.oncomplete = () => resolve(req ? req.result : undefined)
      t.onerror = () => reject(t.error)
      t.onabort = () => reject(t.error)
    })
  } finally {
    db.close()
  }
}

/** True where IndexedDB exists (not in some private modes / old WebViews). */
export function idbAvailable(): boolean {
  return typeof indexedDB !== 'undefined'
}

export const idb = {
  all: async (): Promise<QueueItem[]> => ((await tx<QueueItem[]>(ITEMS, 'readonly', (s) => s.getAll())) ?? []).map(fromStored),
  put: (item: QueueItem) => tx(ITEMS, 'readwrite', (s) => s.put(toStored(item))).then(() => undefined),
  remove: (id: string) => tx(ITEMS, 'readwrite', (s) => s.delete(id)).then(() => undefined),
  putBlob: (key: string, blob: Blob) => tx(BLOBS, 'readwrite', (s) => s.put(blob, key)).then(() => undefined),
  getBlob: async (key: string): Promise<Blob | null> => (await tx<Blob>(BLOBS, 'readonly', (s) => s.get(key))) ?? null,
  removeBlob: (key: string) => tx(BLOBS, 'readwrite', (s) => s.delete(key)).then(() => undefined),
}

// IndexedDB keeps Infinity, but keep "never again until retried" explicit in storage.
const NEVER = -1
const toStored = (i: QueueItem) => ({ ...i, nextAt: i.nextAt === Number.POSITIVE_INFINITY ? NEVER : i.nextAt })
const fromStored = (i: QueueItem): QueueItem => ({ ...i, nextAt: i.nextAt === NEVER ? Number.POSITIVE_INFINITY : i.nextAt })
