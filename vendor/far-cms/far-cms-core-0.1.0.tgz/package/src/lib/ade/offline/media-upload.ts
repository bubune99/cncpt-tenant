/**
 * The core resumable upload action, 'media.upload': a photo taken on the
 * phone goes to the media library when the signal allows. The steps are
 * lib/ade/mobile/upload runPhotoUpload (presign → PUT → complete, each
 * remembered once done, so a retry resumes where it stopped); the queue
 * keeps its state on the item. Other lanes enqueue it with a blob:
 *
 *   enqueue({ type: 'media.upload', label: 'Photo 1 of 3', payload: { name, meta }, blob })
 *
 * Endpoints are the host's (/api/media presign/complete); a host with
 * another media API registers its own 'media.upload'.
 */

import { runPhotoUpload, UploadError, type UploadState } from '../mobile/upload'
import { registerQueueAction, type QueueItem, type QueueRunContext } from './queue'

const ENDPOINTS = { presign: '/api/media', complete: '/api/media' }

interface Payload {
  /** File name for the media library (defaults to a dated name). */
  name?: string
  /** Extra fields for the media row (folderId, alt, title…). */
  meta?: Record<string, unknown>
}

async function run(item: QueueItem, ctx: QueueRunContext) {
  const p = (item.payload ?? {}) as Payload
  const blob = ctx.blob
  if (!blob) throw new UploadError('The photo is no longer on this device', false)
  const type = blob.type || 'image/jpeg'
  const name = p.name || `phone-${new Date(item.createdAt).toISOString().replace(/[:.]/g, '-')}.${type.split('/')[1] || 'jpg'}`
  const state = ((item.progress?.data as { upload?: UploadState } | undefined)?.upload ?? { step: 'presign' }) as UploadState
  ctx.onBytes(0, blob.size)
  // The result ({ id, url } of the media row) is kept on the item for later steps (resultOf).
  return runPhotoUpload({ file: blob, name, type, meta: p.meta }, state, (s) => ctx.save({ stage: s.step, data: { upload: s }, sentBytes: s.step === 'presign' || s.step === 'put' ? 0 : blob.size, totalBytes: blob.size }), ENDPOINTS, (url, init) => fetch(url, { ...init, signal: ctx.signal }))
}

registerQueueAction({
  type: 'media.upload',
  run,
  retry: { max: 8 },
  // runPhotoUpload says which failures can succeed later (network, 5xx, 408, 429).
  classify: (e) => (e instanceof UploadError && !e.retryable ? 'fail' : 'retry'),
})
