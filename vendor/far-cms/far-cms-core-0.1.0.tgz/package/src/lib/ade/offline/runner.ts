/**
 * The offline queue's engine in the browser: one at a time, oldest first,
 * whenever the device is online — on start, on 'online', after a change and
 * on a slow tick for backoff. Items, files and resumable progress live in
 * IndexedDB (idb.ts), so a closed tab or a dead battery loses nothing.
 * Where IndexedDB isn't there (a private window), the queue still works in
 * memory and the chip says it won't survive a reload.
 * Rules (order, backoff, resume, the chip text) are queue.ts.
 *
 * Per person: the shell tells the runner who is signed in (setQueueUser);
 * only that person's items run, another person's are dropped with their
 * files, and signing out clears the queue (clearOfflineQueue).
 */

import { idb, idbAvailable } from './idb'
import {
  classifyError,
  findOpen,
  isNetworkError,
  isSettled,
  markDone,
  markFailed,
  markInterrupted,
  markSending,
  newItem,
  nextDue,
  partitionByUser,
  prune,
  queueAction,
  recoverInterrupted,
  retryNow,
  type EnqueueInput,
  type QueueItem,
} from './queue'

type Listener = (items: QueueItem[], online: boolean) => void

/** Where items and files are kept: IndexedDB, or memory when it can't be used. */
interface Store {
  all(): Promise<QueueItem[]>
  put(item: QueueItem): Promise<void>
  remove(id: string): Promise<void>
  putBlob(key: string, blob: Blob): Promise<void>
  getBlob(key: string): Promise<Blob | null>
  removeBlob(key: string): Promise<void>
}

function memoryStore(): Store {
  const its = new Map<string, QueueItem>()
  const blobs = new Map<string, Blob>()
  return {
    all: async () => [...its.values()],
    put: async (i) => void its.set(i.id, i),
    remove: async (id) => void its.delete(id),
    putBlob: async (k, b) => void blobs.set(k, b),
    getBlob: async (k) => blobs.get(k) ?? null,
    removeBlob: async (k) => void blobs.delete(k),
  }
}

let store: Store = memoryStore()
let persistent = false
let items: QueueItem[] = []
let started: Promise<void> | null = null
let running = false
let timer: ReturnType<typeof setInterval> | null = null
const listeners = new Set<Listener>()
/** The run in flight per item, so a discard, a cancel or leaving the page can stop it. */
const inflight = new Map<string, AbortController>()
/** Who is signed in; nothing runs or is queued until the shell says (setQueueUser). */
let user: string | null = null
let userKnown = false
let resolveUser: () => void = () => {}
let userSet = new Promise<void>((r) => (resolveUser = r))

const online = () => (typeof navigator === 'undefined' ? true : navigator.onLine)
const emit = () => listeners.forEach((l) => l(items, online()))

async function save(item: QueueItem) {
  // Discarded meanwhile (e.g. a run still saving progress): never write it back.
  if (!items.some((i) => i.id === item.id)) return
  items = items.map((i) => (i.id === item.id ? item : i))
  emit()
  await store.put(item).catch(() => {})
}

/** Drop finished items an hour after they settle (and keep at most the newest 20). */
async function tidy() {
  const kept = prune(items, Date.now())
  if (kept.length === items.length) return
  const gone = items.filter((i) => !kept.includes(i))
  items = kept
  emit()
  for (const i of gone) {
    await store.remove(i.id).catch(() => {})
    if (i.blobKey) await store.removeBlob(i.blobKey).catch(() => {})
  }
}

function abortError(reason: string) {
  const e = new Error(reason)
  e.name = 'AbortError'
  return e
}

/** Send what's due, one by one, until nothing is due or the device goes offline. */
async function pump() {
  if (running || !online() || !user) return
  running = true
  try {
    for (let item = nextDue(items, Date.now()); item && online(); item = nextDue(items, Date.now())) {
      const def = queueAction(item.type)
      if (!def) {
        await save(markFailed(markSending(item), `No handler for "${item.type}" on this device`, Date.now(), { permanent: true }))
        continue
      }
      let current = markSending(item)
      await save(current)
      const ctrl = new AbortController()
      inflight.set(current.id, ctrl)
      try {
        const blob = current.blobKey ? await store.getBlob(current.blobKey) : null
        const result = await def.run(current, {
          blob,
          resultOf: (key) => items.find((i) => i.state === 'done' && (i.dedupeKey === key || i.id === key))?.result,
          signal: ctrl.signal,
          save: async (progress) => {
            current = { ...current, progress }
            await save(current)
          },
          onBytes: (sent, total) => {
            current = { ...current, progress: { ...(current.progress ?? { stage: 'uploading' }), sentBytes: sent, totalBytes: total } }
            items = items.map((i) => (i.id === current.id ? current : i))
            emit()
          },
        })
        if (!items.some((i) => i.id === current.id)) continue // discarded while it ran
        current = markDone(current, result)
        await save(current)
        if (current.blobKey) await store.removeBlob(current.blobKey).catch(() => {})
      } catch (error) {
        if (!items.some((i) => i.id === current.id)) continue // discarded while it ran
        const reason = ctrl.signal.aborted ? ctrl.signal.reason : error
        if (isNetworkError(reason, online())) {
          // The connection (or the page) went, not the action: it doesn't use up a try.
          current = markInterrupted(current, Date.now())
          await save(current)
          continue
        }
        const cls = classifyError(current.type, error)
        current = markFailed(current, error, Date.now(), { permanent: cls === 'fail', conflict: cls === 'conflict', jitter: Math.random() * 0.25 })
        await save(current)
      } finally {
        inflight.delete(current.id)
      }
      if (isSettled(current)) {
        try {
          def.onSettled?.(current)
        } catch (e) {
          console.warn('[offline] onSettled threw:', e)
        }
      }
    }
  } finally {
    running = false
    void tidy()
  }
}

/** Load the queue from the device and start sending. Safe to call more than once. */
export function startOfflineQueue(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve()
  if (started) return started
  started = (async () => {
    let stored: QueueItem[] = []
    if (idbAvailable()) {
      try {
        stored = await idb.all() // throws where IndexedDB is blocked (some private modes)
        store = idb
        persistent = true
      } catch {
        store = memoryStore()
        persistent = false
      }
    }
    items = prune(recoverInterrupted(stored, Date.now()), Date.now())
    emit()
    window.addEventListener('online', () => {
      emit()
      void pump()
    })
    window.addEventListener('offline', () => {
      for (const c of inflight.values()) c.abort(abortError('Stopped: offline'))
      emit()
    })
    // Leaving the page: stop cleanly; the item resumes on the next visit (it stays queued).
    window.addEventListener('pagehide', () => {
      for (const c of inflight.values()) c.abort(abortError('Stopped: leaving the page'))
    })
    timer = setInterval(() => void pump(), 15_000)
    void pump()
  })()
  return started
}

/** False when the queue lives in memory only (no IndexedDB): items are lost on reload. */
export function queueIsPersistent(): boolean {
  return persistent
}

/**
 * Queue an action (with a file to upload, if any). Returns the item id.
 * Works offline. Same dedupeKey while one is open → that one's id (nothing added).
 */
export async function enqueue(input: Omit<EnqueueInput, 'blobKey' | 'userId'> & { blob?: Blob }): Promise<string> {
  await startOfflineQueue()
  await userSet
  if (!user) throw new Error('Sign in to queue this')
  const open = findOpen(items, input.dedupeKey)
  if (open) return open.id
  const now = Date.now()
  const blobKey = input.blob ? `b${now.toString(36)}${Math.random().toString(36).slice(2, 8)}` : undefined
  if (input.blob && blobKey) await store.putBlob(blobKey, input.blob)
  const item = newItem({ type: input.type, label: input.label, payload: input.payload, blobKey, dedupeKey: input.dedupeKey, group: input.group, userId: user }, now)
  items = [...items, item]
  emit()
  await store.put(item)
  void pump()
  return item.id
}

/** Try a failed item again now. */
export async function retryItem(id: string): Promise<void> {
  const item = items.find((i) => i.id === id)
  if (!item) return
  await save(retryNow(item, Date.now()))
  void pump()
}

/** Retry everything that gave up. */
export async function retryAll(): Promise<void> {
  for (const i of items.filter((x) => x.state === 'failed')) await save(retryNow(i, Date.now()))
  void pump()
}

/** Drop an item the person doesn't want sent any more (stops it if it's running). */
export async function discardItem(id: string): Promise<void> {
  const item = items.find((i) => i.id === id)
  inflight.get(id)?.abort(abortError('Discarded'))
  items = items.filter((i) => i.id !== id)
  emit()
  await store.remove(id).catch(() => {})
  if (item?.blobKey) await store.removeBlob(item.blobKey).catch(() => {})
}

async function drop(gone: readonly QueueItem[]) {
  for (const i of gone) {
    inflight.get(i.id)?.abort(abortError('Signed out'))
    await store.remove(i.id).catch(() => {})
    if (i.blobKey) await store.removeBlob(i.blobKey).catch(() => {})
  }
}

/**
 * Who is signed in (the shell calls this whenever it knows). Items anyone
 * else queued on this device — or unstamped ones from before — are dropped
 * with their files, never sent as this person. null: signed out → cleared.
 */
export async function setQueueUser(userId: string | null): Promise<void> {
  await startOfflineQueue()
  if (userKnown && userId === user) return
  const { mine, others } = partitionByUser(items, userId)
  user = userId
  userKnown = true
  items = mine
  emit()
  await drop(others)
  resolveUser()
  void pump()
}

/** Sign-out: stop what's running and remove every item and file from this device. */
export async function clearOfflineQueue(): Promise<void> {
  await startOfflineQueue()
  const all = [...items, ...(await store.all().catch(() => [] as QueueItem[]))]
  items = []
  user = null
  userKnown = true
  emit()
  await drop(all)
  resolveUser()
  // The next person starts fresh: their enqueue waits for setQueueUser again.
  userKnown = false
  userSet = new Promise<void>((r) => (resolveUser = r))
}

/** One item's state, by id or dedupeKey (undefined until it exists). */
export function subscribeItem(key: string, cb: (item: QueueItem | undefined) => void): () => void {
  return subscribeQueue((all) => cb(all.find((i) => i.id === key || i.dedupeKey === key)))
}

/** A group's items (e.g. a draft's photos) — pair with queue.ts groupSummary for "All 3 photos up". */
export function subscribeGroup(group: string, cb: (items: QueueItem[]) => void): () => void {
  return subscribeQueue((all) => cb(all.filter((i) => i.group === group)))
}

export function subscribeQueue(l: Listener): () => void {
  listeners.add(l)
  l(items, online())
  return () => {
    listeners.delete(l)
  }
}

/** For tests / sign-out: stop the tick (the stored queue stays on the device). */
export function stopOfflineQueue(): void {
  if (timer) clearInterval(timer)
  timer = null
}
