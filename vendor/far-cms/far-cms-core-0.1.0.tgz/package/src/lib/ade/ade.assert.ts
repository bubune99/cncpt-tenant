/**
 * Assertions for the ADE core (labels, dispatcher, external list, change
 * sets, tasks, code-exec gate, split ratio). No database, no network.
 * Run: npx -y tsx@4.23.15 src/lib/ade/ade.assert.ts
 */
import assert from 'node:assert/strict'
import {
  UNKNOWN_LABELS,
  compositeLabels,
  exposedOn,
  type CapabilityLabels,
} from './capabilities/labels'
import { decideDispatch, type DispatchFacts } from './capabilities/dispatch'
import { externalToolNames } from './capabilities/external-list'
import {
  canReview, statusAfter,
  deriveSetStatus,
  diffBlocks,
  diffFields,
  diffTokens,
  isSnoozed,
  isStale,
  stableEqual,
} from './changesets/logic'
import { createChangeSetService, type ChangeSetStore } from './changesets/service'
import type { ChangeSetItemRecord, ChangeSetRecord, Drafter, TargetAdapter } from './changesets/types'
import { generateTasks, tasksToResolve, visibleTo, type TaskSignals } from './tasks/generate'
import { CodeExecutionDisabledError, createCodeExecGate } from './code-exec/flag'
import { DEFAULT_SPLIT_RATIO, MAX_SPLIT_RATIO, MIN_SPLIT_RATIO, clampSplitRatio, ratioFromPointer } from './ui/split'

let n = 0
async function check(name: string, fn: () => void | Promise<void>) {
  await fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

const L = (exposure: CapabilityLabels['exposure'], effect: CapabilityLabels['effect']): CapabilityLabels => ({
  exposure,
  effect,
})

const base: DispatchFacts = {
  labels: L('in-app', 'write'),
  surface: 'chat',
  changeMode: 'draft',
  executionMode: 'auto',
  permitted: true,
  budgetOk: true,
  canDraft: false,
}

async function main() {
  // ── Labels ────────────────────────────────────────────────────────────────
  await check('composite takes the most restrictive exposure and effect', () => {
    assert.deepEqual(compositeLabels([L('external-mcp', 'read'), L('in-app', 'draft')]), L('in-app', 'draft'))
    assert.deepEqual(compositeLabels([L('external-mcp', 'write'), L('internal', 'read')]), L('internal', 'write'))
    assert.deepEqual(
      compositeLabels([L('external-mcp', 'read'), L('external-mcp', 'irreversible'), L('in-app', 'draft')]),
      L('in-app', 'irreversible')
    )
  })

  await check('composite of nothing is the least restrictive; an unknown step fails closed', () => {
    assert.deepEqual(compositeLabels([]), L('external-mcp', 'read'))
    assert.deepEqual(compositeLabels([L('external-mcp', 'read'), undefined]), UNKNOWN_LABELS)
  })

  await check('exposure: internal never reaches a model; in-app is chat only', () => {
    assert.equal(exposedOn('internal', 'chat'), false)
    assert.equal(exposedOn('internal', 'mcp'), false)
    assert.equal(exposedOn('internal', 'server'), true)
    assert.equal(exposedOn('in-app', 'chat'), true)
    assert.equal(exposedOn('in-app', 'mcp'), false)
    assert.equal(exposedOn('external-mcp', 'mcp'), true)
    assert.equal(exposedOn('external-mcp', 'chat'), true)
  })

  // ── Dispatcher ────────────────────────────────────────────────────────────
  await check('deny order: exposure, then permission, then budget', () => {
    assert.deepEqual(decideDispatch({ ...base, labels: L('in-app', 'read'), surface: 'mcp', permitted: false }), {
      kind: 'deny',
      reason: 'not-exposed',
    })
    assert.deepEqual(decideDispatch({ ...base, permitted: false, budgetOk: false }), { kind: 'deny', reason: 'permission' })
    assert.deepEqual(decideDispatch({ ...base, budgetOk: false }), { kind: 'deny', reason: 'budget' })
  })

  await check('reads always execute without approval, even in readonly', () => {
    assert.deepEqual(decideDispatch({ ...base, labels: L('in-app', 'read'), executionMode: 'readonly' }), {
      kind: 'execute',
      needsApproval: false,
    })
  })

  await check('readonly denies every non-read effect', () => {
    for (const effect of ['draft', 'write', 'irreversible'] as const) {
      assert.deepEqual(decideDispatch({ ...base, labels: L('in-app', effect), executionMode: 'readonly' }), {
        kind: 'deny',
        reason: 'readonly',
      })
    }
  })

  await check('draft effect in draft mode becomes a ChangeSet (no prompt)', () => {
    assert.deepEqual(decideDispatch({ ...base, labels: L('external-mcp', 'draft'), canDraft: true }), { kind: 'draft' })
    assert.deepEqual(decideDispatch({ ...base, labels: L('external-mcp', 'draft'), canDraft: true, surface: 'mcp' }), {
      kind: 'draft',
    })
    // even when the admin asked for approval on everything
    assert.deepEqual(
      decideDispatch({ ...base, labels: L('in-app', 'draft'), canDraft: true, executionMode: 'ask' }),
      { kind: 'draft' }
    )
  })

  await check('draft effect in direct mode, or without a drafter, behaves as a write', () => {
    assert.deepEqual(decideDispatch({ ...base, labels: L('in-app', 'draft'), canDraft: true, changeMode: 'direct' }), {
      kind: 'execute',
      needsApproval: false,
    })
    assert.deepEqual(decideDispatch({ ...base, labels: L('in-app', 'draft'), canDraft: false, executionMode: 'ask' }), {
      kind: 'execute',
      needsApproval: true,
    })
  })

  await check('irreversible: prompt in chat (even in auto), refused over MCP, server needs approval', () => {
    assert.deepEqual(decideDispatch({ ...base, labels: L('in-app', 'irreversible') }), { kind: 'execute', needsApproval: true })
    assert.deepEqual(decideDispatch({ ...base, labels: L('external-mcp', 'irreversible'), surface: 'mcp' }), {
      kind: 'deny',
      reason: 'needs-approval',
    })
    assert.deepEqual(decideDispatch({ ...base, labels: L('internal', 'irreversible'), surface: 'server' }), {
      kind: 'deny',
      reason: 'needs-approval',
    })
    assert.deepEqual(decideDispatch({ ...base, labels: L('internal', 'irreversible'), surface: 'server', approved: true }), {
      kind: 'execute',
      needsApproval: false,
    })
  })

  await check('writes: approval per ask mode / forceConfirm in chat; MCP key scope is the standing approval', () => {
    assert.deepEqual(decideDispatch(base), { kind: 'execute', needsApproval: false })
    assert.deepEqual(decideDispatch({ ...base, executionMode: 'ask' }), { kind: 'execute', needsApproval: true })
    assert.deepEqual(decideDispatch({ ...base, forceConfirm: true }), { kind: 'execute', needsApproval: true })
    assert.deepEqual(decideDispatch({ ...base, labels: L('external-mcp', 'write'), surface: 'mcp', forceConfirm: true }), {
      kind: 'execute',
      needsApproval: false,
    })
  })

  // ── External list ─────────────────────────────────────────────────────────
  await check('external MCP list is generated: only external-mcp, never irreversible or internal', () => {
    const registry = {
      readThing: L('external-mcp', 'read'),
      editThing: L('external-mcp', 'draft'),
      deleteThing: L('external-mcp', 'irreversible'),
      chatOnly: L('in-app', 'write'),
      serverOnly: L('internal', 'read'),
    }
    assert.deepEqual(externalToolNames(registry), ['editThing', 'readThing'])
  })

  // ── ChangeSet logic ───────────────────────────────────────────────────────
  await check('set status derives from item statuses', () => {
    assert.equal(deriveSetStatus([]), 'pending')
    assert.equal(deriveSetStatus(['pending', 'pending']), 'pending')
    assert.equal(deriveSetStatus(['pending', 'approved']), 'partial')
    assert.equal(deriveSetStatus(['saved', 'approved']), 'saved')
    assert.equal(deriveSetStatus(['approved', 'approved']), 'approved')
    assert.equal(deriveSetStatus(['rejected']), 'rejected')
    assert.equal(deriveSetStatus(['approved', 'rejected']), 'done')
    assert.equal(deriveSetStatus(['stale', 'approved']), 'done')
    assert.equal(deriveSetStatus(['applying', 'approved']), 'partial')
  })

  await check('review rules: pending takes anything; saved can be approved/rejected; decided is final', () => {
    assert.ok(canReview('pending', 'save'))
    assert.ok(canReview('saved', 'approve'))
    assert.ok(!canReview('saved', 'save'))
    assert.ok(!canReview('approved', 'reject'))
    assert.ok(!canReview('rejected', 'approve'))
    assert.ok(canReview('stale', 'reject') && !canReview('stale', 'approve'))
    assert.ok(canReview('failed', 'reject') && !canReview('failed', 'save'))
    assert.ok(!canReview('applying', 'approve'))
    // resume undoes "Not now": only from saved, back to pending.
    assert.ok(canReview('saved', 'resume') && !canReview('pending', 'resume') && !canReview('approved', 'resume'))
    assert.equal(statusAfter('resume'), 'pending')
  })

  await check('staleness compares key-order-insensitively; creates are never stale', () => {
    assert.ok(stableEqual({ a: 1, b: { c: 2, d: 3 } }, { b: { d: 3, c: 2 }, a: 1 }))
    assert.equal(isStale('update', { title: 'A', slug: 'a' }, { slug: 'a', title: 'A' }), false)
    assert.equal(isStale('update', { title: 'A' }, { title: 'B' }), true)
    assert.equal(isStale('update', { title: 'A' }, null), true)
    assert.equal(isStale('create', null, null), false)
  })

  await check('field diff lists only changed fields', () => {
    assert.deepEqual(diffFields({ title: 'A', slug: 'a' }, { title: 'B', slug: 'a' }), [
      { field: 'title', before: 'A', after: 'B' },
    ])
  })

  await check('block diff: changed, added (not sibling index noise), removed, moved', () => {
    const before = [
      { id: 'h', tag: 'section', children: [{ id: 't', tag: 'h1', textContent: 'Hi' }, { id: 'x', tag: 'p' }] },
      { id: 'f', tag: 'footer' },
    ]
    const after = [
      {
        id: 'h',
        tag: 'section',
        children: [{ id: 'new', tag: 'p', textContent: 'New' }, { id: 't', tag: 'h1', textContent: 'Hello' }],
      },
      { id: 'f', tag: 'footer', children: [{ id: 'x', tag: 'p' }] },
    ]
    const d = diffBlocks(before, after)
    const by = (id: string) => d.find((c) => c.blockId === id)
    assert.equal(by('t')?.kind, 'changed')
    assert.deepEqual(by('t')?.fields, [{ field: 'textContent', before: 'Hi', after: 'Hello' }])
    assert.equal(by('new')?.kind, 'added')
    assert.equal(by('x')?.kind, 'moved')
    assert.equal(by('h'), undefined)
    assert.equal(diffBlocks(before, before.filter((b) => b.id !== 'f')).find((c) => c.blockId === 'f')?.kind, 'removed')
  })

  // A reorder within the same parent is a move (2026-11-16: the assistant moved a heading to the end
  // of its section and the To-do title said only 'Removes one part'). Index shifts from a sibling
  // added or removed are still not moves: only blocks whose order among their kept siblings changed.
  await check('block diff: a reorder in the same parent is a move; sibling inserts and removals are not', () => {
    const kids = (...ids: string[]) => [{ id: 'sec', tag: 'section', children: ids.map((id) => ({ id, tag: 'p' })) }]
    const kinds = (d: ReturnType<typeof diffBlocks>) => d.map((c) => `${c.blockId}:${c.kind}`).sort()
    assert.deepEqual(kinds(diffBlocks(kids('a', 'b', 'c', 'd'), kids('b', 'c', 'd', 'a'))), ['a:moved'])
    assert.deepEqual(kinds(diffBlocks(kids('a', 'b', 'c'), kids('a', 'c'))), ['b:removed'])
    assert.deepEqual(kinds(diffBlocks(kids('a', 'b', 'c'), kids('x', 'a', 'b', 'c'))), ['x:added'])
    assert.deepEqual(kinds(diffBlocks(kids('a', 'b', 'c', 'd'), kids('a', 'c', 'd', 'b'))), ['b:moved'])
    assert.deepEqual(kinds(diffBlocks(kids('a', 'b', 'c'), kids('c', 'b', 'a'))).length, 2)
  })

  await check('class token diff: removed, added, kept (order of the new string)', () => {
    assert.deepEqual(diffTokens('p-4 text-sm bg-white', 'p-6 text-sm bg-white shadow'), {
      removed: ['p-4'],
      added: ['p-6', 'shadow'],
      kept: ['text-sm', 'bg-white'],
    })
    assert.deepEqual(diffTokens(null, 'a'), { removed: [], added: ['a'], kept: [] })
  })

  // ── ChangeSet service (in-memory store) ───────────────────────────────────
  await check('service: edits to one target fold into one item; apply writes; stale is refused', async () => {
    const { store, sets, items } = memoryStore()
    const live: Record<string, { title: string }> = { p1: { title: 'Old' } }
    const applied: string[] = []
    const draftRetitle: Drafter['draft'] = async (input, pending) => {
      const id = String(input.id)
      if (!live[id]) return { error: 'not found' }
      const base = (pending?.after as { title: string } | undefined) ?? live[id]
      const merged = { ...(pending?.input ?? {}), ...input }
      return {
        targetType: 'thing',
        targetId: id,
        operation: 'update',
        category: 'things',
        before: live[id],
        after: { ...base, title: String(input.title) },
        input: merged,
        blockIds: [String(input.title)],
        summary: `Retitle to ${input.title}`,
      }
    }
    const adapter: TargetAdapter = {
      snapshot: async (id) => live[id] ?? null,
      apply: async (item) => {
        live[item.targetId!] = item.after as { title: string }
        applied.push(item.id)
        return {}
      },
    }
    let clock = new Date('2026-10-09T10:00:00Z')
    const svc = createChangeSetService({
      store,
      drafters: {
        retitle: {
          target: async (input) => (live[String(input.id)] ? { targetType: 'thing', targetId: String(input.id) } : { error: 'not found' }),
          draft: draftRetitle,
        },
      },
      adapters: { thing: adapter },
      now: () => clock,
    })

    assert.equal(svc.canDraft('retitle'), true)
    assert.equal(svc.canDraft('deleteThing'), false)

    const r1 = await svc.propose({ ownerId: 'u1', source: 'chat', toolName: 'retitle', input: { id: 'p1', title: 'A' } })
    const r2 = await svc.propose({ ownerId: 'u1', source: 'chat', toolName: 'retitle', input: { id: 'p1', title: 'B' } })
    assert.ok(r1.ok && r2.ok)
    if (!r1.ok || !r2.ok) return
    assert.equal(r2.merged, true)
    assert.equal(r1.itemId, r2.itemId)
    assert.equal(items.size, 1)
    const item = items.get(r1.itemId)!
    assert.deepEqual(item.after, { title: 'B' })
    assert.deepEqual(item.before, { title: 'Old' })
    assert.deepEqual(item.blockIds, ['B'], "the drafter's latest list wins")
    assert.equal(live.p1.title, 'Old', 'nothing is written until approval')

    // A different owner gets a separate set.
    const r3 = await svc.propose({ ownerId: 'u2', source: 'chat', toolName: 'retitle', input: { id: 'p1', title: 'C' } })
    assert.ok(r3.ok && r3.changeSetId !== r1.changeSetId)

    // After the grouping window a new set starts.
    clock = new Date(clock.getTime() + 31 * 60_000)
    const r4 = await svc.propose({ ownerId: 'u1', source: 'chat', toolName: 'retitle', input: { id: 'p1', title: 'D' } })
    assert.ok(r4.ok && r4.changeSetId !== r1.changeSetId)

    // Approve the first: applied, set approved.
    const [o1] = await svc.review([r1.itemId], 'approve', { id: 'admin' })
    assert.equal(o1.status, 'approved')
    assert.equal(live.p1.title, 'B')
    assert.equal(sets.get(r1.changeSetId)!.status, 'approved')

    // u2's draft was made against "Old" — now stale, refused, not written.
    if (!r3.ok) return
    const [o3] = await svc.review([r3.itemId], 'approve', { id: 'admin' })
    assert.equal(o3.status, 'stale')
    assert.equal(live.p1.title, 'B')

    // Decided items can't be re-decided.
    const [again] = await svc.review([r1.itemId], 'reject', { id: 'admin' })
    assert.equal(again.status, 'approved')
    assert.match(again.error ?? '', /already approved/)

    // Save for later, then reject.
    if (!r4.ok) return
    assert.equal((await svc.review([r4.itemId], 'save', { id: 'admin' }))[0].status, 'saved')
    assert.equal(sets.get(r4.changeSetId)!.status, 'saved')
    assert.equal((await svc.review([r4.itemId], 'reject', { id: 'admin' }))[0].status, 'rejected')
    assert.deepEqual(applied, [r1.itemId])
  })

  await check('service: an approved item keeps the version its apply recorded (change cards)', async () => {
    const { store, items } = memoryStore()
    const live: Record<string, { title: string }> = { p1: { title: 'Old' } }
    const svc = createChangeSetService({
      store,
      drafters: {
        retitle: {
          target: async (input) => ({ targetType: 'thing', targetId: String(input.id) }),
          draft: async (input) => ({ targetType: 'thing', targetId: String(input.id), operation: 'update', category: 'pages', before: live[String(input.id)], after: { title: String(input.title) }, input, blockIds: [], summary: 'Retitle' }),
        },
      },
      adapters: {
        thing: {
          snapshot: async (id) => live[id] ?? null,
          apply: async (item) => {
            live[item.targetId!] = item.after as { title: string }
            return { resultId: item.targetId!, revisionId: 'rev-7', version: 7 }
          },
        },
      },
    })
    const r = await svc.propose({ ownerId: 'u1', source: 'chat', toolName: 'retitle', input: { id: 'p1', title: 'New' } })
    assert.ok(r.ok)
    if (!r.ok) return
    const [out] = await svc.review([r.itemId], 'approve', { id: 'owner', email: null })
    assert.equal(out.status, 'approved')
    assert.equal(out.revisionId, 'rev-7')
    assert.equal((items.get(r.itemId) as unknown as { revisionId?: string }).revisionId, 'rev-7', 'stored on the item')
  })

  await check('service: a drafter error proposes nothing; an apply error marks the item failed', async () => {
    const { store, items } = memoryStore()
    const svc = createChangeSetService({
      store,
      drafters: {
        bad: { target: async () => ({ error: 'Page not found: nope' }), draft: async () => ({ error: 'unreachable' }) },
        make: { target: async () => null, draft: async (input) => ({
          targetType: 'boom',
          targetId: null,
          operation: 'create',
          category: 'x',
          before: null,
          after: input,
          input,
          blockIds: [],
          summary: 'make',
        }) },
      },
      adapters: {
        boom: {
          snapshot: async () => null,
          apply: async () => {
            throw new Error('slug taken')
          },
        },
      },
    })
    const bad = await svc.propose({ ownerId: 'u', source: 'mcp', toolName: 'bad', input: {} })
    assert.deepEqual(bad, { ok: false, error: 'Page not found: nope' })
    assert.equal(items.size, 0)
    const made = await svc.propose({ ownerId: 'u', source: 'mcp', toolName: 'make', input: { t: 1 } })
    assert.ok(made.ok)
    if (!made.ok) return
    const [o] = await svc.review([made.itemId], 'approve', { id: 'a' })
    assert.equal(o.status, 'failed')
    assert.equal(o.error, 'slug taken')
  })

  await check('service: concurrent approvals apply once; a fold after approval becomes a new item', async () => {
    const { store, items } = memoryStore()
    const live: Record<string, { n: number }> = { t: { n: 0 } }
    let applies = 0
    const svc = createChangeSetService({
      store,
      drafters: {
        bump: { target: async () => ({ targetType: 'x', targetId: 't' }), draft: async (input, pending) => ({
          targetType: 'x',
          targetId: 't',
          operation: 'update',
          category: 'c',
          before: pending ? pending.before : live.t,
          after: { n: Number(input.n) },
          input,
          blockIds: [],
          summary: `set ${input.n}`,
        }) },
      },
      adapters: {
        x: {
          snapshot: async () => live.t,
          apply: async (item) => {
            applies++
            await new Promise((r) => setTimeout(r, 5))
            live.t = item.after as { n: number }
            return {}
          },
        },
      },
    })
    const r = await svc.propose({ ownerId: 'u', source: 'chat', toolName: 'bump', input: { n: 1 } })
    assert.ok(r.ok)
    if (!r.ok) return
    const [a, b] = await Promise.all([
      svc.review([r.itemId], 'approve', { id: 'a' }),
      svc.review([r.itemId], 'approve', { id: 'b' }),
    ])
    assert.equal(applies, 1, 'applied exactly once')
    assert.deepEqual([a[0].status, b[0].status].sort(), ['approved', 'pending'])
    assert.ok([a[0].error, b[0].error].some((e) => /already reviewing/.test(e ?? '')))

    // Same target again within the window: the approved item can't absorb it.
    const r2 = await svc.propose({ ownerId: 'u', source: 'chat', toolName: 'bump', input: { n: 2 } })
    assert.ok(r2.ok && r2.itemId !== r.itemId && !r2.merged)
    assert.equal(items.size, 2)
  })

  await check('service: an edit that depends on an earlier draft builds on it (not on live)', async () => {
    const { store } = memoryStore()
    const live: { blocks: string[] } = { blocks: [] }
    const svc = createChangeSetService({
      store,
      drafters: {
        add: {
          target: async () => ({ targetType: 'doc', targetId: 'd' }),
          draft: async (input, pending) => {
            const base = (pending?.after as { blocks: string[] } | undefined) ?? live
            const parent = input.parent as string | undefined
            if (parent && !base.blocks.includes(parent)) return { error: `Parent block not found: ${parent}` }
            return {
              targetType: 'doc',
              targetId: 'd',
              operation: 'update',
              category: 'pages',
              before: pending ? pending.before : live,
              after: { blocks: [...base.blocks, String(input.id)] },
              input,
              blockIds: [String(input.id)],
              summary: `add ${input.id}`,
            }
          },
        },
      },
      adapters: {},
      now: () => new Date('2026-10-09T10:05:00Z'),
    })
    const a = await svc.propose({ ownerId: 'u', source: 'mcp', toolName: 'add', input: { id: 'section' } })
    const b = await svc.propose({ ownerId: 'u', source: 'mcp', toolName: 'add', input: { id: 'h1', parent: 'section' } })
    assert.ok(a.ok && b.ok, JSON.stringify(b))
    if (!a.ok || !b.ok) return
    assert.equal(b.merged, true)
    assert.deepEqual(b.change.after, { blocks: ['section', 'h1'] })
  })

  // ── Tasks ─────────────────────────────────────────────────────────────────
  const now = new Date('2026-10-09T12:00:00Z')
  const signals: TaskSignals = {
    pendingChangeSets: [
      { id: 'cs1', title: 'Homepage copy', itemCount: 2, oldestAt: new Date('2026-10-06T12:00:00Z') },
      { id: 'cs0', title: 'empty', itemCount: 0, oldestAt: now },
    ],
    unreadSubmissions: [{ formId: 'f1', formName: 'Volunteer', count: 3, newestId: 's9' }],
    staleDrafts: [
      { kind: 'page', id: 'p1', title: 'Old draft', updatedAt: new Date('2026-09-20T00:00:00Z') },
      { kind: 'blog-post', id: 'b1', title: 'Fresh', updatedAt: new Date('2026-10-08T00:00:00Z') },
    ],
    brokenMedia: [{ id: 'm1', filename: 'hero.jpg', reason: 'URL points at a retired host' }],
    failedJobs: [{ id: 'w1', name: 'Newsletter', at: now, error: 'SMTP timeout' }],
  }

  await check('tasks: one per real signal, empty/fresh signals skipped, priority-sorted', () => {
    const t = generateTasks(signals, { now, staleDraftDays: 7 })
    assert.deepEqual(
      new Set(t.map((x) => x.dedupeKey)),
      new Set([
        'form-submissions:f1:s9',
        'pending-changes:cs1',
        'failed-jobs:w1',
        'broken-media:m1',
        'stale-drafts:page:p1',
      ])
    )
    assert.equal(t.length, 5)
    assert.equal(t[0].priority, 1)
    assert.ok(t.every((x, i) => i === 0 || t[i - 1].priority <= x.priority))
    const pc = t.find((x) => x.source === 'pending-changes')!
    assert.equal(pc.priority, 1, 'waiting 3 days escalates')
    assert.equal(pc.href, '/admin/todo?view=all&item=cs1')
    assert.ok(!t.some((x) => x.targetId === 'b1'), 'a 1-day-old draft is not stale')
  })

  await check('tasks: a new submission changes the key (reopens); vanished signals resolve', () => {
    const t1 = generateTasks(signals, { now, staleDraftDays: 7 })
    const t2 = generateTasks(
      { ...signals, unreadSubmissions: [{ formId: 'f1', formName: 'Volunteer', count: 4, newestId: 's10' }], brokenMedia: [] },
      { now, staleDraftDays: 7 }
    )
    assert.notEqual(
      t1.find((x) => x.source === 'form-submissions')!.dedupeKey,
      t2.find((x) => x.source === 'form-submissions')!.dedupeKey
    )
    assert.deepEqual(
      tasksToResolve(t1.map((x) => x.dedupeKey), t2).sort(),
      ['broken-media:m1', 'form-submissions:f1:s9']
    )
  })

  await check('tasks: visibility follows the permission each task needs', () => {
    const t = generateTasks(signals, { now, staleDraftDays: 7 })
    const editor = visibleTo(t, (p) => p === 'pages.edit')
    assert.deepEqual(new Set(editor.map((x) => x.source)), new Set(['pending-changes', 'stale-drafts']))
  })

  // ── Code-exec gate ────────────────────────────────────────────────────────
  await check('code exec: OFF until loaded, fails closed on load error, caches with TTL', async () => {
    let t = 0
    let stored = true
    let loads = 0
    const gate = createCodeExecGate({
      load: async () => {
        loads++
        return stored
      },
      ttlMs: 1000,
      now: () => t,
    })
    assert.equal(gate.isEnabledCached(), false, 'cold = off')
    assert.equal(await gate.isEnabled(), true)
    assert.equal(gate.isEnabledCached(), true)
    stored = false
    t = 500
    assert.equal(await gate.isEnabled(), true, 'cached within TTL')
    t = 1500
    assert.equal(await gate.isEnabled(), false, 'reloaded after TTL')
    assert.equal(loads, 2)
    stored = true
    t = 3000
    assert.equal(await gate.isEnabled(), true)
    t = 3000 + 1001
    assert.equal(gate.isEnabledCached(), false, 'sync read fails closed once stale')
    stored = false
    await assert.rejects(gate.assertEnabled('vMCP tool'), CodeExecutionDisabledError)

    const broken = createCodeExecGate({
      load: async () => {
        throw new Error('db down')
      },
    })
    assert.equal(await broken.isEnabled(), false)
    const truthy = createCodeExecGate({ load: async () => 'yes' as unknown as boolean })
    assert.equal(await truthy.isEnabled(), false, 'only a real true enables')
  })

  // ── Split ratio ───────────────────────────────────────────────────────────
  await check('split ratio clamps and falls back', () => {
    assert.equal(clampSplitRatio(undefined), DEFAULT_SPLIT_RATIO)
    assert.equal(clampSplitRatio('0.5'), 0.5)
    assert.equal(clampSplitRatio(0.01), MIN_SPLIT_RATIO)
    assert.equal(clampSplitRatio(5), MAX_SPLIT_RATIO)
    assert.equal(clampSplitRatio(NaN), DEFAULT_SPLIT_RATIO)
    assert.equal(ratioFromPointer(500, 0, 1000), 0.5)
    assert.equal(ratioFromPointer(10, 0, 0), DEFAULT_SPLIT_RATIO)
  })

  await check('Not now snoozes until tomorrow; anything still pending keeps it in focus', () => {
    const day = new Date('2026-10-09T00:00:00')
    const today = '2026-10-09T15:00:00'
    assert.equal(isSnoozed([{ status: 'saved', decidedAt: today }], day), true)
    assert.equal(isSnoozed([{ status: 'saved', decidedAt: '2026-10-08T23:00:00' }], day), false)
    assert.equal(isSnoozed([{ status: 'saved', decidedAt: today }, { status: 'pending', decidedAt: null }], day), false)
    assert.equal(isSnoozed([{ status: 'saved', decidedAt: today }, { status: 'approved', decidedAt: today }], day), true)
    assert.equal(isSnoozed([], day), false)
  })

  console.log(`\n${n} checks passed`)
}

/** In-memory ChangeSetStore for the service checks. */
function memoryStore() {
  const sets = new Map<string, ChangeSetRecord & { createdAt: Date }>()
  const items = new Map<string, ChangeSetItemRecord>()
  let seq = 0
  let tick = 0
  const store: ChangeSetStore = {
    async findOpenSet(ownerId, source, since) {
      const open = [...sets.values()]
        .filter(
          (s) =>
            s.ownerId === ownerId &&
            s.source === source &&
            (s.status === 'pending' || s.status === 'partial') &&
            s.updatedAt >= since
        )
        .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
      return open[0] ?? null
    },
    async createSet(d) {
      const id = `cs${++seq}`
      const at = new Date(Date.parse('2026-10-09T10:00:00Z') + tick++)
      const rec = { id, ...d, status: 'pending' as const, updatedAt: at, createdAt: at }
      sets.set(id, rec)
      return rec
    },
    async setStatus(id, status) {
      const s = sets.get(id)!
      sets.set(id, { ...s, status })
    },
    async findPendingItem(changeSetId, targetType, targetId) {
      return (
        [...items.values()].find(
          (i) => i.changeSetId === changeSetId && i.targetType === targetType && i.targetId === targetId && i.status === 'pending'
        ) ?? null
      )
    },
    async createItem(d) {
      const rec: ChangeSetItemRecord = { id: `it${++seq}`, ...d, status: 'pending', error: null, resultId: null }
      items.set(rec.id, rec)
      return rec
    },
    async claimItem(id, from, to) {
      const cur = items.get(id)
      if (!cur || !from.includes(cur.status)) return false
      items.set(id, { ...cur, status: to })
      return true
    },
    async foldIntoPending(id, patch) {
      const cur = items.get(id)
      if (!cur || cur.status !== 'pending') return null
      const next = { ...cur, ...patch }
      items.set(id, next)
      return next
    },
    async updateItem(id, patch) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { decidedById, ...rest } = patch
      const next = { ...items.get(id)!, ...rest } as ChangeSetItemRecord
      items.set(id, next)
      return next
    },
    async getItems(ids) {
      return ids.map((id) => items.get(id)).filter((x): x is ChangeSetItemRecord => Boolean(x))
    },
    async listItemStatuses(changeSetId) {
      return [...items.values()].filter((i) => i.changeSetId === changeSetId).map((i) => i.status)
    },
    async addComment() {},
  }
  return { store, sets, items }
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
