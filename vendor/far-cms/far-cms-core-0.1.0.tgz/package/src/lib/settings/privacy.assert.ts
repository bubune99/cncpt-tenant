/**
 * Run: npx -y tsx@4.23.15 src/lib/settings/privacy.assert.ts
 */
import assert from 'node:assert/strict'
import { DEFAULT_PRIVACY, PREVIEW_MESSAGE, bumpPolicyVersion, choiceFor, consentRecord, initialSwitches, needsConsent, previewSettingsFrom, resolvePrivacy, validatePrivacy } from './privacy'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('nothing saved → today’s banner, word for word', () => {
  const p = resolvePrivacy(null)
  assert.deepEqual(p, DEFAULT_PRIVACY)
  assert.equal(p.acceptLabel, 'Accept All')
  assert.equal(p.rejectLabel, 'Reject Non-Essential')
  assert.equal(p.chooseLabel, 'Manage Preferences')
  assert.equal(p.position, 'bottom')
  assert.equal(p.footerLink, false, 'no new footer link until someone turns it on')
})

check('odd stored values fall back safely', () => {
  const p = resolvePrivacy({ position: 'top', policyVersion: -3, acceptLabel: '   ', policyPageSlug: 'javascript:x', defaults: { analytics: 'yes' } })
  assert.equal(p.position, 'bottom')
  assert.equal(p.policyVersion, 1)
  assert.equal(p.acceptLabel, 'Accept All')
  assert.equal(p.policyPageSlug, '')
  assert.equal(p.defaults.analytics, false)
  assert.equal(resolvePrivacy({ policyPageSlug: '/privacy' }).policyPageSlug, '/privacy')
})

check('existing visitors are not asked again until the policy version goes up', () => {
  const p = resolvePrivacy(null)
  const old = { version: 1, consent: { analytics: true }, timestamp: 1 } // stored before policyVersion existed
  assert.equal(needsConsent(null, p), true)
  assert.equal(needsConsent(old, p), false)
  const bumped = bumpPolicyVersion(p)
  assert.equal(bumped.policyVersion, 2)
  assert.equal(needsConsent(old, bumped), true)
  assert.equal(needsConsent({ ...old, policyVersion: 2 }, bumped), false)
  assert.equal(needsConsent(old, { ...bumped, askAgainOnChange: false }), false)
})

check('each button makes the choice it says; essential is always on', () => {
  assert.deepEqual(choiceFor('accept'), { essential: true, analytics: true, marketing: true, functional: true })
  assert.deepEqual(choiceFor('reject'), { essential: true, analytics: false, marketing: false, functional: false })
  assert.deepEqual(choiceFor('choose', { analytics: true }), { essential: true, analytics: true, marketing: false, functional: true })
  assert.deepEqual(choiceFor('choose'), { essential: true, analytics: false, marketing: false, functional: false })
})

check('switches start at the site defaults, then the visitor’s last choice', () => {
  const p = resolvePrivacy({ defaults: { analytics: true, marketing: false } })
  assert.deepEqual(initialSwitches(null, p), { analytics: true, marketing: false })
  assert.deepEqual(initialSwitches({ version: 1, consent: { analytics: false, marketing: true }, timestamp: 1 }, p), { analytics: false, marketing: true })
})

check('the compliance record holds the choice and policy, no personal data', () => {
  const r = consentRecord('reject', choiceFor('reject'), resolvePrivacy({ policyVersion: 3, policyPageSlug: '/privacy' }), 'c-1')
  assert.deepEqual(r, { consentId: 'c-1', action: 'reject', analytics: false, marketing: false, policyVersion: 3, policyPage: '/privacy' })
})

check('validation and preview messages', () => {
  assert.deepEqual(validatePrivacy(DEFAULT_PRIVACY), {})
  assert.ok(validatePrivacy({ ...DEFAULT_PRIVACY, acceptLabel: '' }).acceptLabel)
  assert.equal(previewSettingsFrom({ type: 'other', settings: {} }), null)
  assert.equal(previewSettingsFrom({ type: PREVIEW_MESSAGE, settings: { position: 'corner' } })?.position, 'corner')
})

console.log(`\n${n} checks passed`)
