/**
 * Run: npx -y tsx@4.23.15 src/lib/settings/site-identity.assert.ts
 */
import assert from 'node:assert/strict'
import { contactFromStored, contactPayload, identityFromStored, identityPayload, validateContact, validateIdentity } from './site-identity'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// What staging has today (read 2026-10-10).
const branding = { siteName: 'Project Dzidzor', siteTagline: 'Delivering Hope, Healing Lives', primaryColor: '#022b39', accentColor: '#088cbc' }
const general = { siteName: 'Project Dzidzor', siteUrl: 'https://www.projectdzidzor.org', supportEmail: 'dzidzormissionproject@gmail.com' }

check('the client’s stored values show unchanged', () => {
  const f = identityFromStored(branding, general)
  assert.equal(f.siteName, 'Project Dzidzor')
  assert.equal(f.primaryColor, '#022b39')
  assert.equal(f.accentColor, '#088cbc')
  assert.equal(f.logoUrl, '')
  assert.equal(contactFromStored(general).supportEmail, 'dzidzormissionproject@gmail.com')
})

check('name falls back to the old General value only when branding has none', () => {
  assert.equal(identityFromStored({}, { siteName: 'Old name' }).siteName, 'Old name')
  assert.equal(identityFromStored({ siteName: 'Brand' }, { siteName: 'Old' }).siteName, 'Brand')
})

check('one place each: contact save never writes the site name; identity save writes the colours', () => {
  const c = contactPayload(contactFromStored({ ...general, currency: 'EUR' }), { commerceEnabled: false })
  assert.ok(!('siteName' in c))
  assert.ok(!('currency' in c), 'currency hidden while the shop is off')
  assert.equal(contactPayload(contactFromStored({ currency: 'EUR' }), { commerceEnabled: true }).currency, 'EUR')
  const id = identityPayload(identityFromStored(branding))
  assert.equal(id.primaryColor, '#022b39')
  assert.ok(!('supportEmail' in id))
})

check('validation in plain words', () => {
  assert.deepEqual(validateIdentity(identityFromStored(branding)), [])
  assert.equal(validateIdentity({ ...identityFromStored(branding), siteName: ' ' }).length, 1)
  assert.equal(validateIdentity({ ...identityFromStored(branding), primaryColor: 'blue' }).length, 1)
  assert.deepEqual(validateContact(contactFromStored(general)), [])
  assert.equal(validateContact({ ...contactFromStored(general), supportEmail: 'nope' }).length, 1)
})

console.log(`\n${n} checks passed`)
