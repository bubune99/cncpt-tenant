/**
 * Run: npx -y tsx@4.23.15 src/lib/settings/group-access.assert.ts
 */
import assert from 'node:assert/strict'
import { settingsWriteRefusal } from './group-access'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const general = (p: string) => p === 'settings.general'

check('settings.general alone cannot write owner-only or specially-guarded groups', () => {
  for (const g of ['storage', 'security', 'navigation', 'agent', 'ade', 'env']) assert.ok(settingsWriteRefusal(g, general, false), g)
  for (const g of ['payments', 'shipping', 'ai']) assert.ok(settingsWriteRefusal(g, general, false), g)
  for (const g of ['branding', 'general', 'email', 'dashboard', 'seo']) assert.equal(settingsWriteRefusal(g, general, false), null, g)
})

check('the owner still needs the group permission; owner + permission writes', () => {
  assert.equal(settingsWriteRefusal('storage', general, true), null)
  assert.ok(settingsWriteRefusal('payments', general, true))
  assert.equal(settingsWriteRefusal('payments', (p) => p === 'settings.payments', false), null)
})

console.log(`\n${n} checks passed`)
