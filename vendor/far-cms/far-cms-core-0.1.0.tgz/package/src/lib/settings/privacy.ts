/**
 * Cookie & privacy banner settings (settings group `privacy`) and the
 * consent rules the banner follows. Pure (no React, no storage); asserted by
 * privacy.assert.ts.
 *
 * Read-compat: a group never saved reads as the banner the site shows today
 * (same words, bottom bar, no policy link), so the live site doesn't change
 * until someone saves.
 */

export type BannerPosition = 'bottom' | 'corner' | 'center'
export type OptionalCategory = 'analytics' | 'marketing'

export interface PrivacySettings {
  title: string
  message: string
  acceptLabel: string
  rejectLabel: string
  chooseLabel: string
  /** A CMS page id; '' = no link. */
  policyPageId: string
  /** Its address, kept with the id so the site needn't look it up. */
  policyPageSlug: string
  /** Default switch positions in "Choose". */
  defaults: Record<OptionalCategory, boolean>
  position: BannerPosition
  /** Ask everyone again when policyVersion goes up. */
  askAgainOnChange: boolean
  policyVersion: number
  /** Record each visitor's choice (compliance log). */
  keepRecord: boolean
  /** Show a "Cookie settings" link under the footer. */
  footerLink: boolean
  /**
   * Record nothing (not even an anonymous page view) until the visitor
   * presses Accept. Off = today's behaviour: before a choice, an anonymous
   * page view with no id and nothing on the device (lib/privacy/consent-decision).
   */
  trackOnlyAfterAccept: boolean
}

/** Today's banner, word for word. */
export const DEFAULT_PRIVACY: PrivacySettings = {
  title: '',
  message: 'We use cookies to enhance your experience. Essential cookies are always active. You can choose to accept all cookies or manage your preferences.',
  acceptLabel: 'Accept All',
  rejectLabel: 'Reject Non-Essential',
  chooseLabel: 'Manage Preferences',
  policyPageId: '',
  policyPageSlug: '',
  defaults: { analytics: false, marketing: false },
  position: 'bottom',
  askAgainOnChange: true,
  policyVersion: 1,
  keepRecord: true,
  footerLink: false,
  trackOnlyAfterAccept: false,
}

/** The suggested wording (prototype), offered by "Use suggested wording". */
export const SUGGESTED_WORDING: Pick<PrivacySettings, 'title' | 'message' | 'acceptLabel' | 'rejectLabel' | 'chooseLabel'> = {
  title: 'We value your privacy',
  message: 'We use cookies to make this site work and, with your permission, to understand how it is used. Essential cookies are always on.',
  acceptLabel: 'Accept all',
  rejectLabel: 'Only essential',
  chooseLabel: 'Choose',
}

export const CATEGORY_INFO: ReadonlyArray<{ id: 'essential' | OptionalCategory; label: string; hint: string }> = [
  // Turnstile (Cloudflare) checks form senders are people — security, so Essential (disclosed here).
  { id: 'essential', label: 'Essential', hint: 'Needed for the site to work (sign-in, security, your cookie choice). Includes Cloudflare Turnstile, which checks that forms are sent by people, not bots.' },
  { id: 'analytics', label: 'Analytics', hint: 'Helps us see which pages are useful. No ads.' },
  { id: 'marketing', label: 'Marketing', hint: 'Lets us measure campaigns and show relevant messages.' },
]

export const POSITIONS: ReadonlyArray<{ id: BannerPosition; label: string }> = [
  { id: 'bottom', label: 'Bottom bar' },
  { id: 'corner', label: 'Corner card' },
  { id: 'center', label: 'Centre pop-up' },
]

const LIMITS = { title: 80, message: 600, label: 40 } as const

const str = (v: unknown, max: number, fallback: string): string => (typeof v === 'string' ? v.slice(0, max) : fallback)
const bool = (v: unknown, fallback: boolean): boolean => (typeof v === 'boolean' ? v : fallback)

/** Stored (possibly partial / old / odd) → complete settings. */
export function resolvePrivacy(stored: Record<string, unknown> | null | undefined): PrivacySettings {
  const s = stored ?? {}
  const d = DEFAULT_PRIVACY
  const defaults = (s.defaults && typeof s.defaults === 'object' ? s.defaults : {}) as Record<string, unknown>
  const version = Number(s.policyVersion)
  return {
    title: str(s.title, LIMITS.title, d.title),
    message: str(s.message, LIMITS.message, d.message).trim() || d.message,
    acceptLabel: str(s.acceptLabel, LIMITS.label, d.acceptLabel).trim() || d.acceptLabel,
    rejectLabel: str(s.rejectLabel, LIMITS.label, d.rejectLabel).trim() || d.rejectLabel,
    chooseLabel: str(s.chooseLabel, LIMITS.label, d.chooseLabel).trim() || d.chooseLabel,
    policyPageId: str(s.policyPageId, 64, ''),
    policyPageSlug: /^\/[\w\-/]*$/.test(String(s.policyPageSlug ?? '')) ? String(s.policyPageSlug) : '',
    defaults: { analytics: bool(defaults.analytics, d.defaults.analytics), marketing: bool(defaults.marketing, d.defaults.marketing) },
    position: s.position === 'corner' || s.position === 'center' ? s.position : 'bottom',
    askAgainOnChange: bool(s.askAgainOnChange, d.askAgainOnChange),
    policyVersion: Number.isInteger(version) && version >= 1 && version <= 10_000 ? version : d.policyVersion,
    keepRecord: bool(s.keepRecord, d.keepRecord),
    footerLink: bool(s.footerLink, d.footerLink),
    trackOnlyAfterAccept: bool(s.trackOnlyAfterAccept, d.trackOnlyAfterAccept),
  }
}

/** Errors for the form (keyed by field); empty = OK to submit. */
export function validatePrivacy(p: PrivacySettings): Record<string, string> {
  const e: Record<string, string> = {}
  if (!p.message.trim()) e.message = 'Say briefly what cookies are used for.'
  if (p.message.length > LIMITS.message) e.message = `Keep the message under ${LIMITS.message} characters.`
  if (p.title.length > LIMITS.title) e.title = `Keep the title under ${LIMITS.title} characters.`
  for (const k of ['acceptLabel', 'rejectLabel', 'chooseLabel'] as const) {
    if (!p[k].trim()) e[k] = 'A button needs a label.'
    else if (p[k].length > LIMITS.label) e[k] = 'Keep button labels short.'
  }
  return e
}

/** "The policy changed — ask everyone again". */
export function bumpPolicyVersion(p: PrivacySettings): PrivacySettings {
  return { ...p, policyVersion: p.policyVersion + 1 }
}

// ---------------------------------------------------------------------------
// Consent decisions
// ---------------------------------------------------------------------------

export interface ConsentChoice {
  essential: true
  analytics: boolean
  marketing: boolean
  functional: boolean
}

/** What a visitor's browser remembers. Version 1 records (no policyVersion) are policy 1. */
export interface StoredChoice {
  version: number
  consent: { analytics?: boolean; marketing?: boolean; functional?: boolean }
  timestamp: number
  policyVersion?: number
}

/** Should the banner ask this visitor? */
export function needsConsent(stored: StoredChoice | null, p: PrivacySettings): boolean {
  if (!stored) return true
  if (!p.askAgainOnChange) return false
  return (stored.policyVersion ?? 1) < p.policyVersion
}

export type ConsentAction = 'accept' | 'reject' | 'choose'

/** The choice each button makes. "Choose" keeps the switches as set. */
export function choiceFor(action: ConsentAction, picked?: Partial<Record<OptionalCategory, boolean>>): ConsentChoice {
  if (action === 'accept') return { essential: true, analytics: true, marketing: true, functional: true }
  if (action === 'reject') return { essential: true, analytics: false, marketing: false, functional: false }
  const analytics = picked?.analytics === true
  return { essential: true, analytics, marketing: picked?.marketing === true, functional: analytics }
}

/** Where the switches start in "Choose": the visitor's last choice, else the site's defaults. */
export function initialSwitches(stored: StoredChoice | null, p: PrivacySettings): Record<OptionalCategory, boolean> {
  if (stored) return { analytics: stored.consent.analytics === true, marketing: stored.consent.marketing === true }
  return { ...p.defaults }
}

/** The compliance record (no names, no emails): what was chosen, under which policy. */
export function consentRecord(action: ConsentAction, choice: ConsentChoice, p: PrivacySettings, consentId: string): Record<string, unknown> {
  return { consentId, action, analytics: choice.analytics, marketing: choice.marketing, policyVersion: p.policyVersion, policyPage: p.policyPageSlug || null }
}

// ---------------------------------------------------------------------------
// Live preview (admin → iframe of the home page)
// ---------------------------------------------------------------------------

export const PREVIEW_PARAM = 'cookie-banner-preview'
export const PREVIEW_MESSAGE = 'dzidzor:cookie-banner-preview'

/** Is this message an unsaved-settings preview update? (same-origin is checked by the caller) */
export function previewSettingsFrom(data: unknown): PrivacySettings | null {
  if (!data || typeof data !== 'object') return null
  const d = data as Record<string, unknown>
  if (d.type !== PREVIEW_MESSAGE || !d.settings || typeof d.settings !== 'object') return null
  return resolvePrivacy(d.settings as Record<string, unknown>)
}
