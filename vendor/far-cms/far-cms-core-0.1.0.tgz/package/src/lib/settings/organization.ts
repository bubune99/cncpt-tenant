/**
 * Donations & social links (settings group `organization`).
 *
 * Today the Cash App / PayPal / social URLs are typed into the header,
 * footer and page content. The site keeps that content as it is and, at
 * render time, swaps a link for the saved value when either:
 *   - the link carries a binding (`data-link="social.instagram"`), or
 *   - the link is exactly today's hard-wired URL for that place.
 * Nothing saved yet → nothing changes. Pure; asserted by organization.assert.ts.
 */

export type DonationKind = 'cashapp' | 'paypal' | 'other'
export type SocialPlatform = 'instagram' | 'facebook' | 'x' | 'youtube' | 'tiktok' | 'linkedin'

export interface DonationMethod {
  id: string
  kind: DonationKind
  /** Shown on buttons, e.g. "Cash App". */
  label: string
  url: string
}

export interface OrganizationSettings {
  /** In the order they should appear. */
  donations: DonationMethod[]
  social: Partial<Record<SocialPlatform, string>>
}

export const SOCIAL_PLATFORMS: ReadonlyArray<{ id: SocialPlatform; label: string; placeholder: string }> = [
  { id: 'instagram', label: 'Instagram', placeholder: '@yourname or a link' },
  { id: 'facebook', label: 'Facebook', placeholder: 'yourpage or a link' },
  { id: 'x', label: 'X (Twitter)', placeholder: '@yourname or a link' },
  { id: 'youtube', label: 'YouTube', placeholder: '@yourchannel or a link' },
  { id: 'tiktok', label: 'TikTok', placeholder: '@yourname or a link' },
  { id: 'linkedin', label: 'LinkedIn', placeholder: 'company name or a link' },
]

export const DONATION_KINDS: ReadonlyArray<{ id: DonationKind; label: string; placeholder: string }> = [
  { id: 'cashapp', label: 'Cash App', placeholder: '$YourCashtag or a link' },
  { id: 'paypal', label: 'PayPal', placeholder: 'paypal.me name or a link' },
  { id: 'other', label: 'Other', placeholder: 'https://…' },
]

/** What the live site has hard-wired today (seeds + live header/footer). */
export const DEFAULT_ORGANIZATION: OrganizationSettings = {
  donations: [
    { id: 'cashapp', kind: 'cashapp', label: 'Cash App', url: 'https://cash.app/$ProjectDzidzor' },
    { id: 'paypal', kind: 'paypal', label: 'PayPal', url: 'https://www.paypal.com/paypalme/ProjectDzidzor' },
  ],
  social: {
    instagram: 'https://www.instagram.com/project_dzidzor',
    facebook: 'https://facebook.com/projectdzidzor',
    x: 'https://twitter.com/projectdzidzor',
    linkedin: 'https://www.linkedin.com/company/projectdzidzor',
  },
}

const SOCIAL_BASE: Record<SocialPlatform, (h: string) => string> = {
  instagram: (h) => `https://www.instagram.com/${h}`,
  facebook: (h) => `https://facebook.com/${h}`,
  x: (h) => `https://x.com/${h}`,
  youtube: (h) => `https://www.youtube.com/@${h}`,
  tiktok: (h) => `https://www.tiktok.com/@${h}`,
  linkedin: (h) => `https://www.linkedin.com/company/${h}`,
}

const HANDLE = /^[\w.-]{1,100}$/

function asUrl(raw: string): { url: string } | { error: string } {
  const withScheme = /^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`
  try {
    const u = new URL(withScheme)
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return { error: 'Only web links (https://…) can be used.' }
    if (!u.hostname.includes('.')) return { error: 'That doesn’t look like a web address.' }
    // A bare domain comes back as "https://x.com/" — drop the slash the person didn't type.
    const url = u.toString()
    return { url: u.pathname === '/' && !u.search && !u.hash && !raw.endsWith('/') ? url.slice(0, -1) : url }
  } catch {
    return { error: 'That doesn’t look like a web address.' }
  }
}

/** A social handle ("@name", "name") or link → a full https link. Empty stays empty. */
export function normalizeSocial(platform: SocialPlatform, raw: string): { url: string; error?: string } {
  const v = raw.trim()
  if (!v) return { url: '' }
  const handle = v.replace(/^@/, '')
  if (!v.includes('/') && !v.includes(':') && HANDLE.test(handle) && !/\.(com|org|net|be|me)$/i.test(handle)) {
    return { url: SOCIAL_BASE[platform](handle) }
  }
  const r = asUrl(v)
  return 'error' in r ? { url: v, error: r.error } : { url: r.url }
}

/** A donation link: "$cashtag" for Cash App, a paypal.me name for PayPal, else a link. */
export function normalizeDonation(kind: DonationKind, raw: string): { url: string; error?: string } {
  const v = raw.trim()
  if (!v) return { url: '', error: 'Add a link or remove this way to give.' }
  if (kind === 'cashapp' && /^\$?[A-Za-z][\w-]{0,30}$/.test(v)) return { url: `https://cash.app/$${v.replace(/^\$/, '')}` }
  if (kind === 'paypal' && HANDLE.test(v) && !v.includes('.')) return { url: `https://www.paypal.com/paypalme/${v}` }
  const r = asUrl(v)
  return 'error' in r ? { url: v, error: r.error } : { url: r.url }
}

const isPlatform = (k: string): k is SocialPlatform => SOCIAL_PLATFORMS.some((p) => p.id === k)
const isKind = (k: unknown): k is DonationKind => k === 'cashapp' || k === 'paypal' || k === 'other'

/**
 * What's stored → settings. A group never saved reads as today's
 * hard-wired values, so the live site doesn't change.
 */
export function resolveOrganization(stored: Record<string, unknown> | null | undefined): OrganizationSettings {
  const st = stored ?? {}
  const donations = Array.isArray(st.donations)
    ? st.donations
        .filter((d): d is Record<string, unknown> => !!d && typeof d === 'object')
        .filter((d) => isKind(d.kind) && typeof d.url === 'string')
        .map((d, i) => ({
          id: typeof d.id === 'string' && d.id ? d.id : `m${i}`,
          kind: d.kind as DonationKind,
          label: typeof d.label === 'string' && d.label.trim() ? d.label.trim() : DONATION_KINDS.find((k) => k.id === d.kind)!.label,
          url: d.url as string,
        }))
    : DEFAULT_ORGANIZATION.donations.map((d) => ({ ...d }))
  const social: Partial<Record<SocialPlatform, string>> = {}
  if (st.social && typeof st.social === 'object') {
    for (const [k, v] of Object.entries(st.social as Record<string, unknown>)) if (isPlatform(k) && typeof v === 'string') social[k] = v
  } else Object.assign(social, DEFAULT_ORGANIZATION.social)
  return { donations, social }
}

/** Validate + normalise a save. Errors are keyed by field for the form. */
export function sanitizeOrganization(input: OrganizationSettings): { settings: OrganizationSettings; errors: Record<string, string> } {
  const errors: Record<string, string> = {}
  const donations = input.donations.slice(0, 10).map((d, i) => {
    const r = normalizeDonation(d.kind, d.url)
    if (r.error) errors[`donation.${i}`] = r.error
    return { id: d.id || `m${i}`, kind: d.kind, label: d.label.trim().slice(0, 40) || DONATION_KINDS.find((k) => k.id === d.kind)!.label, url: r.url }
  })
  const social: Partial<Record<SocialPlatform, string>> = {}
  for (const p of SOCIAL_PLATFORMS) {
    const r = normalizeSocial(p.id, input.social[p.id] ?? '')
    if (r.error) errors[`social.${p.id}`] = r.error
    if (r.url) social[p.id] = r.url
  }
  return { settings: { donations, social }, errors }
}

/** Compare links loosely: no scheme, no www., no trailing slash, case-insensitive host. */
export function linkKey(href: string): string {
  return href.trim().replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/+$/, '').toLowerCase()
}

export interface SiteLinks {
  /** linkKey(today's hard-wired URL) → the saved URL. */
  byDefault: Record<string, string>
  /** "social.instagram" / "donate.cashapp" / "donate.0" → the saved URL. */
  bindings: Record<string, string>
}

/** The swaps to make, from saved settings. Only links that actually changed are listed by default URL. */
export function siteLinks(org: OrganizationSettings): SiteLinks {
  const byDefault: Record<string, string> = {}
  const bindings: Record<string, string> = {}
  for (const [k, v] of Object.entries(org.social) as Array<[SocialPlatform, string]>) {
    if (!v) continue
    bindings[`social.${k}`] = v
    const def = DEFAULT_ORGANIZATION.social[k]
    if (def && linkKey(def) !== linkKey(v)) byDefault[linkKey(def)] = v
  }
  org.donations.forEach((d, i) => {
    if (!d.url) return
    bindings[`donate.${i}`] = d.url
    if (!bindings[`donate.${d.kind}`]) bindings[`donate.${d.kind}`] = d.url
  })
  for (const def of DEFAULT_ORGANIZATION.donations) {
    const now = org.donations.find((d) => d.kind === def.kind)
    if (now?.url && linkKey(now.url) !== linkKey(def.url)) byDefault[linkKey(def.url)] = now.url
  }
  return { byDefault, bindings }
}

export function hasSiteLinks(l: SiteLinks | null | undefined): boolean {
  return !!l && (Object.keys(l.byDefault).length > 0 || Object.keys(l.bindings).length > 0)
}

interface Linkable {
  attrs?: Record<string, string>
  children?: Linkable[]
}

/**
 * Swap bound / hard-wired hrefs for the saved ones. Returns the same array
 * when nothing changed (no re-render churn); never mutates.
 */
export function applySiteLinks<B extends Linkable>(blocks: B[], links: SiteLinks | null | undefined): B[] {
  if (!hasSiteLinks(links)) return blocks
  const l = links!
  let changed = false
  const walk = (list: B[]): B[] => {
    let listChanged = false
    const next = list.map((b) => {
      let out = b
      const href = b.attrs?.href
      const bind = b.attrs?.['data-link']
      const to = (bind && l.bindings[bind]) || (href ? l.byDefault[linkKey(href)] : undefined)
      if (to && to !== href) out = { ...out, attrs: { ...b.attrs, href: to } }
      if (b.children?.length) {
        const kids = walk(b.children as B[])
        if (kids !== b.children) out = { ...out, children: kids }
      }
      if (out !== b) listChanged = true
      return out
    })
    if (!listChanged) return list
    changed = true
    return next
  }
  const result = walk(blocks)
  return changed ? result : blocks
}
