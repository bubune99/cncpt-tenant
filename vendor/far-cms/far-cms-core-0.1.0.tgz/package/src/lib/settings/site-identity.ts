/**
 * ONE place each for the site name and the colours.
 *
 * The site reads both from the `branding` group (metadata, ThemeInjector,
 * CMS config), so branding is canonical. The old General tab also wrote
 * `general.siteName`, and the old Theme tab showed colour pickers that saved
 * nowhere. Nothing is migrated: these helpers read whatever is stored and
 * make sure each save only writes its own fields. Pure; asserted by
 * site-identity.assert.ts.
 */

export interface IdentityForm {
  siteName: string
  siteTagline: string
  logoUrl: string
  logoDarkUrl: string
  logoAlt: string
  /** Square icon / mark (lib/settings/brand). */
  iconUrl: string
  faviconUrl: string
  appleTouchIconUrl: string
  ogImageUrl: string
  primaryColor: string
  accentColor: string
}

export interface ContactForm {
  supportEmail: string
  supportPhone: string
  address: string
  timezone: string
  currency: string
}

const IDENTITY_KEYS: ReadonlyArray<keyof IdentityForm> = [
  'siteName', 'siteTagline', 'logoUrl', 'logoDarkUrl', 'logoAlt', 'iconUrl', 'faviconUrl', 'appleTouchIconUrl', 'ogImageUrl', 'primaryColor', 'accentColor',
]

const HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i

const s = (v: unknown): string => (typeof v === 'string' ? v : '')

/**
 * The identity form from what's stored. The name falls back to the old
 * General value only when branding has none (read-compat).
 */
export function identityFromStored(branding: Record<string, unknown> | null | undefined, general?: Record<string, unknown> | null): IdentityForm {
  const b = branding ?? {}
  const form = Object.fromEntries(IDENTITY_KEYS.map((k) => [k, s(b[k])])) as unknown as IdentityForm
  if (!form.siteName.trim()) form.siteName = s(general?.siteName)
  return form
}

export function contactFromStored(general: Record<string, unknown> | null | undefined): ContactForm {
  const g = general ?? {}
  return {
    supportEmail: s(g.supportEmail),
    supportPhone: s(g.supportPhone),
    address: s(g.address),
    timezone: s(g.timezone) || 'America/New_York',
    currency: s(g.currency) || 'USD',
  }
}

export function validateIdentity(form: IdentityForm): string[] {
  const errors: string[] = []
  if (!form.siteName.trim()) errors.push('The site needs a name.')
  for (const k of ['primaryColor', 'accentColor'] as const) {
    if (form[k] && !HEX.test(form[k])) errors.push(`${k === 'primaryColor' ? 'Main' : 'Accent'} color must look like #0066cc.`)
  }
  return errors
}

/** The branding save: identity fields only, trimmed. */
export function identityPayload(form: IdentityForm): Record<string, string> {
  return Object.fromEntries(IDENTITY_KEYS.map((k) => [k, form[k].trim()]))
}

/**
 * The general save: contact fields only — never the site name (that lives
 * in Identity & brand), and the currency only while the shop is on.
 */
export function contactPayload(form: ContactForm, opts: { commerceEnabled: boolean }): Record<string, string> {
  const out: Record<string, string> = {
    supportEmail: form.supportEmail.trim(),
    supportPhone: form.supportPhone.trim(),
    address: form.address.trim(),
    timezone: form.timezone,
  }
  if (opts.commerceEnabled) out.currency = form.currency
  return out
}

export function validateContact(form: ContactForm): string[] {
  const email = form.supportEmail.trim()
  return email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? ['The contact email doesn’t look right.'] : []
}
