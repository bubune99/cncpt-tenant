/**
 * Who may change each settings group — one list for every writer (the
 * settings APIs and version history), so a generic endpoint can't write a
 * group its own screen keeps from you. Pure; asserted by group-access.assert.ts.
 */

/** Groups whose screen is owner-only (Settings › Advanced, and what the assistant may see/do). */
export const OWNER_ONLY_SETTING_GROUPS: ReadonlySet<string> = new Set(['storage', 'security', 'navigation', 'agent', 'ade', 'env'])

/** The permission each group's own screen requires (else settings.general). */
export const SETTING_GROUP_PERMISSION: Readonly<Record<string, string>> = {
  payments: 'settings.payments',
  shipping: 'settings.shipping',
  ai: 'settings.ai',
  agent: 'settings.ai',
}

export function settingGroupPermission(group: string): string {
  return SETTING_GROUP_PERMISSION[group] ?? 'settings.general'
}

/** Can someone with `has(permission)` and owner status write `group`? */
export function settingsWriteRefusal(group: string, has: (permission: string) => boolean, isOwner: boolean): string | null {
  if (OWNER_ONLY_SETTING_GROUPS.has(group) && !isOwner) return 'Only the site owner can change these settings'
  if (!has(settingGroupPermission(group))) return 'You don’t have permission to change these settings'
  return null
}

/**
 * Settings fields a version restore never changes: each has its own gate
 * on its own screen (a super admin for changeMode 'direct' and DB code
 * execution, confirmLoosen for the visibility rules and areas, RBAC off),
 * and a restore must not be a way around it. Change them where they live.
 */
export const SETTINGS_NEVER_RESTORE: Readonly<Record<string, string>> = {
  changeMode: 'Change it in Settings › Assistant (direct mode needs a super admin)',
  agentModes: 'Change it in Settings › Assistant (letting the assistant do more needs a super admin)',
  allowDbCodeExecution: 'Only a super admin can change this, in its own setting',
  visibilityRules: 'Change what the assistant can see in its own screen, where loosening is confirmed',
  privacyAreas: 'Change the private areas in their own screen, where loosening is confirmed',
  respectRbac: 'The assistant always follows each person’s permissions',
}
