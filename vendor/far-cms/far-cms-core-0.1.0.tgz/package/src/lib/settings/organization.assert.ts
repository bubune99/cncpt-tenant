/**
 * Run: npx -y tsx@4.23.15 src/lib/settings/organization.assert.ts
 */
import assert from 'node:assert/strict'
import { DEFAULT_ORGANIZATION, applySiteLinks, linkKey, normalizeDonation, normalizeSocial, resolveOrganization, sanitizeOrganization, siteLinks } from './organization'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// The live header (staging, 2026-10-10) — shape trimmed.
const header = [
  { id: 'nav', attrs: {}, children: [
    { id: 'ig', attrs: { href: 'https://www.instagram.com/project_dzidzor' } },
    { id: 'fb', attrs: { href: 'https://facebook.com/projectdzidzor' } },
    { id: 'x', attrs: { href: 'https://twitter.com/projectdzidzor' } },
    { id: 'donate', attrs: { href: '/donate' } },
  ] },
]
const home = [{ id: 'pp', attrs: { href: 'https://www.paypal.com/paypalme/ProjectDzidzor' } }, { id: 'vid', attrs: { href: 'https://www.youtube.com/watch?v=abc' } }]

check('nothing saved → today’s values, and the site is untouched (same arrays)', () => {
  const org = resolveOrganization(null)
  assert.deepEqual(org, DEFAULT_ORGANIZATION)
  const links = siteLinks(org)
  assert.deepEqual(links.byDefault, {})
  assert.equal(applySiteLinks(header, links), header)
  assert.equal(applySiteLinks(home, links), home)
})

check('handles become links', () => {
  assert.equal(normalizeSocial('instagram', '@new_handle').url, 'https://www.instagram.com/new_handle')
  assert.equal(normalizeSocial('x', 'dzidzor').url, 'https://x.com/dzidzor')
  assert.equal(normalizeSocial('youtube', '@chan').url, 'https://www.youtube.com/@chan')
  assert.equal(normalizeSocial('tiktok', 'tok').url, 'https://www.tiktok.com/@tok')
  assert.equal(normalizeSocial('facebook', 'facebook.com/page').url, 'https://facebook.com/page')
  assert.equal(normalizeSocial('facebook', '').url, '')
  assert.equal(normalizeDonation('cashapp', '$NewTag').url, 'https://cash.app/$NewTag')
  assert.equal(normalizeDonation('cashapp', 'NewTag').url, 'https://cash.app/$NewTag')
  assert.equal(normalizeDonation('paypal', 'ProjectDzidzor').url, 'https://www.paypal.com/paypalme/ProjectDzidzor')
  assert.equal(normalizeDonation('other', 'givebutter.com/dz').url, 'https://givebutter.com/dz')
})

check('unsafe or broken links are refused', () => {
  assert.ok(normalizeSocial('instagram', 'javascript:alert(1)').error)
  assert.ok(normalizeDonation('other', 'data:text/html,hi').error)
  assert.ok(normalizeDonation('other', '').error)
  const { errors } = sanitizeOrganization({ donations: [{ id: 'a', kind: 'other', label: '', url: 'javascript:x' }], social: { instagram: 'ftp://x.y' } })
  assert.ok(errors['donation.0'] && errors['social.instagram'])
})

check('saved values replace exactly the hard-wired links, nothing else', () => {
  const org = resolveOrganization({
    donations: [{ id: 'p', kind: 'paypal', label: 'PayPal', url: 'https://www.paypal.com/paypalme/NewDz' }, { id: 'c', kind: 'cashapp', label: 'Cash App', url: 'https://cash.app/$ProjectDzidzor' }],
    social: { instagram: 'https://www.instagram.com/new_handle', facebook: 'https://facebook.com/projectdzidzor', x: 'https://x.com/projectdzidzor' },
  })
  const links = siteLinks(org)
  const h = applySiteLinks(header, links)
  assert.notEqual(h, header)
  assert.equal(h[0].children![0].attrs.href, 'https://www.instagram.com/new_handle')
  assert.equal(h[0].children![1], header[0].children[1], 'unchanged blocks keep their identity')
  assert.equal(h[0].children![2].attrs.href, 'https://x.com/projectdzidzor')
  assert.equal(h[0].children![3].attrs.href, '/donate')
  assert.equal(header[0].children[0].attrs.href, 'https://www.instagram.com/project_dzidzor', 'never mutates')
  const p = applySiteLinks(home, links)
  assert.equal(p[0].attrs.href, 'https://www.paypal.com/paypalme/NewDz')
  assert.equal(p[1].attrs.href, 'https://www.youtube.com/watch?v=abc', 'a video link is not a profile link')
})

check('explicit bindings (data-link) follow the saved value', () => {
  const org = resolveOrganization({ donations: [{ id: 'x', kind: 'other', label: 'Givebutter', url: 'https://givebutter.com/dz' }], social: { tiktok: 'https://www.tiktok.com/@dz' } })
  const blocks = [{ attrs: { href: '#', 'data-link': 'social.tiktok' } }, { attrs: { href: '#', 'data-link': 'donate.0' } }, { attrs: { href: '#', 'data-link': 'social.youtube' } }]
  const out = applySiteLinks(blocks, siteLinks(org))
  assert.equal(out[0].attrs.href, 'https://www.tiktok.com/@dz')
  assert.equal(out[1].attrs.href, 'https://givebutter.com/dz')
  assert.equal(out[2].attrs.href, '#', 'nothing saved for YouTube → left alone')
})

check('link keys ignore scheme, www and trailing slash', () => {
  assert.equal(linkKey('https://www.Instagram.com/project_dzidzor/'), linkKey('http://instagram.com/project_dzidzor'))
})

console.log(`\n${n} checks passed`)
