/**
 * Run: npx -y tsx@4.23.15 src/lib/settings/ai-update.assert.ts
 */
import assert from 'node:assert/strict'
import { sanitizeAiSettingsUpdate } from './ai-update'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const full = {
  enabled: true,
  provider: 'openai',
  enabledModels: ['anthropic/claude-sonnet-4.5'],
  maxTokens: 4096,
  temperature: 0.7,
  rateLimits: { guest: 0, customer: 50, editor: 200, admin: 0, hacker: 9 },
  dailyTokenBudget: 250000,
  // Retired with the page builder's own chat (2026-11-16): an old screen may still send it; it is not saved.
  blockEditorChat: { enabled: true, maxTokensPerRequest: 4096, rateLimitPerHour: 30 },
  usageTracking: { enabled: true, retentionDays: 90 },
}

check('the daily token budget (and every field the screen edits) now saves', () => {
  const { patch, errors } = sanitizeAiSettingsUpdate(full)
  assert.deepEqual(errors, [])
  assert.equal(patch.dailyTokenBudget, 250000)
  assert.deepEqual(patch.rateLimits, { guest: 0, customer: 50, editor: 200, admin: 0 })
  assert.equal('blockEditorChat' in patch, false)
  assert.deepEqual(patch.usageTracking, full.usageTracking)
  assert.equal(patch.provider, 'gateway')
})

check('0 means no limit; bad values are refused with a plain reason, not saved', () => {
  assert.equal(sanitizeAiSettingsUpdate({ dailyTokenBudget: 0 }).patch.dailyTokenBudget, 0)
  for (const bad of [-1, 1.5, '500000', 60_000_000, null]) {
    const r = sanitizeAiSettingsUpdate({ dailyTokenBudget: bad })
    assert.equal(r.patch.dailyTokenBudget, undefined)
    assert.match(r.errors[0], /daily token budget/)
  }
})

check('fields left out stay unchanged; junk is never passed through', () => {
  const { patch } = sanitizeAiSettingsUpdate({ temperature: 1 })
  assert.deepEqual(Object.keys(patch).sort(), ['provider', 'temperature'])
  assert.equal(sanitizeAiSettingsUpdate({ enabledModels: ['<script>'] }).errors.length, 1)
  assert.equal(sanitizeAiSettingsUpdate({ enabledModels: [] }).errors.length, 1)
})

check('effort: low / medium / high / max only', () => {
  assert.equal(sanitizeAiSettingsUpdate({ effort: 'max' }).patch.effort, 'max')
  for (const bad of ['xhigh', 'MAX', 3, null]) {
    const r = sanitizeAiSettingsUpdate({ effort: bad })
    assert.equal(r.patch.effort, undefined)
    assert.match(r.errors[0], /Effort must be/)
  }
})

console.log(`\n${n} checks passed`)
