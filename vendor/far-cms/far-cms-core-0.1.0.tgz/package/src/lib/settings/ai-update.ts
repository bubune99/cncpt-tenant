/**
 * What an AI-settings save may change, validated. The PUT used to copy only
 * four fields, so the daily token budget (and rate limits, block-editor and
 * usage-tracking settings) silently never saved. Pure; asserted by
 * ai-update.assert.ts. Fields left out of the body are left unchanged.
 */

import { isEffort } from '../ai/effort'

const MODEL_ID = /^[a-z0-9-]+\/[a-z0-9.\-]+$/i
const ROLES = ['guest', 'customer', 'editor', 'admin'] as const

function int(v: unknown, min: number, max: number): number | null {
  return typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max ? v : null
}

export function sanitizeAiSettingsUpdate(body: unknown): { patch: Record<string, unknown>; errors: string[] } {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>
  const patch: Record<string, unknown> = { provider: 'gateway' }
  const errors: string[] = []
  const take = (key: string, value: unknown, ok: boolean, message: string) => {
    if (b[key] === undefined) return
    if (ok) patch[key] = value
    else errors.push(message)
  }

  take('enabled', b.enabled, typeof b.enabled === 'boolean', 'enabled must be true or false')
  const models = Array.isArray(b.enabledModels) ? b.enabledModels : null
  take(
    'enabledModels',
    models,
    !!models && models.length > 0 && models.length <= 20 && models.every((m) => typeof m === 'string' && MODEL_ID.test(m)),
    'enabledModels must list 1–20 model ids like "anthropic/claude-haiku-5.5"'
  )
  take('maxTokens', b.maxTokens, int(b.maxTokens, 256, 64_000) !== null, 'maxTokens must be a whole number from 256 to 64,000')
  take('temperature', b.temperature, typeof b.temperature === 'number' && b.temperature >= 0 && b.temperature <= 2, 'temperature must be between 0 and 2')
  take('dailyTokenBudget', b.dailyTokenBudget, int(b.dailyTokenBudget, 0, 50_000_000) !== null, 'The daily token budget must be a whole number from 0 (no limit) to 50,000,000')
  take('effort', b.effort, isEffort(b.effort), 'Effort must be low, medium, high or max')

  if (b.rateLimits !== undefined) {
    const r = (b.rateLimits && typeof b.rateLimits === 'object' ? b.rateLimits : null) as Record<string, unknown> | null
    const clean = r ? Object.fromEntries(ROLES.filter((k) => r[k] !== undefined).map((k) => [k, r[k]])) : null
    if (clean && Object.values(clean).every((v) => int(v, 0, 100_000) !== null)) patch.rateLimits = clean
    else errors.push('Rate limits must be whole numbers from 0 to 100,000 per role')
  }
  if (b.usageTracking !== undefined) {
    const u = (b.usageTracking ?? {}) as Record<string, unknown>
    if (typeof u.enabled === 'boolean' && int(u.retentionDays, 1, 3650) !== null) patch.usageTracking = { enabled: u.enabled, retentionDays: u.retentionDays }
    else errors.push('Usage tracking: enabled and a retention of 1–3,650 days are required')
  }
  return { patch, errors }
}
