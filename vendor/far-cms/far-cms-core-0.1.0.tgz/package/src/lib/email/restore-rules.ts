/**
 * When an email may go back to an earlier version (pure; asserted by
 * restore-rules.assert.ts). A campaign that went out — or is going out, or
 * is scheduled with checked content — stays as it was: only drafts restore.
 * Built-in templates never change.
 */

export function campaignRestoreBlock(status: string): string | null {
  switch (status) {
    case 'DRAFT':
      return null
    case 'SCHEDULED':
      return 'This campaign is scheduled. Unschedule it first, then go back to an earlier version.'
    case 'SENDING':
      return 'This campaign is sending right now, so it stays as it is.'
    case 'STOPPED':
      return 'Part of this campaign has already gone out, so it stays as it was sent.'
    case 'CANCELLED':
      return 'This campaign was cancelled. Only a draft can go back to an earlier version.'
    default: // SENT, FAILED, anything new
      return 'This campaign has been sent, so it stays as it was sent.'
  }
}

export function templateRestoreBlock(t: { isSystem: boolean }): string | null {
  return t.isSystem ? 'Built-in templates can’t be changed — start a campaign from it instead.' : null
}
