/**
 * Keyed email hashing for the suppression list — the same HMAC key family as
 * the IP hash (lib/ade/privacy/ip-hash: derived from ENCRYPTION_KEY, with
 * ENCRYPTION_KEY_PREVIOUS still matching after a rotation), under its own
 * label. The raw address is never stored. Pure; asserted by
 * suppression.assert.ts.
 *
 * Stored form: `e1.<keyId>.<32 hex>`.
 */

import { createHmac } from 'node:crypto'
import { deriveKey, type HashKey } from '../ade/privacy/ip-hash'
import { normalizeEmail } from './send-guard'

const LABEL = 'email-hash:v1'

export function emailKeys(env: { ENCRYPTION_KEY?: string; ENCRYPTION_KEY_PREVIOUS?: string; NODE_ENV?: string }): HashKey[] {
  const keys: HashKey[] = []
  if (env.ENCRYPTION_KEY) keys.push(deriveKey(env.ENCRYPTION_KEY, LABEL))
  else if (env.NODE_ENV !== 'production') keys.push(deriveKey('dev-only-email-hash-secret', LABEL))
  if (env.ENCRYPTION_KEY_PREVIOUS) keys.push(deriveKey(env.ENCRYPTION_KEY_PREVIOUS, LABEL))
  return keys
}

export function hashEmail(email: string, key: HashKey): string {
  return `e1.${key.id}.${createHmac('sha256', key.secret).update(normalizeEmail(email)).digest('hex').slice(0, 32)}`
}

/** Every hash this address could be stored under (current key first) — for lookups across a rotation. */
export function emailHashes(email: string, keys: readonly HashKey[]): string[] {
  return keys.map((k) => hashEmail(email, k))
}
