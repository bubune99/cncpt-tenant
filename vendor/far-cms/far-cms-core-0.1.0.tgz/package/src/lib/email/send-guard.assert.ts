/**
 * Run: npx -y tsx@4.23.15 src/lib/email/send-guard.assert.ts
 */
import assert from 'node:assert/strict'
import { allowListed, decide, MarketingFooterError, marketingRefusal, parseAllowList, unsubscribeHeaders, suppressionBlocks, providerSandbox, withFooter, withPlainText, type EmailCategory } from './send-guard'
import { emailHashes, emailKeys, hashEmail } from './email-hash'
import { htmlToPlainText } from './templates/renderer'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const PROD = { VERCEL_ENV: 'production', NODE_ENV: 'production' }
const PREVIEW = { VERCEL_ENV: 'preview', NODE_ENV: 'production' } // staging is a Vercel preview
const LOCAL = { NODE_ENV: 'development' }
const SELF_HOSTED_PROD = { NODE_ENV: 'production' }
const LIST = parseAllowList('owner@dzidzor.test, @e-creatives.test', 'qa@x.test')

check('the guard matrix: env × allow-list × category', () => {
  for (const category of ['marketing', 'transactional'] as EmailCategory[]) {
    for (const env of [PREVIEW, LOCAL]) {
      // outside production the live-send flag changes nothing
      assert.equal(decide({ env, to: ['real@person.com'], category, allowList: LIST, liveSend: true }), 'drop')
      // empty list outside production: drop everything
      assert.equal(decide({ env, to: ['owner@dzidzor.test'], category, allowList: [] }), 'drop')
      // on the list (exact, case-insensitive, or by @domain): send
      assert.equal(decide({ env, to: ['Owner@Dzidzor.test'], category, allowList: LIST }), 'send')
      assert.equal(decide({ env, to: ['anyone@e-creatives.test'], category, allowList: LIST }), 'send')
      assert.equal(decide({ env, to: ['qa@x.test'], category, allowList: LIST }), 'send')
      // a real person: drop
      assert.equal(decide({ env, to: ['real@person.com'], category, allowList: LIST }), 'drop')
      // one real person copied in drops the whole message
      assert.equal(decide({ env, to: ['owner@dzidzor.test', 'real@person.com'], category, allowList: LIST }), 'drop')
      // nobody to send to
      assert.equal(decide({ env, to: [], category, allowList: LIST }), 'drop')
    }
  }
})

check('production: transactional unchanged; marketing to real people only with EMAIL_LIVE_SEND (fail closed)', () => {
  for (const env of [PROD, SELF_HOSTED_PROD]) {
    // receipts / password / confirmation mail: as before, list or not, flag or not
    assert.equal(decide({ env, to: ['real@person.com'], category: 'transactional', allowList: [] }), 'send')
    assert.equal(decide({ env, to: ['real@person.com'], category: 'transactional', allowList: LIST }), 'send')
    // marketing without the flag: allow-list only
    assert.equal(decide({ env, to: ['real@person.com'], category: 'marketing', allowList: [] }), 'drop')
    assert.equal(decide({ env, to: ['real@person.com'], category: 'marketing', allowList: LIST }), 'drop')
    assert.equal(decide({ env, to: ['owner@dzidzor.test'], category: 'marketing', allowList: LIST }), 'send')
    assert.equal(decide({ env, to: ['owner@dzidzor.test', 'real@person.com'], category: 'marketing', allowList: LIST }), 'drop')
    // marketing with EMAIL_LIVE_SEND=true: real people
    assert.equal(decide({ env, to: ['real@person.com'], category: 'marketing', allowList: [], liveSend: true }), 'send')
    assert.equal(decide({ env, to: [], category: 'marketing', allowList: LIST, liveSend: true }), 'drop')
  }
})

check('allow-list parsing and matching', () => {
  assert.deepEqual(parseAllowList(' A@b.c ;d@e.f', null, undefined, '', 'a@b.c'), ['a@b.c', 'd@e.f'])
  assert.equal(allowListed('x@notallowed.test', ['@allowed.test']), false)
  assert.equal(allowListed('x@sub.allowed.test', ['@allowed.test']), false)
})

check('SendGrid sandbox everywhere but production', () => {
  assert.equal(providerSandbox(PROD), false)
  assert.equal(providerSandbox(PREVIEW), true)
  assert.equal(providerSandbox(LOCAL), true)
})

check('suppression: marketing to a suppressed address is refused; transactional still goes', () => {
  assert.equal(suppressionBlocks('marketing', true), true)
  assert.equal(suppressionBlocks('marketing', false), false)
  assert.equal(suppressionBlocks('transactional', true), false)
})

check('suppression hashes: keyed, normalised, never the address, matched across a key rotation', () => {
  const [key] = emailKeys({ ENCRYPTION_KEY: 'k-new' })
  const h = hashEmail(' Someone@Example.org ', key)
  assert.match(h, /^e1\.[0-9a-f]{6}\.[0-9a-f]{32}$/)
  assert.ok(!h.includes('someone'))
  assert.equal(h, hashEmail('someone@example.org', key))
  const old = hashEmail('someone@example.org', emailKeys({ ENCRYPTION_KEY: 'k-old' })[0])
  assert.ok(emailHashes('someone@example.org', emailKeys({ ENCRYPTION_KEY: 'k-new', ENCRYPTION_KEY_PREVIOUS: 'k-old' })).includes(old))
  // a different key family than the IP hash (same secret, different label)
  assert.notEqual(emailKeys({ ENCRYPTION_KEY: 'k' })[0].id, '')
  assert.deepEqual(emailKeys({ NODE_ENV: 'production' }), []) // no secret in production: nothing to hash with
})

const ADDRESS = 'Project Dzidzor\n123 Main St\nRaleigh, NC 27601'
const UNSUB = 'https://site.test/api/email/unsubscribe?t=abc'

check('the footer: always on marketing (address + unsubscribe), never on transactional', () => {
  const m = withFooter({ html: '<html><body><p>Hi</p></body></html>', text: 'Hi' }, 'marketing', { postalAddress: ADDRESS, unsubscribeUrl: UNSUB })
  assert.ok(m.html!.includes('data-email-footer'))
  assert.ok(m.html!.includes('123 Main St'))
  assert.ok(m.html!.includes(`href="${UNSUB}"`))
  assert.ok(m.html!.indexOf('data-email-footer') < m.html!.indexOf('</body>'))
  assert.ok(m.text!.includes('Raleigh, NC 27601') && m.text!.includes(`Unsubscribe: ${UNSUB}`))
  const t = withFooter({ html: '<p>Receipt</p>', text: 'Receipt' }, 'transactional', { postalAddress: ADDRESS, unsubscribeUrl: UNSUB })
  assert.deepEqual(t, { html: '<p>Receipt</p>', text: 'Receipt' })
  // escaped
  assert.ok(withFooter({ html: '' }, 'marketing', { postalAddress: '<b>x</b>', unsubscribeUrl: UNSUB }).html!.includes('&lt;b&gt;x'))
  // replacement patterns in the address ($& $' $\` $1) are text, not instructions
  const odd = withFooter({ html: '<html><body><p>Hi</p></body></html>' }, 'marketing', { postalAddress: "Suite $& and $' and $` $1", unsubscribeUrl: UNSUB }).html!
  assert.ok(odd.includes("Suite $&amp; and $' and $` $1"), odd)
  assert.equal(odd.split('</body>').length - 1, 1)
  assert.ok(odd.startsWith('<html><body><p>Hi</p>'))
})

check('no postal address or no unsubscribe link: the marketing send is refused, clearly', () => {
  assert.throws(() => withFooter({ html: '<p>Hi</p>' }, 'marketing', { postalAddress: '', unsubscribeUrl: UNSUB }), (e: unknown) => e instanceof MarketingFooterError && /postal address/.test((e as Error).message))
  assert.throws(() => withFooter({ html: '<p>Hi</p>' }, 'marketing', { postalAddress: ADDRESS, unsubscribeUrl: null }), MarketingFooterError)
})

check('marketing must be tied to a subscriber — a raw address is refused; transactional never is', () => {
  assert.match(marketingRefusal({ category: 'marketing', subscriberId: undefined, postalAddress: ADDRESS })!, /subscriber/)
  assert.match(marketingRefusal({ category: 'marketing', subscriberId: '  ', postalAddress: ADDRESS })!, /subscriber/)
  assert.match(marketingRefusal({ category: 'marketing', subscriberId: 'sub_1', postalAddress: '' })!, /postal address/)
  assert.equal(marketingRefusal({ category: 'marketing', subscriberId: 'sub_1', postalAddress: ADDRESS }), null)
  assert.equal(marketingRefusal({ category: 'transactional', subscriberId: undefined, postalAddress: '' }), null)
})

check('List-Unsubscribe carries the same URL as the footer link, with one-click POST', () => {
  const h = unsubscribeHeaders(UNSUB)
  assert.equal(h['List-Unsubscribe'], `<${UNSUB}>`)
  assert.equal(h['List-Unsubscribe-Post'], 'List-Unsubscribe=One-Click')
  const m = withFooter({ html: '<p>Hi</p>' }, 'marketing', { postalAddress: ADDRESS, unsubscribeUrl: UNSUB })
  assert.ok(m.html!.includes(`href="${UNSUB}"`) && h['List-Unsubscribe'].includes(UNSUB))
})

check('plain-text part: generated from the HTML when none is given; a given one is kept', () => {
  const out = withPlainText({ html: '<h1>Hello</h1><p>Read <a href="https://x.test">this</a></p>' }, htmlToPlainText)
  assert.ok(out.text && out.text.includes('Hello') && out.text.includes('this (https://x.test)'))
  assert.equal(withPlainText({ html: '<p>a</p>', text: 'mine' }, htmlToPlainText).text, 'mine')
  assert.equal(withPlainText({ html: '<p>a</p>', text: '  ' }, htmlToPlainText).text, 'a')
  assert.deepEqual(withPlainText({ text: 'only text' }, htmlToPlainText), { text: 'only text' })
  // marketing: the generated text carries the footer too
  const full = withPlainText(withFooter({ html: '<p>News</p>' }, 'marketing', { postalAddress: ADDRESS, unsubscribeUrl: UNSUB }), htmlToPlainText)
  assert.ok(full.text!.includes('123 Main St') && full.text!.includes('Unsubscribe'))
})

console.log(`\n${n} checks passed`)
