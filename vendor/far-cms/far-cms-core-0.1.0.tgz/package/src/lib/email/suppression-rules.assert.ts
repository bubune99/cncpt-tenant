/**
 * Run: npx -y tsx@4.23.15 src/lib/email/suppression-rules.assert.ts
 */
import assert from 'node:assert/strict'
import { suppressionForEvent } from './suppression-rules'
import { ipForStorage, deriveKey, isHashedIp } from '../ade/privacy/ip-hash'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const ev = (type: string, extra: Record<string, unknown> = {}) => ({ type, email: 'a@example.com', provider: 'sendgrid', ...extra }) as Parameters<typeof suppressionForEvent>[0]

check('hard bounces and complaints suppress, tagged with the provider', () => {
  assert.deepEqual(suppressionForEvent(ev('bounced', { bounceType: 'hard' })), { reason: 'bounced', source: 'webhook:sendgrid' })
  assert.deepEqual(suppressionForEvent(ev('bounced', { bounceType: 'blocked', provider: 'ses' })), { reason: 'bounced', source: 'webhook:ses' })
  assert.deepEqual(suppressionForEvent(ev('bounced')), { reason: 'bounced', source: 'webhook:sendgrid' })
  assert.deepEqual(suppressionForEvent(ev('complained', { provider: 'mailgun' })), { reason: 'complained', source: 'webhook:mailgun' })
  assert.deepEqual(suppressionForEvent(ev('unsubscribed', { provider: 'resend' })), { reason: 'unsubscribed', source: 'webhook:resend' })
})

check('soft bounces and ordinary events never suppress; no address, no entry', () => {
  assert.equal(suppressionForEvent(ev('bounced', { bounceType: 'soft' })), null)
  for (const t of ['soft_bounced', 'delivered', 'opened', 'clicked', 'dropped', 'deferred']) assert.equal(suppressionForEvent(ev(t)), null, t)
  assert.equal(suppressionForEvent(ev('complained', { email: '  ' })), null)
})

check('a form submission IP (already hashed, or legacy raw) is stored only as a hash', () => {
  const key = deriveKey('test-master', 'ip:v1')
  const hashed = ipForStorage('203.0.113.9', key)!
  assert.ok(isHashedIp(hashed))
  assert.equal(ipForStorage(hashed, key), hashed)
  assert.equal(ipForStorage('203.0.113.9', key), hashed)
  assert.equal(ipForStorage(null, key), null)
})

console.log(`\n${n} checks passed`)
