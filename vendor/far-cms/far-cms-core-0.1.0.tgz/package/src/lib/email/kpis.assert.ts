/**
 * Run: npx -y tsx@4.23.15 src/lib/email/kpis.assert.ts
 */
import assert from 'node:assert/strict'
import { emailKpis } from './kpis'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const by = (k: ReturnType<typeof emailKpis>, key: string) => k.find((x) => x.key === key)!

check('nothing sent → rates are "—", not 0%; real zero counts stay 0', () => {
  const k = emailKpis({ totalCampaigns: 0, totalSent: 0, avgOpenRate: 0, avgClickRate: 0, subscribers: 0 })
  assert.equal(by(k, 'rates').value, '—')
  assert.equal(by(k, 'rates').hint, 'Not tracked yet — nothing sent')
  assert.equal(by(k, 'sent').value, '0')
  assert.equal(by(k, 'subscribers').value, '0')
})

check('sent → real rates; null rate from the API → "—"', () => {
  assert.equal(by(emailKpis({ totalSent: 1200, avgOpenRate: 41.5, avgClickRate: 7.2 }), 'rates').value, '41.5% / 7.2%')
  assert.equal(by(emailKpis({ totalSent: 1200, avgOpenRate: null, avgClickRate: null }), 'rates').value, '—')
  assert.equal(by(emailKpis({ totalCampaigns: 1234 }), 'campaigns').value, '1,234')
})

check('API unreadable → every cell "—" with a reason, never invented numbers', () => {
  const k = emailKpis(null)
  assert.ok(k.every((c) => c.value === '—'))
  assert.equal(by(k, 'subscribers').hint, 'Not available')
})

console.log(`\n${n} checks passed`)
