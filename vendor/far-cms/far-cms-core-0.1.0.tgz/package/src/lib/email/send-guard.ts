/**
 * Who may be emailed, decided before anything reaches a provider — pure,
 * asserted by send-guard.assert.ts. The one send path (lib/email/core.ts)
 * asks these for every message, so nothing bypasses them.
 *
 * - Outside production (staging, previews, local) mail goes ONLY to the test
 *   allow-list (EMAIL_TEST_ALLOWLIST, comma-separated, plus the optional
 *   email setting `testAllowList`). Anyone else: dropped and logged with the
 *   address hashed. An empty list outside production drops everything.
 *   Production is unchanged.
 * - Marketing mail never goes to a suppressed address (unsubscribed,
 *   bounced, complained, manual), and always carries the footer: the
 *   organisation's postal address + an unsubscribe link. No address on
 *   file → the marketing send is refused with a clear error.
 * - Every message has a plain-text part.
 */

import { isProductionEnv } from '../forms/spam'

export type EmailCategory = 'marketing' | 'transactional'
export type SendDecision = 'send' | 'drop'

export interface GuardEnv {
  NODE_ENV?: string
  VERCEL_ENV?: string
}

/** One spelling per address. */
export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase()
}

/** "a@x.org, @team.org ,b@y.org" → entries; "@domain" allows a whole domain. */
export function parseAllowList(...sources: Array<string | null | undefined>): string[] {
  const out = new Set<string>()
  for (const s of sources) for (const part of (s ?? '').split(/[,;\s]+/)) if (part.trim()) out.add(normalizeEmail(part))
  return [...out]
}

export function allowListed(email: string, allowList: readonly string[]): boolean {
  const e = normalizeEmail(email)
  const domain = e.slice(e.lastIndexOf('@'))
  return allowList.includes(e) || (domain.length > 1 && allowList.includes(domain))
}

/**
 * Send or drop one message. `to` is every recipient (to + cc + bcc): outside
 * production one address off the list drops the whole message, so nobody
 * real is ever copied in.
 */
export function decide({
  env,
  to,
  category,
  allowList,
  liveSend = false,
}: {
  env: GuardEnv
  to: readonly string[]
  category: EmailCategory
  allowList: readonly string[]
  /**
   * EMAIL_LIVE_SEND=true — the explicit "marketing may reach real people"
   * switch. Production detection alone could fail open (a mislabelled
   * environment), so production marketing needs this too.
   */
  liveSend?: boolean
}): SendDecision {
  if (to.length === 0) return 'drop'
  const onList = allowList.length > 0 && to.every((t) => allowListed(t, allowList))
  if (!isProductionEnv(env)) return onList ? 'send' : 'drop'
  // Production: receipts, password and confirmation mail as before.
  if (category === 'transactional') return 'send'
  return liveSend || onList ? 'send' : 'drop'
}

/** SendGrid's sandbox (accepts, never delivers) everywhere but production. */
export function providerSandbox(env: GuardEnv): boolean {
  return !isProductionEnv(env)
}

/** Marketing never reaches a suppressed address; transactional mail (receipts, password links) still does. */
export function suppressionBlocks(category: EmailCategory, suppressed: boolean): boolean {
  return category === 'marketing' && suppressed
}

/**
 * Why a marketing send can't go, before anything is rendered — null when it
 * can. Marketing must be tied to a subscriber (the unsubscribe link is
 * signed for one) and the organisation must have a postal address.
 */
export function marketingRefusal(m: { category: EmailCategory; subscriberId?: string | null; postalAddress?: string | null }): string | null {
  if (m.category !== 'marketing') return null
  if (!m.subscriberId?.trim()) return 'Marketing email must go to a subscriber (it needs their own unsubscribe link); a plain address can only get transactional mail.'
  if (!m.postalAddress?.trim()) return 'Marketing email needs the organization’s postal address (Settings › Contact details › Address).'
  return null
}

/**
 * RFC 2369 / 8058 headers for marketing — the SAME signed URL as the
 * footer link; one-click POST unsubscribes.
 */
export function unsubscribeHeaders(url: string): Record<string, string> {
  return { 'List-Unsubscribe': `<${url}>`, 'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click' }
}

export class MarketingFooterError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'MarketingFooterError'
  }
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

/**
 * The body as sent. Marketing gets the footer (postal address +
 * unsubscribe link) — it throws when either is missing; transactional mail
 * is returned untouched (never a footer).
 */
/** Per-recipient placeholders in an editor-built footer (lib/email/editor/render.tsx). */
export const FOOTER_TOKENS = { unsubscribe: '%%UNSUBSCRIBE_URL%%', preferences: '%%PREFERENCES_URL%%', view: '%%VIEW_URL%%' } as const
/** The email editor's own footer (org, address, Unsubscribe · Update preferences · View in browser). */
export const EDITOR_FOOTER_MARK = 'data-email-footer="editor"'

export function hasEditorFooter(html: string | undefined): boolean {
  return !!html && html.includes(EDITOR_FOOTER_MARK)
}

/** Fill an editor footer's tokens for one recipient (html and text). */
export function fillFooterTokens(s: string, urls: { unsubscribe: string; preferences: string; view: string }): string {
  return s.split(FOOTER_TOKENS.unsubscribe).join(urls.unsubscribe).split(FOOTER_TOKENS.preferences).join(urls.preferences).split(FOOTER_TOKENS.view).join(urls.view)
}

export function withFooter(
  body: { html?: string; text?: string },
  category: EmailCategory,
  footer: { postalAddress?: string | null; unsubscribeUrl?: string | null; preferencesUrl?: string | null; viewUrl?: string | null }
): { html?: string; text?: string } {
  if (category !== 'marketing') {
    // A staff test of an editor email (sent as transactional): its footer links go nowhere, never "%%…%%".
    if (!hasEditorFooter(body.html)) return body
    const none = { unsubscribe: '#', preferences: '#', view: '#' }
    return { html: fillFooterTokens(body.html!, none), text: body.text === undefined ? undefined : fillFooterTokens(body.text, none) }
  }
  // An email built in the editor carries its own footer: fill it, never add a second one.
  if (hasEditorFooter(body.html)) {
    const unsubUrl = (footer.unsubscribeUrl ?? '').trim()
    if (!(footer.postalAddress ?? '').trim()) throw new MarketingFooterError('Marketing email needs the organization’s postal address (Settings › Contact details › Address).')
    if (!unsubUrl) throw new MarketingFooterError('Marketing email needs an unsubscribe link (no subscriber for this recipient).')
    const urls = { unsubscribe: unsubUrl, preferences: (footer.preferencesUrl ?? '').trim() || unsubUrl, view: (footer.viewUrl ?? '').trim() || unsubUrl }
    const attr = (u: string) => u.replace(/&/g, '&amp;').replace(/"/g, '&quot;')
    return {
      html: fillFooterTokens(body.html!, { unsubscribe: attr(urls.unsubscribe), preferences: attr(urls.preferences), view: attr(urls.view) }),
      text: body.text === undefined ? undefined : fillFooterTokens(body.text, urls),
    }
  }
  const address = (footer.postalAddress ?? '').trim()
  const unsub = (footer.unsubscribeUrl ?? '').trim()
  if (!address) throw new MarketingFooterError('Marketing email needs the organization’s postal address (Settings › Contact details › Address).')
  if (!unsub) throw new MarketingFooterError('Marketing email needs an unsubscribe link (no subscriber for this recipient).')
  const lines = address.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
  const unsubHtml = `<a href="${esc(unsub)}" style="color:#666">Unsubscribe</a>`
  const htmlFooter =
    `<div data-email-footer style="margin-top:32px;padding-top:16px;border-top:1px solid #e5e5e5;font:12px/1.5 Arial,sans-serif;color:#666">` +
    `<p style="margin:0 0 8px">${lines.map(esc).join('<br>')}</p>` +
    `<p style="margin:0">${unsubHtml}</p></div>`
  const textFooter = `\n\n--\n${lines.join('\n')}\nUnsubscribe: ${unsub}`
  const html = body.html === undefined ? undefined : /<\/body>/i.test(body.html) ? body.html.replace(/<\/body>/i, () => `${htmlFooter}</body>`) : body.html + htmlFooter
  const text = body.text === undefined ? undefined : body.text + textFooter
  return { html, text }
}

/** Every message has a plain-text part: the given one, else derived from the HTML. */
export function withPlainText(body: { html?: string; text?: string }, htmlToText: (html: string) => string): { html?: string; text?: string } {
  if (body.text?.trim() || !body.html) return body
  return { ...body, text: htmlToText(body.html) }
}
