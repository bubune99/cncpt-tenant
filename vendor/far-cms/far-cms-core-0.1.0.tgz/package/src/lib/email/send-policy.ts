/**
 * What the general send API (/api/email/send) and the test sends may do —
 * pure, asserted by send-policy.assert.ts (audit run-2, R2-3).
 *
 * - Category: MARKETING unless it is one of the named system emails
 *   (receipts, shipping, password…) sent as rendered, to its own
 *   recipients. Anything with custom HTML/text, a bulk list or a campaign is
 *   marketing — so the send guard applies EMAIL_LIVE_SEND, suppression and
 *   the footer (lib/email/send-guard), exactly as for campaigns.
 * - From: the caller's From is dropped unless it is the site's own sender or
 *   on EMAIL_FROM_ALLOWLIST; the default sender is used instead.
 * - Test sends go only to the signed-in person's own address or the test
 *   allow-list.
 */

import { allowListed, normalizeEmail } from './send-guard'

/** System emails that may go as transactional (rendered by their own templates). */
export const SYSTEM_TEMPLATES: ReadonlySet<string> = new Set([
  'order-confirmation',
  'shipping-notification',
  'delivery-confirmation',
  'refund-notification',
  'welcome',
  'password-reset',
  'password-changed',
])

export interface SendRequestShape {
  category?: unknown
  template?: unknown
  html?: unknown
  text?: unknown
  campaignId?: unknown
  bulk?: unknown
  recipients?: unknown
}

export function sendCategory(b: SendRequestShape): 'marketing' | 'transactional' {
  const system = typeof b.template === 'string' && SYSTEM_TEMPLATES.has(b.template)
  const custom = (typeof b.html === 'string' && b.html.trim() !== '') || (typeof b.text === 'string' && b.text.trim() !== '')
  const many = b.bulk === true || (Array.isArray(b.recipients) && b.recipients.length > 0)
  if (system && !custom && !many && !b.campaignId && b.category !== 'marketing') return 'transactional'
  return 'marketing'
}

/** The caller's From, only when it is the site's own sender or allow-listed; otherwise null (use the default). */
export function allowedFrom(fromEmail: string | null | undefined, ctx: { siteFrom?: string | null; allowList: readonly string[] }): string | null {
  if (!fromEmail) return null
  const e = normalizeEmail(fromEmail)
  if (ctx.siteFrom && e === normalizeEmail(ctx.siteFrom)) return e
  return ctx.allowList.length && allowListed(e, ctx.allowList) ? e : null
}

/** A test goes to your own address or the test allow-list — nobody else. */
export function testRecipients(to: readonly string[], ctx: { selfEmail: string | null | undefined; allowList: readonly string[] }): { ok: string[]; refused: string[] } {
  const self = ctx.selfEmail ? normalizeEmail(ctx.selfEmail) : null
  const ok: string[] = []
  const refused: string[] = []
  for (const raw of to) {
    const e = normalizeEmail(raw)
    if (e === self || (ctx.allowList.length && allowListed(e, ctx.allowList))) ok.push(e)
    else refused.push(e)
  }
  return { ok, refused }
}
