/**
 * Email provider webhook signatures — REQUIRED (an unsigned or unverifiable
 * request is rejected; a forged "complaint" must never suppress a real
 * subscriber). Pure (keys/certs passed in); asserted by
 * webhook-verify.assert.ts with fixtures.
 *
 *   Resend    — Svix: HMAC-SHA256 over "id.timestamp.body" with the
 *               base64 secret after "whsec_"; "v1,<sig>" list; 5-min window.
 *   SES (SNS) — RSA signature over the canonical SNS string (v1 SHA1, v2
 *               SHA256) with the cert from SigningCertURL, which must be
 *               https://sns.<region>.amazonaws.com/….pem; TopicArn must be on
 *               the allow-list.
 *   SendGrid  — ECDSA over "timestamp + body" with the verification key.
 *   Mailgun   — HMAC-SHA256 over "timestamp + token", 5-min window.
 */

import { createHmac, createVerify, timingSafeEqual } from 'node:crypto'

const WINDOW_S = 5 * 60

function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a)
  const y = Buffer.from(b)
  return x.length === y.length && timingSafeEqual(x, y)
}

function fresh(timestamp: number, now: number): boolean {
  return Number.isFinite(timestamp) && Math.abs(now - timestamp) <= WINDOW_S
}

// ── Resend (Svix) ──────────────────────────────────────────────────────

export function verifySvix(input: { secret: string; id: string | null; timestamp: string | null; signature: string | null; body: string; now: number }): boolean {
  const { secret, id, timestamp, signature, body, now } = input
  if (!secret || !id || !timestamp || !signature) return false
  if (!fresh(Number(timestamp), now)) return false
  const key = Buffer.from(secret.startsWith('whsec_') ? secret.slice(6) : secret, 'base64')
  if (!key.length) return false
  const expected = createHmac('sha256', key).update(`${id}.${timestamp}.${body}`).digest('base64')
  return signature
    .split(' ')
    .map((part) => part.split(','))
    .some(([version, sig]) => version === 'v1' && !!sig && safeEqual(sig, expected))
}

// ── SES via SNS ────────────────────────────────────────────────────────

const SNS_HOST = /^sns\.[a-z0-9-]+\.amazonaws\.com(\.cn)?$/

/** A URL SNS may send us to (cert download, subscription confirm). */
export function isSnsUrl(raw: unknown, kind: 'cert' | 'subscribe'): boolean {
  if (typeof raw !== 'string') return false
  try {
    const u = new URL(raw)
    if (u.protocol !== 'https:' || u.username || u.password || u.port) return false
    if (!SNS_HOST.test(u.hostname)) return false
    return kind === 'cert' ? u.pathname.endsWith('.pem') : true
  } catch {
    return false
  }
}

export interface SnsMessage {
  Type: string
  MessageId: string
  TopicArn: string
  Message: string
  Timestamp: string
  Signature: string
  SignatureVersion: string
  SigningCertURL: string
  Subject?: string
  Token?: string
  SubscribeURL?: string
}

/** The canonical string SNS signs. */
export function snsStringToSign(m: SnsMessage): string | null {
  const keys =
    m.Type === 'Notification'
      ? ['Message', 'MessageId', ...(m.Subject !== undefined ? ['Subject'] : []), 'Timestamp', 'TopicArn', 'Type']
      : m.Type === 'SubscriptionConfirmation' || m.Type === 'UnsubscribeConfirmation'
        ? ['Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type']
        : null
  if (!keys) return null
  let out = ''
  for (const k of keys) {
    const v = (m as unknown as Record<string, unknown>)[k]
    if (typeof v !== 'string') return null
    out += `${k}\n${v}\n`
  }
  return out
}

export function topicAllowed(topicArn: string, allowList: ReadonlyArray<string>): boolean {
  return allowList.length > 0 && allowList.includes(topicArn)
}

/** Verify an SNS message with the PEM certificate (or public key) fetched from its SigningCertURL. */
export function verifySnsSignature(m: SnsMessage, certPem: string): boolean {
  const text = snsStringToSign(m)
  if (!text || !certPem || typeof m.Signature !== 'string') return false
  const algo = m.SignatureVersion === '2' ? 'RSA-SHA256' : m.SignatureVersion === '1' ? 'RSA-SHA1' : null
  if (!algo) return false
  try {
    return createVerify(algo).update(text, 'utf8').verify(certPem, m.Signature, 'base64')
  } catch {
    return false
  }
}

// ── SendGrid ───────────────────────────────────────────────────────────

/** SendGrid shows the key as bare base64; wrap it as PEM. */
export function sendGridKeyPem(key: string): string {
  if (key.includes('BEGIN PUBLIC KEY')) return key
  const body = key.replace(/\s+/g, '').match(/.{1,64}/g)?.join('\n') ?? ''
  return `-----BEGIN PUBLIC KEY-----\n${body}\n-----END PUBLIC KEY-----\n`
}

export function verifySendGrid(input: { key: string; signature: string | null; timestamp: string | null; body: string; now: number }): boolean {
  const { key, signature, timestamp, body, now } = input
  if (!key || !signature || !timestamp || !fresh(Number(timestamp), now)) return false
  try {
    return createVerify('sha256').update(timestamp + body).verify(sendGridKeyPem(key), signature, 'base64')
  } catch {
    return false
  }
}

// ── Mailgun ────────────────────────────────────────────────────────────

export function verifyMailgun(input: { key: string; timestamp: unknown; token: unknown; signature: unknown; now: number }): boolean {
  const { key, timestamp, token, signature, now } = input
  if (!key || typeof timestamp !== 'string' || typeof token !== 'string' || typeof signature !== 'string') return false
  if (!fresh(Number(timestamp), now)) return false
  const expected = createHmac('sha256', key).update(timestamp + token).digest('hex')
  return safeEqual(signature, expected)
}
