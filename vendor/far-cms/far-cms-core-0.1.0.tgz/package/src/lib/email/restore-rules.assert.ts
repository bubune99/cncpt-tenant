/**
 * Run: npx -y tsx@4.23.15 src/lib/email/restore-rules.assert.ts
 */
import assert from 'node:assert/strict'
import { campaignRestoreBlock, templateRestoreBlock } from './restore-rules'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('only a draft campaign can go back to an earlier version', () => {
  assert.equal(campaignRestoreBlock('DRAFT'), null)
  for (const s of ['SCHEDULED', 'SENDING', 'SENT', 'STOPPED', 'FAILED', 'CANCELLED', 'SOMETHING_NEW']) assert.ok(campaignRestoreBlock(s), s)
})

check('each refusal says why in words', () => {
  assert.match(campaignRestoreBlock('SCHEDULED')!, /Unschedule it first/)
  assert.match(campaignRestoreBlock('SENDING')!, /sending right now/)
  assert.match(campaignRestoreBlock('STOPPED')!, /already gone out/)
  assert.match(campaignRestoreBlock('SENT')!, /stays as it was sent/)
})

check('built-in templates never change; others can', () => {
  assert.ok(templateRestoreBlock({ isSystem: true }))
  assert.equal(templateRestoreBlock({ isSystem: false }), null)
})

console.log(`\n${n} checks passed`)
