/**
 * What a click on a RECORDED campaign link writes. The email carries the link's public trackingId (`l`); the click tables key
 * on the EmailLink ROW id and the campaign, so both come from the looked-up row, never from the request. (Passing the
 * trackingId through as the row id made the click insert fail quietly: the redirect worked but nothing was counted.)
 * Pure; asserted by click-meta.assert.ts.
 */

export function recordedClickMeta(link: { id: string; campaignId: string | null }, requestCampaignId: string | null | undefined): { linkId: string; campaignId?: string } {
  const campaignId = link.campaignId ?? (requestCampaignId || undefined)
  return { linkId: link.id, ...(campaignId ? { campaignId } : {}) }
}
