/** Run: npx -y tsx@4.23.15 src/lib/email/campaign/click-meta.assert.ts */
import assert from 'node:assert/strict'
import { recordedClickMeta } from './click-meta'

assert.deepEqual(recordedClickMeta({ id: 'row1', campaignId: 'camp1' }, null), { linkId: 'row1', campaignId: 'camp1' })
assert.deepEqual(recordedClickMeta({ id: 'row1', campaignId: 'camp1' }, 'forged'), { linkId: 'row1', campaignId: 'camp1' }, 'the row wins over the request')
assert.deepEqual(recordedClickMeta({ id: 'row1', campaignId: null }, 'camp9'), { linkId: 'row1', campaignId: 'camp9' })
assert.deepEqual(recordedClickMeta({ id: 'row1', campaignId: null }, undefined), { linkId: 'row1' })
console.log('4 checks passed')
