/** Why an address is suppressed. Moved from Dzidzor's src/lib/email/suppression.ts (database code, stays in the app; it re-exports this). */
export type SuppressionReason = 'unsubscribed' | 'bounced' | 'complained' | 'manual'
