/**
 * Run: npx -y tsx@4.23.15 src/lib/email/email-s0.assert.ts
 * Consent state machine, click redirect rule, webhook verification (fixtures).
 */
import assert from 'node:assert/strict'
import { createHmac, createSign, generateKeyPairSync } from 'node:crypto'
import { PUBLIC_SUBSCRIBE_MESSAGE, RESEND_GAP_MS, confirmAction, subscribeAction } from './consent'
import { clickRedirectTarget } from './redirect'
import { isSnsUrl, snsStringToSign, topicAllowed, verifyMailgun, verifySendGrid, verifySnsSignature, verifySvix, type SnsMessage } from './webhook-verify'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const NOW = 1_790_000_000

check('consent: public is always double opt-in; nobody reactivates an unsubscribe without confirming', () => {
  const now = NOW * 1000
  assert.deepEqual(subscribeAction({ existing: null, channel: 'public', adminSkipConfirm: true, now }), { kind: 'create', status: 'PENDING', sendConfirm: true })
  assert.deepEqual(subscribeAction({ existing: null, channel: 'admin', adminSkipConfirm: true, now }), { kind: 'create', status: 'ACTIVE', sendConfirm: false })
  for (const channel of ['public', 'admin'] as const) {
    for (const st of ['UNSUBSCRIBED', 'CLEANED'] as const) assert.deepEqual(subscribeAction({ existing: st, channel, adminSkipConfirm: true, now }), { kind: 'set-pending', sendConfirm: true })
    assert.equal(subscribeAction({ existing: 'COMPLAINED', channel, now }).kind, 'refuse')
    assert.equal(subscribeAction({ existing: 'BOUNCED', channel, now }).kind, 'refuse')
  }
  assert.equal(subscribeAction({ existing: 'ACTIVE', channel: 'public', now }).kind, 'already-active')
  assert.ok(!/already|unsubscrib|bounc|complain/i.test(PUBLIC_SUBSCRIBE_MESSAGE))
})

check('consent: a PENDING address is re-sent its confirmation (at most every 10 min); only PENDING confirms', () => {
  const now = NOW * 1000
  assert.equal(subscribeAction({ existing: 'PENDING', channel: 'public', lastConfirmSentAt: now - RESEND_GAP_MS - 1, now }).kind, 'resend-confirm')
  assert.equal(subscribeAction({ existing: 'PENDING', channel: 'public', lastConfirmSentAt: now - 1000, now }).kind, 'wait')
  assert.equal(subscribeAction({ existing: 'PENDING', channel: 'public', lastConfirmSentAt: null, now }).kind, 'resend-confirm')
  assert.equal(confirmAction('PENDING'), 'activate')
  assert.equal(confirmAction('ACTIVE'), 'already-active')
  for (const st of ['UNSUBSCRIBED', 'COMPLAINED', 'BOUNCED', null] as const) assert.equal(confirmAction(st), 'invalid')
})

check('click redirect: only links recorded for the campaign; anything else → home', () => {
  const home = 'https://example.org/'
  const allowed = ['https://example.org/give?utm=1', 'https://partner.example/news']
  assert.equal(clickRedirectTarget({ requested: 'https://partner.example/news', allowed, home }), 'https://partner.example/news')
  assert.equal(clickRedirectTarget({ requested: 'https://evil.example/phish', allowed, home }), home)
  assert.equal(clickRedirectTarget({ requested: 'javascript:alert(1)', allowed: ['javascript:alert(1)'], home }), home)
  assert.equal(clickRedirectTarget({ requested: 'https://user:pw@partner.example/news', allowed, home }), home)
  assert.equal(clickRedirectTarget({ requested: null, allowed, home }), home)
  assert.equal(clickRedirectTarget({ requested: 'https://partner.example/news', allowed: [], home }), home)
})

check('Resend (Svix): valid signature passes; missing/stale/forged fail', () => {
  const key = Buffer.from('a-very-secret-key-for-tests')
  const secret = `whsec_${key.toString('base64')}`
  const body = '{"type":"email.complained","data":{"to":["a@example.com"]}}'
  const id = 'msg_123'
  const ts = String(NOW)
  const sig = createHmac('sha256', key).update(`${id}.${ts}.${body}`).digest('base64')
  const base = { secret, id, timestamp: ts, signature: `v1,${sig}`, body, now: NOW }
  assert.equal(verifySvix(base), true)
  assert.equal(verifySvix({ ...base, signature: `v1,wrong v1,${sig}` }), true)
  assert.equal(verifySvix({ ...base, signature: null }), false)
  assert.equal(verifySvix({ ...base, secret: '' }), false)
  assert.equal(verifySvix({ ...base, now: NOW + 600 }), false)
  assert.equal(verifySvix({ ...base, body: body.replace('complained', 'delivered') }), false)
})

check('SES (SNS): signed message verifies with the cert; tampered/unsigned/wrong topic/odd URLs fail', () => {
  const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 })
  const pub = publicKey.export({ type: 'spki', format: 'pem' }).toString()
  const m: SnsMessage = {
    Type: 'Notification', MessageId: 'm1', TopicArn: 'arn:aws:sns:us-east-1:123:ses', Message: '{"notificationType":"Complaint"}',
    Timestamp: '2026-10-10T00:00:00.000Z', Signature: '', SignatureVersion: '2', SigningCertURL: 'https://sns.us-east-1.amazonaws.com/cert.pem',
  }
  m.Signature = createSign('RSA-SHA256').update(snsStringToSign(m)!).sign(privateKey, 'base64')
  assert.equal(verifySnsSignature(m, pub), true)
  assert.equal(verifySnsSignature({ ...m, Message: '{"notificationType":"Bounce"}' }, pub), false)
  assert.equal(verifySnsSignature({ ...m, Signature: '' }, pub), false)
  assert.equal(verifySnsSignature({ ...m, SignatureVersion: '3' }, pub), false)
  assert.equal(topicAllowed(m.TopicArn, ['arn:aws:sns:us-east-1:123:ses']), true)
  assert.equal(topicAllowed(m.TopicArn, []), false)
  assert.equal(isSnsUrl('https://sns.us-east-1.amazonaws.com/SimpleNotificationService-abc.pem', 'cert'), true)
  for (const bad of ['http://sns.us-east-1.amazonaws.com/x.pem', 'https://evil.example/x.pem', 'https://sns.us-east-1.amazonaws.com.evil.example/x.pem', 'https://169.254.169.254/latest/meta-data', 'https://sns.us-east-1.amazonaws.com:8443/x.pem']) {
    assert.equal(isSnsUrl(bad, 'cert'), false, bad)
  }
  assert.equal(isSnsUrl('https://sns.eu-west-2.amazonaws.com/?Action=ConfirmSubscription&Token=x', 'subscribe'), true)
  assert.equal(isSnsUrl('https://attacker.example/?Action=ConfirmSubscription', 'subscribe'), false)
})

check('SendGrid and Mailgun: valid passes; missing key/signature, stale or forged fail', () => {
  const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' })
  const der = publicKey.export({ type: 'spki', format: 'der' }).toString('base64')
  const body = '[{"event":"spamreport","email":"a@example.com"}]'
  const ts = String(NOW)
  const sig = createSign('sha256').update(ts + body).sign(privateKey, 'base64')
  const sg = { key: der, signature: sig, timestamp: ts, body, now: NOW }
  assert.equal(verifySendGrid(sg), true)
  assert.equal(verifySendGrid({ ...sg, key: '' }), false)
  assert.equal(verifySendGrid({ ...sg, signature: null }), false)
  assert.equal(verifySendGrid({ ...sg, body: '[]' }), false)
  assert.equal(verifySendGrid({ ...sg, now: NOW + 600 }), false)
  const key = 'mailgun-signing-key'
  const token = 'tok123'
  const mg = { key, timestamp: ts, token, signature: createHmac('sha256', key).update(ts + token).digest('hex'), now: NOW }
  assert.equal(verifyMailgun(mg), true)
  assert.equal(verifyMailgun({ ...mg, signature: 'short' }), false)
  assert.equal(verifyMailgun({ ...mg, key: '' }), false)
  assert.equal(verifyMailgun({ ...mg, now: NOW + 600 }), false)
})

console.log(`\n${n} checks passed`)
