/**
 * Which provider webhook events put an address on the suppression list
 * (pure; suppression.ts does the write). Hard bounces and complaints always
 * do; a soft bounce is temporary and never does; a provider-side
 * unsubscribe does too.
 */

import type { EmailWebhookEvent } from './types'
import type { SuppressionReason } from './suppression-types'

export function suppressionForEvent(
  event: Pick<EmailWebhookEvent, 'type' | 'bounceType' | 'provider' | 'email'>,
): { reason: SuppressionReason; source: string } | null {
  if (!event.email || !String(event.email).trim()) return null
  const source = `webhook:${event.provider}`
  switch (event.type) {
    case 'bounced':
      return event.bounceType === 'soft' ? null : { reason: 'bounced', source }
    case 'complained':
      return { reason: 'complained', source }
    case 'unsubscribed':
      return { reason: 'unsubscribed', source }
    default:
      return null
  }
}
