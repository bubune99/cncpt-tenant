/**
 * The newsletter consent state machine — what a subscribe request may do to
 * an address, by who is asking. Pure; asserted by consent.assert.ts.
 *
 * Rules (owner/legal):
 *   - Public signups (site forms, the newsletter block, form automations)
 *     are ALWAYS double opt-in; the caller can't switch that off.
 *   - Nobody — public or admin — moves UNSUBSCRIBED/CLEANED back to ACTIVE
 *     without the person confirming again by email.
 *   - BOUNCED / COMPLAINED are never re-subscribed by a request.
 *   - A PENDING address that subscribes again gets the confirmation resent
 *     (at most once per RESEND_GAP), never an error.
 *   - The public response never reveals which state an address is in.
 */

export type SubscriberStatus = 'PENDING' | 'ACTIVE' | 'UNSUBSCRIBED' | 'CLEANED' | 'BOUNCED' | 'COMPLAINED'
export type SubscribeChannel = 'public' | 'admin'

export type SubscribeAction =
  | { kind: 'create'; status: 'PENDING' | 'ACTIVE'; sendConfirm: boolean }
  | { kind: 'set-pending'; sendConfirm: true }
  | { kind: 'resend-confirm' }
  | { kind: 'wait' }
  | { kind: 'already-active' }
  | { kind: 'refuse'; reason: 'bounced' | 'complained' }

/** Don't resend a confirmation more often than this. */
export const RESEND_GAP_MS = 10 * 60_000

export function subscribeAction(input: {
  existing: SubscriberStatus | null
  channel: SubscribeChannel
  /** Admin-only: add without the confirmation email (new addresses only). */
  adminSkipConfirm?: boolean
  /** When the last confirmation went out (PENDING), if known. */
  lastConfirmSentAt?: number | null
  now: number
}): SubscribeAction {
  const { existing, channel, now } = input
  switch (existing) {
    case null:
      return channel === 'admin' && input.adminSkipConfirm ? { kind: 'create', status: 'ACTIVE', sendConfirm: false } : { kind: 'create', status: 'PENDING', sendConfirm: true }
    case 'ACTIVE':
      return { kind: 'already-active' }
    case 'PENDING':
      return input.lastConfirmSentAt && now - input.lastConfirmSentAt < RESEND_GAP_MS ? { kind: 'wait' } : { kind: 'resend-confirm' }
    case 'UNSUBSCRIBED':
    case 'CLEANED':
      // Coming back needs their own confirmation — never a silent re-activation.
      return { kind: 'set-pending', sendConfirm: true }
    case 'BOUNCED':
      return { kind: 'refuse', reason: 'bounced' }
    case 'COMPLAINED':
      return { kind: 'refuse', reason: 'complained' }
  }
}

/** What the public sees — the same words whatever the address's state. */
export const PUBLIC_SUBSCRIBE_MESSAGE = 'Thanks! If this address can receive email, we’ve sent a link to confirm your subscription.'

/** Confirming: only a PENDING address becomes ACTIVE (an unsubscribed one must sign up again). */
export function confirmAction(existing: SubscriberStatus | null): 'activate' | 'already-active' | 'invalid' {
  if (existing === 'PENDING') return 'activate'
  if (existing === 'ACTIVE') return 'already-active'
  return 'invalid'
}

/**
 * What a provider webhook may do to a subscriber's status. It only ever
 * moves an address to a STRONGER state, never a weaker one:
 *   - soft bounce: touches nothing (it is temporary);
 *   - hard bounce: PENDING/ACTIVE → BOUNCED (an UNSUBSCRIBED person stays
 *     unsubscribed; the suppression list holds the bounce);
 *   - provider unsubscribe: PENDING/ACTIVE → UNSUBSCRIBED;
 *   - complaint: anything but COMPLAINED → COMPLAINED (the strongest state).
 * `from` is the status filter for the update, so it is atomic.
 */
export type WebhookStatusEvent = 'hard_bounce' | 'soft_bounce' | 'complaint' | 'unsubscribe'

export function webhookTransition(event: WebhookStatusEvent): { from: SubscriberStatus[]; to: SubscriberStatus } | null {
  switch (event) {
    case 'soft_bounce':
      return null
    case 'hard_bounce':
      return { from: ['PENDING', 'ACTIVE'], to: 'BOUNCED' }
    case 'unsubscribe':
      return { from: ['PENDING', 'ACTIVE'], to: 'UNSUBSCRIBED' }
    case 'complaint':
      return { from: ['PENDING', 'ACTIVE', 'UNSUBSCRIBED', 'CLEANED', 'BOUNCED'], to: 'COMPLAINED' }
  }
}

/** How strongly a status keeps mail away (higher = stronger). */
export const STATUS_STRENGTH: Record<SubscriberStatus, number> = { ACTIVE: 0, PENDING: 0, CLEANED: 1, UNSUBSCRIBED: 2, BOUNCED: 3, COMPLAINED: 4 }
