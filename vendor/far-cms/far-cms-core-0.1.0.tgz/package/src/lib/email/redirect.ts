/**
 * Where an email click may go — only to a link that was recorded for that
 * campaign (EmailLink). Anything else goes to the site's home page, so the
 * tracking URL can't be used as an open redirect. Pure; asserted by
 * redirect.assert.ts.
 */

function normalise(u: string): string | null {
  try {
    const url = new URL(u)
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null
    if (url.username || url.password) return null
    url.hash = url.hash // keep fragments as written
    return url.toString()
  } catch {
    return null
  }
}

export function clickRedirectTarget(input: { requested: string | null; allowed: ReadonlyArray<string>; home: string }): string {
  const want = input.requested ? normalise(input.requested) : null
  if (!want) return input.home
  const ok = input.allowed.some((a) => normalise(a) === want)
  return ok ? want : input.home
}
