/** Run: npx -y tsx@4.23.15 src/lib/email/templates/plain-text.assert.ts */
import assert from 'node:assert/strict'
import { htmlToPlainText } from './renderer'

const button = '<a href="https://x.test/shop?a=1&amp;b=2" style="x"><span><!--[if mso]><i hidden>&#8202;&#8202;</i><![endif]--></span><span>Shop now</span><span><!--[if mso]><i>&#8203;</i><![endif]--></span></a>'
const out = htmlToPlainText(`<p>Hi</p>${button}<p>It&#39;s &#233;t&#233;</p>`)
assert.ok(out.includes('Shop now (https://x.test/shop?a=1&b=2)'), out)
assert.ok(!out.includes('&#') && !out.includes('<!--'), out)
assert.ok(out.includes('It\'s été'), out)
assert.equal(htmlToPlainText('<a href="https://x.test"><img src="a.png"></a>'), '', 'an image-only link adds no empty "()"')
assert.equal(htmlToPlainText('<a href="https://x.test">Plain</a>'), 'Plain (https://x.test)')
assert.equal(htmlToPlainText('<p>Caf&#xE9;&#x200B; &#x2014; ok</p>'), 'Café \u2014 ok', 'hex entities decode; zero-width hex spacers drop')
console.log('6 checks passed')
