/**
 * Run: npx -y tsx@4.23.15 src/lib/email/send-policy.assert.ts
 * Audit run-2 R2-3: the general send API can't be used to mail anyone outside the guard.
 */
import assert from 'node:assert/strict'
import { allowedFrom, sendCategory, testRecipients } from './send-policy'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('default is marketing (guard: EMAIL_LIVE_SEND, suppression, footer)', () => {
  assert.equal(sendCategory({ html: '<p>Buy now</p>' }), 'marketing')
  assert.equal(sendCategory({}), 'marketing')
  assert.equal(sendCategory({ category: 'transactional', html: '<p>x</p>' }), 'marketing', 'claiming transactional is not enough')
})

check('only a named system email, as rendered, to its own recipient is transactional', () => {
  assert.equal(sendCategory({ template: 'password-reset' }), 'transactional')
  assert.equal(sendCategory({ template: 'order-confirmation', category: 'transactional' }), 'transactional')
  assert.equal(sendCategory({ template: 'password-reset', html: '<p>phish</p>' }), 'marketing', 'custom HTML on a system template')
  assert.equal(sendCategory({ template: 'welcome', bulk: true, recipients: [{ to: 'a@x.org' }] }), 'marketing', 'bulk')
  assert.equal(sendCategory({ template: 'cart-abandonment' }), 'marketing')
  assert.equal(sendCategory({ template: 'shipping-notification', campaignId: 'c1' }), 'marketing')
})

check('From is the site’s own sender or allow-listed, else dropped', () => {
  assert.equal(allowedFrom('ceo@bank.example', { siteFrom: 'hello@dz.org', allowList: [] }), null)
  assert.equal(allowedFrom('Hello@DZ.org', { siteFrom: 'hello@dz.org', allowList: [] }), 'hello@dz.org')
  assert.equal(allowedFrom('news@dz.org', { siteFrom: 'hello@dz.org', allowList: ['@dz.org'] }), 'news@dz.org')
  assert.equal(allowedFrom(null, { siteFrom: 'hello@dz.org', allowList: [] }), null)
})

check('tests go to yourself or the test allow-list only', () => {
  assert.deepEqual(testRecipients(['Me@x.org', 'qa@team.org', 'victim@else.org'], { selfEmail: 'me@x.org', allowList: ['@team.org'] }), { ok: ['me@x.org', 'qa@team.org'], refused: ['victim@else.org'] })
  assert.deepEqual(testRecipients(['a@b.org'], { selfEmail: null, allowList: [] }), { ok: [], refused: ['a@b.org'] })
})

console.log(`\n${n} checks passed`)
