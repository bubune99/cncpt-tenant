/**
 * What the Email marketing screen may claim — the analytics rule
 * (lib/analytics/kpis): only numbers that were actually measured. A rate
 * with nothing sent yet, or a stat the API couldn't read, is `null` and
 * shows as "—" with a reason, never as a fake 0% or 0. Pure; asserted by
 * kpis.assert.ts.
 */

export interface CampaignStatsLike {
  totalCampaigns?: unknown
  totalSent?: unknown
  avgOpenRate?: unknown
  avgClickRate?: unknown
  subscribers?: unknown
}

export interface EmailKpi {
  key: 'campaigns' | 'sent' | 'rates' | 'subscribers'
  label: string
  /** Formatted value, or "—" when not measured. */
  value: string
  hint: string
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null)
const count = (v: number | null) => (v === null ? '—' : v.toLocaleString('en-US'))

/** `stats` null = the API couldn't be read at all. */
export function emailKpis(stats: CampaignStatsLike | null): EmailKpi[] {
  const s = stats ?? {}
  const campaigns = num(s.totalCampaigns)
  const sent = num(s.totalSent)
  const open = num(s.avgOpenRate)
  const click = num(s.avgClickRate)
  const subscribers = num(s.subscribers)
  // Rates mean something only once something was sent.
  const ratesMeasured = sent !== null && sent > 0 && open !== null && click !== null
  return [
    { key: 'campaigns', label: 'Campaigns', value: count(campaigns), hint: campaigns === null ? 'Not available' : 'All campaigns' },
    { key: 'sent', label: 'Emails sent', value: count(sent), hint: sent === null ? 'Not available' : 'All time' },
    {
      key: 'rates',
      label: 'Open / click rate',
      value: ratesMeasured ? `${open}% / ${click}%` : '—',
      hint: ratesMeasured ? 'Average' : sent === 0 ? 'Not tracked yet — nothing sent' : 'Not tracked yet',
    },
    { key: 'subscribers', label: 'Subscribers', value: count(subscribers), hint: subscribers === null ? 'Not available' : 'Active' },
  ]
}
