/**
 * An email campaign (or template) as one editable document — the blocks the
 * editor edits, stored as EmailCampaign.content / EmailTemplate.content in
 * the `{ content: [{ type, props }], root }` shape. Pure; asserted by
 * doc.assert.ts. Rendering is render.tsx (React Email).
 *
 * The footer is a block, always present, always last, locked: the editor
 * can't delete, move or hide it.
 */

export type Align = 'left' | 'center' | 'right'
export type ShowOn = 'all' | 'desktop' | 'phone'
/** Theme colour slots (the brand), never raw hex in a block. */
export type ColorSlot = 'button' | 'header' | 'accent'

export interface CommonProps {
  id: string
  /** Space above / below in px. */
  above: number
  below: number
  showOn: ShowOn
}

export interface BlockPropsMap {
  Header: { logoUrl: string; logoAlt: string }
  Heading: { text: string; level: 1 | 2 | 3; align: Align }
  /** Limited rich text: <b>/<strong>, <i>/<em>, <a href>, <br>; merge tags as {{…}}. */
  Text: { html: string; align: Align }
  Image: { src: string; alt: string; href: string; fullBleed: boolean }
  Button: { label: string; href: string; color: ColorSlot; width: 'auto' | 'full'; align: Align; corner: 'square' | 'round'; trackClicks: boolean }
  Link: { label: string; href: string; align: Align }
  Columns: { columns: Array<{ id: string; content: EmailBlock[] }> }
  Section: { background: 'none' | 'sand' | 'navy'; content: EmailBlock[] }
  Divider: Record<string, never>
  /** Live data, resolved when the email is rendered. null = not picked yet. */
  Initiative: { initiativeId: string | null }
  Donate: { heading: string; amounts: number[]; href: string }
  /** null = the latest post. */
  BlogPost: { postId: string | null }
  Event: { eventId: string | null }
  Footer: { note: string }
}

export type EmailBlockType = keyof BlockPropsMap
export type EmailBlock = { [K in EmailBlockType]: { type: K; props: CommonProps & BlockPropsMap[K] } }[EmailBlockType]
export type BlockOf<K extends EmailBlockType> = Extract<EmailBlock, { type: K }>

export interface EmailTheme {
  headerBg: string
  buttonBg: string
  accent: string
  textColor: string
  footerBg: string
  canvasBg: string
  headingFont: string
  bodyFont: string
}

/** The site's brand as the email theme (editable per email). */
export const DEFAULT_THEME: EmailTheme = {
  headerBg: '#022b39',
  buttonBg: '#088cbc',
  accent: '#d99a1e',
  textColor: '#1f2937',
  footerBg: '#f3efe6',
  canvasBg: '#ffffff',
  headingFont: "'Fredoka', 'Fredoka One', Arial, sans-serif",
  bodyFont: "Georgia, 'Times New Roman', serif",
}

export interface EmailDoc {
  content: EmailBlock[]
  root: { props: { theme: EmailTheme } }
}

export interface BlockCatalogEntry {
  type: EmailBlockType
  label: string
  /** The React Email component it renders as (the pill's tag). */
  tag: string
  group: 'basic' | 'live'
  icon: string
}

export const BLOCK_CATALOG: ReadonlyArray<BlockCatalogEntry> = [
  { type: 'Heading', label: 'Heading', tag: 'Heading', group: 'basic', icon: 'Heading' },
  { type: 'Text', label: 'Text', tag: 'Text', group: 'basic', icon: 'AlignLeft' },
  { type: 'Image', label: 'Image', tag: 'Img', group: 'basic', icon: 'Image' },
  { type: 'Button', label: 'Button', tag: 'Button', group: 'basic', icon: 'MousePointerClick' },
  { type: 'Link', label: 'Link', tag: 'Link', group: 'basic', icon: 'Link' },
  { type: 'Columns', label: 'Columns', tag: 'Row', group: 'basic', icon: 'Columns2' },
  { type: 'Section', label: 'Section', tag: 'Section', group: 'basic', icon: 'Square' },
  { type: 'Divider', label: 'Divider', tag: 'Hr', group: 'basic', icon: 'Minus' },
  { type: 'Initiative', label: 'Initiative card', tag: 'Section', group: 'live', icon: 'HeartHandshake' },
  { type: 'Donate', label: 'Donate band', tag: 'Section', group: 'live', icon: 'HandCoins' },
  { type: 'BlogPost', label: 'Blog post', tag: 'Section', group: 'live', icon: 'Newspaper' },
  { type: 'Event', label: 'Event', tag: 'Section', group: 'live', icon: 'CalendarDays' },
]

export const BLOCK_LABEL: Record<EmailBlockType, string> = {
  Header: 'Header & logo',
  Heading: 'Heading',
  Text: 'Text',
  Image: 'Image',
  Button: 'Button',
  Link: 'Link',
  Columns: 'Columns',
  Section: 'Section',
  Divider: 'Divider',
  Initiative: 'Initiative card',
  Donate: 'Donate band',
  BlogPost: 'Blog post',
  Event: 'Event',
  Footer: 'Footer',
}

export type SavedSection = 'header' | 'two-initiatives'

let seq = 0
export function newId(prefix = 'b'): string {
  seq = (seq + 1) % 1e6
  return `${prefix}_${Date.now().toString(36)}${seq.toString(36)}${Math.random().toString(36).slice(2, 6)}`
}

const common = (id = newId()): CommonProps => ({ id, above: 0, below: 0, showOn: 'all' })

export function newBlock<K extends EmailBlockType>(type: K, id?: string): BlockOf<K> {
  const c = common(id)
  const by: { [T in EmailBlockType]: () => BlockOf<T> } = {
    // logoAlt empty → the site name at render (ctx.org.name, from Identity & brand).
    Header: () => ({ type: 'Header', props: { ...c, logoUrl: '', logoAlt: '' } }),
    Heading: () => ({ type: 'Heading', props: { ...c, text: 'A heading', level: 1, align: 'left', above: 16, below: 8 } }),
    Text: () => ({ type: 'Text', props: { ...c, html: 'Write something…', align: 'left', below: 12 } }),
    Image: () => ({ type: 'Image', props: { ...c, src: '', alt: '', href: '', fullBleed: false } }),
    Button: () => ({ type: 'Button', props: { ...c, label: 'Give this month', href: '/donate', color: 'button', width: 'auto', align: 'center', corner: 'round', trackClicks: true, above: 22, below: 6 } }),
    Link: () => ({ type: 'Link', props: { ...c, label: 'Read more', href: '/', align: 'left' } }),
    Columns: () => ({ type: 'Columns', props: { ...c, columns: [{ id: newId('col'), content: [] }, { id: newId('col'), content: [] }] } }),
    Section: () => ({ type: 'Section', props: { ...c, background: 'none', content: [] } }),
    Divider: () => ({ type: 'Divider', props: { ...c, above: 12, below: 12 } as CommonProps & Record<string, never> }),
    Initiative: () => ({ type: 'Initiative', props: { ...c, initiativeId: null } }),
    Donate: () => ({ type: 'Donate', props: { ...c, heading: 'Help us reach this year’s goal', amounts: [25, 50, 100], href: '/donate' } }),
    BlogPost: () => ({ type: 'BlogPost', props: { ...c, postId: null } }),
    Event: () => ({ type: 'Event', props: { ...c, eventId: null } }),
    Footer: () => ({ type: 'Footer', props: { ...c, note: 'You’re receiving this because you signed up at projectdzidzor.org.' } }),
  }
  return by[type]() as BlockOf<K>
}

/** A column set with `count` columns (2 or 3). */
export function newColumns(count: 2 | 3, fill?: (i: number) => EmailBlock[]): BlockOf<'Columns'> {
  const b = newBlock('Columns')
  b.props.columns = Array.from({ length: count }, (_, i) => ({ id: newId('col'), content: fill ? fill(i) : [] }))
  return b
}

export function savedSection(kind: SavedSection): EmailBlock {
  if (kind === 'header') return newBlock('Header')
  return newColumns(2, () => [newBlock('Initiative')])
}

/** The starting email: header, heading, text, button — and the footer. */
export function newEmailDoc(logoUrl?: string): EmailDoc {
  const d = normalizeEmailDoc({
    content: [newBlock('Header'), newBlock('Heading'), newBlock('Text'), newBlock('Button')],
    root: { props: { theme: { ...DEFAULT_THEME } } },
  })
  // A new email's header uses the site's logo.
  const h = d.content[0]
  if (logoUrl && h?.type === 'Header') h.props.logoUrl = logoUrl
  return d
}

/** Does stored content hold an editor document (vs empty / another shape)? */
export function hasEmailDoc(content: unknown): boolean {
  return !!content && typeof content === 'object' && Array.isArray((content as { content?: unknown }).content)
}

/* ---- walking ---- */

/** The block lists inside a block (sections and each column). */
export function childLists(b: EmailBlock): EmailBlock[][] {
  if (b.type === 'Section') return [b.props.content]
  if (b.type === 'Columns') return b.props.columns.map((c) => c.content)
  return []
}

export function walk(list: ReadonlyArray<EmailBlock>, visit: (b: EmailBlock, depth: number) => void, depth = 0): void {
  for (const b of list) {
    visit(b, depth)
    for (const l of childLists(b)) walk(l, visit, depth + 1)
  }
}

export function findBlock(doc: EmailDoc, id: string): EmailBlock | null {
  let hit: EmailBlock | null = null
  walk(doc.content, (b) => {
    if (!hit && b.props.id === id) hit = b
  })
  return hit
}

/** A list's address: the top level, a section's content, or one column of a column set. */
export type ListRef = { kind: 'root' } | { kind: 'section'; id: string } | { kind: 'column'; id: string; column: number }

export function listKey(ref: ListRef): string {
  return ref.kind === 'root' ? 'root' : ref.kind === 'section' ? `section:${ref.id}` : `column:${ref.id}:${ref.column}`
}

/** Where a block sits: its list and index. */
export function locate(doc: EmailDoc, id: string): { ref: ListRef; index: number } | null {
  const search = (list: EmailBlock[], ref: ListRef): { ref: ListRef; index: number } | null => {
    const i = list.findIndex((b) => b.props.id === id)
    if (i >= 0) return { ref, index: i }
    for (const b of list) {
      if (b.type === 'Section') {
        const r = search(b.props.content, { kind: 'section', id: b.props.id })
        if (r) return r
      } else if (b.type === 'Columns') {
        for (let c = 0; c < b.props.columns.length; c++) {
          const r = search(b.props.columns[c].content, { kind: 'column', id: b.props.id, column: c })
          if (r) return r
        }
      }
    }
    return null
  }
  return search(doc.content, { kind: 'root' })
}

/* ---- immutable edits ---- */

function mapList(list: EmailBlock[], ref: ListRef, here: ListRef, fn: (l: EmailBlock[]) => EmailBlock[]): EmailBlock[] {
  let out = listKey(ref) === listKey(here) ? fn(list) : list
  out = out.map((b) => {
    if (b.type === 'Section') {
      const inner = mapList(b.props.content, ref, { kind: 'section', id: b.props.id }, fn)
      return inner === b.props.content ? b : { ...b, props: { ...b.props, content: inner } }
    }
    if (b.type === 'Columns') {
      let changed = false
      const columns = b.props.columns.map((c, i) => {
        const inner = mapList(c.content, ref, { kind: 'column', id: b.props.id, column: i }, fn)
        if (inner !== c.content) changed = true
        return inner === c.content ? c : { ...c, content: inner }
      })
      return changed ? { ...b, props: { ...b.props, columns } } : b
    }
    return b
  })
  return out
}

function withList(doc: EmailDoc, ref: ListRef, fn: (l: EmailBlock[]) => EmailBlock[]): EmailDoc {
  return { ...doc, content: mapList(doc.content, ref, { kind: 'root' }, fn) }
}

/** Insert into a list at `index` (default: the end; at the top level, never after the footer). */
export function insertBlock(doc: EmailDoc, block: EmailBlock, ref: ListRef = { kind: 'root' }, index?: number): EmailDoc {
  if (block.type === 'Footer') return doc
  return normalizeEmailDoc(
    withList(doc, ref, (l) => {
      const max = ref.kind === 'root' && l.at(-1)?.type === 'Footer' ? l.length - 1 : l.length
      const at = Math.max(0, Math.min(index ?? max, max))
      return [...l.slice(0, at), block, ...l.slice(at)]
    })
  )
}

/** Insert right after another block (in its list), or before the footer. */
export function insertAfter(doc: EmailDoc, block: EmailBlock, afterId: string | null): EmailDoc {
  const at = afterId ? locate(doc, afterId) : null
  if (!at) return insertBlock(doc, block)
  return insertBlock(doc, block, at.ref, at.index + 1)
}

export function removeBlock(doc: EmailDoc, id: string): EmailDoc {
  const b = findBlock(doc, id)
  if (!b || b.type === 'Footer') return doc
  const at = locate(doc, id)!
  return withList(doc, at.ref, (l) => l.filter((x) => x.props.id !== id))
}

export function patchBlock(doc: EmailDoc, id: string, patch: Record<string, unknown>): EmailDoc {
  const at = locate(doc, id)
  if (!at) return doc
  const { id: _ignored, ...rest } = patch
  void _ignored
  return withList(doc, at.ref, (l) => l.map((b) => (b.props.id === id ? ({ ...b, props: { ...b.props, ...rest } } as EmailBlock) : b)))
}

function cloneFresh(b: EmailBlock): EmailBlock {
  const props = { ...b.props, id: newId() } as EmailBlock['props']
  if (b.type === 'Section') (props as BlockOf<'Section'>['props']).content = b.props.content.map(cloneFresh)
  if (b.type === 'Columns') (props as BlockOf<'Columns'>['props']).columns = b.props.columns.map((c) => ({ id: newId('col'), content: c.content.map(cloneFresh) }))
  return { type: b.type, props } as EmailBlock
}

export function duplicateBlock(doc: EmailDoc, id: string): { doc: EmailDoc; newId: string | null } {
  const b = findBlock(doc, id)
  if (!b || b.type === 'Footer') return { doc, newId: null }
  const copy = cloneFresh(b)
  return { doc: insertAfter(doc, copy, id), newId: copy.props.id }
}

/** Is `id` the block `ancestorId` or inside it? */
export function isInside(doc: EmailDoc, id: string, ancestorId: string): boolean {
  if (id === ancestorId) return true
  const a = findBlock(doc, ancestorId)
  if (!a) return false
  let hit = false
  for (const l of childLists(a)) walk(l, (b) => {
    if (b.props.id === id) hit = true
  })
  return hit
}

/** Move a block to `index` of a list (one edit; ids kept). Never the footer, never into itself. */
export function moveBlock(doc: EmailDoc, id: string, ref: ListRef, index: number): EmailDoc {
  const b = findBlock(doc, id)
  if (!b || b.type === 'Footer') return doc
  if (ref.kind !== 'root' && isInside(doc, ref.id, id)) return doc
  const from = locate(doc, id)!
  const without = withList(doc, from.ref, (l) => l.filter((x) => x.props.id !== id))
  const adjusted = listKey(from.ref) === listKey(ref) && from.index < index ? index - 1 : index
  return insertBlock(without, b, ref, adjusted)
}

/* ---- normalising (anything stored or pasted becomes a valid doc) ---- */

const ALIGNS: Align[] = ['left', 'center', 'right']
const SHOW: ShowOn[] = ['all', 'desktop', 'phone']
const str = (v: unknown, d = '') => (typeof v === 'string' ? v : d)
const num = (v: unknown, d = 0, max = 200) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(0, Math.min(max, Math.round(v))) : d)
const pick = <T extends string>(v: unknown, opts: readonly T[], d: T): T => (opts.includes(v as T) ? (v as T) : d)

function normalizeBlock(raw: unknown, seen: Set<string>): EmailBlock | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as { type?: unknown; props?: Record<string, unknown> }
  const type = r.type as EmailBlockType
  if (!(type in BLOCK_LABEL)) return null
  const p = r.props ?? {}
  let id = str(p.id)
  if (!id || seen.has(id)) id = newId()
  seen.add(id)
  const base = newBlock(type, id)
  const c: CommonProps = { id, above: num(p.above, base.props.above), below: num(p.below, base.props.below), showOn: pick(p.showOn, SHOW, 'all') }
  const list = (v: unknown) => (Array.isArray(v) ? v.map((x) => normalizeBlock(x, seen)).filter((x): x is EmailBlock => !!x && x.type !== 'Footer') : [])
  switch (type) {
    case 'Header':
      return { type, props: { ...c, logoUrl: str(p.logoUrl), logoAlt: str(p.logoAlt) } }
    case 'Heading':
      return { type, props: { ...c, text: str(p.text), level: ([1, 2, 3] as const).includes(p.level as 1) ? (p.level as 1 | 2 | 3) : 1, align: pick(p.align, ALIGNS, 'left') } }
    case 'Text':
      return { type, props: { ...c, html: str(p.html), align: pick(p.align, ALIGNS, 'left') } }
    case 'Image':
      return { type, props: { ...c, src: str(p.src), alt: str(p.alt), href: str(p.href), fullBleed: p.fullBleed === true } }
    case 'Button':
      return {
        type,
        props: {
          ...c,
          label: str(p.label, 'Button'),
          href: str(p.href),
          color: pick(p.color, ['button', 'header', 'accent'] as const, 'button'),
          width: pick(p.width, ['auto', 'full'] as const, 'auto'),
          align: pick(p.align, ALIGNS, 'center'),
          corner: pick(p.corner, ['square', 'round'] as const, 'round'),
          trackClicks: p.trackClicks !== false,
        },
      }
    case 'Link':
      return { type, props: { ...c, label: str(p.label, 'Link'), href: str(p.href), align: pick(p.align, ALIGNS, 'left') } }
    case 'Columns': {
      const cols = Array.isArray(p.columns) ? p.columns.slice(0, 3) : []
      const columns = cols.map((col) => ({ id: str((col as { id?: unknown })?.id) || newId('col'), content: list((col as { content?: unknown })?.content) }))
      while (columns.length < 2) columns.push({ id: newId('col'), content: [] })
      return { type, props: { ...c, columns } }
    }
    case 'Section':
      return { type, props: { ...c, background: pick(p.background, ['none', 'sand', 'navy'] as const, 'none'), content: list(p.content) } }
    case 'Divider':
      return { type, props: c as CommonProps & Record<string, never> }
    case 'Initiative':
      return { type, props: { ...c, initiativeId: str(p.initiativeId) || null } }
    case 'Donate': {
      const amounts = Array.isArray(p.amounts) ? p.amounts.filter((a): a is number => typeof a === 'number' && a > 0).slice(0, 4) : []
      return { type, props: { ...c, heading: str(p.heading), amounts: amounts.length ? amounts : [25, 50, 100], href: str(p.href, '/donate') } }
    }
    case 'BlogPost':
      return { type, props: { ...c, postId: str(p.postId) || null } }
    case 'Event':
      return { type, props: { ...c, eventId: str(p.eventId) || null } }
    case 'Footer':
      return { type, props: { ...c, showOn: 'all', note: str(p.note, (base as BlockOf<'Footer'>).props.note) } }
  }
}

/** Any stored value → a valid doc: known blocks only, unique ids, exactly one footer, last. */
export function normalizeEmailDoc(raw: unknown): EmailDoc {
  const r = (raw && typeof raw === 'object' ? raw : {}) as { content?: unknown; root?: { props?: { theme?: Partial<EmailTheme> } } }
  const seen = new Set<string>()
  const all = Array.isArray(r.content) ? r.content.map((x) => normalizeBlock(x, seen)).filter((x): x is EmailBlock => !!x) : []
  const footer = all.find((b) => b.type === 'Footer') ?? newBlock('Footer')
  const content = [...all.filter((b) => b.type !== 'Footer'), footer]
  const t = r.root?.props?.theme ?? {}
  const theme: EmailTheme = { ...DEFAULT_THEME }
  for (const k of Object.keys(DEFAULT_THEME) as Array<keyof EmailTheme>) if (typeof t[k] === 'string' && t[k]) theme[k] = t[k] as string
  return { content, root: { props: { theme } } }
}

/** "Heading — “Your support…”" style names for the outline. */
export function blockName(b: EmailBlock): string {
  const label = BLOCK_LABEL[b.type]
  const text = b.type === 'Heading' ? b.props.text : b.type === 'Button' || b.type === 'Link' ? b.props.label : b.type === 'Text' ? b.props.html.replace(/<[^>]+>/g, '') : b.type === 'Image' ? b.props.alt : ''
  const t = text.replace(/\s+/g, ' ').trim()
  return t ? `${label} — “${t.length > 32 ? `${t.slice(0, 31)}…` : t}”` : label
}
