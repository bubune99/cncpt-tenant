/**
 * May a campaign be sent now, and if not, why — from forms-pkg's checks
 * (GET /api/emails/campaigns/[id]/checks). Pure; asserted by readiness.assert.ts.
 */

export interface SendCheck {
  id: string;
  label: string;
  ok: boolean;
  /** required checks block sending; warnings don't. */
  level?: 'required' | 'warning';
  detail?: string;
  fixHref?: string;
}

/**
 * Pure: may it be sent, and if not, the first reason. The server's canSend
 * has the last word (it also knows who may send); a failing required check
 * is the reason shown. Warnings never block.
 */
export function sendReadiness(checks: SendCheck[] | null, canSend?: boolean): { ready: boolean; reason: string | null } {
  if (!checks) return { ready: false, reason: 'Checking…' };
  if (!checks.length) return { ready: false, reason: 'The pre-send checks aren’t available yet.' };
  const bad = checks.find((c) => !c.ok && c.level !== 'warning');
  if (bad) return { ready: false, reason: bad.detail || bad.label };
  if (canSend === false) return { ready: false, reason: 'Only the site owner can send campaigns for now.' };
  return { ready: true, reason: null };
}

