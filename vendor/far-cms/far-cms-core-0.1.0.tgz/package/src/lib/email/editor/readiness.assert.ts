/**
 * Run: npx -y tsx@4.23.15 src/lib/email/editor/readiness.assert.ts
 */
import assert from 'node:assert/strict'
import { sendReadiness, type SendCheck } from './readiness'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const C = (id: string, ok: boolean, level: SendCheck['level'] = 'required', detail?: string): SendCheck => ({ id, label: id, ok, level, detail })

check('Send stays off while a required check fails, with that reason', () => {
  assert.deepEqual(sendReadiness([C('sender', false, 'required', 'Settings › Email has no verified sender'), C('audience', true)], true), { ready: false, reason: 'Settings › Email has no verified sender' })
  assert.deepEqual(sendReadiness([C('audience', false)], true), { ready: false, reason: 'audience' })
})

check('warnings never block; the server’s canSend has the last word', () => {
  assert.deepEqual(sendReadiness([C('alt', false, 'warning'), C('sender', true)], true), { ready: true, reason: null })
  assert.equal(sendReadiness([C('sender', true)], false).ready, false)
  assert.match(sendReadiness([C('sender', true)], false).reason!, /owner/)
})

check('no checks yet / not available: off, never assumed fine', () => {
  assert.equal(sendReadiness(null).ready, false)
  assert.equal(sendReadiness([]).ready, false)
})

console.log(`\n${n} checks passed`)
