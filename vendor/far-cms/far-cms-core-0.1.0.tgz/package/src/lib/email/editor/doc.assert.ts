/**
 * Run: npx -y tsx@4.23.15 src/lib/email/editor/doc.assert.ts
 */
import assert from 'node:assert/strict'
import {
  duplicateBlock, findBlock, insertAfter, insertBlock, locate, moveBlock, newBlock, newColumns, newEmailDoc, normalizeEmailDoc, patchBlock, removeBlock, savedSection, walk, type EmailDoc,
} from './doc'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const types = (d: EmailDoc) => d.content.map((b) => b.type)
const ids = (d: EmailDoc) => { const o: string[] = []; walk(d.content, (b) => o.push(b.props.id)); return o }

check('the stored shape: { content: [{ type, props }], root }, footer always last and only once', () => {
  const d = newEmailDoc()
  assert.deepEqual(types(d), ['Header', 'Heading', 'Text', 'Button', 'Footer'])
  assert.ok(d.root.props.theme.headerBg === '#022b39' && d.root.props.theme.buttonBg === '#088cbc')
  const messy = normalizeEmailDoc({ content: [{ type: 'Footer', props: { id: 'f' } }, { type: 'Heading', props: { id: 'h', text: 'x' } }, { type: 'Footer', props: { id: 'f2' } }, { type: 'Nope', props: {} }, null] })
  assert.deepEqual(types(messy), ['Heading', 'Footer'])
  assert.deepEqual(types(normalizeEmailDoc(null)), ['Footer'])
})

check('normalising: unknown values fall back, duplicate ids are renewed, the brand fills the theme', () => {
  const d = normalizeEmailDoc({ content: [{ type: 'Button', props: { id: 'a', color: 'pink', width: 'huge', above: -5 } }, { type: 'Text', props: { id: 'a' } }], root: { props: { theme: { buttonBg: '#123456' } } } })
  const b = d.content[0]
  assert.ok(b.type === 'Button' && b.props.color === 'button' && b.props.width === 'auto' && b.props.above === 0)
  assert.notEqual(d.content[1].props.id, 'a')
  assert.equal(d.root.props.theme.buttonBg, '#123456')
  assert.equal(d.root.props.theme.headerBg, '#022b39')
})

check('the footer is locked: never removed, duplicated, moved or inserted again', () => {
  const d = newEmailDoc()
  const f = d.content.at(-1)!.props.id
  assert.equal(removeBlock(d, f), d)
  assert.equal(duplicateBlock(d, f).newId, null)
  assert.equal(moveBlock(d, f, { kind: 'root' }, 0), d)
  assert.deepEqual(types(insertBlock(d, newBlock('Footer'))), types(d))
  // inserts land before it
  assert.equal(insertBlock(d, newBlock('Divider')).content.at(-2)!.type, 'Divider')
  assert.equal(insertBlock(d, newBlock('Divider'), { kind: 'root' }, 99).content.at(-1)!.type, 'Footer')
})

check('insert after the selection, patch, duplicate (fresh ids), remove', () => {
  let d = newEmailDoc()
  const h = d.content[1].props.id
  d = insertAfter(d, newBlock('Divider', 'div1'), h)
  assert.deepEqual(types(d).slice(0, 4), ['Header', 'Heading', 'Divider', 'Text'])
  d = patchBlock(d, h, { text: 'New', id: 'hijack' })
  const hb = findBlock(d, h)!
  assert.ok(hb.type === 'Heading' && hb.props.text === 'New')
  const r = duplicateBlock(d, h)
  assert.ok(r.newId && r.newId !== h && findBlock(r.doc, r.newId)!.type === 'Heading')
  assert.equal(new Set(ids(r.doc)).size, ids(r.doc).length)
  assert.equal(findBlock(removeBlock(d, 'div1'), 'div1'), null)
})

check('columns and sections hold blocks; moves across lists keep ids; never into itself', () => {
  let d = newEmailDoc()
  const cols = newColumns(2)
  cols.props.id = 'cols'
  d = insertBlock(d, cols)
  const txt = d.content[2].props.id
  d = moveBlock(d, txt, { kind: 'column', id: 'cols', column: 1 }, 0)
  assert.deepEqual(locate(d, txt), { ref: { kind: 'column', id: 'cols', column: 1 }, index: 0 })
  assert.ok(findBlock(d, txt))
  // back out to the top, right after the header
  d = moveBlock(d, txt, { kind: 'root' }, 1)
  assert.equal(d.content[1].props.id, txt)
  // a section can't go into its own column
  const sec = savedSection('two-initiatives')
  d = insertBlock(d, sec)
  assert.equal(moveBlock(d, sec.props.id, { kind: 'column', id: sec.props.id, column: 0 }, 0), d)
  // reorder within a list (dnd-kit semantics: index counted before removal)
  const before = types(d)
  const moved = moveBlock(d, d.content[1].props.id, { kind: 'root' }, 3)
  assert.equal(moved.content[2].props.id, d.content[1].props.id)
  assert.equal(moved.content.length, before.length)
})

check('saved sections: header; two initiative cards side by side', () => {
  assert.equal(savedSection('header').type, 'Header')
  const two = savedSection('two-initiatives')
  assert.ok(two.type === 'Columns' && two.props.columns.length === 2 && two.props.columns.every((c) => c.content[0]?.type === 'Initiative'))
})

console.log(`\n${n} checks passed`)
