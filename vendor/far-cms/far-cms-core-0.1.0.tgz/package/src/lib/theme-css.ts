/**
 * A page's theme CSS (content.themeCSS): the CSS variables and Google Fonts
 * imports a project import extracted (lib/project-import/theme-extractor).
 * It is rendered inside <style>, so it must never be able to close that
 * element or load anything but fonts. Pure; asserted by theme-css.assert.ts.
 */

export const THEME_CSS_MAX = 20_000

const FONT_IMPORT = /^@import\s+url\(\s*(['"]?)https:\/\/fonts\.googleapis\.com\/[^'")\s<>]*\1\s*\)\s*;?$/i

/**
 * Why this theme CSS can't be saved, or null when it's fine: plain CSS (no
 * "<" anywhere, so it can't close the <style>), no script-ish values, and
 * url() only in Google Fonts @imports.
 */
export function themeCssProblem(css: unknown): string | null {
  if (css == null || css === '') return null
  if (typeof css !== 'string') return 'Theme CSS must be text.'
  if (css.length > THEME_CSS_MAX) return 'Theme CSS is too long.'
  if (css.includes('<')) return 'Theme CSS can’t contain “<”.'
  if (/javascript:|expression\s*\(|behavior\s*:|-moz-binding|\\/i.test(css)) return 'Theme CSS can only hold colors, fonts and sizes.'
  for (const line of css.split(/\n/)) {
    const l = line.trim()
    if (/^@import/i.test(l) && !FONT_IMPORT.test(l)) return 'Theme CSS can only import Google Fonts.'
  }
  const withoutFontImports = css.split(/\n/).filter((l) => !FONT_IMPORT.test(l.trim())).join('\n')
  if (/url\s*\(/i.test(withoutFontImports) || /@import/i.test(withoutFontImports)) return 'Theme CSS can only load Google Fonts.'
  return null
}

/**
 * What the page renders inside <style>: whatever is stored (old rows were
 * never checked), made unable to leave the element — any "</style" is
 * removed and every "<" becomes the inert CSS escape "\3c ".
 */
export function neutraliseThemeCss(css: string | null | undefined): string {
  if (!css) return ''
  return css.replace(/<\/style/gi, '').replace(/</g, '\\3c ')
}
