/**
 * Unified Slug Management
 *
 * Single source of truth for slug formatting, validation, and collision handling.
 * Replaces 5 duplicate slugify() functions across the codebase.
 */

const MAX_SLUG_LENGTH = 128

const RESERVED_SLUGS = new Set([
  'admin', 'api', 'auth', 'login', 'signup', 'register',
  'account', 'dashboard', 'settings', 'checkout', 'cart',
  'shop', 'products', 'categories', 'tags', 'posts', 'blog',
  'search', 'sitemap', 'robots', 'favicon', 'health',
  'handler', 's', 'webhook', 'webhooks',
])

/**
 * Format a string into a URL-safe slug.
 * Lowercase, alphanumeric + hyphens only, no leading/trailing/double hyphens.
 */
export function formatSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '')
    .replace(/-{2,}/g, '-')
    .slice(0, MAX_SLUG_LENGTH)
}

/**
 * Format a page slug — same as formatSlug but ensures a leading `/`.
 * Returns empty string if input is empty.
 */
export function formatPageSlug(text: string): string {
  const slug = formatSlug(text)
  return slug ? `/${slug}` : ''
}

/**
 * Check whether a slug is reserved (would collide with app routes).
 */
export function isReservedSlug(slug: string): boolean {
  // Strip leading slash, then check the first path segment
  const bare = slug.replace(/^\/+/, '')
  const firstSegment = bare.split('/')[0]
  return RESERVED_SLUGS.has(firstSegment)
}

/**
 * Validate a slug and return an error message if invalid.
 */
export function validateSlug(slug: string): { valid: boolean; error?: string } {
  // Strip leading slash for pages
  const bare = slug.replace(/^\/+/, '')

  if (!bare) {
    return { valid: false, error: 'Slug cannot be empty' }
  }

  if (bare.length > MAX_SLUG_LENGTH) {
    return { valid: false, error: `Slug cannot exceed ${MAX_SLUG_LENGTH} characters` }
  }

  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(bare)) {
    return { valid: false, error: 'Slug may only contain lowercase letters, numbers, and single hyphens' }
  }

  if (isReservedSlug(bare)) {
    return { valid: false, error: `"${bare}" is a reserved path and cannot be used as a slug` }
  }

  return { valid: true }
}

/**
 * Generate a unique slug by appending -1, -2, etc. if the base slug is taken.
 *
 * @param slug      - The desired slug
 * @param checkExists - Callback that returns true if the slug is already in use
 * @param excludeId  - Optional ID to exclude from the check (for updates)
 */
export async function ensureUniqueSlug(
  slug: string,
  checkExists: (slug: string) => Promise<boolean>,
  excludeId?: string,
): Promise<string> {
  let candidate = slug
  let counter = 1

  while (await checkExists(candidate)) {
    candidate = `${slug}-${counter}`
    counter++
  }

  return candidate
}
