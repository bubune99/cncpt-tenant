/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/change-widgets.assert.ts
 */
import assert from 'node:assert/strict'
import { batchOf, entityHref, entityNameOf, entityTypeOf, pathLabel, pickPageSnapshot, pickRevision, revisionLines, unchangedOf, viewFromItems, viewFromRevision, withRevision, type WidgetItem } from './change-widgets'
import { kindOf } from '../ade/chat/change-review'
import { widgetActions, widgetHeader } from '../ade/chat/change-widgets'
import { maskData } from '../ade/governance/visibility'
import { VISIBILITY_FLOOR } from './visibility-rules'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const item = (over: Partial<WidgetItem> = {}): WidgetItem => ({
  id: 'i1', targetType: 'record', targetId: 'r1', status: 'pending', error: null, isPublish: false, canApprove: true,
  adminHref: '/admin/records/initiative/r1', fieldChanges: [{ field: 'summary', before: 'Old words', after: 'New words' }], blockChanges: [],
  after: { type: 'initiative', data: { title: 'Clinic roof' } }, ...over,
})
const ref = (itemIds: string[]) => ({ kind: 'changeset' as const, changeSetId: 'cs1', itemIds })

check('entity names and types come from the stored change', () => {
  assert.equal(entityTypeOf(item()), 'Initiative')
  assert.equal(entityTypeOf(item({ targetType: 'site-layout', targetId: 'footer' })), 'Footer')
  assert.equal(entityTypeOf(item({ targetType: 'page-content' })), 'Page')
  assert.equal(entityTypeOf(item({ targetType: 'blog-status' })), 'Blog post')
  assert.equal(entityTypeOf(item({ targetType: 'record', after: null })), 'Record')
  assert.equal(entityNameOf({ data: { title: 'Clinic roof' } }), 'Clinic roof')
  assert.equal(entityNameOf({ title: 'About us', data: { title: 'x' } }), 'About us')
  assert.equal(entityNameOf(null), null)
})

check('a drafted edit + its publish make ONE card that approves both', () => {
  const v = viewFromItems(ref(['i1', 'i2']), [
    item({ id: 'i2', isPublish: true, targetType: 'record-status', fieldChanges: [{ field: 'status', before: 'DRAFT', after: 'PUBLISHED' }] }),
    item(),
    item({ id: 'other' }),
  ])!
  assert.equal(v.entityType, 'Initiative')
  assert.equal(v.entityName, 'Clinic roof', 'named from the content item, not the publish item')
  assert.deepEqual(v.itemIds.sort(), ['i1', 'i2'])
  assert.deepEqual(v.fields.map((f) => [f.label, f.before, f.after]), [['Status', 'DRAFT', 'PUBLISHED'], ['Summary', 'Old words', 'New words']])
  assert.equal(v.status, 'pending')
  assert.deepEqual(widgetActions(v), ['approve', 'reject', 'open'])
  assert.equal(v.href, '/admin/todo/review/cs1', 'Open while pending = its review page')
  assert.equal(widgetHeader(v).title, 'Drafted a change to Initiative “Clinic roof”')
})

check('once approved it is Saved; nothing left to approve', () => {
  const v = viewFromItems(ref(['i1']), [item({ status: 'approved' })])!
  assert.equal(v.status, 'applied')
  assert.deepEqual(v.itemIds, [])
  assert.equal(v.href, '/admin/records/initiative/r1', 'Open once saved = the thing itself')
  assert.deepEqual(widgetActions(v), ['open'])
})

check('a reviewer without the permission gets no review buttons', () => {
  const v = viewFromItems(ref(['i1', 'i2']), [item(), item({ id: 'i2', canApprove: false })])!
  assert.equal(v.canApprove, false)
  assert.deepEqual(widgetActions(v), ['open'])
})

check('no visible item → no widget', () => {
  assert.equal(viewFromItems(ref(['gone']), [item()]), null)
  assert.equal(viewFromItems(ref([]), []), null)
})

check('stale/failed carry the reason', () => {
  const v = viewFromItems(ref(['i1']), [item({ status: 'stale', error: 'The target changed after the agent drafted this' })])!
  assert.equal(v.status, 'stale')
  assert.match(v.error!, /target changed/)
})

check('a page content card is named after its page (its snapshot holds only content)', () => {
  const v = viewFromItems(ref(['i1']), [item({ targetType: 'page-content', after: { content: { blocks: [] } }, targetTitle: 'About', fieldChanges: [], blockChanges: [{ kind: 'changed', tag: 'h2', fields: [{ field: 'textContent', before: 'Old', after: 'New' }] }] })])!
  assert.equal(v.entityName, 'About')
  assert.equal(widgetHeader(v).title, 'Drafted a change to Page “About”')
  assert.equal(v.fields[0].label, 'Heading')
})

check('page content lists the blocks it touched', () => {
  const v = viewFromItems(ref(['i1']), [item({ targetType: 'page-content', after: { title: 'Home' }, fieldChanges: [], blockChanges: [{ kind: 'changed', label: 'Hero heading', fields: [{ field: 'textContent', before: 'Welcome', after: 'Hello' }] }] })])!
  assert.deepEqual(v.fields, [{ field: 'Hero heading', label: 'Hero heading', before: 'Welcome', after: 'Hello' }])
  assert.equal(widgetHeader(v).title, 'Drafted a change to Page “Home”')
})

check('the floor masks secrets in the before/after shape the server builds', () => {
  const floor = VISIBILITY_FLOOR.filter((r) => r.target.kind === 'field')
  const { data } = maskData({ before: { resendApiKey: 'old-key', title: 'A' }, after: { resendApiKey: 'new-key', title: 'B' } }, floor, 'owner')
  assert.notEqual(data.before.resendApiKey, 'old-key')
  assert.notEqual(data.after.resendApiKey, 'new-key')
  assert.equal(data.after.title, 'B')
})

check('an applied change from its revision: its name, its field names, version, Compare and Restore', () => {
  const v = viewFromRevision({ kind: 'revision', revisionId: 'rv1' }, {
    id: 'rv1', entityType: 'form', entityId: 'f 1', entityName: 'Volunteer sign-up', fieldLabels: { fields: 'Questions', display: 'Where it shows' }, version: 3,
    changed: ['title', 'fields.3.label', 'display', 'smtpPassword', 'notes', 'fields'],
    before: { title: 'Volunteer', 'fields.3.label': 'Phone', display: 'inline', notes: null },
    after: { title: 'Volunteer sign-up', 'fields.3.label': 'Mobile', display: 'modal', notes: 'x' },
  }, true)
  assert.equal(v.key, 'rev:rv1')
  assert.equal(v.href, '/admin/forms/f%201')
  assert.deepEqual(v.fields.map((f) => [f.label, f.before, f.after, !!f.hidden]), [
    ['Title', 'Volunteer', 'Volunteer sign-up', false],
    ['Question 4 label', 'Phone', 'Mobile', false],
    ['Where it shows', 'inline', 'modal', false],
    ['Smtp password', '', 'changed (hidden)', true],
  ])
  assert.equal(v.more, 2)
  assert.deepEqual(widgetHeader(v), { title: 'Changed Form “Volunteer sign-up”', sub: 'Version 3 · 6 changes', badge: 'Saved' })
  assert.deepEqual(widgetActions(v), ['open', 'compare', 'restore'])
})

check('Compare lists every line; a null value is a real "—", not hidden', () => {
  const lines = revisionLines({ changed: ['notes', 'apiKey'], before: { notes: null }, after: { notes: 'x' }, fieldLabels: null })
  assert.deepEqual(lines.map((l) => [l.before, l.after, !!l.hidden]), [['—', 'x', false], ['', 'changed (hidden)', true]])
})

check('a revision whose field is a whole object lists its inner changes', () => {
  const lines = revisionLines({ changed: ['display'], before: { display: { mode: 'popup' } }, after: { display: { mode: 'popup', popupDelay: 5, popupFrequency: 'visitor' } }, fieldLabels: { display: 'Where it shows' } })
  assert.deepEqual(lines.map((l) => [l.label, l.before, l.after]), [['Where it shows popup delay', '—', '5'], ['Where it shows popup frequency', '—', 'visitor']])
  assert.equal(entityNameOf({ doc: { name: 'ZZ Change card test (temp)' } }), 'ZZ Change card test (temp)')
})

check('paths, settings and links', () => {
  assert.equal(pathLabel('automations'), 'Automations')
  assert.equal(pathLabel('fields.0'), 'Field 1')
  assert.equal(pathLabel('display.mode', { display: 'Where it shows' }), 'Where it shows mode')
  assert.equal(entityHref('page', 'p1'), '/admin/pages/p1')
  assert.equal(entityHref('settings:identity', 'x'), '/admin/settings')
  assert.equal(entityHref('access', 'user:1'), null)
  assert.equal(entityTypeOf({ targetType: 'settings:identity', targetId: 'x', after: null }), 'Settings')
  assert.equal(entityTypeOf({ targetType: 'email-template', targetId: 'x', after: null }), 'Email template')
})

check('an approved draft gets the revision its apply recorded', () => {
  const pending = viewFromItems(ref(['i1']), [item()])!
  assert.equal(withRevision(pending, { id: 'rv', version: 2 }, true), pending, 'still pending: no revision yet')
  const saved = withRevision(viewFromItems(ref(['i1']), [item({ status: 'approved' })])!, { id: 'rv', version: 2 }, false)
  assert.equal(saved.version, 2)
  assert.deepEqual(widgetActions(saved), ['open', 'compare'], 'no Restore without edit rights')
  const revs = [{ entityType: 'page', entityId: 'p', version: 7 }, { entityType: 'record', entityId: 'r1', version: 3 }]
  assert.equal(pickRevision(revs, 'record', 'r1')?.version, 3)
  assert.equal(pickRevision(revs, 'form', 'x')?.version, 7)
  assert.equal(pickRevision([], 'form', 'x'), null)
})

check('an approved page edit finds the snapshot its apply took (pages keep no change set)', () => {
  const t = (s: number) => new Date(Date.UTC(2026, 9, 11, 12, 0, s))
  const snaps = [
    { id: 'human-save', createdAt: t(50), createdById: 'owner', reason: 'save' },
    { id: 'older-ai', createdAt: t(0), createdById: 'owner', reason: 'ai-edit' },
    { id: 'this-apply', createdAt: t(58), createdById: 'owner', reason: 'ai-edit' },
    { id: 'someone-else', createdAt: t(59), createdById: 'other', reason: 'ai-edit' },
    { id: 'after-decided', createdAt: t(61), createdById: 'owner', reason: 'ai-edit' },
  ]
  assert.equal(pickPageSnapshot(snaps, { decidedAt: t(60), decidedById: 'owner' })?.id, 'this-apply')
  assert.equal(pickPageSnapshot(snaps, { decidedAt: t(60), decidedById: 'owner' }, 1000), null, 'outside the window: none rather than a wrong one')
  assert.equal(pickPageSnapshot(snaps, { decidedAt: null, decidedById: 'owner' }), null)
})

check('review fields: render path, blocks, page, publishes, unchanged and the body they pick (chat v2 P2)', () => {
  const page = viewFromItems(ref([]), [item({ targetType: 'page-content', targetId: 'p1', previewPath: '/about', blockIds: ['b1', 'b2'], operation: 'update', after: { title: 'About', blocks: [] } })])!
  assert.equal(page.target, 'page-content')
  assert.equal(page.previewPath, '/ade-preview/about?set=cs1')
  assert.deepEqual(page.blockIds, ['b1', 'b2'])
  assert.equal(page.pageId, 'p1')
  assert.equal(page.publishes, true)
  assert.equal(kindOf(page), 'preview')
  const draft = viewFromItems(ref([]), [item({ operation: 'create', after: { type: 'initiative', status: 'DRAFT', data: { title: 'Clinic' } } })])!
  assert.equal(draft.publishes, false, 'a new initiative saved as a draft: Approve, not Publish')
  assert.equal(kindOf(draft), 'values', 'no render path → the values body')
  const setting = viewFromItems(ref([]), [item({ targetType: 'site-setting', targetId: 'donations', fieldChanges: [{ field: 'minimumGift', before: 10, after: 20 }], after: { minimumGift: 20, currency: 'GHS', receipts: true, id: 'x' } })])!
  assert.equal(setting.pageId, null)
  assert.deepEqual(setting.unchanged, ['Currency', 'Receipts'], 'bookkeeping (id) is never listed')
  assert.deepEqual(unchangedOf({ data: { title: 'A', summary: 'B', goal: 3 } }, ['summary']), ['Title', 'Goal'])
})

check('a batch: the same edit on several things of one kind, with a few sample rows', () => {
  const rows = ['Kente Tote Bag', 'Beaded Bracelet', 'Shea Butter Set', 'Clay Pot'].map((title, i) =>
    item({ id: `i${i}`, targetId: `r${i}`, after: { type: 'product', data: { title } }, fieldChanges: [{ field: 'price', before: 100 + i, after: 110 + i }] }))
  const b = batchOf(rows)!
  assert.equal(b.count, 4)
  assert.equal(b.noun, 'products')
  assert.deepEqual(b.rows, [{ name: 'Kente Tote Bag', before: '100', after: '110' }, { name: 'Beaded Bracelet', before: '101', after: '111' }, { name: 'Shea Butter Set', before: '102', after: '112' }])
  assert.equal(batchOf([rows[0]]), null)
  assert.equal(batchOf([rows[0], item({ id: 'x', targetId: 'r0' })]), null, 'two edits to the same thing are not a batch')
  assert.equal(batchOf([rows[0], item({ id: 'p', targetType: 'page', targetId: 'p1' })]), null, 'mixed kinds are not a batch')
  assert.equal(batchOf([rows[0], { ...rows[1], isPublish: true }]), null, 'a publish item does not count')
  assert.equal(kindOf(viewFromItems(ref([]), rows)!), 'batch')
})

console.log(`\n${n} checks passed`)
