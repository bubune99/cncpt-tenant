/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/blog-list.assert.ts
 */
import assert from 'node:assert/strict'
import { blogDate, blogState, blogTabCounts, filterPosts, isBlogTab, type BlogListRow } from './blog-list'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const post = (p: Partial<BlogListRow>): BlogListRow => ({
  id: p.slug ?? 'x', title: 'X', slug: 'x', status: 'DRAFT', createdAt: '2026-09-01T00:00:00Z', featured: false, categories: [], ...p,
})
const rows = [
  post({ slug: 'a', title: 'Back to school', status: 'PUBLISHED', publishedAt: '2026-09-20T00:00:00Z', categories: [{ category: { id: 'c1', name: 'News' } }], author: { name: 'Ama', email: 'a@x' } }),
  post({ slug: 'b', title: 'Water update', status: 'PUBLISHED', publishedAt: '2026-10-01T00:00:00Z' }),
  post({ slug: 'c', title: 'Draft idea', status: 'DRAFT', createdAt: '2026-10-05T00:00:00Z' }),
  post({ slug: 'd', title: 'Gala recap', status: 'SCHEDULED', scheduledAt: '2026-11-01T00:00:00Z' }),
  post({ slug: 'e', title: 'Holiday drive', status: 'SCHEDULED', scheduledAt: '2026-10-20T00:00:00Z' }),
  post({ slug: 'z', title: 'Old', status: 'ARCHIVED' }),
]

check('states and counts (archived never counted)', () => {
  assert.equal(blogState(rows[0]), 'live')
  assert.equal(blogState(rows[3]), 'scheduled')
  assert.deepEqual(blogTabCounts(rows), { all: 5, published: 2, drafts: 1, scheduled: 2, archived: 1 })
  assert.deepEqual(filterPosts(rows, 'archived').map((p) => p.slug), ['z'])
})

check('the card date says what it means', () => {
  assert.deepEqual(blogDate(rows[3]), { label: 'Goes live', iso: '2026-11-01T00:00:00Z' })
  assert.deepEqual(blogDate(rows[0]), { label: 'Published', iso: '2026-09-20T00:00:00Z' })
  assert.deepEqual(blogDate(rows[2]), { label: 'Started', iso: '2026-10-05T00:00:00Z' })
})

check('order: newest first; Scheduled = soonest first', () => {
  assert.deepEqual(filterPosts(rows, 'all').map((p) => p.slug), ['d', 'e', 'c', 'b', 'a'])
  assert.deepEqual(filterPosts(rows, 'scheduled').map((p) => p.slug), ['e', 'd'])
})

check('search covers title, excerpt, author and category', () => {
  assert.deepEqual(filterPosts(rows, 'all', 'news').map((p) => p.slug), ['a'])
  assert.deepEqual(filterPosts(rows, 'all', 'AMA').map((p) => p.slug), ['a'])
  assert.equal(filterPosts(rows, 'drafts', 'water').length, 0)
})

check('tabs are validated', () => {
  assert.ok(isBlogTab('scheduled') && !isBlogTab('live'))
})

console.log(`\n${n} checks passed`)
