/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/todo-lanes.assert.ts
 */
import assert from 'node:assert/strict'
import { approvalLane, approvalPublishes, approvedMessage, approveLabel, approveOutcome, approveWhen, batchApproval, decideMove, goesLiveOf, needYouCount, taskLane } from './todo-lanes'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('approval lanes follow the engine state', () => {
  assert.equal(approvalLane({ items: [{ status: 'pending' }], snoozed: false, comments: [] }), 'approve')
  assert.equal(approvalLane({ items: [{ status: 'saved' }], snoozed: true, comments: [] }), 'notnow')
  assert.equal(approvalLane({ items: [{ status: 'saved' }], snoozed: false, comments: [] }), 'approve', 'parked yesterday → back today')
  assert.equal(approvalLane({ items: [{ status: 'saved' }], snoozed: true, comments: [{ kind: 'revise' }] }), 'changes')
  assert.equal(approvalLane({ items: [{ status: 'saved' }, { status: 'pending' }], snoozed: false, comments: [{ kind: 'revise' }] }), 'approve', 'rework arrived')
  assert.equal(approvalLane({ items: [{ status: 'approved' }], snoozed: false, comments: [] }), 'done')
})

check('task lanes by group', () => {
  assert.equal(taskLane('messages', 'open'), 'messages')
  assert.equal(taskLane('fresh', 'open'), 'drafts')
  assert.equal(taskLane('attention', 'open'), 'attention')
  assert.equal(taskLane('messages', 'done'), 'done')
})

check('board moves map onto the approval engine; approving still confirms', () => {
  const a = { kind: 'approval' as const, canApprove: true }
  assert.deepEqual(decideMove(a, 'approve', 'done'), { kind: 'act', action: 'approve', confirm: true })
  assert.deepEqual(decideMove(a, 'approve', 'notnow'), { kind: 'act', action: 'notNow', confirm: false })
  assert.deepEqual(decideMove(a, 'notnow', 'changes'), { kind: 'act', action: 'askForChanges', confirm: false, needsText: true })
  assert.equal(decideMove(a, 'changes', 'notnow').kind, 'refuse')
  assert.deepEqual(decideMove(a, 'notnow', 'approve'), { kind: 'act', action: 'resume', confirm: false })
  assert.equal(decideMove(a, 'changes', 'approve').kind, 'refuse')
  assert.equal(decideMove(a, 'approve', 'messages').kind, 'refuse')
  assert.equal(decideMove({ kind: 'approval', canApprove: false }, 'approve', 'done').kind, 'refuse')
  assert.equal(decideMove(a, 'done', 'approve').kind, 'refuse')
  assert.deepEqual(decideMove(a, 'approve', 'approve'), { kind: 'none' })
})

check('tasks can only be marked done', () => {
  const t = { kind: 'task' as const }
  assert.deepEqual(decideMove(t, 'messages', 'done'), { kind: 'act', action: 'taskDone', confirm: false })
  assert.equal(decideMove(t, 'messages', 'notnow').kind, 'refuse')
})

check('"need you" counts open work, not parked or done', () => {
  assert.equal(needYouCount([{ lane: 'approve' }, { lane: 'notnow' }, { lane: 'changes' }, { lane: 'messages' }, { lane: 'done' }]), 2)
})

check('approving says "live" only when something goes public', () => {
  // New initiative without its publish step: record + page created as drafts.
  assert.equal(approvalPublishes([
    { operation: 'create', targetType: 'record', after: { status: 'DRAFT' } },
    { operation: 'create', targetType: 'page', after: { status: 'DRAFT' } },
  ]), false)
  // Edits to a record that is still a draft.
  assert.equal(approvalPublishes([{ operation: 'update', targetType: 'record', after: { status: 'DRAFT' } }]), false)
  // A publish step, an edit to live page content, or a published record → live.
  assert.equal(approvalPublishes([{ operation: 'create', targetType: 'record', after: { status: 'DRAFT' } }, { operation: 'update', targetType: 'record-status', isPublish: true }]), true)
  assert.equal(approvalPublishes([{ operation: 'update', targetType: 'page-content', after: { content: {} } }]), true)
  assert.equal(approvalPublishes([{ operation: 'update', targetType: 'record', after: { status: 'PUBLISHED' } }]), true)
})

check('labels and messages follow publishes (tasks and unknowns read as publishing)', () => {
  assert.equal(approveLabel({ publishes: false }), 'Approve')
  assert.equal(approveLabel({ publishes: true }), 'Approve & publish')
  assert.equal(approveLabel({ kind: 'task' }), 'Approve & publish')
  assert.equal(approveLabel(null), 'Approve & publish')
  assert.equal(approvedMessage({ publishes: false }), 'Approved — saved as a draft (not on the site yet).')
  assert.equal(approvedMessage({ publishes: true }), 'Approved — it’s live.')
  assert.equal(approvedMessage({ publishes: false }, 3), 'Approved 3 — saved as drafts (not on the site yet).')
})

check('a scheduled approval says "Approve & schedule" and the toast names the go-live time (staging 2026-10-23)', () => {
  const at = '2026-10-23T11:38:00.000Z'
  // Page / record: status stays DRAFT, scheduledAt set; post: SCHEDULED. Worded in the chosen zone.
  assert.equal(goesLiveOf([{ category: 'pages', after: { content: {} } }, { category: 'publish', after: { status: 'DRAFT', scheduledAt: at }, input: { tz: 'America/New_York' } }]), 'Goes live Fri 23 Oct, 7:38 New York time')
  assert.equal(goesLiveOf([{ category: 'publish', after: { status: 'SCHEDULED', scheduledAt: at }, input: { tz: 'Africa/Accra' } }]), 'Goes live Fri 23 Oct, 11:38 Accra time')
  // Publishing now (even a post whose old schedule is carried along) and unpublishing are not scheduling.
  assert.equal(goesLiveOf([{ category: 'publish', after: { status: 'PUBLISHED', scheduledAt: at } }]), null)
  assert.equal(goesLiveOf([{ category: 'publish', after: { status: 'DRAFT' } }]), null)
  const item = { publishes: true, goesLive: 'Goes live Fri 23 Oct, 7:38 New York time' }
  assert.equal(approveLabel(item), 'Approve & schedule')
  assert.equal(approvedMessage(item), 'Approved — goes live Fri 23 Oct, 7:38 New York time.')
  assert.equal(approveOutcome(item), 'It goes live Fri 23 Oct, 7:38 New York time.')
  assert.equal(approveOutcome({ publishes: true, goesLive: null }), 'It goes live now.')
  assert.equal(approveOutcome({ publishes: false }), 'It’s saved as a draft — not on the site yet.')
  assert.equal(approveLabel({ publishes: true, goesLive: null }), 'Approve & publish')
})

check('approving several: scheduled ones list their go-live time, only immediate ones "go live now"', () => {
  const now = { publishes: true, goesLive: null }
  const later = { publishes: true, goesLive: 'Goes live Fri 23 Oct, 7:38 New York time' }
  const draft = { publishes: false }
  assert.equal(approveWhen(now), 'Goes live now')
  assert.equal(approveWhen(later), 'Goes live Fri 23 Oct, 7:38 New York time')
  assert.equal(approveWhen(draft), 'Saved as a draft — not on the site yet')
  assert.deepEqual(batchApproval([now, now]), { label: 'Approve & publish', intro: 'These go live now:', message: 'Approved 2 — 2 live now.' })
  assert.deepEqual(batchApproval([later, later]), { label: 'Approve & schedule', intro: 'These go live at their scheduled times:', message: 'Approved 2 — 2 scheduled.' })
  assert.deepEqual(batchApproval([now, later, draft]), { label: 'Approve & publish', intro: 'Each goes live as shown:', message: 'Approved 3 — 1 live now, 1 scheduled, 1 saved as draft.' })
  assert.deepEqual(batchApproval([later]), { label: 'Approve & schedule', intro: 'This goes live Fri 23 Oct, 7:38 New York time:', message: 'Approved — goes live Fri 23 Oct, 7:38 New York time.' })
  assert.equal(batchApproval([draft, draft]).intro, 'These are saved as drafts — not on the site yet:')
  assert.equal(batchApproval([draft, draft]).label, 'Approve')
  assert.doesNotMatch(batchApproval([later, later]).intro, /now/)
})

console.log(`\n${n} checks passed`)
