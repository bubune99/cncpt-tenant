/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/agent-activity.assert.ts
 */
import assert from 'node:assert/strict'
import { agentActivitySentence, auditRunId, budgetPercent, costLabel, messageRunId, parseAgentSummary, runHref, showAgentActivity } from './agent-activity'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// Stub of GET /api/admin/agent-activity/summary (forms-pkg).
const stub = {
  since: '2026-10-11T00:00:00.000Z',
  runs: 12,
  failures: [
    { id: 'run_a', request: 'Make the Akuse hero brighter', at: '2026-10-11T09:12:00Z', status: 'error' },
    { id: 'run_b', request: 'Draft a post', at: '2026-10-11T08:00:00Z', status: 'budget' },
  ],
  writes: 5,
  draftsAwaiting: 3,
  spend: { tokens: 240_000, cost: 0.42, budgetTokens: 500_000, people: 2 },
}

check('parses the summary; drops junk failures; defaults missing counts', () => {
  const s = parseAgentSummary({ ...stub, failures: [...stub.failures, { request: 'no id' }, null] })!
  assert.equal(s.failures.length, 2)
  assert.equal(s.failures[0].status, 'error')
  assert.deepEqual(parseAgentSummary({ runs: 1 }), { runs: 1, failures: [], failedCount: 0, writes: 0, draftsAwaiting: 0, spend: { tokens: 0, cost: 0, budgetTokens: 0, people: 0 } })
  for (const bad of [null, 'x', {}, { runs: -1 }, { runs: 'many' }, { aiEnabled: false, runs: 3 }]) assert.equal(parseAgentSummary(bad), null)
})

check('hidden when AI is off or nothing ran — the CMS works without AI', () => {
  const s = parseAgentSummary(stub)
  assert.equal(showAgentActivity(s, true), true)
  assert.equal(showAgentActivity(s, false), false)
  assert.equal(showAgentActivity(parseAgentSummary({ runs: 0 }), true), false)
  assert.equal(showAgentActivity(null, true), false)
})

check('one plain sentence', () => {
  assert.equal(agentActivitySentence(parseAgentSummary(stub)!), 'The assistant worked 12 times today — 2 failed, 5 changes made, 3 drafts are waiting for your review. About $0.42 · 24% of today’s budget.')
  assert.equal(agentActivitySentence(parseAgentSummary({ runs: 1, writes: 1, draftsAwaiting: 1 })!), 'The assistant worked once today — 1 change made, 1 draft is waiting for your review.')
  assert.equal(agentActivitySentence(parseAgentSummary({ runs: 2 })!), 'The assistant worked 2 times today.')
})

check('failed counts the server total, not the 10-item list', () => {
  const many = parseAgentSummary({ runs: 30, failedCount: 14, failures: [{ id: 'a', request: 'x', at: '2026-10-11T00:00:00Z', status: 'error' }] })!
  assert.equal(many.failedCount, 14)
  assert.match(agentActivitySentence(many), /— 14 failed/)
  assert.equal(parseAgentSummary({ runs: 3 })!.failedCount, 0)
})

check('budget share: per-person budget × people; unlimited → null; over budget shows over 100', () => {
  assert.equal(budgetPercent({ tokens: 240_000, cost: 0, budgetTokens: 500_000, people: 2 }), 24)
  assert.equal(budgetPercent({ tokens: 600_000, cost: 0, budgetTokens: 500_000, people: 0 }), 120)
  assert.equal(budgetPercent({ tokens: 10, cost: 0, budgetTokens: 0, people: 3 }), null)
})

check('cost wording', () => {
  assert.equal(costLabel(0), '')
  assert.equal(costLabel(0.004), 'under 1¢')
  assert.equal(costLabel(1.5), 'about $1.50')
})

check('run links', () => {
  assert.equal(runHref('run_a'), '/admin/agent-activity?run=run_a')
  assert.equal(runHref('a b/c'), '/admin/agent-activity?run=a%20b%2Fc')
})

check('only assistant messages with a run id link', () => {
  assert.equal(messageRunId({ role: 'assistant', metadata: { runId: 'run_a' } }), 'run_a')
  assert.equal(messageRunId({ role: 'user', metadata: { runId: 'run_a' } }), null)
  assert.equal(messageRunId({ role: 'assistant', metadata: {} }), null)
  assert.equal(messageRunId({ role: 'assistant' }), null)
  assert.equal(messageRunId(null), null)
})

check('only audit rows that carry a run id link', () => {
  assert.equal(auditRunId({ source: 'agent', details: { runId: 'run_a' } }), 'run_a')
  assert.equal(auditRunId({ source: 'admin', details: { field: 'title' } }), null)
  assert.equal(auditRunId({ details: null }), null)
  assert.equal(auditRunId({ details: { runId: '' } }), null)
})

console.log(`\n${n} checks passed`)
