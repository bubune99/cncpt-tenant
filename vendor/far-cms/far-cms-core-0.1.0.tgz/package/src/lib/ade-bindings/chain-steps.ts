/**
 * This app's plain words for the thought chain (lib/ade/chat/thought-chain):
 * a step title per tool, what it looked at, and where the person can do it
 * by hand when a step fails. Tools not listed fall back to the core's
 * verb-based title, never the tool's name.
 */

import type { ChainDeps } from '../ade/chat/thought-chain'

type Input = Record<string, unknown>
const s = (v: unknown) => (typeof v === 'string' ? v.trim() : '')
/** "blog_post" / "initiative" → "blog posts" / "initiatives". */
const plural = (t: string) => {
  const w = t.replace(/[_-]+/g, ' ').toLowerCase()
  return /s$/.test(w) ? w : /y$/.test(w) ? `${w.slice(0, -1)}ies` : `${w}s`
}
const kindOf = (i: Input) => s(i.entityType) || s(i.recordType) || s(i.type)
const q = (v: unknown) => (s(v) ? ` for “${s(v).slice(0, 40)}”` : '')

const TITLES: Record<string, (i: Input) => string> = {
  read_view: () => 'Look at the screen',
  capture_view: () => 'Look at how it looks',
  scan_page: () => 'Look over the page',
  navigateTo: () => 'Go to the page',
  navigate_to_route: () => 'Go to the page',
  operate_ui: () => 'Use the screen',
  spotlight_steps: () => 'Point it out on screen',
  spotlight_step: () => 'Show one step, then wait for you',
  // Its failure text already says how to do it by hand (lib/ade/ui/control), so no MANUAL entry.
  show_unit: (i) => (s(i.unit) ? `Point at ${s(i.unit).slice(0, 40)}` : 'Point it out on screen'),
  open_menu: () => 'Open the menu',
  open_tab: () => 'Open the tab',
  expand: () => 'Open the section',
  collapse: () => 'Close the section',
  scroll_to: () => 'Scroll to it',
  coverage_check: () => 'Check what the screen covers',
  describe_platform: () => 'Check how the platform works',
  listNavigationTabs: () => 'Check the menu',
  getSiteContext: () => 'Check the site’s setup',
  getDashboardStats: () => 'Check the numbers',
  getRecentActivity: () => 'Check recent activity',
  searchEntities: (i) => (kindOf(i) ? `Search ${plural(kindOf(i))}${q(i.query)}` : `Search the site${q(i.query)}`),
  getEntityStats: (i) => (kindOf(i) ? `Count the ${plural(kindOf(i))}` : 'Count them'),
  getEntityDetails: () => 'Open the record',
  searchProducts: (i) => `Search products${q(i.query)}`,
  searchOrders: (i) => `Search orders${q(i.query)}`,
  listInitiatives: () => 'Check the initiatives',
  listRecordTypes: () => 'Check the kinds of records',
  listRecords: (i) => (kindOf(i) ? `Check the ${plural(kindOf(i))}` : 'Check the records'),
  getRecord: () => 'Open the record',
  listForms: () => 'Check the forms',
  getForm: () => 'Open the form',
  getPageBlocks: () => 'Read the page',
  getSiteLayoutBlocks: () => 'Read the header and footer',
  createPage: () => 'Draft a new page',
  updatePage: () => 'Draft changes to the page',
  duplicatePage: () => 'Draft a copy of the page',
  publishPage: () => 'Ask to publish the page',
  updateBlock: () => 'Draft a change on the page',
  insertBlock: () => 'Draft a new section',
  find_blocks: () => 'Look for a block to use',
  suggest_layouts: () => 'Sketch some layout ideas',
  add_block: () => 'Add the block',
  save_block: () => 'Save it as a block',
  createRecordWithPage: (i) => (kindOf(i) ? `Draft the ${kindOf(i).replace(/[_-]+/g, ' ')} page` : 'Draft the page'),
  updateRecord: () => 'Draft changes to the record',
  publishRecord: () => 'Ask to publish it',
  setFeaturedInitiatives: () => 'Draft the featured initiatives',
  createBlogPost: () => 'Draft a blog post',
  updateBlogPost: () => 'Draft changes to the post',
  publishBlogPost: () => 'Ask to publish the post',
  messageSiteOwner: () => 'Write to the site owner',
  send_feedback_to_owner: () => 'Pass your feedback on',
  explain_access: () => 'Check who can do what',
  draft_access_change: () => 'Draft an access change',
}

/** "Looked at" in a step's details: the thing, not the action. */
const LOOKED: Record<string, (i: Input) => string> = {
  read_view: () => 'The screen',
  show_unit: (i) => (s(i.unit) ? `“${s(i.unit).slice(0, 40)}” on this screen` : 'This screen'),
  capture_view: () => 'A picture of the screen',
  scan_page: () => 'The page',
  describe_platform: () => 'How the platform works',
  listNavigationTabs: () => 'The menu',
  getSiteContext: () => 'The site’s setup',
  getDashboardStats: () => 'The dashboard numbers',
  searchEntities: (i) => `${kindOf(i) ? plural(kindOf(i)) : 'The site'}${q(i.query)}`.replace(/^./, (c) => c.toUpperCase()),
  getEntityStats: (i) => (kindOf(i) ? `The number of ${plural(kindOf(i))}` : 'The counts'),
  listInitiatives: () => 'The initiatives list',
  listRecords: (i) => (kindOf(i) ? `The ${plural(kindOf(i))} list` : 'The records list'),
  listForms: () => 'The forms list',
  getRecord: () => 'The record',
  getEntityDetails: () => 'The record',
  getForm: () => 'The form',
  getPageBlocks: () => 'The page’s sections',
  getSiteLayoutBlocks: () => 'The header and footer',
}

/** Where to do it by hand, by the kind of thing the failed step was working on. */
const MANUAL: ReadonlyArray<readonly [RegExp, string]> = [
  [/Page|Block/, 'You can do it yourself in Pages: open the page and edit it there.'],
  [/BlogPost|Blog/, 'You can do it yourself in Blog: open the post and edit it there.'],
  [/Initiative|Record/, 'You can do it yourself: open the record from its list and edit it there.'],
  [/Form/, 'You can do it yourself in Forms.'],
  [/Settings|SiteLayout|NavigationTab/, 'You can do it yourself in Settings.'],
  [/Product/, 'You can do it yourself in Products.'],
  [/Order/, 'You can do it yourself in Orders.'],
  [/^(read_view|capture_view|open_|expand|collapse|scroll_to|spotlight_steps|spotlight_step|navigate)/, 'You can find it yourself from the menu on the left.'],
]

export const CHAIN_STEP_DEPS: ChainDeps = {
  titleOf: (name, input) => TITLES[name]?.(input) ?? null,
  lookedAtOf: (name, input) => LOOKED[name]?.(input) ?? null,
  manualPathOf: (name) => MANUAL.find(([re]) => re.test(name))?.[1] ?? null,
}
