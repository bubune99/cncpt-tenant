/**
 * Blog posts list: tabs, counts, search and the Live/Draft/Scheduled state,
 * as pure rules (the screen and the assistant agree on what "Scheduled"
 * shows). Same direction as the records list. Asserted by blog-list.assert.ts.
 */

export interface BlogListRow {
  id: string
  title: string
  slug: string
  excerpt?: string | null
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED' | 'SCHEDULED' | string
  publishedAt?: string | null
  scheduledAt?: string | null
  createdAt: string
  featured: boolean
  author?: { name?: string | null; email: string } | null
  categories: Array<{ category: { id: string; name: string } }>
  featuredImage?: { url: string; alt?: string | null } | null
}

export const BLOG_TABS = [
  { id: 'all', label: 'All' },
  { id: 'published', label: 'Published' },
  { id: 'drafts', label: 'Drafts' },
  { id: 'scheduled', label: 'Scheduled' },
  // Shown only when there are any (e.g. the old initiative posts).
  { id: 'archived', label: 'Archived' },
] as const
export type BlogTab = (typeof BLOG_TABS)[number]['id']

export function isBlogTab(v: unknown): v is BlogTab {
  return typeof v === 'string' && BLOG_TABS.some((t) => t.id === v)
}

export type BlogState = 'live' | 'draft' | 'scheduled' | 'archived'

/** Live / Draft / Scheduled as a person says it. A scheduled date in the past with status PUBLISHED is just live. */
export function blogState(p: Pick<BlogListRow, 'status'>): BlogState {
  if (p.status === 'PUBLISHED') return 'live'
  if (p.status === 'SCHEDULED') return 'scheduled'
  if (p.status === 'ARCHIVED') return 'archived'
  return 'draft'
}

export const BLOG_STATE_LABEL: Record<BlogState, string> = { live: 'Live', draft: 'Draft', scheduled: 'Scheduled', archived: 'Archived' }

export function inBlogTab(p: BlogListRow, tab: BlogTab): boolean {
  const s = blogState(p)
  if (tab === 'all') return s !== 'archived'
  if (tab === 'published') return s === 'live'
  if (tab === 'drafts') return s === 'draft'
  if (tab === 'archived') return s === 'archived'
  return s === 'scheduled'
}

export function blogTabCounts(rows: readonly BlogListRow[]): Record<BlogTab, number> {
  const out = Object.fromEntries(BLOG_TABS.map((t) => [t.id, 0])) as Record<BlogTab, number>
  for (const r of rows) for (const t of BLOG_TABS) if (inBlogTab(r, t.id)) out[t.id]++
  return out
}

/** The date a card shows: when it went live, when it will, or when it was started. */
export function blogDate(p: BlogListRow): { label: string; iso: string } {
  const s = blogState(p)
  if (s === 'scheduled' && p.scheduledAt) return { label: 'Goes live', iso: p.scheduledAt }
  if (s === 'live' && p.publishedAt) return { label: 'Published', iso: p.publishedAt }
  return { label: 'Started', iso: p.createdAt }
}

function matches(p: BlogListRow, q: string): boolean {
  const s = q.trim().toLowerCase()
  if (!s) return true
  return [p.title, p.slug, p.excerpt, p.author?.name, ...p.categories.map((c) => c.category.name)].some((v) => typeof v === 'string' && v.toLowerCase().includes(s))
}

/** Rows for a tab + search: scheduled soonest first in Scheduled; otherwise newest date first. */
export function filterPosts(rows: readonly BlogListRow[], tab: BlogTab, query = ''): BlogListRow[] {
  return rows
    .filter((p) => inBlogTab(p, tab) && matches(p, query))
    .slice()
    .sort((a, b) => (tab === 'scheduled' ? blogDate(a).iso.localeCompare(blogDate(b).iso) : blogDate(b).iso.localeCompare(blogDate(a).iso)))
}
