/**
 * The old blog-backed initiative screens (/admin/blog/initiatives*) now
 * resolve to the initiative RECORDS (owner, 2026-10-10). Old links carry a
 * blog-post id; the record migrated from it has legacyRef "blog-post:<id>".
 * Pure mapping (the page does the lookup); never a 404 — a post with no
 * record opens in the post editor. Asserted by legacy-initiatives.assert.ts.
 */

export const RECORDS_PATH = '/admin/records/initiative'

export type LegacyInitiativeRoute = { kind: 'list' } | { kind: 'new' } | { kind: 'post'; postId: string; recordId: string | null }

/** legacyRef a migrated record carries for a blog post. */
export function legacyRefFor(postId: string): string {
  return `blog-post:${postId}`
}

export function legacyInitiativeTarget(route: LegacyInitiativeRoute): string {
  switch (route.kind) {
    case 'list':
      return RECORDS_PATH
    case 'new':
      return `${RECORDS_PATH}/new`
    case 'post':
      return route.recordId ? `${RECORDS_PATH}/${encodeURIComponent(route.recordId)}` : `/admin/blog/${encodeURIComponent(route.postId)}`
  }
}
