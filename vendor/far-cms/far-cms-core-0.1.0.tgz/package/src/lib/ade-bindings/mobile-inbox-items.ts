/**
 * One form submission as a mobile Inbox row (lib/ade/mobile/inbox). Pure;
 * asserted by mobile-inbox.assert.ts. Data comes in already masked for the
 * person, so a masked address never becomes a reply address.
 */

import { contactOf, type Answers } from '../forms/automations'
import { inboxStatus, messageOf } from '../forms/inbox'
import type { InboxItem } from '../ade/mobile/inbox'

export interface SubmissionRow {
  id: string
  formId: string
  formName: string
  data: Answers
  status: string
  read: boolean
  createdAt: Date
  fields: Parameters<typeof contactOf>[0]
}

/** One submission as an inbox row (pure; masked data in, so masked values never become an address). */
export function submissionItem(r: SubmissionRow): InboxItem {
  const c = contactOf(r.fields, r.data)
  const status = inboxStatus({ status: r.status, read: r.read })
  const email = c.email && !/\[private\]/i.test(c.email) ? c.email : null
  const hidden = JSON.stringify(r.data ?? {}).includes('[private]')
  return {
    id: `submission:${r.formId}:${r.id}`,
    segment: 'customers',
    sourceLabel: r.formName,
    from: c.name || 'Someone',
    subject: r.formName,
    preview: messageOf(r.fields, r.data).slice(0, 200),
    at: r.createdAt.toISOString(),
    unread: status === 'new',
    needsReply: status !== 'replied' && !!email,
    canReply: !!email,
    ...(hidden ? { private: true } : {}),
    href: `/admin/forms/${encodeURIComponent(r.formId)}?tab=submissions&submission=${encodeURIComponent(r.id)}`,
  }
}
