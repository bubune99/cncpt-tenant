/**
 * Which revisions one agent tool call recorded. guardTools runs each call
 * inside captureRevisions; recordRevision notes every revision it writes. So
 * a tool that saves through a history chokepoint (writeForm, settings,
 * partials…) hands back the ids of what it actually saved, without each tool
 * plumbing them through — and the chat's change cards are built from those.
 */
import { AsyncLocalStorage } from 'node:async_hooks'
import type { RecordedRevision } from '../ade/chat/change-widgets'

const store = new AsyncLocalStorage<RecordedRevision[]>()

export async function captureRevisions<T>(fn: () => Promise<T>): Promise<{ result: T; revisions: RecordedRevision[] }> {
  const revisions: RecordedRevision[] = []
  const result = await store.run(revisions, fn)
  return { result, revisions }
}

/** Called by recordRevision; outside a captured tool call it does nothing. */
export function noteRevision(r: RecordedRevision): void {
  store.getStore()?.push(r)
}

/** The revisions the current tool call has recorded so far (empty outside a captured call). */
export function peekRevisions(): readonly RecordedRevision[] {
  return store.getStore()?.slice() ?? []
}

/**
 * Auto needs Undo (agent modes, rule 3): an Auto change runs inside withVersionRequired. A write chokepoint
 * that could not record its version calls noteVersionMissing and does not leave the change live (pages
 * snapshot first and skip the write; blog posts put the old values back). guardTools then falls back to
 * Accept changes for that call (lib/ai/governance/agent-mode-gates autoVersionFallback).
 */
const required = new AsyncLocalStorage<{ missing: boolean } | null>()

export async function withVersionRequired<T>(fn: () => Promise<T>): Promise<{ result: T; missing: boolean }> {
  const state = { missing: false }
  const result = await required.run(state, fn)
  return { result, missing: state.missing }
}

/** Is the current write one that must leave a version behind? */
export function versionRequired(): boolean {
  return !!required.getStore()
}

export function noteVersionMissing(): void {
  const s = required.getStore()
  if (s) s.missing = true
}

/** Run a repair write (putting old values back) outside the requirement. */
export function withoutVersionRequired<T>(fn: () => Promise<T>): Promise<T> {
  return required.run(null, fn)
}
