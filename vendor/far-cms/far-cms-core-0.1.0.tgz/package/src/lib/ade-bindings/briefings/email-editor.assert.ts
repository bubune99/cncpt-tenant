/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/briefings/email-editor.assert.ts
 */
import assert from 'node:assert/strict'
import { leadText } from '../../ade/briefing'
import { SCREENS } from '../../ade/screens'
import { SCREEN_BRIEFINGS } from '../screen-briefings'
import { campaignIdFrom, checkCards, emailBriefing, emailEditorBriefing, emailLead, isRequired, readiness, suggestSubject } from './email-editor'

let n = 0
const check = async (name: string, fn: () => void | Promise<void>) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }

const SUBJECT = 'Your support reached Akuse Hospital this month — 1,200 supply kits delivered'
const CHECKS = {
  audienceCount: 1284,
  checks: [
    { id: 'sender-verified', label: 'Sender email isn’t verified', ok: false, detail: 'Test sends work, but campaigns can’t go out until Settings › Email has a verified sender.', fixHref: '/admin/settings?section=email' },
    { id: 'subject-length', label: 'Subject is 47 characters', ok: false, detail: null },
    { id: 'unsubscribe-link', label: 'Has an unsubscribe link', ok: true },
  ],
}

async function main() {
  await check('subject suggestion: drop the clause after the em dash, cut at a word, no dangling “this”', () => {
    assert.equal(suggestSubject(SUBJECT), 'Your support reached Akuse Hospital')
    assert.equal(suggestSubject('Short and sweet'), null, 'already fits')
    assert.equal(suggestSubject('Join us for the spring mission trip to Ghana and help the nurses'), 'Join us for the spring mission trip')
    assert.equal(suggestSubject('Everything you wanted to know — and a bit more'), 'Everything you wanted to know')
    assert.ok((suggestSubject('A'.repeat(60)) ?? '').length <= 40)
    for (const s of [SUBJECT, 'Join us for the spring mission trip to Ghana and help the nurses']) assert.ok(suggestSubject(s)!.length <= 40)
  })

  await check('the sentence as in the design', () => {
    assert.equal(leadText(emailLead('October update', 1284, { kind: 'blocked', count: 2 })), 'You’re writing the October update to 1,284 subscribers. Two things before it can go out:')
    assert.equal(leadText(emailLead('October update', 1, { kind: 'blocked', count: 1 })), 'You’re writing the October update to 1 subscriber. One thing before it can go out:')
    assert.equal(leadText(emailLead('October update', null, { kind: 'ready' })), 'You’re writing the October update. It’s ready to go out when you are.')
  })

  await check('cards: failing checks only; sender → settings link; subject → Use suggestion via the editor capability', () => {
    const cards = checkCards(CHECKS.checks, SUBJECT)
    assert.deepEqual(cards.map((c) => c.id), ['sender-verified', 'subject-length'])
    assert.deepEqual(cards[0].actions, [{ label: 'Open email settings', href: '/admin/settings?section=email' }])
    assert.equal(cards[1].detail, 'Phones cut it off after about 40. Try “Your support reached Akuse Hospital” (35).')
    assert.deepEqual(cards[1].actions, [{ label: 'Use suggestion', ui: { capability: 'email.set_subject', args: { subject: 'Your support reached Akuse Hospital' } } }])
    // Unknown failing checks still show, with a generic fix link when there is one.
    const other = checkCards([{ id: 'alt-text', label: '2 images have no description', ok: false, fixHref: '#images' }], SUBJECT)
    assert.deepEqual(other[0].actions, [{ label: 'Fix this', href: '#images' }])
  })

  await check('chips: two ask the assistant, "Send me a test" runs the editor’s capability', () => {
    const b = emailBriefing({ id: 'c1', name: 'October update', subject: SUBJECT }, CHECKS)
    assert.deepEqual(b.chips.map((c) => c.label), ['Pull in this month’s initiatives', 'Write the intro for me', 'Send me a test'])
    assert.ok('ask' in b.chips[0] && 'ask' in b.chips[1])
    assert.deepEqual('ui' in b.chips[2] && b.chips[2].ui, { capability: 'email.send_test', args: {} })
  })

  await check('provider: reads the campaign + checks (stubbed fetch); not on /new; survives a missing checks route', async () => {
    const calls: string[] = []
    const fetchJson = async (url: string) => {
      calls.push(url)
      if (url.endsWith('/checks')) return CHECKS
      return { success: true, campaign: { id: 'c1', name: 'October update', subject: SUBJECT } }
    }
    const b = await emailEditorBriefing({ pathname: '/admin/email-marketing/c1' }, { fetchJson })
    assert.deepEqual(calls.sort(), ['/api/emails/campaigns/c1', '/api/emails/campaigns/c1/checks'])
    assert.equal(leadText(b!.lead), 'You’re writing the October update to 1,284 subscribers. Two things before it can go out:')
    assert.equal(await emailEditorBriefing({ pathname: '/admin/email-marketing/new' }, { fetchJson }), null)
    const noChecks = await emailEditorBriefing({ pathname: '/admin/email-marketing/c1' }, { fetchJson: async (u) => (u.endsWith('/checks') ? { error: 'Not found' } : fetchJson(u)) })
    // A missing /checks route is "couldn't check", never "ready".
    assert.doesNotMatch(leadText(noChecks!.lead), /ready/i)
    assert.equal(leadText(noChecks!.lead), 'You’re writing the October update.')
    assert.deepEqual(noChecks!.cards.map((c) => c.id), ['checks-unknown'])
    assert.equal(campaignIdFrom('/admin/email-marketing/c1/'), 'c1')
    assert.equal(campaignIdFrom('/admin/email-marketing/c1/design'), 'c1')
    assert.equal(campaignIdFrom('/admin/email-marketing/templates'), null)
  })

  await check('every briefing a screen names is registered', () => {
    for (const s of SCREENS) if (s.briefing) assert.ok(SCREEN_BRIEFINGS[s.briefing], s.key)
  })

  await check('never "ready" unless checks loaded and every required one passed', async () => {
    const camp = { id: 'c1', name: 'Test campaign (temp)', subject: 'Hi' }
    for (const bad of [null, { error: 'Not found' }, { checks: 'nope' }, {}, { checks: [] }]) {
      const b = await emailEditorBriefing({ pathname: '/admin/email-marketing/c1/design' }, { fetchJson: async (u) => (u.endsWith('/checks') ? bad : { campaign: camp }) })
      assert.equal(leadText(b!.lead), 'You’re writing the Test campaign (temp).', JSON.stringify(bad))
      assert.ok(!b!.cards.some((c) => /ready to go out/i.test(c.title)))
    }
    assert.deepEqual(readiness(null), { kind: 'unknown' })
    assert.deepEqual(readiness({ checks: [] }), { kind: 'unknown' })
    assert.deepEqual(readiness({ checks: [{ id: 'a', label: 'A', ok: true }] }), { kind: 'ready' })
    // Advice-only failures don't block; required ones (default) do.
    assert.deepEqual(readiness({ checks: [{ id: 'a', label: 'A', ok: true }, { id: 'tip', label: 'Tip', ok: false, required: false }] }), { kind: 'ready' })
    assert.deepEqual(readiness({ checks: [{ id: 'addr', label: 'No postal address', ok: false }, { id: 'tip', label: 'Tip', ok: false, required: false }] }), { kind: 'blocked', count: 1 })
    const blocked = emailBriefing(camp, { checks: [{ id: 'tip', label: 'Tip', ok: false, required: false }, { id: 'addr', label: 'No postal address', ok: false }] })
    assert.equal(leadText(blocked.lead), 'You’re writing the Test campaign (temp). One thing before it can go out:')
    assert.deepEqual(blocked.cards.map((c) => c.id), ['addr', 'tip'], 'required first')
  })

  await check('the send pipeline’s real shape (level: required | warning): warnings advise, required blocks', async () => {
    // As src/lib/email/checks.ts returns them (ids, labels and levels copied).
    const pass = (id: string, label: string) => ({ id, label, ok: true, level: 'required' as const })
    const base = [
      pass('audience', 'Goes to 12 subscribers'),
      pass('html', 'The email has content'),
      pass('address', 'Postal address and unsubscribe link'),
      pass('images-alt', 'Every image has alt text'),
      pass('sender-verified', 'Sent from hello@projectdzidzor.org'),
      pass('subject', 'Has a subject line'),
      pass('test-sent', 'Test email sent'),
      pass('phone-width', 'Fits a phone screen'),
    ]
    const camp = { id: 'c1', name: 'Test campaign (temp)', subject: SUBJECT }
    // A warning failing alone → still ready.
    const warnOnly = { checks: [...base, { id: 'subject-length', label: 'Subject is 47 characters', ok: false, level: 'warning' as const, detail: 'Phones show about 40; the end may be cut off.' }, { id: 'preview-text', label: 'No preview text', ok: false, level: 'warning' as const }] }
    assert.deepEqual(readiness(warnOnly), { kind: 'ready' })
    const w = emailBriefing(camp, warnOnly)
    assert.equal(leadText(w.lead), 'You’re writing the Test campaign (temp). It’s ready to go out when you are.')
    assert.deepEqual(w.cards.map((c) => c.id), ['subject-length', 'preview-text'], 'warnings still shown as advice')
    // A required one failing → blocks (and comes before the warnings).
    const blocked = { checks: warnOnly.checks.map((c) => (c.id === 'address' ? { id: 'address', label: 'No postal address yet', ok: false, level: 'required' as const, detail: 'The law needs your postal address…', fixHref: '/admin/settings?section=contact' } : c)) }
    assert.deepEqual(readiness(blocked), { kind: 'blocked', count: 1 })
    const b = emailBriefing(camp, blocked)
    assert.equal(leadText(b.lead), 'You’re writing the Test campaign (temp). One thing before it can go out:')
    assert.equal(b.cards[0].id, 'address')
    // Field precedence.
    assert.equal(isRequired({ level: 'required' }), true)
    assert.equal(isRequired({ level: 'warning' }), false)
    assert.equal(isRequired({ required: true }), true)
    assert.equal(isRequired({ required: false }), false)
    assert.equal(isRequired({}), true, 'neither field → required (fail safe)')
    assert.equal(isRequired({ level: 'warning', required: true }), true)
  })

  console.log(`\n${n} checks passed`)
}
void main()
