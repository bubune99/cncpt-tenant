/**
 * The email campaign editor's assistant briefing (owner-approved design,
 * ref-shots-2026-10-09/dzidzor-email/editor-2560.png, left column):
 *
 *   You're writing the **October update** to 1,284 subscribers. Two things before it can go out:
 *   [Sender email isn't verified]  Open email settings
 *   [Subject is 47 characters]     Phones cut it off after about 40. Try "…" (35).  Use suggestion
 *   chips: Pull in this month's initiatives · Write the intro for me · Send me a test
 *
 * Data: GET /api/emails/campaigns/<id> (name, subject) and
 * GET /api/emails/campaigns/<id>/checks → { checks: [{ id, label, ok, detail, fixHref? }], audienceCount? }
 * (the send pipeline's contract). "Use suggestion" and "Send me a test" run
 * the editor's UI capabilities (email.set_subject / email.send_test) — no
 * model call. Pure builders + a provider; asserted by email-editor.assert.ts.
 */

import { countThings, type BriefingAction, type BriefingCard, type BriefingProvider, type ScreenBriefing } from '../../ade/briefing'

/** Phones show about this many subject characters. */
export const PHONE_SUBJECT_CHARS = 40

export interface CampaignCheck {
  id: string
  label: string
  ok: boolean
  detail?: string | null
  fixHref?: string | null
  /** The send pipeline's severity (lib/email/checks): 'required' blocks, 'warning' is advice. */
  level?: 'required' | 'warning'
  /** Older shape: true = blocks, false = advice. */
  required?: boolean
}

/**
 * Does this check block sending? Required when level is 'required' or
 * required is true; advice when level is 'warning' or required is false;
 * neither field → required (fail safe).
 */
export function isRequired(c: Pick<CampaignCheck, 'level' | 'required'>): boolean {
  if (c.level === 'required' || c.required === true) return true
  if (c.level === 'warning' || c.required === false) return false
  return true
}

export interface ChecksResponse {
  checks: CampaignCheck[]
  /** People the campaign will go to, when the pipeline knows. */
  audienceCount?: number | null
}

export interface CampaignSummary {
  id: string
  name: string
  subject: string
}

const TRAILING_FILLER = new Set(['a', 'an', 'the', 'and', 'or', 'but', 'to', 'of', 'in', 'on', 'at', 'for', 'with', 'from', 'by', 'this', 'that', 'these', 'our', 'your', 'my', 'is', 'are'])

function tidyEnd(s: string): string {
  let words = s.trim().replace(/[\s,;:–—-]+$/u, '').split(/\s+/)
  while (words.length > 1 && TRAILING_FILLER.has(words[words.length - 1].toLowerCase().replace(/[^a-z]/g, ''))) words = words.slice(0, -1)
  return words.join(' ').replace(/[\s,;:–—-]+$/u, '')
}

/**
 * A shorter subject that fits a phone (pure heuristic, no model):
 * drop a trailing clause after an em dash; if still too long, cut at the
 * last word boundary within the limit; never end on a dangling "the/this/…".
 * null when it already fits or nothing sensible remains.
 */
export function suggestSubject(subject: string, limit = PHONE_SUBJECT_CHARS): string | null {
  const s = subject.trim().replace(/\s+/g, ' ')
  if (s.length <= limit) return null
  let candidate = s
  const dash = s.lastIndexOf('—')
  if (dash > 0) candidate = tidyEnd(s.slice(0, dash))
  if (candidate.length > limit) {
    const cut = candidate.slice(0, limit + 1)
    const space = cut.lastIndexOf(' ')
    candidate = tidyEnd(space > 0 ? cut.slice(0, space) : cut.slice(0, limit))
  }
  return candidate.length >= 3 && candidate.length <= limit && candidate !== s ? candidate : null
}

/**
 * Can it go out? Only "ready" when the checks LOADED, there is at least one,
 * and every required check (isRequired: level "required") passed. Missing / errored / empty checks are
 * "unknown" — never read as ready.
 */
export type Readiness = { kind: 'unknown' } | { kind: 'blocked'; count: number } | { kind: 'ready' }

export function readiness(checks: ChecksResponse | null): Readiness {
  if (!checks || !Array.isArray(checks.checks) || checks.checks.length === 0) return { kind: 'unknown' }
  const blocking = checks.checks.filter((c) => isRequired(c) && c.ok !== true).length
  return blocking > 0 ? { kind: 'blocked', count: blocking } : { kind: 'ready' }
}

/** The opening sentence. */
export function emailLead(name: string, audience: number | null | undefined, state: Readiness): ScreenBriefing['lead'] {
  const to = typeof audience === 'number' ? ` to ${audience.toLocaleString('en-US')} subscriber${audience === 1 ? '' : 's'}` : ''
  const tail = state.kind === 'ready' ? '. It’s ready to go out when you are.' : state.kind === 'blocked' ? `. ${countThings(state.count)} before it can go out:` : '.'
  return ['You’re writing the ', { strong: name || 'email' }, `${to}${tail}`]
}

/** Shown when the send checks couldn't be read — quiet, no claim either way. */
export const CHECKS_UNKNOWN_CARD: BriefingCard = { id: 'checks-unknown', title: 'Couldn’t check whether it’s ready to send', detail: 'The send checks didn’t load. Review & send shows them before anything goes out.', actions: [] }

/** One card per failing check; the subject check gets the suggestion. */
export function checkCards(checks: ReadonlyArray<CampaignCheck>, subject: string): BriefingCard[] {
  return checks
    .filter((c) => !c.ok)
    .map((c): BriefingCard => {
      if (c.id === 'subject-length') {
        const suggestion = suggestSubject(subject)
        return {
          id: c.id,
          title: c.label,
          detail: suggestion
            ? `Phones cut it off after about ${PHONE_SUBJECT_CHARS}. Try “${suggestion}” (${suggestion.length}).`
            : c.detail || `Phones cut it off after about ${PHONE_SUBJECT_CHARS}.`,
          actions: suggestion ? [{ label: 'Use suggestion', ui: { capability: 'email.set_subject', args: { subject: suggestion } } }] : [],
        }
      }
      const actions: BriefingAction[] = []
      if (c.fixHref) actions.push({ label: c.id === 'sender-verified' ? 'Open email settings' : 'Fix this', href: c.fixHref })
      return { id: c.id, title: c.label, detail: c.detail || undefined, actions }
    })
}

export const EMAIL_CHIPS: BriefingAction[] = [
  { label: 'Pull in this month’s initiatives', ask: 'Pull this month’s initiatives into this email' },
  { label: 'Write the intro for me', ask: 'Write the intro for this email' },
  { label: 'Send me a test', ui: { capability: 'email.send_test', args: {} } },
]

/** @param checks null when the checks didn't load (404, error, wrong shape). */
export function emailBriefing(campaign: CampaignSummary, checks: ChecksResponse | null): ScreenBriefing {
  const state = readiness(checks)
  if (state.kind === 'unknown') return { lead: emailLead(campaign.name, checks?.audienceCount, state), cards: [CHECKS_UNKNOWN_CARD], chips: EMAIL_CHIPS }
  // Required failures first, then advice.
  const ordered = [...checks!.checks].sort((a, b) => Number(!isRequired(a)) - Number(!isRequired(b)))
  return { lead: emailLead(campaign.name, checks!.audienceCount, state), cards: checkCards(ordered, campaign.subject), chips: EMAIL_CHIPS }
}

/** /admin/email-marketing/<id> → <id>. */
export function campaignIdFrom(pathname: string): string | null {
  // The campaign page and its editor (/[id]/design).
  const m = /^\/admin\/email-marketing\/([A-Za-z0-9_-]{1,80})(?:\/design)?\/?$/.exec(pathname)
  return m && m[1] !== 'new' && m[1] !== 'templates' ? m[1] : null
}

export const emailEditorBriefing: BriefingProvider = async ({ pathname }, { fetchJson }) => {
  const id = campaignIdFrom(pathname)
  if (!id) return null
  const [c, k] = await Promise.all([fetchJson(`/api/emails/campaigns/${id}`), fetchJson(`/api/emails/campaigns/${id}/checks`)])
  const campaign = (c as { campaign?: CampaignSummary } | null)?.campaign
  if (!campaign) return null
  // A 404 / error body / wrong shape is "couldn't check" — never "no failing checks".
  const checks = k && typeof k === 'object' && Array.isArray((k as ChecksResponse).checks) ? (k as ChecksResponse) : null
  return emailBriefing(campaign, checks)
}
