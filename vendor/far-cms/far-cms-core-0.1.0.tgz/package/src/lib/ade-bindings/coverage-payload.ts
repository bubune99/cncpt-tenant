/**
 * The coverage runner's POST body (one admin route's result), validated and
 * capped before it is stored. Pure; asserted by coverage-payload.assert.ts.
 */

import type { CoverageRow, RevealStep, TourStep } from '../ade/coverage/logic'
import { collapsePerItem, contentFreeLabel, contentFreeTarget, perItemCollapser, slugCollapser } from '../ade/coverage/sanitize'

/** What the runner posts for one route. */
export interface CoveragePayload {
  row: CoverageRow
  /** Per-unit detail for the report (label, kind, entity.action, tools, how it's revealed). */
  units?: Array<{ id: string; label: string; kind: string; action: string | null; tools: string[]; reveal: string[] }>
  /** A replayable walk-through of one hidden control (spotlight_steps steps). */
  tour?: { title: string; steps: TourStep[] } | null
}

const MAX_LIST = 200
/** Labels name controls: the record's copy and settings values are cut out, then capped. */
const MAX_LABEL = 80
const label = (s: string) => contentFreeLabel(s).slice(0, MAX_LABEL)
/**
 * A unit id is a stable selector or "role:label" — either can carry a label.
 * A selector whose aria-label names a record ("Edit Akuse Hospital") becomes
 * "kind:Edit (each item)".
 */
const unitId = (id: string, kind: string, collapse: (l: string) => string): string => {
  if (id.startsWith('[') || /^[a-z]+\[/.test(id)) {
    const aria = /aria-label=["']([^"']*)["']/.exec(id)?.[1]
    if (aria && collapse(contentFreeLabel(aria)) !== aria) return `${kind}:${collapse(contentFreeLabel(aria))}`.slice(0, 200)
    return (contentFreeTarget(id) ?? '').slice(0, 200)
  }
  const i = id.indexOf(':')
  const rest = i > 0 ? id.slice(i + 1) : id
  // "role:label" keys are lower-cased; collapse sees the label's words either way.
  const cleaned = collapse(contentFreeLabel(rest))
  return (i > 0 ? `${id.slice(0, i)}:${cleaned.toLowerCase()}` : cleaned).slice(0, 200)
}
/** "Where to find “X”", "Open the “X” tab.": the quoted label is cleaned, the sentence kept. */
const caption = (s: string, max: number) =>
  s.replace(/\s+/g, ' ').replace(/“(.*)”/, (_m, inner: string) => `“${contentFreeLabel(inner)}”`).slice(0, max)
const strings = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string').slice(0, MAX_LIST) : [])
/** Cleaned, then without blanks (a label that was all content), record names ("Edit (each item)") and repeats. */
const strList = (v: unknown, collapse?: (l: string) => string): string[] => {
  const cleaned = strings(v).map(label).filter(Boolean)
  return collapsePerItem(cleaned, collapse ?? perItemCollapser(cleaned))
}

/** Validate a posted payload; null when it isn't one. */
export function parseCoveragePayload(body: unknown): CoveragePayload | null {
  if (!body || typeof body !== 'object') return null
  const o = body as Record<string, unknown>
  const r = o.row as Record<string, unknown> | undefined
  if (!r || typeof r.route !== 'string' || !/^\/admin(\/|$)/.test(r.route) || r.route.length > 300) return null
  // Record names are judged across the whole screen: "Edit A" in one list and "Edit B" in another.
  const rawUnits = Array.isArray(o.units) ? (o.units as Array<Record<string, unknown>>).slice(0, 500) : null
  const every = [r.toolGaps, r.uiGaps, r.hiddenOnly, rawUnits?.map((u) => u?.label)].flatMap(strings).map(label)
  const byWords = perItemCollapser(every)
  // A slug label ("every" on [data-ui="forms.rule.every"]) is a record's too.
  const slugs = slugCollapser((rawUnits ?? []).map((u) => ({ id: String(u?.id ?? ''), label: String(u?.label ?? '') })))
  const slugLabels = new Set((rawUnits ?? []).map((u) => ({ id: String(u?.id ?? ''), label: String(u?.label ?? '') })).filter((u) => slugs(u) !== u.label).map((u) => label(u.label)))
  const collapse = (l: string) => (slugLabels.has(l) ? '(each item)' : byWords(l))
  const row: CoverageRow = {
    route: r.route.split('?')[0],
    at: typeof r.at === 'string' && !Number.isNaN(Date.parse(r.at)) ? r.at : new Date().toISOString(),
    units: typeof r.units === 'number' && Number.isFinite(r.units) ? Math.max(0, Math.round(r.units)) : 0,
    toolGaps: strList(r.toolGaps, collapse),
    uiGaps: strList(r.uiGaps, collapse),
    hiddenOnly: strList(r.hiddenOnly, collapse),
    ...(r.private === true ? { private: true } : {}),
  }
  // A private route stores the route only — never anything from its screen.
  if (row.private) return { row: { ...row, units: 0, toolGaps: [], uiGaps: [], hiddenOnly: [] }, units: undefined, tour: null }
  const units = rawUnits
    ? rawUnits.map((u) => ({
        id: slugs({ id: String(u?.id ?? ''), label: String(u?.label ?? '') }) !== String(u?.label ?? '')
          ? String(u?.id ?? '').replace(/^\[data-ui=(["'])([\w.-]+)\.[\w-]+\1\]$/, '[data-ui^=$1$2.$1]')
          : unitId(String(u?.id ?? ''), String(u?.kind ?? 'other').slice(0, 20), collapse),
        label: collapse(label(String(u?.label ?? ''))),
        kind: String(u?.kind ?? 'other').slice(0, 20),
        action: typeof u?.action === 'string' ? u.action.slice(0, 120) : null,
        tools: strList(u?.tools),
        reveal: strList(u?.reveal),
      }))
    : undefined
  return { row, units, tour: parseTour(o.tour, collapse) }
}

/** A tour whose targets would name content isn't stored (a cleaned target couldn't be replayed). */
function parseTour(v: unknown, collapse: (l: string) => string): CoveragePayload['tour'] {
  const t = v as Record<string, unknown> | null | undefined
  if (!t || !Array.isArray(t.steps)) return null
  const steps: TourStep[] = []
  for (const s of (t.steps as Array<Record<string, unknown>>).slice(0, 12)) {
    if (!s || typeof s.target !== 'string' || typeof s.caption !== 'string') continue
    const target = contentFreeTarget(s.target.slice(0, 300))
    if (!target) return null
    const m = s.meta as { reveal?: Record<string, unknown>; unit?: unknown } | undefined
    const r = m?.reveal
    const revealTarget = r && typeof r.target === 'string' ? contentFreeTarget(r.target.slice(0, 300)) : null
    if (r && !revealTarget) return null
    const meta: TourStep['meta'] = {
      ...(r && revealTarget ? { reveal: { action: String(r.action) as RevealStep['action'], target: revealTarget, label: label(String(r.label ?? '')) } } : {}),
      ...(typeof m?.unit === 'string' ? { unit: unitId(m.unit, 'unit', collapse) } : {}),
    }
    steps.push({ target, caption: caption(s.caption, 160), position: 'auto', ...(Object.keys(meta).length ? { meta } : {}) })
  }
  // A tour to one record's button ("Edit Akuse Hospital") names the record: not stored.
  const quoted = /“(.*)”/.exec(String(t.title ?? ''))?.[1]
  if (quoted && collapse(contentFreeLabel(quoted)) !== contentFreeLabel(quoted)) return null
  return { title: caption(String(t.title ?? 'Walk-through'), 120), steps }
}

