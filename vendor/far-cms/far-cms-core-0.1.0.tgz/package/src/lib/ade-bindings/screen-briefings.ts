/**
 * Dzidzor's per-screen assistant briefings, by the name a screen's manifest
 * entry gives (lib/ade/screens `briefing`). A screen without one gets the
 * general briefing.
 */

import type { BriefingProvider } from '../ade/briefing'
import { emailEditorBriefing } from './briefings/email-editor'

export const SCREEN_BRIEFINGS: Readonly<Record<string, BriefingProvider>> = {
  'email-editor': emailEditorBriefing,
}
