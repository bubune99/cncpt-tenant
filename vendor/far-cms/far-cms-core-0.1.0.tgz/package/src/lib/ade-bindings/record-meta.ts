/**
 * Search & share meta for a record's page (og:image, description), made from
 * the record: its own SEO description / share image when set, else its
 * one-line summary / main photo. Images are served from the media domain.
 * Pure; asserted by record-meta.assert.ts.
 */

import type { RecordData } from '../ade'
import { toMediaDomain } from '../media/public-url'

export interface RecordMeta {
  description?: string
  image?: string
}

const str = (v: unknown) => (typeof v === 'string' && v.trim() ? v.trim() : undefined)

/** Search engines show ~155 characters; cut on a word boundary. */
export function clip(text: string, max = 160): string {
  if (text.length <= max) return text
  const cut = text.slice(0, max - 1)
  const at = cut.lastIndexOf(' ')
  return `${(at > max * 0.6 ? cut.slice(0, at) : cut).replace(/[\s,.;:–-]+$/, '')}…`
}

export function metaFromRecord(data: RecordData | null | undefined): RecordMeta {
  if (!data) return {}
  const description = str(data.seoDescription) ?? str(data.summary) ?? str(data.goal)
  const image = str(data.shareImageUrl) ?? str(data.heroImageUrl)
  return {
    ...(description ? { description: clip(description) } : {}),
    ...(image ? { image: toMediaDomain(image) } : {}),
  }
}
