/**
 * Walkthrough pace for Dzidzor: the admin setting (Settings › Assistant › Walkthrough pace), the person's own choices
 * in their browser, and what autoplay may touch. Pure and asserted by walkthrough-pace.assert.ts; the clock is
 * components/spotlight/walk-player, the controls sit on the spot card.
 *
 * Adapted from BYB's module of the same name (review/byb-walkthrough-pace-2026-10-23); the differences are Dzidzor's
 * spotlight press contract (lib/ade/ui/spot-press): a step that asked for a click on the highlighted thing
 * (clickToContinue) is never moved on by the countdown, and the person's advance choice lives in their browser.
 *
 * HOW a walk-through advances is lib/ade/ui/advance (the person's saved choice, then the site's rule, then the
 * assistant's, else a timer). HOW LONG a step stays is lib/ade/ui/autoplay. This module decides what may play:
 *   - a SET shown together (spotlight_steps, the to-do tour): on a timer the countdown only moves the card's index,
 *     exactly as its Next would. It stops on a step that waits for the person's click, and holds the last step.
 *   - a WAIT (spotlight_step): the run is parked on the person's answer. Autoplay may answer one ONLY when the
 *     assistant marked it informational, it does not ask for a click, the advance is a timer, and a next step exists.
 */

import { advanceGuidance, resolveAdvance, sanitizeAdvance, type Advance } from '../ade/ui/advance'
import { autoplayMayAdvance } from '../ade/ui/spot-press'
import { DEFAULT_PACE, MAX_SECONDS, MAX_WPM, MIN_SECONDS, MIN_WPM, SPEEDS, dwellMs, initial, reduce, sanitizePace, type Pace, type PaceMethod, type PlayState } from '../ade/ui/autoplay'

const METHODS: readonly PaceMethod[] = ['reading', 'fixed', 'floor']

// ── The admin setting ────────────────────────────────────────────────

export type PaceCheck = { ok: true; pace: Pace } | { ok: false; error: string }

const bad = (error: string): PaceCheck => ({ ok: false, error })
const inRange = (v: unknown, lo: number, hi: number): v is number => typeof v === 'number' && Number.isFinite(v) && v >= lo && v <= hi

/**
 * A pace sent by the settings screen. Unlike a stored value (clamped on read by sanitizePace), a value sent to the
 * server that is out of bounds is refused, so the screen never silently saves something other than what it showed.
 * Fields left out keep the current value.
 */
export function checkPaceInput(current: Pace, input: unknown): PaceCheck {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return bad('walkthroughPace must be an object')
  const o = input as Record<string, unknown>
  const method = o.method === undefined ? current.method : o.method
  if (!METHODS.includes(method as PaceMethod)) return bad('method must be reading, fixed or floor')
  const seconds = o.seconds === undefined ? current.seconds : o.seconds
  if (!inRange(seconds, MIN_SECONDS, MAX_SECONDS)) return bad(`seconds must be ${MIN_SECONDS}–${MAX_SECONDS}`)
  const wordsPerMinute = o.wordsPerMinute === undefined ? current.wordsPerMinute : o.wordsPerMinute
  if (!inRange(wordsPerMinute, MIN_WPM, MAX_WPM)) return bad(`wordsPerMinute must be ${MIN_WPM}–${MAX_WPM}`)
  return { ok: true, pace: { method: method as PaceMethod, seconds, wordsPerMinute } }
}

// ── A walk-through's own pace (set by the assistant only when the person asked for one) ──

export interface WalkPace {
  /** Every step stays exactly this long. */
  seconds?: number
  /** Reading time, but at least this long. */
  minSeconds?: number
}

const secondsOrNull = (v: unknown): number | null => (inRange(v, MIN_SECONDS, MAX_SECONDS) ? v : null)

/** Untrusted (model output or stored metadata): only in-range numbers count; both set, fixed wins. */
export function sanitizeWalkPace(v: unknown): WalkPace | undefined {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return undefined
  const o = v as Record<string, unknown>
  const seconds = secondsOrNull(o.seconds)
  if (seconds !== null) return { seconds }
  const minSeconds = secondsOrNull(o.minSeconds)
  return minSeconds !== null ? { minSeconds } : undefined
}

/** A step's own time, if it is one in bounds (the tool schema refuses the rest; stored copies are checked again). */
export const sanitizeStepSeconds = (v: unknown): number | undefined => secondsOrNull(v) ?? undefined

/** The pace that applies: the walk-through's own (fixed beats floor), else the app's setting. */
export function effectivePace(app: Pace, walk: WalkPace | undefined): Pace {
  const base = sanitizePace(app)
  if (walk?.seconds !== undefined) return { ...base, method: 'fixed', seconds: walk.seconds }
  if (walk?.minSeconds !== undefined) return { ...base, method: 'floor', seconds: walk.minSeconds }
  return base
}

/** How long a step stays, at the person's speed: the step's own time, then the walk-through's pace, then the app's. */
export function stepDwellMs(step: { title?: string; sentence?: string; seconds?: number }, app: Pace, walk: WalkPace | undefined, speed: number): number {
  return dwellMs({ title: step.title, sentence: step.sentence, seconds: sanitizeStepSeconds(step.seconds) }, speed, effectivePace(app ?? DEFAULT_PACE, walk))
}

// ── The person's own choices, kept in their browser ──────────────────

export interface PersonPlay {
  /** 1x, 1.5x or 0.75x. */
  speed: number
  /** The person paused it themselves; stays until they press Play. A pause never changes how walk-throughs advance. */
  paused: boolean
  /** "Play it for me" / "I'll click through", saved; null = not decided. Sent with each chat message. */
  advance: Advance | null
}

export const DEFAULT_PERSON_PLAY: PersonPlay = { speed: 1, paused: false, advance: null }
export const PERSON_PLAY_KEY = 'dz.walkthrough.play'

/** Whatever is in storage is untrusted: only the known values are kept. */
export function sanitizePersonPlay(input: unknown): PersonPlay {
  const o = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>
  return {
    speed: SPEEDS.includes(o.speed as (typeof SPEEDS)[number]) ? (o.speed as number) : DEFAULT_PERSON_PLAY.speed,
    paused: o.paused === true,
    advance: sanitizeAdvance(o.advance),
  }
}

// ── What kind of walk-through is on screen ───────────────────────────

export interface WalkInput {
  /** Steps in the shown set. */
  steps: number
  /** The wait the card answers, if it is one: where it is in the walk-through. */
  wait?: { index?: number; total?: number }
  /** How it advances, already resolved by resolveAdvance. */
  advance: Advance
  /** The assistant said this wait step only shows something. Absent means it may need the person. */
  informational?: boolean
  /** The wait step asked the person to click the highlighted thing (spot-press): theirs alone. */
  clickToContinue?: boolean
  person: Pick<PersonPlay, 'paused'>
  reducedMotion: boolean
}

export type Walk =
  /** Nothing to play: a single spot, or a wait whose length is unknown. */
  | { kind: 'none' }
  /** A set the card moves through itself. */
  | { kind: 'set'; total: number; playing: boolean }
  /** A wait: `canPlay` says the step may be answered for the person at all; `playing` that it will be. */
  | { kind: 'wait'; index: number; total: number; playing: boolean; canPlay: boolean }

export function classifyWalk(w: WalkInput): Walk {
  const still = w.reducedMotion || w.person.paused
  const timed = w.advance === 'timer'
  if (w.wait) {
    const { index, total } = w.wait
    // A wait with no known length is a single question to the person, not a walk-through.
    if (index === undefined || total === undefined || total < 2) return { kind: 'none' }
    const canPlay = w.informational === true && autoplayMayAdvance({ clickToContinue: w.clickToContinue })
    return { kind: 'wait', index: Math.min(Math.max(index, 1), total), total, canPlay, playing: timed && canPlay && !still }
  }
  if (w.steps < 2) return { kind: 'none' }
  return { kind: 'set', total: w.steps, playing: timed && !still }
}

/** The whole decision in one place, so the player and the asserts run the same code. */
export interface DecideInput extends Omit<WalkInput, 'advance'> {
  /** The site's rule (assistant | timer | manual). */
  rule: unknown
  /** What the assistant said for this walk-through. */
  assistant: unknown
  /** The person's saved choice (PersonPlay.advance). */
  saved: unknown
}

export function decideWalk(i: DecideInput): { walk: Walk; advance: Advance } {
  // A wait's length is the walk-through's; a set's is the steps shown.
  const steps = i.wait ? (i.wait.total ?? 0) : i.steps
  const { advance } = resolveAdvance({ steps, person: i.saved, admin: i.rule, assistant: i.assistant })
  return { advance, walk: classifyWalk({ ...i, advance }) }
}

// ── A set's clock, with steps that wait for a click ──────────────────

/**
 * One tick of a set. A step that asked for a click on the highlighted thing is the person's: the countdown does not
 * run on it (their click moves it on, spot-press-wire), and it starts fresh on the step after.
 */
export function tickSet(s: PlayState, dt: number, dwellAt: (index: number) => number, waitsForClick: (index: number) => boolean): PlayState {
  if (waitsForClick(s.index)) return s
  return reduce(s, { type: 'tick', dt }, dwellAt)
}

/** Is the countdown shown on this step of a set? Only while it is really counting. */
export function setCounting(s: PlayState, waitsForClick: boolean): boolean {
  return s.playing && !s.held && !s.done && !waitsForClick
}

// ── One wait step as a play state ────────────────────────────────────

/**
 * A wait step is played as a two-step state, "this step" and "the next": when the countdown runs out the state moves
 * on and the caller answers Next. The last step has no next: it is held (done), never answered, so Got it is the
 * person's.
 */
export function waitPlay(w: Extract<Walk, { kind: 'wait' }>, speed: number): PlayState {
  const last = w.index >= w.total
  return initial(last ? 1 : 2, { autoplay: w.playing, speed })
}

/** Run a wait step's clock: the new state, and whether the countdown ran out on a step that has a next. */
export function tickWait(s: PlayState, dt: number, dwell: number): { state: PlayState; advance: boolean } {
  const state = reduce(s, { type: 'tick', dt }, () => dwell)
  return { state, advance: state.index > s.index }
}

// ── What the assistant said about a walk-through ─────────────────────

export interface AssistantWalk {
  advance: Advance | null
  informational: boolean
  pace?: WalkPace
  /** spotlight_step's own time (a set's steps carry theirs on the step). */
  seconds?: number
}

/** The tool call's own input (untrusted model output): only the two known advance values, a literal true, bounded times. */
export function assistantWalkFrom(input: unknown): AssistantWalk {
  const o = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>
  const pace = sanitizeWalkPace(o.pace)
  const seconds = sanitizeStepSeconds(o.seconds)
  return { advance: sanitizeAdvance(o.advance), informational: o.informational === true, ...(pace ? { pace } : {}), ...(seconds !== undefined ? { seconds } : {}) }
}

// ── What freezes the countdown ───────────────────────────────────────

export interface Holds {
  /** The tab is hidden. */
  hidden: boolean
  /** The pointer is over the card. */
  hover: boolean
  /** Focus is inside the card. */
  focus: boolean
  /** Typing in a field holds it until this time (ms since epoch); 0 = not typing. */
  typingUntil: number
}

export const NO_HOLDS: Holds = { hidden: false, hover: false, focus: false, typingUntil: 0 }

/** Is the countdown frozen right now? Any one hold is enough; none of them changes the person's saved choices. */
export const isHeld = (h: Holds, now: number): boolean => h.hidden || h.hover || h.focus || now < h.typingUntil

// ── What the assistant is told ───────────────────────────────────────

/** What a step must be to play by itself: one that only shows something. */
export const INFORMATIONAL_RULE =
  'A spotlight_step plays by itself only if it is informational: set informational true ONLY when the step just shows something and asks the person to do nothing. A step that asks them to click, enter, press or confirm anything is never informational (and one that asks for a click on the highlighted item gets clickToContinue): leave informational out, and it waits for them.'

/** A model choosing arbitrary times makes pacing worse: only the person's own words set one. */
export const PACE_RULE =
  'Leave seconds (on a step) and pace (on a walk-through) unset: the site setting decides how long each step stays. Set them only when the person asked for a specific pace ("3 seconds each", "slower", "give me at least 10 seconds"): pace.seconds for exactly N seconds each, pace.minSeconds for at least N, 2 to 60.'

/** Only the player knows what applies on their screen, so the assistant never promises autoplay in its words. */
export const NO_AUTOPLAY_CLAIM =
  'In your reply never say a walk-through plays or moves on by itself, and never say you will wait for them to click: you cannot know which applies on their screen. Say neutrally what you started.'

/**
 * The [Walkthrough] line for this request: who decides (from the stored site rule and the person's choice their browser
 * sent, both sanitised), when a step may play itself, and when a time may be set. Code enforces the same precedence when
 * it plays (walk-player), so a model that ignores this still cannot overrule a saved choice.
 */
export function walkthroughGuidance(i: { person?: unknown; admin?: unknown }): string {
  return `[Walkthrough] ${[...advanceGuidance(i), INFORMATIONAL_RULE, PACE_RULE, NO_AUTOPLAY_CLAIM].join(' ')}`
}
