/**
 * Dzidzor's phone extensions (browser side; imported once by the admin
 * shell so they're registered on every admin page, where the offline queue
 * runs):
 *
 * - Manage's hero button "New initiative" → /admin/m/initiatives/new.
 * - 'record.phone-draft': the assistant's draft from the phone's notes and
 *   the photos already uploaded in its group (notes survive a reload or a
 *   dropped signal on the queue).
 * - 'record.phone-save': save the reviewed draft as a draft change set; the
 *   draft key makes a retried save return the first one (no double drafts).
 *
 * Photos use core 'media.upload' (lib/ade/offline/media-upload) in the same
 * group, so they're done before the draft runs.
 */

import { registerMobileAction } from '../../ade/mobile/nav'
import { registerQueueAction } from '../../ade/offline/queue'
import '../../ade/offline/media-upload'
import { ApiError, classifyApiError, uploadedPhotos, voiceQueueKey } from '../../ade/mobile/phone-draft'

registerMobileAction({
  id: 'new-initiative',
  label: 'New initiative',
  icon: 'Camera',
  href: '/admin/m/initiatives/new',
  permission: 'pages.create',
  placement: 'manage-hero',
})

async function post(url: string, body: unknown, signal: AbortSignal): Promise<Record<string, unknown>> {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal })
  const j = (await r.json().catch(() => ({}))) as Record<string, unknown>
  if (!r.ok || !j.success) throw new ApiError(typeof j.error === 'string' ? j.error : `Request failed (${r.status})`, r.ok ? 500 : r.status)
  return j
}

export interface PhoneDraftPayload {
  type: string
  notes: string
  draftKey: string
  /** Photo keys in page order (cover first). */
  photoKeys: string[]
  /** Uploads the phone already knows (the queue clears finished items after a while). */
  uploaded?: Record<string, { url: string; mediaId: string }>
  /** Where the photos were taken, rounded ("near 6.6°N, 0.47°E"). */
  near?: string
}

/**
 * The draft streams: partial fields and story are kept on the item as they
 * arrive (progress.data.partial) so the screen can say what's happening and
 * "Fill it in myself" starts from what's already written.
 */
async function streamDraft(body: unknown, signal: AbortSignal, onPartial: (p: unknown) => void): Promise<{ draft: unknown; timing?: unknown }> {
  const r = await fetch('/api/admin/mobile/records/draft', { method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/x-ndjson' }, body: JSON.stringify(body), signal })
  if (!r.ok || !r.body) {
    const j = (await r.json().catch(() => ({}))) as { error?: string }
    throw new ApiError(j.error || `Request failed (${r.status})`, r.ok ? 500 : r.status)
  }
  const reader = r.body.getReader()
  const dec = new TextDecoder()
  let buf = ''
  for (;;) {
    const { value, done } = await reader.read()
    if (value) buf += dec.decode(value, { stream: !done })
    let nl: number
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).trim()
      buf = buf.slice(nl + 1)
      if (!line) continue
      const m = JSON.parse(line) as { t: string; draft?: unknown; timing?: unknown; status?: number; error?: string; fields?: unknown; story?: unknown }
      if (m.t === 'partial') onPartial({ fields: m.fields, story: m.story })
      else if (m.t === 'done') return { draft: m.draft, timing: m.timing }
      else if (m.t === 'error') throw new ApiError(m.error || 'The assistant couldn’t draft it', m.status ?? 500)
    }
    if (done) break
  }
  throw new ApiError('The draft was cut off', 502)
}

registerQueueAction({
  type: 'record.phone-draft',
  run: async (item, { resultOf, signal, save }) => {
    const p = item.payload as PhoneDraftPayload
    let last = 0
    const out = await streamDraft({ type: p.type, notes: p.notes, photos: uploadedPhotos(p.draftKey, p.photoKeys, resultOf, p.uploaded), near: p.near }, signal, (partial) => {
      const now = Date.now()
      if (now - last < 500) return
      last = now
      void save({ stage: 'drafting', data: { partial } })
    })
    if (out.timing) console.info('[mobile-draft] timing', out.timing)
    return out.draft
  },
  retry: { max: 4 },
  classify: classifyApiError,
})

export interface PhoneSavePayload {
  type: string
  draftKey: string
  data: Record<string, unknown>
  story: string[]
  conversationId?: string
  /** Voice notes (by queue key) and photos to attach for Review / To-do; audio urls are read from the queue at send time. */
  voices?: Array<{ key: string; seconds: number; transcript: string; url?: string }>
  photoUrls?: string[]
}

registerQueueAction({
  type: 'record.phone-save',
  run: async (item, { signal, resultOf }) => {
    const p = item.payload as PhoneSavePayload
    // The voice notes uploaded before this (same group) — their audio links come from the queue.
    const voice = (p.voices ?? []).map((v) => ({ seconds: v.seconds, transcript: v.transcript, url: v.url ?? (resultOf(voiceQueueKey(p.draftKey, v.key)) as { url?: string } | undefined)?.url ?? null }))
    const attachments = { photos: p.photoUrls ?? [], voice }
    const j = await post('/api/admin/mobile/records/save', { type: p.type, data: p.data, story: p.story, conversationId: p.conversationId, clientKey: p.draftKey, attachments }, signal)
    return { changeSetId: j.changeSetId, path: j.path }
  },
  retry: { max: 8 },
  classify: classifyApiError,
})

// ── Field update on an initiative (mock 12) ───────────────────────────

export interface PhoneUpdateDraftPayload {
  id: string
  notes: string
}

registerQueueAction({
  type: 'record.phone-update-draft',
  run: async (item, { signal }) => {
    const p = item.payload as PhoneUpdateDraftPayload
    const j = await post('/api/admin/mobile/records/update', { action: 'draft', id: p.id, notes: p.notes }, signal)
    if (typeof j.ms === 'number') console.info('[mobile-update] draft ms', j.ms)
    return { update: j.update }
  },
  retry: { max: 4 },
  classify: classifyApiError,
})

export interface PhoneUpdateSavePayload {
  id: string
  draftKey: string
  update: string
  photoKeys: string[]
  uploaded?: Record<string, { url: string; mediaId: string }>
  voices?: Array<{ key: string; seconds: number; transcript: string; url?: string }>
}

registerQueueAction({
  type: 'record.phone-update-save',
  run: async (item, { signal, resultOf }) => {
    const p = item.payload as PhoneUpdateSavePayload
    const photos = uploadedPhotos(p.draftKey, p.photoKeys, resultOf, p.uploaded).map((x) => x.url)
    const voice = (p.voices ?? []).map((v) => ({ seconds: v.seconds, transcript: v.transcript, url: v.url ?? (resultOf(voiceQueueKey(p.draftKey, v.key)) as { url?: string } | undefined)?.url ?? null }))
    const j = await post('/api/admin/mobile/records/update', { action: 'save', id: p.id, update: p.update, attachments: { photos, voice }, clientKey: p.draftKey }, signal)
    return { changeSetId: j.changeSetId }
  },
  retry: { max: 8 },
  classify: classifyApiError,
})
