/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/mobile/register.assert.ts
 * The phone's queue actions send what the routes expect, keep the result for
 * the screen, and say which failures are worth retrying.
 */
import assert from 'node:assert/strict'
import './register'
import { queueAction, classifyError, type QueueItem } from '../../ade/offline/queue'
import { mobileActions } from '../../ade/mobile/nav'
import { photoQueueKey } from '../../ade/mobile/phone-draft'

let n = 0
const check = async (name: string, fn: () => Promise<void> | void) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }
const calls: Array<{ url: string; body: Record<string, unknown> }> = []
let reply: { status: number; json?: unknown; ndjson?: string } = { status: 200, json: {} }
globalThis.fetch = (async (url: string, init: RequestInit) => {
  calls.push({ url, body: JSON.parse(String(init.body)) })
  return new Response(reply.ndjson ?? JSON.stringify(reply.json), { status: reply.status })
}) as typeof fetch
const item = (type: string, payload: unknown): QueueItem => ({ id: 'i', type, label: 'x', payload, createdAt: 0, attempts: 0, state: 'sending', nextAt: 0 })
const ctx = (results: Record<string, unknown> = {}) => ({ blob: null, resultOf: (k: string) => results[k], save: async () => {}, onBytes: () => {}, signal: new AbortController().signal })

async function main() {
  await check('"New initiative" is Manage’s hero for people who can create pages', () => {
    const hero = mobileActions('manage-hero', (p) => p === 'pages.create', [])
    assert.deepEqual(hero.map((a) => [a.id, a.href]), [['new-initiative', '/admin/m/initiatives/new']])
    assert.equal(mobileActions('manage-hero', () => false, []).length, 0)
  })

  await check('the draft sends the notes with the photos already uploaded in its group, cover first', async () => {
    reply = { status: 200, ndjson: [{ t: 'partial', fields: { name: 'Water' } }, { t: 'done', success: true, draft: { data: { name: 'Water for Ada' }, story: ['s'] }, timing: { totalMs: 4200 } }].map((l) => JSON.stringify(l)).join('\n') + '\n' }
    const k = 'initiative-x-abcdef'
    const saved: unknown[] = []
    const c = { ...ctx({ [photoQueueKey(k, 'c')]: { id: 'm1', url: 'https://r2/1.jpg' }, [photoQueueKey(k, 'p')]: { id: 'm2', url: 'https://r2/2.jpg' } }), save: async (pr: unknown) => { saved.push(pr) } }
    const out = await queueAction('record.phone-draft')!.run(item('record.phone-draft', { type: 'initiative', notes: 'raising $3,000', draftKey: k, photoKeys: ['c', 'p'] }), c)
    assert.deepEqual(saved, [{ stage: 'drafting', data: { partial: { fields: { name: 'Water' }, story: undefined } } }], 'partials are kept on the item')
    assert.equal(calls.at(-1)!.url, '/api/admin/mobile/records/draft')
    assert.deepEqual(calls.at(-1)!.body, { type: 'initiative', notes: 'raising $3,000', photos: [{ url: 'https://r2/1.jpg', mediaId: 'm1' }, { url: 'https://r2/2.jpg', mediaId: 'm2' }] })
    assert.deepEqual(out, { data: { name: 'Water for Ada' }, story: ['s'] })
  })

  await check('an error line mid-stream (e.g. the daily limit) is a refusal; a cut-off stream retries', async () => {
    reply = { status: 200, ndjson: JSON.stringify({ t: 'error', status: 429, error: 'limit' }) + '\n' }
    const e = (await queueAction('record.phone-draft')!.run(item('record.phone-draft', { type: 'initiative', notes: 'x', draftKey: 'initiative-x-abcdef', photoKeys: [] }), ctx()).catch((x: Error) => x)) as Error
    assert.equal(e.message, 'limit')
    reply = { status: 200, ndjson: JSON.stringify({ t: 'partial', fields: {} }) + '\n' }
    const cut = (await queueAction('record.phone-draft')!.run(item('record.phone-draft', { type: 'initiative', notes: 'x', draftKey: 'initiative-x-abcdef', photoKeys: [] }), ctx()).catch((x: Error) => x)) as Error
    assert.equal(classifyError('record.phone-draft', cut), 'retry')
  })

  await check('the save carries the draft key (a retry returns the first save)', async () => {
    reply = { status: 200, json: { success: true, changeSetId: 'cs1', path: '/initiatives/a' } }
    const out = await queueAction('record.phone-save')!.run(item('record.phone-save', { type: 'initiative', draftKey: 'initiative-x-abcdef', data: { name: 'A' }, story: [] }), ctx())
    assert.equal(calls.at(-1)!.body.clientKey, 'initiative-x-abcdef')
    assert.deepEqual(out, { changeSetId: 'cs1', path: '/initiatives/a' })
  })

  await check('a refusal fails for good; a server error or no signal waits and retries', async () => {
    reply = { status: 400, json: { success: false, error: 'No name yet' } }
    const e = await queueAction('record.phone-save')!.run(item('record.phone-save', { type: 'initiative', draftKey: 'initiative-x-abcdef', data: {}, story: [] }), ctx()).catch((x: Error) => x) as Error
    assert.equal(e.message, 'No name yet')
    assert.equal(classifyError('record.phone-save', e), 'fail')
    reply = { status: 503, json: {} }
    const e2 = await queueAction('record.phone-draft')!.run(item('record.phone-draft', { type: 'initiative', notes: '', draftKey: 'initiative-x-abcdef', photoKeys: [] }), ctx()).catch((x: Error) => x) as Error
    assert.equal(classifyError('record.phone-draft', e2), 'retry')
    assert.equal(classifyError('record.phone-draft', new TypeError('Failed to fetch')), 'retry')
  })

  console.log(`\n${n} checks passed`)
}
void main()
