/**
 * Dzidzor's one line for an initiative sent from a phone, on its Review card
 * (mock 10): "Active · Volta Region · goal $3,000 · 3 photos · voice note",
 * then how donations work until it has its own link.
 */

import { attachmentsLine, type PhoneAttachments } from '../../ade/mobile/attachments'

const STAGES: Record<string, string> = { active: 'Active', ongoing: 'Ongoing', completed: 'Completed' }

export function phoneFacts(fields: Record<string, unknown>, a: PhoneAttachments | null, money: (n: number, cur: string) => string): string {
  const parts: string[] = []
  if (typeof fields.stage === 'string' && STAGES[fields.stage]) parts.push(STAGES[fields.stage])
  if (typeof fields.location === 'string' && fields.location.trim()) parts.push(fields.location.trim())
  if (typeof fields.goalAmount === 'number' && fields.goalAmount > 0) parts.push(`goal ${money(fields.goalAmount, typeof fields.goalCurrency === 'string' ? fields.goalCurrency : 'USD')}`)
  if (a) parts.push(attachmentsLine(a))
  const line = parts.filter(Boolean).join(' · ')
  const donate = typeof fields.donationUrl === 'string' && fields.donationUrl ? '' : ' Uses your main donate page until a dedicated link is added.'
  return `${line}${line ? '.' : ''}${donate}`.trim()
}
