/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/mobile/phone-facts.assert.ts
 */
import assert from 'node:assert/strict'
import { phoneFacts } from './phone-facts'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the Review card line for a phone draft (mock 10)', () => {
  const money = (n: number, c: string) => `${c === 'USD' ? '$' : c + ' '}${n.toLocaleString('en-US')}`
  assert.equal(phoneFacts({ stage: 'active', location: 'Volta Region', goalAmount: 3000, goalCurrency: 'USD' }, { photos: ['a', 'b', 'c'], voice: [{ url: null, seconds: 24, transcript: 'x' }] }, money), 'Active · Volta Region · goal $3,000 · 3 photos · voice note. Uses your main donate page until a dedicated link is added.')
  assert.equal(phoneFacts({ donationUrl: 'https://give/x' }, null, money), '')
})

console.log(`\n${n} checks passed`)
