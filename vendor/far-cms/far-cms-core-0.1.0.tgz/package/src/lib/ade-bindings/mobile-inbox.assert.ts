/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/mobile-inbox.assert.ts
 */
import assert from 'node:assert/strict'
import { submissionItem, type SubmissionRow } from './mobile-inbox-items'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const fields = [
  { id: 'first_name', type: 'text', label: 'First name' },
  { id: 'last_name', type: 'text', label: 'Last name' },
  { id: 'email', type: 'email', label: 'Email' },
  { id: 'message', type: 'textarea', label: 'Message' },
] as unknown as SubmissionRow['fields']
const row = (o: Partial<SubmissionRow>): SubmissionRow => ({
  id: 's1', formId: 'f1', formName: 'Contact Us', fields, status: 'new', read: false, createdAt: new Date('2026-10-11T09:00:00Z'),
  data: { first_name: 'Ama', last_name: 'Mensah', email: 'Ama@Example.org', message: 'Can I volunteer\n on Saturday?' }, ...o,
})

check('a new submission: who, what, unread, waiting for a reply, with a link to it', () => {
  const i = submissionItem(row({}))
  assert.equal(i.id, 'submission:f1:s1')
  assert.equal(i.segment, 'customers')
  assert.equal(i.from, 'Ama Mensah')
  assert.equal(i.subject, 'Contact Us')
  assert.equal(i.preview, 'Can I volunteer on Saturday?')
  assert.ok(i.unread && i.needsReply && i.canReply)
  assert.equal(i.href, '/admin/forms/f1?tab=submissions&submission=s1')
})

check('replied: no longer waiting; no address: cannot reply', () => {
  const r = submissionItem(row({ status: 'replied', read: true }))
  assert.ok(!r.unread && !r.needsReply && r.canReply)
  const x = submissionItem(row({ data: { first_name: 'Kofi', message: 'Hi' } }))
  assert.ok(!x.canReply && !x.needsReply)
  assert.equal(x.from, 'Kofi')
})

check('a masked address (confidential area) never becomes a reply address', () => {
  const m = submissionItem(row({ data: { first_name: 'Ama', email: '[private]', message: 'Hi' } }))
  assert.ok(!m.canReply && !m.needsReply && m.private === true, 'marked private so the screen shows the privacy note')
  assert.equal(submissionItem(row({})).private, undefined)
  const none = submissionItem(row({ data: {} }))
  assert.equal(none.from, 'Someone')
})

console.log(`\n${n} checks passed`)
