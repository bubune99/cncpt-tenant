/**
 * This app's record pages, for fill in place (lib/ade/records/fill): which
 * record fields each bound part of a template edits on the page itself, in the
 * order the fill visits them. Everything else is in the Details drawer.
 */

export const RECORD_FILL_BOUND_PARTS: Readonly<Record<string, readonly string[]>> = {
  // The initiative banner: the title, the one-liner and the place are typed on the photo; the photo is picked.
  InitiativeHeader: ['name', 'summary', 'location', 'heroImageUrl'],
}

/** The assistant's name on the page's marks and legend (core defaults are neutral). */
export const RECORD_FILL_NAMES = { badgeAssistant: 'Kofi', legendAssistant: 'Filled by Kofi' } as const

/** Details-drawer inputs by id — a fallback until every field carries lane A's record.field unit (field-units). */
const DETAILS_IDS: Readonly<Record<string, string>> = {
  stage: '#d-stage',
  startDate: '#d-start',
  endDate: '#d-end',
  slug: '#d-slug',
  partner: '#d-partner',
  videoUrl: '#d-video',
  featured: '#d-featured',
  featuredOrder: '#d-order',
}

/**
 * Where a field is on the record page: the shared field unit
 * [data-ui="record.field.<key>"] (the same one read_view and the spotlight use),
 * then the older hooks (a Details id, a data-field element) while those remain.
 */
export function recordFillTarget(key: string): string {
  const k = key.replace(/[^\w-]/g, '')
  return [`[data-ui="record.field.${k}"]`, DETAILS_IDS[k], `[data-field="${k}"]`].filter(Boolean).join(', ')
}

/** The record page's draft banner (R8), from the change set's To-do approval. */
export interface DraftBannerView {
  title: string
  line: string
  approveLabel: string
  /** Approve: every open item this person may approve — the record AND its page. */
  approveIds: string[]
  /** Reject: the same items plus any whose target is gone, so nothing of the draft is left half-open. */
  rejectIds: string[]
  canApprove: boolean
  reviewHref: string
  askHref: string
}

export function draftBannerView(a: { id: string; itemIds: string[]; discardIds: string[]; canApprove: boolean; headline: string; title: string; publishes: boolean }): DraftBannerView {
  const n = a.itemIds.length
  return {
    title: 'Drafted. Waiting for approval.',
    line: `Nothing is live yet. ${n === 1 ? '1 change' : `${n} changes`}: ${a.title}`,
    approveLabel: a.publishes ? 'Approve & publish' : 'Approve',
    approveIds: a.itemIds,
    rejectIds: [...new Set([...a.itemIds, ...a.discardIds])],
    canApprove: a.canApprove && n > 0,
    reviewHref: `/admin/todo/review/${encodeURIComponent(a.id)}`,
    askHref: `/admin/todo?view=all&item=${encodeURIComponent(a.id)}`,
  }
}

/**
 * This app's record write and commit tools: hidden while the record's own page is open. record.fill is the way
 * in; publishing is the person's press on the page (spec C11: the agent points, never presses).
 */
export const RECORD_WRITE_TOOLS = ['updateRecord', 'createRecordWithPage', 'publishRecord', 'archiveRecord'] as const
/** Hidden on the record screen: the record writes, and the page tools that need a page row (a draft record has none — blocks go in through record.add_block). */
export const RECORD_HIDDEN_TOOLS = [...RECORD_WRITE_TOOLS, 'add_block', 'save_block'] as const
