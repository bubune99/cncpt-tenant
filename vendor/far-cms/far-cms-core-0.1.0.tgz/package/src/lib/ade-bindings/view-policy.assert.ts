/**
 * The screen tools' policy against Dzidzor's real rules: the floor plus
 * per-person area access (RBAC areas, lib/ade/governance/access).
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/view-policy.assert.ts
 */
import assert from 'node:assert/strict'
import { blockedScreen, fallbackPolicy, markerLevel, maskReports, screenLevel, showRawFor, type ViewPolicy } from '../ade/ui/view-policy'
import { blockedFromOutput } from '../ade/observability/continuation'
import { areaAccess, areaRules, type PermissionView } from '../ade/governance/access'
import { PRIVACY_AREAS, VISIBILITY_DEFAULTS, VISIBILITY_FLOOR, withAreaSettings } from './visibility-rules'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

/** As GET /api/admin/ade/visibility builds it for the caller. */
const policyFor = (p: PermissionView, role: 'owner' | 'staff', areas = PRIVACY_AREAS): ViewPolicy => ({
  role,
  rules: [...VISIBILITY_FLOOR, ...VISIBILITY_DEFAULTS, ...areaRules(areas, p, 'agent')],
  areas,
  access: areas.map((a) => areaAccess(a, p)),
})
const ownerP: PermissionView = { permissions: ['*'], overrides: [] }
const staffP: PermissionView = { permissions: ['pages.view', 'forms.view'], overrides: [] }
const owner = policyFor(ownerP, 'owner')
const staff = policyFor(staffP, 'staff')

check('screens: the floor blocks MCP / environment / auth for everyone; admin people are layout-only for a staff assistant', () => {
  for (const p of [staff, owner]) {
    assert.equal(screenLevel(p, '/admin/settings?section=mcp').level, 'blocked')
    assert.equal(screenLevel(p, '/admin/settings?section=environment').level, 'blocked')
    assert.equal(screenLevel(p, '/handler/sign-in').level, 'blocked')
  }
  assert.equal(screenLevel(staff, '/admin/settings?section=identity').level, 'readable')
  const users = screenLevel(staff, '/admin/users')
  assert.deepEqual([users.level, users.rule?.id], ['metadata-only', 'area.people'])
  assert.equal(screenLevel(owner, '/admin/users').level, 'readable')
  // Customers follow the person by default.
  assert.equal(screenLevel(staff, '/admin/customers').level, 'readable')
})

check('markers: secrets/passwords/tokens/payment blocked for all; contact readable for the owner, masked for staff; unknown stays private', () => {
  const s = markerLevel(staff)
  const o = markerLevel(owner)
  for (const m of ['secret', 'password', 'token', 'payment']) {
    assert.equal(s(m), 'blocked', m)
    assert.equal(o(m), 'blocked', m)
  }
  assert.equal(s('contact'), 'metadata-only')
  assert.equal(o('contact'), 'readable')
  assert.equal(s('something-new'), 'metadata-only', 'fail closed on a marker no rule names')
})

check('raw contact text reaches the model only when the contact area follows the person (switch) — owner included', () => {
  assert.equal(showRawFor(owner)('contact'), false, 'default: redacted even for the owner')
  const switched = withAreaSettings(PRIVACY_AREAS, { contact: { agentByDefault: true } })
  assert.equal(showRawFor(policyFor(ownerP, 'owner', switched))('contact'), true)
  // Switch on but this person's assistant is denied by an exception: still redacted.
  const denied: PermissionView = { permissions: ['*'], overrides: [{ permission: 'privacy.contact.agent', type: 'DENY' }] }
  assert.equal(showRawFor(policyFor(denied, 'owner', switched))('contact'), false)
  assert.equal(showRawFor(owner)('secret'), false)
})

check('a blocked screen says nothing but that it is private — and agent activity can read its report', () => {
  const r = blockedScreen(screenLevel(staff, '/admin/settings?section=mcp'), 'Settings › MCP address', '/admin/settings')
  assert.deepEqual(Object.keys(r).sort(), ['blocked', 'canGuide', 'message', 'ok', 'private', 'reason', 'route'])
  assert.equal(r.reason, 'floor.mcp-keys')
  assert.deepEqual(blockedFromOutput(r), [{ mode: 'blocked', target: 'Settings › MCP address', reason: 'floor.mcp-keys' }])
})

check('mask reports: grouped by place + rule id (area.*), labels only; redaction reported as such; nothing withheld → nothing', () => {
  assert.deepEqual(maskReports(screenLevel(staff, '/admin/users'), 'Users', [], staff), [{ mode: 'metadata-only', target: 'Users', reason: 'area.people' }])
  const notes = [
    { target: 'Submissions', field: 'Email', marker: 'contact', kind: 'policy' as const },
    { target: 'Submissions', field: 'Phone', marker: 'contact', kind: 'policy' as const },
  ]
  assert.deepEqual(maskReports(null, 'Submissions', notes, staff), [{ mode: 'masked', target: 'Submissions', fields: ['Email', 'Phone'], reason: 'area.contact' }])
  const red = maskReports(null, 'Submissions', [{ target: 'Submissions', field: 'Email', kind: 'redaction' as const }], owner)
  assert.deepEqual(blockedFromOutput({ blocked: red }), [{ mode: 'masked', target: 'Submissions', fields: ['Email'], reason: 'redaction' }])
  assert.deepEqual(maskReports(null, 'X', [], staff), [])
})

check('until the rules load (or if they cannot), the strictest view applies', () => {
  const f = fallbackPolicy(VISIBILITY_FLOOR, VISIBILITY_DEFAULTS)
  assert.equal(f.role, 'staff')
  assert.equal(markerLevel(f)('contact'), 'metadata-only')
  assert.equal(showRawFor(f)('contact'), false)
})

console.log(`\n${n} checks passed`)
