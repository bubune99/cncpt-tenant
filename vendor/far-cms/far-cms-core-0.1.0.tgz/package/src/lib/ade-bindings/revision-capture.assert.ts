/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/revision-capture.assert.ts
 */
import assert from 'node:assert/strict'
import { captureRevisions, noteRevision } from './revision-capture'

const rev = (id: string) => ({ revisionId: id, version: 1, entityType: 'form', entityId: 'f' })
const later = (ms: number) => new Promise((r) => setTimeout(r, ms))

async function main() {
  // Outside a call: ignored.
  noteRevision(rev('stray'))
  // Each call sees only its own, even when two run at once (the model calls tools in parallel).
  const [a, b] = await Promise.all([
    captureRevisions(async () => { await later(20); noteRevision(rev('a1')); await later(5); noteRevision(rev('a2')); return 'A' }),
    captureRevisions(async () => { noteRevision(rev('b1')); await later(10); return 'B' }),
  ])
  assert.deepEqual(a.revisions.map((r) => r.revisionId), ['a1', 'a2'])
  assert.deepEqual(b.revisions.map((r) => r.revisionId), ['b1'])
  assert.equal(a.result, 'A')
  console.log('ok 1 - each tool call captures only what it recorded (parallel-safe)')
}
main()
