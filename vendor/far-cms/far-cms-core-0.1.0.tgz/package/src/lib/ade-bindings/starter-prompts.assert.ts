/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/starter-prompts.assert.ts
 */
import assert from 'node:assert/strict'
import { SCREEN_STARTERS, STARTER_LIBRARY } from './starter-prompts'
import { EMPTY_CHAT, starterRow, startersForScreen } from '../ade/chat/empty-chat'
import { SCREENS } from '../ade/screens'
import { runStyle } from '../ade/chat/plan'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('R3: the page builder has its own starters; other screens keep the Home library', () => {
  const lib = startersForScreen(STARTER_LIBRARY, SCREEN_STARTERS, 'page-editor')
  assert.notEqual(lib, STARTER_LIBRARY)
  assert.deepEqual(starterRow(lib).map((c) => c.title), ['Fill in an empty section', 'Improve the wording', 'Add a call to action', 'Add a gallery under the story', 'Ideas for a banner', 'Check it on a phone'])
  assert.equal(starterRow(lib).length, EMPTY_CHAT.rowSize)
  assert.equal(startersForScreen(STARTER_LIBRARY, SCREEN_STARTERS, 'dashboard'), STARTER_LIBRARY)
  for (const key of Object.keys(SCREEN_STARTERS)) assert.ok(SCREENS.some((s) => s.key === key), `${key} is a real screen`)
})

check('the starters are plain conversation starters (no colors, short) that lead to the library and the run styles', () => {
  const cards = SCREEN_STARTERS['page-editor'].groups.flatMap((g) => g.cards)
  for (const c of cards) {
    assert.ok(c.title.length <= 40 && c.hint.length <= 60 && c.prompt.length <= 80, c.title)
    assert.ok(!('color' in c) && !('tone' in c), 'neutral cards: no color data')
  }
  assert.equal(runStyle(cards.find((c) => c.title === 'Plan it out first')!.prompt), 'planned', 'the plan-first starter shows a plan and waits')
  assert.equal(runStyle(cards.find((c) => c.title === 'Add a call to action')!.prompt), 'fly', 'a small add runs on the fly')
})

console.log(`\n${n} checks passed`)
