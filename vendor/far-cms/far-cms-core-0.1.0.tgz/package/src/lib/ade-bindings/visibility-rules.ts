/**
 * Dzidzor's visibility rules for the agent (lib/ade/governance/visibility).
 *
 * FLOOR — always blocked, shown locked in Settings › What it can do:
 * secrets and keys, passwords, payment details, sign-in screens, MCP keys,
 * personal-data requests. DEFAULTS — the owner can tighten or loosen these.
 * Pure (no I/O): the server reads custom rules from the agent settings and
 * passes them to effectiveRules().
 */

import type { VisibilityRule } from '../ade/governance/visibility'
import type { PrivacyArea } from '../ade/governance/access'

export const VISIBILITY_FLOOR: readonly VisibilityRule[] = ([
  // Secrets, keys and the screens that hold them.
  { id: 'floor.secrets', label: 'Environment and storage keys', target: { kind: 'route', pattern: '/admin/settings?section=environment' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Environment and storage keys', target: { kind: 'route', pattern: '/admin/settings?section=storage' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*secret' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*token' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*apikey' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*privatekey' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*secretkey' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*encryptionkey' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: 'accesskeyid' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*accesskey' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: '*accesskeyid' }, level: 'blocked' },
  { id: 'floor.secrets', label: 'Secrets, tokens and API keys', target: { kind: 'field', name: 'secret' }, level: 'blocked' },
  // Passwords.
  { id: 'floor.passwords', label: 'Passwords', target: { kind: 'field', name: 'password*' }, level: 'blocked' },
  { id: 'floor.passwords', label: 'Passwords', target: { kind: 'field', name: '*passwordhash' }, level: 'blocked' },
  { id: 'floor.passwords', label: 'Passwords', target: { kind: 'field', name: '*password' }, level: 'blocked' },
  { id: 'floor.passwords', label: 'Passwords', target: { kind: 'field', name: '*pass' }, level: 'blocked' },
  // Payment details and keys.
  { id: 'floor.payment', label: 'Payment details and keys', target: { kind: 'field', name: 'cardnumber' }, level: 'blocked' },
  { id: 'floor.payment', label: 'Payment details and keys', target: { kind: 'field', name: 'cvc' }, level: 'blocked' },
  { id: 'floor.payment', label: 'Payment details and keys', target: { kind: 'field', name: 'iban' }, level: 'blocked' },
  { id: 'floor.payment', label: 'Payment details and keys', target: { kind: 'field', name: 'accountnumber' }, level: 'blocked' },
  { id: 'floor.payment', label: 'Payment details and keys', target: { kind: 'field', name: 'webhooksecret' }, level: 'blocked' },
  { id: 'floor.payment', label: 'Payment details and keys', target: { kind: 'field', name: 'payment' }, level: 'blocked' },
  // Sign-in and session screens (Hexclave / Stack Auth handler pages).
  { id: 'floor.auth', label: 'Sign-in and account security screens', target: { kind: 'route', pattern: '/handler/**' }, level: 'blocked' },
  { id: 'floor.auth', label: 'Sign-in and account security screens', target: { kind: 'route', pattern: '/account/security/**' }, level: 'blocked' },
  { id: 'floor.auth', label: 'Sign-in and account security screens', target: { kind: 'field', name: 'session' }, level: 'blocked' },
  // MCP keys.
  { id: 'floor.mcp-keys', label: 'MCP keys', target: { kind: 'route', pattern: '/admin/settings?section=mcp' }, level: 'blocked' },
  { id: 'floor.mcp-keys', label: 'MCP keys', target: { kind: 'route', pattern: '/admin/settings/mcp/**' }, level: 'blocked' },
  { id: 'floor.mcp-keys', label: 'MCP keys', target: { kind: 'entity', type: 'apikey' }, level: 'blocked' },
  { id: 'floor.mcp-keys', label: 'MCP keys', target: { kind: 'field', name: 'keyhash' }, level: 'blocked' },
  // Personal-data requests (export / delete someone's data).
  { id: 'floor.personal-data', label: 'Personal-data requests', target: { kind: 'route', pattern: '/admin/settings?section=personal-data' }, level: 'blocked' },
  { id: 'floor.personal-data', label: 'Personal-data requests', target: { kind: 'entity', type: 'datarequest' }, level: 'blocked' },
] as VisibilityRule[]).map((r) => ({ ...r, floor: true }))

/**
 * Site-wide extra rules start empty: who may see what is per person now
 * (PRIVACY_AREAS + RBAC). The owner can still add site-wide rules.
 */
export const VISIBILITY_DEFAULTS: readonly VisibilityRule[] = []

/**
 * Protected areas, governed by RBAC (lib/ade/governance/access): roles grant
 * privacy.<area>.see / privacy.<area>.agent and per-person exceptions allow
 * or deny them. `confidential` / `agentByDefault` are the starting values;
 * the owner switches them in Settings › What it can do (agent.privacyAreas).
 */
export const PRIVACY_AREAS: readonly PrivacyArea[] = [
  {
    id: 'contact',
    label: 'Contact details',
    what: 'people’s email addresses and phone numbers',
    targets: [
      { kind: 'field', name: '*email' },
      { kind: 'field', name: '*phone' },
      { kind: 'field', name: '*phonenumber' },
      { kind: 'field', name: 'mobile' },
      { kind: 'field', name: 'contact' },
    ],
    withoutAccess: 'metadata-only',
    confidential: false,
    agentByDefault: false,
  },
  {
    id: 'people',
    label: 'Admin people',
    what: 'the people who use the admin and their accounts',
    targets: [
      { kind: 'route', pattern: '/admin/users/**' },
      { kind: 'route', pattern: '/admin/admin-users/**' },
      { kind: 'entity', type: 'user' },
    ],
    fields: ['name', 'lastLogin*', 'lastActive*'],
    withoutAccess: 'metadata-only',
    confidential: false,
    agentByDefault: false,
  },
  {
    id: 'customers',
    label: 'Customers',
    what: 'customer records',
    targets: [
      { kind: 'route', pattern: '/admin/customers/**' },
      { kind: 'entity', type: 'customer' },
    ],
    fields: ['name', 'firstName', 'lastName', '*email', '*phone', 'company', 'address*', 'notes'],
    withoutAccess: 'metadata-only',
    confidential: false,
    agentByDefault: true,
  },
  {
    id: 'submissions',
    label: 'Form submissions',
    what: 'what people sent through the site’s forms',
    targets: [
      { kind: 'route', pattern: '/admin/forms/*?tab=submissions' },
      { kind: 'entity', type: 'submission' },
    ],
    fields: ['data', 'answers', 'message', 'name'],
    withoutAccess: 'metadata-only',
    confidential: false,
    agentByDefault: true,
  },
  {
    id: 'orders',
    label: 'Orders',
    what: 'orders and who placed them',
    targets: [
      { kind: 'route', pattern: '/admin/orders/**' },
      { kind: 'entity', type: 'order' },
    ],
    fields: ['shippingAddress', 'billingAddress', 'customerName'],
    withoutAccess: 'metadata-only',
    confidential: false,
    agentByDefault: true,
  },
]

/** Areas with the owner's switches applied (agent.privacyAreas). */
export function withAreaSettings(
  areas: readonly PrivacyArea[],
  settings: unknown
): PrivacyArea[] {
  const s = (settings && typeof settings === 'object' ? settings : {}) as Record<string, { confidential?: unknown; agentByDefault?: unknown }>
  return areas.map((a) => ({
    ...a,
    ...(typeof s[a.id]?.confidential === 'boolean' ? { confidential: s[a.id].confidential as boolean } : {}),
    ...(typeof s[a.id]?.agentByDefault === 'boolean' ? { agentByDefault: s[a.id].agentByDefault as boolean } : {}),
  }))
}

/** data-ade-private marker values used in Dzidzor markup (resolve through the field rules above). */
export const PRIVATE_MARKERS = { secret: 'secret', password: 'password', token: 'token', contact: 'contact', payment: 'payment' } as const
