/**
 * Change widgets for Dzidzor: a stored change (a review item, or a revision
 * from lib/ade/history) → the view the chat shows. Pure; the database
 * read is change-widgets-server.ts. Asserted by change-widgets.assert.ts.
 */

import {
  blockLines,
  expandChanges,
  fieldLabel,
  fieldLines,
  formatValue,
  MAX_FIELD_LINES,
  refKey,
  statusOfItems,
  type ChangeRef,
  type ChangeView,
  type FieldLine,
} from '../ade/chat/change-widgets'
import { proposedPathFor } from '../../components/ade/preview-path'
import { approvalPublishes } from './todo-lanes'

/** The parts of a review item a widget needs (lib/ade-bindings/queries ReviewItem). */
export interface WidgetItem {
  id: string
  targetType: string
  targetId: string | null
  status: string
  error: string | null
  isPublish: boolean
  canApprove: boolean
  adminHref: string | null
  /** The page's own title (page content snapshots don't carry one). */
  targetTitle?: string | null
  fieldChanges: ReadonlyArray<{ field: string; before: unknown; after: unknown }>
  blockChanges: ReadonlyArray<{ kind: string; tag?: string; label?: string; fields: ReadonlyArray<{ field: string; before: unknown; after: unknown }> }>
  after: unknown
  // For the review shell (assistant chat v2 P2); the review query has them all.
  operation?: string
  previewPath?: string | null
  blockIds?: string[]
}

const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '')
const cap = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s)

/** "Page", "Blog post", "Initiative", "Header"… */
export function entityTypeOf(item: Pick<WidgetItem, 'targetType' | 'targetId' | 'after'>): string {
  const t = item.targetType
  if (t === 'page' || t === 'page-content' || t === 'page-status') return 'Page'
  if (t.startsWith('blog')) return 'Blog post'
  if (t === 'initiative') return 'Initiative'
  if (t === 'record-featured') return 'Featured list'
  if (t === 'record' || t === 'record-status') return cap(str((item.after as { type?: unknown } | null)?.type).replace(/[-_]+/g, ' ')) || 'Record'
  if (t === 'site-layout') return item.targetId === 'footer' ? 'Footer' : item.targetId === 'header' ? 'Header' : 'Site layout'
  if (t === 'partial') return 'Section'
  if (t === 'form') return 'Form'
  if (t === 'site-setting' || t.startsWith('settings:')) return 'Settings'
  if (t === 'access') return 'Access'
  return cap(t.replace(/[-_]+/g, ' '))
}

/** The thing's own name from its stored after-state; null when it has none. */
export function entityNameOf(after: unknown): string | null {
  const a = (after ?? {}) as Record<string, unknown>
  // Records keep their fields under data, forms under doc.
  const data = (a.data ?? {}) as Record<string, unknown>
  const doc = (a.doc ?? {}) as Record<string, unknown>
  const name = str(a.title) || str(a.name) || str(data.title) || str(data.name) || str(doc.name) || str(doc.title)
  return name ? (name.length > 60 ? `${name.slice(0, 59).trimEnd()}…` : name) : null
}

/** The item a card is about: the content change, not its publish. */
export function primaryOf<T extends Pick<WidgetItem, 'isPublish'>>(items: readonly T[]): T {
  return items.find((i) => !i.isPublish) ?? items[0]
}

/** The items of a set this ref covers (all of them when it names none). */
export function itemsOf<T extends Pick<WidgetItem, 'id'>>(ref: Extract<ChangeRef, { kind: 'changeset' }>, items: readonly T[]): T[] {
  return ref.itemIds.length ? items.filter((i) => ref.itemIds.includes(i.id)) : [...items]
}

/** Fields that are bookkeeping, not something a person edits: never listed as "Unchanged". */
const META_KEYS = new Set(['id', 'type', 'slug', 'status', 'createdAt', 'updatedAt', 'createdById', 'updatedById', 'version', 'deletedAt', 'publishedAt', 'order', 'position'])

/** The thing's own fields this change leaves alone (Values body: "Unchanged: …"), by label. */
export function unchangedOf(after: unknown, changed: readonly string[]): string[] {
  const a = (after ?? {}) as Record<string, unknown>
  const own = (a.data && typeof a.data === 'object' && !Array.isArray(a.data) ? a.data : a.doc && typeof a.doc === 'object' ? a.doc : a) as Record<string, unknown>
  const touched = new Set(changed.map((f) => f.split('.')[0]))
  return Object.keys(own).filter((k) => !META_KEYS.has(k) && !touched.has(k)).map(fieldLabel).slice(0, 12)
}

/** "pages", "initiatives", "products": what a batch is a batch of. */
function nounOf(type: string): string {
  const t = type.toLowerCase()
  return t.endsWith('s') ? t : t.endsWith('y') ? `${t.slice(0, -1)}ies` : `${t}s`
}

/**
 * The same edit on several things (one change set, one kind of thing, more
 * than one of them) → a batch: how many, and the first few, each with its
 * first change. Null for anything else.
 */
export function batchOf(items: readonly WidgetItem[]): ChangeView['batch'] {
  const content = items.filter((i) => !i.isPublish)
  if (content.length < 2) return null
  const type = content[0].targetType
  if (!content.every((i) => i.targetType === type)) return null
  const targets = new Set(content.map((i) => i.targetId ?? i.id))
  if (targets.size < 2) return null
  return {
    count: targets.size,
    noun: nounOf(entityTypeOf(content[0])),
    rows: content.slice(0, 3).map((i) => {
      const c = expandChanges(i.fieldChanges)[0]
      return {
        name: entityNameOf(i.after) ?? (i.targetTitle?.trim() || entityTypeOf(i)),
        before: c ? formatValue(c.before) : '',
        after: c ? formatValue(c.after) : '',
      }
    }),
  }
}

/** The review fields of a change set's view (render, blocks, page, batch, unchanged, publishes). */
export function reviewFieldsOf(changeSetId: string, mine: readonly WidgetItem[], primary: WidgetItem): Partial<ChangeView> {
  const open = mine.filter((i) => i.status === 'pending' || i.status === 'saved')
  const shown = open.length ? open : mine
  const newPage = shown.find((i) => i.targetType === 'page' && i.operation === 'create')?.previewPath
  const path = newPage ?? shown.find((i) => i.previewPath)?.previewPath ?? null
  return {
    target: primary.targetType,
    previewPath: path ? proposedPathFor(path, changeSetId) : null,
    blockIds: [...new Set(shown.flatMap((i) => i.blockIds ?? []))],
    pageId: PAGE_TARGETS.has(primary.targetType) ? primary.targetId : null,
    batch: batchOf(mine),
    unchanged: unchangedOf(primary.after, primary.fieldChanges.map((c) => c.field)),
    publishes: approvalPublishes(shown.map((i) => ({ isPublish: i.isPublish, operation: i.operation ?? 'update', targetType: i.targetType, after: i.after }))),
  }
}

/**
 * One change set ref → one view. Approve / Reject act on all of its items at
 * once (the review API orders content before publishing), so a reply that
 * drafted an edit and its publish shows one card. Items the person may not
 * see were already left out by the review query; none left → no widget.
 */
export function viewFromItems(ref: Extract<ChangeRef, { kind: 'changeset' }>, items: readonly WidgetItem[], why: string | null = null): ChangeView | null {
  const mine = itemsOf(ref, items)
  if (!mine.length) return null
  const primary = primaryOf(mine)
  const changes = mine.flatMap((i) => [...i.fieldChanges, ...blockLines(i.blockChanges)])
  const { fields, more } = fieldLines(changes)
  const status = statusOfItems(mine.map((i) => i.status))
  const failed = mine.find((i) => i.error && (i.status === 'stale' || i.status === 'failed'))
  return {
    key: refKey(ref),
    status,
    entityType: entityTypeOf(primary),
    entityName: entityNameOf(primary.after) ?? (primary.targetTitle?.trim() || null),
    // While it waits, Open is its review page (preview, comments); after, the thing itself.
    href: status === 'pending' ? `/admin/todo/review/${ref.changeSetId}` : primary.adminHref,
    fields,
    more,
    // Once applied, the server adds the revision it recorded (withRevision).
    version: null,
    revisionId: null,
    canRestore: false,
    // Only the items still waiting; Approve / Reject act on these.
    itemIds: mine.filter((i) => i.status === 'pending' || i.status === 'saved').map((i) => i.id),
    canApprove: mine.every((i) => i.canApprove),
    error: failed?.error ?? null,
    why,
    ...reviewFieldsOf(ref.changeSetId, mine, primary),
  }
}

// ── Revisions (lib/ade/history, forms-pkg) ───────────────────────────

/**
 * getRevision(id, viewer): only the changed fields, by path, already masked
 * for the viewer. A floor field (secret) is in `changed` but has no value in
 * before/after.
 */
export interface RevisionRecord {
  id: string
  entityType: string
  entityId: string
  /** "Volunteer sign-up", "Identity & brand"; absent for things without a name. */
  entityName?: string | null
  /** The entity's own names for its top-level fields ({ fields: 'Questions' }). */
  fieldLabels?: Record<string, string> | null
  version: number
  changed: string[]
  before: Record<string, unknown>
  after: Record<string, unknown>
}

/** Where an entity is edited, by its history type; null when no screen edits it. */
export function entityHref(entityType: string, entityId: string): string | null {
  const id = encodeURIComponent(entityId)
  if (entityType === 'form') return `/admin/forms/${id}`
  if (entityType === 'page' || entityType === 'page-content') return `/admin/pages/${id}`
  if (entityType.startsWith('blog')) return `/admin/blog/${id}`
  if (entityType === 'partial') return `/admin/partials/${id}`
  if (entityType === 'site-layout' || entityType === 'site-setting') return '/admin/site-settings'
  if (entityType.startsWith('settings:')) return '/admin/settings'
  return null
}

/**
 * A changed path as a person reads it, with the entity's own field names:
 * "fields.3.label" + { fields: 'Questions' } → "Question 4 label";
 * plain paths go through fieldLabel.
 */
export function pathLabel(path: string, labels: Record<string, string> | null = null): string {
  if (labels?.[path]) return labels[path]
  const parts = path.split('.')
  const head = (key: string) => labels?.[key] ?? fieldLabel(key)
  const i = parts.findIndex((p) => /^\d+$/.test(p))
  if (i > 0) {
    const list = head(parts.slice(0, i).join('.')).replace(/s$/, '')
    const rest = parts.slice(i + 1).join(' ')
    return `${list} ${Number(parts[i]) + 1}${rest ? ` ${fieldLabel(rest).toLowerCase()}` : ''}`
  }
  return parts.length > 1 && labels?.[parts[0]] ? `${labels[parts[0]]} ${fieldLabel(parts.slice(1).join(' ')).toLowerCase()}` : head(path)
}

/** Every changed field of a revision as lines (Compare shows all of them). */
export function revisionLines(rev: Pick<RevisionRecord, 'changed' | 'before' | 'after' | 'fieldLabels'>): FieldLine[] {
  const has = (o: Record<string, unknown>, k: string) => Object.prototype.hasOwnProperty.call(o ?? {}, k)
  return rev.changed.flatMap((p) => {
    if (!has(rev.before, p) && !has(rev.after, p)) return [{ field: p, label: pathLabel(p, rev.fieldLabels ?? null), before: '', after: 'changed (hidden)', hidden: true }]
    // A whole-object change ("display") lists the fields inside it that changed.
    return expandChanges([{ field: p, before: rev.before[p], after: rev.after[p] }]).map((c) => ({ field: c.field, label: pathLabel(c.field, rev.fieldLabels ?? null), before: formatValue(c.before), after: formatValue(c.after) }))
  })
}

/** An applied change, from its revision → the view (Open, Compare, Restore this version). */
export function viewFromRevision(ref: Extract<ChangeRef, { kind: 'revision' }>, rev: RevisionRecord, canRestore = false): ChangeView {
  const lines = revisionLines(rev)
  return {
    key: refKey(ref),
    status: 'applied',
    entityType: entityTypeOf({ targetType: rev.entityType, targetId: rev.entityId, after: null }),
    entityName: rev.entityName?.trim() || null,
    href: entityHref(rev.entityType, rev.entityId),
    fields: lines.slice(0, MAX_FIELD_LINES),
    more: Math.max(0, lines.length - MAX_FIELD_LINES),
    version: rev.version,
    revisionId: rev.id,
    canRestore,
    itemIds: [],
    canApprove: false,
    error: null,
    target: rev.entityType,
  }
}

/** An approved change set's card, with the revision its apply recorded (Compare / Restore). */
export function withRevision(view: ChangeView, rev: { id: string; version: number } | null, canRestore: boolean): ChangeView {
  if (view.status !== 'applied' || !rev) return view
  return { ...view, revisionId: rev.id, version: rev.version, canRestore }
}

/** Of the revisions a change set recorded, the one for the card's own thing (else the latest). */
export function pickRevision<T extends { entityType: string; entityId: string; version: number }>(revs: readonly T[], targetType: string, targetId: string | null): T | null {
  return revs.find((r) => r.entityType === targetType && r.entityId === targetId) ?? [...revs].sort((a, b) => b.version - a.version)[0] ?? null
}

/** Change-set targets whose versions are the page's own snapshots (PageRevision). */
export const PAGE_TARGETS: ReadonlySet<string> = new Set(['page', 'page-content', 'page-status'])

/**
 * The page snapshot an approved item's apply took. Pages don't store the
 * change set, so it is matched by what they do store: an 'ai-edit' snapshot
 * by the approver, taken while the item was being applied (claim → saved,
 * at most `windowMs` before it was marked decided). The latest such wins.
 */
export function pickPageSnapshot<T extends { id: string; createdAt: Date; createdById: string | null; reason: string }>(
  snaps: readonly T[],
  item: { decidedAt: Date | null; decidedById: string | null },
  windowMs = 60_000
): T | null {
  if (!item.decidedAt) return null
  const end = item.decidedAt.getTime()
  const hits = snaps.filter((s) => s.reason === 'ai-edit' && s.createdById === item.decidedById && s.createdAt.getTime() <= end && s.createdAt.getTime() >= end - windowMs)
  return hits.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0] ?? null
}
