/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/coverage-platform.assert.ts
 */
import assert from 'node:assert/strict'
import { classifyCoverage, type CoverageUnit } from '../ade/coverage/logic'
import { actionsForEntry, entryRoutes, humanizeToolName, platformMatcher, verbSynonyms, type FindAction, type PlatformEntryLike } from './coverage-platform'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// Stubs in the platform-map / toolsets / registry shapes.
const pagesEntry: PlatformEntryLike = { id: '/admin/pages', name: 'Pages', href: '/admin/pages', tools: ['pages', 'extensions'], synonyms: ['web pages'] }
const groups = { pages: { tools: ['createPage', 'updatePage', 'deletePage', 'duplicatePage', 'publishPage'] } }
const registry = { createPage: { effect: 'draft' }, updatePage: { effect: 'draft' }, deletePage: { effect: 'irreversible' }, duplicatePage: { effect: 'draft' }, publishPage: { effect: 'write' } }

check('tool names read as owner words', () => {
  assert.equal(humanizeToolName('createPage'), 'create page')
  assert.equal(humanizeToolName('set_automation_enabled'), 'set automation enabled')
  assert.deepEqual(verbSynonyms('publishPage', registry.publishPage), ['publish', 'go live', 'make live'])
  assert.ok(verbSynonyms('updatePage', registry.updatePage).includes('submit for review'))
  assert.ok(!verbSynonyms('createPage', registry.createPage).includes('submit for review'))
})

check('entry → one action per tool (extensions skipped), under its route', () => {
  const acts = actionsForEntry(pagesEntry, groups, registry)
  assert.deepEqual(acts.map((a) => a.action), ['createPage', 'updatePage', 'deletePage', 'duplicatePage', 'publishPage'])
  assert.deepEqual(entryRoutes({ ...pagesEntry, href: '/admin/settings?section=privacy' }), ['/admin/settings', '/admin/settings/*'])
})

check('declared actions win over the tool fallback', () => {
  const formsEntry: PlatformEntryLike = { id: '/admin/forms', name: 'Forms', href: '/admin/forms', tools: ['forms'], actions: [{ verb: 'export_submissions', label: 'Export submissions', synonyms: ['export csv'], tools: ['exportSubmissions'] }] }
  const acts = actionsForEntry(formsEntry, {}, {})
  assert.deepEqual(acts, [{ entity: '/admin/forms', action: 'export_submissions', label: 'Export submissions', synonyms: ['export csv'], tools: ['exportSubmissions'], routes: ['/admin/forms', '/admin/forms/*'] }])
})

check('end to end on a page editor screen with the fallback', () => {
  const route = '/admin/pages/p1/editor'
  const units: CoverageUnit[] = [
    { id: 'editor.submit', label: 'Submit for review', kind: 'action', target: '[data-ui="editor.submit"]', reveal: [] },
    { id: 'editor.duplicate', label: 'Duplicate', kind: 'action', target: '[data-ui="editor.duplicate"]', reveal: [{ action: 'open-menu', target: '[data-ws-more]', label: 'More' }] },
    { id: 'editor.history', label: 'Revisions', kind: 'action', target: '[data-ws-act="revisions"]', reveal: [] },
  ]
  const toolNames = new Set(Object.keys(registry))
  const r = classifyCoverage({ route, units, actions: actionsForEntry(pagesEntry, groups, registry), toolNames })
  assert.deepEqual(r.toolGaps.map((u) => u.id), ['editor.history'])
  assert.deepEqual(r.hiddenOnly.map((m) => m.unit.id), ['editor.duplicate'])
  // create / delete / publish have tools for this route but no unit on screen here.
  assert.deepEqual(r.uiGaps.map((a) => a.action).sort(), ['createPage', 'deletePage', 'publishPage'])
})

check('a declared action with tools: [] (people only) is a tool gap, never a UI gap', () => {
  const formsEntry: PlatformEntryLike = {
    id: '/admin/forms',
    name: 'Forms',
    href: '/admin/forms',
    tools: ['forms'],
    actions: [
      { verb: 'export_csv', label: 'Export CSV', synonyms: ['download submissions'], tools: [] },
      { verb: 'duplicate_form', label: 'Duplicate form', tools: ['duplicateForm'] },
    ],
  }
  const units: CoverageUnit[] = [{ id: 'forms.export', label: 'Export CSV', kind: 'action', target: '[data-ui="forms.export"]', reveal: [] }]
  const r = classifyCoverage({ route: '/admin/forms/f1', units, actions: actionsForEntry(formsEntry, {}, {}), toolNames: new Set(['duplicateForm']) })
  assert.deepEqual(r.toolGaps.map((u) => u.id), ['forms.export'])
  assert.deepEqual(r.uiGaps.map((a) => a.action), ['duplicate_form'])
})

check('the map’s findAction decides first; the core’s scoring only when it finds nothing', () => {
  const entry: PlatformEntryLike = {
    id: '/admin/pages',
    name: 'Pages',
    href: '/admin/pages',
    tools: ['pages'],
    actions: [
      { verb: 'publish', label: 'Publish', synonyms: ['go live'], tools: ['publishPage'] },
      { verb: 'duplicate', label: 'Duplicate page', tools: ['duplicatePage'] },
    ],
  }
  const actions = actionsForEntry(entry, {}, {})
  // Stub findAction: "Publish changes" → publish (contained label), nothing else.
  const findAction: FindAction = (_e, label) => (/publish/i.test(label) ? { verb: 'publish' } : null)
  const units: CoverageUnit[] = [
    { id: 'pub', label: 'Publish changes', kind: 'action', target: '#pub', reveal: [] },
    { id: 'dup', label: 'Duplicate page', kind: 'action', target: '#dup', reveal: [] },
  ]
  const r = classifyCoverage({ route: '/admin/pages/p1/editor', units, actions, toolNames: new Set(['publishPage', 'duplicatePage']), matcher: platformMatcher(entry, findAction, actions) })
  assert.equal(r.mapped[0].action?.action, 'publish')
  assert.equal(r.mapped[1].action?.action, 'duplicate') // fallback scoring
  assert.equal(platformMatcher(null, findAction, actions), undefined)
})

console.log(`\n${n} checks passed`)
