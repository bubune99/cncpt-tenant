/**
 * This app's top-bar controls as shell units (lib/ade/ui/shell-units): what
 * the assistant can point at around the screen, per layout, using the
 * selectors the controls already carry. Menu sections come from the live
 * menu, not from here.
 *
 * Classic (sidebar / drawer): the header row (search, notifications,
 * feedback, tour, help) and the sidebar's own controls. Workspace
 * (menu): the action bar (☰, To-do, feedback, More, your initials — whose
 * menu holds profile, Settings and light/dark); the assistant's way in is
 * the sidebar tab, or the ☰ menu while the sidebar and the chat are closed.
 * The color scheme lives in Settings (a menu section, not a top-bar unit).
 */

import type { ShellUnit } from '../ade/ui/shell-units'

export const SHELL_TOP_UNITS: ReadonlyArray<ShellUnit> = [
  { id: 'menu', label: 'Menu', places: { menu: [{ selector: '[data-ws-menu]' }], drawer: [{ selector: '[data-classic-menu-trigger]' }] } },
  { id: 'todo', label: 'To-do', places: { menu: [{ selector: '[data-ws-todo]' }] } },
  {
    id: 'assistant',
    label: 'Assistant',
    places: {
      sidebar: [{ selector: '[data-ui="nav.assistant"]' }],
      drawer: [{ selector: '[data-ui="nav.assistant"]', inside: 'drawer' }],
      menu: [{ selector: '[data-ws-menu-panel] [data-ws-menu-assistant]', inside: 'menu' }],
    },
  },
  {
    id: 'search',
    label: 'Search',
    places: {
      sidebar: [{ selector: '[data-tour-id="header-search"]' }],
      drawer: [{ selector: '[data-tour-id="header-search"]' }],
      menu: [{ selector: '[data-ws-menu-search]', inside: 'menu' }],
    },
  },
  { id: 'notifications', label: 'Notifications', places: { sidebar: [{ selector: '[data-tour-id="header-notifications"]' }], drawer: [{ selector: '[data-tour-id="header-notifications"]' }] } },
  {
    id: 'feedback',
    label: 'Send feedback',
    places: { sidebar: [{ selector: '[data-ui="feedback.open"]' }], drawer: [{ selector: '[data-ui="feedback.open"]' }], menu: [{ selector: '[data-ui="feedback.open"]' }] },
  },
  { id: 'tour', label: 'Tours', places: { sidebar: [{ selector: '[data-tour-id="header-tour-button"]' }], drawer: [{ selector: '[data-tour-id="header-tour-button"]' }] } },
  { id: 'help', label: 'Help mode', places: { sidebar: [{ selector: '[data-tour-id="header-help"]' }], drawer: [{ selector: '[data-tour-id="header-help"]' }] } },
  { id: 'more', label: 'More', places: { menu: [{ selector: '[data-ws-more]' }] } },
  {
    id: 'account',
    label: 'Your account',
    places: {
      sidebar: [{ selector: '[data-tour-id="header-user-menu"]' }],
      drawer: [{ selector: '[data-tour-id="header-user-menu"]', inside: 'drawer' }],
      menu: [{ selector: '[data-ws-avatar]' }],
    },
  },
  {
    id: 'show-sidebar',
    label: 'Show the sidebar',
    places: { menu: [{ selector: '[data-ws-show-sidebar]' }, { selector: '[data-ws-menu-panel] [data-mode-switch="classic"]', inside: 'menu' }] },
  },
  {
    id: 'switch-workspace',
    label: 'Switch to Workspace',
    places: { sidebar: [{ selector: '[data-mode-switch="workspace"]' }], drawer: [{ selector: '[data-mode-switch="workspace"]', inside: 'drawer' }] },
  },
  { id: 'collapse-sidebar', label: 'Collapse sidebar', places: { sidebar: [{ selector: 'button[aria-label="Collapse sidebar"]' }] } },
]
