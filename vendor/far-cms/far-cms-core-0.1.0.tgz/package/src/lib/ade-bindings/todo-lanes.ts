/**
 * To-do lanes (board columns / list tabs) and what moving a card means.
 * Pure — asserted by todo-lanes.assert.ts. Every move maps onto the one
 * approval engine (approve / not now / ask for changes / task done); there
 * is no board-only state.
 */

import { goesLiveLabel, safeTimeZone } from '../publishing/schedule'

export type TodoLane = 'approve' | 'changes' | 'notnow' | 'drafts' | 'messages' | 'attention' | 'done'

export const LANES: ReadonlyArray<{ id: TodoLane; title: string; optional?: boolean }> = [
  { id: 'approve', title: 'Needs approval' },
  { id: 'changes', title: 'Changes requested' },
  { id: 'notnow', title: 'Not now' },
  { id: 'drafts', title: 'Drafts' },
  { id: 'messages', title: 'Messages' },
  { id: 'attention', title: 'Needs a look', optional: true },
  { id: 'done', title: 'Done' },
]

export type TodoTab = 'all' | 'approvals' | 'messages' | 'drafts' | 'done'

export const TABS: ReadonlyArray<{ id: TodoTab; title: string; lanes: ReadonlyArray<TodoLane> }> = [
  { id: 'all', title: 'All', lanes: ['approve', 'changes', 'notnow', 'drafts', 'messages', 'attention'] },
  { id: 'approvals', title: 'Approvals', lanes: ['approve', 'changes', 'notnow'] },
  { id: 'messages', title: 'Messages', lanes: ['messages'] },
  { id: 'drafts', title: 'Drafts', lanes: ['drafts'] },
  { id: 'done', title: 'Done', lanes: ['done'] },
]

export function isLane(v: unknown): v is TodoLane {
  return typeof v === 'string' && LANES.some((l) => l.id === v)
}
export function isTab(v: unknown): v is TodoTab {
  return typeof v === 'string' && TABS.some((t) => t.id === v)
}

/** Where an approval sits. `items` are the set's items as this reviewer sees them. */
export function approvalLane(input: {
  items: ReadonlyArray<{ status: string }>
  snoozed: boolean
  comments: ReadonlyArray<{ kind: string }>
}): TodoLane {
  const open = input.items.filter((i) => i.status === 'pending' || i.status === 'saved')
  if (!open.length) return 'done'
  // Asked for changes and nothing new has arrived yet (a rework adds a pending item).
  if (input.comments.some((c) => c.kind === 'revise') && open.every((i) => i.status === 'saved')) return 'changes'
  return input.snoozed ? 'notnow' : 'approve'
}

const TASK_LANE: Record<string, TodoLane> = { messages: 'messages', fresh: 'drafts', attention: 'attention' }
export function taskLane(group: string, status: string): TodoLane {
  return status === 'done' ? 'done' : TASK_LANE[group] ?? 'attention'
}

export type MoveAction = 'approve' | 'notNow' | 'askForChanges' | 'taskDone' | 'resume'
export type MoveDecision =
  | { kind: 'none' }
  | { kind: 'refuse'; message: string }
  | { kind: 'act'; action: MoveAction; confirm: boolean; needsText?: boolean }

/** What dragging a card from one column to another does. */
export function decideMove(item: { kind: 'approval' | 'task'; canApprove?: boolean }, from: TodoLane, to: TodoLane): MoveDecision {
  if (from === to) return { kind: 'none' }
  if (from === 'done') return { kind: 'refuse', message: 'Done is final — it has already happened.' }
  if (item.kind === 'task') {
    if (to === 'done') return { kind: 'act', action: 'taskDone', confirm: false }
    return { kind: 'refuse', message: 'This one can only be marked done.' }
  }
  switch (to) {
    case 'done':
      return item.canApprove === false
        ? { kind: 'refuse', message: 'You can’t approve this one — it needs someone with that permission.' }
        : { kind: 'act', action: 'approve', confirm: true }
    case 'notnow':
      return from === 'changes'
        ? { kind: 'refuse', message: 'It’s already parked while the changes are made.' }
        : { kind: 'act', action: 'notNow', confirm: false }
    case 'changes':
      return { kind: 'act', action: 'askForChanges', confirm: false, needsText: true }
    case 'approve':
      // "Not now" can be undone; changes requested come back when the rework arrives.
      return from === 'notnow'
        ? { kind: 'act', action: 'resume', confirm: false }
        : { kind: 'refuse', message: 'It comes back here when the changes arrive.' }
    default:
      return { kind: 'refuse', message: 'That column is for a different kind of item.' }
  }
}

/** "N need you": open approvals not parked + open tasks. */
/**
 * Whether a row counts in any number (the "N need you" title, the tab counts, badges). An approval whose
 * every open change edits something since deleted (targetGone) can only be discarded: it stays listed, uncounted.
 */
export function countsTowardTotals(i: object): boolean {
  return !(i as { targetGone?: boolean }).targetGone
}

export function needYouCount(items: ReadonlyArray<{ lane: TodoLane; targetGone?: boolean }>): number {
  return items.filter((i) => countsTowardTotals(i) && (i.lane === 'approve' || i.lane === 'messages' || i.lane === 'drafts' || i.lane === 'attention')).length
}

/** A tab's count: its lanes' rows, minus the ones that don't count (the list still shows them). */
export function tabCount(items: ReadonlyArray<{ lane: TodoLane; targetGone?: boolean }>, tab: TodoTab): number {
  const lanes = TABS.find((t) => t.id === tab)?.lanes ?? []
  return items.filter((i) => lanes.includes(i.lane) && countsTowardTotals(i)).length
}

/**
 * Approving goes public unless every item only makes or edits DRAFTS: a new
 * page/record created as a draft (no publish step), or edits to a record
 * that is still a draft. Anything else — a publish, an edit to live content —
 * counts as going live. Pure; asserted.
 */
export function approvalPublishes(items: ReadonlyArray<{ isPublish?: boolean; operation: string; targetType: string; after?: unknown }>): boolean {
  const draftOnly = (i: (typeof items)[number]) => {
    const status = (i.after as { status?: unknown } | null | undefined)?.status
    if (i.operation === 'create') return status === undefined || status === 'DRAFT'
    return i.targetType === 'record' && status === 'DRAFT'
  }
  return items.some((i) => i.isPublish || !draftOnly(i))
}

/**
 * When approving schedules something instead of putting it live now: "Goes live Fri 23 Oct, 7:38 New York
 * time", worded in the zone the person chose (input.tz). A page or record being scheduled keeps its status
 * and gains scheduledAt; a post becomes SCHEDULED. Null when nothing here is scheduled. Pure; asserted.
 */
export function goesLiveOf(items: ReadonlyArray<{ category: string; after?: unknown; input?: Record<string, unknown> }>): string | null {
  for (const i of items) {
    if (i.category !== 'publish') continue
    const after = (i.after ?? {}) as { status?: unknown; scheduledAt?: unknown }
    if (typeof after.scheduledAt !== 'string' || after.status === 'PUBLISHED') continue
    const at = new Date(after.scheduledAt)
    if (Number.isNaN(at.getTime())) continue
    return goesLiveLabel(at, { timeZone: safeTimeZone(i.input?.tz) })
  }
  return null
}

/** Any To-do item's go-live time when approving schedules it (TodoApproval.goesLive). */
function goesLive(item: unknown): string | null {
  const g = !!item && typeof item === 'object' ? (item as { goesLive?: unknown }).goesLive : null
  return typeof g === 'string' && g ? g : null
}

/** What the approve button says: only "publish" when approving changes the site; "schedule" when it sets a go-live time. */
export function approveLabel(item: unknown): string {
  if (draftOnly(item)) return 'Approve'
  return goesLive(item) ? 'Approve & schedule' : 'Approve & publish'
}

/** The confirm dialog's line: what happens when you approve. */
export function approveOutcome(item: unknown): string {
  if (draftOnly(item)) return 'It’s saved as a draft — not on the site yet.'
  const g = goesLive(item)
  return g ? `It ${g.charAt(0).toLowerCase()}${g.slice(1)}.` : 'It goes live now.'
}

/** Any To-do item: only an approval that says publishes === false is draft-only. */
function draftOnly(item: unknown): boolean {
  return !!item && typeof item === 'object' && (item as { publishes?: unknown }).publishes === false
}

/** One item's line in a batch confirm: "Goes live now", its scheduled "Goes live …", or saved as a draft. */
export function approveWhen(item: unknown): string {
  if (draftOnly(item)) return 'Saved as a draft — not on the site yet'
  return goesLive(item) ?? 'Goes live now'
}

/** Approving several at once: the button, the dialog's lead line and the toast, from what each item does. */
export function batchApproval(items: ReadonlyArray<unknown>): { label: string; intro: string; message: string } {
  const n = items.length
  const live = items.filter((i) => !draftOnly(i) && !goesLive(i)).length
  const scheduled = items.filter((i) => !draftOnly(i) && goesLive(i)).length
  const drafts = n - live - scheduled
  const label = live ? 'Approve & publish' : scheduled ? 'Approve & schedule' : 'Approve'
  if (!live && !scheduled) return { label, intro: 'These are saved as drafts — not on the site yet:', message: approvedMessage({ publishes: false }, n) }
  if (n === 1) return { label, intro: scheduled ? `This ${goesLive(items[0])!.replace(/^Goes/, 'goes')}:` : 'This goes live now:', message: approvedMessage(items[0], 1) }
  const parts = [live ? `${live} live now` : '', scheduled ? `${scheduled} scheduled` : '', drafts ? `${drafts} saved as draft${drafts === 1 ? '' : 's'}` : ''].filter(Boolean)
  const intro = !scheduled && !drafts ? 'These go live now:' : !live && !drafts ? 'These go live at their scheduled times:' : 'Each goes live as shown:'
  return { label, intro, message: `Approved ${n} — ${parts.join(', ')}.` }
}

/** What we say after approving. */
export function approvedMessage(item: unknown, count = 1): string {
  if (draftOnly(item)) return count > 1 ? `Approved ${count} — saved as drafts (not on the site yet).` : 'Approved — saved as a draft (not on the site yet).'
  const g = goesLive(item)
  if (g) return `Approved${count > 1 ? ` ${count}` : ''} — ${g.charAt(0).toLowerCase()}${g.slice(1)}.`
  return count > 1 ? `Approved ${count} — live now.` : 'Approved — it’s live.'
}
