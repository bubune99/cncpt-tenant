/**
 * Assertions for the proposed-version overlay (no DB).
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/proposed.assert.ts
 */
import assert from 'node:assert/strict'
import { overlayProposed, proposedPathFor, replayOps, type LivePage, type OverlayItem } from './proposed'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

const live: LivePage = {
  title: 'About',
  metaTitle: null,
  metaDescription: 'old',
  status: 'PUBLISHED',
  content: { version: '2.0', blocks: [{ id: 'h', tag: 'h1', textContent: 'Hi' }, { id: 's', tag: 'section', children: [] }] },
}
const t = (m: number) => new Date(Date.UTC(2026, 9, 9, 12, m))
const item = (id: string, targetType: string, m: number, extra: Partial<OverlayItem>): OverlayItem => ({
  id, targetType, before: null, after: null, input: {}, blockIds: [], createdAt: t(m), ...extra,
})
type Doc = { blocks: Array<{ id: string; textContent?: string; children?: Array<{ id: string; textContent?: string }> }> }

check('no pending items → the live page', () => {
  const p = overlayProposed(live, [])
  assert.deepEqual(p.content, live.content)
  assert.deepEqual(p.appliedItemIds, [])
})

check('content drafts STACK in draft order (two sets editing the same page both show)', () => {
  const a = item('a', 'page-content', 1, { input: { ops: [{ tool: 'updateBlock', blockId: 'h', textContent: 'Hello' }] }, blockIds: ['h'] })
  const b = item('b', 'page-content', 2, {
    input: { ops: [{ tool: 'insertBlock', parentBlockId: 's', tag: 'p', textContent: 'New', newBlockId: 'n1' }] },
    blockIds: ['n1', 's'],
  })
  const p = overlayProposed(live, [b, a])
  const doc = p.content as Doc
  assert.equal(doc.blocks[0].textContent, 'Hello')
  assert.equal(doc.blocks[1].children?.[0].id, 'n1', 'inserted with the drafted id')
  assert.deepEqual(p.appliedItemIds, ['a', 'b'])
  assert.deepEqual(p.changedBlockIds, ['h', 'n1', 's'])
  assert.equal(p.skippedOps, 0)
  assert.equal(((live.content as Doc).blocks[0]).textContent, 'Hi', 'live not mutated')
})

check('an op whose block is gone is skipped and counted', () => {
  const r = replayOps(live.content, [{ tool: 'updateBlock', blockId: 'gone', textContent: 'x' }, { tool: 'updateBlock', blockId: 'h', textContent: 'ok' }])
  assert.equal(r.skipped, 1)
  assert.equal((r.content as Doc).blocks[0].textContent, 'ok')
})

check('page field drafts apply only their own delta, in order; status takes the newest', () => {
  const base = { title: 'About', metaTitle: null, metaDescription: 'old', status: 'PUBLISHED', slug: '/about', parentId: null }
  const p = overlayProposed(live, [
    item('m1', 'page', 1, { before: base, after: { ...base, title: 'About us' } }),
    item('m2', 'page', 2, { before: base, after: { ...base, metaDescription: 'new' } }),
    item('s1', 'page-status', 3, { after: { status: 'DRAFT' } }),
    item('s2', 'page-status', 4, { after: { status: 'PUBLISHED' } }),
  ])
  assert.equal(p.title, 'About us', 'the second draft does not reset the first')
  assert.equal(p.metaDescription, 'new')
  assert.equal(p.status, 'PUBLISHED')
})

check('proposed path: home maps to the bare route; set id is encoded', () => {
  assert.equal(proposedPathFor('/'), '/ade-preview')
  assert.equal(proposedPathFor('/about/'), '/ade-preview/about')
  assert.equal(proposedPathFor('/about?x=1', 'a b'), '/ade-preview/about?set=a%20b')
})

check('an editor save replaces the whole document; later block ops stack on top of it', () => {
  const edited = { version: '2.0', blocks: [{ id: 'h', tag: 'h1', className: '', textContent: 'Edited by hand' }] }
  const r = replayOps(live.content, [{ tool: 'replaceContent', content: edited }, { tool: 'updateBlock', blockId: 'h', textContent: 'Then the agent' }])
  assert.equal(r.skipped, 0)
  assert.equal((r.content as Doc).blocks[0].textContent, 'Then the agent')
  assert.equal(replayOps(live.content, [{ tool: 'replaceContent', content: null }]).skipped, 1)
})

console.log(`\n${n} checks passed`)
