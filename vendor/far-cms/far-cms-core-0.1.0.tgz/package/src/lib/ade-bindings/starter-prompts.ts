/**
 * This app's starter prompts for the empty chat (lib/ade/chat/empty-chat):
 * the "Try asking" row and the "Quick actions" library. Data only — another
 * app (a shop) ships its own copy with its own tasks (products, orders,
 * inventory). Editable per site later; for now the owner-approved guesses.
 */

import type { StarterLibrary } from '../ade/chat/empty-chat'

export const STARTER_LIBRARY: StarterLibrary = {
  row: ['Add an initiative', 'Edit a page', 'Upload media', 'Check form messages', 'Walk me through the to-do', 'Where is something?'],
  groups: [
    {
      name: 'Content',
      cards: [
        { title: 'Add an initiative', hint: 'Create the page and a card for it', prompt: 'Add a new initiative' },
        { title: 'Edit a page', hint: 'Change a section of any page', prompt: 'Edit a page' },
        { title: 'Write a blog post', hint: 'Draft a post for review', prompt: 'Write a blog post' },
        { title: 'Fix a typo', hint: 'Point me at it and I will draft the fix', prompt: 'Fix a typo on a page' },
      ],
    },
    {
      name: 'Media',
      cards: [
        { title: 'Upload media', hint: 'Add photos to the media library', prompt: 'Upload media' },
        { title: 'Find a photo', hint: 'Search the library by name or folder', prompt: 'Find a photo in the media library' },
        { title: 'Check hero images', hint: 'See which initiatives are missing one', prompt: 'Which initiatives have no hero image?' },
      ],
    },
    {
      name: 'Forms and messages',
      cards: [
        { title: 'Check form messages', hint: 'See what people sent you', prompt: 'Check my form messages' },
        { title: 'Summarize this week', hint: 'What came in since Monday', prompt: 'Summarize form messages from this week' },
      ],
    },
    {
      name: 'Your to-do',
      cards: [
        { title: 'Walk me through the to-do', hint: 'I will point out what needs you', prompt: 'Walk me through my to-do' },
        { title: 'What changed?', hint: 'Drafts and approvals since yesterday', prompt: 'What changed since yesterday?' },
      ],
    },
    {
      name: 'Find your way around',
      cards: [
        { title: 'Where is something?', hint: 'Ask me to point at it', prompt: 'Where is the media library?' },
        { title: 'Take me to a page', hint: 'Jump straight there', prompt: 'Take me to the media library' },
        { title: 'Change the cookie banner', hint: 'Show me where it lives', prompt: 'Where do I change the cookie banner?' },
      ],
    },
  ],
}

/** The page builder's starters (owner R3): neutral conversation starters for this kind of page — they lean on
 * the block library (Saved first, then Sections, then Ideas) and the phone preview. */
const PAGE_EDITOR_STARTERS: StarterLibrary = {
  row: ['Fill in an empty section', 'Improve the wording', 'Add a call to action', 'Add a gallery under the story', 'Ideas for a banner', 'Check it on a phone'],
  groups: [
    {
      name: 'On this page',
      cards: [
        { title: 'Fill in an empty section', hint: 'I’ll ask what to say, then write it', prompt: 'Fill in the empty sections on this page' },
        { title: 'Improve the wording', hint: 'Rewrite a section in the site’s voice', prompt: 'Improve the wording on this page' },
        { title: 'Check it on a phone', hint: 'Open the phone preview and point out problems', prompt: 'Check this page on a phone' },
      ],
    },
    {
      name: 'Add from your blocks',
      cards: [
        { title: 'Add a call to action', hint: 'Uses one of your saved blocks first', prompt: 'Add a call to action after the story' },
        { title: 'Add a gallery under the story', hint: 'Uses the Gallery section from the tray', prompt: 'Add a gallery under the story' },
        { title: 'Ideas for a banner', hint: 'Layouts with placeholder words — nothing is saved', prompt: 'Give me ideas for a banner' },
        { title: 'Save a section as a block', hint: 'Reuse it on other pages', prompt: 'Save the selected section as a reusable block' },
      ],
    },
    {
      name: 'Build the page',
      cards: [
        { title: 'Build the page from a document', hint: 'Upload a Word or Google Doc', prompt: 'Build this page from a document' },
        { title: 'Plan it out first', hint: 'I’ll show the steps and wait for Go', prompt: 'Plan it out first: build this page' },
      ],
    },
  ],
}

/**
 * Page-specific starters for working screens, keyed by screen key
 * (lib/ade/screens SCREENS[].key); a screen without one shows the Home library (owner R3).
 * Screens that report live starters in their screen context (the record page) use those instead.
 */
export const SCREEN_STARTERS: Readonly<Record<string, StarterLibrary>> = {
  'page-editor': PAGE_EDITOR_STARTERS,
}
