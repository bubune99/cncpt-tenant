/**
 * "Proposed version" of a page — pure, asserted by proposed.assert.ts.
 *
 * Overlays the pending/saved change-set items for ONE page (and the
 * site-wide header/footer) onto the live state, without writing anything.
 *
 * Drafts STACK (owner decision 2026-10-09): every pending item applies in
 * the order it was drafted, so the reviewer sees the combined end state.
 *   - block content items replay their recorded block ops (updateBlock /
 *     insertBlock, with the block ids they created) on top of the live doc
 *   - page fields apply only what each draft changed (its before→after delta)
 *   - status takes the newest publish/unpublish
 * `?set=<id>` narrows the overlay to one change set (done by the caller).
 */

import { diffFields, setOverride } from '../ade'
import { applyBlockInsert, applyBlockUpdate, applyBlockRemove, applyBlockMove } from '../ai/tools/block-ops'

export interface LivePage {
  title: string
  metaTitle: string | null
  metaDescription: string | null
  status: string
  content: unknown
}

export interface OverlayItem {
  id: string
  targetType: string
  before: unknown
  after: unknown
  input: Record<string, unknown>
  blockIds: string[]
  createdAt: Date
}

export interface ProposedPage extends LivePage {
  appliedItemIds: string[]
  /** Blocks to spotlight in the proposed render (inserted ones included). */
  changedBlockIds: string[]
  /** Ops that could not be replayed (their target block is gone). */
  skippedOps: number
}

const META_FIELDS = new Set(['title', 'metaTitle', 'metaDescription'])

interface BlockOp {
  tool?: string
  /** replaceContent: the whole edited page document (a person's editor save). */
  content?: unknown
  blockId?: string
  parentBlockId?: string
  index?: number
  tag?: string
  className?: string
  textContent?: string
  attrs?: Record<string, string | null>
  label?: string
  hidden?: boolean
  newBlockId?: string
  field?: string
  value?: unknown
  componentName?: string
}

/** Replay recorded block ops onto a block document. */
export function replayOps(content: unknown, ops: ReadonlyArray<BlockOp>): { content: unknown; skipped: number } {
  let doc = content
  let skipped = 0
  for (const op of ops) {
    if (op.tool === 'updateBlock' && op.blockId) {
      const r = applyBlockUpdate(doc, {
        blockId: op.blockId,
        className: op.className,
        textContent: op.textContent,
        attrs: op.attrs,
        label: op.label,
        hidden: op.hidden,
      })
      if ('error' in r) skipped++
      else doc = r.content
    } else if (op.tool === 'insertBlock' && op.tag) {
      const r = applyBlockInsert(doc, {
        parentBlockId: op.parentBlockId,
        index: op.index,
        tag: op.tag,
        className: op.className,
        textContent: op.textContent,
        attrs: op.attrs,
        label: op.label,
        componentName: op.componentName,
        newId: op.newBlockId,
      })
      if ('error' in r) skipped++
      else doc = r.content
    } else if (op.tool === 'removeBlock' && op.blockId) {
      const r = applyBlockRemove(doc, { blockId: op.blockId })
      if ('error' in r) skipped++
      else doc = r.content
    } else if (op.tool === 'moveBlock' && op.blockId) {
      const r = applyBlockMove(doc, { blockId: op.blockId, parentBlockId: op.parentBlockId, index: op.index })
      if ('error' in r) skipped++
      else doc = r.content
    } else if (op.tool === 'replaceContent' && op.content && typeof op.content === 'object') {
      doc = op.content
    } else if (op.tool === 'setOverride' && op.blockId && op.field) {
      const r = setOverride(doc, op.blockId, op.field, op.value ?? null)
      if ('error' in r) skipped++
      else doc = r.content
    } else {
      skipped++
    }
  }
  return { content: doc, skipped }
}

function opsOf(item: OverlayItem): BlockOp[] {
  return Array.isArray(item.input.ops) ? (item.input.ops as BlockOp[]) : []
}

/** Stack every content item's ops, oldest first, onto `content`. */
export function stackContent(
  content: unknown,
  items: ReadonlyArray<OverlayItem>
): { content: unknown; applied: string[]; changed: string[]; skipped: number } {
  let doc = content
  let skipped = 0
  const applied: string[] = []
  const changed: string[] = []
  for (const item of [...items].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())) {
    const r = replayOps(doc, opsOf(item))
    doc = r.content
    skipped += r.skipped
    applied.push(item.id)
    changed.push(...item.blockIds)
  }
  return { content: doc, applied, changed: Array.from(new Set(changed)), skipped }
}

export function overlayProposed(page: LivePage, items: ReadonlyArray<OverlayItem>): ProposedPage {
  const oldestFirst = [...items].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())

  const stacked = stackContent(page.content, oldestFirst.filter((i) => i.targetType === 'page-content'))
  let next: LivePage = { ...page, content: stacked.content }
  const applied = [...stacked.applied]

  for (const item of oldestFirst.filter((i) => i.targetType === 'page')) {
    const patch: Record<string, unknown> = {}
    for (const change of diffFields(item.before, item.after)) {
      if (META_FIELDS.has(change.field)) patch[change.field] = change.after
      if (change.field === 'status' && typeof change.after === 'string') patch.status = change.after
    }
    next = { ...next, ...patch }
    applied.push(item.id)
  }

  const statusItems = oldestFirst.filter((i) => i.targetType === 'page-status')
  const lastStatus = statusItems[statusItems.length - 1]
  if (lastStatus) {
    const status = (lastStatus.after as { status?: unknown } | null)?.status
    if (typeof status === 'string') {
      next = { ...next, status }
      applied.push(lastStatus.id)
    }
  }

  return { ...next, appliedItemIds: applied, changedBlockIds: stacked.changed, skippedOps: stacked.skipped }
}

export { proposedPathFor } from '../../components/ade/preview-path'
