/**
 * Executable checks for Dzidzor's walkthrough pace: the setting's validation, a walk-through's own pace, the person's
 * saved choices, which walk-throughs play themselves, the spot-press rule (a step waiting for a click never moves on by
 * itself), and how a wait step is counted down. Adapted from BYB's walkthrough-pace.assert.ts.
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/walkthrough-pace.assert.ts
 */
import assert from 'node:assert/strict'
import { DEFAULT_PACE, initial, reduce, sanitizePace, type Pace, type PlayState } from '../ade/ui/autoplay'
import { resolveAdvance } from '../ade/ui/advance'
import {
  DEFAULT_PERSON_PLAY,
  assistantWalkFrom,
  checkPaceInput,
  classifyWalk,
  decideWalk,
  effectivePace,
  isHeld,
  NO_HOLDS,
  sanitizePersonPlay,
  sanitizeStepSeconds,
  sanitizeWalkPace,
  setCounting,
  stepDwellMs,
  tickSet,
  tickWait,
  waitPlay,
  walkthroughGuidance,
  type Walk,
} from './walkthrough-pace'

let n = 0
const ok = (c: unknown, m: string) => { assert.ok(c, m); n++ }
const eq = <T>(a: T, b: T, m: string) => { assert.deepEqual(a, b, m); n++ }

// ---------- the setting: refused when out of bounds, clamped when read ----------
const cur: Pace = { method: 'reading', seconds: 5, wordsPerMinute: 200 }
const good = checkPaceInput(cur, { method: 'fixed', seconds: 3 })
ok(good.ok && good.pace.method === 'fixed' && good.pace.seconds === 3 && good.pace.wordsPerMinute === 200, 'a partial update keeps the other fields')
ok(!checkPaceInput(cur, { seconds: 1 }).ok, 'under 2 seconds is refused')
ok(!checkPaceInput(cur, { seconds: 61 }).ok, 'over 60 seconds is refused')
ok(checkPaceInput(cur, { seconds: 2 }).ok && checkPaceInput(cur, { seconds: 60 }).ok, 'the bounds themselves are accepted')
ok(!checkPaceInput(cur, { wordsPerMinute: 99 }).ok && !checkPaceInput(cur, { wordsPerMinute: 401 }).ok, 'words per minute outside 100–400 is refused')
ok(!checkPaceInput(cur, { method: 'instant' }).ok, 'an unknown method is refused')
ok(!checkPaceInput(cur, { seconds: '3' }).ok && !checkPaceInput(cur, { seconds: Number.NaN }).ok && !checkPaceInput(cur, { seconds: Infinity }).ok, 'strings, NaN and Infinity are not numbers')
ok(!checkPaceInput(cur, null).ok && !checkPaceInput(cur, 'fixed').ok && !checkPaceInput(cur, [1]).ok, 'only an object is accepted')
eq(sanitizePace({ method: 'fixed', seconds: 9999, wordsPerMinute: -4 }), { method: 'fixed', seconds: 60, wordsPerMinute: 100 }, 'a tampered stored value is clamped when read')
eq(sanitizePace(undefined), DEFAULT_PACE, 'never saved reads as the default (reading time)')

// ---------- a walk-through's own pace and a step's own time ----------
eq(sanitizeWalkPace({ seconds: 4 }), { seconds: 4 }, 'a fixed walk pace')
eq(sanitizeWalkPace({ minSeconds: 6 }), { minSeconds: 6 }, 'a floor walk pace')
eq(sanitizeWalkPace({ seconds: 4, minSeconds: 6 }), { seconds: 4 }, 'both set: fixed wins')
eq(sanitizeWalkPace({ seconds: 1 }), undefined, 'out of bounds is dropped, not clamped (the model asked for something we do not do)')
eq(sanitizeWalkPace({ seconds: '4' }), undefined, 'a string is not a time')
eq(sanitizeWalkPace('fast'), undefined, 'only an object')
eq(sanitizeStepSeconds(61), undefined, 'a step time over 60 s is dropped')
eq(sanitizeStepSeconds(2), 2, 'the bound itself is kept')
eq(effectivePace(DEFAULT_PACE, { seconds: 4 }), { method: 'fixed', seconds: 4, wordsPerMinute: 200 }, 'the walk pace beats the app setting')
eq(effectivePace({ method: 'fixed', seconds: 9, wordsPerMinute: 150 }, { minSeconds: 6 }), { method: 'floor', seconds: 6, wordsPerMinute: 150 }, 'a floor keeps the app reading speed')
eq(effectivePace({ method: 'fixed', seconds: 9, wordsPerMinute: 150 }, undefined), { method: 'fixed', seconds: 9, wordsPerMinute: 150 }, 'no walk pace: the app setting')

// ---------- the person's saved choices ----------
eq(sanitizePersonPlay(null), DEFAULT_PERSON_PLAY, 'nothing stored: defaults')
eq(sanitizePersonPlay({ speed: 1.5, paused: true, advance: 'manual' }), { speed: 1.5, paused: true, advance: 'manual' }, 'known values are kept')
eq(sanitizePersonPlay({ speed: 99, paused: 'yes', advance: 'auto' }), DEFAULT_PERSON_PLAY, 'unknown speed, non-boolean pause and unknown advance are dropped')

// ---------- which walk-throughs play ----------
const p = DEFAULT_PERSON_PLAY
const T = 'timer' as const
const M = 'manual' as const
const playing = (w: Walk) => (w.kind === 'none' ? false : w.playing)
eq(classifyWalk({ steps: 1, advance: T, person: p, reducedMotion: false }).kind, 'none', 'a single spot never plays')
ok(playing(classifyWalk({ steps: 4, advance: T, person: p, reducedMotion: false })), 'a set on a timer plays')
ok(!playing(classifyWalk({ steps: 4, advance: M, person: p, reducedMotion: false })), 'a set the person clicks through does not')
ok(!playing(classifyWalk({ steps: 4, advance: T, person: p, reducedMotion: true })), 'reduced motion: no autoplay')
ok(!playing(classifyWalk({ steps: 4, advance: T, person: { paused: true }, reducedMotion: false })), 'a pause the person chose is kept')
eq(classifyWalk({ steps: 1, wait: { index: 1 }, advance: T, informational: true, person: p, reducedMotion: false }).kind, 'none', 'a wait of unknown length is a question, not a walk-through')
eq(classifyWalk({ steps: 1, wait: { index: 1, total: 1 }, advance: T, informational: true, person: p, reducedMotion: false }).kind, 'none', 'a one-step wait is not a walk-through')
const wait = (o: { advance: 'timer' | 'manual'; informational?: boolean; click?: boolean; index?: number; paused?: boolean; reduced?: boolean }) =>
  classifyWalk({ steps: 1, wait: { index: o.index ?? 1, total: 3 }, advance: o.advance, informational: o.informational, clickToContinue: o.click, person: { paused: o.paused ?? false }, reducedMotion: o.reduced ?? false })
ok(!playing(wait({ advance: T })), 'HARD RULE: a wait step the assistant did not mark informational is never answered for the person, even on a timer')
ok(!playing(wait({ advance: T, informational: false })), 'a step marked as needing the person is never answered')
ok(playing(wait({ advance: T, informational: true })), 'an informational wait step on a timer plays')
ok(!playing(wait({ advance: T, informational: true, click: true })), 'SPOT PRESS: a wait step that asks for a click is never answered, even marked informational')
ok(!(wait({ advance: T, informational: true, click: true }) as { canPlay: boolean }).canPlay, 'and it is not even offered to play')
ok(!playing(wait({ advance: M, informational: true })), 'an informational wait step the person clicks through does not')
ok(!playing(wait({ advance: T, informational: true, reduced: true })), 'reduced motion beats a timer on a wait')
ok(!playing(wait({ advance: T, informational: true, paused: true })), 'a pause beats a timer on a wait')

// the model can say anything: only a literal true marks a step informational, only the two advance values count
eq(assistantWalkFrom({ advance: 'timer', informational: true }), { advance: 'timer', informational: true }, 'read from the tool call')
eq(assistantWalkFrom({ advance: 'auto', informational: 'true' }), { advance: null, informational: false }, 'junk is ignored; "true" is not true')
eq(assistantWalkFrom({ pace: { seconds: 3 }, seconds: 90 }), { advance: null, informational: false, pace: { seconds: 3 } }, 'a walk pace is kept, an out-of-range step time is not')
eq(assistantWalkFrom(undefined), { advance: null, informational: false }, 'no call (a restored step): not informational')

// precedence reaches the walk: a saved "click through" beats an assistant "timer"
ok(!playing(classifyWalk({ steps: 4, advance: resolveAdvance({ steps: 4, person: 'manual', assistant: 'timer' }).advance, person: p, reducedMotion: false })), 'the person\'s saved choice beats the assistant on a set')
ok(!playing(wait({ advance: resolveAdvance({ steps: 3, person: 'manual', admin: 'timer', assistant: 'timer' }).advance, informational: true })), 'and on an informational wait')
ok(playing(wait({ advance: resolveAdvance({ steps: 3, person: 'timer', admin: 'manual', assistant: 'manual' }).advance, informational: true })), 'and the other way')

// ---------- the pace reaches the countdown ----------
const step = { title: 'Orders', sentence: 'Every order, newest first.' }
const fixed3: Pace = { method: 'fixed', seconds: 3, wordsPerMinute: 200 }
eq(stepDwellMs(step, fixed3, undefined, 1), 3000, 'fixed 3 s: every step stays 3.0 s')
eq(stepDwellMs(step, fixed3, undefined, 1.5), 2000, 'the person\'s speed applies on top')
eq(stepDwellMs({ sentence: 'word '.repeat(200) }, fixed3, undefined, 1), 3000, 'fixed ignores length')
ok(stepDwellMs({ sentence: 'word '.repeat(200) }, DEFAULT_PACE, undefined, 1) === 14000, 'reading time is capped')
ok(stepDwellMs(step, { method: 'floor', seconds: 30, wordsPerMinute: 200 }, undefined, 1) === 30000, 'floor holds a short step up to the minimum')
eq(stepDwellMs({ ...step, seconds: 7 }, fixed3, { seconds: 5 }, 1), 7000, 'precedence: a step\'s own time beats the walk pace and the app')
eq(stepDwellMs(step, fixed3, { seconds: 5 }, 1), 5000, 'then the walk pace beats the app')
eq(stepDwellMs({ ...step, seconds: 0.5 }, fixed3, undefined, 1), 3000, 'a step time out of bounds is ignored, not clamped')

// A set at fixed 3 s, ticked at 250 ms like the player: steps change 3.0 s apart; the last is held.
const never = () => false
{
  let s: PlayState = initial(3, { autoplay: true })
  const at: number[] = []
  const dwell = () => stepDwellMs(step, fixed3, undefined, s.speed)
  for (let t = 0; t < 12000 && !s.done; t += 250) {
    const before = s.index
    s = tickSet(s, 250, dwell, never)
    if (s.index !== before) at.push(t + 250)
  }
  eq(at, [3000, 6000], 'steps change 3.0 s apart')
  ok(s.done && s.index === 2, 'the last step is held, not closed or looped')
  s = tickSet(s, 500, dwell, never)
  ok(s.done && s.index === 2, 'a held last step stays held')
}
{
  // SPOT PRESS on a set: step 2 of 3 asks for a click. The countdown reaches it and stops there.
  const click = (i: number) => i === 1
  let s: PlayState = initial(3, { autoplay: true })
  for (let t = 0; t < 60_000; t += 250) s = tickSet(s, 250, () => 3000, click)
  ok(s.index === 1 && s.elapsed === 0 && !s.done, 'the countdown never moves a step that waits for the person\'s click')
  ok(!setCounting(s, click(s.index)), 'and no countdown is shown on it')
  // Their click moves the walk on (the card's Next / spot-press-wire); the countdown starts fresh on the next step.
  s = reduce(s, { type: 'goto', index: 2 }, () => 3000)
  ok(s.playing && s.elapsed === 0, 'after their click, autoplay carries on as it was')
  ok(setCounting(s, click(s.index)), 'and the countdown shows again')
}
{
  let s: PlayState = initial(3, { autoplay: true })
  const dwell = () => 3000
  s = reduce(s, { type: 'hold', held: true }, dwell) // hidden tab, hover or typing
  for (let i = 0; i < 40; i++) s = tickSet(s, 250, dwell, never)
  ok(s.index === 0 && s.elapsed === 0, 'a held countdown does not move')
  ok(!setCounting(s, false), 'and is not shown as counting')
  s = reduce(s, { type: 'hold', held: false }, dwell)
  s = reduce(s, { type: 'pause' }, dwell)
  for (let i = 0; i < 40; i++) s = tickSet(s, 250, dwell, never)
  ok(s.index === 0, 'a pause does not move it either')
  s = reduce(s, { type: 'play' }, dwell)
  s = reduce(s, { type: 'tick', dt: 1000 }, dwell)
  s = reduce(s, { type: 'next' }, dwell)
  ok(s.index === 1 && s.elapsed === 0 && s.playing, 'Next restarts the countdown and keeps autoplay')
  s = reduce(s, { type: 'prev' }, dwell)
  ok(s.index === 0 && s.elapsed === 0 && s.playing, 'Back too')
}
ok(!initial(3, { autoplay: true, reducedMotion: true }).playing, 'reduced motion starts still')

// ---------- a wait step: advances once on a step with a next, holds the last ----------
{
  const w = wait({ advance: T, informational: true }) as Extract<Walk, { kind: 'wait' }>
  let s = waitPlay(w, 1)
  let advances = 0
  for (let t = 0; t < 8000; t += 250) {
    const r = tickWait(s, 250, 3000)
    s = r.state
    if (r.advance) advances++
  }
  eq(advances, 1, 'the countdown asks for the next step exactly once')
  const held = tickWait({ ...waitPlay(w, 1), held: true }, 10_000, 3000)
  ok(!held.advance && held.state.elapsed === 0, 'a held wait step does not advance')
  const idle = waitPlay(wait({ advance: T }) as Extract<Walk, { kind: 'wait' }>, 1)
  ok(!tickWait(idle, 60_000, 3000).advance, 'a wait that is not informational never advances')
  const clicky = waitPlay(wait({ advance: T, informational: true, click: true }) as Extract<Walk, { kind: 'wait' }>, 1)
  ok(!tickWait(clicky, 60_000, 3000).advance, 'a wait that asks for a click never advances')
  const last = wait({ advance: T, informational: true, index: 3 }) as Extract<Walk, { kind: 'wait' }>
  let l = waitPlay(last, 1)
  let lastAdvances = 0
  for (let t = 0; t < 30_000; t += 250) {
    const r = tickWait(l, 250, 3000)
    l = r.state
    if (r.advance) lastAdvances++
  }
  ok(lastAdvances === 0 && !l.playing && l.elapsed === 0, 'the last step of a wait walk-through has no countdown and is never answered: Got it is the person\'s')
}

// ---------- who decides, through the real composition (person > site rule > assistant > timer) ----------
{
  const base = { person: p, reducedMotion: false }
  const set = (saved: unknown, rule: unknown, assistant: unknown) => decideWalk({ ...base, steps: 3, saved, rule, assistant })
  const wt = (saved: unknown, rule: unknown, assistant: unknown, informational = true) => decideWalk({ ...base, steps: 1, wait: { index: 1, total: 3 }, saved, rule, assistant, informational })
  for (const [name, mk] of [['set', set], ['informational wait', wt]] as const) {
    const run = (saved: unknown, rule: unknown, assistant: unknown) => { const d = mk(saved, rule, assistant); return d.walk.kind !== 'none' && d.walk.playing }
    ok(!run(null, 'manual', 'timer'), `${name}: rule manual, no personal choice, assistant timer: no autoplay`)
    ok(run(null, 'timer', 'manual'), `${name}: rule timer, assistant manual: autoplay`)
    ok(!run('manual', 'timer', 'timer'), `${name}: a saved manual beats rule timer`)
    ok(run('timer', 'manual', 'manual'), `${name}: a saved timer beats rule manual`)
    ok(run(null, 'assistant', 'timer') && !run(null, 'assistant', 'manual'), `${name}: rule assistant defers to the assistant`)
    ok(run(null, 'assistant', undefined), `${name}: nobody decided: a timer`)
    ok(!run(null, 'nonsense-rule', 'manual'), `${name}: an unknown rule means the assistant decides`)
  }
  ok(!(wt(null, 'timer', 'timer', false).walk as { playing: boolean }).playing, 'a timer rule never plays a wait step that is not informational')
  eq(decideWalk({ ...base, steps: 1, saved: 'timer', rule: 'timer', assistant: 'timer' }).walk.kind, 'none', 'one spot never plays, whoever asks')
}

// ---------- what freezes the countdown ----------
ok(!isHeld(NO_HOLDS, 1000), 'nothing holding: counting')
ok(isHeld({ ...NO_HOLDS, hover: true }, 1000), 'pointer over the card freezes it')
ok(isHeld({ ...NO_HOLDS, focus: true }, 1000), 'focus inside the card freezes it')
ok(isHeld({ ...NO_HOLDS, hidden: true }, 1000), 'a hidden tab freezes it')
ok(isHeld({ ...NO_HOLDS, typingUntil: 9000 }, 1000) && !isHeld({ ...NO_HOLDS, typingUntil: 9000 }, 9000), 'typing holds it until the quiet period ends')
{
  // Through the clock: a hold freezes elapsed exactly, and releasing it carries on from there.
  let st: PlayState = initial(3, { autoplay: true })
  const d = () => 3000
  st = reduce(st, { type: 'tick', dt: 1000 }, d)
  st = reduce(st, { type: 'hold', held: isHeld({ ...NO_HOLDS, hidden: true }, 0) }, d)
  for (let i = 0; i < 100; i++) st = reduce(st, { type: 'tick', dt: 500 }, d)
  eq(st.elapsed, 1000, 'a hidden tab keeps the elapsed time, however many ticks arrive')
  st = reduce(st, { type: 'hold', held: isHeld(NO_HOLDS, 0) }, d)
  st = reduce(st, { type: 'tick', dt: 500 }, d)
  eq(st.elapsed, 1500, 'and carries on from there')
}

// ---------- what the assistant is told ----------
{
  const free = walkthroughGuidance({ person: null, admin: 'assistant' })
  ok(free.startsWith('[Walkthrough] ') && free.includes('ask_user'), 'nobody decided: the assistant may choose, and ask once')
  const decided = walkthroughGuidance({ person: 'manual', admin: 'timer' })
  ok(decided.includes('Do not ask') && decided.includes('"manual"') && !decided.includes('ask_user'), 'the person decided: told not to ask, and which applies')
  ok(walkthroughGuidance({ person: 'sideways', admin: 'timer' }).includes('This site plays walkthroughs by themselves'), 'a junk personal value from the browser is ignored; the site rule applies')
  for (const g of [free, decided]) ok(g.includes('informational') && g.includes('pace.seconds') && g.includes('never say a walk-through plays'), 'always: the informational rule, the pace rule, no autoplay claims')
}

console.log(`walkthrough-pace assertions passed: ${n} checks`)
