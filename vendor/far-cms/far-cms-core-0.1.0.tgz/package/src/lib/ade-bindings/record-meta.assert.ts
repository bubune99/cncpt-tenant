/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/record-meta.assert.ts
 */
import assert from 'node:assert/strict'
import { clip, metaFromRecord } from './record-meta'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const OLD = 'https://pub-89521fc08b10436cb278c7c927b1a037.r2.dev/images/Akuse-Hospital.jpg'

check('summary + main photo by default, photo from the media domain', () => {
  assert.deepEqual(metaFromRecord({ summary: 'Supporting a hospital.', heroImageUrl: OLD }), {
    description: 'Supporting a hospital.',
    image: 'https://dzidzor-media.farsociety.com/images/Akuse-Hospital.jpg',
  })
})

check('explicit SEO description / share image win', () => {
  assert.deepEqual(metaFromRecord({ summary: 's', seoDescription: 'For search', heroImageUrl: OLD, shareImageUrl: 'https://x.test/s.png' }), { description: 'For search', image: 'https://x.test/s.png' })
})

check('falls back to the goal; nothing → no keys', () => {
  assert.equal(metaFromRecord({ goal: 'Our goal text' }).description, 'Our goal text')
  assert.deepEqual(metaFromRecord({ summary: '  ', heroImageUrl: '' }), {})
  assert.deepEqual(metaFromRecord(null), {})
})

check('long text is clipped on a word boundary', () => {
  const long = 'word '.repeat(60).trim()
  const c = clip(long)
  assert.ok(c.length <= 160 && c.endsWith('…') && !c.includes('wor…'))
  assert.equal(clip('short'), 'short')
})

console.log(`\n${n} checks passed`)
