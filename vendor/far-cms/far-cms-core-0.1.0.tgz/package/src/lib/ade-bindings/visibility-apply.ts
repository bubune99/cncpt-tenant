/**
 * The one function every server read path runs a tool result through
 * before it can reach a model (chat guard, MCP surface). Pure (rules and
 * role are passed in); asserted by visibility-apply.assert.ts.
 */

import {
  blockedResult,
  maskData,
  metadataOnly,
  resolveEntity,
  resolveRoute,
  type ViewerRole,
  type Visibility,
  type VisibilityRule,
} from '../ade/governance/visibility'

/** What a refusal or mask looks like for agent activity (lib/ai/agent-runs reportReadBlocked). */
export interface ReadBlockedReport {
  mode: 'blocked' | 'masked' | 'metadata-only'
  /** A label for what was refused — never the value. */
  target: string
  fields?: string[]
  /** The rule id (floor.secrets, pii.contact, people.users, custom.*). */
  reason?: string
  tool?: string
}

/**
 * What a read tool's input points at: an entity type (entity tools, MCP
 * get_customer/list_users…) and/or a route (screenshot_page, navigate).
 */
export const TOOL_ENTITY: Record<string, string> = {
  list_users: 'user',
  get_customer: 'customer',
  list_customers: 'customer',
  getRecord: 'record',
  get_settings: 'settings',
  // Orders carry names, emails and addresses: an orders area set to "assistant may not see" must cover them all.
  searchOrders: 'order',
  list_orders: 'order',
  get_order: 'order',
  updateOrderStatus: 'order',
  fulfillOrder: 'order',
  refundOrder: 'order',
  cancelOrder: 'order',
  // New users' names (and order numbers) — people data.
  getRecentActivity: 'user',
  // What visitors typed into forms: a submissions area the assistant may not see covers it.
  listFormSubmissions: 'submission',
}

export function targetsOf(tool: string, input: unknown): { entity?: string; route?: string } {
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>
  const entity = typeof i.entityType === 'string' ? i.entityType : TOOL_ENTITY[tool]
  const routeRaw = [i.path, i.route, i.url, i.href].find((v) => typeof v === 'string') as string | undefined
  const route = routeRaw ? (routeRaw.startsWith('http') ? safePath(routeRaw) : routeRaw) : undefined
  return { ...(entity ? { entity } : {}), ...(route?.startsWith('/') ? { route } : {}) }
}

function safePath(url: string): string | undefined {
  try {
    const u = new URL(url)
    return `${u.pathname}${u.search}`
  } catch {
    return undefined
  }
}

const RANK: Record<Visibility, number> = { readable: 0, 'metadata-only': 1, blocked: 2 }

/**
 * Run a tool result through the policy: a blocked target becomes
 * { blocked, reason, canGuide }; metadata-only keeps the shape, not the
 * values; everything else has private fields masked. Reports each refusal
 * or mask (names only). Never throws: on an internal error the result is
 * reduced to metadata-only rather than passed through.
 */
export function applyVisibility(args: {
  tool: string
  input: unknown
  output: unknown
  role: ViewerRole
  rules: readonly VisibilityRule[]
  report?: (r: ReadBlockedReport) => void
}): unknown {
  const { tool, input, output, role, rules, report } = args
  try {
    const t = targetsOf(tool, input)
    const byEntity = t.entity ? resolveEntity(rules, t.entity, role) : null
    const byRoute = t.route ? resolveRoute(rules, t.route, role) : null
    const decided = [byEntity, byRoute].filter(Boolean).sort((a, b) => RANK[b!.level] - RANK[a!.level])[0] ?? null
    const label = t.route ?? (t.entity ? `${t.entity} records` : tool)
    if (decided?.level === 'blocked') {
      report?.({ mode: 'blocked', target: label, reason: decided.rule?.id, tool })
      return blockedResult(decided.rule, label)
    }
    if (decided?.level === 'metadata-only') {
      report?.({ mode: 'metadata-only', target: label, reason: decided.rule?.id, tool })
      return { metadataOnly: true, reason: decided.rule?.id ?? 'policy', shape: metadataOnly(output), note: 'Only what is there is shown, not the values — this is private for your role.' }
    }
    const { data, report: masked } = maskData(output, rules, role)
    if (masked.fields.length) report?.({ mode: 'masked', target: label, fields: masked.fields, reason: masked.rules[0], tool })
    return data
  } catch {
    return { metadataOnly: true, reason: 'policy-error', shape: metadataOnly(output) }
  }
}
