/**
 * Agent activity (ADE v2 phase 2) — what the briefing says about the
 * assistant's day, and which things link to a run. Pure; asserted by
 * agent-activity.assert.ts. The data comes from (forms-pkg)
 *   GET /api/admin/agent-activity/summary?since=<ISO>
 *   → { since, runs, failures: [{ id, request, at, status }], writes, draftsAwaiting,
 *       spend: { tokens, cost (USD estimate), budgetTokens (per person per day, 0 = unlimited), people } }
 *
 * The CMS works without AI: when the assistant is off, or it did nothing
 * today, the section is not shown at all.
 */

export interface AgentFailure {
  id: string
  /** What the person asked (first words, redacted by the server). */
  request: string
  at: string | null
  /** error | aborted | budget */
  status: string | null
}

export interface AgentSpend {
  tokens: number
  /** USD estimate. */
  cost: number
  /** The daily token budget per person; 0 = unlimited. */
  budgetTokens: number
  /** Distinct people who ran the assistant in the window. */
  people: number
}

export interface AgentActivitySummary {
  runs: number
  failures: AgentFailure[]
  /** Real failures today (error/aborted); `failures` lists at most 10. */
  failedCount: number
  writes: number
  draftsAwaiting: number
  spend: AgentSpend
}

export const AGENT_ACTIVITY_PATH = '/admin/agent-activity'

const n = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : null)

/** Validate the API's JSON; null when it isn't a summary (AI off, error, old server). */
export function parseAgentSummary(json: unknown): AgentActivitySummary | null {
  if (!json || typeof json !== 'object') return null
  const o = json as Record<string, unknown>
  if (o.aiEnabled === false || o.enabled === false) return null
  const runs = n(o.runs)
  if (runs === null) return null
  const failures = Array.isArray(o.failures)
    ? o.failures
        .filter((f): f is Record<string, unknown> => !!f && typeof f === 'object' && typeof (f as Record<string, unknown>).id === 'string')
        .map((f) => ({
          id: String(f.id),
          request: typeof f.request === 'string' ? f.request : '',
          at: typeof f.at === 'string' ? f.at : null,
          status: typeof f.status === 'string' ? f.status : null,
        }))
    : []
  const sp = o.spend && typeof o.spend === 'object' ? (o.spend as Record<string, unknown>) : {}
  return {
    runs,
    failures,
    failedCount: Math.max(n(o.failedCount) ?? 0, failures.length),
    writes: n(o.writes) ?? 0,
    draftsAwaiting: n(o.draftsAwaiting) ?? 0,
    spend: { tokens: n(sp.tokens) ?? 0, cost: n(sp.cost) ?? 0, budgetTokens: n(sp.budgetTokens) ?? 0, people: n(sp.people) ?? 0 },
  }
}

/** Show the section only when AI is on AND the assistant actually ran. */
export function showAgentActivity(summary: AgentActivitySummary | null, aiAvailable: boolean): summary is AgentActivitySummary {
  return aiAvailable && !!summary && summary.runs > 0
}

const plural = (count: number, one: string, many = `${one}s`) => `${count} ${count === 1 ? one : many}`

/**
 * Share of today's budget used, rounded: tokens against the per-person
 * budget × the people who used it. null when the budget is unlimited (0).
 */
export function budgetPercent(spend: AgentSpend): number | null {
  if (!(spend.budgetTokens > 0)) return null
  const allowance = spend.budgetTokens * Math.max(1, spend.people)
  return Math.min(999, Math.round((spend.tokens / allowance) * 100))
}

/** "about $0.42" (USD estimate); '' when nothing was spent. */
export function costLabel(cost: number): string {
  if (!(cost > 0)) return ''
  return cost < 0.01 ? 'under 1¢' : `about $${cost.toFixed(2)}`
}

/**
 * "The assistant worked 12 times today — 2 failed, 5 changes made, 3 drafts
 * are waiting for your review. About $0.42 · 24% of today's budget."
 */
export function agentActivitySentence(s: AgentActivitySummary): string {
  const bits: string[] = []
  if (s.failedCount) bits.push(`${s.failedCount} failed`)
  if (s.writes) bits.push(`${plural(s.writes, 'change')} made`)
  if (s.draftsAwaiting) bits.push(`${plural(s.draftsAwaiting, 'draft')} ${s.draftsAwaiting === 1 ? 'is' : 'are'} waiting for your review`)
  const head = `The assistant worked ${s.runs === 1 ? 'once' : `${s.runs} times`} today`
  const cost = costLabel(s.spend.cost)
  const pct = budgetPercent(s.spend)
  const spendBits = [cost && cost[0].toUpperCase() + cost.slice(1), pct !== null && `${pct}% of today’s budget`].filter(Boolean)
  return `${head}${bits.length ? ` — ${bits.join(', ')}` : ''}.${spendBits.length ? ` ${spendBits.join(' · ')}.` : ''}`
}

/** Where a run opens. */
export function runHref(runId: string): string {
  return `${AGENT_ACTIVITY_PATH}?run=${encodeURIComponent(runId)}`
}

// ---------------------------------------------------------------------------
// Which things link to a run. The field names live here (one place) so the
// recording side (forms-pkg) can change them without touching the screens.
// ---------------------------------------------------------------------------

const runIdOf = (v: unknown): string | null => (typeof v === 'string' && v.trim() ? v : null)

/** An assistant chat message's run (its metadata carries the run id). */
export function messageRunId(message: { role?: string; metadata?: unknown } | null | undefined): string | null {
  if (!message || message.role !== 'assistant') return null
  const meta = message.metadata as Record<string, unknown> | null | undefined
  return runIdOf(meta?.runId)
}

/** An audit-log row made by an agent run (its details carry the run id). */
export function auditRunId(row: { source?: unknown; details?: unknown; metadata?: unknown } | null | undefined): string | null {
  if (!row) return null
  const details = (row.details ?? row.metadata) as Record<string, unknown> | null | undefined
  return runIdOf(details?.runId)
}
