/**
 * This app's money actions (control layer risk class "money"): prices, stock
 * and order states always need the person's explicit approval with before and
 * after — never run on the assistant's say-so in any mode. Applied to the tool
 * registry (lib/ade/ui/control withMoneyRules).
 */

const touches = (keys: readonly string[]) => (input: unknown) => {
  const o = (input ?? {}) as Record<string, unknown>
  return keys.some((k) => o[k] !== undefined && o[k] !== null)
}

export const MONEY_TOOLS: Readonly<Record<string, true | ((input: unknown) => boolean)>> = {
  // A new product carries its price.
  createProduct: true,
  // Price or stock changes only (a title or description edit isn't money).
  updateProduct: touches(['basePrice', 'compareAtPrice', 'costPrice', 'stock']),
  manageProductVariant: touches(['price', 'compareAtPrice', 'stock']),
  // Pushes prices to the payment provider.
  syncProductToStripe: true,
  // Money back: a cancel or refund status (shipping or processing is not money).
  updateOrderStatus: (input) => ['CANCELLED', 'REFUNDED'].includes(String((input as { status?: unknown } | null)?.status ?? '')),
  fulfillOrder: true,
  refundOrder: true,
  cancelOrder: true,
}
