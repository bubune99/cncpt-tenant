/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/record-checklist.assert.ts
 */
import assert from 'node:assert/strict'
import { blockingItems, checklistSummary, evaluateChecklist } from '../ade/records/checklist'
import { generateTasks } from '../ade/tasks/generate'
import { recordChecklist, REVIEWED_ITEM } from './record-checklist'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const full = {
  name: 'Akuse Hospital',
  summary: 'Supporting one of the oldest hospitals in Ghana.',
  location: 'Lower Manya, Ghana',
  stage: 'active',
  goal: 'g',
  progress: 'p',
  beneficiaries: 'b',
  heroImageUrl: 'https://pub-89521fc08b10436cb278c7c927b1a037.r2.dev/images/Akuse-Hospital.jpg',
}

check('a complete initiative needs only the manual review tick', () => {
  const r = recordChecklist('initiative', { data: full })!
  assert.equal(r.requiredLeft, 1)
  assert.deepEqual(blockingItems(r).map((i) => i.id), [REVIEWED_ITEM])
  assert.equal(r.optionalLeft, 0)
  const ticked = recordChecklist('initiative', { data: full }, { [REVIEWED_ITEM]: true })!
  assert.ok(ticked.ready)
  assert.equal(checklistSummary(ticked), 'Ready')
})

check('the photo must be served from the media domain (legacy bucket host counts; others don’t)', () => {
  const r = recordChecklist('initiative', { data: { ...full, heroImageUrl: 'https://example.com/x.jpg' } }, { reviewed: true })!
  const photo = r.items.find((i) => i.id === 'photo')!
  assert.ok(!photo.done && /Media library/.test(photo.hint ?? ''))
  assert.ok(!r.ready)
})

check('missing facts are listed with plain hints; optional items only warn', () => {
  const r = recordChecklist('initiative', { data: { name: 'New', stage: 'active', goal: 'g' } })!
  const missing = r.items.filter((i) => !i.done).map((i) => i.id)
  assert.deepEqual(missing, ['photo', 'summary', 'location', 'story', 'share', 'reviewed'])
  assert.equal(r.requiredLeft, 5)
  assert.equal(r.optionalLeft, 1)
  assert.equal(r.items.find((i) => i.id === 'story')!.hint, 'Still empty: Progress so far, Who it helps')
  assert.equal(checklistSummary(r), '5 items left')
})

check('the placement item appears only when there are rules to check', () => {
  assert.ok(!recordChecklist('initiative', { data: full })!.items.some((i) => i.id === 'placement'))
  const r = recordChecklist('initiative', { data: full, placementMatches: false }, { reviewed: true })!
  assert.ok(r.ready && r.optionalLeft === 1)
})

check('unknown types have no checklist; manual items ignore truthy non-booleans', () => {
  assert.equal(recordChecklist('event', { data: {} }), null)
  const r = evaluateChecklist([{ id: 'm', label: 'M', required: true, kind: 'manual' }], {}, { m: 'yes' as unknown as boolean })
  assert.equal(r.ready, false)
})

check('To-do: a draft record becomes “Ready to publish: <name> — N items left”', () => {
  const tasks = generateTasks(
    {
      pendingChangeSets: [],
      unreadSubmissions: [],
      staleDrafts: [],
      brokenMedia: [],
      failedJobs: [],
      recordsToPublish: [{ type: 'initiative', id: 'r1', title: 'Clean Water Pilot', left: 2 }],
    },
    { now: new Date('2026-10-10T00:00:00Z'), staleDraftDays: 14 }
  )
  assert.equal(tasks.length, 1)
  assert.equal(tasks[0].title, 'Ready to publish: Clean Water Pilot — 2 items left')
  assert.equal(tasks[0].href, '/admin/records/initiative/r1?details=1&tab=ready')
  assert.equal(tasks[0].dedupeKey, 'record-ready:r1')
})

console.log(`\n${n} checks passed`)
