/**
 * Dzidzor's ready-to-go-public checklists, per record type (engine:
 * lib/ade/records/checklist). Used by the record's Details panel, the
 * publish route (server re-checks — the client can't skip it) and the
 * To-do signal "Ready to publish: <name> — N items left".
 */

import { evaluateChecklist, REVIEWED_ITEM, type ChecklistItemDef, type ChecklistResult, type ChecklistRow, type RecordChecklistCtx } from '../ade/records/checklist'
import { getRecordType, RECORD_TYPES } from './record-types'

export { REVIEWED_ITEM }
export type { RecordChecklistCtx }

/** Each type's checklist, from its definition (a new type brings its own; none → no checklist). */
export const RECORD_CHECKLISTS: Readonly<Record<string, ReadonlyArray<ChecklistItemDef<RecordChecklistCtx>>>> = Object.fromEntries(
  Object.values(RECORD_TYPES).flatMap((t) => (t.checklist ? [[t.key, t.checklist]] : []))
)

/**
 * Sent from a phone (owner, 2026-10-11: "they will be able to access from
 * the web anyways"): the story sections are warnings, not blockers — it can
 * be approved and published, and `later` says what to fill in on the web.
 */
export const PHONE_WARNING_ITEMS: ReadonlySet<string> = new Set(Object.values(RECORD_TYPES).flatMap((t) => t.phoneWarnings ?? []))

/** From a phone, the type's phone-warning items stop blocking (and are listed for later). */
export function relaxForPhone(r: ChecklistResult, type?: string): { result: ChecklistResult; later: ChecklistRow[] } {
  const warn = new Set(type ? getRecordType(type)?.phoneWarnings ?? [] : PHONE_WARNING_ITEMS)
  const items = r.items.map((i) => (warn.has(i.id) ? { ...i, required: false } : i))
  return { result: { ...r, items }, later: items.filter((i) => warn.has(i.id) && !i.done) }
}

export function recordChecklist(type: string, ctx: RecordChecklistCtx, ticks: Readonly<Record<string, boolean>> = {}): ChecklistResult | null {
  const defs = getRecordType(type)?.checklist ?? null
  return defs ? evaluateChecklist(defs, ctx, ticks) : null
}
