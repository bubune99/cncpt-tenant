/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/chain-steps.assert.ts
 */
import assert from 'node:assert/strict'
import { TOOL_REGISTRY } from '../ai/governance/tool-registry'
import { buildChain } from '../ade/chat/thought-chain'
import { CHAIN_STEP_DEPS } from './chain-steps'
import { PLUMBING_TOOLS } from '../ade/chat/chain-constants'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const titleFor = (name: string, input: Record<string, unknown> = {}) =>
  buildChain({ parts: [{ type: `tool-${name}`, toolCallId: 'x', state: 'output-available', input, output: { ok: true } }], planBefore: null, busy: false, deps: CHAIN_STEP_DEPS }).chain!.steps[0]

check('every registered tool gets a plain step title — never its name', () => {
  for (const name of Object.keys(TOOL_REGISTRY)) {
    // Plumbing (the plan tool, load_tools) is never a step.
    if (PLUMBING_TOOLS.has(name)) { assert.equal(buildChain({ parts: [{ type: `tool-${name}`, toolCallId: 'x', state: 'output-available', input: {}, output: {} }], planBefore: null, busy: false }).chain, null); continue }
    const t = titleFor(name).title
    assert.ok(t.length > 0 && t.length <= 80, name)
    assert.ok(!t.includes(name), `${name} → "${t}"`)
    assert.ok(!/_|[a-z][A-Z]/.test(t), `${name} → "${t}" looks like code`)
  }
})

check('the words from the recorded sample (playbook 13b) read plainly', () => {
  assert.equal(titleFor('read_view').title, 'Look at the screen')
  assert.equal(titleFor('navigateTo').title, 'Go to the page')
  assert.equal(titleFor('describe_platform').title, 'Check how the platform works')
  assert.equal(titleFor('spotlight_steps').title, 'Point it out on screen')
  assert.equal(titleFor('searchEntities', { entityType: 'initiative', query: 'Ho' }).title, 'Search initiatives for “Ho”')
})

check('"Looked at" names the thing, not the action', () => {
  assert.deepEqual(titleFor('listInitiatives').trace!.lookedAt, ['The initiatives list'])
  assert.deepEqual(titleFor('read_view').trace!.lookedAt, ['The screen'])
  assert.deepEqual(titleFor('searchEntities', { entityType: 'page' }).trace!.lookedAt, ['Pages'])
})

check('a failed change names where to do it by hand', () => {
  const { chain } = buildChain({ parts: [{ type: 'tool-updatePage', toolCallId: 'u', state: 'output-available', input: {}, output: { success: false, error: 'Locked' } }], planBefore: null, busy: false, deps: CHAIN_STEP_DEPS })
  assert.equal(chain!.problem!.manual, 'You can do it yourself in Pages: open the page and edit it there.')
})

console.log(`\n${n} checks passed`)
