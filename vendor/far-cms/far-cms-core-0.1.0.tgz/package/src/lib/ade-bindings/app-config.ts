/**
 * This app's defaults for the shared ADE layer. The shared code (src/lib/ade,
 * components/ade, lib/features) never hard-codes these; another app ships its
 * own copy of this file with its own values. No brand here: the site's name
 * and mark come from Settings › Identity & brand (lib/settings/brand).
 *
 * Pure data, no runtime imports — safe from server, client and settings code alike.
 */

import type { PlatformVocabulary } from '../ade/platform-map'

export interface BriefingChip {
  /** Lucide icon name (components/admin/nav-icon-map). */
  icon: string
  label: string
  /** What the chip asks the assistant. */
  ask: string
}

/** Extra assistant tool-group hints (lib/ai/toolsets ToolHints): [pattern, groups]. */
export interface AppToolHints {
  routes: ReadonlyArray<readonly [RegExp, readonly string[]]>
  keywords: ReadonlyArray<readonly [RegExp, readonly string[]]>
}

/** A button on a briefing row: open a link ('task' = the task's own link) or ask the assistant ({title}/{detail} filled in). */
export interface BriefingAction {
  label: string
  primary?: boolean
  to?: 'task' | string
  ask?: string
}

/** How the briefing shows one task source: dot colour, actions, and whether same-source tasks merge into one row. */
export interface BriefingTaskStyle {
  tone: 'accent' | 'bad' | 'warn'
  actions: ReadonlyArray<BriefingAction>
  /** Merge every open task of this source into one row titled with {n} (their quoted names become the detail). */
  merge?: { one: string; many: string }
}

export interface AppAdeDefaults {
  /** Org admin theme when the `ade` settings group has none (lib/ade/ui/admin-theme ADMIN_THEMES id). */
  adminTheme: string
  /** commerce.enabled when neither the settings row nor COMMERCE_ENABLED is set (and on a DB error). */
  commerceEnabled: boolean
  /** The assistant briefing's quick actions. */
  briefingChips: ReadonlyArray<BriefingChip>
  /** Example request in the dashboard's ask box. */
  askExample?: string
  /** Per task source (To-do), how the assistant briefing shows it; others get an "Open" link. */
  briefingTasks?: Readonly<Record<string, BriefingTaskStyle>>
  /** Which assistant tool groups this app's screens and words need (on top of the generic CMS ones). */
  toolHints: AppToolHints
  /** The assistant column's width before anyone drags it: share of the viewport, capped (lib/ade/ui/split). */
  agentDefault: { ratio: number; maxPx: number }
  /** The owner's words for each admin area (lib/ade/platform-map): keyed by nav href, `records:<type>` or `settings:<section>`. */
  vocabulary: PlatformVocabulary
  /** The phone admin (lib/ade/mobile): where the tabs go, which areas are desktop-only, the default pins. */
  mobile: AppMobileDefaults
  /** Who client feedback goes to, by name ("Tell Bubune…"); none: "the site's builder". */
  feedbackOwnerName?: string
  /** The top bar's avatar menu › Profile: where a person edits their own account. None: no Profile row. */
  accountProfileHref?: string
  /**
   * Whole home screen designs a person can pick (lib/ade/home/home-style). Two or more: new staff start on one
   * at random and can switch in Customize. None: the one home ('focused'), no choice shown.
   */
  homeStyles?: ReadonlyArray<HomeStyleOption>
}

export interface HomeStyleOption {
  /** Lowercase id, stored per person. */
  id: string
  label: string
  /** One line under the label in Customize. */
  description: string
}

export interface AppMobileDefaults {
  /** Today · Review · Inbox · Manage (Ask is the assistant sheet). */
  tabs: { today: string; review: string; inbox: string; manage: string; ask?: string }
  /** Areas that open on a phone but work best on a computer (laptop mark in Manage). */
  desktopOnly: readonly string[]
  /** The four pins before the person chooses their own. */
  defaultPins: readonly string[]
  /** "View your site" — the live site's home. */
  siteLabel: string
  /** Manage's short list (groups in order; SITE_ROW from lib/ade/mobile/nav places "View your site"); other areas go under `more`. None: the menu's groups. */
  manageLayout?: ReadonlyArray<{ name: string; hrefs: readonly string[] }>
  /** Heading for the areas the layout doesn't name. */
  manageMore?: string
  /** The phone's Analytics: the goal page counted on its own tile ("donate views"). */
  analyticsGoal?: { path: string; label: string; name: string }
}

/**
 * Submit for review: in draft mode the assistant's edits ARE the submission
 * (held in Admin → To-do), so no separate tool; approving is people-only.
 */
const SUBMIT_REVIEW = { verb: 'submit_review', label: 'Submit for review', synonyms: ['send for review', 'send for approval', 'propose'], tools: [] } as const

export const APP_ADE_DEFAULTS: AppAdeDefaults = {
  adminTheme: 'studio',
  feedbackOwnerName: 'Bubune',
  // The sign-in provider's own account page (lib/stack-client handler routes).
  accountProfileHref: '/handler/account-settings',
  // No shop at handoff: fail closed.
  commerceEnabled: false,
  askExample: 'Add our new clinic visit in Ho as an initiative',
  // Untouched draft pages are one row, not one each (owner's briefing review).
  briefingTasks: {
    'stale-drafts': {
      tone: 'warn',
      merge: { one: '1 draft page untouched', many: '{n} draft pages untouched' },
      actions: [{ label: 'Review in To-do', to: '/admin/todo' }],
    },
  },
  briefingChips: [
    { icon: 'Target', label: 'Add an initiative', ask: 'Add a new initiative' },
    { icon: 'FilePen', label: 'Edit a page', ask: 'I want to edit a page' },
    { icon: 'Image', label: 'Upload media', ask: 'Open the media library so I can upload' },
    { icon: 'Inbox', label: 'Check form messages', ask: 'What came in through the forms this week?' },
  ],
  // Owner 2026-10-17: half the page by default (the CMS keeps at least 560px), drag to resize, remembered per person.
  agentDefault: { ratio: 0.5, maxPx: 2400 },
  toolHints: {
    routes: [[/^\/admin\/records\/initiative/, ['initiatives', 'records']]],
    keywords: [
      // Initiatives are records: their writes (create, change facts / stage, publish) are the records tools.
      [/\b(initiatives?|programs?|campaigns?|featured)\b/i, ['initiatives', 'records']],
      // Stage words belong to initiatives ("mark Akuse completed" names no area at all).
      [/\bmark\b[\s\S]{0,60}\b(completed?|active|ongoing|finished|done)\b/i, ['initiatives', 'records']],
      [/\b(cookie|privacy|donat\w*|social links?)\b/i, ['settings']],
    ],
  },
  // What owners call things → the real area (the platform map's synonyms).
  // Only words that genuinely mean this app's feature; another product's
  // features (e.g. "projects") go in closeTo, offered as "did you mean…?".
  vocabulary: {
    '/admin': { about: 'The admin home: today at a glance and what needs attention.', synonyms: ['home', 'overview', 'start'] },
    '/admin/todo': {
      about: 'Everything waiting on someone: drafts to review and approve, tasks and flagged items.',
      synonyms: ['tasks', 'approvals', 'approve', 'review queue', 'waiting for approval', 'inbox', 'pending', 'drafts to review'],
      actions: [
        { verb: 'approve', label: 'Approve', synonyms: ['approve selected', 'accept'], tools: [] },
        { verb: 'reject', label: 'Reject', synonyms: ['decline', 'send back'], tools: [] },
      ],
    },
    '/admin/analytics': { about: 'Visitors and page views for the site.', synonyms: ['traffic', 'visitors', 'visits', 'page views', 'stats', 'statistics', 'reports'] },
    '/admin/products': {
      synonyms: ['merch', 'merchandise', 'items', 'store', 'shop', 'catalog', 'inventory'],
      actions: [
        { verb: 'add', label: 'Add product', synonyms: ['new product'], tools: ['createProduct'] },
        { verb: 'edit', label: 'Edit product', synonyms: ['save'], tools: ['updateProduct'] },
        { verb: 'variants', label: 'Variants', synonyms: ['add variant', 'sizes', 'colours'], tools: ['manageProductVariant'] },
        { verb: 'delete', label: 'Delete product', synonyms: ['delete'], tools: ['deleteProduct'] },
      ],
    },
    '/admin/orders': {
      synonyms: ['purchases', 'sales', 'refunds'],
      actions: [
        { verb: 'status', label: 'Update status', synonyms: ['mark as'], tools: ['updateOrderStatus'] },
        { verb: 'fulfil', label: 'Fulfil', synonyms: ['fulfill', 'mark as shipped', 'ship'], tools: ['fulfillOrder'] },
        { verb: 'refund', label: 'Refund', tools: ['refundOrder'] },
        { verb: 'cancel', label: 'Cancel order', tools: ['cancelOrder'] },
      ],
    },
    '/admin/customers': { synonyms: ['buyers', 'shoppers'] },
    '/admin/shipping': { synonyms: ['delivery', 'postage', 'labels'] },
    '/admin/pages': {
      about: 'The pages of the website, edited in the visual page builder.',
      synonyms: ['web pages', 'home page', 'homepage', 'about page', 'landing page', 'website content'],
      models: ['Page'],
      actions: [
        { verb: 'add', label: 'New page', synonyms: ['add page', 'create page'], tools: ['createPage'] },
        { verb: 'edit_content', label: 'Edit', synonyms: ['open editor', 'add block', 'change text'], tools: ['getPageBlocks', 'updateBlock', 'insertBlock'] },
        { verb: 'page_settings', label: 'Page settings', synonyms: ['rename', 'web address', 'seo'], tools: ['updatePage'] },
        { verb: 'duplicate', label: 'Duplicate', synonyms: ['copy'], tools: ['duplicatePage'] },
        { verb: 'publish', label: 'Publish', synonyms: ['publish changes', 'unpublish', 'go live'], tools: ['publishPage'] },
        SUBMIT_REVIEW,
        { verb: 'delete', label: 'Delete', tools: ['deletePage'] },
      ],
    },
    'records:initiative': {
      about: "The organisation's programs. Each initiative has its own page under /initiatives; published ones are listed on /initiatives and starred ones show on the home page.",
      synonyms: ['programs', 'programmes'],
      closeTo: [{ words: ['projects'], why: "Initiatives are the organisation's programs, each with its own page — the nearest thing here." }],
      actions: [
        { verb: 'add', label: 'New initiative', synonyms: ['add initiative', 'add', 'start a new initiative', 'new initiative from my phone', 'from photos'], tools: ['createRecordWithPage'] },
        { verb: 'edit', label: 'Edit', synonyms: ['save'], tools: ['updateRecord'] },
        { verb: 'stage', label: 'Stage', synonyms: ['mark completed', 'mark active', 'mark ongoing'], tools: ['updateRecord'] },
        { verb: 'feature', label: 'Feature on the home page', synonyms: ['star', 'featured', 'home page order'], tools: ['setFeaturedInitiatives'] },
        { verb: 'publish', label: 'Publish', synonyms: ['unpublish', 'go live'], tools: ['publishRecord'] },
        { verb: 'archive', label: 'Archive', synonyms: ['restore', 'unarchive', 'put away', 'hide an old initiative'], tools: ['archiveRecord'] },
        SUBMIT_REVIEW,
      ],
      models: ['AdeRecord'],
    },
    '/admin/blog': {
      about: 'News and stories: blog posts with categories and tags.',
      synonyms: ['posts', 'news', 'articles', 'stories', 'updates'],
      models: ['BlogPost'],
      actions: [
        { verb: 'add', label: 'New post', synonyms: ['write a post', 'add post'], tools: ['createBlogPost'] },
        { verb: 'edit', label: 'Edit', synonyms: ['save'], tools: ['updateBlogPost'] },
        { verb: 'publish', label: 'Publish', synonyms: ['schedule', 'unpublish'], tools: ['publishBlogPost'] },
        { verb: 'categories', label: 'Categories', synonyms: ['add category'], tools: ['manageBlogCategory'] },
        { verb: 'tags', label: 'Tags', synonyms: ['add tag'], tools: ['manageBlogTag'] },
        SUBMIT_REVIEW,
        { verb: 'delete', label: 'Delete', tools: ['deleteBlogPost'] },
      ],
    },
    '/admin/events': { about: 'Events with dates, schedule, speakers, tickets and registrations.', synonyms: ['calendar', 'registrations', 'rsvp', 'tickets', 'upcoming'], models: ['Event', 'EventRegistration'] },
    '/admin/forms': {
      about: "The site's forms (contact, sign-up, volunteer…) and what people sent through them — a form's Submissions tab has the responses.",
      synonyms: ['submissions', 'responses', 'form responses', 'entries', 'sign-ups', 'contact form', 'messages', 'enquiries', 'inquiries'],
      models: ['Form', 'FormSubmission'],
      actions: [
        { verb: 'add', label: 'New form', synonyms: ['create form'], tools: [] },
        { verb: 'open', label: 'Open form', synonyms: ['view submissions', 'submissions'], tools: ['getForm', 'listFormSubmissions'] },
        { verb: 'add_field', label: 'Add field', synonyms: ['new field'], tools: [] },
        { verb: 'display', label: 'Display', synonyms: ['popup', 'inline', 'show as popup'], tools: ['setFormDisplay'] },
        { verb: 'automations', label: 'Automations', synonyms: ['add automation', 'when submitted'], tools: ['setFormAutomations'] },
        { verb: 'export', label: 'Export CSV', synonyms: ['export', 'download'], tools: [] },
        SUBMIT_REVIEW,
      ],
    },
    '/admin/media': {
      about: 'Uploaded images, videos and files used across the site.',
      synonyms: ['photos', 'pictures', 'images', 'videos', 'files', 'uploads', 'documents', 'pdf'],
      models: ['Media'],
      actions: [{ verb: 'upload', label: 'Upload', synonyms: ['add files', 'add photos'], tools: [] }],
    },
    '/admin/email-marketing': {
      about: 'Email campaigns and newsletters to your subscribers: design the email, pick who gets it, then review and send.',
      synonyms: ['campaigns', 'newsletter', 'mailing', 'mailing list', 'email blast', 'blast', 'email campaign', 'subscribers', 'mass email', 'bulk email'],
      models: ['EmailCampaign', 'EmailSubscriber'],
      actions: [
        { verb: 'add', label: 'New campaign', synonyms: ['create campaign'], tools: [] },
        { verb: 'send', label: 'Send', synonyms: ['send now', 'schedule send', 'review and send'], tools: [] },
      ],
    },
    '/admin/users': { about: 'The people who can sign in to the admin, and their roles.', synonyms: ['staff', 'team', 'team members', 'admins', 'log in', 'login', 'sign in', 'invite'] },
    '/admin/roles': { synonyms: ['permissions', 'access', 'who can do what'] },
    '/admin/audit-log': { about: 'A record of every change made in the admin, including by the assistant.', synonyms: ['history', 'changes', 'activity', 'who changed'] },
    '/admin/tours': { about: 'Guided walkthroughs of the admin.', synonyms: ['walkthroughs', 'tutorials', 'training'] },
    '/admin/settings': { about: 'All site settings in one screen, grouped: site, organization, assistant, email and people.', synonyms: ['preferences', 'configuration', 'options'] },
    'settings:identity': { synonyms: ['logo', 'brand', 'site name', 'colours', 'favicon'], actions: [{ verb: 'save', label: 'Save', tools: ['updateBrandingSettings'] }] },
    'settings:header': { actions: [{ verb: 'edit', label: 'Edit header', synonyms: ['save', 'publish'], tools: ['getSiteLayoutBlocks', 'updateSiteLayoutBlock', 'insertSiteLayoutBlock'] }] },
    'settings:footer': { actions: [{ verb: 'edit', label: 'Edit footer', synonyms: ['save', 'publish'], tools: ['getSiteLayoutBlocks', 'updateSiteLayoutBlock', 'insertSiteLayoutBlock'] }] },
    'settings:admin-menu': { actions: [{ verb: 'rename', label: 'Rename', synonyms: ['hide', 'change icon'], tools: ['customizeNavigationTab'] }] },
    'settings:privacy': { synonyms: ['cookie banner', 'cookie notice', 'cookies', 'consent'] },
    'settings:announcement': { synonyms: ['banner', 'notice bar', 'top bar'], actions: [{ verb: 'save', label: 'Save', tools: ['updateSiteSettings'] }] },
    'settings:contact': { synonyms: ['phone number', 'address', 'email address'] },
    'settings:donations': {
      about: 'Where the Donate button sends people (Cash App, PayPal…) and your social profiles. The giving service takes the donation; the site keeps no donor list.',
      synonyms: ['donations', 'donate', 'giving', 'social media'],
      closeTo: [{ words: ['donors'], why: 'The site keeps no donor list — donations are taken by the giving service set here (Cash App, PayPal…).' }],
    },
    'settings:spam': { synonyms: ['captcha', 'bots'] },
    // The person's own mailbox (per person): set up here, read in the Inbox's My email tab.
    'settings:connectors': { synonyms: ['my inbox', 'my email', 'my mailbox', 'connect my email', 'connect gmail', 'connect outlook', 'gmail', 'outlook', 'email account', 'mailbox'] },
    '/admin/m/inbox?tab=email': { synonyms: ['my inbox', 'my email', 'my mail', 'gmail', 'outlook', 'read my email', 'reply to email', 'draft a reply'] },
    'settings:assistant': { synonyms: ['ai', 'assistant limits', 'budget'] },
  },
  mobile: {
    tabs: { today: '/admin/today', review: '/admin/m/review', inbox: '/admin/m/inbox', manage: '/admin/manage', ask: '/admin/m/ask' },
    // Builders and system screens: they open, but the work needs a big screen.
    desktopOnly: ['/admin/partials', '/admin/workflows', '/admin/order-workflows', '/admin/plugins', '/admin/modules', '/admin/tours', '/admin/email-marketing', '/admin/settings'],
    // The owner-approved mock-up (2026-10-11): Initiatives, Forms, Pages, Email.
    defaultPins: ['/admin/records', '/admin/forms', '/admin/pages', '/admin/email-marketing', '/admin/media'],
    siteLabel: 'View the site',
    manageLayout: [
      { name: 'Content', hrefs: ['/admin/records', '/admin/pages', '/admin/blog', '/admin/media'] },
      { name: 'People', hrefs: ['/admin/forms', '/admin/email-marketing'] },
      { name: 'Site', hrefs: ['/admin/m/analytics', '@site', '/admin/settings'] },
    ],
    manageMore: 'More',
    analyticsGoal: { path: '/donate', label: 'donate views', name: 'Donate' },
  },
}
