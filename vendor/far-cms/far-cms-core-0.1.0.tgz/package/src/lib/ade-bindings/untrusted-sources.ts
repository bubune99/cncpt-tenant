/**
 * Dzidzor's tools whose results carry text written by outsiders
 * (customers, visitors, email senders). Reading one taints the run: every
 * change after it needs approval (lib/ade/governance/taint). Applied to the
 * registry as `untrustedSource` (lib/ai/governance/tool-registry). A new
 * read tool must be listed here or reviewed as trusted
 * (lib/security/run-taint.assert.ts).
 */

import type { UntrustedLabel } from '../ade/governance/taint'

/** Entity types whose records hold what customers typed (names, notes, messages). */
const OUTSIDER_ENTITY_TYPES = new Set(['order', 'customer'])
const outsiderEntity: UntrustedLabel = (input) => {
  const t = (input as { entityType?: unknown } | null)?.entityType
  // No type given (a search across everything) counts as outside text.
  return typeof t !== 'string' || OUTSIDER_ENTITY_TYPES.has(t)
}

export const UNTRUSTED_SOURCES: Readonly<Record<string, UntrustedLabel>> = {
  // The person's own mailbox: other people's email.
  email_search_threads: true,
  email_read_thread: true,
  email_list_drafts: true,
  email_prepare_send: true,
  email_gmail_search_threads: true,
  email_gmail_get_thread: true,
  email_gmail_get_message: true,
  email_gmail_list_drafts: true,
  email_gmail_list_labels: true,
  // Shop data customers typed (names, notes, addresses).
  searchOrders: true,
  // What visitors typed into a form.
  listFormSubmissions: true,
  getRecentActivity: true,
  getEntityDetails: outsiderEntity,
  searchEntities: outsiderEntity,
  // Screen reads: tainted on screens that show outside text (lib/ade-bindings/outside-text).
  read_view: 'screen',
  scan_page: 'screen',
  capture_view: 'screen',
}
