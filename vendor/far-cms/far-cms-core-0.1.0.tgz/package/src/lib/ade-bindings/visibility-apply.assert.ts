/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/visibility-apply.assert.ts
 */
import assert from 'node:assert/strict'
import { areaRules } from '../ade/governance/access'
import { effectiveRules } from '../ade/governance/visibility'
import { PRIVACY_AREAS, VISIBILITY_DEFAULTS, VISIBILITY_FLOOR } from './visibility-rules'
import { applyVisibility, targetsOf, type ReadBlockedReport } from './visibility-apply'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
// An assistant's rules = floor + site-wide + its person's area access (RBAC).
const staffRules = [...effectiveRules(VISIBILITY_FLOOR, VISIBILITY_DEFAULTS), ...areaRules(PRIVACY_AREAS, { permissions: ['orders.view'], overrides: [] }, 'agent')]
const ownerRules = [...effectiveRules(VISIBILITY_FLOOR, VISIBILITY_DEFAULTS), ...areaRules(PRIVACY_AREAS, { permissions: ['*'], overrides: [] }, 'agent')]
const rules = staffRules

check('targets come from the tool input', () => {
  assert.deepEqual(targetsOf('getEntityDetails', { entityType: 'customer', id: '1' }), { entity: 'customer' })
  assert.deepEqual(targetsOf('list_users', {}), { entity: 'user' })
  assert.deepEqual(targetsOf('screenshot_page', { path: '/admin/settings?section=mcp' }), { route: '/admin/settings?section=mcp' })
  assert.deepEqual(targetsOf('screenshot_page', { url: 'https://x.org/handler/sign-in' }), { route: '/handler/sign-in' })
  assert.deepEqual(targetsOf('searchProducts', { query: 'mug' }), {})
})

check('blocked target: the value never comes back, the refusal is reported with its rule', () => {
  const reports: ReadBlockedReport[] = []
  const out = applyVisibility({ tool: 'screenshot_page', input: { path: '/admin/settings?section=environment' }, output: { image: 'data:…', text: 'R2_SECRET=abc' }, role: 'owner', rules, report: (r) => reports.push(r) }) as Record<string, unknown>
  assert.equal(out.blocked, true)
  assert.equal(out.canGuide, true)
  assert.equal(out.reason, 'floor.secrets')
  assert.ok(!JSON.stringify(out).includes('abc'))
  assert.deepEqual(reports, [{ mode: 'blocked', target: '/admin/settings?section=environment', reason: 'floor.secrets', tool: 'screenshot_page' }])
})

check('metadata-only for staff on people; readable (with masks) for the owner', () => {
  const users = [{ id: 'u1', name: 'Ama', email: 'ama@x.org', role: 'EDITOR' }]
  const staff = applyVisibility({ tool: 'list_users', input: {}, output: users, role: 'staff', rules }) as Record<string, unknown>
  assert.equal(staff.metadataOnly, true)
  assert.deepEqual(staff.shape, { count: 1, each: { id: 'string', name: 'string', email: 'string', role: 'string' } })
  assert.ok(!JSON.stringify(staff).includes('Ama'))
  const owner = applyVisibility({ tool: 'list_users', input: {}, output: users, role: 'owner', rules: ownerRules })
  assert.deepEqual(owner, users)
})

check('other reads: private fields masked, reported by name', () => {
  const reports: ReadBlockedReport[] = []
  const out = applyVisibility({ tool: 'getEntityDetails', input: { entityType: 'order', id: 'o1' }, output: { id: 'o1', customerEmail: 'a@b.c', total: 9 }, role: 'staff', rules, report: (r) => reports.push(r) })
  assert.deepEqual(out, { id: 'o1', customerEmail: '[private]', total: 9 })
  assert.deepEqual(reports, [{ mode: 'masked', target: 'order records', fields: ['customerEmail'], reason: 'area.contact', tool: 'getEntityDetails' }])
  // Nothing private: no report, same data.
  const quiet: ReadBlockedReport[] = []
  assert.deepEqual(applyVisibility({ tool: 'searchProducts', input: {}, output: [{ title: 'Mug' }], role: 'staff', rules, report: (r) => quiet.push(r) }), [{ title: 'Mug' }])
  assert.equal(quiet.length, 0)
})

console.log(`\n${n} checks passed`)
