/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/record-checklist-phone.assert.ts
 * Owner decision 2026-10-11: from a phone, empty story sections are warnings, not blockers.
 */
import assert from 'node:assert/strict'
import { blockingItems } from '../ade/records/checklist'
import { recordChecklist, relaxForPhone, REVIEWED_ITEM } from './record-checklist'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const base = { name: 'Clinic', heroImageUrl: 'https://dzidzor-media.farsociety.com/x.jpg', summary: 'S', location: 'Ada', stage: 'active' }

check('a phone draft without story sections can publish; the story is listed for later', () => {
  const full = recordChecklist('initiative', { data: base }, { [REVIEWED_ITEM]: true })!
  assert.deepEqual(blockingItems(full).map((i) => i.id), ['story'], 'on the desktop it still blocks')
  const { result, later } = relaxForPhone(full)
  assert.deepEqual(blockingItems(result), [])
  assert.deepEqual(later.map((i) => i.id), ['story'])
})

check('everything else still blocks from a phone (name, photo, summary, location, stage, review)', () => {
  const full = recordChecklist('initiative', { data: { stage: 'active' } })!
  assert.deepEqual(blockingItems(relaxForPhone(full).result).map((i) => i.id).sort(), ['location', 'name', 'photo', 'reviewed', 'summary'])
})

console.log(`\n${n} checks passed`)
