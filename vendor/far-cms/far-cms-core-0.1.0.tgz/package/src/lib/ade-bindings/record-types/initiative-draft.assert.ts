/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/record-types/initiative-draft.assert.ts
 * Drafting is driven by the record type's definition, never a hard-coded list.
 */
import assert from 'node:assert/strict'
import { assignPhotos, coerceDraft, draftInstructions, draftSpec, missingItems, prefillDraft } from '../../ade/records/draft'
import type { RecordTypeDef } from '../../ade/records/types'
import { initiativeType } from './initiative'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the spec is the definition: text/date/enum/stats fields, not slug, images or placement choices', () => {
  const keys = draftSpec(initiativeType).map((f) => f.key)
  for (const k of ['name', 'summary', 'location', 'stage', 'startDate', 'endDate', 'goal', 'progress', 'beneficiaries', 'partner', 'videoUrl', 'stats', 'seoDescription']) assert.ok(keys.includes(k), k)
  for (const k of ['slug', 'heroImageUrl', 'shareImageUrl', 'featured', 'featuredOrder']) assert.ok(!keys.includes(k), k)
  assert.match(draftInstructions(initiativeType), /stage \(one of active \| ongoing \| completed\)/)
  assert.match(draftInstructions(initiativeType), /name \(short text, ≤ 120 characters\) REQUIRED/)
})

check('a different type drafts its own fields — nothing initiative-specific in the logic', () => {
  const event: RecordTypeDef = {
    key: 'event', label: 'Event', plural: 'Events', titleField: 'title', slugField: 'slug', pathPrefix: '/events', category: 'events', pageTemplate: [],
    fields: [
      { key: 'title', label: 'Title', type: 'text', required: true },
      { key: 'slug', label: 'Address', type: 'slug' },
      { key: 'when', label: 'Date', type: 'date', quick: true },
      { key: 'seats', label: 'Seats', type: 'number', quick: true },
      { key: 'poster', label: 'Poster', type: 'image' },
    ],
  }
  assert.deepEqual(draftSpec(event).map((f) => f.key), ['title', 'when', 'seats'])
  const c = coerceDraft(event, { title: 'Open day', when: '2026-11-02', seats: '1,200', name: 'x' })
  assert.deepEqual(c.data, { title: 'Open day', when: '2026-11-02', seats: 1200, slug: 'open-day' })
  assert.deepEqual(c.dropped, [{ key: 'name', reason: 'not a field of this type' }])
})

check('coercion: enum labels → values, bad dates and links dropped, long text clipped, system fields refused', () => {
  const c = coerceDraft(initiativeType, {
    name: '  Clean water for Ada  ', stage: 'Ongoing', startDate: '2026-02-30', endDate: '2026-12-01', videoUrl: 'youtube dot com',
    summary: 'x'.repeat(300), stats: [{ value: '120', label: 'wells' }, { value: '', label: 'skip' }], slug: 'hand-set', featured: true, heroImageUrl: 'https://evil.example/x.jpg',
  })
  assert.equal(c.data.name, 'Clean water for Ada')
  assert.equal(c.data.slug, 'clean-water-for-ada')
  assert.equal(c.data.stage, 'ongoing')
  assert.equal(c.data.endDate, '2026-12-01')
  assert.equal((c.data.summary as string).length, 240)
  assert.deepEqual(c.data.stats, [{ value: '120', label: 'wells' }])
  const why = Object.fromEntries(c.dropped.map((d) => [d.key, d.reason]))
  assert.match(why.startDate, /real date/)
  assert.match(why.videoUrl, /link/)
  for (const k of ['slug', 'featured', 'heroImageUrl']) assert.equal(why[k], 'filled another way', k)
})

check('photos fill the image fields in order (cover first), the rest go to the gallery; placement-only images stay empty', () => {
  const r = assignPhotos(initiativeType, { name: 'A' }, [{ url: 'https://r2/1.jpg' }, { url: 'https://r2/2.jpg' }, { url: 'https://r2/3.jpg' }])
  assert.equal(r.data.heroImageUrl, 'https://r2/1.jpg')
  assert.equal(r.data.shareImageUrl, undefined, 'share image uses the main photo when empty')
  assert.deepEqual(r.data.gallery, ['https://r2/2.jpg', 'https://r2/3.jpg'])
  assert.deepEqual(r.unused, [])
  const many = assignPhotos(initiativeType, {}, Array.from({ length: 15 }, (_, i) => ({ url: `https://r2/${i}.jpg` })))
  assert.equal((many.data.gallery as string[]).length, 12, 'gallery holds at most 12')
  assert.equal(many.unused.length, 2)
})

check('missing items: required blocks, quick-form fields are suggestions, in plain words', () => {
  const m = missingItems(initiativeType, { name: '', summary: 'S', stage: 'active' })
  const by = Object.fromEntries(m.map((x) => [x.key, x]))
  assert.equal(by.name.required, true)
  assert.equal(by.name.message, 'No name yet')
  assert.equal(by.startDate.required, false)
  assert.equal(by.goal.message, 'No goal yet')
  assert.ok(by.heroImageUrl, 'no cover photo is flagged')
  assert.ok(!by.summary && !by.stage && !by.featured && !by.slug)
  assert.equal(by.goalAmount.message, 'No goal amount yet')
  assert.equal(by.goalAmount.required, false)
  assert.ok(by.donationUrl, 'no donation link is a suggestion')
  assert.ok(!by.gallery && !by.goalCurrency)
})

check('goal amounts as people write them: "$3,000", "GH₵ 12k", "1.5m"; words are refused, never guessed', () => {
  const amount = (v: unknown) => coerceDraft(initiativeType, { name: 'A', goalAmount: v })
  assert.equal(amount('$3,000').data.goalAmount, 3000)
  assert.equal(amount('GH₵ 12k').data.goalAmount, 12000)
  assert.equal(amount('1.5m').data.goalAmount, 1500000)
  assert.equal(amount(2500).data.goalAmount, 2500)
  assert.equal(amount('three thousand').data.goalAmount, undefined)
  assert.equal(coerceDraft(initiativeType, { name: 'A', goalCurrency: 'Ghana cedis (GH₵)' }).data.goalCurrency, 'GHS')
  assert.equal(coerceDraft(initiativeType, { name: 'A', donationUrl: 'paypal.me/x' }).data.donationUrl, undefined, 'a donation link must be a real link')
  assert.ok(!draftSpec(initiativeType).some((f) => f.key === 'gallery'), 'the gallery is filled from photos, not drafted')
})

check('existing initiatives keep working: the new fields are optional and empty is valid', () => {
  for (const k of ['goalAmount', 'goalCurrency', 'donationUrl', 'gallery']) {
    const f = initiativeType.fields.find((x) => x.key === k)!
    assert.ok(f && !f.required, k)
  }
})

check('"Fill it in myself" mid-draft keeps what was written, drops what doesn’t fit, places the photos', () => {
  const cut = prefillDraft(initiativeType, { fields: { name: 'Water for Ada', stage: 'Ongo', goalAmount: 30 } }, [])
  assert.equal(cut.data.name, 'Water for Ada')
  assert.equal(cut.data.stage, undefined, 'a value that doesn’t fit is dropped')
  assert.equal(cut.data.goalAmount, undefined, 'the field still being written (30 of 3000?) is never kept')
  const p = prefillDraft(initiativeType, { fields: { name: 'Water for Ada', goalAmount: 3000 }, story: ['Families walk an hour.', ''] }, [{ url: 'https://r2/1.jpg' }, { url: 'https://r2/2.jpg' }])
  assert.equal(p.data.goalAmount, 3000, 'once the story has started the fields are complete')
  assert.equal(p.data.heroImageUrl, 'https://r2/1.jpg')
  assert.deepEqual(p.data.gallery, ['https://r2/2.jpg'])
  assert.deepEqual(p.story, ['Families walk an hour.'])
  assert.deepEqual(prefillDraft(initiativeType, null, []), { data: {}, story: [] })
})

console.log(`\n${n} checks passed`)
