/**
 * The "initiative" record type — Dzidzor's first. Pure data: fields, the page
 * template and event fields. Adding a type (blog post, product-launch CTA)
 * means adding another object like this, not new code paths.
 *
 * Field keys match the legacy InitiativeData (name, summary, stage, …) so the
 * existing InitiativeBlock / InitiativeHighlights render records unchanged.
 */

import type { RecordTypeDef } from '../../ade'
import { CURRENCIES } from '../../ade/records/goal'
import { INITIATIVE_CHECKLIST, INITIATIVE_PHONE_WARNINGS } from './initiative-checklist'

export const initiativeType: RecordTypeDef = {
  key: 'initiative',
  label: 'Initiative',
  plural: 'Initiatives',
  titleField: 'name',
  slugField: 'slug',
  pathPrefix: '/initiatives',
  category: 'initiatives',
  eventFields: ['stage'],
  dateEventFields: ['startDate', 'endDate'],
  // Per-type parts of the engine (lib/ade/records/type-config): all of it data.
  checklist: INITIATIVE_CHECKLIST,
  phoneWarnings: INITIATIVE_PHONE_WARNINGS,
  canvasParts: {
    InitiativeHeader: {
      part: 'header',
      fields: { title: 'name', summary: 'summary', place: 'location', badge: 'stage', image: 'heroImageUrl', start: 'startDate', end: 'endDate', partner: 'partner' },
    },
    InitiativeStats: { part: 'stats', fields: { stats: 'stats' } },
    InitiativeGoal: { part: 'goal', fields: { amount: 'goalAmount', currency: 'goalCurrency', raised: 'raisedAmount', donation: 'donationUrl' } },
    InitiativeGallery: { part: 'gallery', fields: { gallery: 'gallery' } },
  },
  listComponents: [{ componentName: 'InitiativeHighlights', modes: ['stats', 'initiatives', 'showcase'], featuredByDefault: true }],
  homeCard: { componentName: 'InitiativeCard', areaComponents: ['InitiativeBlock', 'InitiativeCard'] },
  placement: { group: 'stage', featured: 'featured', featuredOrder: 'featuredOrder', photo: 'heroImageUrl', start: 'startDate', end: 'endDate' },
  // What the record page's Details tab edits (record-details.tsx); the rest is on the page or elsewhere.
  // Donations first (owner 2026-11-16): the goal and where Donate goes lead the Details tab.
  detailsFields: ['goalAmount', 'goalCurrency', 'donationUrl', 'startDate', 'endDate', 'slug', 'partner', 'videoUrl', 'featured', 'featuredOrder', 'seoDescription', 'shareImageUrl', 'stats'],
  fields: [
    { key: 'name', label: 'Name', aliases: ['title', 'name'], type: 'text', required: true, max: 120, quick: true },
    { key: 'slug', label: 'Web address', aliases: ['address', 'url', 'link'], type: 'slug', max: 80, help: 'Made from the name when left empty.' },
    { key: 'summary', label: 'One-line summary', aliases: ['summary', 'subtitle', 'one-liner', 'tagline'], type: 'text', max: 240, quick: true },
    { key: 'location', label: 'Location', aliases: ['place', 'region'], type: 'text', max: 120, quick: true },
    {
      key: 'stage',
      label: 'Stage', aliases: ['status', 'phase'],
      type: 'enum',
      default: 'active',
      quick: true,
      options: [
        { value: 'active', label: 'Active' },
        { value: 'ongoing', label: 'Ongoing' },
        { value: 'completed', label: 'Completed' },
      ],
    },
    { key: 'startDate', label: 'Start date', aliases: ['start', 'starts', 'begin date'], type: 'date', quick: true },
    { key: 'endDate', label: 'End date', aliases: ['end', 'ends', 'finish date'], type: 'date' },
    { key: 'goal', label: 'Goal', aliases: ['aim', 'our goal'], type: 'longtext', max: 2000, quick: true },
    // Money goal (owner, 2026-10-11): shown on the page and in email cards as "Goal: $3,000".
    // A progress bar needs a real raised amount — nothing records one yet, so none is shown.
    { key: 'goalAmount', label: 'Goal amount', type: 'number', quick: true, help: 'The amount you’re raising, e.g. 3000.' },
    {
      key: 'goalCurrency',
      label: 'Currency',
      type: 'enum',
      default: 'USD',
      options: [...CURRENCIES],
    },
    { key: 'donationUrl', label: 'Donation link', type: 'url', max: 2000, quick: true, help: 'Where “Donate” goes for this initiative. Leave empty to use the site’s donate link.' },
    { key: 'progress', label: 'Progress so far', aliases: ['progress so far'], type: 'longtext', max: 2000 },
    { key: 'beneficiaries', label: 'Who it helps', aliases: ['who it helps', 'people helped'], type: 'longtext', max: 2000 },
    { key: 'partner', label: 'Partner', aliases: ['partnership'], type: 'text', max: 120 },
    { key: 'heroImageUrl', label: 'Hero image', aliases: ['photo', 'hero photo', 'main photo', 'banner', 'picture'], type: 'image', max: 2000, quick: true },
    { key: 'videoUrl', label: 'Video link', aliases: ['video'], type: 'url', max: 2000 },
    { key: 'stats', label: 'Impact stats', aliases: ['impact numbers', 'numbers', 'stats'], type: 'stats', max: 4 },
    { key: 'gallery', label: 'Photo gallery', type: 'gallery', max: 12, help: 'More photos, shown under the story.' },
    { key: 'featured', label: 'Feature on the home page', aliases: ['feature', 'home page feature'], type: 'boolean', default: false, quick: true, draftable: false },
    { key: 'featuredOrder', label: 'Home page order', type: 'number', draftable: false },
    // Search & sharing (og meta); the summary / main photo are used when empty.
    { key: 'seoDescription', label: 'Search description', aliases: ['search description', 'seo'], type: 'text', max: 300, help: 'Shown by search engines and when the page is shared. Uses the summary when empty.' },
    { key: 'shareImageUrl', label: 'Share image', aliases: ['share image', 'social image'], type: 'image', max: 2000, help: 'The picture shown when the page is shared. Uses the main photo when empty.', draftable: false },
  ],
  // The record's own page: bound placements up top (facts, always in sync),
  // then a first-draft story the page owns (filled from the facts once).
  pageTemplate: [
    { tag: 'section', label: 'Initiative header', componentName: 'InitiativeHeader', attrs: { 'data-record': '$record' } },
    { tag: 'section', label: 'Impact stats', componentName: 'InitiativeStats', attrs: { 'data-record': '$record' } },
    { tag: 'section', label: 'Goal', componentName: 'InitiativeGoal', attrs: { 'data-record': '$record' } },
    {
      // Explicit light background: the story must stay readable whatever the
      // page around it (it used to inherit a dark page background).
      tag: 'section',
      label: 'Story',
      className: 'bg-white px-6 py-12',
      children: [
        {
          tag: 'div',
          className: 'max-w-3xl mx-auto space-y-5 text-lg leading-relaxed text-gray-800',
          children: [
            { tag: 'h2', className: "text-3xl font-['Fredoka_One'] text-[#022b39]", textContent: 'Our goal' },
            { tag: 'p', textContent: '{{goal}}' },
            { tag: 'h2', className: "text-3xl font-['Fredoka_One'] text-[#022b39]", textContent: 'Progress so far' },
            { tag: 'p', textContent: '{{progress}}' },
            { tag: 'h2', className: "text-3xl font-['Fredoka_One'] text-[#022b39]", textContent: 'Who it helps' },
            { tag: 'p', textContent: '{{beneficiaries}}' },
          ],
        },
      ],
    },
    { tag: 'section', label: 'Photo gallery', componentName: 'InitiativeGallery', attrs: { 'data-record': '$record' } },
    {
      tag: 'section',
      label: 'Call to action',
      className: 'bg-white px-6 pb-16 flex flex-wrap justify-center gap-4',
      children: [
        {
          tag: 'a',
          className: 'inline-block px-6 py-3 bg-[#a85f1f] text-white font-semibold rounded hover:bg-[#8f501a]',
          attrs: { href: '/donate' },
          textContent: 'Support this initiative',
        },
        {
          tag: 'a',
          className: 'inline-block px-6 py-3 border border-[#022b39] text-[#022b39] font-semibold rounded hover:bg-[#022b39] hover:text-white',
          attrs: { href: '/initiatives' },
          textContent: 'All initiatives',
        },
      ],
    },
  ],
}
