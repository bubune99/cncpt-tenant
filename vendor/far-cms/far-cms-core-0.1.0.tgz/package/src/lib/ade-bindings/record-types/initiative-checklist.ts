/**
 * The initiative's Ready to publish checklist — part of its type definition
 * (record-types/initiative.ts `checklist`), engine: lib/ade/records/checklist.
 */

import { REVIEWED_ITEM, type ChecklistItemDef, type RecordChecklistCtx } from '../../ade/records/checklist'
import { isOnMediaDomain } from '../../media/public-url'
import { metaFromRecord } from '../record-meta'

const filled = (v: unknown) => typeof v === 'string' && v.trim().length > 0

export const INITIATIVE_CHECKLIST: ReadonlyArray<ChecklistItemDef<RecordChecklistCtx>> = [
  // An empty draft (R2: "Add an initiative" opens one) starts without a name.
  { id: 'name', starter: { title: 'Name this initiative', sub: 'The title on the banner', prompt: 'Help me name this initiative' }, label: 'Name', required: true, kind: 'auto', check: ({ data }) => filled(data.name) || 'Click the title on the page to name it' },
  {
    id: 'photo',
    starter: { title: 'Choose the hero photo', sub: 'From the media library', prompt: 'Help me choose the hero photo' },
    label: 'Main photo chosen from the Media library',
    required: true,
    kind: 'auto',
    check: ({ data }) => (!filled(data.heroImageUrl) ? 'Click the photo on the page to choose one' : isOnMediaDomain(data.heroImageUrl) ? true : 'This photo isn’t from the Media library — choose it again from there'),
  },
  { id: 'summary', starter: { title: 'Write the one-line summary', sub: 'The line under the title', prompt: 'Help me write the one-line summary' }, label: 'One-line summary', required: true, kind: 'auto', check: ({ data }) => filled(data.summary) || 'Click under the name on the page to add it' },
  { id: 'location', starter: { title: 'Add the location', sub: 'Shown beside the stage', prompt: 'Help me add the location' }, label: 'Location', required: true, kind: 'auto', check: ({ data }) => filled(data.location) || 'Click beside the stage pill on the page to add it' },
  { id: 'stage', starter: { title: 'Set the stage', sub: 'Active, ongoing or completed', prompt: 'Help me set the stage' }, label: 'Stage', required: true, kind: 'auto', check: ({ data }) => filled(data.stage) || 'Set it under Details' },
  {
    id: 'story',
    starter: { title: 'Fill in the story', sub: 'Our goal, Progress so far, Who it helps', prompt: 'Help me fill in the story sections' },
    label: 'Story sections filled (goal, progress, who it helps)',
    required: true,
    kind: 'auto',
    check: ({ data }) => {
      const missing = [
        ['goal', 'Our goal'],
        ['progress', 'Progress so far'],
        ['beneficiaries', 'Who it helps'],
      ].filter(([k]) => !filled(data[k]))
      return missing.length === 0 || `Still empty: ${missing.map(([, l]) => l).join(', ')}`
    },
  },
  {
    id: 'share',
    starter: { title: 'Set how shared links look', sub: 'Share image and search description', prompt: 'Help me set the share image and search description' },
    label: 'Share image and search description',
    required: false,
    kind: 'auto',
    check: ({ data }) => {
      const m = metaFromRecord(data)
      return (Boolean(m.image) && Boolean(m.description)) || 'Shared links will show without a picture or description'
    },
  },
  {
    id: 'placement',
    label: 'Shows on the home page once live (a placement rule matches)',
    required: false,
    kind: 'auto',
    applies: (ctx) => ctx.placementMatches !== undefined,
    check: (ctx) => ctx.placementMatches === true || 'No home-page section’s rules pick it up — fine if that’s intended',
  },
  { id: REVIEWED_ITEM, label: 'Page reviewed in preview', required: true, kind: 'manual', hint: 'Look through the page on Desktop and Phone, then tick this', starter: { title: 'Check it on a phone', sub: 'Preview it before publishing', prompt: 'Show me this page on a phone' } },
]

/** Sent from a phone (owner, 2026-10-11): the story sections are warnings, not blockers. */
export const INITIATIVE_PHONE_WARNINGS: ReadonlyArray<string> = ['story']
