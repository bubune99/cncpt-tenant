/**
 * Registered record types. A type is data (RecordTypeDef); add one here.
 */

import type { RecordTypeDef } from '../../ade'
import { initiativeType } from './initiative'
import { withPageBlocksField } from '../../ade/records/page-blocks'

// Every type with a page can take sections from the block library (its 'blocks' field — lib/ade/records/page-blocks).
export const RECORD_TYPES: Readonly<Record<string, RecordTypeDef>> = {
  [initiativeType.key]: withPageBlocksField(initiativeType),
}

export function getRecordType(key: unknown): RecordTypeDef | null {
  return typeof key === 'string' && Object.hasOwn(RECORD_TYPES, key) ? RECORD_TYPES[key] : null
}

export { initiativeType }
