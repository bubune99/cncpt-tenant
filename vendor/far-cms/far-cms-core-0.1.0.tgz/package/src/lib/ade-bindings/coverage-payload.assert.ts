/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/coverage-payload.assert.ts
 */
import assert from 'node:assert/strict'
import { parseCoveragePayload } from './coverage-payload'
import { collapsePerItem, contentFreeLabel, contentFreeTarget } from '../ade/coverage/sanitize'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const row = { route: '/admin/settings?section=theme', at: '2026-10-11T10:00:00Z', units: 14.4, toolGaps: ['Reset theme', 3], uiGaps: [], hiddenOnly: ['Export settings'] }

check('admin routes only; query dropped; lists cleaned; units rounded', () => {
  const p = parseCoveragePayload({ row })!
  assert.equal(p.row.route, '/admin/settings')
  assert.equal(p.row.units, 14)
  assert.deepEqual(p.row.toolGaps, ['Reset theme'])
  for (const bad of [null, {}, { row: { route: '/account' } }, { row: { route: 'https://x/admin' } }]) assert.equal(parseCoveragePayload(bad), null)
})

check('tour steps keep the spotlight_steps shape, max 12, junk dropped', () => {
  const steps = [...Array.from({ length: 14 }, (_, i) => ({ target: `#s${i}`, caption: `Step ${i}` })), { target: 1 }]
  const p = parseCoveragePayload({ row, tour: { title: 'Find Export', steps } })!
  assert.equal(p.tour!.steps.length, 12)
  assert.deepEqual(p.tour!.steps[0], { target: '#s0', caption: 'Step 0', position: 'auto' })
})

check('bad dates fall back to now', () => {
  const p = parseCoveragePayload({ row: { ...row, at: 'soon' } })!
  assert.ok(!Number.isNaN(Date.parse(p.row.at)))
})

check('a private route stores the route only; labels are capped at 80', () => {
  const p = parseCoveragePayload({ row: { ...row, private: true, toolGaps: ['Secret'] }, units: [{ id: 'x', label: 'Leak' }], tour: { title: 't', steps: [{ target: '#a', caption: 'c' }] } })!
  assert.equal(p.row.private, true)
  assert.deepEqual([p.row.toolGaps, p.row.hiddenOnly, p.units, p.tour], [[], [], undefined, null])
  const long = parseCoveragePayload({ row: { ...row, toolGaps: ['y'.repeat(300)] }, units: [{ id: 'u', label: 'z'.repeat(300) }] })!
  assert.equal(long.row.toolGaps[0].length, 80)
  assert.equal(long.units![0].label.length, 80)
})

check('outline rows keep the block type only (quoted copy and the text after a dash go)', () => {
  assert.equal(contentFreeLabel('Hero banner — “Delivering Hope”'), 'Hero banner')
  assert.equal(contentFreeLabel('Quote — ““The supplies arrived the week our…”'), 'Quote')
  assert.equal(contentFreeLabel('Essential · always on Needed for the site to work'), 'Essential')
  assert.equal(contentFreeLabel('1 First Name Required Half'), 'First Name Required Half')
})

check('automation rows keep the action kind, never configured values (tags, templates, recipients, amounts, rule names)', () => {
  assert.equal(contentFreeLabel('Tag the contact Tag: volunteer'), 'Tag the contact')
  assert.equal(contentFreeLabel('Send a promotional email Template: “does-not-exist” · only if they agreed to ma…'), 'Send a promotional email')
  assert.equal(contentFreeLabel('Add a To-do item For: Trip coordinator — “Follow up about the next trip (temp t…'), 'Add a To-do item')
  assert.equal(contentFreeLabel('Give store credit $5 gift-card balance · needs your approval each time'), 'Give store credit')
  assert.equal(contentFreeLabel('Remove “Every volunteer (temp)”'), 'Remove')
  assert.equal(contentFreeLabel('Creativity (0–2)'), 'Creativity')
})

check('control names pass unchanged', () => {
  for (const l of ['Export CSV', 'Add Hero banner section', 'Phone (optional)', 'Settings › Spam protection', 'Keep usage history (days)', 'Check that a person is sending this form (Cloudflare Turnstile)', 'Submit for review'])
    assert.equal(contentFreeLabel(l), l)
})

check('stored rows, units and tours carry no copy or values; a tour aimed by content is not stored', () => {
  const p = parseCoveragePayload({
    row: { route: '/admin/forms/f1', units: 3, toolGaps: ['Tag the contact Tag: volunteer', 'Remove “Every volunteer (temp)”', 'Remove “Wants to travel (temp)”', '“Delivering Hope”'], uiGaps: [], hiddenOnly: ['Hero banner — “Delivering Hope”'] },
    units: [{ id: 'button:remove “every volunteer (temp)”', label: 'Remove “Every volunteer (temp)”', kind: 'action', action: null, tools: [], reveal: ['Open the “Automations” tab.'] }],
    tour: {
      title: 'Where to find “Hero banner — “Delivering Hope””',
      steps: [
        { target: '[data-ui="ws.tool.outline"]', caption: 'Open the “Outline” tab.', meta: { reveal: { action: 'open-tab', target: '[data-ui="ws.tool.outline"]', label: 'Outline' } } },
        { target: '[data-ui="ws.section.hero"]', caption: '“Hero banner — “Delivering Hope”” is here.', meta: { unit: 'button:hero banner — “delivering hope”' } },
      ],
    },
  })!
  assert.deepEqual(p.row.toolGaps, ['Tag the contact', 'Remove'])
  assert.deepEqual(p.row.hiddenOnly, ['Hero banner'])
  assert.equal(p.units![0].id, 'button:remove')
  assert.equal(p.units![0].label, 'Remove')
  assert.equal(p.tour!.title, 'Where to find “Hero banner”')
  assert.equal(p.tour!.steps[1].caption, '“Hero banner” is here.')
  assert.equal(p.tour!.steps[1].meta?.unit, 'button:hero banner')
  assert.equal(contentFreeTarget('[data-ui="privacy.create_policy_page"]'), '[data-ui="privacy.create_policy_page"]')
  assert.equal(contentFreeTarget('button[aria-label="Expand"]'), 'button[aria-label="Expand"]')
  const leaky = parseCoveragePayload({ row: { route: '/admin/pages/p1', units: 1, toolGaps: [], uiGaps: [], hiddenOnly: [] }, tour: { title: 'x', steps: [{ target: '[role="button"][aria-label="Quote — “The supplies arrived”"]', caption: 'here' }] } })!
  assert.equal(leaky.tour, null)
})

check('record names in per-item buttons are never stored ("Edit Akuse Hospital" → "Edit (each item)"); its tour is dropped', () => {
  assert.deepEqual(collapsePerItem(['Edit Akuse Hospital', 'Edit Community Clinic Construction', 'New initiative', 'Edit']), ['Edit (each item)', 'New initiative', 'Edit'])
  assert.deepEqual(collapsePerItem(['Rename Dashboard', 'Hide Dashboard', 'Rename Orders', 'Hide Orders']), ['Rename (each item)', 'Hide (each item)'])
  // One verb with one object is a control, not a list ("Edit Layout").
  assert.deepEqual(collapsePerItem(['Edit Layout', 'Add base product', 'Add an action']), ['Edit Layout', 'Add base product', 'Add an action'])
  const p = parseCoveragePayload({
    row: { route: '/admin/blog', units: 3, toolGaps: ['Edit Akuse Hospital'], uiGaps: [], hiddenOnly: ['Edit Community Clinic Construction'] },
    units: [{ id: 'button:edit akuse hospital', label: 'Edit Akuse Hospital', kind: 'action', action: null, tools: [], reveal: [] }],
    tour: { title: 'Where to find “Edit Akuse Hospital”', steps: [{ target: '[data-ui="blog.tab.archived"]', caption: 'Open the “Archived” tab.' }] },
  })!
  assert.deepEqual(p.row.toolGaps, ['Edit (each item)'])
  assert.deepEqual(p.row.hiddenOnly, ['Edit (each item)'])
  assert.equal(p.units![0].label, 'Edit (each item)')
  assert.equal(p.tour, null)
  // Selector ids and "More for <record>" menus don't carry the name either.
  const q = parseCoveragePayload({
    row: { route: '/admin/blog', units: 4, toolGaps: [], uiGaps: [], hiddenOnly: [] },
    units: [
      { id: 'a[aria-label="Edit Akuse Hospital"]', label: 'Edit Akuse Hospital', kind: 'link', action: null, tools: [], reveal: [] },
      { id: 'a[aria-label="Edit Community Clinic"]', label: 'Edit Community Clinic', kind: 'link', action: null, tools: [], reveal: [] },
      { id: 'button[aria-label="More for Akuse Hospital"]', label: 'More for Akuse Hospital', kind: 'other', action: null, tools: [], reveal: [] },
      { id: 'button[aria-label="More for Community Clinic"]', label: 'More for Community Clinic', kind: 'other', action: null, tools: [], reveal: [] },
    ],
  })!
  assert.deepEqual(q.units!.map((u) => [u.id, u.label]), [['link:Edit (each item)', 'Edit (each item)'], ['link:Edit (each item)', 'Edit (each item)'], ['other:More for (each item)', 'More for (each item)'], ['other:More for (each item)', 'More for (each item)']])
  assert.ok(!/Akuse|Clinic/.test(JSON.stringify(p)))
})

check('fields named by their value (colours, emails, hosts) and per-record slugs are not stored', () => {
  assert.equal(contentFreeLabel('#0066cc'), '')
  assert.equal(contentFreeLabel('noreply@yourdomain.com'), '')
  assert.equal(contentFreeLabel('smtp.yourdomain.com'), '')
  assert.equal(contentFreeLabel('Logo URL'), 'Logo URL')
  assert.equal(contentFreeLabel('Search media...'), 'Search media...')
  const p = parseCoveragePayload({
    row: { route: '/admin/forms/f1', units: 3, toolGaps: ['every', 'travel', '#6366f1'], uiGaps: [], hiddenOnly: [] },
    units: [
      { id: '[data-ui="forms.rule.every"]', label: 'every', kind: 'action', action: null, tools: [], reveal: [] },
      { id: '[data-ui="forms.rule.travel"]', label: 'travel', kind: 'action', action: null, tools: [], reveal: [] },
      { id: '[data-ui="forms.automations.new"]', label: 'New rule', kind: 'action', action: null, tools: [], reveal: [] },
    ],
  })!
  assert.deepEqual(p.row.toolGaps, ['(each item)'])
  assert.deepEqual(p.units!.map((u) => u.label), ['(each item)', '(each item)', 'New rule'])
  assert.ok(!/every|travel|6366f1/.test(JSON.stringify(p)))
  assert.equal(p.units![0].id, '[data-ui^="forms.rule."]')
})

console.log(`\n${n} checks passed`)
