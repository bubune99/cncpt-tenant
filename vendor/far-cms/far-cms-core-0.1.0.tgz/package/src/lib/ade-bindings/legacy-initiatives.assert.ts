/**
 * Run: npx -y tsx@4.23.15 src/lib/ade-bindings/legacy-initiatives.assert.ts
 */
import assert from 'node:assert/strict'
import { legacyInitiativeTarget, legacyRefFor } from './legacy-initiatives'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the list and the wizard go to the records screens', () => {
  assert.equal(legacyInitiativeTarget({ kind: 'list' }), '/admin/records/initiative')
  assert.equal(legacyInitiativeTarget({ kind: 'new' }), '/admin/records/initiative/new')
})

check('an old post id goes to the record migrated from it', () => {
  assert.equal(legacyInitiativeTarget({ kind: 'post', postId: 'cms6825d40000r4izabh9qpew', recordId: 'c892188b889ef4bcd865471be' }), '/admin/records/initiative/c892188b889ef4bcd865471be')
})

check('no record → the post editor (never a 404)', () => {
  assert.equal(legacyInitiativeTarget({ kind: 'post', postId: 'p1', recordId: null }), '/admin/blog/p1')
})

check('ids are encoded; legacyRef shape matches the migration', () => {
  assert.equal(legacyInitiativeTarget({ kind: 'post', postId: 'a/b', recordId: null }), '/admin/blog/a%2Fb')
  assert.equal(legacyRefFor('p1'), 'blog-post:p1')
})

console.log(`\n${n} checks passed`)
