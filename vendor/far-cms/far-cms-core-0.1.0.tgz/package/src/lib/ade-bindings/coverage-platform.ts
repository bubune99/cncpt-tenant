/**
 * Coverage check ↔ the platform map (platform-map agent's
 * lib/ade-bindings/platform-map: entryForRoute / dzidzorPlatformMap) and the
 * agent's tools (lib/ai/toolsets TOOL_GROUPS, TOOL_REGISTRY). Pure; asserted
 * by coverage-platform.assert.ts.
 *
 * The map covers areas/entities. When an entry carries `actions` (verb,
 * synonyms, tool names) those are used as-is; otherwise every tool in the
 * entry's tool groups becomes one action, named from the tool ("createPage"
 * → "create page") plus a few owner words from a small verb table — enough to
 * match buttons like "Publish" or "Delete" until the map has real actions.
 */

import type { CoverageUnit, PlatformAction, UnitMatcher } from '../ade/coverage/logic'

/** What the coverage check needs from a PlatformEntry (structural, so it works before/after the map's merge). */
export interface PlatformEntryLike {
  id: string
  name: string
  href: string
  /** Tool GROUP keys. */
  tools: readonly string[]
  synonyms?: readonly string[]
  actions?: ReadonlyArray<{ verb: string; label?: string; synonyms?: readonly string[]; tools: readonly string[] }>
}

export interface ToolMetaLike {
  effect?: string
  mutation?: boolean
}

/** "createPage" / "set_automation_enabled" → "create page" / "set automation enabled". */
export function humanizeToolName(name: string): string {
  return name
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .toLowerCase()
    .trim()
}

/** Owner words a tool also answers to, by its name / effect. */
export function verbSynonyms(name: string, meta: ToolMetaLike | undefined): string[] {
  const h = humanizeToolName(name)
  const out: string[] = []
  const first = h.split(' ')[0]
  if (first === 'publish') out.push('publish', 'go live', 'make live')
  if (first === 'unpublish') out.push('unpublish', 'take down')
  if (first === 'delete' || first === 'remove') out.push('delete', 'remove')
  if (first === 'duplicate') out.push('duplicate', 'copy')
  if (first === 'create' || first === 'add') out.push('new', 'add', 'create')
  if (first === 'update' || first === 'set' || first === 'edit') out.push('save', 'edit')
  if (first === 'export') out.push('export', 'download')
  // "Submit for review" sends EDITS for approval: only tools that change something
  // that already exists (not create / duplicate, which make new things).
  if (first === 'propose' || first === 'submit' || (meta?.effect === 'draft' && ['update', 'set', 'edit', 'save'].includes(first))) out.push('submit for review', 'propose changes', 'propose')
  return [...new Set(out)]
}

/** Route pattern for everything under an entry's admin route. */
export function entryRoutes(entry: PlatformEntryLike): string[] {
  const base = entry.href.split('?')[0].replace(/\/+$/, '') || '/admin'
  return [base, `${base}/*`]
}

/**
 * The platform actions available on an entry: its declared actions, else one
 * per tool in its groups (read-only tools are kept — reading counts as doing
 * for a "view"/"open" unit).
 */
export function actionsForEntry(
  entry: PlatformEntryLike,
  toolGroups: Readonly<Record<string, { tools: readonly string[] }>>,
  registry: Readonly<Record<string, ToolMetaLike>>
): PlatformAction[] {
  const routes = entryRoutes(entry)
  if (entry.actions?.length) {
    return entry.actions.map((a) => ({
      entity: entry.id,
      action: a.verb,
      label: a.label ?? humanizeToolName(a.verb),
      synonyms: [...(a.synonyms ?? [])],
      tools: [...a.tools],
      routes,
    }))
  }
  const names = [...new Set(entry.tools.filter((g) => g !== 'extensions').flatMap((g) => toolGroups[g]?.tools ?? []))]
  return names.map((name) => ({
    entity: entry.id,
    action: name,
    label: humanizeToolName(name),
    synonyms: verbSynonyms(name, registry[name]),
    tools: [name],
    routes,
  }))
}

/** The platform map's findAction (lib/ade/platform-map): one matcher for the chat and the coverage check. */
export type FindAction = (entry: PlatformEntryLike, label: string) => { verb: string } | null

/**
 * A coverage UnitMatcher backed by the platform map's findAction for the
 * screen's entry: the map decides which action a button is. When it finds
 * none, the core's own scoring applies (the tool-group fallback). Labels that
 * should resolve but don't are vocabulary gaps — add synonyms to the map.
 */
export function platformMatcher(entry: PlatformEntryLike | null, findAction: FindAction | null, actions: ReadonlyArray<PlatformAction>): UnitMatcher | undefined {
  if (!entry || !findAction) return undefined
  return (unit: CoverageUnit) => {
    const hit = findAction(entry, unit.label)
    if (!hit) return undefined
    return actions.find((a) => a.action === hit.verb) ?? undefined
  }
}
