/**
 * Run: npx -y tsx@4.23.15 src/lib/plural.assert.ts
 */
import assert from 'node:assert/strict'
import { plural } from './plural'

assert.equal(plural(1, 'permission'), '1 permission')
assert.equal(plural(3, 'permission'), '3 permissions')
assert.equal(plural(0, 'permission'), '0 permissions')
assert.equal(plural(0, 'user', 'users', { zero: 'No users' }), 'No users')
assert.equal(plural(2, 'entry', 'entries'), '2 entries')
assert.equal(plural(1200, 'event'), '1,200 events')
console.log('6 assertions passed')
