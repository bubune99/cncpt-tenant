/**
 * Pure planning for scripts/fix-role-permissions.ts.
 *
 * Older seeds stored Role.permissions as a JSON *string* ('["orders.*"]')
 * instead of an array, which the permission checker iterated character by
 * character, and used role names (order_fulfillment, support_agent) that do
 * not match BUILT_IN_ROLES. This module decides what to change; the script
 * applies it. No I/O here so it can be asserted directly.
 */

import { BUILT_IN_ROLES } from './constants'

export interface RoleRow {
  id: string
  name: string
  permissions: unknown
}

/** Legacy seed role name → canonical BUILT_IN_ROLES name. */
export const LEGACY_ROLE_NAMES: Record<string, keyof typeof BUILT_IN_ROLES> = {
  order_fulfillment: 'order_fulfiller',
  support_agent: 'support_staff',
}

export type RoleAction =
  | { kind: 'set-permissions'; roleId: string; name: string; permissions: string[] }
  | { kind: 'merge-into'; roleId: string; name: string; targetName: string }
  | { kind: 'rename'; roleId: string; name: string; newName: string; permissions: string[] }

/** Normalize a stored permissions value to a string array (null if unusable). */
export function normalizePermissions(value: unknown): string[] | null {
  let v = value
  if (typeof v === 'string') {
    try {
      v = JSON.parse(v)
    } catch {
      return null
    }
  }
  if (!Array.isArray(v)) return null
  return v.every((p) => typeof p === 'string') ? (v as string[]) : null
}

export function planRoleRepair(rows: RoleRow[]): RoleAction[] {
  const actions: RoleAction[] = []
  const names = new Set(rows.map((r) => r.name))

  for (const row of rows) {
    const legacyTarget = LEGACY_ROLE_NAMES[row.name]
    if (legacyTarget) {
      if (names.has(legacyTarget)) {
        actions.push({ kind: 'merge-into', roleId: row.id, name: row.name, targetName: legacyTarget })
      } else {
        actions.push({
          kind: 'rename',
          roleId: row.id,
          name: row.name,
          newName: legacyTarget,
          permissions: [...BUILT_IN_ROLES[legacyTarget].permissions],
        })
      }
      continue
    }

    const builtIn = (BUILT_IN_ROLES as Record<string, { permissions: readonly string[] }>)[row.name]
    const current = normalizePermissions(row.permissions)
    if (builtIn) {
      // Built-in roles stored in the broken (string / unparseable) format are
      // reset to their canonical definition. A well-formed array is left
      // alone — it may be an intentional edit made in Roles & Permissions.
      if (typeof row.permissions === 'string' || !current) {
        actions.push({ kind: 'set-permissions', roleId: row.id, name: row.name, permissions: [...builtIn.permissions] })
      }
      continue
    }

    // Custom role: only repair the storage format, keep its permissions.
    if (typeof row.permissions === 'string' && current) {
      actions.push({ kind: 'set-permissions', roleId: row.id, name: row.name, permissions: current })
    }
  }

  return actions
}
