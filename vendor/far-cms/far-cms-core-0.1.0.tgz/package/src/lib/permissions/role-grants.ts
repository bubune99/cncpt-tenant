/**
 * Whether a role's permission list grants one permission, the same way the server checks it
 * (permissionMatches in ./index.ts): exact, '*' for everything, 'group.*' for a whole group.
 * Pure, so the role page can use it; checked by role-grants.assert.ts.
 */
export function roleGrants(permissions: readonly string[], key: string): boolean {
  return permissions.some((p) => p === key || p === '*' || (p.endsWith('.*') && key.startsWith(p.slice(0, -1))))
}
