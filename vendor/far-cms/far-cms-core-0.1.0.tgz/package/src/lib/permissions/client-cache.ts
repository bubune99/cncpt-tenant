/**
 * The browser's copy of "what may I see" (GET /api/auth/permissions) — pure
 * rules for sharing it and for waiting out the rate limit.
 *
 * That endpoint is limited to 10 requests a minute per IP (the auth
 * preset). Every admin page load — every tab, every Preview sizes frame —
 * used to fetch it, and three quick retries inside the same minute turned a
 * 429 into "Couldn't check your access". Now:
 *  - one request per page at a time (dedupe), a 60s cache shared by the
 *    page and its same-origin frames (sessionStorage) and other tabs
 *    (BroadcastChannel);
 *  - on 429 the hook keeps loading and waits Retry-After (capped) before
 *    asking again, within a budget; 5xx / network get short retries.
 *
 * Server checks stay the authority; this only drives what the UI shows.
 * Pure. Run: npx -y tsx@4.23.15 src/lib/permissions/client-cache.assert.ts
 */

export const PERMISSIONS_TTL_MS = 60_000
/** How long a page keeps waiting out 429s before showing the "couldn't check" card. */
export const RATE_LIMIT_BUDGET_MS = 75_000
export const MAX_RETRY_AFTER_MS = 60_000
export const MAX_ERROR_ATTEMPTS = 3

export interface Cached<T> {
  data: T
  at: number
}

/** A cached copy is used while it is younger than the TTL (and not from the future). */
export function isFresh(c: Cached<unknown> | null | undefined, now: number, ttl = PERMISSIONS_TTL_MS): boolean {
  return !!c && c.at <= now && now - c.at < ttl
}

/** Retry-After: seconds, or an HTTP date; null when absent or unreadable. */
export function parseRetryAfter(header: string | null | undefined, now: number): number | null {
  if (!header) return null
  const s = header.trim()
  if (/^\d+(\.\d+)?$/.test(s)) return Math.round(Number(s) * 1000)
  const t = Date.parse(s)
  return Number.isFinite(t) ? Math.max(0, t - now) : null
}

export type RetryDecision = { retry: true; waitMs: number } | { retry: false }

/**
 * After a failed attempt: wait and retry, or give up.
 *  - 429: wait Retry-After (capped at 60s; 5s·2^n without one), as long as
 *    the total waited stays within the budget.
 *  - 5xx / network (status 0): 600ms·2^n, up to 3 attempts.
 *  - anything else (4xx): give up.
 */
export function nextRetry(p: { status: number; retryAfter: string | null; attempt: number; waitedMs: number; now: number }): RetryDecision {
  if (p.status === 429) {
    const hinted = parseRetryAfter(p.retryAfter, p.now)
    const waitMs = Math.min(MAX_RETRY_AFTER_MS, Math.max(1000, hinted ?? 5000 * 2 ** p.attempt))
    return p.waitedMs + waitMs <= RATE_LIMIT_BUDGET_MS ? { retry: true, waitMs } : { retry: false }
  }
  if (p.status === 0 || p.status >= 500) {
    return p.attempt + 1 < MAX_ERROR_ATTEMPTS ? { retry: true, waitMs: 600 * 2 ** p.attempt } : { retry: false }
  }
  return { retry: false }
}

/**
 * One in-flight request shared by every caller; a fresh cached value
 * answers without a request; failures are never cached.
 */
export function createSharedLoader<T>(deps: {
  fetchOnce: () => Promise<T>
  now: () => number
  read: () => Cached<T> | null
  write: (c: Cached<T>) => void
  ttl?: number
}) {
  let inflight: Promise<T> | null = null
  return (force = false): Promise<T> => {
    const c = deps.read()
    if (!force && isFresh(c, deps.now(), deps.ttl)) return Promise.resolve(c!.data)
    if (inflight) return inflight
    const p = deps
      .fetchOnce()
      .then((data) => {
        deps.write({ data, at: deps.now() })
        return data
      })
      .finally(() => {
        if (inflight === p) inflight = null
      })
    inflight = p
    return p
  }
}
