/**
 * Assertions for the role repair planner.
 * Run: npx -y tsx@4.23.15 src/lib/permissions/role-repair.assert.ts
 */
import assert from 'node:assert/strict'
import { normalizePermissions, planRoleRepair } from './role-repair'
import { BUILT_IN_ROLES } from './constants'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

check('string-encoded permissions parse to an array', () => {
  assert.deepEqual(normalizePermissions('["orders.*","products.view"]'), ['orders.*', 'products.view'])
})
check('arrays pass through, junk is null', () => {
  assert.deepEqual(normalizePermissions(['a.b']), ['a.b'])
  assert.equal(normalizePermissions('not json'), null)
  assert.equal(normalizePermissions({ a: 1 }), null)
  assert.equal(normalizePermissions([1, 2]), null)
})
check('built-in role stored as a string is reset to the constants', () => {
  const plan = planRoleRepair([{ id: 'r1', name: 'content_editor', permissions: '["blog.*","pages.*","media.*"]' }])
  assert.deepEqual(plan, [
    { kind: 'set-permissions', roleId: 'r1', name: 'content_editor', permissions: [...BUILT_IN_ROLES.content_editor.permissions] },
  ])
})
check('a correct built-in role is left alone (idempotent)', () => {
  const plan = planRoleRepair([{ id: 'r0', name: 'super_admin', permissions: ['*'] }])
  assert.deepEqual(plan, [])
})
check('a built-in role edited in the UI (valid array) is kept', () => {
  assert.deepEqual(planRoleRepair([{ id: 'r2', name: 'content_editor', permissions: ['pages.*', 'forms.*'] }]), [])
})
check('super_admin stored as the string ["*"] is repaired', () => {
  const plan = planRoleRepair([{ id: 'r0', name: 'super_admin', permissions: '["*"]' }])
  assert.equal(plan.length, 1)
  assert.deepEqual((plan[0] as { permissions: string[] }).permissions, ['*'])
})
check('legacy name renames when the canonical role is absent', () => {
  const plan = planRoleRepair([{ id: 'r3', name: 'order_fulfillment', permissions: '[]' }])
  assert.deepEqual(plan, [
    { kind: 'rename', roleId: 'r3', name: 'order_fulfillment', newName: 'order_fulfiller', permissions: [...BUILT_IN_ROLES.order_fulfiller.permissions] },
  ])
})
check('legacy name merges when the canonical role exists', () => {
  const plan = planRoleRepair([
    { id: 'r4', name: 'support_agent', permissions: '[]' },
    { id: 'r5', name: 'support_staff', permissions: [...BUILT_IN_ROLES.support_staff.permissions] },
  ])
  assert.deepEqual(plan, [{ kind: 'merge-into', roleId: 'r4', name: 'support_agent', targetName: 'support_staff' }])
})
check('custom role: string fixed, permissions kept; array left alone', () => {
  const plan = planRoleRepair([
    { id: 'c1', name: 'volunteer_lead', permissions: '["forms.view"]' },
    { id: 'c2', name: 'board', permissions: ['analytics.view'] },
  ])
  assert.deepEqual(plan, [{ kind: 'set-permissions', roleId: 'c1', name: 'volunteer_lead', permissions: ['forms.view'] }])
})

console.log(`\n${n} assertions passed`)
