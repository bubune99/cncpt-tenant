/**
 * Permission System Types
 */

import type { Permission } from './constants'

// User with resolved permissions
export interface UserWithPermissions {
  id: string
  email: string
  name: string | null

  // Computed permissions (roles + overrides)
  permissions: Set<string>

  // Raw data for debugging
  roles: RoleData[]
  overrides: PermissionOverride[]
}

// Role data from database
export interface RoleData {
  id: string
  name: string
  displayName: string
  description: string | null
  permissions: string[]
  isSystem: boolean
}

// Permission override from database
export interface PermissionOverride {
  id: string
  permission: string
  type: 'GRANT' | 'DENY'
  expiresAt: Date | null
  reason: string | null
}

// Permission check result
export interface PermissionCheckResult {
  allowed: boolean
  reason?: string
  // Which role or override granted/denied this
  source?: {
    type: 'role' | 'override' | 'super_admin'
    id?: string
    name?: string
  }
}

// Audit log action types
export type AuditAction =
  | 'role.create'
  | 'role.update'
  | 'role.delete'
  | 'role.assign'
  | 'role.remove'
  | 'permission.grant'
  | 'permission.deny'
  | 'permission.remove'
  | 'user.create'
  | 'user.update'
  | 'user.delete'
  | 'user.purged'
  | 'user.anonymised'
  | 'page.create'
  | 'page.update'
  | 'page.delete'
  | 'route.create'
  | 'route.update'
  | 'route.delete'
  | 'puck_template.create'
  | 'puck_template.update'
  | 'puck_template.delete'
  | 'template.create'
  | 'template.update'
  | 'template.delete'
  | 'product.create'
  | 'product.update'
  | 'product.delete'
  | 'product.archive'
  | 'order.update'
  | 'order.delete'
  | 'order.fulfill'
  | 'order.refund'
  | 'order.cancel'
  | 'customer.create'
  | 'customer.update'
  | 'customer.delete'
  | 'customer.export'
  | 'blog.create'
  | 'blog.update'
  | 'blog.delete'
  | 'blog.publish'
  | 'settings.update'
  | 'site_settings.update'
  | 'canva.connect'
  | 'canva.disconnect'
  | 'canva.import'
  | 'partial.create'
  | 'partial.update'
  | 'partial.delete'
  | 'form.update'
  | 'mcp.limit_refused'
  | 'mcp.key_create'
  | 'mcp.key_revoke'
  | 'privacy.subject_export'
  | 'privacy.subject_delete'
  | 'form.automation_test'
  | 'form.bulk_run'
  | 'form.bulk_stop'
  | 'form.export'
  | 'form.credit_approve'
  | 'form.credit_decline'
  | 'form.submission_update'
  // A reply sent to a form's sender from the admin (mobile Inbox; details: to (hashed), subject, sent|dropped)
  | 'form.submission_reply'
  | 'partial.set_default'
  | 'tour.create'
  | 'tour.update'
  | 'tour.delete'
  | 'help.update'
  // Generic action recorded when the AI agent executes a dynamic tool
  // (VMCP/MCP) that has no dedicated audit action of its own.
  | 'agent.tool_execute'
  // A person undid one recorded change (details: the undone version, the run it came from, the new version).
  | 'agent.undo'
  // The agent tried to read something the visibility policy blocks or masks
  // (details: runId, mode, target, fields, reason, tool — never the value).
  | 'ai.read_blocked'
  // Personal email connectors (details: provider, via; never addresses, subjects or tokens).
  | 'connector.connect'
  | 'connector.disconnect'
  | 'connector.email_sent'

// Audit log entry
export interface AuditLogEntry {
  id: string
  userId: string | null
  userEmail: string | null
  action: AuditAction
  targetType: string | null
  targetId: string | null
  details: Record<string, unknown>
  ipAddress: string | null
  userAgent: string | null
  createdAt: Date
}

// API request types
export interface AssignRoleRequest {
  userId: string
  roleId: string
}

export interface RemoveRoleRequest {
  userId: string
  roleId: string
}

export interface GrantPermissionRequest {
  userId: string
  permission: Permission | string
  expiresAt?: Date | string
  reason?: string
}

export interface DenyPermissionRequest {
  userId: string
  permission: Permission | string
  expiresAt?: Date | string
  reason?: string
}

export interface RemovePermissionOverrideRequest {
  userId: string
  permission: Permission | string
}

export interface CreateRoleRequest {
  name: string
  displayName: string
  description?: string
  permissions: string[]
  position?: number
}

export interface UpdateRoleRequest {
  displayName?: string
  description?: string
  permissions?: string[]
  position?: number
}

// API response types
export interface RoleWithAssignments extends RoleData {
  _count: {
    assignments: number
  }
}

export interface UserPermissionSummary {
  userId: string
  email: string
  name: string | null
  roles: Array<{
    id: string
    name: string
    displayName: string
  }>
  overrides: PermissionOverride[]
  effectivePermissions: string[]
}
