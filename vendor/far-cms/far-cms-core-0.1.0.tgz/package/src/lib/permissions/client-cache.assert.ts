/**
 * Run: npx -y tsx@4.23.15 src/lib/permissions/client-cache.assert.ts
 */
import assert from 'node:assert/strict'
import { RATE_LIMIT_BUDGET_MS, createSharedLoader, isFresh, nextRetry, parseRetryAfter, type Cached } from './client-cache'

let n = 0
const log = (name: string) => { n++; console.log(`ok ${n} - ${name}`) }

async function main() {
  // Cache freshness.
  assert.equal(isFresh({ data: 1, at: 1000 }, 50_000), true)
  assert.equal(isFresh({ data: 1, at: 1000 }, 61_000), false)
  assert.equal(isFresh({ data: 1, at: 99_000 }, 50_000), false, 'a copy from the future (clock skew) is not trusted')
  assert.equal(isFresh(null, 1), false)
  log('a cached copy counts for 60s')

  // Retry-After parsing.
  assert.equal(parseRetryAfter('42', 0), 42_000)
  assert.equal(parseRetryAfter(new Date(10_000).toUTCString(), 4_000), 6_000)
  assert.equal(parseRetryAfter('soon', 0), null)
  assert.equal(parseRetryAfter(null, 0), null)
  log('Retry-After: seconds or an HTTP date')

  // Backoff rules.
  assert.deepEqual(nextRetry({ status: 429, retryAfter: '42', attempt: 0, waitedMs: 0, now: 0 }), { retry: true, waitMs: 42_000 })
  assert.deepEqual(nextRetry({ status: 429, retryAfter: '600', attempt: 0, waitedMs: 0, now: 0 }), { retry: true, waitMs: 60_000 }, 'capped at 60s')
  assert.deepEqual(nextRetry({ status: 429, retryAfter: null, attempt: 1, waitedMs: 0, now: 0 }), { retry: true, waitMs: 10_000 }, 'no header: 5s·2^n')
  assert.deepEqual(nextRetry({ status: 429, retryAfter: '42', attempt: 1, waitedMs: 30_000, now: 0 }), { retry: true, waitMs: 42_000 }, '30s + 42s fits the 75s budget')
  assert.equal(nextRetry({ status: 429, retryAfter: '42', attempt: 1, waitedMs: 42_000, now: 0 }).retry, false, '42s + 42s does not')
  log('429 waits Retry-After (capped), never three quick retries in the same minute')
  assert.equal(nextRetry({ status: 429, retryAfter: '42', attempt: 2, waitedMs: RATE_LIMIT_BUDGET_MS - 10_000, now: 0 }).retry, false, 'past the budget: give up and show the card')
  assert.deepEqual(nextRetry({ status: 503, retryAfter: null, attempt: 0, waitedMs: 0, now: 0 }), { retry: true, waitMs: 600 })
  assert.deepEqual(nextRetry({ status: 0, retryAfter: null, attempt: 1, waitedMs: 0, now: 0 }), { retry: true, waitMs: 1200 })
  assert.equal(nextRetry({ status: 500, retryAfter: null, attempt: 2, waitedMs: 0, now: 0 }).retry, false)
  assert.equal(nextRetry({ status: 403, retryAfter: null, attempt: 0, waitedMs: 0, now: 0 }).retry, false)
  log('5xx/network: short retries; other 4xx: no retry')

  // Dedupe + shared cache.
  let calls = 0
  let t = 0
  let store: Cached<string> | null = null
  let release: (v: string) => void = () => {}
  const load = createSharedLoader<string>({
    fetchOnce: () => { calls++; return new Promise<string>((r) => { release = r }) },
    now: () => t,
    read: () => store,
    write: (c) => { store = c },
  })
  const a = load()
  const b = load()
  const c = load()
  assert.equal(calls, 1, 'three components mounting at once: one request')
  release('perms')
  assert.deepEqual(await Promise.all([a, b, c]), ['perms', 'perms', 'perms'])
  t = 30_000
  assert.equal(await load(), 'perms')
  assert.equal(calls, 1, 'within 60s: from the shared cache (a frame or another tab wrote it)')
  t = 61_000
  const d = load()
  assert.equal(calls, 2, 'stale: one new request')
  release('perms2')
  assert.equal(await d, 'perms2')
  void load(true)
  assert.equal(calls, 3, 'refresh forces a request')
  release('perms3')
  log('one request at a time; fresh cache answers without a request; refresh forces one')

  // Failures are never cached.
  let fail = true
  let calls2 = 0
  let store2: Cached<string> | null = null
  const load2 = createSharedLoader<string>({
    fetchOnce: () => { calls2++; return fail ? Promise.reject(new Error('boom')) : Promise.resolve('ok') },
    now: () => 0,
    read: () => store2,
    write: (c) => { store2 = c },
  })
  await assert.rejects(load2())
  fail = false
  assert.equal(await load2(), 'ok')
  assert.equal(calls2, 2)
  log('a failure is never cached')

  console.log(`\n${n} checks passed`)
}

void main()
