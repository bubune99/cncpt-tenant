/**
 * The role page must count a permission as on exactly when the server would grant it (permissionMatches in
 * ./index.ts). Found 2026-11-22: Super Admin ('*') read "Everything" yet every group showed "0 of 5".
 * Run: node_modules/.bin/tsx src/lib/permissions/role-grants.assert.ts
 */
import assert from 'node:assert/strict'
import { roleGrants } from './role-grants'

assert.equal(roleGrants(['*'], 'products.view'), true, "'*' grants everything")
assert.equal(roleGrants(['products.*'], 'products.edit'), true, "'products.*' grants every products permission")
assert.equal(roleGrants(['products.*'], 'productVariants.view'), false, 'but not a group whose name only starts the same')
assert.equal(roleGrants(['orders.view'], 'orders.view'), true)
assert.equal(roleGrants(['orders.view'], 'orders.edit'), false)
assert.equal(roleGrants([], 'orders.view'), false)
console.log('role-grants: 6 checks passed')
