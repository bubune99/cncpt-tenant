/**
 * Model price table (pure — no I/O). Used by the admin usage stats
 * (./usage.ts) and the AI cost test kit (./testing/run-scenarios.ts).
 */

// Approximate pricing per 1M tokens (input/output averaged).
// Keys must cover every ID ever written to ai_messages.metadata.model —
// legacy "-4" IDs included — or estimates silently fall to the default rate.
export const MODEL_PRICING_PER_MILLION: Record<string, number> = {
  'anthropic/claude-sonnet-4.5': 9.0,
  'anthropic/claude-haiku-4.5': 3.0, // $1 / $5 per 1M (gateway, 2026-10-10)
  'anthropic/claude-opus-4.5': 15.0, // $5 / $25 per 1M (gateway, 2026-10-10)
  // Legacy IDs from before the catalog consolidation (same tiers)
  'anthropic/claude-sonnet-4': 9.0,
  'anthropic/claude-haiku-4': 1.25,
  'anthropic/claude-opus-4': 45.0,
  // Claude 5.5 — Vercel AI Gateway price list (GET https://ai-gateway.vercel.sh/v1/models,
  // read 2026-10-10), averaged the same way: (input + output) / 2 per 1M tokens.
  //   Opus 5.5   $4 in / $20 out → 12.0
  //   Sonnet 5.5 $2 in / $10 out → 6.0
  //   Haiku 5.5  $0.10 in / $0.50 out → 0.30 (first tier; above 100k input tokens
  //              the gateway charges $0.50 / $2.50, i.e. 1.5)
  // Every id form we may store: gateway ("…-5.5"), dashed, and bare Anthropic.
  'anthropic/claude-opus-5.5': 12.0,
  'anthropic/claude-opus-5-5': 12.0,
  'claude-opus-5-5': 12.0,
  'anthropic/claude-sonnet-5.5': 6.0,
  'anthropic/claude-sonnet-5-5': 6.0,
  'claude-sonnet-5-5': 6.0,
  'anthropic/claude-haiku-5.5': 0.3,
  'anthropic/claude-haiku-5-5': 0.3,
  'claude-haiku-5-5': 0.3,
}
export const DEFAULT_PRICE_PER_MILLION = 9.0

export function estimateCost(totalTokens: number, model?: string): number {
  const pricePerMillion = model
    ? (MODEL_PRICING_PER_MILLION[model] ?? DEFAULT_PRICE_PER_MILLION)
    : DEFAULT_PRICE_PER_MILLION
  return (totalTokens / 1_000_000) * pricePerMillion
}
