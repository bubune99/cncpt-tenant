/**
 * Dynamic tool loading for the admin assistant.
 *
 * Sending every tool definition on every step costs ~15k tokens before the
 * model reads a word. Instead a small core set is always on, the groups the
 * current screen and message obviously need are preloaded, and the model can
 * call `load_tools` for anything else mid-task.
 *
 * Tools are also put in a stable order — core first, then the screen tool,
 * then groups in a fixed order — so the prompt-cache prefix (tools come before
 * the system prompt) stays byte-identical across requests. The last core tool
 * carries a cache breakpoint.
 *
 * Pure: no React, no DB. Run: npx -y tsx@4.23.15 src/lib/ai/toolsets.assert.ts
 */

export type ToolGroupKey =
  | 'pages'
  | 'blocks'
  | 'blog'
  | 'initiatives'
  | 'records'
  | 'forms'
  | 'settings'
  | 'help'
  | 'shop'
  | 'email'
  | 'extensions'

/** Always on: looking at the screen, finding things, moving around, pointing, and loading more tools. */
export const CORE_TOOLS = [
  'navigateTo',
  'navigate_to_route',
  'spotlight_steps',
  'spotlight_step',
  'getEntityDetails',
  'searchEntities',
  'getEntityStats',
  'getSiteContext',
  'getSiteTraffic',
  'messageSiteOwner',
  'send_feedback_to_owner',
  'listNavigationTabs',
  'describe_platform',
  'read_view',
  'show_unit',
  'capture_view',
  'open_tab',
  'expand',
  'collapse',
  'scroll_to',
  'open_menu',
  'coverage_check',
  'update_plan',
  'ask_user',
  'load_tools',
] as const

/** The per-screen dispatcher; its description varies by screen, so it sits right after the cached core. */
export const SCREEN_TOOL = 'operate_ui'

export const TOOL_GROUPS: Record<Exclude<ToolGroupKey, 'extensions'>, { summary: string; tools: readonly string[] }> = {
  pages: {
    summary: 'create, rename, duplicate, delete and publish pages',
    tools: ['createPage', 'updatePage', 'deletePage', 'duplicatePage', 'publishPage'],
  },
  blocks: {
    summary: "read and edit the blocks on a page and the site header/footer; build from the block library (saved blocks, layouts, ideas)",
    tools: ['getPageBlocks', 'updateBlock', 'insertBlock', 'removeBlock', 'moveBlock', 'importPageCode', 'generateImage', 'getSiteLayoutBlocks', 'updateSiteLayoutBlock', 'insertSiteLayoutBlock', 'find_blocks', 'suggest_layouts', 'add_block', 'save_block'],
  },
  blog: {
    summary: 'write, edit, publish and organise blog posts, categories and tags',
    tools: ['createBlogPost', 'updateBlogPost', 'deleteBlogPost', 'publishBlogPost', 'manageBlogCategory', 'manageBlogTag'],
  },
  initiatives: {
    summary: 'how many initiatives are live / drafts, and which are featured on the home page (create, change, stage and publish them with the records tools)',
    tools: ['listInitiatives', 'setFeaturedInitiatives'],
  },
  records: {
    summary: 'records of any type (list, read, create with a page, update, publish, placement overrides)',
    tools: ['listRecordTypes', 'listRecords', 'getRecord', 'createRecordWithPage', 'updateRecord', 'publishRecord', 'archiveRecord', 'overridePlacementField', 'resetPlacementField'],
  },
  forms: {
    summary: 'forms: list them, read fields and submissions settings, display mode, automations',
    tools: ['listForms', 'getForm', 'listFormSubmissions', 'setFormDisplay', 'setFormAutomations'],
  },
  settings: {
    summary: 'site, branding and admin settings, renaming or reordering the admin menu, and who may see private areas (explain / propose access for a person or role)',
    tools: ['updateSettings', 'updateBrandingSettings', 'updateSiteSettings', 'customizeNavigationTab', 'explain_access', 'draft_access_change'],
  },
  help: {
    summary: 'guided walkthroughs, explaining elements, and managing help content',
    tools: [
      'suggestWalkthroughs', 'generateWalkthrough', 'startWalkthrough', 'createHelpContent', 'listWalkthroughs',
      'explainElement', 'highlightElement', 'startGuidedExplanation', 'scan_page',
      'listHelpKeys', 'getHelpContent', 'updateHelpContent', 'scanForMissingHelp', 'batchGenerateHelp',
      'reviewOrphanedHelp', 'markHelpOrphaned', 'manageHelpStatus', 'purgeDeletedHelp', 'generateEntityHelp',
    ],
  },
  shop: {
    summary: 'products, variants, orders, fulfilment, refunds and store stats',
    tools: [
      'searchProducts', 'searchOrders', 'getDashboardStats', 'getRecentActivity',
      'createProduct', 'updateProduct', 'deleteProduct', 'manageProductVariant', 'syncProductToStripe',
      'updateOrderStatus', 'fulfillOrder', 'refundOrder', 'cancelOrder',
    ],
  },
  email: {
    summary: 'the person’s own connected mailbox (Gmail / Outlook): search, read, write drafts, send with their approval',
    tools: [
      'email_search_threads', 'email_read_thread', 'email_list_drafts', 'email_create_draft', 'email_update_draft', 'email_prepare_send', 'email_send_draft',
      // Gmail MCP pass-through (when enabled)
      'email_gmail_search_threads', 'email_gmail_get_thread', 'email_gmail_get_message', 'email_gmail_list_drafts', 'email_gmail_list_labels',
    ],
  },
}

/** Fixed group order — part of the cache prefix, so never sort by load order. */
export const GROUP_ORDER: readonly ToolGroupKey[] = ['pages', 'blocks', 'blog', 'initiatives', 'records', 'forms', 'settings', 'help', 'shop', 'email', 'extensions']

export const EXTENSIONS_SUMMARY = 'custom tools added by an administrator (VMCP / MCP servers)'

const CORE_SET = new Set<string>(CORE_TOOLS)
const GROUP_OF = new Map<string, ToolGroupKey>()
for (const [g, def] of Object.entries(TOOL_GROUPS)) for (const t of def.tools) GROUP_OF.set(t, g as ToolGroupKey)

/** Which group a tool belongs to; anything unknown (VMCP/MCP) is an extension. */
export function groupOf(toolName: string): ToolGroupKey | 'core' | 'screen' {
  if (CORE_SET.has(toolName)) return 'core'
  if (toolName === SCREEN_TOOL) return 'screen'
  return GROUP_OF.get(toolName) ?? 'extensions'
}

export function isToolGroupKey(v: unknown): v is ToolGroupKey {
  return typeof v === 'string' && (GROUP_ORDER as readonly string[]).includes(v)
}

/**
 * App-supplied extras (another app's screens and words). The host passes
 * them in (Dzidzor: lib/ade-bindings/app-config toolHints) — this file never
 * imports app code. Group names that aren't real groups are ignored.
 */
export interface ToolHints {
  /** Checked BEFORE the generic routes (first match wins), so an app can specialise a path. */
  routes?: ReadonlyArray<readonly [RegExp, readonly string[]]>
  /** Added to the generic keyword rules. */
  keywords?: ReadonlyArray<readonly [RegExp, readonly string[]]>
}

/** Groups the screen being worked on obviously needs (generic CMS screens). */
const ROUTE_GROUPS: Array<[RegExp, ToolGroupKey[]]> = [
  [/^\/admin\/pages(\/|$)/, ['pages', 'blocks']],
  [/^\/admin\/partials(\/|$)/, ['blocks']],
  [/^\/admin\/site-settings(\/|$)/, ['blocks', 'settings']],
  [/^\/admin\/blog(\/|$)/, ['blog']],
  [/^\/admin\/records(\/|$)/, ['records']],
  [/^\/admin\/forms(\/|$)/, ['forms']],
  [/^\/admin\/settings(\/|$)/, ['settings']],
  [/^\/admin\/(products|orders|customers|shipping)(\/|$)/, ['shop']],
  [/^\/admin\/help(\/|$)/, ['help']],
  [/^\/admin\/inbox(\/|$)/, ['email']],
]

/** Words in the person's message that make a group's need obvious (saves a load_tools round trip). */
const KEYWORD_GROUPS: Array<[RegExp, ToolGroupKey[]]> = [
  [/\b(pages?|landing|slug|duplicate)\b/i, ['pages']],
  [/\b(blocks?|section|heading|header|footer|hero|button|image|text on|wording|copy)\b/i, ['blocks']],
  [/\b(blog|posts?|article|categor(y|ies)|tags?)\b/i, ['blog']],
  [/\b(records?)\b/i, ['records']],
  [/\b(forms?|submissions?|sign-?ups?|newsletter|automations?)\b/i, ['forms']],
  [/\b(settings?|branding|logo|colou?rs?|menu)\b/i, ['settings']],
  [/\b(walkthrough|tour|show me around|explain|help (text|content))\b/i, ['help']],
  [/\b(products?|orders?|refund|fulfil+|inventory|stock|variants?|sales)\b/i, ['shop']],
  [/\b(e-?mails?|inbox|mailbox|gmail|outlook|reply to|draft (a )?(reply|message))\b/i, ['email']],
]

export function groupsForRequest(input: {
  route?: string | null
  message?: string | null
  /** Groups loaded earlier in this conversation (load_tools calls in history). */
  previouslyLoaded?: readonly string[]
  /** Help keys the current screen offers (entityContext.availableHelpKeys): the prompt then points at explainElement / highlightElement, so 'help' must be on. */
  availableHelpKeys?: readonly string[] | null
  /** The app's extra routes / words. */
  hints?: ToolHints
}): ToolGroupKey[] {
  const out = new Set<ToolGroupKey>()
  const add = (gs: readonly string[]) => gs.forEach((g) => isToolGroupKey(g) && out.add(g))
  const route = input.route ?? ''
  const routes = [...(input.hints?.routes ?? []), ...ROUTE_GROUPS]
  for (const [re, gs] of routes) if (re.test(route)) { add(gs); break }
  const msg = (input.message ?? '').slice(0, 2000)
  for (const [re, gs] of [...KEYWORD_GROUPS, ...(input.hints?.keywords ?? [])]) if (re.test(msg)) add(gs)
  for (const g of input.previouslyLoaded ?? []) if (isToolGroupKey(g)) out.add(g)
  if (input.availableHelpKeys && input.availableHelpKeys.length > 0) out.add('help')
  return GROUP_ORDER.filter((g) => out.has(g))
}

/**
 * Stable tool order for the cache prefix: core (in CORE_TOOLS order), then the
 * screen tool, then each group in GROUP_ORDER (tools in their listed order),
 * then extensions alphabetically. Returns names only; tools not present are skipped.
 */
export function orderToolNames(present: readonly string[]): string[] {
  const has = new Set(present)
  const out: string[] = []
  for (const t of CORE_TOOLS) if (has.has(t)) out.push(t)
  if (has.has(SCREEN_TOOL)) out.push(SCREEN_TOOL)
  for (const g of GROUP_ORDER) {
    if (g === 'extensions') continue
    for (const t of TOOL_GROUPS[g].tools) if (has.has(t)) out.push(t)
  }
  out.push(...present.filter((t) => groupOf(t) === 'extensions').sort())
  return out
}

/** The last core tool present — where the tools cache breakpoint goes. */
export function cacheBreakpointTool(ordered: readonly string[]): string | null {
  let last: string | null = null
  for (const t of ordered) if (groupOf(t) === 'core') last = t
  return last
}

/** Names the model may call this step: core + screen tool + the loaded groups, in prefix order. */
export function activeToolNames(ordered: readonly string[], loaded: readonly ToolGroupKey[]): string[] {
  const on = new Set<string>(loaded)
  return ordered.filter((t) => {
    const g = groupOf(t)
    return g === 'core' || g === 'screen' || on.has(g)
  })
}

/** Groups that actually have at least one tool available to this user (after governance). */
export function availableGroups(present: readonly string[]): ToolGroupKey[] {
  const gs = new Set(present.map(groupOf))
  return GROUP_ORDER.filter((g) => gs.has(g))
}

/** Groups requested via load_tools calls in earlier steps / messages. */
export function groupsFromLoadCalls(calls: ReadonlyArray<{ toolName?: string; input?: unknown }>): ToolGroupKey[] {
  const out = new Set<ToolGroupKey>()
  for (const c of calls) {
    if (c.toolName !== 'load_tools') continue
    const gs = (c.input as { groups?: unknown } | undefined)?.groups
    if (Array.isArray(gs)) for (const g of gs) if (isToolGroupKey(g)) out.add(g)
  }
  return GROUP_ORDER.filter((g) => out.has(g))
}

/** Static catalogue for the load_tools description (byte-stable → cacheable). */
export function groupCatalogue(): string {
  return GROUP_ORDER.map((g) => `- ${g}: ${g === 'extensions' ? EXTENSIONS_SUMMARY : TOOL_GROUPS[g].summary}`).join('\n')
}
