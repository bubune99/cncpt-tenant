/**
 * Run: npx -y tsx@4.23.15 src/lib/ai/pricing.assert.ts
 */
import assert from 'node:assert/strict'
import { DEFAULT_PRICE_PER_MILLION, MODEL_PRICING_PER_MILLION, estimateCost } from './pricing'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const near = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-9, `${a} ≈ ${b}`)

check('every 5.5 id form is costed at its own rate, not the default', () => {
  const rates = { opus: 12.0, sonnet: 6.0, haiku: 0.3 }
  for (const [tier, rate] of Object.entries(rates)) {
    for (const id of [`anthropic/claude-${tier}-5.5`, `anthropic/claude-${tier}-5-5`, `claude-${tier}-5-5`]) {
      assert.ok(id in MODEL_PRICING_PER_MILLION, `${id} is priced`)
      near(estimateCost(1_000_000, id), rate)
      assert.notEqual(estimateCost(1_000_000, id), DEFAULT_PRICE_PER_MILLION)
    }
  }
})

check('a million tokens of Haiku 5.5 costs 30 cents, a thousand 0.03 cents', () => {
  near(estimateCost(1_000_000, 'anthropic/claude-haiku-5.5'), 0.3)
  near(estimateCost(1_000, 'anthropic/claude-haiku-5.5'), 0.0003)
})

check('unknown models still fall to the default rate', () => {
  near(estimateCost(1_000_000, 'anthropic/claude-unknown-9'), DEFAULT_PRICE_PER_MILLION)
  near(estimateCost(1_000_000), DEFAULT_PRICE_PER_MILLION)
})

console.log(`\n${n} checks passed`)
