/**
 * Block edit operations — pure (no DB), shared by the block tools (direct
 * writes) and the ADE drafters (proposed changes). Both inputs are cloned,
 * never mutated, so a drafter can compute "after" from "before" safely.
 */

export interface BlockNode {
  id?: string;
  tag?: string;
  className?: string;
  textContent?: string;
  attrs?: Record<string, string>;
  children?: BlockNode[];
  label?: string;
  hidden?: boolean;
  locked?: boolean;
  componentName?: string;
  partialId?: string;
}

export interface PageContent {
  version?: string;
  blocks?: BlockNode[];
  [key: string]: unknown;
}

export function findBlock(
  blocks: BlockNode[] | undefined,
  blockId: string
): { block: BlockNode; parent: BlockNode[] } | null {
  for (const b of blocks || []) {
    if (b.id === blockId) return { block: b, parent: blocks! };
    const inChild = findBlock(b.children, blockId);
    if (inChild) return inChild;
  }
  return null;
}

export function sanitizeAttrs(
  existing: Record<string, string> | undefined,
  patch: Record<string, string | null> | undefined
): { attrs: Record<string, string> | undefined; error?: string } {
  if (!patch) return { attrs: existing };
  const merged: Record<string, string> = { ...(existing || {}) };
  for (const [key, value] of Object.entries(patch)) {
    // Event-handler attributes would execute script in visitors' browsers.
    if (/^on/i.test(key)) return { attrs: existing, error: `Attribute not allowed: ${key}` };
    if (value === null) delete merged[key];
    else merged[key] = value;
  }
  return { attrs: Object.keys(merged).length ? merged : undefined };
}

function cloneContent(content: unknown): PageContent {
  const base = (content && typeof content === 'object' ? content : {}) as PageContent;
  return structuredClone(base);
}

export interface BlockUpdateArgs {
  blockId: string;
  className?: string;
  textContent?: string;
  attrs?: Record<string, string | null>;
  label?: string;
  hidden?: boolean;
}

export function applyBlockUpdate(
  content: unknown,
  args: BlockUpdateArgs
): { content: PageContent; changed: string[] } | { error: string } {
  const next = cloneContent(content);
  const hit = findBlock(next.blocks, args.blockId);
  if (!hit) return { error: `Block not found on this page: ${args.blockId}` };
  if (hit.block.locked) {
    return { error: 'Block is locked in the editor — unlock it in the page builder first.' };
  }

  const changed: string[] = [];
  if (args.className !== undefined) { hit.block.className = args.className; changed.push('className'); }
  if (args.textContent !== undefined) { hit.block.textContent = args.textContent; changed.push('textContent'); }
  if (args.label !== undefined) { hit.block.label = args.label; changed.push('label'); }
  if (args.hidden !== undefined) { hit.block.hidden = args.hidden; changed.push('hidden'); }
  if (args.attrs !== undefined) {
    const result = sanitizeAttrs(hit.block.attrs, args.attrs);
    if (result.error) return { error: result.error };
    hit.block.attrs = result.attrs;
    changed.push('attrs');
  }
  if (changed.length === 0) return { error: 'No fields to change were provided' };
  return { content: next, changed };
}

export interface BlockInsertArgs {
  parentBlockId?: string;
  index?: number;
  tag: string;
  className?: string;
  textContent?: string;
  attrs?: Record<string, string | null>;
  label?: string;
  /** Smart-block component (record placements are inserted this way). */
  componentName?: string;
  /** Override the generated id (tests). */
  newId?: string;
}

export function newBlockId(): string {
  return `blk_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
}

export function applyBlockInsert(
  content: unknown,
  args: BlockInsertArgs
): { content: PageContent; newBlock: BlockNode; at: number } | { error: string } {
  const next = cloneContent(content);
  next.blocks = next.blocks || [];

  let siblings = next.blocks;
  if (args.parentBlockId) {
    const hit = findBlock(next.blocks, args.parentBlockId);
    if (!hit) return { error: `Parent block not found: ${args.parentBlockId}` };
    if (hit.block.locked) return { error: 'Parent block is locked in the editor.' };
    hit.block.children = hit.block.children || [];
    siblings = hit.block.children;
  }

  const attrsResult = sanitizeAttrs(undefined, args.attrs);
  if (attrsResult.error) return { error: attrsResult.error };

  const newBlock: BlockNode = {
    id: args.newId ?? newBlockId(),
    tag: args.tag,
    className: args.className || '',
    ...(args.textContent !== undefined ? { textContent: args.textContent } : {}),
    ...(attrsResult.attrs ? { attrs: attrsResult.attrs } : {}),
    ...(args.label ? { label: args.label } : {}),
    ...(args.componentName ? { componentName: args.componentName } : {}),
  };
  const at = args.index === undefined ? siblings.length : Math.min(args.index, siblings.length);
  siblings.splice(at, 0, newBlock);
  return { content: next, newBlock, at };
}

export interface BlockRemoveArgs {
  blockId: string;
}

/** Remove a block and everything inside it. Locked blocks are refused. */
export function applyBlockRemove(
  content: unknown,
  args: BlockRemoveArgs
): { content: PageContent; removed: BlockNode } | { error: string } {
  const next = cloneContent(content);
  const hit = findBlock(next.blocks, args.blockId);
  if (!hit) return { error: `Block not found on this page: ${args.blockId}` };
  if (hit.block.locked) return { error: 'Block is locked in the editor — unlock it in the page builder first.' };
  hit.parent.splice(hit.parent.indexOf(hit.block), 1);
  return { content: next, removed: hit.block };
}

export interface BlockMoveArgs {
  blockId: string;
  /** New parent; omit for the page root. */
  parentBlockId?: string;
  /** Position among the new siblings, counted after the block is taken out (default: append). */
  index?: number;
}

function contains(block: BlockNode, id: string): boolean {
  return (block.children || []).some((c) => c.id === id || contains(c, id));
}

/** Move a block (with its children) under another parent or to the root, at an index. */
export function applyBlockMove(
  content: unknown,
  args: BlockMoveArgs
): { content: PageContent; at: number } | { error: string } {
  const next = cloneContent(content);
  next.blocks = next.blocks || [];
  const hit = findBlock(next.blocks, args.blockId);
  if (!hit) return { error: `Block not found on this page: ${args.blockId}` };
  if (hit.block.locked) return { error: 'Block is locked in the editor — unlock it in the page builder first.' };
  if (args.parentBlockId && (args.parentBlockId === args.blockId || contains(hit.block, args.parentBlockId))) {
    return { error: 'A block cannot be moved inside itself.' };
  }
  let siblings = next.blocks;
  if (args.parentBlockId) {
    const parent = findBlock(next.blocks, args.parentBlockId);
    if (!parent) return { error: `Parent block not found: ${args.parentBlockId}` };
    if (parent.block.locked) return { error: 'Parent block is locked in the editor.' };
    parent.block.children = parent.block.children || [];
    siblings = parent.block.children;
  }
  hit.parent.splice(hit.parent.indexOf(hit.block), 1);
  const at = args.index === undefined ? siblings.length : Math.max(0, Math.min(args.index, siblings.length));
  siblings.splice(at, 0, hit.block);
  return { content: next, at };
}
