/**
 * Run: node_modules/.bin/tsx src/lib/ai/assistant-turn.assert.ts
 */
import assert from 'node:assert/strict'
import { readAssistantTurn } from './assistant-turn'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('a fresh reply: all its text parts, no prior parts', () => {
  const t = readAssistantTurn({ id: 'a1', parts: [{ type: 'text', text: 'Hello ' }, { type: 'tool-x' }, { type: 'text', text: 'there' }] }, { id: 'u1', role: 'user', parts: [] })
  assert.equal(t.text, 'Hello there')
  assert.equal(t.continuing, false)
  assert.equal(t.newParts.length, 3)
  assert.deepEqual(t.allParts.length, 3)
})
check('a continuation saves only the parts after what the earlier request saved', () => {
  const last = { id: 'a1', role: 'assistant', parts: [{ type: 'text', text: 'Before. ' }] }
  const t = readAssistantTurn({ id: 'a1', parts: [{ type: 'text', text: 'Before. ' }, { type: 'text', text: 'After.' }] }, last)
  assert.equal(t.continuing, true)
  assert.equal(t.text, 'After.')
  assert.equal(t.allParts.length, 2, 'whole message for spots/changes (no prior parts added twice)')
})
check('a new reply after an assistant turn carries that turn\'s parts for spots and changes', () => {
  const last = { id: 'a0', role: 'assistant', parts: [{ type: 'tool-read' }] }
  const t = readAssistantTurn({ id: 'a2', parts: [{ type: 'text', text: 'Done' }] }, last)
  assert.equal(t.continuing, false)
  assert.equal(t.allParts.length, 2)
})
check('older shapes with content instead of parts still give their text', () => {
  const t = readAssistantTurn({ id: 'x', content: [{ type: 'text', text: 'Old shape' }] }, undefined)
  assert.equal(t.text, 'Old shape')
})
check('nothing readable gives empty text and no parts', () => {
  const t = readAssistantTurn(null, undefined)
  assert.equal(t.text, '')
  assert.equal(t.newParts.length, 0)
})
console.log(`\n${n} checks passed`)
