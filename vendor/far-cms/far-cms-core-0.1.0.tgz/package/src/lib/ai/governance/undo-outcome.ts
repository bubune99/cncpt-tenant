/**
 * What the Undo button tells the person, in plain words — for every answer the route can give, and for no answer
 * at all. Pure, asserted by undo-outcome.assert.ts. Undo is never silent: it says "Undone", or why it could not.
 */

export interface UndoOutcome {
  kind: 'done' | 'info' | 'error'
  text: string
}

interface UndoAnswer {
  success?: boolean
  error?: unknown
  alreadyUndone?: boolean
  restored?: unknown
  skipped?: unknown
  notes?: unknown
}

const list = (v: unknown): unknown[] => (Array.isArray(v) ? v : [])

/** `status` is the HTTP status (0 = no answer came back), `body` the parsed JSON if there was any. */
export function undoOutcome(status: number, body: unknown): UndoOutcome {
  const b = (body && typeof body === 'object' ? body : {}) as UndoAnswer
  if (status === 0) return { kind: 'error', text: 'Couldn’t reach the site, so nothing was undone. Check your connection and try again.' }
  if (status === 401 || status === 403) return { kind: 'error', text: typeof b.error === 'string' && b.error ? b.error : 'You don’t have permission to undo this.' }
  if (status < 200 || status >= 300 || b.success === false) {
    return { kind: 'error', text: typeof b.error === 'string' && b.error ? b.error : `Couldn’t undo that (error ${status}). Nothing was changed.` }
  }
  if (b.alreadyUndone) return { kind: 'info', text: 'That change is already undone.' }
  const restored = list(b.restored).length
  if (restored === 0) return { kind: 'info', text: 'Nothing needed putting back.' }
  const skipped = list(b.skipped).length
  if (skipped > 0) {
    const notes = list(b.notes).filter((n): n is string => typeof n === 'string').join(' ')
    return { kind: 'info', text: `Part of it was undone; ${skipped === 1 ? 'one thing was' : `${skipped} things were`} left as it is.${notes ? ` ${notes}` : ''}` }
  }
  return { kind: 'done', text: 'Undone. That is saved as a new version, so nothing is lost.' }
}
