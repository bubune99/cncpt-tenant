/**
 * Undo for one recorded change — pure, asserted by undo-plan.assert.ts.
 *
 * A revision stores the top-level fields one write changed with their value
 * before and after (lib/ade/history). Undoing it puts exactly those fields
 * back to `before`: the state to plan from is the entity as it is now, with
 * just those fields swapped. A field somebody has changed again since
 * (current no longer equals `after`) is a conflict and is left alone, so an
 * undo never overwrites a newer edit. Secrets are never stored, so they are
 * never undone.
 */

import { SECRET_MARK, sameValue } from '../../ade/history'

type Obj = Record<string, unknown>

export interface UndoRevision {
  changed: readonly string[]
  before: Obj
  after: Obj
}

export interface UndoState {
  /** The entity now, with each undoable field put back to its value before the change. */
  target: Obj
  /** Fields to put back. */
  fields: string[]
  /** Fields changed again since (current is neither `after` nor already `before`): not undone. */
  conflicts: string[]
  /** Fields that already hold their old value. */
  alreadyBack: string[]
  /** Fields never stored (secrets), so never undone. */
  secret: string[]
}

export function undoState(current: Obj, rev: UndoRevision, ignore: ReadonlySet<string> = new Set()): UndoState {
  const target: Obj = { ...current }
  const fields: string[] = []
  const conflicts: string[] = []
  const alreadyBack: string[] = []
  const secret: string[] = []
  for (const f of rev.changed) {
    if (ignore.has(f)) continue
    if (rev.before[f] === SECRET_MARK || rev.after[f] === SECRET_MARK) {
      secret.push(f)
      continue
    }
    if (sameValue(current[f], rev.before[f])) {
      alreadyBack.push(f)
      continue
    }
    if (!sameValue(current[f], rev.after[f])) conflicts.push(f)
    // A conflict still goes into the target so the plan lists it (unticked, "changed since").
    target[f] = rev.before[f] ?? null
    fields.push(f)
  }
  return { target, fields, conflicts, alreadyBack, secret }
}

/** Why an undo can't go all the way, in plain words (one line per kind of reason). */
export function undoNotes(state: UndoState, skipped: ReadonlyArray<{ field: string; reason: string }>): string[] {
  const notes: string[] = []
  if (state.secret.length) notes.push('A secret value is never kept, so it can’t be put back.')
  for (const s of skipped) notes.push(`${s.field}: ${s.reason}`)
  return notes
}
