/**
 * Run: npx -y tsx@4.23.15 src/lib/ai/governance/undo-outcome.assert.ts
 */
import assert from 'node:assert/strict'
import { undoOutcome } from './undo-outcome'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('every answer, and no answer, says something in plain words', () => {
  assert.deepEqual(undoOutcome(200, { success: true, restored: ['content'], skipped: [] }).kind, 'done')
  assert.match(undoOutcome(200, { success: true, restored: ['content'], skipped: [] }).text, /^Undone/)
  assert.equal(undoOutcome(200, { success: true, alreadyUndone: true, restored: [], skipped: [] }).kind, 'info')
  assert.equal(undoOutcome(200, { success: true, restored: [], skipped: [] }).kind, 'info', 'a no-op is reported, never silent')
  const part = undoOutcome(200, { success: true, restored: ['title'], skipped: [{ field: 'notes' }], notes: ['notes: Changed by someone else since — left as it is'] })
  assert.equal(part.kind, 'info')
  assert.match(part.text, /left as it is/)
  assert.equal(undoOutcome(409, { success: false, error: 'Nothing could be put back automatically.' }).text, 'Nothing could be put back automatically.')
  assert.equal(undoOutcome(500, { success: false, error: 'Could not undo that change' }).kind, 'error')
  assert.match(undoOutcome(500, null).text, /error 500/)
  assert.match(undoOutcome(404, 'html page').text, /error 404/)
  assert.equal(undoOutcome(0, null).kind, 'error')
  assert.match(undoOutcome(0, null).text, /nothing was undone/)
  assert.equal(undoOutcome(403, {}).kind, 'error')
  assert.equal(undoOutcome(200, 'garbage').kind, 'info', 'an unreadable success still says something')
})

console.log(`\n${n} checks passed`)
