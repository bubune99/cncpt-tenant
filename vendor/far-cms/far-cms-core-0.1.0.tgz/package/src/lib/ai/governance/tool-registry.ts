/**
 * Agent Governance — Tool Registry
 *
 * Single source of truth describing every built-in AI tool the chat agent can
 * call: which business domain it belongs to, which RBAC permission it requires,
 * whether it mutates state, and whether it is high-risk (always needs approval).
 *
 * The model-facing tool NAME (the key used in the assembled `allTools` object,
 * e.g. `createPage`, `navigate_to_route`) is the key here. Tools NOT listed
 * here (dynamic VMCP/MCP tools) are passed through unguarded — they self-govern
 * via their own `needsApproval` (see src/lib/vmcp/tools.ts).
 */

import type { AuditAction } from '../../permissions/types'
import type { AgentToolDomain } from './types'
import { withUntrustedSources, type UntrustedLabel } from '../../ade/governance/taint'
import { UNTRUSTED_SOURCES } from '../../ade-bindings/untrusted-sources'
import { MONEY_TOOLS } from '../../ade-bindings/money-tools'
import { withMoneyRules } from '../../ade/ui/control'
import {
  UNKNOWN_LABELS,
  compositeLabels,
  externalToolNames,
  type CapabilityLabels,
  type Effect,
  type Exposure,
} from '../../ade'

export interface ToolMeta {
  /** Business/pseudo domain this tool belongs to. */
  domain: AgentToolDomain
  /** RBAC permission required to use it (checked for reads AND writes). */
  permission?: string
  /**
   * For polymorphic tools whose required permission depends on the call's
   * input (e.g. `entityType`). Checked at call time; returning `undefined`
   * means the input maps to no known permission and the call is denied.
   */
  permissionFor?: (input: unknown) => string | undefined
  /** True if the tool changes persistent state (DB / Stripe / settings). */
  mutation: boolean
  /** True if it must always require approval (delete/refund/publish/settings). */
  highRisk?: boolean
  /**
   * Input-dependent risk: approval is required for THIS call when it returns
   * true (e.g. a status write that cancels an order) — on top of `highRisk`.
   */
  highRiskWhen?: (input: unknown) => boolean
  /** A further permission THIS call needs (checked at call time with `permission`). */
  extraPermission?: (input: unknown) => string | undefined
  /**
   * A non-mutating tool that WRITES for some inputs (explainElement with
   * saveAsHelp / suggestWalkthrough): those calls ask once the run read
   * outside text (lib/ade/governance/taint).
   */
  writesWhen?: (input: unknown) => boolean
  /** Audit-log action recorded on a successful mutation. */
  audit?: AuditAction
  /**
   * Its results carry text written by outsiders: reading it taints the run,
   * and every change after that needs approval (lib/ade/governance/taint).
   * Set by the app's bindings (lib/ade-bindings/untrusted-sources), not here.
   */
  untrustedSource?: UntrustedLabel
  /**
   * Money (control layer): prices, stock, order states — always the person's approval.
   * Set by the app's bindings (lib/ade-bindings/money-tools), not here.
   */
  money?: true | ((input: unknown) => boolean)
  /** True for navigation tools, gated by AgentSettings.navigationEnabled. */
  navigation?: boolean
  /**
   * ADE capability labels (src/lib/ade/capabilities/labels.ts).
   * exposure: who can reach it — `external-mcp` tools are published over MCP
   *   (the MCP list is GENERATED from this), `in-app` is the admin chat only,
   *   `internal` is server-only.
   * effect: `draft` edits are held for review in draft mode, `irreversible`
   *   ones always need explicit approval and are never offered over MCP.
   */
  exposure: Exposure
  effect: Effect
}

/**
 * View permission per entity type, for the polymorphic entity read tools.
 * Every entity type those tools accept MUST have an entry — an unmapped type
 * is denied rather than passed through.
 */
export const ENTITY_VIEW_PERMISSIONS: Record<string, string> = {
  product: 'products.view',
  order: 'orders.view',
  customer: 'customers.view',
  page: 'pages.view',
  blogPost: 'blog.view',
  workflow: 'workflows.view',
  form: 'forms.view',
  media: 'media.view',
  emailCampaign: 'email.view',
  setting: 'settings.view',
}

function entityViewPermission(input: unknown): string | undefined {
  if (!input || typeof input !== 'object') return undefined
  const entityType = (input as { entityType?: unknown }).entityType
  if (typeof entityType !== 'string') return undefined
  return Object.hasOwn(ENTITY_VIEW_PERMISSIONS, entityType)
    ? ENTITY_VIEW_PERMISSIONS[entityType]
    : undefined
}

/**
 * updateOrderStatus can set CANCELLED: that is what cancelOrder does, so it gets
 * cancelOrder's approval and orders.cancel (a status write must not be a cheaper
 * way to cancel, e.g. when injected order text steers the assistant).
 */
const requestsCancel = (input: unknown) => (input as { status?: unknown } | null)?.status === 'CANCELLED'
const orderCancelGate = {
  highRiskWhen: requestsCancel,
  extraPermission: (input: unknown) => (requestsCancel(input) ? 'orders.cancel' : undefined),
}

const BASE_REGISTRY: Record<string, ToolMeta> = {
  // --- Navigation (gated by navigationEnabled) ---
  navigateTo: { domain: 'navigation', mutation: false, navigation: true, exposure: 'in-app', effect: 'read' },
  navigate_to_route: { domain: 'navigation', mutation: false, navigation: true, exposure: 'in-app', effect: 'read' },
  // Drives the person's own screen (lib/ade/ui/capabilities). State changes run in
  // the browser through the same audited APIs a click uses; publishing needs their yes.
  operate_ui: { domain: 'navigation', mutation: false, navigation: true, exposure: 'in-app', effect: 'read' },

  // --- Visual / meta (never mutate persistent state) ---
  spotlight_steps: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  spotlight_step: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  // The plan shown in the chat (lib/ade/chat/plan): no database, no screen.
  update_plan: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  // The question form (lib/ai/tools/ask-tools): shows choices, changes nothing; answers come back as the person's message.
  ask_user: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  scan_page: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  // Run in the person's browser against the screen they're on (lib/ade/ui/view-dom).
  read_view: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  // Points at a part of the screen (reveals it, view-only, checked): lib/ade/ui/control.
  show_unit: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  // Coverage check: browser-run, view-only walk + a coverage row / To-do item (no site change).
  coverage_check: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  capture_view: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  // View-only navigation (tabs, accordions, menus, scrolling); never save, submit or leave.
  open_tab: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  expand: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  collapse: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  scroll_to: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  open_menu: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },

  // --- Reads (RBAC-gated, never mutate, never need approval) ---
  searchProducts: { domain: 'read', permission: 'products.view', mutation: false, exposure: 'in-app', effect: 'read' },
  searchOrders: { domain: 'read', permission: 'orders.view', mutation: false, exposure: 'in-app', effect: 'read' },
  getDashboardStats: { domain: 'read', permission: 'analytics.view', mutation: false, exposure: 'in-app', effect: 'read' },
  getSiteTraffic: { domain: 'read', permission: 'analytics.view', mutation: false, exposure: 'in-app', effect: 'read' },
  getRecentActivity: { domain: 'read', permission: 'analytics.view', mutation: false, exposure: 'in-app', effect: 'read' },
  getEntityDetails: { domain: 'read', permissionFor: entityViewPermission, mutation: false, exposure: 'in-app', effect: 'read' },
  searchEntities: { domain: 'read', permissionFor: entityViewPermission, mutation: false, exposure: 'in-app', effect: 'read' },
  getEntityStats: { domain: 'read', permissionFor: entityViewPermission, mutation: false, exposure: 'in-app', effect: 'read' },

  // --- Site orientation + owner channel ---
  getSiteContext: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'external-mcp', effect: 'read' },
  messageSiteOwner: { domain: 'meta', mutation: true, audit: 'agent.tool_execute', exposure: 'external-mcp', effect: 'write' },
  // Client feedback to the site's builder: never drafted, but always confirmed — the person sees the whole note and taps Send (F-3).
  send_feedback_to_owner: { domain: 'meta', mutation: true, highRisk: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'write' },

  // --- Pages ---
  getPageBlocks: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'external-mcp', effect: 'read' },
  updateBlock: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'external-mcp', effect: 'draft' },
  insertBlock: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'external-mcp', effect: 'draft' },
  // From the builder chat (Unify AI chats, owner's yes 2026-11-16): drafted to To-do, in the app only.
  removeBlock: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  generateImage: { domain: 'pages', permission: 'media.upload', mutation: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'write' },
  importPageCode: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  moveBlock: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  // The block library (lib/ade/blocks/library, R23): look-ups read the site's own blocks; add/save are drafts.
  find_blocks: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'in-app', effect: 'read' },
  suggest_layouts: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'in-app', effect: 'read' },
  add_block: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  // Saving or changing a saved block affects every page that uses it: managers (publish permission) only.
  save_block: { domain: 'pages', permission: 'pages.publish', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  getSiteLayoutBlocks: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'in-app', effect: 'read' },
  updateSiteLayoutBlock: { domain: 'settings', permission: 'settings.general', mutation: true, highRisk: true, audit: 'site_settings.update', exposure: 'in-app', effect: 'draft' },
  insertSiteLayoutBlock: { domain: 'settings', permission: 'settings.general', mutation: true, highRisk: true, audit: 'site_settings.update', exposure: 'in-app', effect: 'draft' },
  createPage: { domain: 'pages', permission: 'pages.create', mutation: true, audit: 'page.create', exposure: 'external-mcp', effect: 'draft' },
  updatePage: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'external-mcp', effect: 'draft' },
  duplicatePage: { domain: 'pages', permission: 'pages.create', mutation: true, audit: 'page.create', exposure: 'external-mcp', effect: 'draft' },
  deletePage: { domain: 'pages', permission: 'pages.delete', mutation: true, highRisk: true, audit: 'page.delete', exposure: 'in-app', effect: 'irreversible' },
  publishPage: { domain: 'pages', permission: 'pages.publish', mutation: true, highRisk: true, audit: 'page.update', exposure: 'external-mcp', effect: 'draft' },

  // --- Records (ADE: initiatives first) — facts on the record, placements bound ---
  listRecordTypes: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'in-app', effect: 'read' },
  listRecords: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'in-app', effect: 'read' },
  getRecord: { domain: 'read', permission: 'pages.view', mutation: false, exposure: 'in-app', effect: 'read' },
  createRecordWithPage: { domain: 'pages', permission: 'pages.create', mutation: true, audit: 'page.create', exposure: 'in-app', effect: 'draft' },
  updateRecord: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  publishRecord: { domain: 'pages', permission: 'pages.publish', mutation: true, highRisk: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  archiveRecord: { domain: 'pages', permission: 'pages.publish', mutation: true, highRisk: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  overridePlacementField: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },
  resetPlacementField: { domain: 'pages', permission: 'pages.edit', mutation: true, audit: 'page.update', exposure: 'in-app', effect: 'draft' },

  // --- Forms (automations are declarative rules, drafted for review) ---
  // Who may see private areas (lib/ade/governance/access): owner only; changes are always drafted for approval.
  explain_access: { domain: 'settings', permission: 'plugins.install', mutation: false, exposure: 'in-app', effect: 'read' },
  draft_access_change: { domain: 'settings', permission: 'plugins.install', mutation: true, audit: 'permission.grant', exposure: 'in-app', effect: 'draft' },
  getForm: { domain: 'read', permission: 'forms.view', mutation: false, exposure: 'in-app', effect: 'read' },
  listFormSubmissions: { domain: 'read', permission: 'forms.submissions', mutation: false, exposure: 'in-app', effect: 'read' },

  // --- The person's own mailbox (lib/ade/connectors). Labels mirror EMAIL_TOOLS; no `audit`
  //     here (the generic audit row would copy recipients and text) — sends audit themselves, sealed.
  email_search_threads: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_read_thread: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_list_drafts: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_create_draft: { domain: 'email', mutation: true, exposure: 'in-app', effect: 'draft' },
  email_update_draft: { domain: 'email', mutation: true, exposure: 'in-app', effect: 'draft' },
  email_prepare_send: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  // Sending can't be undone: the approval card every time, in every mode.
  email_send_draft: { domain: 'email', mutation: true, highRisk: true, exposure: 'in-app', effect: 'irreversible' },
  // Google's Gmail MCP server, passed through (GOOGLE_GMAIL_MCP=1). Labels mirror GMAIL_MCP_TOOLS.
  email_gmail_search_threads: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_gmail_get_thread: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_gmail_get_message: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_gmail_list_drafts: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },
  email_gmail_list_labels: { domain: 'email', mutation: false, exposure: 'in-app', effect: 'read' },

  setFormAutomations: { domain: 'pages', permission: 'forms.edit', mutation: true, audit: 'form.update', exposure: 'in-app', effect: 'draft' },

  // --- Products ---
  createProduct: { domain: 'products', permission: 'products.create', mutation: true, audit: 'product.create', exposure: 'in-app', effect: 'write' },
  updateProduct: { domain: 'products', permission: 'products.edit', mutation: true, audit: 'product.update', exposure: 'in-app', effect: 'write' },
  manageProductVariant: { domain: 'products', permission: 'products.edit', mutation: true, audit: 'product.update', exposure: 'in-app', effect: 'write' },
  syncProductToStripe: { domain: 'products', permission: 'products.edit', mutation: true, audit: 'product.update', exposure: 'in-app', effect: 'write' },
  deleteProduct: { domain: 'products', permission: 'products.delete', mutation: true, highRisk: true, audit: 'product.delete', exposure: 'in-app', effect: 'irreversible' },

  // --- Blog ---
  createBlogPost: { domain: 'blog', permission: 'blog.create', mutation: true, audit: 'blog.create', exposure: 'external-mcp', effect: 'draft' },
  updateBlogPost: { domain: 'blog', permission: 'blog.edit', mutation: true, audit: 'blog.update', exposure: 'external-mcp', effect: 'draft' },
  manageBlogCategory: { domain: 'blog', permission: 'blog.edit', mutation: true, audit: 'blog.update', exposure: 'external-mcp', effect: 'write' },
  manageBlogTag: { domain: 'blog', permission: 'blog.edit', mutation: true, audit: 'blog.update', exposure: 'external-mcp', effect: 'write' },
  deleteBlogPost: { domain: 'blog', permission: 'blog.delete', mutation: true, highRisk: true, audit: 'blog.delete', exposure: 'in-app', effect: 'irreversible' },
  publishBlogPost: { domain: 'blog', permission: 'blog.publish', mutation: true, highRisk: true, audit: 'blog.publish', exposure: 'external-mcp', effect: 'draft' },

  // --- Orders ---
  updateOrderStatus: { domain: 'orders', permission: 'orders.edit', mutation: true, audit: 'order.update', ...orderCancelGate, exposure: 'in-app', effect: 'write' },
  fulfillOrder: { domain: 'orders', permission: 'orders.fulfill', mutation: true, audit: 'order.fulfill', exposure: 'in-app', effect: 'write' },
  refundOrder: { domain: 'orders', permission: 'orders.refund', mutation: true, highRisk: true, audit: 'order.refund', exposure: 'in-app', effect: 'irreversible' },
  cancelOrder: { domain: 'orders', permission: 'orders.cancel', mutation: true, highRisk: true, audit: 'order.cancel', exposure: 'in-app', effect: 'irreversible' },

  // --- Settings (all high-risk) ---
  updateSettings: { domain: 'settings', permission: 'settings.general', mutation: true, highRisk: true, audit: 'settings.update', exposure: 'in-app', effect: 'write' },
  updateBrandingSettings: { domain: 'settings', permission: 'settings.general', mutation: true, highRisk: true, audit: 'site_settings.update', exposure: 'in-app', effect: 'write' },
  updateSiteSettings: { domain: 'settings', permission: 'settings.general', mutation: true, highRisk: true, audit: 'site_settings.update', exposure: 'in-app', effect: 'write' },

  // --- Help content (help domain; reads free for staff, writes need settings.general and are audited) ---
  listHelpKeys: { domain: 'help', mutation: false, exposure: 'in-app', effect: 'read' },
  getHelpContent: { domain: 'help', mutation: false, exposure: 'in-app', effect: 'read' },
  scanForMissingHelp: { domain: 'help', mutation: false, exposure: 'in-app', effect: 'read' },
  reviewOrphanedHelp: { domain: 'help', mutation: false, exposure: 'in-app', effect: 'read' },
  updateHelpContent: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'help.update', exposure: 'in-app', effect: 'write' },
  batchGenerateHelp: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'help.update', exposure: 'in-app', effect: 'write' },
  generateEntityHelp: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'help.update', exposure: 'in-app', effect: 'write' },
  markHelpOrphaned: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'help.update', exposure: 'in-app', effect: 'write' },
  manageHelpStatus: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'help.update', exposure: 'in-app', effect: 'write' },
  purgeDeletedHelp: { domain: 'help', permission: 'settings.general', mutation: true, highRisk: true, audit: 'help.update', exposure: 'in-app', effect: 'irreversible' },

  // --- Walkthroughs / guided tours ---
  suggestWalkthroughs: { domain: 'help', mutation: false, exposure: 'in-app', effect: 'read' },
  listWalkthroughs: { domain: 'help', mutation: false, exposure: 'in-app', effect: 'read' },
  explainElement: { domain: 'meta', mutation: false, writesWhen: (i) => !!(i as { saveAsHelp?: unknown; suggestWalkthrough?: unknown } | null)?.saveAsHelp || !!(i as { suggestWalkthrough?: unknown } | null)?.suggestWalkthrough, exposure: 'in-app', effect: 'read' },
  highlightElement: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  startWalkthrough: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  startGuidedExplanation: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  generateWalkthrough: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'tour.create', exposure: 'in-app', effect: 'write' },
  createHelpContent: { domain: 'help', permission: 'settings.general', mutation: true, audit: 'help.update', exposure: 'in-app', effect: 'write' },

  // --- Platform (nav customization, initiatives, forms) ---
  describe_platform: { domain: 'meta', mutation: false, exposure: 'in-app', effect: 'read' },
  listNavigationTabs: { domain: 'read', permission: 'settings.view', mutation: false, exposure: 'external-mcp', effect: 'read' },
  customizeNavigationTab: { domain: 'settings', permission: 'settings.general', mutation: true, audit: 'settings.update', exposure: 'in-app', effect: 'write' },
  listInitiatives: { domain: 'read', permission: 'blog.view', mutation: false, exposure: 'external-mcp', effect: 'read' },
  setFeaturedInitiatives: { domain: 'blog', permission: 'blog.edit', mutation: true, audit: 'settings.update', exposure: 'external-mcp', effect: 'draft' },
  listForms: { domain: 'read', permission: 'forms.view', mutation: false, exposure: 'external-mcp', effect: 'read' },
  setFormDisplay: { domain: 'settings', permission: 'settings.general', mutation: true, audit: 'settings.update', exposure: 'in-app', effect: 'write' },

  // --- vMCP management (DB-stored tool code). Only offered while a super
  // admin has enabled DB code execution (Admin → To-do → Assistant settings); the
  // DB-defined tools themselves are dynamic → labelled DYNAMIC_TOOL_LABELS.
  vmcp_list_tools: { domain: 'read', permission: 'plugins.view', mutation: false, exposure: 'in-app', effect: 'read' },
  vmcp_search_tools: { domain: 'read', permission: 'plugins.view', mutation: false, exposure: 'in-app', effect: 'read' },
  vmcp_get_tool: { domain: 'read', permission: 'plugins.view', mutation: false, exposure: 'in-app', effect: 'read' },
  vmcp_stats: { domain: 'read', permission: 'plugins.view', mutation: false, exposure: 'in-app', effect: 'read' },
  vmcp_create_tool: { domain: 'settings', permission: 'plugins.configure', mutation: true, highRisk: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'write' },
  vmcp_iterate_tool: { domain: 'settings', permission: 'plugins.configure', mutation: true, highRisk: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'write' },
  vmcp_mount_tool: { domain: 'settings', permission: 'plugins.configure', mutation: true, highRisk: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'write' },
  vmcp_dismount_tool: { domain: 'settings', permission: 'plugins.configure', mutation: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'write' },
  vmcp_test_tool: { domain: 'settings', permission: 'plugins.configure', mutation: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'irreversible' },
  vmcp_delete_tool: { domain: 'settings', permission: 'plugins.delete', mutation: true, highRisk: true, audit: 'agent.tool_execute', exposure: 'in-app', effect: 'irreversible' },
}

const withSources = withUntrustedSources(BASE_REGISTRY, UNTRUSTED_SOURCES)
// Money tools always ask (lib/ade/ui/control withMoneyRules on the app's list).
const withMoney = withMoneyRules(withSources.registry, MONEY_TOOLS)
export const TOOL_REGISTRY: Record<string, ToolMeta> = withMoney.registry
/** Names in MONEY_TOOLS that aren't registered tools (asserted empty). */
export const UNKNOWN_MONEY_TOOLS: readonly string[] = withMoney.unknown
/** Names in UNTRUSTED_SOURCES that aren't registered tools (asserted empty). */
export const UNKNOWN_UNTRUSTED_SOURCES: readonly string[] = withSources.unknown

/** What the guard assumes of an unregistered (vMCP / external MCP) tool: its output is never trusted. */
export const DYNAMIC_TOOL_META: Pick<ToolMeta, 'untrustedSource'> = { untrustedSource: true }

/** Pseudo-domains that are never subject to the admin domain allowlist. */
// 'email' is the person's own mailbox: the tools only exist once THEY connected it (lib/ai/tools/email-tools).
const UNGATED_DOMAINS = new Set<AgentToolDomain>(['read', 'meta', 'navigation', 'email'])

export function isAllowlistGatedDomain(domain: AgentToolDomain): boolean {
  return !UNGATED_DOMAINS.has(domain)
}

/**
 * Labels for tools NOT in the registry (DB-defined vMCP tools, tools from
 * external MCP servers). Their effect is unknown, so they are treated as
 * irreversible: chat-only, explicit approval on every call, never over MCP.
 */
export const DYNAMIC_TOOL_LABELS: CapabilityLabels = { exposure: 'in-app', effect: 'irreversible' }

/** Labels of a registered tool; unknown names fail closed. */
export function labelsOf(name: string): CapabilityLabels {
  const meta = Object.hasOwn(TOOL_REGISTRY, name) ? TOOL_REGISTRY[name] : undefined
  return meta ? { exposure: meta.exposure, effect: meta.effect } : UNKNOWN_LABELS
}

/**
 * Tools that exist ONLY on the MCP endpoint (registered straight on the MCP
 * server in src/app/mcp/route.ts and src/lib/mcp/tools/*), with their
 * labels. They are not agent tools, but they ARE capabilities an external
 * client can call, so they are labelled like everything else and the MCP
 * server refuses to publish any name the generated list does not contain.
 *
 * internal (not published):
 *   create_blog_post     — writes past the review queue; createBlogPost
 *                          (governed, drafts in draft mode) replaces it
 *   scan_project /       — read arbitrary paths on the SERVER's filesystem;
 *   import_from_project    meaningful only for a local CLI, not a hosted MCP
 */
export const MCP_NATIVE_TOOLS: Readonly<Record<string, CapabilityLabels>> = {
  list_products: { exposure: 'external-mcp', effect: 'read' },
  get_product: { exposure: 'external-mcp', effect: 'read' },
  list_orders: { exposure: 'external-mcp', effect: 'read' },
  get_order: { exposure: 'external-mcp', effect: 'read' },
  list_blog_posts: { exposure: 'external-mcp', effect: 'read' },
  get_blog_post: { exposure: 'external-mcp', effect: 'read' },
  create_blog_post: { exposure: 'internal', effect: 'write' },
  list_pages: { exposure: 'external-mcp', effect: 'read' },
  get_page: { exposure: 'external-mcp', effect: 'read' },
  get_settings: { exposure: 'external-mcp', effect: 'read' },
  update_setting: { exposure: 'external-mcp', effect: 'write' },
  list_media: { exposure: 'external-mcp', effect: 'read' },
  list_users: { exposure: 'external-mcp', effect: 'read' },
  get_analytics_summary: { exposure: 'external-mcp', effect: 'read' },
  list_customers: { exposure: 'external-mcp', effect: 'read' },
  get_customer: { exposure: 'external-mcp', effect: 'read' },
  scan_project: { exposure: 'internal', effect: 'read' },
  import_from_project: { exposure: 'internal', effect: 'write' },
  request_media_upload: { exposure: 'external-mcp', effect: 'write' },
  confirm_media_upload: { exposure: 'external-mcp', effect: 'write' },
  search_media: { exposure: 'external-mcp', effect: 'read' },
  upload_media_from_url: { exposure: 'external-mcp', effect: 'write' },
  screenshot_page: { exposure: 'external-mcp', effect: 'write' },
}

/** Governed agent tools published over MCP (registered by registry-adapter). */
export const EXTERNAL_AGENT_TOOLS: readonly string[] = externalToolNames(TOOL_REGISTRY)

/**
 * Every tool name the MCP endpoint may publish — generated from labels,
 * never hand-listed, so an in-app or internal capability can't leak out.
 */
export const EXTERNAL_MCP_TOOLS: readonly string[] = [
  ...EXTERNAL_AGENT_TOOLS,
  ...externalToolNames(MCP_NATIVE_TOOLS),
].sort()

/**
 * Labels of a composite (a workflow, a button) from its step tool names:
 * the most restrictive of its steps; an unregistered step fails closed.
 */
export function labelsForComposite(stepToolNames: ReadonlyArray<string>): CapabilityLabels {
  return compositeLabels(
    stepToolNames.map((n) => (Object.hasOwn(TOOL_REGISTRY, n) ? labelsOf(n) : undefined))
  )
}
