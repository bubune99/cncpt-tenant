/**
 * Agent modes — what the person sees as one switch: Look only / Accept changes / Auto.
 * Pure and asserted by agent-modes.assert.ts. This is the SETTINGS layer only: it
 * turns a mode into the (executionMode, changeMode) pair the ADE dispatcher
 * already understands (lib/ade/capabilities/dispatch.ts decideDispatch is not
 * touched), per tool, on the server, on every request.
 *
 *   Look only        executionMode 'readonly'
 *   Accept changes   executionMode 'ask'  + changeMode 'draft'   (the default)
 *   Auto             executionMode 'auto' + changeMode 'direct'
 *
 * What holds in EVERY mode (the dispatcher and the registry's gates still run
 * on top of this): irreversible effects ask, the money gate (alwaysAskWhen)
 * asks, outside text taints the run so every change asks, unknown labels ask.
 * This file adds the rules that belong to Auto itself: it needs undo, it is
 * bounded per run, and it only ever applies where an admin allowed it.
 */

export type AgentMode = 'readonly' | 'ask' | 'auto'
export type ModeChangeMode = 'draft' | 'direct'

export const AGENT_MODES: readonly AgentMode[] = ['readonly', 'ask', 'auto']
const RANK: Record<AgentMode, number> = { readonly: 0, ask: 1, auto: 2 }

/** What people call each mode. */
export const MODE_LABEL: Record<AgentMode, string> = { readonly: 'Look only', ask: 'Accept changes', auto: 'Auto' }
export const MODE_HINT: Record<AgentMode, string> = {
  readonly: 'The assistant reads and points, and never changes anything.',
  ask: 'The assistant proposes; you accept or reject each change.',
  auto: 'Safe, reversible changes apply straight away, each with an Undo. Anything that cannot be undone still asks first.',
}

export const isAgentMode = (v: unknown): v is AgentMode => v === 'readonly' || v === 'ask' || v === 'auto'
export const modeRank = (m: AgentMode): number => RANK[m]
export const lowerMode = (a: AgentMode, b: AgentMode): AgentMode => (RANK[a] <= RANK[b] ? a : b)
export const higherMode = (a: AgentMode, b: AgentMode): AgentMode => (RANK[a] >= RANK[b] ? a : b)

/** The tool domains an admin can set a mode for (ToolMeta.domain of the changing tools). Dzidzor: no campaigns domain. */
export const MODE_TARGETS = ['pages', 'products', 'orders', 'blog', 'settings', 'help'] as const
export type ModeTarget = (typeof MODE_TARGETS)[number]

/**
 * The targets that can be set to Auto: the ones whose changes are versions Undo can restore (see
 * AUTO_UNDOABLE_TOOLS). Dzidzor: products and orders have no revision history (and every status change
 * asks anyway), settings are high-risk, help has no history: they stay Accept changes.
 */
export const AUTO_CAPABLE_TARGETS: readonly ModeTarget[] = ['pages', 'blog']

export interface AgentModeSettings {
  /**
   * Off (never saved): the assistant runs exactly as it did before this existed (the stored agent
   * executionMode and the Assistant "review" switch), and the composer shows no switch. On: the three modes
   * below apply, and the safe defaults (Accept changes) hold until an owner raises them.
   */
  enabled: boolean
  /** Where a person starts, until they pick (clamped to their ceiling). */
  defaultMode: AgentMode
  /** The ceiling for anyone whose roles are not listed in roleMaxMode. */
  maxMode: AgentMode
  /** The ceiling per role name; a person holding several roles gets the highest of those that are listed. */
  roleMaxMode: Record<string, AgentMode>
  /** A ceiling per target (tool domain). A target not listed is Accept changes. */
  targetModes: Partial<Record<ModeTarget, AgentMode>>
  /** Changes Auto may apply in one run; past it the run stops and asks. */
  maxAutoChanges: number
  /** Decision 1: true = the person picks within the ceiling (recommended); false = only the default applies. */
  personPicks: boolean
  /** Decision 2: true = in Auto small edits apply live (Publish still asks); false = they wait as drafts. */
  autoLiveEdits: boolean
}

export const DEFAULT_MAX_AUTO_CHANGES = 10

export const DEFAULT_AGENT_MODE_SETTINGS: AgentModeSettings = {
  enabled: false,
  defaultMode: 'ask',
  maxMode: 'ask',
  roleMaxMode: {},
  targetModes: {},
  maxAutoChanges: DEFAULT_MAX_AUTO_CHANGES,
  personPicks: true,
  autoLiveEdits: true,
}

const isTarget = (k: string): k is ModeTarget => (MODE_TARGETS as readonly string[]).includes(k)
const isPlain = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v)

/** Stored (untrusted) → settings; anything unrecognised falls back to the safe default. */
export function normalizeModeSettings(raw: unknown): AgentModeSettings {
  const d = DEFAULT_AGENT_MODE_SETTINGS
  const r = isPlain(raw) ? raw : {}
  const mode = (v: unknown, fallback: AgentMode): AgentMode => (isAgentMode(v) ? v : fallback)
  const roleMaxMode: Record<string, AgentMode> = {}
  if (isPlain(r.roleMaxMode)) {
    for (const [role, m] of Object.entries(r.roleMaxMode)) if (role.length > 0 && role.length <= 80 && isAgentMode(m)) roleMaxMode[role] = m
  }
  const targetModes: Partial<Record<ModeTarget, AgentMode>> = {}
  if (isPlain(r.targetModes)) {
    for (const [target, m] of Object.entries(r.targetModes)) {
      // No working undo, no Auto: a stored 'auto' on such a target reads as Accept changes.
      if (isTarget(target) && isAgentMode(m)) targetModes[target] = m === 'auto' && !AUTO_CAPABLE_TARGETS.includes(target) ? 'ask' : m
    }
  }
  const n = Number(r.maxAutoChanges)
  return {
    enabled: r.enabled === true,
    defaultMode: mode(r.defaultMode, d.defaultMode),
    maxMode: mode(r.maxMode, d.maxMode),
    roleMaxMode,
    targetModes,
    maxAutoChanges: Number.isInteger(n) && n >= 1 && n <= 100 ? n : d.maxAutoChanges,
    personPicks: r.personPicks !== false,
    autoLiveEdits: r.autoLiveEdits !== false,
  }
}

/** The most this person may use: the highest ceiling among their listed roles, else the general ceiling. */
export function ceilingFor(settings: AgentModeSettings, roles: readonly string[]): AgentMode {
  const listed = roles.flatMap((r) => (Object.hasOwn(settings.roleMaxMode, r) ? [settings.roleMaxMode[r]] : []))
  return listed.length > 0 ? listed.reduce(higherMode) : settings.maxMode
}

export interface ResolvedMode {
  /** Off: nothing here applies; the pre-modes behaviour runs and the composer shows no switch. */
  legacy: boolean
  /** The person's mode for this request (their ceiling already applied). */
  mode: AgentMode
  ceiling: AgentMode
  /** The modes the switch offers: never one above the ceiling. */
  offered: AgentMode[]
  /** Why this mode: the person's own pick, or the admin default. */
  source: 'default' | 'chosen'
}

/**
 * The person's mode for one request. `requested` is whatever the client sent
 * (this conversation's switch) and `saved` their remembered pick: both are
 * only ever a CHOICE, clamped to the ceiling here, never the authority.
 */
export function resolveMode(input: { settings: AgentModeSettings; roles: readonly string[]; requested?: unknown; saved?: unknown }): ResolvedMode {
  const { settings } = input
  const ceiling = ceilingFor(settings, input.roles)
  const offered = AGENT_MODES.filter((m) => RANK[m] <= RANK[ceiling])
  if (!settings.enabled) return { legacy: true, mode: 'ask', ceiling, offered: [], source: 'default' }
  const choice = settings.personPicks ? [input.requested, input.saved].find(isAgentMode) : undefined
  const mode = lowerMode(choice ?? settings.defaultMode, ceiling)
  return { legacy: false, mode, ceiling, offered, source: choice !== undefined ? 'chosen' : 'default' }
}

// ── Auto needs undo ──────────────────────────────────────────────────

/**
 * The changing tools Auto may run without asking: each one saves through a
 * history chokepoint, so the change is a version with its exact previous
 * values, and Undo can put them back. Dzidzor: updateBlock / insertBlock
 * snapshot the page first (PageRevision, block-tools savePageContent);
 * updateBlogPost wraps its write in withPostHistory. A tool NOT listed here
 * asks in Auto exactly as in Accept changes — no revision history, no Auto
 * (updatePage is not listed: a title / address edit takes no page snapshot).
 * The value narrows a tool by its input (false = this call asks).
 */
export const AUTO_UNDOABLE_TOOLS: Readonly<Record<string, (input: unknown) => boolean>> = {
  // Pages — edits to one block. Publishing is never Auto (publishPage is high-risk and asks).
  updateBlock: () => true,
  insertBlock: () => true,
  // Blog — editing a post's fields (publishBlogPost is a separate, high-risk tool).
  updateBlogPost: () => true,
}

export const autoUndoable = (toolName: string): boolean => Object.hasOwn(AUTO_UNDOABLE_TOOLS, toolName)

/** Does this one CALL of an Auto tool have to ask (the tool is undoable only for some inputs)? */
export function autoCallAsks(toolName: string, input: unknown): boolean {
  if (!Object.hasOwn(AUTO_UNDOABLE_TOOLS, toolName)) return true
  try {
    return !AUTO_UNDOABLE_TOOLS[toolName](input)
  } catch {
    return true
  }
}

// ── Per tool ─────────────────────────────────────────────────────────

export interface ToolRuntime {
  /** The mode this tool runs under, as the person sees it (recorded in the audit row). */
  mode: AgentMode
  /** What the dispatcher is given. */
  executionMode: AgentMode
  changeMode: ModeChangeMode
  /** Why a higher mode was held back for this tool, if it was. */
  heldBack?: 'target' | 'no-undo' | 'drafts-only'
}

/**
 * The mode one tool runs under: the person's mode, lowered to the target's
 * ceiling (a target not listed is Accept changes), and lowered again when
 * the tool has no undo. Auto = 'auto' + 'direct'; Accept = 'ask' + 'draft'.
 */
export function toolRuntime(input: { settings: AgentModeSettings; person: AgentMode; toolName: string; target: string; effect: string; canDraft: boolean }): ToolRuntime {
  const { settings, person } = input
  if (person === 'readonly') return { mode: 'readonly', executionMode: 'readonly', changeMode: 'draft' }
  const targetCeiling = isTarget(input.target) ? (settings.targetModes[input.target] ?? 'ask') : 'ask'
  let mode = lowerMode(person, targetCeiling)
  let heldBack: ToolRuntime['heldBack']
  if (mode !== person) heldBack = 'target'
  if (mode === 'auto' && !autoUndoable(input.toolName)) {
    mode = 'ask'
    heldBack = 'no-undo'
  }
  if (mode === 'auto' && !settings.autoLiveEdits) {
    // Decision 2, the other way: Auto edits wait as drafts. A tool that cannot be drafted would apply live, so it asks.
    if (input.effect === 'draft' && input.canDraft) return { mode, executionMode: 'auto', changeMode: 'draft', heldBack: 'drafts-only' }
    mode = 'ask'
    heldBack = 'drafts-only'
  }
  return mode === 'auto' ? { mode, executionMode: 'auto', changeMode: 'direct' } : { mode, executionMode: mode, changeMode: 'draft', ...(heldBack ? { heldBack } : {}) }
}

// ── Bounded per run ──────────────────────────────────────────────────

/** The one plain sentence the person sees when Auto reaches its limit. */
export const pausedSentence = (limit: number): string =>
  `I've made ${limit} changes on my own in this run, so I'm pausing here. Tell me to carry on and I'll do the next batch, or switch to Accept changes.`

export interface AutoBudget {
  readonly limit: number
  readonly used: number
  /** Count one change applied without asking; false once the limit is spent (the change must not run). */
  take(): boolean
}

export function createAutoBudget(limit: number, used = 0): AutoBudget {
  let n = used
  return {
    limit,
    get used() {
      return n
    },
    take() {
      if (n >= limit) return false
      n++
      return true
    },
  }
}

// ── Who may loosen the settings ──────────────────────────────────────

/** Did `next` give the assistant more freedom than `prev`? Loosening is the owner's decision (a super admin). */
export function loosensModes(prev: AgentModeSettings, next: AgentModeSettings): boolean {
  if (prev.enabled && !next.enabled) return true // back to the pre-modes behaviour, which is Auto-like
  if (RANK[next.defaultMode] > RANK[prev.defaultMode] || RANK[next.maxMode] > RANK[prev.maxMode]) return true
  for (const [role, m] of Object.entries(next.roleMaxMode)) if (RANK[m] > RANK[prev.roleMaxMode[role] ?? prev.maxMode]) return true
  for (const target of MODE_TARGETS) if (RANK[next.targetModes[target] ?? 'ask'] > RANK[prev.targetModes[target] ?? 'ask']) return true
  if (next.maxAutoChanges > prev.maxAutoChanges) return true
  if (next.autoLiveEdits && !prev.autoLiveEdits) return true
  if (next.personPicks && !prev.personPicks) return true
  return false
}
