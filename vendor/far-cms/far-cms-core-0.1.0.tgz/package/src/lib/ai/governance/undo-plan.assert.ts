/**
 * Undo of one recorded change: exactly the fields it changed, back to their old values.
 * Run: npx -y tsx@4.23.15 src/lib/ai/governance/undo-plan.assert.ts
 */
import assert from 'node:assert/strict'
import { planRestore, selectRestore, SECRET_MARK, type RestorePolicy } from '../../ade/history'
import { undoNotes, undoState } from './undo-plan'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const policy: RestorePolicy = { schemaVersion: 1, fields: { title: { class: 'restorable', type: 'string' }, price: { class: 'restorable', type: 'number' }, status: { class: 'guarded', type: 'string', consequence: 'goes live' } } }
const rev = { changed: ['title', 'price'], before: { title: 'Old title', price: 20 }, after: { title: 'New title', price: 24 } }

check('undo restores the exact previous values of the changed fields, nothing else', () => {
  const current = { title: 'New title', price: 24, status: 'ACTIVE', other: 1 }
  const st = undoState(current, rev)
  assert.deepEqual(st.fields, ['title', 'price'])
  assert.deepEqual(st.target, { title: 'Old title', price: 20, status: 'ACTIVE', other: 1 })
  assert.deepEqual(st.conflicts, [])
  const plan = planRestore({ policy, current, target: st.target, fromVersion: 0, targetSchemaVersion: 1, changedSince: new Set(st.conflicts) })
  const sel = selectRestore(plan, plan.fields.filter((f) => f.selected).map((f) => f.field))
  assert.deepEqual(sel.patch, { title: 'Old title', price: 20 }, 'the old values, exactly, and only those fields')
})

check('a field changed again since is a conflict: left alone, never overwritten', () => {
  const current = { title: 'Edited by Ama', price: 24 }
  const st = undoState(current, rev)
  assert.deepEqual(st.conflicts, ['title'])
  const plan = planRestore({ policy, current, target: st.target, fromVersion: 0, targetSchemaVersion: 1, changedSince: new Set(st.conflicts) })
  const sel = selectRestore(plan, plan.fields.filter((f) => f.selected).map((f) => f.field))
  assert.deepEqual(sel.patch, { price: 20 })
  assert.ok(sel.skipped.some((s) => s.field === 'title'))
  assert.ok(undoNotes(st, sel.skipped).some((x) => x.startsWith('title')))
})

check('already undone: nothing to do; secrets are never undone; ignored fields are skipped', () => {
  const back = undoState({ title: 'Old title', price: 20 }, rev)
  assert.deepEqual(back.fields, [])
  assert.deepEqual(back.alreadyBack, ['title', 'price'])
  const sec = undoState({ apiKey: 'x' }, { changed: ['apiKey'], before: { apiKey: SECRET_MARK }, after: { apiKey: SECRET_MARK } })
  assert.deepEqual(sec.fields, [])
  assert.deepEqual(sec.secret, ['apiKey'])
  assert.ok(undoNotes(sec, []).length > 0)
  assert.deepEqual(undoState({ updatedAt: 2, title: 'New title' }, { changed: ['updatedAt', 'title'], before: { updatedAt: 1, title: 'Old title' }, after: { updatedAt: 2, title: 'New title' } }, new Set(['updatedAt'])).fields, ['title'])
})

check('key order and undefined keys do not look like a conflict (editors reorder JSON)', () => {
  const r = { changed: ['content'], before: { content: { b: 1, a: 2 } }, after: { content: { a: 3, b: 1 } } }
  assert.deepEqual(undoState({ content: { b: 1, a: 3, extra: undefined } }, r).conflicts, [])
})

check('a guarded field is listed but not ticked: the one-click undo does not publish by itself', () => {
  const current = { status: 'PUBLISHED' }
  const st = undoState(current, { changed: ['status'], before: { status: 'DRAFT' }, after: { status: 'PUBLISHED' } })
  const plan = planRestore({ policy, current, target: st.target, fromVersion: 0, targetSchemaVersion: 1, changedSince: new Set() })
  assert.equal(plan.fields[0].selected, false)
})

console.log(`\n${n} checks passed`)
