/**
 * Look only / Accept changes / Auto: the pure rules.
 * Run: npx -y tsx@4.23.15 src/lib/ai/governance/agent-modes.assert.ts
 */
import assert from 'node:assert/strict'
import {
  AUTO_CAPABLE_TARGETS,
  AUTO_UNDOABLE_TOOLS,
  DEFAULT_AGENT_MODE_SETTINGS,
  MODE_TARGETS,
  autoCallAsks,
  ceilingFor,
  createAutoBudget,
  loosensModes,
  normalizeModeSettings,
  pausedSentence,
  resolveMode,
  toolRuntime,
  type AgentModeSettings,
} from './agent-modes'
import { TOOL_REGISTRY } from './tool-registry'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const on = (over: Partial<AgentModeSettings> = {}): AgentModeSettings => ({ ...DEFAULT_AGENT_MODE_SETTINGS, enabled: true, ...over })

check('safe defaults: off (the assistant works as before), and once on every default is Accept changes', () => {
  const d = DEFAULT_AGENT_MODE_SETTINGS
  assert.equal(d.enabled, false)
  assert.equal(d.defaultMode, 'ask')
  assert.equal(d.maxMode, 'ask')
  assert.deepEqual(d.roleMaxMode, {})
  assert.deepEqual(d.targetModes, {})
  assert.equal(d.maxAutoChanges, 10)
  assert.equal(d.personPicks, true, 'decision 1: the person picks, within the ceiling')
  assert.equal(d.autoLiveEdits, true, 'decision 2: small edits apply live, Publish still asks')
  assert.deepEqual(normalizeModeSettings(undefined), d)
  assert.deepEqual(normalizeModeSettings('nonsense'), d)
  assert.deepEqual(normalizeModeSettings({ enabled: true }), { ...d, enabled: true })
})

check('switched off: legacy, and the switch offers nothing', () => {
  const r = resolveMode({ settings: DEFAULT_AGENT_MODE_SETTINGS, roles: ['admin'], requested: 'auto' })
  assert.equal(r.legacy, true)
  assert.deepEqual(r.offered, [])
})

check('a client-sent mode above the ceiling is ignored', () => {
  const r = resolveMode({ settings: on(), roles: ['admin'], requested: 'auto' })
  assert.equal(r.mode, 'ask', 'asked for Auto, the ceiling is Accept changes')
  assert.equal(r.ceiling, 'ask')
  assert.deepEqual(r.offered, ['readonly', 'ask'], 'an unavailable mode is not offered')
  assert.equal(resolveMode({ settings: on(), roles: [], saved: 'auto' }).mode, 'ask', 'a remembered Auto is clamped too')
  assert.equal(resolveMode({ settings: on(), roles: [], requested: 'readonly' }).mode, 'readonly', 'going down is always allowed')
  for (const bad of ['AUTO', 'yes', 3, null, {}, '']) assert.equal(resolveMode({ settings: on({ maxMode: 'auto' }), roles: [], requested: bad }).mode, 'ask', `${JSON.stringify(bad)} is not a mode`)
})

check('the person picks within the ceiling; an admin default is the start', () => {
  const s = on({ maxMode: 'auto', defaultMode: 'ask' })
  assert.equal(resolveMode({ settings: s, roles: [] }).mode, 'ask')
  assert.equal(resolveMode({ settings: s, roles: [] }).source, 'default')
  const r = resolveMode({ settings: s, roles: [], requested: 'auto' })
  assert.equal(r.mode, 'auto')
  assert.equal(r.source, 'chosen')
  assert.equal(resolveMode({ settings: s, roles: [], requested: 'bogus', saved: 'readonly' }).mode, 'readonly', 'a bad request falls back to the remembered pick')
  // The default itself is clamped: a default above the ceiling cannot be reached.
  assert.equal(resolveMode({ settings: on({ defaultMode: 'auto', maxMode: 'ask' }), roles: [] }).mode, 'ask')
})

check('decision 1 flipped: admins only — the person’s pick is ignored', () => {
  const s = on({ maxMode: 'auto', defaultMode: 'ask', personPicks: false })
  const r = resolveMode({ settings: s, roles: [], requested: 'auto', saved: 'auto' })
  assert.equal(r.mode, 'ask')
  assert.equal(r.source, 'default')
})

check('ceilings by role: the highest listed role wins; unlisted roles use the general ceiling', () => {
  const s = on({ maxMode: 'ask', roleMaxMode: { editor: 'readonly', super_admin: 'auto' } })
  assert.equal(ceilingFor(s, ['editor']), 'readonly')
  assert.equal(ceilingFor(s, ['editor', 'super_admin']), 'auto')
  assert.equal(ceilingFor(s, ['someone-else']), 'ask')
  assert.equal(ceilingFor(s, []), 'ask')
  assert.equal(resolveMode({ settings: s, roles: ['editor'], requested: 'ask' }).mode, 'readonly')
  assert.equal(resolveMode({ settings: s, roles: ['super_admin'], requested: 'auto' }).mode, 'auto')
})

check('a tampered or old settings blob can never raise anything', () => {
  const r = normalizeModeSettings({ enabled: 'yes', defaultMode: 'turbo', maxMode: 7, roleMaxMode: { a: 'turbo', b: 'auto', '': 'auto' }, targetModes: { pages: 'auto', orders: 'auto', products: 'auto', unknown: 'auto' }, maxAutoChanges: 5000, personPicks: 'no' })
  assert.equal(r.enabled, false)
  assert.equal(r.defaultMode, 'ask')
  assert.equal(r.maxMode, 'ask')
  assert.deepEqual(r.roleMaxMode, { b: 'auto' })
  assert.deepEqual(r.targetModes, { pages: 'auto', orders: 'ask', products: 'ask' }, 'a target with no undo cannot be Auto (Dzidzor products have no history); unknown targets drop')
  assert.equal(r.maxAutoChanges, 10)
  assert.equal(normalizeModeSettings({ maxAutoChanges: 3 }).maxAutoChanges, 3)
})

check('per tool: the target caps the person; a target not listed is Accept changes', () => {
  const s = on({ maxMode: 'auto', targetModes: { blog: 'auto', orders: 'ask' } })
  const rt = (toolName: string, target: string, person: 'readonly' | 'ask' | 'auto' = 'auto', effect = 'write') => toolRuntime({ settings: s, person, toolName, target, effect, canDraft: false })
  assert.deepEqual(rt('updateBlogPost', 'blog', 'auto', 'draft'), { mode: 'auto', executionMode: 'auto', changeMode: 'direct' }, 'Auto = auto + direct')
  assert.equal(rt('updateOrderStatus', 'orders').mode, 'ask', 'orders stay Accept changes')
  assert.equal(rt('updateBlock', 'pages', 'auto', 'draft').mode, 'ask', 'pages is not listed: Accept changes')
  assert.equal(rt('updateBlock', 'pages', 'auto', 'draft').heldBack, 'target')
  assert.equal(rt('updateBlogPost', 'blog', 'ask').mode, 'ask')
  assert.deepEqual(rt('updateBlogPost', 'blog', 'ask'), { mode: 'ask', executionMode: 'ask', changeMode: 'draft' }, 'Accept changes = ask + draft')
  assert.deepEqual(rt('updateBlogPost', 'blog', 'readonly'), { mode: 'readonly', executionMode: 'readonly', changeMode: 'draft' }, 'Look only = readonly')
  assert.equal(rt('newTool', 'brand-new-target').mode, 'ask', 'a new target defaults to the safest mode')
})

check('Auto needs undo: a tool with no revision history asks in Auto', () => {
  const s = on({ maxMode: 'auto', targetModes: { pages: 'auto', blog: 'auto' } })
  const rt = (toolName: string, target: string) => toolRuntime({ settings: s, person: 'auto', toolName, target, effect: 'write', canDraft: false })
  assert.equal(rt('updatePage', 'pages').mode, 'ask', 'a title / address edit takes no snapshot')
  assert.equal(rt('updatePage', 'pages').heldBack, 'no-undo')
  assert.equal(rt('createPage', 'pages').mode, 'ask', 'a create has nothing to put back')
  assert.equal(rt('add_block', 'pages').mode, 'ask')
  assert.equal(rt('manageBlogCategory', 'blog').mode, 'ask')
  assert.equal(rt('updateBlock', 'pages').mode, 'auto')
  assert.equal(rt('insertBlock', 'pages').mode, 'auto')
  assert.equal(rt('updateBlogPost', 'blog').mode, 'auto')
  // products are not Auto-capable here: even a stored 'auto' reads as Accept changes.
  const p = normalizeModeSettings({ ...s, targetModes: { products: 'auto' } })
  assert.equal(toolRuntime({ settings: p, person: 'auto', toolName: 'updateProduct', target: 'products', effect: 'write', canDraft: false }).mode, 'ask')
})

check('every Auto tool is a registered changing tool on an Auto-capable target, never irreversible, never the money/order/mail tools', () => {
  for (const name of Object.keys(AUTO_UNDOABLE_TOOLS)) {
    const meta = TOOL_REGISTRY[name]
    assert.ok(meta, `${name} is registered`)
    assert.equal(meta.mutation, true, name)
    assert.notEqual(meta.effect, 'irreversible', name)
    assert.ok((AUTO_CAPABLE_TARGETS as readonly string[]).includes(meta.domain), `${name} is on ${meta.domain}`)
    assert.notEqual(meta.highRisk, true, `${name} is not high-risk`)
  }
  for (const target of AUTO_CAPABLE_TARGETS) assert.ok((MODE_TARGETS as readonly string[]).includes(target))
  for (const never of ['deleteProduct', 'deletePage', 'publishPage', 'publishBlogPost', 'publishRecord', 'deleteBlogPost', 'refundOrder', 'cancelOrder', 'fulfillOrder', 'updateOrderStatus', 'updateProduct', 'manageProductVariant', 'email_send_draft', 'updateSettings', 'updateSiteSettings', 'updateSiteLayoutBlock']) {
    assert.equal(Object.hasOwn(AUTO_UNDOABLE_TOOLS, never), false, never)
  }
})

check('Auto per call: only the listed tools run without asking; anything else asks', () => {
  assert.equal(autoCallAsks('updateBlock', { page: 'home', blockId: 'b1' }), false)
  assert.equal(autoCallAsks('updatePage', { id: 'p', status: 'PUBLISHED' }), true)
  assert.equal(autoCallAsks('updateProduct', { id: 'p' }), true)
  assert.equal(autoCallAsks('somethingUnknown', {}), true)
})

check('decision 2 flipped: Auto edits wait as drafts where they can be drafted, otherwise ask', () => {
  const s = on({ maxMode: 'auto', autoLiveEdits: false, targetModes: { pages: 'auto', blog: 'auto' } })
  assert.deepEqual(toolRuntime({ settings: s, person: 'auto', toolName: 'updateBlock', target: 'pages', effect: 'draft', canDraft: true }), { mode: 'auto', executionMode: 'auto', changeMode: 'draft', heldBack: 'drafts-only' })
  assert.equal(toolRuntime({ settings: s, person: 'auto', toolName: 'updateBlock', target: 'pages', effect: 'draft', canDraft: false }).executionMode, 'ask')
})

check('Auto is bounded per run: past the limit nothing more applies, and the run says so in one sentence', () => {
  const b = createAutoBudget(3)
  assert.deepEqual([b.take(), b.take(), b.take(), b.take(), b.take()], [true, true, true, false, false])
  assert.equal(b.used, 3)
  assert.equal(createAutoBudget(2, 2).take(), false)
  const sentence = pausedSentence(10)
  assert.match(sentence, /10 changes/)
  assert.equal(sentence.split(/[.!?]\s/).length <= 2, true, 'plain and short')
})

check('loosening is detected: only tightening is free', () => {
  const base = on()
  assert.equal(loosensModes(base, base), false)
  assert.equal(loosensModes(base, on({ maxMode: 'auto' })), true)
  assert.equal(loosensModes(base, on({ defaultMode: 'readonly' })), false)
  assert.equal(loosensModes(base, on({ roleMaxMode: { editor: 'auto' } })), true)
  assert.equal(loosensModes(base, on({ roleMaxMode: { editor: 'readonly' } })), false)
  assert.equal(loosensModes(base, on({ targetModes: { pages: 'auto' } })), true)
  assert.equal(loosensModes(on({ targetModes: { pages: 'auto' } }), on({ targetModes: {} })), false)
  assert.equal(loosensModes(base, on({ maxAutoChanges: 11 })), true)
  assert.equal(loosensModes(base, on({ maxAutoChanges: 5 })), false)
  assert.equal(loosensModes(on({ autoLiveEdits: false }), on({ autoLiveEdits: true })), true)
  assert.equal(loosensModes(on({ personPicks: false }), on({ personPicks: true })), true)
  assert.equal(loosensModes(DEFAULT_AGENT_MODE_SETTINGS, base), false, 'turning the modes ON tightens (Accept changes is stricter than the old behaviour)')
  assert.equal(loosensModes(base, DEFAULT_AGENT_MODE_SETTINGS), true, 'turning them OFF goes back to the old, looser behaviour')
})

console.log(`\n${n} checks passed`)
