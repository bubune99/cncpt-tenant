/**
 * Assertions for dynamic tool loading and cache-stable tool order.
 * Run: npx -y tsx@4.23.15 src/lib/ai/toolsets.assert.ts
 */
import assert from 'node:assert/strict'
import { APP_ADE_DEFAULTS } from '../ade-bindings/app-config'
import {
  CORE_TOOLS,
  TOOL_GROUPS,
  activeToolNames,
  availableGroups,
  cacheBreakpointTool,
  groupCatalogue,
  groupOf,
  groupsForRequest,
  groupsFromLoadCalls,
  orderToolNames,
} from './toolsets'

/** Dzidzor's app hints — the chat route passes the same object. */
const H = APP_ADE_DEFAULTS.toolHints

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

// Every built-in tool as of origin/staging 2bc9b391 (lib/ai/tools index exports).
const BUILT_IN = [
  'navigateTo', 'searchProducts', 'searchOrders', 'getDashboardStats', 'getRecentActivity', 'scan_page',
  'suggestWalkthroughs', 'generateWalkthrough', 'startWalkthrough', 'createHelpContent', 'listWalkthroughs', 'explainElement', 'highlightElement', 'startGuidedExplanation',
  'listHelpKeys', 'getHelpContent', 'updateHelpContent', 'scanForMissingHelp', 'batchGenerateHelp', 'reviewOrphanedHelp', 'markHelpOrphaned', 'manageHelpStatus', 'purgeDeletedHelp', 'generateEntityHelp',
  'getEntityDetails', 'searchEntities', 'getEntityStats', 'getSiteTraffic',
  'createPage', 'updatePage', 'deletePage', 'duplicatePage', 'publishPage',
  'getPageBlocks', 'updateBlock', 'insertBlock', 'getSiteLayoutBlocks', 'updateSiteLayoutBlock', 'insertSiteLayoutBlock',
  'getSiteContext', 'messageSiteOwner', 'send_feedback_to_owner',
  'createBlogPost', 'updateBlogPost', 'deleteBlogPost', 'publishBlogPost', 'manageBlogCategory', 'manageBlogTag',
  'createProduct', 'updateProduct', 'deleteProduct', 'manageProductVariant', 'syncProductToStripe',
  'updateOrderStatus', 'fulfillOrder', 'refundOrder', 'cancelOrder',
  'updateSettings', 'updateBrandingSettings', 'updateSiteSettings',
  'spotlight_steps', 'spotlight_step', 'navigate_to_route',
  'listNavigationTabs', 'customizeNavigationTab', 'listInitiatives', 'setFeaturedInitiatives', 'listForms', 'setFormDisplay',
  'listRecordTypes', 'listRecords', 'getRecord', 'createRecordWithPage', 'updateRecord', 'publishRecord', 'overridePlacementField', 'resetPlacementField',
  'getForm', 'setFormAutomations',
  'describe_platform',
  'read_view', 'show_unit', 'capture_view', 'open_tab', 'expand', 'collapse', 'scroll_to', 'open_menu', 'coverage_check',
  'update_plan', 'ask_user',
]

check('the assistant can always look at the screen: read_view + capture_view are core; scan_page is a tour tool', () => {
  assert.ok((CORE_TOOLS as readonly string[]).includes('read_view'))
  assert.ok((CORE_TOOLS as readonly string[]).includes('capture_view'))
  assert.equal(groupOf('scan_page'), 'help')
})

check('every built-in tool is core or in a named group (none fall into extensions)', () => {
  const stray = BUILT_IN.filter((t) => groupOf(t) === 'extensions')
  assert.deepEqual(stray, [])
})

check('no tool is in two groups, and core is not duplicated in a group', () => {
  const seen = new Map<string, string>()
  for (const [g, def] of Object.entries(TOOL_GROUPS)) for (const t of def.tools) {
    assert.ok(!seen.has(t), `${t} in ${seen.get(t)} and ${g}`)
    assert.ok(!(CORE_TOOLS as readonly string[]).includes(t), `${t} is core and in ${g}`)
    seen.set(t, g)
  }
})

check('order is independent of input order (cache prefix stays byte-identical)', () => {
  const shuffled = [...BUILT_IN, 'load_tools', 'operate_ui', 'vmcp_zeta', 'vmcp_alpha'].reverse()
  const a = orderToolNames(shuffled)
  const b = orderToolNames([...shuffled].sort())
  assert.deepEqual(a, b)
  assert.equal(a[0], 'navigateTo')
  assert.equal(a.indexOf('operate_ui'), CORE_TOOLS.length) // right after core
  assert.deepEqual(a.slice(-2), ['vmcp_alpha', 'vmcp_zeta'])
})

check('cache breakpoint goes on the last core tool present', () => {
  const ordered = orderToolNames([...BUILT_IN, 'load_tools', 'operate_ui'])
  assert.equal(cacheBreakpointTool(ordered), 'load_tools')
  assert.equal(cacheBreakpointTool(orderToolNames(['navigateTo', 'createPage'])), 'navigateTo')
  assert.equal(cacheBreakpointTool(['createPage']), null)
})

check('active = core + screen tool + loaded groups only', () => {
  const ordered = orderToolNames([...BUILT_IN, 'load_tools', 'operate_ui', 'vmcp_x'])
  const act = activeToolNames(ordered, ['forms'])
  assert.ok(act.includes('navigateTo') && act.includes('operate_ui') && act.includes('getForm') && act.includes('listForms'))
  assert.ok(!act.includes('createPage') && !act.includes('refundOrder') && !act.includes('vmcp_x'))
  assert.ok(activeToolNames(ordered, ['extensions']).includes('vmcp_x'))
  // far fewer than everything
  assert.ok(activeToolNames(ordered, []).length <= CORE_TOOLS.length + 1)
})

check('route preloads the screen\'s groups', () => {
  assert.deepEqual(groupsForRequest({ route: '/admin/pages/abc/editor' }), ['pages', 'blocks'])
  assert.deepEqual(groupsForRequest({ route: '/admin/records/initiative/xyz', hints: H }), ['initiatives', 'records'])
  assert.deepEqual(groupsForRequest({ route: '/admin/forms/f1' }), ['forms'])
  assert.deepEqual(groupsForRequest({ route: '/admin/todo' }), [])
  assert.deepEqual(groupsForRequest({ route: null }), [])
})

check('message keywords preload obvious groups', () => {
  assert.deepEqual(groupsForRequest({ route: '/admin/today', message: 'Take me to the forms list.' }), ['forms'])
  assert.deepEqual(groupsForRequest({ route: '/admin/today', message: 'How many initiatives are still drafts?', hints: H }), ['initiatives', 'records']) // initiative writes are the records tools
  // Not a Dzidzor feature: "projects" preloads nothing.
  assert.deepEqual(groupsForRequest({ route: '/admin', message: 'Show me my projects', hints: H }), [])
  assert.deepEqual(groupsForRequest({ route: '/admin/settings', message: 'Add a Donate link to the site header', hints: H }), ['blocks', 'settings'])
  assert.deepEqual(groupsForRequest({ route: '/admin/today', message: 'I want to change the cookie banner wording', hints: H }), ['blocks', 'settings'])
  assert.deepEqual(groupsForRequest({ route: '/admin/today', message: 'hello' }), [])
})

check('earlier load_tools calls carry over; junk is ignored', () => {
  const calls = [
    { toolName: 'load_tools', input: { groups: ['shop', 'nope', 3] } },
    { toolName: 'navigateTo', input: { groups: ['blog'] } },
    { toolName: 'load_tools', input: { groups: ['blog'] } },
    { toolName: 'load_tools', input: null },
  ]
  assert.deepEqual(groupsFromLoadCalls(calls), ['blog', 'shop'])
  assert.deepEqual(groupsForRequest({ route: '/admin/today', previouslyLoaded: ['shop', 'bogus'] }), ['shop'])
})

check('available groups reflect what governance left', () => {
  assert.deepEqual(availableGroups(['navigateTo', 'getForm', 'vmcp_x']), ['forms', 'extensions'])
  assert.deepEqual(availableGroups(['navigateTo']), [])
})

check('catalogue is stable text naming every group', () => {
  const c = groupCatalogue()
  assert.equal(c, groupCatalogue())
  for (const g of ['pages', 'blocks', 'blog', 'initiatives', 'records', 'forms', 'settings', 'help', 'shop', 'extensions']) assert.ok(c.includes(`- ${g}:`))
})

check('app extras are honoured (and only through the hints — the generic table has none)', () => {
  // Without Dzidzor's hints the generic table knows nothing about initiatives.
  assert.deepEqual(groupsForRequest({ route: '/admin/records/initiative/xyz' }), ['records'])
  assert.deepEqual(groupsForRequest({ route: '/admin/today', message: 'How many initiatives are still drafts?' }), [])
  // Another app's screens and words (BYB-like), bogus groups ignored.
  const byb = { routes: [[/^\/admin\/designs(\/|$)/, ['shop', 'nope']]] as const, keywords: [[/\b(garments?|dtf)\b/i, ['shop']]] as const }
  assert.deepEqual(groupsForRequest({ route: '/admin/designs/d1', hints: byb }), ['shop'])
  assert.deepEqual(groupsForRequest({ route: '/admin/today', message: 'Price the DTF garments', hints: byb }), ['shop'])
  // App routes are checked before the generic ones (first match wins).
  assert.deepEqual(groupsForRequest({ route: '/admin/pages/x', hints: { routes: [[/^\/admin\/pages/, ['help']]] } }), ['help'])
})

check('help keys on the screen preload the help group (explain / highlight), never core', () => {
  assert.deepEqual(groupsForRequest({ route: '/admin/todo', availableHelpKeys: ['admin.todo.approve'] }), ['help'])
  assert.deepEqual(groupsForRequest({ route: '/admin/todo', availableHelpKeys: [] }), [])
  assert.deepEqual(groupsForRequest({ route: '/admin/todo', availableHelpKeys: null }), [])
  assert.equal(groupOf('explainElement'), 'help')
  assert.equal(groupOf('highlightElement'), 'help')
  assert.ok(!(CORE_TOOLS as readonly string[]).includes('explainElement'))
})

console.log(`\n${n} checks passed`)
