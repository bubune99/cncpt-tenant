/**
 * How hard the assistant thinks: the owner's "effort" setting, mapped to
 * the Anthropic provider option for the model actually in use. Models that
 * don't take effort get nothing (the API would reject it); a model that
 * stops below the chosen level gets its highest level instead.
 * Pure; asserted by effort.assert.ts.
 */

export const EFFORT_LEVELS = ['low', 'medium', 'high', 'max'] as const
export type Effort = (typeof EFFORT_LEVELS)[number]
export const DEFAULT_EFFORT: Effort = 'high'

export const EFFORT_LABELS: Record<Effort, string> = { low: 'Low', medium: 'Medium', high: 'High', max: 'Max' }

export function isEffort(v: unknown): v is Effort {
  return typeof v === 'string' && (EFFORT_LEVELS as readonly string[]).includes(v)
}

/** "anthropic/claude-haiku-5.5" / "claude-haiku-5-5-20261001" → "claude-haiku-5-5…". */
function bareId(modelId: string): string {
  return modelId.toLowerCase().replace(/^[a-z0-9-]+\//, '').replace(/\./g, '-')
}

/**
 * Effort levels a model accepts, or null when it takes none. From the
 * @ai-sdk/anthropic model table + changelog: effort arrived with Opus 4.5
 * (low–high); 'max' with the 4.6 generation; every 5.x model takes all.
 */
export function effortLevelsFor(modelId: string): readonly Effort[] | null {
  const id = bareId(modelId)
  if (!id.startsWith('claude-')) return null
  if (/^claude-(?:haiku|sonnet|opus|fable)-5(?:-|$)/.test(id)) return EFFORT_LEVELS
  if (/^claude-(?:opus|sonnet)-4-[6-9](?:-|$)/.test(id)) return EFFORT_LEVELS
  if (/^claude-opus-4-5(?:-|$)/.test(id)) return ['low', 'medium', 'high']
  return null
}

/** The providerOptions fragment for streamText, or undefined to send nothing. */
export function effortOptions(setting: unknown, modelId: string): { anthropic: { effort: Effort } } | undefined {
  const levels = effortLevelsFor(modelId)
  if (!levels) return undefined
  const wanted = isEffort(setting) ? setting : DEFAULT_EFFORT
  if (levels.includes(wanted)) return { anthropic: { effort: wanted } }
  // Clamp to the highest level the model has that's below what was asked.
  const below = EFFORT_LEVELS.slice(0, EFFORT_LEVELS.indexOf(wanted)).filter((l) => levels.includes(l))
  return below.length ? { anthropic: { effort: below[below.length - 1] } } : undefined
}

/**
 * Room for the answer at each effort. Thinking counts against the output
 * cap, so max effort inside 4,096 tokens can spend it all thinking and
 * return an empty answer (seen on Haiku 5.5). Low/medium keep 4,096.
 */
export const OUTPUT_TOKENS_FOR_EFFORT: Record<Effort, number> = { low: 4096, medium: 4096, high: 8192, max: 16384 }

/**
 * maxOutputTokens for a request: the configured cap, raised to what the
 * effort actually sent to this model needs, never above the ceiling.
 * Models that take no effort keep the configured cap.
 */
export function outputTokensFor(setting: unknown, modelId: string, configured: number, ceiling: number): number {
  const sent = effortOptions(setting, modelId)?.anthropic.effort
  const want = sent ? Math.max(configured, OUTPUT_TOKENS_FOR_EFFORT[sent]) : configured
  return Math.max(1, Math.min(Math.floor(want), ceiling))
}
