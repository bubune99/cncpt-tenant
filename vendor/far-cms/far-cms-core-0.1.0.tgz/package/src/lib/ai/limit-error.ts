/**
 * Parse an AI route's refusal body (client-safe, pure). The chat transports
 * throw Error(responseBody); refusals are JSON carrying the human message and,
 * for limits, resetAt (ISO) + resetText. Asserted by spend-policy.assert.ts.
 */

export interface LimitError {
  message: string
  /** seconds until retry is sensible, when the reset is near (<= 2 min) */
  retryAfterSec?: number
  resetAt?: string
}

/**
 * The chat transport throws Error(responseBody). Our AI routes answer
 * refusals with JSON { error, resetAt?, resetText? } — surface that text
 * (it already says when the limit resets) instead of a generic message.
 */
export function parseLimitError(raw: string, nowMs: number): LimitError | null {
  let body: unknown
  try {
    body = JSON.parse(raw)
  } catch {
    return null
  }
  if (!body || typeof body !== 'object') return null
  const b = body as { error?: unknown; message?: unknown; resetAt?: unknown; resetText?: unknown }
  // ChatSDKError bodies are { error: '<code>', message }; ours are { error: '<text>' }.
  const text = typeof b.message === 'string' && b.message ? b.message : b.error
  if (typeof text !== 'string' || text.length === 0) return null
  const out: LimitError = { message: text }
  if (typeof b.resetAt === 'string') {
    out.resetAt = b.resetAt
    const ms = Date.parse(b.resetAt) - nowMs
    if (Number.isFinite(ms) && ms > 0 && ms <= 120_000) out.retryAfterSec = Math.ceil(ms / 1000)
    if (typeof b.resetText === 'string' && !text.includes('resets')) {
      out.message = `${text} Resets ${b.resetText}.`
    }
  }
  return out
}
