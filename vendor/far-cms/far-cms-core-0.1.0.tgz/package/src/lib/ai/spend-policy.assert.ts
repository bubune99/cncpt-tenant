/**
 * Assertions for AI spend decisions and refusal parsing.
 * Run: npx -y tsx@4.23.15 src/lib/ai/spend-policy.assert.ts
 */
import assert from 'node:assert/strict'
import {
  clampOutputTokens,
  decideCountedAction,
  decideImageForRequest,
  decideTokenAdmission,
  parseSpendConfig,
  requestTokenCap,
  tokensFromUsage,
} from './spend-policy'
import { parseLimitError } from './limit-error'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}
const H = 3_600_000

check('defaults: 5h user window, 3M/24h global, 20 images, 2/request, 10 v0 runs, enabled', () => {
  const c = parseSpendConfig({})
  assert.deepEqual(c, {
    disabled: false,
    userWindowMs: 5 * H,
    globalTokenLimit: 3_000_000,
    globalWindowMs: 24 * H,
    imagesPerUser: 20,
    imagesPerRequest: 2,
    v0RunsPerUser: 10,
    countedActionWindowMs: 24 * H,
  })
})
check('env overrides, 0 = off for the global ceiling, garbage falls back', () => {
  const c = parseSpendConfig({
    AI_DISABLED: '1',
    AI_BUDGET_WINDOW_HOURS: '24',
    AI_GLOBAL_DAILY_TOKEN_LIMIT: '0',
    AI_IMAGES_PER_USER_DAY: 'lots',
    AI_GLOBAL_WINDOW_HOURS: '-3',
  })
  assert.equal(c.disabled, true)
  assert.equal(c.userWindowMs, 24 * H)
  assert.equal(c.globalTokenLimit, 0)
  assert.equal(c.imagesPerUser, 20)
  assert.equal(c.globalWindowMs, 24 * H)
  assert.equal(parseSpendConfig({ AI_DISABLED: 'true' }).disabled, true)
  assert.equal(parseSpendConfig({ AI_DISABLED: '0' }).disabled, false)
  assert.equal(parseSpendConfig({ AI_BUDGET_WINDOW_HOURS: '0.5' }).userWindowMs, 0.5 * H)
})

const base = { disabled: false, userUsed: 0, userBudget: 500_000, userResetAt: 1, globalUsed: 0, globalLimit: 3_000_000, globalResetAt: 2 }
check('admission: kill switch refuses first (503)', () => {
  assert.deepEqual(decideTokenAdmission({ ...base, disabled: true }), { ok: false, status: 503, code: 'disabled' })
})
check('admission: global ceiling refuses everyone, with its resetAt', () => {
  assert.deepEqual(decideTokenAdmission({ ...base, globalUsed: 3_000_000 }), { ok: false, status: 429, code: 'global_ceiling', resetAt: 2 })
})
check('admission: user budget refuses, with its resetAt', () => {
  assert.deepEqual(decideTokenAdmission({ ...base, userUsed: 500_000 }), { ok: false, status: 429, code: 'user_budget', resetAt: 1 })
})
check('admission: remaining = min(user left, global left); 0 limits = off', () => {
  assert.deepEqual(decideTokenAdmission({ ...base, userUsed: 400_000, globalUsed: 2_950_000 }), { ok: true, remainingTokens: 50_000 })
  assert.deepEqual(decideTokenAdmission({ ...base, userBudget: 0, globalLimit: 0 }), { ok: true, remainingTokens: Infinity })
})
check('counted actions: charged-first count must stay <= max; max 0 = off', () => {
  assert.equal(decideCountedAction(20, 20), true)
  assert.equal(decideCountedAction(21, 20), false)
  assert.equal(decideCountedAction(1, 0), false)
})
check('images per request: at most 2', () => {
  assert.equal(decideImageForRequest(0, 2), true)
  assert.equal(decideImageForRequest(1, 2), true)
  assert.equal(decideImageForRequest(2, 2), false)
})
check('continuations draw from the same per-message budget', () => {
  assert.equal(requestTokenCap(120_000, 0, Infinity), 120_000)
  assert.equal(requestTokenCap(120_000, 119_000, Infinity), 1_000, 'continuation gets only what is left')
  assert.equal(requestTokenCap(120_000, 130_000, Infinity), 0, 'over budget -> nothing (refuse)')
  assert.equal(requestTokenCap(120_000, 0, 5_000), 5_000, 'bounded by admission remaining')
})
check('maxOutputTokens clamp', () => {
  assert.equal(clampOutputTokens(100_000, 4096, 8192), 8192)
  assert.equal(clampOutputTokens(2048, 4096, 8192), 2048)
  assert.equal(clampOutputTokens(undefined, 4096, 8192), 4096)
  assert.equal(clampOutputTokens(-5, 4096, 8192), 4096)
})
check('tokensFromUsage', () => {
  assert.equal(tokensFromUsage({ totalTokens: 10 }), 10)
  assert.equal(tokensFromUsage({ inputTokens: 3, outputTokens: 4 }), 7)
  assert.equal(tokensFromUsage(undefined), 0)
  assert.equal(tokensFromUsage({ totalTokens: NaN }), 0)
})
check('tokensFromUsage: cache reads count at a tenth', () => {
  // 30k prompt of which 28k came from the cache, 200 out: 2_000 + 2_800 + 200
  assert.equal(tokensFromUsage({ totalTokens: 30_200, inputTokens: 30_000, outputTokens: 200, inputTokenDetails: { cacheReadTokens: 28_000 } }), 5_000)
  assert.equal(tokensFromUsage({ totalTokens: 1_000, cachedInputTokens: 500 }), 550)
  assert.equal(tokensFromUsage({ totalTokens: 100, inputTokenDetails: { cacheReadTokens: undefined } }), 100)
  // a bogus cache figure never exceeds the total or goes negative
  assert.equal(tokensFromUsage({ totalTokens: 100, inputTokenDetails: { cacheReadTokens: 10_000 } }), 10)
  assert.equal(tokensFromUsage({ totalTokens: 100, inputTokenDetails: { cacheReadTokens: -5 } }), 100)
})
check('parseLimitError: our body, ChatSDKError body, resetText appended, near reset -> countdown', () => {
  const now = Date.UTC(2026, 9, 8, 9, 0, 0)
  assert.deepEqual(parseLimitError(JSON.stringify({ error: 'Your budget is used up. It resets in 2h (at 11:00 UTC).', resetAt: new Date(now + 2 * H).toISOString(), resetText: 'in 2h (at 11:00 UTC)' }), now), {
    message: 'Your budget is used up. It resets in 2h (at 11:00 UTC).',
    resetAt: new Date(now + 2 * H).toISOString(),
  })
  assert.equal(parseLimitError(JSON.stringify({ error: 'rate_limit:chat', message: 'Nope.' }), now)?.message, 'Nope.')
  assert.equal(parseLimitError(JSON.stringify({ error: 'Limited.', resetAt: new Date(now + H).toISOString(), resetText: 'in 1h' }), now)?.message, 'Limited. Resets in 1h.')
  assert.equal(parseLimitError(JSON.stringify({ error: 'x', resetAt: new Date(now + 30_000).toISOString() }), now)?.retryAfterSec, 30)
  assert.equal(parseLimitError('not json', now), null)
})

console.log(`\n${n} checks passed`)
