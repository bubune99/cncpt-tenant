/**
 * AI spend policy — pure decisions, no I/O. Asserted by spend-policy.assert.ts.
 *
 * Every AI surface (chat, Kofi, v0 import, image generation) is admitted and
 * metered through ./spend.ts, which reads/writes `usage_counters` and asks
 * these functions what to do.
 */

const HOUR_MS = 3_600_000

export interface AiSpendConfig {
  /** AI_DISABLED=1 — refuse every AI request. */
  disabled: boolean
  /** Per-user token budget window (AI_BUDGET_WINDOW_HOURS, default 5). */
  userWindowMs: number
  /** Site-wide ceiling (AI_GLOBAL_DAILY_TOKEN_LIMIT, default 3,000,000; 0 = off). */
  globalTokenLimit: number
  /** Site-wide ceiling window (AI_GLOBAL_WINDOW_HOURS, default 24). */
  globalWindowMs: number
  /** Images per user per window (AI_IMAGES_PER_USER_DAY, default 20). */
  imagesPerUser: number
  /** Images per single request (AI_IMAGES_PER_REQUEST, default 2). */
  imagesPerRequest: number
  /** v0 import runs per user per window (V0_RUNS_PER_USER_DAY, default 10). */
  v0RunsPerUser: number
  /** Window for the image and v0-run caps (24h). */
  countedActionWindowMs: number
}

type Env = Record<string, string | undefined>

function intFromEnv(env: Env, name: string, fallback: number, allowZero: boolean): number {
  const raw = env[name]
  if (raw === undefined || raw.trim() === '') return fallback
  const n = Number(raw)
  if (!Number.isFinite(n) || n < 0 || (!allowZero && n === 0)) return fallback
  return Math.floor(n)
}

function hoursFromEnv(env: Env, name: string, fallbackHours: number): number {
  const raw = env[name]
  const n = raw === undefined ? NaN : Number(raw)
  const hours = Number.isFinite(n) && n > 0 && n <= 24 * 31 ? n : fallbackHours
  return Math.round(hours * HOUR_MS)
}

export function parseSpendConfig(env: Env): AiSpendConfig {
  const disabled = ['1', 'true', 'yes', 'on'].includes((env.AI_DISABLED ?? '').trim().toLowerCase())
  return {
    disabled,
    userWindowMs: hoursFromEnv(env, 'AI_BUDGET_WINDOW_HOURS', 5),
    globalTokenLimit: intFromEnv(env, 'AI_GLOBAL_DAILY_TOKEN_LIMIT', 3_000_000, true),
    globalWindowMs: hoursFromEnv(env, 'AI_GLOBAL_WINDOW_HOURS', 24),
    imagesPerUser: intFromEnv(env, 'AI_IMAGES_PER_USER_DAY', 20, true),
    imagesPerRequest: intFromEnv(env, 'AI_IMAGES_PER_REQUEST', 2, true),
    v0RunsPerUser: intFromEnv(env, 'V0_RUNS_PER_USER_DAY', 10, true),
    countedActionWindowMs: 24 * HOUR_MS,
  }
}

export type AdmissionDecision =
  | { ok: true; remainingTokens: number }
  | {
      ok: false
      status: 429 | 503
      /** in_flight: requests already running hold reservations on the rest of the budget. */
      code: 'disabled' | 'user_budget' | 'global_ceiling' | 'in_flight' | 'unverifiable'
      resetAt?: number
    }

/**
 * Admit a token-spending request. `userBudget` 0 = no per-user budget;
 * `globalLimit` 0 = no site ceiling. `remainingTokens` is what this request
 * may spend at most (Infinity when neither applies).
 */
export function decideTokenAdmission(input: {
  disabled: boolean
  userUsed: number
  userBudget: number
  userResetAt: number
  globalUsed: number
  globalLimit: number
  globalResetAt: number
}): AdmissionDecision {
  if (input.disabled) return { ok: false, status: 503, code: 'disabled' }
  if (input.globalLimit > 0 && input.globalUsed >= input.globalLimit) {
    return { ok: false, status: 429, code: 'global_ceiling', resetAt: input.globalResetAt }
  }
  if (input.userBudget > 0 && input.userUsed >= input.userBudget) {
    return { ok: false, status: 429, code: 'user_budget', resetAt: input.userResetAt }
  }
  const userLeft = input.userBudget > 0 ? input.userBudget - input.userUsed : Number.POSITIVE_INFINITY
  const globalLeft = input.globalLimit > 0 ? input.globalLimit - input.globalUsed : Number.POSITIVE_INFINITY
  return { ok: true, remainingTokens: Math.min(userLeft, globalLeft) }
}

/**
 * A counted action (image, v0 run) was charged first; `countAfter` is the
 * window's count including it. `max` 0 = the action is turned off.
 */
export function decideCountedAction(countAfter: number, max: number): boolean {
  return max > 0 && Number.isFinite(countAfter) && countAfter <= max
}

/** Per-request image cap: `alreadyThisRequest` images were already made. */
export function decideImageForRequest(alreadyThisRequest: number, perRequestMax: number): boolean {
  return alreadyThisRequest < perRequestMax
}

/** Cache reads are billed at a tenth of normal input; the budget counts them the same way. */
export const CACHE_READ_WEIGHT = 0.1

/**
 * Tokens in an AI SDK usage object (totalTokens, else input + output), with
 * prompt-cache reads counted at CACHE_READ_WEIGHT so the budget tracks real cost.
 */
export function tokensFromUsage(
  u:
    | {
        totalTokens?: number
        inputTokens?: number
        outputTokens?: number
        inputTokenDetails?: { cacheReadTokens?: number | undefined }
        cachedInputTokens?: number
      }
    | undefined
    | null,
): number {
  if (!u) return 0
  const total = u.totalTokens ?? (u.inputTokens ?? 0) + (u.outputTokens ?? 0)
  if (!Number.isFinite(total) || total <= 0) return 0
  const raw = u.inputTokenDetails?.cacheReadTokens ?? u.cachedInputTokens ?? 0
  const cacheRead = Number.isFinite(raw) && raw > 0 ? Math.min(raw, total) : 0
  return Math.floor(total - cacheRead + Math.ceil(cacheRead * CACHE_READ_WEIGHT))
}

/**
 * Token ceiling for one request: the per-request cap, minus what earlier
 * runs for the same user message already spent (continuations draw from
 * the same budget), bounded by what admission allows. 0 = nothing left.
 */
export function requestTokenCap(perRequestCap: number, alreadySpentForMessage: number, admittedRemaining: number): number {
  return Math.max(0, Math.min(perRequestCap - alreadySpentForMessage, admittedRemaining))
}

/** Clamp a settings value for maxOutputTokens to [1, ceiling]. */
export function clampOutputTokens(settingValue: number | undefined | null, fallback: number, ceiling: number): number {
  const v = typeof settingValue === 'number' && Number.isFinite(settingValue) && settingValue > 0 ? settingValue : fallback
  return Math.max(1, Math.min(Math.floor(v), ceiling))
}
