/**
 * What to keep from an assistant reply when the run finishes (api/chat POST onFinish). Pure: no
 * database. Moved out of the route on 2026-11-22 (size check); behaviour unchanged. Asserted by
 * assistant-turn.assert.ts.
 *
 * With originalMessages, a continuation's responseMessage is the WHOLE last assistant message: what
 * the earlier request already saved comes first and is not saved again. AI SDK v6 messages carry
 * `parts`; older shapes used `content` — both are read, or a saved reply ends up empty.
 */
import { spotsFromParts, type AreaItem } from '../ade/ui/spots'
import { changeRefsFromParts } from '../ade/chat/change-widgets'
import { spotCallRecords } from '../ade/chat/spot-record'

type Part = Record<string, unknown>
export interface LastMessageIn { id?: string; role?: string; parts?: unknown[] }

export interface AssistantTurn {
  /** The reply's words that are new in this request. */
  text: string
  /** This request continues the last assistant message. */
  continuing: boolean
  /** The parts new in this request (what gets saved). */
  newParts: Part[]
  /** The reply's parts, plus the previous assistant turn's when this is a new reply after it (for spots and changes). */
  allParts: unknown[]
}

export function readAssistantTurn(responseMessage: unknown, lastIn: LastMessageIn | undefined): AssistantTurn {
  const msg = responseMessage as Record<string, unknown> | null
  const parts = (Array.isArray(msg?.parts) ? msg!.parts : Array.isArray(msg?.content) ? msg!.content : []) as Part[]
  const continuing = lastIn?.role === 'assistant' && Array.isArray(lastIn.parts) && msg?.id === lastIn.id
  const newParts = continuing ? parts.slice(lastIn!.parts!.length) : parts
  const text = newParts
    .filter((part) => part.type === 'text')
    .map((part) => String(part.text || ''))
    .join('') || ''
  // A resumed turn (after a screen read) continues the last assistant message, whose earlier parts hold the read that names the units.
  const priorParts = !continuing && lastIn?.role === 'assistant' && Array.isArray(lastIn.parts) ? lastIn.parts : []
  return { text, continuing: !!continuing, newParts, allParts: [...priorParts, ...parts] }
}

/** What the reply pointed at, what it changed (refs from its tools, never its words) and each pointing call, for the saved metadata. */
export function turnRecords(allParts: unknown[], currentRoute: string | null, navAreas: readonly AreaItem[]) {
  return {
    spots: spotsFromParts(allParts, currentRoute, navAreas),
    changes: changeRefsFromParts(allParts),
    spotCalls: spotCallRecords(allParts),
  }
}

/** Real token usage across every step of the tool loop (the daily budget reads it); undefined when unreadable. */
export async function readTotalUsage(totalUsage: PromiseLike<{ inputTokens?: number; outputTokens?: number; totalTokens?: number }>) {
  try {
    const u = await totalUsage
    return {
      promptTokens: u.inputTokens ?? 0,
      completionTokens: u.outputTokens ?? 0,
      totalTokens: u.totalTokens ?? (u.inputTokens ?? 0) + (u.outputTokens ?? 0),
    }
  } catch (usageError) {
    console.warn('[Chat] Could not read token usage:', usageError)
    return undefined
  }
}
