/**
 * Run: npx -y tsx@4.23.15 src/lib/ai/effort.assert.ts
 */
import assert from 'node:assert/strict'
import { DEFAULT_EFFORT, OUTPUT_TOKENS_FOR_EFFORT, effortLevelsFor, effortOptions, isEffort, outputTokensFor } from './effort'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('Haiku 5.5 at max — the owner’s setting — goes through as is', () => {
  assert.deepEqual(effortOptions('max', 'anthropic/claude-haiku-5.5'), { anthropic: { effort: 'max' } })
  assert.deepEqual(effortOptions('max', 'claude-haiku-5-5'), { anthropic: { effort: 'max' } })
  assert.deepEqual(effortOptions('low', 'anthropic/claude-sonnet-5.5'), { anthropic: { effort: 'low' } })
  assert.deepEqual(effortOptions('max', 'anthropic/claude-opus-5.5'), { anthropic: { effort: 'max' } })
  assert.deepEqual(effortOptions('high', 'anthropic/claude-opus-4.6'), { anthropic: { effort: 'high' } })
})

check('models without effort get nothing (the API would reject it)', () => {
  assert.equal(effortOptions('max', 'anthropic/claude-haiku-4.5'), undefined)
  assert.equal(effortOptions('high', 'anthropic/claude-sonnet-4.5'), undefined)
  assert.equal(effortOptions('high', 'anthropic/claude-opus-4.1'), undefined)
  assert.equal(effortOptions('high', 'openai/gpt-5'), undefined)
  assert.equal(effortLevelsFor('anthropic/claude-sonnet-4'), null)
})

check('a model that stops below the setting gets its highest level', () => {
  assert.deepEqual(effortOptions('max', 'anthropic/claude-opus-4.5'), { anthropic: { effort: 'high' } })
  assert.deepEqual(effortOptions('medium', 'anthropic/claude-opus-4.5'), { anthropic: { effort: 'medium' } })
})

check('a missing or unknown setting means the default (high)', () => {
  assert.equal(DEFAULT_EFFORT, 'high')
  assert.deepEqual(effortOptions(undefined, 'anthropic/claude-haiku-5.5'), { anthropic: { effort: 'high' } })
  assert.deepEqual(effortOptions('extreme', 'anthropic/claude-haiku-5.5'), { anthropic: { effort: 'high' } })
  assert.ok(isEffort('max') && !isEffort('xhigh') && !isEffort(3))
})

check('output cap grows with effort, never past the ceiling', () => {
  const haiku = 'anthropic/claude-haiku-5.5'
  assert.equal(outputTokensFor('low', haiku, 4096, 16384), 4096)
  assert.equal(outputTokensFor('medium', haiku, 4096, 16384), 4096)
  assert.equal(outputTokensFor('high', haiku, 4096, 16384), 8192)
  assert.equal(outputTokensFor('max', haiku, 4096, 16384), OUTPUT_TOKENS_FOR_EFFORT.max)
  assert.equal(outputTokensFor('max', haiku, 4096, 8192), 8192)
  // A bigger configured cap stays; a model without effort keeps the configured cap.
  assert.equal(outputTokensFor('low', haiku, 6000, 16384), 6000)
  assert.equal(outputTokensFor('max', 'anthropic/claude-haiku-4.5', 4096, 16384), 4096)
  // Opus 4.5 is clamped to high effort, so it gets high's room.
  assert.equal(outputTokensFor('max', 'anthropic/claude-opus-4.5', 4096, 16384), 8192)
  // Default effort (high) when unset.
  assert.equal(outputTokensFor(undefined, haiku, 4096, 16384), 8192)
})

console.log(`\n${n} checks passed`)
