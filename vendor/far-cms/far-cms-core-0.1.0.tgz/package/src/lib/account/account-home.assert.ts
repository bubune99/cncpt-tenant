/**
 * The customer account home (/account) shows only places that exist. Found by the page scan on
 * dzidzor-staging 2026-11-22: with shopping off, "View All Orders" and "My Orders" led to 404,
 * and "Wishlist" has no page at all. Run: node_modules/.bin/tsx src/lib/account/account-home.assert.ts
 */
import assert from 'node:assert/strict'
import { accountHome } from './account-home'

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log('ok', n, '-', name) }

ok('shopping off: no orders card, no orders or addresses actions', () => {
  const h = accountHome(false)
  assert.equal(h.showOrders, false)
  assert.deepEqual(h.actions.map((a) => a.url), ['/account/profile', '/account/settings'])
  assert.doesNotMatch(h.subtitle, /order|address/i)
})
ok('shopping on: orders card and the orders and addresses actions', () => {
  const h = accountHome(true)
  assert.equal(h.showOrders, true)
  assert.deepEqual(h.actions.map((a) => a.url), ['/account/orders', '/account/addresses', '/account/profile', '/account/settings'])
  assert.match(h.subtitle, /orders/)
})
ok('never a link to a page that does not exist (wishlist)', () => {
  for (const on of [true, false]) assert.ok(!accountHome(on).actions.some((a) => a.url.includes('wishlist')))
})
console.log(`\n${n} checks passed`)
