/**
 * What the customer account home (/account) shows, from whether shopping is on (commerce.enabled,
 * lib/features). Order and address pages 404 while shopping is off (their layouts call notFound),
 * so their links are left out; there is no wishlist page, so it is never offered.
 * Check: src/lib/account/account-home.assert.ts
 */
import { isCommerceStorefrontPath } from '../commerce-paths'

export interface AccountAction { label: string; icon: string; url: string; color: string }

const ALL_ACTIONS: AccountAction[] = [
  { label: 'My Orders', icon: 'Package', url: '/account/orders', color: 'blue' },
  { label: 'Addresses', icon: 'MapPin', url: '/account/addresses', color: 'green' },
  { label: 'Profile', icon: 'User', url: '/account/profile', color: 'gray' },
  { label: 'Settings', icon: 'Settings', url: '/account/settings', color: 'purple' },
]

export function accountHome(commerceEnabled: boolean): { showOrders: boolean; subtitle: string; actions: AccountAction[] } {
  return {
    showOrders: commerceEnabled,
    subtitle: commerceEnabled ? 'Manage your orders, addresses, and account settings' : 'Manage your profile and account settings',
    actions: commerceEnabled ? ALL_ACTIONS : ALL_ACTIONS.filter((a) => !isCommerceStorefrontPath(a.url)),
  }
}
