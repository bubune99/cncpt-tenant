/**
 * Who sees which products through the catalog API. Someone who may manage products sees every status they ask for;
 * anyone else (a visitor, a signed-in shopper) sees only ACTIVE ones: never drafts or archived products.
 * Run: node_modules/.bin/tsx packages/core/src/lib/products/catalog-visibility.assert.ts
 */
import assert from "node:assert/strict"
import { catalogStatus, canSeeProduct } from "./catalog-visibility"

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

ok("a manager sees what they ask for, or every status when they ask for none", () => {
  assert.equal(catalogStatus("DRAFT", true), "DRAFT")
  assert.equal(catalogStatus(null, true), undefined)
})
ok("anyone else sees only ACTIVE products, whatever they ask for", () => {
  assert.equal(catalogStatus(null, false), "ACTIVE")
  assert.equal(catalogStatus("DRAFT", false), "ACTIVE")
  assert.equal(catalogStatus("ARCHIVED", false), "ACTIVE")
})
ok("one product: a draft or archived product is hidden from non-managers", () => {
  assert.equal(canSeeProduct("ACTIVE", false), true)
  assert.equal(canSeeProduct("DRAFT", false), false)
  assert.equal(canSeeProduct("ARCHIVED", false), false)
  assert.equal(canSeeProduct("DRAFT", true), true)
})
console.log(`${n} checks passed`)
