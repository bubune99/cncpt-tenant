/**
 * Who sees which products through the catalog API (GET /api/products, /api/products/[id]). A caller who may manage
 * products (products.view) sees any status; anyone else sees only ACTIVE products. Pure. Checked in
 * catalog-visibility.assert.ts.
 */
export type CatalogStatus = "DRAFT" | "ACTIVE" | "ARCHIVED"

/** The status filter for a list: the requested one for a manager (or none), ACTIVE for anyone else. */
export function catalogStatus(requested: CatalogStatus | null, canManage: boolean): CatalogStatus | undefined {
  if (canManage) return requested ?? undefined
  return "ACTIVE"
}

/** Whether one product may be shown to this caller. */
export function canSeeProduct(status: CatalogStatus, canManage: boolean): boolean {
  return canManage || status === "ACTIVE"
}
