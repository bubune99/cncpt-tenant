/**
 * The page builder's state and the reducer that changes it: pure, no React.
 * Moved out of editor-context.tsx (2026-11-16) to keep that file under 800 lines.
 */
import { sameValue } from "../ade/history/revisions"
import type { Block, DragState } from "./types"
import type { BlockSpotlight } from "./workflow-types"
import { clearedHistory } from "./clear-all"
import type { SavedPage } from "./storage"

/* ------------------------------------------------------------------ */
/*  Viewed File (for code panel file browsing)                         */
/* ------------------------------------------------------------------ */

export interface ViewedFile {
  path: string
  content: string
  title: string
  isReadOnly: boolean
  sourceType: "page" | "template" | "component" | "layout"
  sourceId: string
}

/* ------------------------------------------------------------------ */
/*  State + Reducer                                                    */
/* ------------------------------------------------------------------ */

export interface EditorState {
  blocks: Block[]
  selectedBlockId: string | null
  hoveredBlockId: string | null
  dragState: DragState | null
  clipboard: Block | null
  history: Block[][]
  historyIndex: number
  // Page management
  currentPage: SavedPage | null
  hasUnsavedChanges: boolean
  /** The blocks as last loaded or saved: "unsaved" means blocks differ from these (unsaved.assert.ts). */
  savedBlocks: Block[]
  saveStatus: "idle" | "saving" | "saved" | "error"
  lastSavedAt: string | null
  // Loading state
  isLoading: boolean
  /** The page (or header, footer, section) could not be loaded: show a retry, not an empty editor. */
  loadFailed?: boolean
  // Code editor sync
  jsxSyncDirection: "visual" | "code" | null
  // Currently viewed file in code panel
  viewedFile: ViewedFile | null
  // AI spotlight state (Kofi)
  activeSpotlights: BlockSpotlight[]
}

export type EditorAction =
  | { type: "SET_BLOCKS"; blocks: Block[] }
  | { type: "TRANSFORM_BLOCKS"; fn: (prev: Block[]) => Block[] }
  | { type: "SELECT_BLOCK"; id: string | null }
  | { type: "SET_HOVERED"; id: string | null }
  | { type: "SET_DRAG_STATE"; dragState: DragState | null }
  | { type: "SET_CLIPBOARD"; block: Block }
  | { type: "UNDO" }
  | { type: "REDO" }
  | { type: "CLEAR_ALL" }
  | { type: "SET_CURRENT_PAGE"; page: SavedPage | null }
  | { type: "SET_SAVE_STATUS"; status: EditorState["saveStatus"] }
  | { type: "MARK_SAVED"; timestamp: string; page: SavedPage }
  | { type: "LOAD_PAGE"; page: SavedPage }
  | { type: "SET_LOADING"; loading: boolean }
  | { type: "LOAD_FAILED" }
  | { type: "SET_BLOCKS_FROM_JSX"; blocks: Block[] }
  | { type: "SET_SYNC_DIRECTION"; direction: EditorState["jsxSyncDirection"] }
  | { type: "SET_VIEWED_FILE"; file: ViewedFile | null }
  | { type: "SET_SPOTLIGHTS"; spotlights: BlockSpotlight[] }
  | { type: "CLEAR_SPOTLIGHTS" }

function pushHistory(state: EditorState, blocks: Block[]): EditorState {
  const newHistory = state.history.slice(0, state.historyIndex + 1)
  newHistory.push(blocks)
  if (newHistory.length > 50) newHistory.shift()
  return {
    ...state,
    blocks,
    history: newHistory,
    historyIndex: newHistory.length - 1,
  }
}

export function editorReducer(state: EditorState, action: EditorAction): EditorState {
  const next = reduce(state, action)
  // Any change to the blocks: unsaved exactly when they differ from what was last saved.
  if (next !== state && next.blocks !== state.blocks && action.type !== "LOAD_PAGE") {
    const unsaved = !sameValue(next.blocks, next.savedBlocks)
    return unsaved === next.hasUnsavedChanges ? next : { ...next, hasUnsavedChanges: unsaved }
  }
  return next
}

function reduce(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    // Only a real change is an edit: a component re-setting the same blocks
    // (on mount, on blur) must not mark the page unsaved — that would autosave
    // a draft just for opening the editor.
    case "SET_BLOCKS":
      if (sameValue(action.blocks, state.blocks)) return state
      return { ...pushHistory(state, action.blocks), hasUnsavedChanges: true, jsxSyncDirection: "visual" }
    case "TRANSFORM_BLOCKS": {
      const next = action.fn(state.blocks)
      if (sameValue(next, state.blocks)) return state
      return { ...pushHistory(state, next), hasUnsavedChanges: true, jsxSyncDirection: "visual" }
    }
    case "SELECT_BLOCK":
      return { ...state, selectedBlockId: action.id }
    case "SET_HOVERED":
      return { ...state, hoveredBlockId: action.id }
    case "SET_DRAG_STATE":
      return { ...state, dragState: action.dragState }
    case "SET_CLIPBOARD":
      return { ...state, clipboard: action.block }
    case "UNDO": {
      if (state.historyIndex <= 0) return state
      const i = state.historyIndex - 1
      return { ...state, blocks: state.history[i], historyIndex: i, selectedBlockId: null, hasUnsavedChanges: true }
    }
    case "REDO": {
      if (state.historyIndex >= state.history.length - 1) return state
      const i = state.historyIndex + 1
      return { ...state, blocks: state.history[i], historyIndex: i, selectedBlockId: null, hasUnsavedChanges: true }
    }
    case "CLEAR_ALL":
      // One more step in the history (never a reset): Undo brings the page back.
      return {
        ...clearedHistory(state),
        selectedBlockId: null,
        hoveredBlockId: null,
        dragState: null,
        hasUnsavedChanges: state.blocks.length > 0 ? true : state.hasUnsavedChanges,
      }
    case "SET_CURRENT_PAGE":
      return { ...state, currentPage: action.page }
    case "SET_SAVE_STATUS":
      return { ...state, saveStatus: action.status }
    case "MARK_SAVED": {
      const savedBlocks = action.page.blocks ?? state.blocks
      return {
        ...state,
        currentPage: action.page,
        savedBlocks,
        // An edit made while the save was in flight is still unsaved.
        hasUnsavedChanges: !sameValue(state.blocks, savedBlocks),
        saveStatus: "saved",
        lastSavedAt: action.timestamp,
      }
    }
    case "LOAD_PAGE":
      return {
        ...state,
        blocks: action.page.blocks,
        currentPage: action.page,
        selectedBlockId: null,
        hoveredBlockId: null,
        history: [action.page.blocks],
        historyIndex: 0,
        hasUnsavedChanges: false,
        savedBlocks: action.page.blocks,
        saveStatus: "idle",
        lastSavedAt: action.page.updatedAt,
        isLoading: false,
        loadFailed: false,
        jsxSyncDirection: null,
      }
    case "SET_LOADING":
      return { ...state, isLoading: action.loading }
    case "LOAD_FAILED":
      return { ...state, isLoading: false, loadFailed: true }
    case "SET_BLOCKS_FROM_JSX": {
      if (sameValue(state.blocks, action.blocks)) {
        return { ...state, jsxSyncDirection: "code" }
      }
      return {
        ...pushHistory(state, action.blocks),
        hasUnsavedChanges: true,
        jsxSyncDirection: "code",
      }
    }
    case "SET_SYNC_DIRECTION":
      return { ...state, jsxSyncDirection: action.direction }
    case "SET_VIEWED_FILE":
      return { ...state, viewedFile: action.file }
    case "SET_SPOTLIGHTS":
      return { ...state, activeSpotlights: action.spotlights }
    case "CLEAR_SPOTLIGHTS":
      return { ...state, activeSpotlights: [] }
    default:
      return state
  }
}
