/**
 * How the page editor fits its container (Classic: beside the sidebar).
 * Below NARROW_EDITOR_PX of CONTAINER width — not the window — the toolbar
 * keeps its primary action and moves the rest into More, and Blocks /
 * Properties become toggleable side sheets so the canvas takes the space.
 * (At 1068 in Classic the toolbar overflowed by ~99px and the canvas was
 * 270px wide.) The sidebar is never collapsed for the person.
 *
 * Pure. Run: npx -y tsx@4.23.15 src/lib/block-editor/editor-fit.assert.ts
 */

export const NARROW_EDITOR_PX = 1280

export interface EditorFit {
  /** Save, Preview and the assistant/properties toggle live in More; Publish/Submit stays. */
  compactToolbar: boolean
  /** Blocks and Properties open as sheets over the canvas instead of beside it. */
  panelsAsSheets: boolean
}

/** `containerWidth` null = not measured yet: assume roomy (no flash of sheets on wide screens). */
export function editorFit(containerWidth: number | null, isMobile: boolean): EditorFit {
  const narrow = isMobile || (containerWidth !== null && containerWidth < NARROW_EDITOR_PX)
  return { compactToolbar: narrow, panelsAsSheets: narrow }
}
