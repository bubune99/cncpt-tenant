/**
 * Assertions for Kofi's client auto-continue decision.
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/kofi-continuation.assert.ts
 */
import assert from 'node:assert/strict'
import { decideAutoContinue, isBudgetStop, isLoopStop } from './kofi-continuation'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}
const base = { finishReason: 'tool-calls', budgetStop: false, count: 0, max: 3, wasStopped: false, queued: false }

check('continues a step-limited run (tool-calls) and counts it', () => {
  assert.deepEqual(decideAutoContinue(base), { continue: true, nextCount: 1 })
  assert.deepEqual(decideAutoContinue({ ...base, finishReason: 'length', count: 2 }), { continue: true, nextCount: 3 })
})
check('THE BUG: a budget stop also reports tool-calls but must NOT continue', () => {
  assert.deepEqual(decideAutoContinue({ ...base, budgetStop: true }), { continue: false, nextCount: 0, why: 'budget' })
})
check('a loop-guard stop (also tool-calls) must NOT continue', () => {
  assert.deepEqual(decideAutoContinue({ ...base, loopStop: true }), { continue: false, nextCount: 0, why: 'loop' })
  assert.equal(isLoopStop({ kofiLoopStop: true }), true)
  assert.equal(isLoopStop({ kofiLoopStop: 1 }), false)
})
check('stops at MAX_CONTINUATIONS', () => {
  assert.deepEqual(decideAutoContinue({ ...base, count: 3 }), { continue: false, nextCount: 0, why: 'max' })
})
check('user stop and queued message win', () => {
  assert.equal(decideAutoContinue({ ...base, wasStopped: true }).continue, false)
  assert.equal(decideAutoContinue({ ...base, queued: true }).continue, false)
})
check('natural finish does not continue', () => {
  assert.equal(decideAutoContinue({ ...base, finishReason: 'stop' }).continue, false)
  assert.equal(decideAutoContinue({ ...base, finishReason: undefined }).continue, false)
})
check('isBudgetStop reads message metadata strictly', () => {
  assert.equal(isBudgetStop({ kofiBudgetStop: true }), true)
  assert.equal(isBudgetStop({ kofiBudgetStop: 'true' }), false)
  assert.equal(isBudgetStop(undefined), false)
})

console.log(`\n${n} checks passed`)
