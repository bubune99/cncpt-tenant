/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/move.assert.ts
 */
import assert from 'node:assert/strict'
import { containerAt, crossMoveMessage, edgeBand, insertAfter, layoutOfRects, moveMessage, restingOn, sortDirectionFor, type DropCandidate } from './move'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('siblings shift by layout: stack, row, grid/bento', () => {
  assert.equal(sortDirectionFor('max-w-[1200px] mx-auto px-4'), 'vertical')
  assert.equal(sortDirectionFor('flex items-center gap-4'), 'horizontal')
  assert.equal(sortDirectionFor('flex flex-col gap-4'), 'vertical')
  assert.equal(sortDirectionFor('flex flex-col md:flex-row gap-8'), 'vertical')
  assert.equal(sortDirectionFor('grid grid-cols-1 md:grid-cols-3 gap-8'), 'grid')
  assert.equal(sortDirectionFor('md:grid md:grid-cols-2'), 'grid')
  assert.equal(sortDirectionFor(undefined), 'vertical')
})

check('the drop is described in plain words, above/below a neighbour', () => {
  const sibs = [
    { id: 'a', tag: 'section', children: [{ tag: 'h2', textContent: 'Join The Mission' }] },
    { id: 'b', tag: 'section', children: [{ tag: 'h2', textContent: 'Our Story' }] },
    { id: 'c', tag: 'p', textContent: 'A very long paragraph that goes on and on about things' },
  ]
  assert.equal(moveMessage(sibs, 'b', 'a'), 'Moved “Our Story” above “Join The Mission”')
  assert.equal(moveMessage(sibs, 'a', 'c'), 'Moved “Join The Mission” below “A very long paragraph that…”')
  assert.equal(moveMessage(sibs, 'b', 'b'), null)
  assert.equal(moveMessage(sibs, 'x', 'a'), null)
})

check('the strategy follows the MEASURED layout: row, stack, wrap/grid', () => {
  const R = (left: number, top: number, w = 100, h = 50) => ({ left, top, width: w, height: h })
  // photo | text side by side (different heights, same top)
  assert.equal(layoutOfRects([R(0, 100, 500, 400), R(520, 100, 500, 260)]), 'horizontal')
  // the same row wrapped to a stack on a narrow screen
  assert.equal(layoutOfRects([R(0, 100, 600, 400), R(0, 510, 600, 260)]), 'vertical')
  // a 2×2 grid / bento
  assert.equal(layoutOfRects([R(0, 0), R(110, 0), R(0, 60), R(110, 60)]), 'grid')
  // a stack of different heights and indents is still a stack
  assert.equal(layoutOfRects([R(0, 0, 300, 40), R(20, 44, 260, 120), R(0, 170, 300, 30)]), 'vertical')
  // one item / unmeasured → harmless default
  assert.equal(layoutOfRects([R(0, 0)]), 'vertical')
  assert.equal(layoutOfRects([null, R(0, 0)]), 'vertical')
})

// ---- across containers ----
const R = (left: number, top: number, w = 100, h = 50) => ({ left, top, width: w, height: h })
const C = (id: string, rect: ReturnType<typeof R>, depth: number, allowed = true, reason?: string): DropCandidate => ({ id, rect, depth, allowed, reason })

// Travel Requirements-ish: two page sections; the first holds a row with a photo column and a text column.
const page = [
  C('s1', R(0, 0, 1000, 600), 0),
  C('row', R(40, 40, 920, 520), 1),
  C('colPhoto', R(40, 40, 450, 520), 2),
  C('colText', R(510, 40, 450, 520), 2),
  C('textGroup', R(530, 100, 410, 300), 3),
  C('btn', R(540, 420, 160, 40), 3, false, "A section can't go inside a button"),
  C('s2', R(0, 600, 1000, 400), 0),
]

check('the deepest container under the pointer wins', () => {
  assert.equal(containerAt({ x: 700, y: 200 }, page).targetId, 'textGroup')
  assert.equal(containerAt({ x: 700, y: 480 }, page).targetId, 'colText')
  assert.equal(containerAt({ x: 200, y: 300 }, page).targetId, 'colPhoto')
  assert.equal(containerAt({ x: 500, y: 800 }, page).targetId, 's2')
})

check('between two page sections (their shared edge) → the page itself', () => {
  assert.equal(containerAt({ x: 500, y: 598 }, page).targetId, null)
  assert.equal(containerAt({ x: 500, y: 604 }, page).targetId, null)
  // off every container → page
  assert.equal(containerAt({ x: 500, y: 1200 }, page).targetId, null)
  // the edge band never swallows a small container whole
  assert.equal(edgeBand(R(0, 0, 1000, 20)), 3)
})

check('near a column edge counts as its parent: beside it, not inside it', () => {
  assert.equal(containerAt({ x: 512, y: 300 }, page).targetId, 'row')
})

check('the home container has no edge band (sorting near its edge stays put)', () => {
  assert.equal(containerAt({ x: 512, y: 300 }, page, ['colText']).targetId, 'colText')
  // overshooting the home column by a few px still sorts at home; well past it → beside it in the row
  assert.equal(containerAt({ x: 500, y: 300 }, page, ['colText']).targetId, 'colText')
  assert.equal(containerAt({ x: 300, y: 300 }, page, ['colText']).targetId, 'colPhoto')
})

check('a refusing container is skipped (no gap) and says why', () => {
  const hit = containerAt({ x: 600, y: 440 }, page)
  assert.equal(hit.targetId, 'colText')
  assert.deepEqual(hit.blocked, { id: 'btn', reason: "A section can't go inside a button" })
  assert.equal(containerAt({ x: 700, y: 200 }, page).blocked, null)
  // a refusal shallower than the target isn't reported
  const nested = [C('outer', R(0, 0, 500, 500), 0, false, 'no'), C('inner', R(100, 100, 200, 200), 1)]
  assert.deepEqual(containerAt({ x: 200, y: 200 }, nested), { targetId: 'inner', blocked: null, small: null })
  assert.deepEqual(containerAt({ x: 50, y: 50 }, nested).blocked, { id: 'outer', reason: 'no' })
})

check('a small container under the pointer is reported (to open up after a rest)', () => {
  const tiny = [C('sec', R(0, 0, 800, 400), 0), C('strip', R(100, 100, 600, 18), 1)]
  assert.equal(containerAt({ x: 300, y: 108 }, tiny).small, 'strip')
  assert.equal(containerAt({ x: 300, y: 300 }, tiny).small, null)
  // once opened (sticky) it takes the drop, edge band or not
  assert.equal(containerAt({ x: 300, y: 101 }, tiny, ['strip']).targetId, 'strip')
})

check('resting on the middle of a sibling (not its edges) opens it', () => {
  const sibs = [{ id: 'card1', rect: R(0, 0, 200, 200) }, { id: 'card2', rect: R(220, 0, 200, 200) }]
  assert.equal(restingOn({ x: 320, y: 100 }, sibs), 'card2')
  assert.equal(restingOn({ x: 225, y: 100 }, sibs), null)
  assert.equal(restingOn({ x: 210, y: 100 }, sibs), null)
})

check('entering a container over a block: before or after it, along the layout', () => {
  const r = R(100, 100, 200, 100)
  assert.equal(insertAfter(r, { x: 150, y: 120 }, 'vertical'), false)
  assert.equal(insertAfter(r, { x: 150, y: 180 }, 'vertical'), true)
  assert.equal(insertAfter(r, { x: 120, y: 180 }, 'horizontal'), false)
  assert.equal(insertAfter(r, { x: 280, y: 120 }, 'horizontal'), true)
  assert.equal(insertAfter(r, { x: 280, y: 150 }, 'grid'), true)
  assert.equal(insertAfter(r, { x: 50, y: 250 }, 'grid'), true)
  assert.equal(insertAfter(r, { x: 280, y: 50 }, 'grid'), false)
})

check('a move into another container is described by where it went', () => {
  assert.equal(crossMoveMessage({ tag: 'img', attrs: { alt: 'Passport' } }, { tag: 'div', children: [{ tag: 'p', textContent: 'x' }] }), 'Moved Image into Group')
  assert.equal(crossMoveMessage({ tag: 'img' }, { tag: 'div', label: 'Text group' }), 'Moved Image into Text group')
  assert.equal(crossMoveMessage({ tag: 'h2', textContent: 'Our Story' }, null), 'Moved “Our Story” onto the page')
})

console.log(`\n${n} checks passed`)
