/**
 * Write-time safety for stored page and partial content.
 *
 * Block textContent is rendered with innerHTML and page themeCSS inside a
 * <style> element, and both are written by roles (content_editor, CMS API
 * keys) below the staff and customers who view them. The renderers guard at
 * the sink (BlockRenderer, BlockPageRenderer via lib/theme-css); this module is the second
 * layer, applied by the write APIs, so stored content is already clean
 * wherever else it gets read.
 */

import { STORED_KEY } from '../page-css/stored'
import { sanitizeHtml } from '../sanitize-html'
import { themeCssProblem } from '../theme-css'
import type { Block } from './types'

/** Same test BlockRenderer uses to decide between text and innerHTML. */
export function containsHtml(text: string): boolean {
  return /<[a-z][\s\S]*>/i.test(text)
}

function cleanText(text: unknown): unknown {
  return typeof text === 'string' && containsHtml(text) ? sanitizeHtml(text) : text
}

/** Every textContent in the tree sanitized: children, interaction overlays and partial overrides. */
export function sanitizeBlockTree(blocks: ReadonlyArray<Block>): Block[] {
  return blocks.map((block) => {
    if (!block || typeof block !== 'object') return block
    const next: Block = { ...block }
    if (block.textContent !== undefined) next.textContent = cleanText(block.textContent) as string
    if (Array.isArray(block.children)) next.children = sanitizeBlockTree(block.children)
    if (block.interaction && Array.isArray(block.interaction.content)) {
      next.interaction = { ...block.interaction, content: sanitizeBlockTree(block.interaction.content) }
    }
    if (block.partialOverrides && typeof block.partialOverrides === 'object') {
      next.partialOverrides = Object.fromEntries(
        Object.entries(block.partialOverrides).map(([id, o]) => [
          id,
          o && typeof o === 'object' && o.textContent !== undefined ? { ...o, textContent: cleanText(o.textContent) as string } : o,
        ]),
      )
    }
    return next
  })
}

export type ContentWriteResult<T> = { ok: true; content: T } | { ok: false; error: string }

/**
 * Prepare `content` from a page/partial write request for storage: block
 * textContent sanitized wherever it sits, themeCSS checked.
 */
export function prepareContentForWrite<T>(content: T): ContentWriteResult<T> {
  if (Array.isArray(content)) return { ok: true, content: sanitizeBlockTree(content as Block[]) as T }
  if (!content || typeof content !== 'object') return { ok: true, content }

  const doc = { ...(content as Record<string, unknown>) }
  if (Array.isArray(doc.blocks)) doc.blocks = sanitizeBlockTree(doc.blocks as Block[])
  // Per-page CSS is compiled by the server only (lib/ade-bindings/page-css); a client never supplies it.
  delete doc[STORED_KEY]

  // Rendered inside <style>: only CSS variables and Google Fonts (lib/theme-css).
  const themeProblem = themeCssProblem(doc.themeCSS)
  if (themeProblem) return { ok: false, error: themeProblem }
  return { ok: true, content: doc as T }
}

/**
 * prepareContentForWrite for server-side writers (approved drafts, AI tools, imports, the
 * CLI, restores): the same sanitising, throwing when the content is refused. Every path
 * that stores page or partial content goes through one of the two (asserted in
 * security/content-writes.assert.ts).
 */
export function safeContent<T>(content: T): T {
  // Prisma's JsonNull / DbNull and other non-plain values pass through untouched.
  if (content && typeof content === 'object' && !Array.isArray(content) && Object.getPrototypeOf(content) !== Object.prototype) return content
  const prepared = prepareContentForWrite(content)
  if (!prepared.ok) throw new Error(prepared.error)
  return prepared.content
}
