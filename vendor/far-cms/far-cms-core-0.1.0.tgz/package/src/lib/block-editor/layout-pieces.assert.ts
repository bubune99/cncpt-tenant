/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/layout-pieces.assert.ts
 */
import assert from 'node:assert/strict'
import { FOOTER_PIECES, HEADER_PIECES } from './layout-pieces'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const ids = (blk: { id: string; children?: unknown[] }): string[] => [blk.id, ...((blk.children ?? []) as Array<{ id: string; children?: unknown[] }>).flatMap(ids)]

check('the owner’s pieces, in plain words', () => {
  assert.deepEqual(HEADER_PIECES.map((p) => p.name), ['Logo', 'Menu', 'Social icons', 'Button', 'Search', 'Text'])
  assert.deepEqual(FOOTER_PIECES.map((p) => p.name), ['Logo & tagline', 'Link column', 'Contact details', 'Social icons', 'Newsletter sign-up', 'Copyright', 'Cookie settings link'])
})

check('each build is a fresh tree with unique ids and a label', () => {
  for (const p of [...HEADER_PIECES, ...FOOTER_PIECES]) {
    const a = p.build(), b = p.build()
    assert.ok(a.label, p.name)
    const all = [...ids(a), ...ids(b)]
    assert.equal(new Set(all).size, all.length, `${p.name}: ids unique across builds`)
  }
})

console.log(`\n${n} checks passed`)
