/**
 * Pieces for the header and footer editors (owner): the parts a header or
 * footer is made of, in plain words. Each builds a fresh block tree. A piece
 * inside a container goes INTO the selected container; otherwise at the end.
 * "{year}" in text renders as the current year (block renderer).
 */

import type { Block } from "./types"
import { generateId } from "./tree-utils"

export interface PieceDef {
  id: string
  name: string
  description: string
  build: () => Block
}

function b(tag: string, className: string, text?: string | null, children?: Block[], attrs?: Record<string, string>): Block {
  return {
    id: generateId(),
    tag,
    className,
    ...(text ? { textContent: text } : {}),
    ...(children?.length ? { children } : {}),
    ...(attrs ? { attrs } : {}),
  } as Block
}
const labelled = (label: string, block: Block): Block => ({ ...block, label })

const LINK = "text-sm font-semibold uppercase tracking-wide hover:opacity-80"
const SOCIAL = "inline-grid h-9 w-9 place-items-center rounded-full border border-current/30 text-xs font-bold"

export const HEADER_PIECES: ReadonlyArray<PieceDef> = [
  { id: "logo", name: "Logo", description: "Your logo, linking home", build: () => labelled("Logo", b("a", "inline-flex items-center", null, [b("img", "h-10 w-auto", null, undefined, { src: "/logo.png", alt: "Home" })], { href: "/" })) },
  {
    id: "menu",
    name: "Menu",
    description: "Links to your main pages",
    build: () => labelled("Menu", b("nav", "flex flex-wrap items-center gap-6", null, [b("a", LINK, "Home", undefined, { href: "/" }), b("a", LINK, "About", undefined, { href: "/about" }), b("a", LINK, "Get involved", undefined, { href: "/get-involved" })])),
  },
  {
    id: "social",
    name: "Social icons",
    description: "Links to your social profiles",
    build: () => labelled("Social icons", b("div", "flex items-center gap-2", null, [b("a", SOCIAL, "IG", undefined, { href: "https://instagram.com/" }), b("a", SOCIAL, "f", undefined, { href: "https://facebook.com/" }), b("a", SOCIAL, "X", undefined, { href: "https://x.com/" })])),
  },
  { id: "button", name: "Button", description: "A call to action, like Donate", build: () => labelled("Button", b("a", "inline-block rounded border-2 border-current px-5 py-2 text-sm font-bold uppercase tracking-wide", "Donate", undefined, { href: "/donate" })) },
  { id: "search", name: "Search", description: "A search box", build: () => labelled("Search", b("input", "h-9 w-48 rounded border px-3 text-sm text-black", null, undefined, { type: "search", placeholder: "Search", "aria-label": "Search" })) },
  { id: "text", name: "Text", description: "A short line of text", build: () => labelled("Text", b("p", "text-sm", "Short message")) },
]

export const FOOTER_PIECES: ReadonlyArray<PieceDef> = [
  {
    id: "logo-tagline",
    name: "Logo & tagline",
    description: "Your logo with one line about you",
    build: () => labelled("Logo & tagline", b("div", "space-y-3", null, [b("img", "h-10 w-auto", null, undefined, { src: "/logo.png", alt: "Logo" }), b("p", "max-w-xs text-sm opacity-80", "One line about what you do.")])),
  },
  {
    id: "links",
    name: "Link column",
    description: "A heading with a list of links",
    build: () => labelled("Link column", b("div", "space-y-3", null, [b("h4", "text-sm font-bold uppercase tracking-wide", "Explore"), b("div", "flex flex-col gap-2 text-sm", null, [b("a", "hover:underline", "About", undefined, { href: "/about" }), b("a", "hover:underline", "Initiatives", undefined, { href: "/initiatives" }), b("a", "hover:underline", "Get involved", undefined, { href: "/get-involved" })])])),
  },
  {
    id: "contact",
    name: "Contact details",
    description: "Email, phone and address",
    build: () => labelled("Contact details", b("div", "space-y-2 text-sm", null, [b("h4", "text-sm font-bold uppercase tracking-wide", "Contact"), b("a", "block hover:underline", "info@example.org", undefined, { href: "mailto:info@example.org" }), b("p", "opacity-80", "City, Country")])),
  },
  {
    id: "social",
    name: "Social icons",
    description: "Links to your social profiles",
    build: () => labelled("Social icons", b("div", "flex items-center gap-2", null, [b("a", SOCIAL, "IG", undefined, { href: "https://instagram.com/" }), b("a", SOCIAL, "f", undefined, { href: "https://facebook.com/" }), b("a", SOCIAL, "X", undefined, { href: "https://x.com/" })])),
  },
  {
    id: "newsletter",
    name: "Newsletter sign-up",
    description: "An email box to join your list",
    build: () => labelled("Newsletter sign-up", { ...b("div", "", null), componentName: "NewsletterSignup" } as Block),
  },
  { id: "copyright", name: "Copyright", description: "© with this year, updated automatically", build: () => labelled("Copyright", b("p", "text-xs opacity-70", "© {year} Your organization. All rights reserved.")) },
  { id: "cookie", name: "Cookie settings link", description: "Lets visitors change their cookie choices", build: () => labelled("Cookie settings link", b("a", "text-xs underline opacity-80", "Cookie settings", undefined, { href: "#cookie-settings", "data-cookie-settings": "" })) },
]

export function piecesFor(part: "header" | "footer"): ReadonlyArray<PieceDef> {
  return part === "header" ? HEADER_PIECES : FOOTER_PIECES
}
