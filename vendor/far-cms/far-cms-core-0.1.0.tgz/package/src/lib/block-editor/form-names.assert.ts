/**
 * The block list offers one obvious 'Form', and it is the one that collects answers.
 * Walk 2026-11-19 'Build a form, put it on a page, read what comes in': the list had 'Form' (an
 * empty HTML form that saves nothing) and 'Managed Form' (the real one), and the obvious name was
 * the wrong one. Run: node_modules/.bin/tsx src/lib/block-editor/form-names.assert.ts
 */
import assert from 'node:assert/strict'
import { BLOCK_TEMPLATES } from './block-templates'

const labels = BLOCK_TEMPLATES.map((t) => t.label)
assert.equal(new Set(labels).size, labels.length, 'template names are unique (they are lookup keys)')
const form = BLOCK_TEMPLATES.find((t) => t.label === 'Form')
assert.equal(form?.componentName, 'FormBlock', "'Form' is the block that shows a form from Forms")
assert.match(form?.description ?? '', /Submissions/)
assert.ok(!labels.includes('Managed Form'))
const wrapper = BLOCK_TEMPLATES.find((t) => t.tag === 'form')
assert.equal(wrapper?.label, 'Form fields wrapper')
assert.match(wrapper?.description ?? '', /not saved/)
console.log('ok - one obvious Form, and it collects answers\n\n1 checks passed')
