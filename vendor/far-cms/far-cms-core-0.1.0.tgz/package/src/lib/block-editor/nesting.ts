/**
 * What may go inside what when a block is dragged into another container —
 * pure rules, asserted by nesting.assert.ts. The canvas asks these before it
 * opens a gap in a container; a refusal comes with a plain-words reason
 * ("A section can't go inside a button") that the drag shows as a hint.
 */

import { isContainerTag } from "./types"

export interface NestBlock {
  id?: string
  tag: string
  componentName?: string
  partialId?: string
  locked?: boolean
  children?: NestBlock[]
}

export type NestVerdict = { ok: true } | { ok: false; reason: string }

/** Text-level blocks: they hold words (and small inline pieces), never sections or groups. */
const TEXT_LEVEL = new Set(["h1", "h2", "h3", "h4", "h5", "h6", "p", "span", "a", "button", "label", "figcaption", "summary", "legend", "strong", "em", "b", "i", "u", "small", "code", "mark", "sup", "sub", "s"])

/** What may sit inside a text-level block. */
const INLINE = new Set(["span", "strong", "em", "b", "i", "u", "small", "br", "img", "svg", "code", "mark", "sup", "sub", "s", "abbr", "time", "a", "button", "label", "input"])

/** Blocks that never hold anything. */
const VOID = new Set(["img", "video", "iframe", "hr", "br", "input", "textarea", "svg", "option", "audio", "source"])

const INTERACTIVE = new Set(["a", "button"])

/** Children that only make sense inside one kind of parent, and the parents that hold only them. */
const ONLY_INSIDE: Record<string, string[]> = {
  li: ["ul", "ol"],
  option: ["select"],
  tr: ["table", "thead", "tbody", "tfoot"],
  td: ["tr"],
  th: ["tr"],
  thead: ["table"],
  tbody: ["table"],
  tfoot: ["table"],
  caption: ["table"],
}
const HOLDS_ONLY: Record<string, string[]> = {
  ul: ["li"],
  ol: ["li"],
  select: ["option"],
  table: ["thead", "tbody", "tfoot", "tr", "caption"],
  thead: ["tr"],
  tbody: ["tr"],
  tfoot: ["tr"],
  tr: ["td", "th"],
}

const NOUNS: Record<string, string> = {
  section: "section",
  header: "header",
  footer: "footer",
  main: "section",
  article: "section",
  aside: "section",
  nav: "menu",
  div: "group",
  h1: "heading",
  h2: "heading",
  h3: "subheading",
  h4: "subheading",
  h5: "subheading",
  h6: "subheading",
  p: "paragraph",
  span: "piece of text",
  a: "button",
  button: "button",
  label: "label",
  img: "image",
  video: "video",
  iframe: "video",
  ul: "list",
  ol: "list",
  li: "list item",
  form: "form",
  blockquote: "quote",
  figure: "figure",
  figcaption: "caption",
  table: "table",
  tr: "table row",
  td: "table cell",
  th: "table cell",
  select: "dropdown",
  option: "dropdown option",
}

/** Smart blocks and shared sections render their own content: nothing goes inside them. */
export function isLiveBlock(b: Pick<NestBlock, "componentName" | "partialId">): boolean {
  return !!b.componentName || !!b.partialId
}

/** "section", "button", "shared section" — a block as a person would call it, for hints. */
export function nounFor(b: NestBlock): string {
  if (b.componentName === "PartialReference" || b.partialId) return "shared section"
  if (b.componentName) return "live block"
  return NOUNS[b.tag] ?? "block"
}

function withArticle(noun: string): string {
  return `${/^[aeiou]/i.test(noun) ? "an" : "a"} ${noun}`
}

function capitalise(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1)
}

/**
 * Whether the canvas treats a block as something you can drop INTO
 * (its own drop area), regardless of what is being dragged.
 */
export function acceptsChildren(b: NestBlock): boolean {
  if (isLiveBlock(b) || VOID.has(b.tag)) return false
  // A heading/paragraph holding only its own words isn't a drop area (its text would be lost).
  return isContainerTag(b.tag) || !!b.children?.length
}

/**
 * May `child` go inside `parent` (null = the page itself)? Moves within the
 * child's own container never ask — those are always allowed.
 */
export function canNest(parent: NestBlock | null, child: NestBlock): NestVerdict {
  const what = capitalise(withArticle(nounFor(child)))
  const onlyIn = ONLY_INSIDE[child.tag]

  if (!parent) {
    if (onlyIn) return { ok: false, reason: `${what} only goes inside ${withArticle(nounFor({ tag: onlyIn[0] }))}` }
    return { ok: true }
  }

  const where = withArticle(nounFor(parent))
  if (parent.locked) return { ok: false, reason: `This ${nounFor(parent)} is locked` }
  if (isLiveBlock(parent) || VOID.has(parent.tag)) return { ok: false, reason: `${capitalise(where)} can't hold other blocks` }

  const holdsOnly = HOLDS_ONLY[parent.tag]
  if (holdsOnly && !holdsOnly.includes(child.tag)) {
    return { ok: false, reason: `Only ${nounFor({ tag: holdsOnly[0] })}s go inside ${where}` }
  }
  if (onlyIn && !onlyIn.includes(parent.tag)) {
    return { ok: false, reason: `${what} only goes inside ${withArticle(nounFor({ tag: onlyIn[0] }))}` }
  }

  if (TEXT_LEVEL.has(parent.tag)) {
    if (isLiveBlock(child) || !INLINE.has(child.tag)) return { ok: false, reason: `${what} can't go inside ${where}` }
    if (INTERACTIVE.has(parent.tag) && INTERACTIVE.has(child.tag)) return { ok: false, reason: `${what} can't go inside ${where}` }
  }

  if (parent.tag === "form" && child.tag === "form") return { ok: false, reason: "A form can't go inside another form" }

  return { ok: true }
}

export interface TreeEntry<B extends NestBlock = NestBlock> {
  block: B
  parentId: string | null
  depth: number
}

/** id → block, parent and depth, in one walk (the drag looks these up on every pointer move). */
export function indexTree<B extends NestBlock>(blocks: ReadonlyArray<B>): Map<string, TreeEntry<B>> {
  const map = new Map<string, TreeEntry<B>>()
  const walk = (list: ReadonlyArray<B>, parentId: string | null, depth: number) => {
    for (const b of list) {
      if (b.id) map.set(b.id, { block: b, parentId, depth })
      if (b.children?.length) walk(b.children as B[], b.id ?? null, depth + 1)
    }
  }
  walk(blocks, null, 0)
  return map
}

function collectIds(b: NestBlock, into: Set<string>) {
  if (b.id) into.add(b.id)
  for (const c of b.children ?? []) collectIds(c, into)
}

/**
 * Containers the dragged block may NOT be dropped into, before any nesting
 * rule: itself and everything inside it; and the siblings it started among,
 * with everything inside them — over a sibling the drag reorders (cards in a
 * grid swap places rather than swallowing each other; page sections only
 * reorder). Pass the tree as it was when the drag began. `openedId` is a
 * sibling the pointer has rested on long enough to open it as a target.
 */
export function excludedTargets(index: Map<string, TreeEntry>, roots: ReadonlyArray<NestBlock>, activeId: string, openedId: string | null = null): Set<string> {
  const out = new Set<string>()
  const active = index.get(activeId)
  if (!active) return out
  collectIds(active.block, out)
  const siblings = active.parentId ? index.get(active.parentId)?.block.children ?? [] : roots
  for (const s of siblings) {
    if (s.id && s.id !== activeId && s.id !== openedId) collectIds(s, out)
  }
  return out
}
