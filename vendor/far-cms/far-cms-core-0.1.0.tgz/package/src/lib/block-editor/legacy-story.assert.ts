/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/legacy-story.assert.ts
 */
import assert from 'node:assert/strict'
import type { Block } from './types'
import { isLegacyStoryColumn, liftLegacyStory } from './legacy-story'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const legacy: Block = {
  id: 'story', tag: 'section', className: 'max-w-3xl mx-auto px-6 py-12 space-y-5 text-lg leading-relaxed text-gray-800',
  children: [{ id: 'h', tag: 'h2', className: 'text-3xl', textContent: 'Our goal', parentId: 'story' }],
} as Block

check('the bare story column is lifted into a light full-width section', () => {
  const page = [{ id: 'hero', tag: 'section', className: 'bg-[#022b39]' } as Block, legacy]
  const out = liftLegacyStory(page)
  assert.equal(out[0], page[0], 'other blocks untouched (same object)')
  assert.equal(out[1].className, 'bg-white px-6 py-12')
  const inner = out[1].children![0]
  assert.equal(inner.id, 'story', 'the original block id is kept (spotlights, links)')
  assert.equal(inner.tag, 'div')
  assert.equal(inner.className, 'max-w-3xl mx-auto space-y-5 text-lg leading-relaxed text-gray-800')
  assert.equal(inner.children![0].textContent, 'Our goal')
})

check('stored content is never mutated', () => {
  const before = JSON.stringify(legacy)
  liftLegacyStory([legacy])
  assert.equal(JSON.stringify(legacy), before)
})

check('only the legacy shape: anything with its own background, or the new template, is left alone', () => {
  assert.equal(isLegacyStoryColumn({ ...legacy, className: legacy.className + ' bg-white' } as Block), false)
  assert.equal(isLegacyStoryColumn({ ...legacy, tag: 'div' } as Block), false, 'the template’s inner column is a div')
  const nested = liftLegacyStory([{ id: 'wrap', tag: 'div', className: '', children: [legacy] } as Block])
  assert.equal(nested[0].children![0].className, 'bg-white px-6 py-12', 'found at any depth')
})

console.log(`\n${n} checks passed`)
