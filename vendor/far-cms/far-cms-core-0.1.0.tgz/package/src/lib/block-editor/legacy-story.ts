/**
 * Older initiative pages carry the story ("Our goal / Progress so far / Who
 * it helps") as a bare centred column — dark text with no background — so on
 * the site's dark body it is unreadable. Rather than edit the client's pages,
 * the renderer lifts that column into the light story section the template
 * now uses, at render time. Stored content is never touched.
 * Pure; asserted by legacy-story.assert.ts.
 */

import type { Block } from './types'

const COLUMN = ['max-w-3xl', 'mx-auto', 'text-gray-800']
const OUTER = 'bg-white px-6 py-12'
const INNER_DROP = new Set(['px-6', 'py-12'])

function classes(b: Block): string[] {
  return (b.className ?? '').split(/\s+/).filter(Boolean)
}

/** A bare story column: the old shape, with no background of its own. */
export function isLegacyStoryColumn(b: Block): boolean {
  const c = classes(b)
  return b.tag === 'section' && COLUMN.every((k) => c.includes(k)) && !c.some((k) => /^bg-/.test(k))
}

/** The same blocks with any legacy story column wrapped in a light section (new objects; input untouched). */
export function liftLegacyStory(blocks: ReadonlyArray<Block>): Block[] {
  return blocks.map((b) => {
    if (isLegacyStoryColumn(b)) {
      const inner: Block = { ...b, tag: 'div', className: classes(b).filter((k) => !INNER_DROP.has(k)).join(' ') }
      return { id: `${b.id}__story`, tag: 'section', className: OUTER, parentId: b.parentId ?? null, children: [{ ...inner, parentId: `${b.id}__story` }] } as Block
    }
    return b.children?.length ? { ...b, children: liftLegacyStory(b.children) } : b
  })
}
