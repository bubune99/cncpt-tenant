/**
 * Clear All is an edit like any other: it is added to the undo history, so Undo brings the page back.
 * Pure; asserted by clear-all.assert.ts.
 */
export interface HistoryState<B> { blocks: B[]; history: B[][]; historyIndex: number }

const MAX_STEPS = 50

export function clearedHistory<B, S extends HistoryState<B>>(state: S): S {
  if (state.blocks.length === 0) return state
  const history = [...state.history.slice(0, state.historyIndex + 1), [] as B[]]
  const kept = history.length > MAX_STEPS ? history.slice(history.length - MAX_STEPS) : history
  return { ...state, blocks: [] as B[], history: kept, historyIndex: kept.length - 1 }
}
