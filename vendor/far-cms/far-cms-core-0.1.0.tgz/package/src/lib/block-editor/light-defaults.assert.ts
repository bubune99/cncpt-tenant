/**
 * Blocks added from the block list must read on the site's own (white) pages. Found on the
 * 2026-11-19 walk 'Make a new page and put it live': Heading 1 arrived white on white, so the
 * published page looked empty. Run: node_modules/.bin/tsx src/lib/block-editor/light-defaults.assert.ts
 */
import assert from 'node:assert/strict'
import { BLOCK_TEMPLATES } from './block-templates'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const cls = (label: string) => BLOCK_TEMPLATES.find((t) => t.label === label)?.defaultClassName ?? ''
/** A block painting its own solid color (a blue button, a Stripe button, a gradient) keeps white text. */
const solid = (c: string) => /(^|\s)bg-(\[#|gradient|[a-z]+-[5-9]00(?!\/)\b|slate-900|black\b)/.test(c)

check('text blocks are dark on a white page', () => {
  for (const l of ['Heading 1', 'Heading 2', 'Heading 3']) assert.match(cls(l), /text-slate-900/, l)
  for (const l of ['Paragraph', 'Small Text', 'Blockquote', 'List (UL)', 'Label']) assert.match(cls(l), /text-slate-[5-7]00/, l)
})
check('no block uses white text or see-through white lines unless it paints its own background', () => {
  for (const t of BLOCK_TEMPLATES) {
    const c = t.defaultClassName ?? ''
    if (solid(c)) continue
    assert.doesNotMatch(c, /(^|\s)(hover:)?text-white(\/\d+)?(\s|$)/, `${t.label}: ${c}`)
    assert.doesNotMatch(c, /(border|bg|ring|placeholder:text)-white\/\d+/, `${t.label}: ${c}`)
  }
})
check('blocks with their own solid color keep white text', () => {
  assert.match(cls('Button'), /bg-blue-600.*text-white/)
  assert.match(cls('Stripe Checkout'), /text-white/)
})
check('links and badges are dark enough to read on white', () => {
  assert.match(cls('Link'), /text-blue-700/)
  assert.match(cls('Badge'), /text-blue-700/)
})
console.log(`\n${n} checks passed`)
