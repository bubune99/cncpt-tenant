/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/canvas-breakpoints.assert.ts
 */
import assert from 'node:assert/strict'
import {
  breakpointWidths,
  canvasBreakpointCss,
  canvasClass,
  canvasClassName,
  canvasSelector,
  canvasStyleWidth,
  widthPredicate,
  DEVICE_PX,
  DEVICE_WIDTH,
  DESKTOP_MIN_WIDTH,
  type CssNode,
} from './canvas-breakpoints'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// Tailwind 4.1.18's real output for these classes (both shapes: dev = nested, prod = lowered).
const style = (selector: string, declarations: string, children: CssNode[] = []): CssNode => ({ type: 'style', selector, declarations, children })
const media = (condition: string, children: CssNode[]): CssNode => ({ type: 'media', condition, children })
const decls = (declarations: string): CssNode => ({ type: 'decls', declarations })
const layer = (children: CssNode[]): CssNode => ({ type: 'group', prelude: '@layer utilities', children })

const NESTED: CssNode[] = [layer([
  style('.hidden', 'display: none;'),
  style('.text-sm', 'font-size: var(--text-sm);'),
  style('.max-md\\:hidden', '', [media('(width < 48rem)', [decls('display: none;')])]),
  style('.min-\\[900px\\]\\:p-4', '', [media('(width >= 900px)', [decls('padding: 1rem;')])]),
  style('.md\\:block', '', [media('(width >= 48rem)', [decls('display: block;')])]),
  style('.md\\:text-lg', '', [media('(width >= 48rem)', [decls('font-size: var(--text-lg);')])]),
  style('.md\\:hover\\:bg-red-500', '', [media('(width >= 48rem)', [style('&:hover', '', [media('(hover: hover)', [decls('background-color: red;')])])])]),
  style('.lg\\:grid-cols-3', '', [media('(width >= 64rem)', [decls('grid-template-columns: repeat(3, minmax(0, 1fr));')])]),
  style('.\\32 xl\\:p-8', '', [media('(width >= 96rem)', [decls('padding: 2rem;')])]),
])]

const LOWERED: CssNode[] = [layer([
  style('.hidden', 'display: none;'),
  style('.text-sm', 'font-size: var(--text-sm);'),
  media('not all and (min-width: 48rem)', [style('.max-md\\:hidden', 'display: none;')]),
  media('(min-width: 900px)', [style('.min-\\[900px\\]\\:p-4', 'padding: 1rem;')]),
  media('(min-width: 48rem)', [
    style('.md\\:block', 'display: block;'),
    style('.md\\:text-lg', 'font-size: var(--text-lg);'),
    media('(hover: hover)', [style('.md\\:hover\\:bg-red-500:hover', 'background-color: red;')]),
    style('.container', 'max-width: 48rem;'),
  ]),
  media('(min-width: 64rem)', [style('.lg\\:grid-cols-3', 'grid-template-columns: repeat(3, minmax(0, 1fr));')]),
  media('(min-width: 96rem)', [style('.\\32 xl\\:p-8', 'padding: 2rem;')]),
])]

/** Simulate the cascade for a property: base rules (window), window media rules, then the canvas's rules. */
function resolve(nodes: CssNode[], className: string, windowWidth: number, canvasWidth: number, prop: string): string | null {
  const classes = new Set(canvasClassName(className).split(/\s+/))
  const unescape = (sel: string) => sel.replace(/^\./, '').replace(/\\32 /g, '2').replace(/\\(.)/g, '$1')
  let value: string | null = null
  const take = (selector: string, d: string) => {
    const name = unescape(selector.split(':hover')[0])
    const m = new RegExp(`${prop}:\\s*([^;]+);`).exec(d)
    if (m && classes.has(name)) value = m[1].trim()
  }
  const walk = (list: CssNode[], sel: string | null, ok: boolean) => {
    for (const x of list) {
      if (x.type === 'group') walk(x.children, sel, ok)
      else if (x.type === 'media') { const t = widthPredicate(x.condition); walk(x.children, sel, ok && (t ? t(windowWidth) : true)) }
      else if (x.type === 'style') { const s = x.selector.replace('&', sel ?? ''); if (ok) take(s, x.declarations); walk(x.children, s, ok) }
      else if (ok && sel) take(sel, x.declarations)
    }
  }
  walk(nodes, null, true)
  // the canvas sheet comes last in the same layer
  for (const rule of canvasBreakpointCss(nodes, canvasWidth).split('\n').filter(Boolean)) {
    const m = /\{(\.[^{]+)\{([^}]*)\}/.exec(rule.replace(/^@layer utilities/, ''))
    if (m) for (const s of m[1].split(', ')) take(s, m[2])
  }
  return value
}

check('classes starting with a breakpoint get the canvas prefix; the rest stay', () => {
  assert.equal(canvasClass('md:text-lg'), 'cq-md:text-lg')
  assert.equal(canvasClass('lg:grid-cols-3'), 'cq-lg:grid-cols-3')
  assert.equal(canvasClass('max-md:hidden'), 'cq-max-md:hidden')
  assert.equal(canvasClass('2xl:p-8'), 'cq-2xl:p-8')
  assert.equal(canvasClass('min-[900px]:p-4'), 'cq-min-[900px]:p-4')
  assert.equal(canvasClass('md:hover:bg-red-500'), 'cq-md:hover:bg-red-500')
  assert.equal(canvasClass('hover:md:bg-red-500'), 'hover:md:bg-red-500')
  assert.equal(canvasClass('text-sm'), 'text-sm')
  assert.equal(canvasClass('bg-[url(a:b)]'), 'bg-[url(a:b)]')
  assert.equal(canvasClass('mdx:p-2'), 'mdx:p-2')
  assert.equal(canvasClass('cq-md:text-lg'), 'cq-md:text-lg') // idempotent
  assert.equal(canvasClassName('text-sm  md:text-lg\nlg:p-4'), 'text-sm  cq-md:text-lg\ncq-lg:p-4')
  const same = 'flex gap-4'
  assert.equal(canvasClassName(same), same)
})

check('selectors: breakpoint classes re-targeted, other parts dropped', () => {
  assert.equal(canvasSelector('.md\\:text-lg'), '.cq-md\\:text-lg')
  assert.equal(canvasSelector('.md\\:hover\\:bg-red-500:hover'), '.cq-md\\:hover\\:bg-red-500:hover')
  assert.equal(canvasSelector('.\\32 xl\\:p-8'), '.cq-\\32 xl\\:p-8')
  assert.equal(canvasSelector('.max-md\\:hidden'), '.cq-max-md\\:hidden')
  assert.equal(canvasSelector('.min-\\[900px\\]\\:p-4'), '.cq-min-\\[900px\\]\\:p-4')
  assert.equal(canvasSelector('.container'), null)
  assert.equal(canvasSelector('.md\\:a, .container, .lg\\:b > p'), '.cq-md\\:a, .cq-lg\\:b > p')
})

check('width-only media conditions, both Tailwind shapes; anything else is not', () => {
  const at = (c: string, w: number) => widthPredicate(c)!(w)
  assert.equal(at('(width >= 48rem)', 768), true)
  assert.equal(at('(width >= 48rem)', 767), false)
  assert.equal(at('(width < 48rem)', 390), true)
  assert.equal(at('(min-width: 48rem)', 820), true)
  assert.equal(at('not all and (min-width: 48rem)', 390), true)
  assert.equal(at('not all and (min-width: 48rem)', 820), false)
  assert.equal(at('(min-width: 40rem) and (max-width: 63.99rem)', 820), true)
  assert.equal(at('(48rem <= width)', 820), true)
  assert.equal(at('screen and (max-width: 600px)', 390), true)
  assert.equal(widthPredicate('(hover: hover)'), null)
  assert.equal(widthPredicate('print'), null)
  assert.equal(widthPredicate('(prefers-reduced-motion: reduce)'), null)
})

check('the width the canvas styles for: phone/tablet fixed; desktop = canvas, at least lg', () => {
  assert.equal(canvasStyleWidth('390px', 1440), 390)
  assert.equal(canvasStyleWidth('820px', 1440), 820)
  assert.equal(canvasStyleWidth('375px', 0), 375)
  assert.equal(canvasStyleWidth('100%', 700), 1024) // 1068 layout with panels open: still desktop
  assert.equal(canvasStyleWidth('100%', 1600), 1600)
  assert.equal(canvasStyleWidth('100%', 0), 1024)
})

for (const [shape, nodes] of [['nested (dev)', NESTED], ['lowered (prod)', LOWERED]] as const) {
  check(`${shape}: "text-sm md:text-lg" shows the PHONE style at Phone on a wide window`, () => {
    assert.equal(resolve(nodes, 'text-sm md:text-lg', 1440, 390, 'font-size'), 'var(--text-sm)')
    assert.equal(resolve(nodes, 'text-sm md:text-lg', 1440, 820, 'font-size'), 'var(--text-lg)')
    assert.equal(resolve(nodes, 'text-sm md:text-lg', 1440, 1024, 'font-size'), 'var(--text-lg)')
    // and a narrow window can still show Desktop
    assert.equal(resolve(nodes, 'text-sm md:text-lg', 600, 1024, 'font-size'), 'var(--text-lg)')
    // without the rewrite the window decides (the bug)
    assert.notEqual(canvasClassName('text-sm md:text-lg'), 'text-sm md:text-lg')
  })

  check(`${shape}: device visibility, grids, arbitrary and 2xl breakpoints follow the device`, () => {
    assert.equal(resolve(nodes, 'max-md:hidden', 1440, 390, 'display'), 'none')
    assert.equal(resolve(nodes, 'max-md:hidden', 600, 820, 'display'), null)
    assert.equal(resolve(nodes, 'hidden md:block', 1440, 390, 'display'), 'none')
    assert.equal(resolve(nodes, 'hidden md:block', 1440, 820, 'display'), 'block')
    assert.equal(resolve(nodes, 'lg:grid-cols-3', 1440, 820, 'grid-template-columns'), null)
    assert.equal(resolve(nodes, 'lg:grid-cols-3', 1440, 1024, 'grid-template-columns'), 'repeat(3, minmax(0, 1fr))')
    assert.equal(resolve(nodes, 'min-[900px]:p-4', 1440, 820, 'padding'), null)
    assert.equal(resolve(nodes, '2xl:p-8', 1600, 1536, 'padding'), '2rem')
    assert.equal(resolve(nodes, '2xl:p-8', 1600, 1200, 'padding'), null)
  })

  check(`${shape}: emitted rules keep their @layer and non-width wrappers (hover)`, () => {
    const css = canvasBreakpointCss(nodes, 820)
    assert.ok(css.includes('@layer utilities{.cq-md\\:text-lg{font-size: var(--text-lg);}}'), css)
    assert.ok(css.includes('@layer utilities{@media (hover: hover){.cq-md\\:hover\\:bg-red-500:hover{background-color: red;}}}'), css)
    assert.ok(!css.includes('cq-lg'))
    assert.ok(!css.includes('.container'))
    assert.ok(!css.includes('max-md')) // 820 is not < 48rem
    assert.ok(canvasBreakpointCss(nodes, 390).includes('.cq-max-md\\:hidden{display: none;}'))
  })
}

check('two canvases at different devices stay apart (scoped, same specificity)', () => {
  assert.equal(
    canvasSelector('.md\\:text-lg', 'r1'),
    '.cq-md\\:text-lg:where([data-canvas-scope="r1"], [data-canvas-scope="r1"] *)'
  )
  assert.equal(
    canvasSelector('.md\\:before\\:x::before', 'r1'),
    '.cq-md\\:before\\:x:where([data-canvas-scope="r1"], [data-canvas-scope="r1"] *)::before'
  )
  const css = canvasBreakpointCss(LOWERED, 820, 'ed')
  assert.ok(css.includes('.cq-md\\:text-lg:where([data-canvas-scope="ed"], [data-canvas-scope="ed"] *){font-size: var(--text-lg);}'), css)
})

check('one set of device widths: phone/tablet/desktop land on bare / md: / lg:', () => {
  assert.equal(canvasStyleWidth(DEVICE_WIDTH.phone, 1440), DEVICE_PX.phone)
  assert.equal(canvasStyleWidth(DEVICE_WIDTH.tablet, 1440), DEVICE_PX.tablet)
  assert.equal(canvasStyleWidth(DEVICE_WIDTH.desktop, 700), DESKTOP_MIN_WIDTH)
  const md = widthPredicate('(width >= 48rem)')!
  const lg = widthPredicate('(width >= 64rem)')!
  const sm = widthPredicate('(width >= 40rem)')!
  assert.deepEqual([sm(DEVICE_PX.phone), md(DEVICE_PX.phone)], [false, false])
  assert.deepEqual([md(DEVICE_PX.tablet), lg(DEVICE_PX.tablet)], [true, false])
  assert.equal(lg(DESKTOP_MIN_WIDTH), true)
})

check('the CSS only changes across breakpoint widths', () => {
  assert.deepEqual(breakpointWidths(LOWERED), [768, 900, 1024, 1536])
  assert.deepEqual(breakpointWidths(NESTED), [768, 900, 1024, 1536])
})

console.log(`\n${n} checks passed`)
