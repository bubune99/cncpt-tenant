/**
 * "Unsaved changes" means the page differs from what was last saved or loaded.
 * Found 2026-11-16 on staging: add a block, Undo it, and the builder still said
 * Unsaved changes, while Save answered "Page not saved: Nothing has changed".
 * Run: node_modules/.bin/tsx src/lib/block-editor/unsaved.assert.ts
 */
import assert from 'node:assert/strict'
import { editorReducer, type EditorState } from './editor-reducer'
import type { Block } from './types'
import type { SavedPage } from './storage'

let n = 0
const check = (name: string, fn: () => void): void => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const h1: Block = { id: 'a', tag: 'h1', className: 'text-4xl', textContent: 'Hello' } as Block
const p: Block = { id: 'b', tag: 'p', className: 'text-base', textContent: 'World' } as Block
const page = (blocks: Block[]): SavedPage => ({ id: 'pg', slug: 's', title: 'T', blocks, status: 'draft', createdAt: 'x', updatedAt: 'y' } as SavedPage)
const blank = {
  blocks: [], selectedBlockId: null, hoveredBlockId: null, dragState: null, clipboard: null,
  history: [[]], historyIndex: 0, currentPage: null, hasUnsavedChanges: false, savedBlocks: [],
  saveStatus: 'idle', lastSavedAt: null, isLoading: false, jsxSyncDirection: null, viewedFile: null, activeSpotlights: [],
} as EditorState
const loaded = editorReducer(blank, { type: 'LOAD_PAGE', page: page([h1]) })

check('a freshly loaded page has no unsaved changes', () => assert.equal(loaded.hasUnsavedChanges, false))
check('adding a block is an unsaved change', () => {
  const s = editorReducer(loaded, { type: 'SET_BLOCKS', blocks: [h1, p] })
  assert.equal(s.hasUnsavedChanges, true)
})
check('add then Undo is back to what was saved: not unsaved', () => {
  const s = editorReducer(editorReducer(loaded, { type: 'SET_BLOCKS', blocks: [h1, p] }), { type: 'UNDO' })
  assert.equal(s.hasUnsavedChanges, false)
})
check('add, Undo, Redo is unsaved again', () => {
  let s = editorReducer(loaded, { type: 'SET_BLOCKS', blocks: [h1, p] })
  s = editorReducer(editorReducer(s, { type: 'UNDO' }), { type: 'REDO' })
  assert.equal(s.hasUnsavedChanges, true)
})
check('an edit that changes it back by hand is not unsaved', () => {
  let s = editorReducer(loaded, { type: 'SET_BLOCKS', blocks: [{ ...h1, textContent: 'Hi' } as Block] })
  s = editorReducer(s, { type: 'SET_BLOCKS', blocks: [h1] })
  assert.equal(s.hasUnsavedChanges, false)
})
check('after saving, the saved version is the new baseline', () => {
  let s = editorReducer(loaded, { type: 'SET_BLOCKS', blocks: [h1, p] })
  s = editorReducer(s, { type: 'MARK_SAVED', timestamp: 't', page: page([h1, p]) })
  assert.equal(s.hasUnsavedChanges, false)
  s = editorReducer(s, { type: 'UNDO' })
  assert.equal(s.hasUnsavedChanges, true, 'undoing past the save is a change from what is saved')
})
check('an edit made while the save was in flight stays unsaved', () => {
  let s = editorReducer(loaded, { type: 'SET_BLOCKS', blocks: [h1, p] })
  s = editorReducer(s, { type: 'SET_BLOCKS', blocks: [h1, p, { ...p, id: 'c' } as Block] })
  s = editorReducer(s, { type: 'MARK_SAVED', timestamp: 't', page: page([h1, p]) })
  assert.equal(s.hasUnsavedChanges, true)
})
check('Clear All on a page with blocks is unsaved; Undo of it is not', () => {
  const s = editorReducer(loaded, { type: 'CLEAR_ALL' })
  assert.equal(s.hasUnsavedChanges, true)
  assert.equal(editorReducer(s, { type: 'UNDO' }).hasUnsavedChanges, false)
})
check('code view writing the same blocks back is not unsaved', () => {
  const s = editorReducer(loaded, { type: 'SET_BLOCKS_FROM_JSX', blocks: [h1] })
  assert.equal(s.hasUnsavedChanges, false)
})
console.log(`\n${n} checks passed`)
