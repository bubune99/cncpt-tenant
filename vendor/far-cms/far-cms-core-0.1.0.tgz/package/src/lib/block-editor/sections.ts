/**
 * Sections — the plain-language building blocks people add to a page
 * ("Hero banner", "Photo + text"…), built from the site's own design
 * (brand colours, Fredoka One headings, the button styles used on the live
 * pages; see seeds/pages). Each builds a fresh block tree with new ids.
 *
 * The 80-odd primitive blocks (<div>, Flex Row…) stay available under
 * "Advanced" for developers; people pick from these.
 */

import type { Block } from "./types"
import { generateId } from "./tree-utils"

export interface SectionDef {
  id: string
  name: string
  description: string
  build: () => Block
}

const R2 = "https://pub-89521fc08b10436cb278c7c927b1a037.r2.dev/images"
const HEADING = "text-4xl text-[#022b39] font-['Fredoka_One']"
const BUTTON = "inline-block px-8 py-3 bg-[#b45309] text-white font-semibold rounded uppercase tracking-wider font-['Fredoka_One'] hover:bg-[#088cbc] transition-colors"
const BUTTON_DARK = "inline-block px-8 py-3 bg-[#022b39] text-white font-semibold rounded hover:bg-[#088cbc] transition-colors"
const WRAP = "max-w-[1200px] mx-auto px-4"

/** Tiny block builder: b(tag, className, text?, children?, attrs?). */
function b(tag: string, className: string, text?: string | null, children?: Block[], attrs?: Record<string, string>): Block {
  return {
    id: generateId(),
    tag,
    className,
    ...(text ? { textContent: text } : {}),
    ...(children?.length ? { children } : {}),
    ...(attrs ? { attrs } : {}),
  } as Block
}

const section = (label: string, className: string, children: Block[]): Block => ({ ...b("section", className, null, children), label })

export const SECTIONS: ReadonlyArray<SectionDef> = [
  {
    id: "hero",
    name: "Hero banner",
    description: "Big photo with a headline and a button",
    build: () => ({
      ...section("Hero banner", "relative text-white py-40", [
        b("div", "absolute inset-0 bg-gradient-to-r from-[#022b39]/80 via-[#022b39]/50 to-[#022b39]/20"),
        b("div", "relative z-10 max-w-[800px] ml-[5%]", null, [
          b("h1", "text-5xl md:text-6xl font-extrabold mb-4 drop-shadow-lg", "Delivering Hope"),
          b("p", "text-lg mb-8 drop-shadow", "Bridging the healthcare gap in Ghana"),
          b("a", BUTTON, "Get Involved", undefined, { href: "/get-involved" }),
        ]),
      ]),
      background: { url: `${R2}/Homepage-Banner.png`, size: "cover", position: "center" },
    }) as Block,
  },
  {
    id: "photo-text",
    name: "Photo + text",
    description: "A photo beside a heading, words and a button",
    build: () =>
      section("Photo + text", "py-20 bg-white", [
        b("div", `${WRAP} grid grid-cols-1 md:grid-cols-2 gap-12 items-center`, null, [
          b("div", "overflow-hidden rounded-lg shadow-xl", null, [b("img", "w-full h-auto block", null, undefined, { src: `${R2}/About-Image.jpeg`, alt: "Our team in Ghana" })]),
          b("div", "", null, [
            b("h2", `${HEADING} mb-6`, "Our Story"),
            b("p", "mb-6 text-lg leading-relaxed", "Tell visitors what this part of your work is about, in a few warm sentences."),
            b("a", BUTTON_DARK, "Learn more", undefined, { href: "/about" }),
          ]),
        ]),
      ]),
  },
  {
    id: "initiative-cards",
    name: "Initiative cards",
    description: "Your featured initiatives, always up to date",
    build: () =>
      section("Initiative cards", "py-20 bg-gray-50", [
        b("div", WRAP, null, [
          b("h2", `${HEADING} text-center mb-10`, "Our Initiatives"),
          { ...b("div", "w-full", null, undefined, { "data-mode": "cards" }), componentName: "InitiativeHighlights" } as Block,
        ]),
      ]),
  },
  {
    id: "donate-band",
    name: "Donate band",
    description: "A bold strip asking visitors to give",
    build: () =>
      section("Donate band", "py-16 bg-[#022b39] text-white text-center", [
        b("div", "max-w-[800px] mx-auto px-4", null, [
          b("h2", "text-4xl mb-4 font-['Fredoka_One']", "Your gift delivers care"),
          b("p", "text-lg mb-8 text-white/90", "Every donation sends medical supplies to communities across Ghana."),
          b("a", BUTTON, "Donate now", undefined, { href: "/donate" }),
        ]),
      ]),
  },
  {
    id: "gallery",
    name: "Gallery",
    description: "A grid of photos",
    build: () =>
      section("Gallery", "py-20 bg-white", [
        b("div", WRAP, null, [
          b("h2", `${HEADING} text-center mb-10`, "From the field"),
          b(
            "div",
            "grid grid-cols-2 md:grid-cols-3 gap-4",
            null,
            ["Akuse-Hospital.jpg", "About-Image.jpeg", "Airplane.jpg"].map((f) => b("img", "w-full h-56 object-cover rounded-lg", null, undefined, { src: `${R2}/${f}`, alt: "" }))
          ),
        ]),
      ]),
  },
  {
    id: "quote",
    name: "Quote",
    description: "A testimonial in someone's own words",
    build: () =>
      section("Quote", "py-20 bg-[#f5f8ff]", [
        b("figure", "max-w-[800px] mx-auto px-4 text-center", null, [
          b("blockquote", "text-2xl leading-relaxed text-[#022b39] italic mb-6", "“The supplies arrived the week our clinic ran out. It changed everything for our patients.”"),
          b("figcaption", "text-gray-600 font-semibold", "Nurse, Akuse Government Hospital"),
        ]),
      ]),
  },
  {
    id: "faq",
    name: "FAQ",
    description: "Common questions with short answers",
    build: () =>
      section("FAQ", "py-20 bg-white", [
        b("div", "max-w-[800px] mx-auto px-4", null, [
          b("h2", `${HEADING} text-center mb-10`, "Questions"),
          ...[
            ["Where does my donation go?", "Directly to medical supplies, patient advocacy and health education in Ghana."],
            ["Can I volunteer?", "Yes — see Get Involved for upcoming trips and ways to help from home."],
          ].flatMap(([q, a]) => [b("h3", "text-xl font-semibold text-[#022b39] mt-6 mb-2", q), b("p", "text-gray-700 leading-relaxed", a)]),
        ]),
      ]),
  },
  {
    id: "contact-form",
    name: "Contact form",
    description: "A form from Admin → Forms",
    build: () =>
      section("Contact form", "py-20 bg-gray-50", [
        b("div", "max-w-[700px] mx-auto px-4", null, [
          b("h2", `${HEADING} text-center mb-6`, "Get in touch"),
          { ...b("div", "w-full", null, undefined, { "data-form-slug": "contact" }), componentName: "FormBlock" } as Block,
        ]),
      ]),
  },
  {
    id: "newsletter",
    name: "Newsletter",
    description: "Invite visitors to get updates",
    build: () =>
      section("Newsletter", "py-16 bg-[#f5f8ff] text-center", [
        b("div", "max-w-[640px] mx-auto px-4", null, [
          b("h2", `${HEADING} mb-3`, "Stay in the loop"),
          b("p", "text-gray-600 mb-6", "Stories and updates from our work, a few times a year."),
          { ...b("div", "w-full", null, undefined, { "data-form-slug": "newsletter" }), componentName: "FormBlock" } as Block,
        ]),
      ]),
  },
  {
    id: "stats",
    name: "Stats strip",
    description: "Big numbers that show your impact",
    build: () =>
      section("Stats strip", "py-16 bg-white", [
        b(
          "div",
          `${WRAP} grid grid-cols-1 md:grid-cols-3 gap-8 text-center`,
          null,
          [
            ["3", "Hospitals equipped"],
            ["500+", "Medical supplies"],
            ["7", "Women funded"],
          ].map(([n, l]) => b("div", "p-6 rounded-lg shadow-md bg-white", null, [b("div", "text-5xl font-bold text-[#022b39] mb-2", n), b("div", "text-lg font-semibold text-gray-700", l)]))
        ),
      ]),
  },
  {
    id: "cta",
    name: "Call to action",
    description: "One clear next step",
    build: () =>
      section("Call to action", "py-16 bg-gray-50 text-center", [
        b("div", "max-w-[800px] mx-auto px-4", null, [
          b("h2", `${HEADING} mb-4`, "Travel with us"),
          b("p", "text-lg text-gray-700 mb-8", "Join a medical mission and make a direct impact."),
          b("a", BUTTON_DARK, "See trip details", undefined, { href: "/travel-requirements" }),
        ]),
      ]),
  },
  {
    id: "video",
    name: "Video",
    description: "A YouTube video",
    build: () =>
      section("Video", "py-12 bg-white", [
        b("div", "max-w-[800px] mx-auto px-4", null, [
          b("div", "relative overflow-hidden rounded-lg aspect-video", null, [
            b("iframe", "absolute inset-0 w-full h-full", null, undefined, { src: "https://www.youtube.com/embed/vOlqSvMxpog", title: "Project Dzidzor video", allowfullscreen: "" }),
          ]),
        ]),
      ]),
  },
]

/** The site's own styles, for blocks drawn elsewhere (the tray's Ideas — lib/ade-bindings/block-library). */
export const SITE_STYLES = { heading: HEADING, button: BUTTON, buttonDark: BUTTON_DARK, wrap: WRAP } as const
