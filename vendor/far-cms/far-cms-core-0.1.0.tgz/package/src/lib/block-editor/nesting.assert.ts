/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/nesting.assert.ts
 */
import assert from 'node:assert/strict'
import { acceptsChildren, canNest, excludedTargets, indexTree, type NestBlock } from './nesting'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const B = (tag: string, extra: Partial<NestBlock> = {}): NestBlock => ({ tag, ...extra })
const ok = (parent: NestBlock | null, child: NestBlock) => assert.deepEqual(canNest(parent, child), { ok: true })
const no = (parent: NestBlock | null, child: NestBlock, reason: string) => assert.deepEqual(canNest(parent, child), { ok: false, reason })

check('content goes into sections, groups, columns and rows', () => {
  ok(B('div'), B('img'))
  ok(B('div'), B('p'))
  ok(B('section'), B('div'))
  ok(B('div'), B('section'))
  ok(B('section'), B('section'))
  ok(B('div'), B('div', { componentName: 'FormBlock' }))
  ok(B('div'), B('div', { componentName: 'PartialReference', partialId: 'p1' }))
  ok(B('li'), B('p'))
  ok(B('MyCard'), B('h2'))
})

check('the page itself takes any block except table/list pieces', () => {
  ok(null, B('section'))
  ok(null, B('img'))
  no(null, B('li'), 'A list item only goes inside a list')
})

check('text-level blocks take inline pieces only — never sections or groups', () => {
  no(B('button'), B('section'), "A section can't go inside a button")
  no(B('a'), B('section'), "A section can't go inside a button")
  no(B('h2'), B('div'), "A group can't go inside a heading")
  no(B('p'), B('img', { componentName: 'ProductGrid' }), "A live block can't go inside a paragraph")
  no(B('p'), B('h3'), "A subheading can't go inside a paragraph")
  ok(B('p'), B('span'))
  ok(B('a'), B('img'))
  ok(B('h1'), B('strong'))
  no(B('a'), B('button'), "A button can't go inside a button")
})

check('live blocks, shared sections and media hold nothing', () => {
  no(B('div', { componentName: 'ProductGrid' }), B('p'), "A live block can't hold other blocks")
  no(B('div', { componentName: 'PartialReference', partialId: 'x' }), B('p'), "A shared section can't hold other blocks")
  no(B('img'), B('span'), "An image can't hold other blocks")
  assert.equal(acceptsChildren(B('div', { componentName: 'FormBlock' })), false)
  assert.equal(acceptsChildren(B('img')), false)
})

check('lists and tables keep their structure', () => {
  ok(B('ul'), B('li'))
  no(B('ul'), B('p'), 'Only list items go inside a list')
  no(B('div'), B('li'), 'A list item only goes inside a list')
  ok(B('tr'), B('td'))
  no(B('div'), B('td'), 'A table cell only goes inside a table row')
  no(B('form'), B('form'), "A form can't go inside another form")
  no(B('div', { locked: true }), B('p'), 'This group is locked')
})

check('a drop area: containers, and text blocks only when they already hold pieces', () => {
  assert.equal(acceptsChildren(B('div')), true)
  assert.equal(acceptsChildren(B('section')), true)
  assert.equal(acceptsChildren(B('p')), false)
  assert.equal(acceptsChildren(B('a', { children: [B('span')] })), true)
  assert.equal(acceptsChildren(B('Custom')), true)
})

check('never into itself, its own insides, or a sibling (siblings reorder) — unless opened', () => {
  const tree: NestBlock[] = [
    { id: 's1', tag: 'section', children: [
      { id: 'row', tag: 'div', children: [
        { id: 'colA', tag: 'div', children: [{ id: 'img', tag: 'img' }] },
        { id: 'colB', tag: 'div', children: [{ id: 'grp', tag: 'div', children: [{ id: 'h', tag: 'h2' }] }] },
      ] },
    ] },
    { id: 's2', tag: 'section', children: [{ id: 's2in', tag: 'div' }] },
  ]
  const idx = indexTree(tree)
  assert.equal(idx.get('grp')?.depth, 3)
  assert.equal(idx.get('grp')?.parentId, 'colB')
  assert.equal(idx.get('s1')?.parentId, null)

  // the photo may go into the other column / text group: they aren't its siblings
  const forImg = excludedTargets(idx, tree, 'img')
  assert.deepEqual([...forImg].sort(), ['img'])
  // dragging a column: itself + the other column's whole subtree are out
  assert.deepEqual([...excludedTargets(idx, tree, 'colA')].sort(), ['colA', 'colB', 'grp', 'h', 'img'])
  // ...until the pointer rests on the other column
  assert.deepEqual([...excludedTargets(idx, tree, 'colA', 'colB')].sort(), ['colA', 'img'])
  // page sections only reorder between themselves
  assert.deepEqual([...excludedTargets(idx, tree, 's1')].sort(), ['colA', 'colB', 'grp', 'h', 'img', 'row', 's1', 's2', 's2in'])
  assert.equal(excludedTargets(idx, tree, 'missing').size, 0)
})

console.log(`\n${n} checks passed`)
