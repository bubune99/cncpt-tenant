/**
 * The canvas shows the DEVICE you picked, not the browser window.
 *
 * Tailwind's md:/lg: (and sm:, xl:, 2xl:, max-*:, min-[…]:) follow the
 * window, so with Phone picked on a wide screen the canvas used to show the
 * desktop classes and per-device edits looked like they did nothing. Inside
 * the canvas every class whose first variant is a breakpoint gets a `cq-`
 * prefix (so the window's media rules no longer match it), and the site's
 * own breakpoint rules are re-emitted for those `cq-` classes — only the
 * ones whose width condition holds at the picked device's width.
 *
 * Phone and tablet are their fixed widths; desktop is the canvas's width
 * but never less than lg (1024px), so Desktop always shows desktop.
 * Pure; asserted by canvas-breakpoints.assert.ts. The browser glue (reading
 * the stylesheets, rewriting class attributes) is in
 * components/block-editor/canvas-breakpoints.tsx.
 */

export const CANVAS_CLASS_PREFIX = 'cq-'

/** The devices every site canvas previews (page editor, records, blog, forms). */
export type CanvasDevice = 'desktop' | 'tablet' | 'phone'
/** Phone and tablet preview widths (px). Desktop is the canvas's own width, at least DESKTOP_MIN_WIDTH. */
export const DEVICE_PX = { phone: 390, tablet: 820 } as const
/** The width a canvas is laid out at, per device ("100%" = all the room it has). */
export const DEVICE_WIDTH: Record<CanvasDevice, string> = { desktop: '100%', tablet: `${DEVICE_PX.tablet}px`, phone: `${DEVICE_PX.phone}px` }
/** Desktop never shows less than the lg breakpoint (64rem), whatever room the canvas has. */
export const DESKTOP_MIN_WIDTH = 1024
const ROOT_FONT_PX = 16

const BREAKPOINT_VARIANT = /^(?:max-)?(?:sm|md|lg|xl|2xl)$|^(?:min|max)-\[[^\]]+\]$/

/** The first variant of a class ("md" in "md:hover:bg-x"), split on the first top-level colon. */
export function firstVariant(token: string): string | null {
  let depth = 0
  for (let i = 0; i < token.length; i++) {
    const ch = token[i]
    if (ch === '[' || ch === '(') depth++
    else if (ch === ']' || ch === ')') depth--
    else if (ch === ':' && depth === 0) return token.slice(0, i)
  }
  return null
}

/** "md:text-lg" → "cq-md:text-lg"; anything not starting with a breakpoint stays as it is. */
export function canvasClass(token: string): string {
  const v = firstVariant(token)
  return v && BREAKPOINT_VARIANT.test(v) ? `${CANVAS_CLASS_PREFIX}${token}` : token
}

/** A whole class attribute for the canvas (returns the same string when nothing changes). */
export function canvasClassName(className: string): string {
  const tokens = className.split(/(\s+)/)
  let changed = false
  const out = tokens.map((t) => {
    if (!t || /^\s+$/.test(t)) return t
    const c = canvasClass(t)
    if (c !== t) changed = true
    return c
  })
  return changed ? out.join('') : className
}

/** Split on top-level commas (not inside :is(…) / [..]). */
function splitSelectorList(selector: string): string[] {
  const parts: string[] = []
  let depth = 0
  let start = 0
  for (let i = 0; i < selector.length; i++) {
    const ch = selector[i]
    if (ch === '\\') {
      i++
      continue
    }
    if (ch === '(' || ch === '[') depth++
    else if (ch === ')' || ch === ']') depth--
    else if (ch === ',' && depth === 0) {
      parts.push(selector.slice(start, i).trim())
      start = i + 1
    }
  }
  parts.push(selector.slice(start).trim())
  return parts.filter(Boolean)
}

// An escaped breakpoint class in a selector: .md\:  .max-md\:  .\32 xl\:  .min-\[900px\]\:
const SELECTOR_BREAKPOINT = /\.((?:max-)?(?:sm|md|lg|xl|2xl|\\32 xl)\\:|(?:min|max)-\\\[)/g

/** Limit a selector to one canvas (its root or anything inside), keeping its specificity. */
function scoped(part: string, scope: string): string {
  const where = `:where([data-canvas-scope="${scope}"], [data-canvas-scope="${scope}"] *)`
  const pseudo = part.indexOf('::')
  return pseudo < 0 ? `${part}${where}` : `${part.slice(0, pseudo)}${where}${part.slice(pseudo)}`
}

/**
 * The selector for the canvas's `cq-` copy of a breakpoint class, or null when
 * no part of it is a breakpoint class (e.g. `.container` inside a media rule).
 * With `scope`, it only matches inside that canvas — two canvases at
 * different devices (records on Phone beside the page editor) can't mix.
 */
export function canvasSelector(selector: string, scope?: string): string | null {
  const parts = splitSelectorList(selector)
    .filter((p) => new RegExp(SELECTOR_BREAKPOINT.source).test(p))
    .map((p) => p.replace(SELECTOR_BREAKPOINT, `.${CANVAS_CLASS_PREFIX}$1`))
    .map((p) => (scope ? scoped(p, scope) : p))
  return parts.length ? parts.join(', ') : null
}

function toPx(value: string): number | null {
  const m = /^(-?[\d.]+)(px|rem|em)?$/.exec(value.trim())
  if (!m) return null
  const n = parseFloat(m[1])
  return m[2] === 'rem' || m[2] === 'em' ? n * ROOT_FONT_PX : n
}

/**
 * A media condition that only tests the width, as a predicate on a width in
 * px; null when it tests anything else (hover, print, motion…).
 * Handles Tailwind v4's "(width >= 48rem)" and the lowered
 * "(min-width: 48rem)" / "not all and (min-width: 48rem)".
 */
export function widthPredicate(condition: string): ((width: number) => boolean) | null {
  let text = condition.trim().replace(/^only\s+screen\s+and\s+/i, '').replace(/^screen\s+and\s+/i, '')
  let negate = false
  const not = /^not\s+(?:all|screen)\s+and\s+/i.exec(text)
  if (not) {
    negate = true
    text = text.slice(not[0].length)
  }
  const tests: Array<(w: number) => boolean> = []
  for (const part of text.split(/\s+and\s+/i)) {
    const m = /^\(\s*(.+?)\s*\)$/.exec(part.trim())
    if (!m) return null
    const body = m[1]
    let t: ((w: number) => boolean) | null = null
    const colon = /^(min|max)-width\s*:\s*(.+)$/i.exec(body)
    const range = /^width\s*(>=|<=|>|<)\s*(.+)$/i.exec(body)
    const flipped = /^(.+?)\s*(>=|<=|>|<)\s*width$/i.exec(body)
    if (colon) {
      const px = toPx(colon[2])
      if (px === null) return null
      t = colon[1].toLowerCase() === 'min' ? (w) => w >= px : (w) => w <= px
    } else if (range || flipped) {
      const op = range ? range[1] : ({ '>=': '<=', '<=': '>=', '>': '<', '<': '>' } as const)[flipped![2] as '>=' | '<=' | '>' | '<']
      const px = toPx(range ? range[2] : flipped![1])
      if (px === null) return null
      t = op === '>=' ? (w) => w >= px : op === '<=' ? (w) => w <= px : op === '>' ? (w) => w > px : (w) => w < px
    }
    if (!t) return null
    tests.push(t)
  }
  if (!tests.length) return null
  return (w) => tests.every((t) => t(w)) !== negate
}

/** The width the canvas styles for: the device's own width; desktop = the canvas, at least lg. */
export function canvasStyleWidth(viewportWidth: string, measuredPx: number): number {
  const fixed = /^(\d+(?:\.\d+)?)px$/.exec(viewportWidth.trim())
  if (fixed) return parseFloat(fixed[1])
  return Math.max(DESKTOP_MIN_WIDTH, Math.round(measuredPx) || 0)
}

/** A stylesheet, reduced to what matters here (built from the CSSOM by the browser glue). */
export type CssNode =
  | { type: 'group'; prelude: string; children: CssNode[] } // @layer / @supports / other @media: kept as wrappers
  | { type: 'media'; condition: string; children: CssNode[] }
  | { type: 'style'; selector: string; declarations: string; children: CssNode[] }
  | { type: 'decls'; declarations: string } // nested declarations (inside @media inside a rule)

/** Resolve a nested selector against its parent rule (CSS nesting: `&`, or a descendant). */
function nest(parent: string | null, selector: string): string {
  if (!parent) return selector
  const p = splitSelectorList(parent)
  const ref = p.length > 1 ? `:is(${parent})` : parent
  return selector.includes('&') ? selector.replace(/&/g, ref) : `${ref} ${selector}`
}

/**
 * The canvas's breakpoint rules at `width`: every rule for a breakpoint class
 * whose width conditions hold there, re-targeted at its `cq-` class, inside
 * the same @layer (so the cascade is the site's own). Order is kept.
 */
export function canvasBreakpointCss(nodes: ReadonlyArray<CssNode>, width: number, scope?: string): string {
  const out: string[] = []
  const emit = (wrappers: string[], selector: string | null, declarations: string) => {
    const decl = declarations.trim()
    if (!selector || !decl) return
    const sel = canvasSelector(selector, scope)
    if (!sel) return
    out.push(`${wrappers.map((w) => `${w}{`).join('')}${sel}{${decl}}${'}'.repeat(wrappers.length)}`)
  }
  const walk = (list: ReadonlyArray<CssNode>, wrappers: string[], selector: string | null, inWidth: boolean) => {
    for (const n of list) {
      if (n.type === 'group') walk(n.children, [...wrappers, n.prelude], selector, inWidth)
      else if (n.type === 'media') {
        const test = widthPredicate(n.condition)
        if (!test) walk(n.children, [...wrappers, `@media ${n.condition}`], selector, inWidth)
        else if (test(width)) walk(n.children, wrappers, selector, true)
      } else if (n.type === 'style') {
        const sel = nest(selector, n.selector)
        if (inWidth) emit(wrappers, sel, n.declarations)
        walk(n.children, wrappers, sel, inWidth)
      } else if (inWidth) emit(wrappers, selector, n.declarations)
    }
  }
  walk(nodes, [], null, false)
  return out.join('\n')
}

/** Every width (px) at which some breakpoint rule switches — the CSS only changes across these. */
export function breakpointWidths(nodes: ReadonlyArray<CssNode>): number[] {
  const found = new Set<number>()
  const walk = (list: ReadonlyArray<CssNode>) => {
    for (const n of list) {
      if (n.type === 'media') for (const m of n.condition.matchAll(/(-?[\d.]+)(px|rem|em)\b/g)) found.add(toPx(m[0]) ?? 0)
      if (n.type !== 'decls') walk(n.children)
    }
  }
  walk(nodes)
  return [...found].sort((a, b) => a - b)
}
