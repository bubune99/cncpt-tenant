/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/editor-fit.assert.ts
 */
import assert from 'node:assert/strict'
import { NARROW_EDITOR_PX, editorFit } from './editor-fit'

assert.deepEqual(editorFit(829, false), { compactToolbar: true, panelsAsSheets: true }, 'Classic at 1068: 1068 − 224 sidebar − scrollbar ≈ 829px')
assert.deepEqual(editorFit(2321, false), { compactToolbar: false, panelsAsSheets: false }, 'Classic at 2560')
assert.deepEqual(editorFit(NARROW_EDITOR_PX, false), { compactToolbar: false, panelsAsSheets: false }, 'the threshold itself is roomy')
assert.deepEqual(editorFit(NARROW_EDITOR_PX - 1, false), { compactToolbar: true, panelsAsSheets: true })
assert.deepEqual(editorFit(null, false), { compactToolbar: false, panelsAsSheets: false }, 'unmeasured: roomy')
assert.deepEqual(editorFit(null, true), { compactToolbar: true, panelsAsSheets: true }, 'phones always compact')
console.log('6 checks passed')
