/**
 * Moving a block within its container (drag to reorder) — pure rules,
 * asserted by move.assert.ts. The drag itself is dnd-kit; this decides the
 * direction the siblings shift and how the move is described afterwards.
 */

import { blockKind, shorten, type NamedBlock } from "./outline-names"

export type SortDirection = "vertical" | "horizontal" | "grid"

/** Stacks shift vertically, rows horizontally, grids/bento reflow every tile. */
export function sortDirectionFor(className: string | undefined): SortDirection {
  const classes = (className ?? "").split(/\s+/)
  const base = (c: string) => c.replace(/^[a-z0-9]+:/, "")
  if (classes.some((c) => base(c) === "grid" || base(c).startsWith("grid-cols-"))) return "grid"
  // A flex row (no base flex-col) shifts sideways; "flex flex-col md:flex-row" is a stack first.
  if (classes.includes("flex") && !classes.includes("flex-col")) return "horizontal"
  return "vertical"
}

/** Where `activeId` lands when dropped on `overId` among `siblingIds` (dnd-kit sortable semantics). */
export function moveIndices(siblingIds: ReadonlyArray<string>, activeId: string, overId: string): { from: number; to: number } | null {
  const from = siblingIds.indexOf(activeId)
  const to = siblingIds.indexOf(overId)
  if (from < 0 || to < 0) return null
  return { from, to }
}

function nameOf(b: NamedBlock): string {
  const text = b.textContent?.trim()
  return text ? `“${shorten(text, 28)}”` : blockKind(b)
}

/** "Moved “Our Story” below “Join the mission”" — or null when it stays put. */
export function moveMessage(siblings: ReadonlyArray<NamedBlock & { id?: string }>, activeId: string, overId: string): string | null {
  const ids = siblings.map((s) => s.id ?? "")
  const m = moveIndices(ids, activeId, overId)
  if (!m || m.from === m.to) return null
  const moved = siblings[m.from]
  const neighbour = siblings[m.to]
  const firstText = (b: NamedBlock): string | null => {
    if (b.textContent?.trim()) return b.textContent.trim()
    for (const c of b.children ?? []) {
      const t = firstText(c)
      if (t) return t
    }
    return null
  }
  const label = (b: NamedBlock) => {
    const t = firstText(b)
    return t ? `“${shorten(t, 28)}”` : nameOf(b)
  }
  return `Moved ${label(moved)} ${m.to > m.from ? "below" : "above"} ${label(neighbour)}`
}

export interface RectLike {
  top: number
  left: number
  width: number
  height: number
}

/**
 * The layout siblings ACTUALLY have on screen (measured, not guessed from
 * class names): all on one line → a row; one per line → a stack; anything
 * else (wrapping rows, grids, bento) → a grid. Switches by itself when a
 * row wraps to a stack on a narrow screen.
 */
export function layoutOfRects(rects: ReadonlyArray<RectLike | null | undefined>, tolerance = 4): SortDirection {
  const r = rects.filter((x): x is RectLike => !!x && x.width > 0 && x.height > 0)
  if (r.length < 2) return "vertical"
  const sameTop = r.every((x) => Math.abs(x.top - r[0].top) <= tolerance)
  if (sameTop) return "horizontal"
  // One per line: no two items overlap vertically.
  const sorted = [...r].sort((a, b) => a.top - b.top)
  const stacked = sorted.every((x, i) => i === 0 || x.top >= sorted[i - 1].top + sorted[i - 1].height - tolerance)
  return stacked ? "vertical" : "grid"
}

/* ---- Moving ACROSS containers ---- */

export interface Point {
  x: number
  y: number
}

/** A container the pointer might be dropping into, as the drag measured it. */
export interface DropCandidate {
  id: string
  rect: RectLike
  depth: number
  /** The nesting rules let the dragged block go inside it (nesting.ts). */
  allowed: boolean
  reason?: string
}

export interface ContainerHit {
  /** The container the block would go into; null = the page itself. */
  targetId: string | null
  /** A deeper container under the pointer that refused it, and why. */
  blocked: { id: string; reason: string } | null
  /** A small container under the pointer (worth opening up after a short rest). */
  small: string | null
}

function contains(r: RectLike, p: Point, inset = 0): boolean {
  return p.x >= r.left + inset && p.x <= r.left + r.width - inset && p.y >= r.top + inset && p.y <= r.top + r.height - inset
}

/** The band along a container's edges that counts as "beside it", not "inside it". */
export function edgeBand(r: RectLike, edge = 12): number {
  return Math.min(edge, r.width * 0.15, r.height * 0.15)
}

/**
 * Which container is under the pointer. The deepest one that allows the
 * block wins; near a container's edge counts as its parent (so the pointer
 * between two page sections means the page itself). `sticky` containers —
 * where the block already is, or one the pointer rested on — have no edge
 * band and even reach `stickyMargin` px past their edges, so sorting near
 * (or slightly over) their edges never pops the block out.
 */
export function containerAt(point: Point, candidates: ReadonlyArray<DropCandidate>, sticky: ReadonlyArray<string> = [], smallSize = 32, stickyMargin = 16): ContainerHit {
  const under = candidates.filter((c) => contains(c.rect, point, sticky.includes(c.id) ? -stickyMargin : edgeBand(c.rect)))
  under.sort((a, b) => b.depth - a.depth || a.rect.width * a.rect.height - b.rect.width * b.rect.height)
  const target = under.find((c) => c.allowed) ?? null
  const refused = under.find((c) => !c.allowed && (!target || c.depth > target.depth))
  const small = candidates
    .filter((c) => c.allowed && contains(c.rect, point) && (c.rect.width < smallSize || c.rect.height < smallSize))
    .sort((a, b) => a.rect.width * a.rect.height - b.rect.width * b.rect.height)[0]
  return {
    targetId: target?.id ?? null,
    blocked: refused ? { id: refused.id, reason: refused.reason ?? "It can't go there" } : null,
    small: small?.id ?? null,
  }
}

/** The sibling container whose middle the pointer rests on (to open it after a pause), if any. */
export function restingOn(point: Point, siblings: ReadonlyArray<{ id: string; rect: RectLike }>): string | null {
  const hit = siblings.find((s) => contains(s.rect, point, Math.min(s.rect.width, s.rect.height) * 0.25))
  return hit?.id ?? null
}

/** Entering a container over one of its blocks: land after it when the pointer is past its middle. */
export function insertAfter(rect: RectLike, point: Point, layout: SortDirection): boolean {
  if (layout === "horizontal") return point.x > rect.left + rect.width / 2
  if (layout === "vertical") return point.y > rect.top + rect.height / 2
  if (point.y > rect.top + rect.height) return true
  if (point.y < rect.top) return false
  return point.x > rect.left + rect.width / 2
}

/** "Moved Image into Text group" / "Moved “Our Story” onto the page". */
export function crossMoveMessage(moved: NamedBlock, target: NamedBlock | null): string {
  const label = (b: NamedBlock): string => {
    const own = b.textContent?.trim()
    if (own) return `“${shorten(own, 28)}”`
    return blockKind(b)
  }
  return target ? `Moved ${label(moved)} into ${blockKind(target)}` : `Moved ${label(moved)} onto the page`
}
