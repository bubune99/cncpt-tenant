/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/outline-names.assert.ts
 */
import assert from 'node:assert/strict'
import { outlineName, shorten } from './outline-names'
import { SECTIONS } from './sections'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('page sections read like a person describes them', () => {
  const hero = { tag: 'section', className: 'py-40 bg-cover', children: [{ tag: 'div', children: [{ tag: 'h1', textContent: 'Together we can save lives' }] }] }
  assert.equal(outlineName(hero), 'Hero — “Together we can save lives”')
  const story = { tag: 'section', children: [{ tag: 'img', attrs: { src: 'x' } }, { tag: 'h2', textContent: 'Our Story' }, { tag: 'p', textContent: 'Long text' }] }
  assert.equal(outlineName(story), 'Photo + text — “Our Story”')
  assert.equal(outlineName({ tag: 'div', componentName: 'InitiativeHighlights' }), 'Initiative cards')
  assert.equal(outlineName({ tag: 'section', label: 'Donate band', children: [{ tag: 'h2', textContent: 'Give' }] }), 'Donate band — “Give”')
  assert.equal(outlineName({ tag: 'img', attrs: { alt: 'Akuse hospital ward' } }), 'Image — Akuse hospital ward')
  assert.equal(outlineName({ tag: 'p', textContent: 'Hello' }), 'Text — “Hello”')
})

check('never shows a raw tag', () => {
  for (const tag of ['div', 'span', 'section', 'h4', 'x-custom']) assert.doesNotMatch(outlineName({ tag }), /<|div|span|x-custom/)
})

check('long text is shortened', () => {
  assert.equal(shorten('a'.repeat(50), 10), 'aaaaaaaaa…')
})

check('every catalog section builds, is labelled, and has fresh ids', () => {
  assert.equal(SECTIONS.length, 12)
  for (const s of SECTIONS) {
    const a = s.build()
    const b = s.build()
    assert.equal(a.label, s.name)
    assert.notEqual(a.id, b.id)
    assert.ok(outlineName(a).startsWith(s.name))
  }
})

console.log(`\n${n} checks passed`)
