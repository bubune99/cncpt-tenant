/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/properties/device-classes.assert.ts
 */
import assert from 'node:assert/strict'
import { hasOverride, re, readAt, resetToAll, splitVariant, writeAt } from './device-classes'
import { readSide, resetSpacing, spacingVaries, writeSides } from './spacing'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const size = re(/^text-(?:xs|sm|base|lg|[2-9]?xl)$/)
const align = re(/^text-(?:left|center|right)$/)

check('variants split on the last top-level colon; only bare/md:/lg: are ours', () => {
  assert.deepEqual(splitVariant('text-lg'), { layer: '', utility: 'text-lg' })
  assert.deepEqual(splitVariant('md:text-lg'), { layer: 'md:', utility: 'text-lg' })
  assert.deepEqual(splitVariant('hover:text-lg'), { layer: null, utility: 'text-lg' })
  assert.deepEqual(splitVariant('md:hover:text-lg'), { layer: null, utility: 'text-lg' })
  assert.deepEqual(splitVariant("bg-[url('https://x.y/a.png')]"), { layer: '', utility: "bg-[url('https://x.y/a.png')]" })
  assert.deepEqual(splitVariant('[&>*:first-child]:order-last'), { layer: null, utility: 'order-last' })
})

check('devices inherit mobile-first: phone = bare, tablet = md:, desktop = lg:', () => {
  const c = 'text-2xl md:text-4xl lg:text-6xl font-bold'
  assert.equal(readAt(c, size, 'phone'), 'text-2xl')
  assert.equal(readAt(c, size, 'tablet'), 'text-4xl')
  assert.equal(readAt(c, size, 'desktop'), 'text-6xl')
  assert.equal(readAt('text-2xl md:text-4xl', size, 'desktop'), 'text-4xl')
  assert.equal(readAt('font-bold', size, 'desktop'), null)
})

check('all devices: one bare class, the per-device ones go, nothing else moves', () => {
  const c = 'text-2xl md:text-4xl lg:text-6xl hover:text-lg font-bold'
  assert.equal(writeAt(c, size, 'text-3xl', 'desktop', 'all'), 'hover:text-lg font-bold text-3xl')
  assert.equal(hasOverride(c, size), true)
  assert.equal(hasOverride('text-2xl hover:text-lg', size), false)
})

check('this device only: other devices keep what they showed', () => {
  // Desktop only: lg: is enough.
  assert.equal(writeAt('text-2xl', size, 'text-6xl', 'desktop', 'device'), 'text-2xl lg:text-6xl')
  // Phone only: tablet/desktop pinned to the old value.
  const phone = writeAt('text-4xl', size, 'text-2xl', 'phone', 'device')
  assert.equal(readAt(phone, size, 'phone'), 'text-2xl')
  assert.equal(readAt(phone, size, 'tablet'), 'text-4xl')
  assert.equal(readAt(phone, size, 'desktop'), 'text-4xl')
  assert.equal(phone, 'text-2xl md:text-4xl')
  // Tablet only: desktop pinned via lg:, phone untouched.
  const tab = writeAt('text-2xl md:text-4xl', size, 'text-5xl', 'tablet', 'device')
  assert.deepEqual([readAt(tab, size, 'phone'), readAt(tab, size, 'tablet'), readAt(tab, size, 'desktop')], ['text-2xl', 'text-5xl', 'text-4xl'])
})

check('nothing set before: the fallback pins the other devices', () => {
  const c = writeAt('mb-4', align, 'text-center', 'phone', 'device', 'text-left')
  assert.equal(readAt(c, align, 'phone'), 'text-center')
  assert.equal(readAt(c, align, 'tablet'), 'text-left')
  assert.equal(readAt(c, align, 'desktop'), 'text-left')
})

check('redundant per-device values are tidied away', () => {
  // Setting desktop back to what tablet shows drops the lg: value.
  assert.equal(writeAt('text-2xl lg:text-6xl', size, 'text-2xl', 'desktop', 'device'), 'text-2xl')
})

check('reset to all devices: this device’s value everywhere', () => {
  assert.equal(resetToAll('text-2xl md:text-4xl lg:text-6xl', size, 'tablet'), 'text-4xl')
  assert.equal(resetToAll('text-2xl md:text-4xl lg:text-6xl', size, 'phone'), 'text-2xl')
})

check('spacing reads through shorthands (p < px/py < pt)', () => {
  const c = 'p-4 py-8 pt-12 md:px-10'
  assert.equal(readSide(c, 'p', 't', 'phone'), '12')
  assert.equal(readSide(c, 'p', 'b', 'phone'), '8')
  assert.equal(readSide(c, 'p', 'l', 'phone'), '4')
  assert.equal(readSide(c, 'p', 'l', 'desktop'), '10')
  assert.equal(readSide('-mt-4 mx-auto', 'm', 't', 'phone'), '-4')
  assert.equal(readSide('-mt-4 mx-auto', 'm', 'l', 'phone'), 'auto')
})

check('spacing writes one side and folds back to shorthands', () => {
  assert.equal(writeSides('py-20 bg-white', 'p', ['t'], '8', 'desktop', 'all'), 'bg-white pt-8 pb-20')
  assert.equal(writeSides('pt-8 pb-20', 'p', ['t', 'r', 'b', 'l'], '4', 'desktop', 'all'), 'p-4')
  assert.equal(writeSides('px-4', 'p', ['t', 'b'], '12', 'desktop', 'all'), 'py-12 px-4')
  // Desktop only keeps phone/tablet as they were.
  const d = writeSides('py-8', 'p', ['t', 'b'], '20', 'desktop', 'device')
  assert.equal(d, 'py-8 lg:py-20')
  assert.equal(spacingVaries(d, 'p'), true)
  assert.equal(resetSpacing(d, 'p', 'desktop'), 'py-20')
  // Linked, phone only, from nothing: other devices pinned to 0.
  const ph = writeSides('', 'p', ['t', 'r', 'b', 'l'], '4', 'phone', 'device')
  assert.equal(readSide(ph, 'p', 't', 'phone'), '4')
  assert.equal(readSide(ph, 'p', 't', 'desktop'), '0')
})

console.log(`\n${n} checks passed`)
