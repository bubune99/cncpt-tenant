/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/properties/contrast.assert.ts
 */
import assert from 'node:assert/strict'
import { checkContrast, colorOfUtility, contrastRatio, isLargeText, overlayDarkness, overlayFor, parseHex } from './contrast'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const near = (a: number, b: number) => assert.ok(Math.abs(a - b) < 0.01, `${a} ≈ ${b}`)

check('ratio matches the WCAG reference values', () => {
  near(contrastRatio([0, 0, 0], [255, 255, 255]), 21)
  near(contrastRatio([255, 255, 255], [255, 255, 255]), 1)
  // #767676 on white is the classic 4.54:1 AA boundary.
  near(contrastRatio(parseHex('#767676')!, [255, 255, 255]), 4.54)
  // Order doesn't matter.
  near(contrastRatio([255, 255, 255], parseHex('#022b39')!), contrastRatio(parseHex('#022b39')!, [255, 255, 255]))
})

check('colours resolve from classes; unknown palette names don’t guess', () => {
  assert.deepEqual(colorOfUtility('text-[#fff]'), [255, 255, 255])
  assert.deepEqual(colorOfUtility('bg-[#022B39]'), [2, 43, 57])
  assert.deepEqual(colorOfUtility('bg-black'), [0, 0, 0])
  assert.equal(colorOfUtility('text-gray-600'), null)
  assert.equal(parseHex('#12'), null)
})

check('large text: 24px+, or bold at 20px', () => {
  assert.equal(isLargeText('text-4xl', 'desktop'), true)
  assert.equal(isLargeText('text-xl font-bold', 'desktop'), true)
  assert.equal(isLargeText('text-xl', 'desktop', 'p'), false)
  assert.equal(isLargeText('text-xl', 'desktop', 'h3'), true)
  assert.equal(isLargeText('text-base lg:text-4xl', 'phone'), false)
})

check('text on the nearest background, walking out from the block', () => {
  // Brand palette on mist: amber passes AA; sky fails for body text but passes the large-text bar.
  const path = [{ className: 'bg-[#f5f8ff] py-20' }, { className: 'text-[#b45309] text-base' }]
  const body = checkContrast(path, 'desktop', 'p')!
  assert.equal(body.passes, true)
  const sky = checkContrast([{ className: 'bg-[#f5f8ff]' }, { className: 'text-[#088cbc]' }], 'desktop', 'p')!
  assert.equal(sky.required, 4.5)
  assert.equal(sky.passes, false)
  const skyHeading = checkContrast([{ className: 'bg-[#f5f8ff]' }, { className: 'text-[#088cbc] text-4xl' }], 'desktop', 'h2')!
  assert.equal(skyHeading.required, 3)
  assert.equal(skyHeading.passes, true)
  // White text inherited from the section, on navy.
  assert.equal(checkContrast([{ className: 'bg-[#022b39] text-white' }, { className: 'text-lg' }], 'desktop', 'p')!.passes, true)
  // White on white fails.
  assert.equal(checkContrast([{ className: 'text-[#ffffff]' }], 'desktop', 'p')!.passes, false)
})

check('per device: the phone colour is what is judged on the phone', () => {
  const path = [{ className: 'bg-[#022b39]' }, { className: 'text-[#1f2937] lg:text-white' }]
  assert.equal(checkContrast(path, 'desktop', 'p')!.passes, true)
  assert.equal(checkContrast(path, 'phone', 'p')!.passes, false)
})

check('over a photo: judged against the worst case through the overlay', () => {
  assert.equal(overlayDarkness('rgba(0,0,0,0.6)'), 0.6)
  assert.equal(overlayDarkness('linear-gradient(red, blue)'), 0)
  assert.equal(overlayFor(0.6), 'rgba(0,0,0,0.6)')
  assert.equal(overlayFor(0), undefined)
  const light = checkContrast([{ hasImage: true, imageOverlay: 'rgba(0,0,0,0.2)' }, { className: 'text-white' }], 'desktop', 'p')!
  assert.equal(light.overImage, true)
  assert.equal(light.passes, false)
  const dark = checkContrast([{ hasImage: true, imageOverlay: 'rgba(0,0,0,0.6)' }, { className: 'text-white' }], 'desktop', 'p')!
  assert.equal(dark.passes, true)
})

check('unknown colours: no verdict rather than a wrong one', () => {
  assert.equal(checkContrast([{ className: 'bg-sky-700' }, { className: 'text-white' }], 'desktop', 'p'), null)
  assert.equal(checkContrast([{ className: 'text-gray-500' }], 'desktop', 'p'), null)
})

console.log(`\n${n} checks passed`)
