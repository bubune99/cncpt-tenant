/**
 * Content rules for the properties panel: what kind of element is
 * selected (and so which tabs apply), heading levels and the one-H1 rule,
 * link destinations, section anchors, and image captions / links.
 * Pure; asserted by content.assert.ts.
 */

import type { Block } from '../types'
import { blockKind } from '../outline-names'
import { isRow } from './rows'

export type ElementType = 'heading' | 'text' | 'button' | 'image' | 'video' | 'row' | 'section' | 'smart' | 'other'

const TEXT_TAGS = new Set(['p', 'span', 'li', 'blockquote', 'figcaption', 'label', 'small', 'strong', 'em'])
const CONTAINER_TAGS = new Set(['section', 'div', 'header', 'footer', 'article', 'figure', 'main', 'aside', 'nav', 'ul', 'ol', 'form'])

export function elementType(block: Pick<Block, 'tag' | 'className' | 'componentName'>): ElementType {
  if (block.componentName) return 'smart'
  const tag = block.tag
  if (/^h[1-6]$/.test(tag)) return 'heading'
  if (TEXT_TAGS.has(tag)) return 'text'
  if (tag === 'a' || tag === 'button') return 'button'
  if (tag === 'img') return 'image'
  if (tag === 'video' || tag === 'iframe') return 'video'
  if (CONTAINER_TAGS.has(tag)) return isRow(block.className) ? 'row' : 'section'
  return 'other'
}

export type PanelTab = 'content' | 'layout' | 'style' | 'responsive' | 'more'

/** Only the tabs that apply, most used first. */
export function tabsFor(type: ElementType): PanelTab[] {
  switch (type) {
    case 'heading':
    case 'text':
    case 'button':
    case 'image':
      return ['content', 'style', 'layout', 'responsive', 'more']
    case 'row':
    case 'section':
      return ['layout', 'style', 'responsive', 'more']
    case 'video':
    case 'smart':
      return ['layout', 'responsive', 'more']
    default:
      return ['style', 'layout', 'responsive', 'more']
  }
}

export const TYPE_NAMES: Record<ElementType, string> = {
  heading: 'Heading',
  text: 'Text',
  button: 'Button',
  image: 'Image',
  video: 'Video',
  row: 'Row',
  section: 'Section',
  smart: 'Live content',
  other: 'Element',
}

/** Breadcrumb crumbs, root → selection: the person's name for each level plus its id. */
export function breadcrumb(path: Block[]): Array<{ id: string; name: string }> {
  return path.map((b) => {
    const type = elementType(b)
    const kind = blockKind(b)
    const name = type === 'row' && (kind === 'Section' || kind === 'Group') ? 'Row' : kind
    return { id: b.id, name }
  })
}

// ── Headings ─────────────────────────────────────────────────────────

function walk(blocks: Block[], visit: (b: Block) => void) {
  for (const b of blocks) {
    visit(b)
    if (b.children) walk(b.children, visit)
  }
}

export function countH1(blocks: Block[], exceptId?: string): number {
  let n = 0
  walk(blocks, (b) => {
    if (b.tag === 'h1' && b.id !== exceptId && !b.hidden) n++
  })
  return n
}

/** Changing this block to `level` would leave the page with more than one H1. */
export function wouldDuplicateH1(blocks: Block[], blockId: string, level: string): boolean {
  return level === 'h1' && countH1(blocks, blockId) >= 1
}

// ── Links ────────────────────────────────────────────────────────────

export type LinkKind = 'page' | 'url' | 'email' | 'phone' | 'section' | 'none'

export interface LinkTarget {
  kind: LinkKind
  value: string
}

export function parseHref(href: string | undefined): LinkTarget {
  const h = (href ?? '').trim()
  if (!h || h === '#') return { kind: 'none', value: '' }
  if (/^mailto:/i.test(h)) return { kind: 'email', value: decodeURIComponent(h.slice(7).split('?')[0]) }
  if (/^tel:/i.test(h)) return { kind: 'phone', value: h.slice(4) }
  if (h.startsWith('#')) return { kind: 'section', value: h.slice(1) }
  if (h.startsWith('/')) return { kind: 'page', value: h }
  return { kind: 'url', value: h }
}

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** The href to write, or an error in plain words. Never writes a script URL. */
export function buildHref(target: LinkTarget): { href: string } | { error: string } {
  const v = target.value.trim()
  switch (target.kind) {
    case 'none':
      return { href: '' }
    case 'page':
      if (!v) return { error: 'Pick a page' }
      return { href: v.startsWith('/') ? v : `/${v}` }
    case 'section':
      if (!v) return { error: 'Pick a section' }
      return { href: `#${v.replace(/^#/, '')}` }
    case 'email':
      if (!EMAIL.test(v)) return { error: 'That doesn’t look like an email address' }
      return { href: `mailto:${v}` }
    case 'phone': {
      const digits = v.replace(/[\s().-]/g, '')
      if (!/^\+?\d{6,15}$/.test(digits)) return { error: 'Use digits, with + and country code if outside the US' }
      return { href: `tel:${digits}` }
    }
    case 'url': {
      const withScheme = /^[a-z][a-z0-9+.-]*:/i.test(v) ? v : `https://${v}`
      try {
        const u = new URL(withScheme)
        if (u.protocol !== 'https:' && u.protocol !== 'http:') return { error: 'Only web addresses (https://…) can be linked' }
        if (!u.hostname.includes('.')) return { error: 'That doesn’t look like a web address' }
        return { href: withScheme }
      } catch {
        return { error: 'That doesn’t look like a web address' }
      }
    }
  }
}

/** Opening in a new tab: target + rel, together. */
export function newTabAttrs(on: boolean): Record<string, string | undefined> {
  return on ? { target: '_blank', rel: 'noopener noreferrer' } : { target: undefined, rel: undefined }
}

// ── Anchors ──────────────────────────────────────────────────────────

/** Sections someone can link to (blocks with an id), named the way the outline names them. */
export function pageAnchors(blocks: Block[]): Array<{ id: string; name: string }> {
  const out: Array<{ id: string; name: string }> = []
  walk(blocks, (b) => {
    const id = b.attrs?.id?.trim()
    if (id) out.push({ id, name: blockKind(b) })
  })
  return out
}

/** "Our Story!" → "our-story". */
export function toAnchorId(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48)
}

export function anchorTaken(blocks: Block[], id: string, exceptBlockId: string): boolean {
  let taken = false
  walk(blocks, (b) => {
    if (b.id !== exceptBlockId && b.attrs?.id === id) taken = true
  })
  return taken
}

// ── Images: caption and link ─────────────────────────────────────────

/** The figcaption next to an image inside its figure, if any. */
export function captionOf(parent: Block | null, imageId: string): Block | null {
  if (!parent || parent.tag !== 'figure') return null
  if (!parent.children?.some((c) => c.id === imageId)) return null
  return parent.children.find((c) => c.tag === 'figcaption') ?? null
}

function parentOf(blocks: Block[], id: string, parent: Block | null = null): Block | null | undefined {
  for (const b of blocks) {
    if (b.id === id) return parent
    const found = b.children ? parentOf(b.children, id, b) : undefined
    if (found !== undefined) return found
  }
  return undefined
}

/** Replace the block with this id (by one block or several). */
function replaceById(blocks: Block[], id: string, fn: (b: Block) => Block | Block[]): Block[] {
  return blocks.flatMap((b) => {
    if (b.id === id) return fn(b)
    return b.children ? { ...b, children: replaceById(b.children, id, fn) } : b
  })
}

const CAPTION_CLASS = 'mt-2 text-sm text-center opacity-80'

/**
 * Set an image's caption: wraps the image in a figure the first time,
 * updates the figcaption after, and unwraps again when the caption is cleared.
 */
export function setCaption(blocks: Block[], imageId: string, caption: string, makeId: () => string): Block[] {
  const text = caption.trim()
  const parent = parentOf(blocks, imageId)
  if (parent === undefined) return blocks
  if (parent?.tag === 'figure') {
    const kids = parent.children ?? []
    const cap = kids.find((c) => c.tag === 'figcaption')
    return replaceById(blocks, parent.id, (fig) => {
      if (!text) {
        const rest = kids.filter((c) => c.tag !== 'figcaption')
        return rest.length === 1 && !fig.attrs?.id && !fig.label ? rest : { ...fig, children: rest }
      }
      if (cap) return { ...fig, children: kids.map((c) => (c.id === cap.id ? { ...c, textContent: text } : c)) }
      return { ...fig, children: [...kids, { id: makeId(), tag: 'figcaption', className: CAPTION_CLASS, textContent: text }] }
    })
  }
  if (!text) return blocks
  return replaceById(blocks, imageId, (img) => ({
    id: makeId(),
    tag: 'figure',
    className: '',
    children: [img, { id: makeId(), tag: 'figcaption', className: CAPTION_CLASS, textContent: text }],
  }))
}

/** The link around an image (its parent `a` with only the image inside), if any. */
export function imageLinkOf(parent: Block | null, imageId: string): Block | null {
  if (!parent || parent.tag !== 'a') return null
  return parent.children?.length === 1 && parent.children[0].id === imageId ? parent : null
}

/** Link an image somewhere (wraps it in `a`), change it, or remove it (unwraps). */
export function setImageLink(blocks: Block[], imageId: string, href: string, makeId: () => string): Block[] {
  const parent = parentOf(blocks, imageId)
  if (parent === undefined) return blocks
  const link = imageLinkOf(parent, imageId)
  if (link) return replaceById(blocks, link.id, (a) => (href ? { ...a, attrs: { ...a.attrs, href } } : a.children![0]))
  if (!href) return blocks
  return replaceById(blocks, imageId, (img) => ({ id: makeId(), tag: 'a', className: 'block', attrs: { href }, children: [img] }))
}
