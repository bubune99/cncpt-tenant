/**
 * Read and write one Tailwind class group per device, the way the site is
 * already written: mobile-first — phone is the bare class, tablet `md:`,
 * desktop `lg:` (block-renderer's device visibility uses the same mapping).
 *
 * "All devices" sets the bare class and clears the md:/lg: ones of that
 * group. "This device only" sets the device's layer and pins the other
 * devices to what they showed before, so nothing else moves. Classes with
 * other variants (hover:, sm:, dark:, md:hover:) are never touched.
 * Pure; asserted by device-classes.assert.ts.
 */

export type Device = 'desktop' | 'tablet' | 'phone'
export type Scope = 'all' | 'device'
type Layer = '' | 'md:' | 'lg:'

export const DEVICE_PREFIX: Record<Device, Layer> = { phone: '', tablet: 'md:', desktop: 'lg:' }

/** Which utilities belong to the group (e.g. every `pt-*`). Gets the bare utility. */
export type Matcher = (utility: string) => boolean

const DEVICES: Device[] = ['phone', 'tablet', 'desktop']

/** Variant prefix and utility, split on the last top-level colon (brackets may hold colons). */
export function splitVariant(cls: string): { layer: Layer | null; utility: string } {
  let depth = 0
  let cut = -1
  for (let i = 0; i < cls.length; i++) {
    const ch = cls[i]
    if (ch === '[' || ch === '(') depth++
    else if (ch === ']' || ch === ')') depth--
    else if (ch === ':' && depth === 0) cut = i
  }
  if (cut < 0) return { layer: '', utility: cls }
  const variants = cls.slice(0, cut + 1)
  const utility = cls.slice(cut + 1)
  return { layer: variants === 'md:' || variants === 'lg:' ? variants : null, utility }
}

export function classList(className: string | undefined): string[] {
  return (className ?? '').split(/\s+/).filter(Boolean)
}

/** The value set at exactly this layer (no inheritance); the last one wins, as in CSS order. */
function layerValue(list: string[], layer: Layer, match: Matcher): string | null {
  let found: string | null = null
  for (const c of list) {
    const v = splitVariant(c)
    if (v.layer === layer && match(v.utility)) found = v.utility
  }
  return found
}

function effective(list: string[], device: Device, match: Matcher): string | null {
  const base = layerValue(list, '', match)
  if (device === 'phone') return base
  const md = layerValue(list, 'md:', match)
  if (device === 'tablet') return md ?? base
  return layerValue(list, 'lg:', match) ?? md ?? base
}

function setLayer(list: string[], layer: Layer, match: Matcher, value: string | null): string[] {
  const kept = list.filter((c) => {
    const v = splitVariant(c)
    return !(v.layer === layer && match(v.utility))
  })
  return value ? [...kept, `${layer}${value}`] : kept
}

/** Drop md:/lg: values that repeat what the device below already shows. */
function tidy(list: string[], match: Matcher): string[] {
  let out = list
  const base = layerValue(out, '', match)
  const md = layerValue(out, 'md:', match)
  if (md !== null && md === base) out = setLayer(out, 'md:', match, null)
  const lg = layerValue(out, 'lg:', match)
  if (lg !== null && lg === (layerValue(out, 'md:', match) ?? base)) out = setLayer(out, 'lg:', match, null)
  return out
}

/** What the device shows for this group (inherits from smaller devices). */
export function readAt(className: string | undefined, match: Matcher, device: Device): string | null {
  return effective(classList(className), device, match)
}

/** Does this group differ between devices (any md:/lg: value)? */
export function hasOverride(className: string | undefined, match: Matcher): boolean {
  return classList(className).some((c) => {
    const v = splitVariant(c)
    return (v.layer === 'md:' || v.layer === 'lg:') && match(v.utility)
  })
}

/**
 * Set the group to `value` (a bare utility, or null to remove). With scope
 * 'device', other devices keep what they showed; `fallback` pins a device
 * that had nothing set (e.g. 'text-left'), otherwise it may inherit.
 */
export function writeAt(
  className: string | undefined,
  match: Matcher,
  value: string | null,
  device: Device,
  scope: Scope,
  fallback?: string
): string {
  let list = classList(className)
  if (scope === 'all') {
    list = setLayer(setLayer(list, 'md:', match, null), 'lg:', match, null)
    return setLayer(list, '', match, value).join(' ')
  }
  const before = Object.fromEntries(DEVICES.map((d) => [d, effective(list, d, match)])) as Record<Device, string | null>
  list = setLayer(list, DEVICE_PREFIX[device], match, value)
  for (const d of DEVICES) {
    if (d === device) continue
    if (effective(list, d, match) === before[d]) continue
    const pin = before[d] ?? fallback ?? null
    if (pin) list = setLayer(list, DEVICE_PREFIX[d], match, pin)
  }
  return tidy(list, match).join(' ')
}

/** "Reset to all devices": what this device shows becomes the value everywhere. */
export function resetToAll(className: string | undefined, match: Matcher, device: Device): string {
  return writeAt(className, match, readAt(className, match, device), device, 'all')
}

/** Matcher from a regex over the bare utility. */
export const re = (r: RegExp): Matcher => (u) => r.test(u)
