/**
 * The design tokens the properties panel offers: each control is a class
 * group (what it may replace) and a short list of named choices (what it
 * writes). Anything on a block that isn't one of the choices reads back as
 * "Custom" — developers can type a class; everyone else picks a token.
 * Pure; asserted by tokens.assert.ts.
 */

import { BRAND_COLORS } from '../style-tokens'
import { re, type Matcher } from './device-classes'
import { COLUMN_PRESETS } from './rows'

export interface TokenOption {
  id: string
  label: string
  /** One bare utility, or several space-separated (written as one choice). */
  value: string
}

export interface TokenGroup {
  id: string
  label: string
  match: Matcher
  options: ReadonlyArray<TokenOption>
  /** Pins a device that had nothing set when another device changes. */
  fallback?: string
}

const opt = (id: string, label: string, value: string): TokenOption => ({ id, label, value })

const HEX = '\\[#[0-9a-fA-F]{3,8}\\]'
const NAMED = '(?:white|black|transparent|[a-z]+-\\d{2,3})(?:\\/\\d{1,3})?'

export const TEXT_COLOR: TokenGroup = {
  id: 'text-color',
  label: 'Text color',
  match: re(new RegExp(`^text-(?:${HEX}|${NAMED})$`)),
  options: BRAND_COLORS.map((c) => opt(c.id, c.name, `text-[${c.value}]`)),
}

export const BG_COLOR: TokenGroup = {
  id: 'bg-color',
  label: 'Background',
  match: re(new RegExp(`^bg-(?:${HEX}|${NAMED})$`)),
  options: [opt('none', 'None', 'bg-transparent'), ...BRAND_COLORS.map((c) => opt(c.id, c.name, `bg-[${c.value}]`))],
}

export const BORDER_COLOR: TokenGroup = {
  id: 'border-color',
  label: 'Border color',
  match: re(new RegExp(`^border-(?:${HEX}|${NAMED})$`)),
  options: BRAND_COLORS.map((c) => opt(c.id, c.name, `border-[${c.value}]`)),
}

export const BORDER_WIDTH: TokenGroup = {
  id: 'border-width',
  label: 'Border',
  match: re(/^border(?:-[0248])?$/),
  options: [opt('none', 'None', 'border-0'), opt('thin', 'Thin', 'border'), opt('thick', 'Thick', 'border-2')],
  fallback: 'border-0',
}

export const RADIUS: TokenGroup = {
  id: 'radius',
  label: 'Corners',
  match: re(/^rounded(?:-(?:none|xs|sm|md|lg|xl|2xl|3xl|full|\[[^\]]+\]))?$/),
  options: [
    opt('none', 'Square', 'rounded-none'),
    opt('S', 'S', 'rounded-md'),
    opt('M', 'M', 'rounded-xl'),
    opt('L', 'L', 'rounded-3xl'),
    opt('full', 'Round', 'rounded-full'),
  ],
  fallback: 'rounded-none',
}

export const OPACITY: TokenGroup = {
  id: 'opacity',
  label: 'Opacity',
  match: re(/^opacity-\d{1,3}$/),
  options: [opt('100', '100%', 'opacity-100'), opt('90', '90%', 'opacity-90'), opt('75', '75%', 'opacity-75'), opt('50', '50%', 'opacity-50'), opt('25', '25%', 'opacity-25')],
  fallback: 'opacity-100',
}

export const TEXT_ALIGN: TokenGroup = {
  id: 'text-align',
  label: 'Align',
  match: re(/^text-(?:left|center|right|justify|start|end)$/),
  options: [opt('left', 'Left', 'text-left'), opt('center', 'Centre', 'text-center'), opt('right', 'Right', 'text-right')],
  fallback: 'text-left',
}

export const TEXT_SIZE: TokenGroup = {
  id: 'text-size',
  label: 'Size',
  match: re(/^text-(?:xs|sm|base|lg|[2-9]?xl)$/),
  options: [opt('S', 'S', 'text-sm'), opt('M', 'M', 'text-base'), opt('L', 'L', 'text-lg'), opt('XL', 'XL', 'text-2xl')],
}

export const FONT_WEIGHT: TokenGroup = {
  id: 'font-weight',
  label: 'Weight',
  match: re(/^font-(?:thin|extralight|light|normal|medium|semibold|bold|extrabold|black)$/),
  options: [opt('normal', 'Regular', 'font-normal'), opt('medium', 'Medium', 'font-medium'), opt('semibold', 'Semibold', 'font-semibold'), opt('bold', 'Bold', 'font-bold')],
}

const TRACKING: Matcher = re(/^tracking-\S+$/)
const CASE: Matcher = re(/^(?:uppercase|lowercase|capitalize|normal-case)$/)

/** Heading type styles: each writes size, weight, letter spacing and case together. */
export const TYPE_STYLES: ReadonlyArray<{ id: string; label: string; size: string; weight: string; tracking: string; case: string }> = [
  { id: 'display', label: 'Display', size: 'text-6xl', weight: 'font-bold', tracking: 'tracking-tight', case: 'normal-case' },
  { id: 'title', label: 'Title', size: 'text-4xl', weight: 'font-bold', tracking: 'tracking-tight', case: 'normal-case' },
  { id: 'subtitle', label: 'Subtitle', size: 'text-2xl', weight: 'font-semibold', tracking: 'tracking-normal', case: 'normal-case' },
  { id: 'eyebrow', label: 'Eyebrow', size: 'text-sm', weight: 'font-semibold', tracking: 'tracking-widest', case: 'uppercase' },
]

export const HEADING_SIZE: TokenGroup = { ...TEXT_SIZE, options: TYPE_STYLES.map((t) => opt(t.id, t.label, t.size)) }
export const TYPE_PARTS: ReadonlyArray<{ part: 'size' | 'weight' | 'tracking' | 'case'; match: Matcher }> = [
  { part: 'size', match: TEXT_SIZE.match },
  { part: 'weight', match: FONT_WEIGHT.match },
  { part: 'tracking', match: TRACKING },
  { part: 'case', match: CASE },
]

/** Section padding runs larger than element padding (matches the strip's section sizes). */
export const SPACE_STEPS = {
  section: [opt('none', 'None', '0'), opt('S', 'S', '8'), opt('M', 'M', '12'), opt('L', 'L', '20'), opt('XL', 'XL', '32')],
  element: [opt('none', 'None', '0'), opt('S', 'S', '2'), opt('M', 'M', '4'), opt('L', 'L', '6'), opt('XL', 'XL', '10')],
} as const

export const GAP: TokenGroup = {
  id: 'gap',
  label: 'Gap',
  match: re(/^gap-(?:\d+(?:\.5)?|px|\[[^\]]+\])$/),
  options: [opt('none', 'None', 'gap-0'), opt('S', 'S', 'gap-2'), opt('M', 'M', 'gap-4'), opt('L', 'L', 'gap-8'), opt('XL', 'XL', 'gap-12')],
  fallback: 'gap-0',
}

/** Containers: how wide the content runs. Writes max width; centring is margin auto. */
export const WIDTH: TokenGroup = {
  id: 'width',
  label: 'Width',
  match: re(/^max-w-\S+$/),
  options: [opt('content', 'Content', 'max-w-5xl'), opt('wide', 'Wide', 'max-w-7xl'), opt('full', 'Full bleed', 'max-w-none')],
  fallback: 'max-w-none',
}

/** Text, buttons and images: the longest line / largest size. */
export const MAX_WIDTH: TokenGroup = {
  id: 'max-width',
  label: 'Max width',
  match: re(/^max-w-\S+$/),
  options: [opt('S', 'S', 'max-w-sm'), opt('M', 'M', 'max-w-xl'), opt('L', 'L', 'max-w-3xl'), opt('none', 'None', 'max-w-none')],
  fallback: 'max-w-none',
}

export const MIN_HEIGHT: TokenGroup = {
  id: 'min-height',
  label: 'Min height',
  match: re(/^min-h-\S+$/),
  options: [opt('none', 'None', 'min-h-0'), opt('S', 'S', 'min-h-64'), opt('M', 'M', 'min-h-96'), opt('L', 'L', 'min-h-[70vh]'), opt('screen', 'Screen', 'min-h-screen')],
  fallback: 'min-h-0',
}

export const JUSTIFY: TokenGroup = {
  id: 'justify',
  label: 'Horizontal',
  match: re(/^justify-(?:start|center|end|between|around|evenly|stretch)$/),
  options: [opt('start', 'Start', 'justify-start'), opt('center', 'Centre', 'justify-center'), opt('end', 'End', 'justify-end'), opt('between', 'Spread', 'justify-between')],
  fallback: 'justify-start',
}

export const ITEMS: TokenGroup = {
  id: 'items',
  label: 'Vertical',
  match: re(/^items-(?:start|center|end|stretch|baseline)$/),
  options: [opt('start', 'Top', 'items-start'), opt('center', 'Middle', 'items-center'), opt('end', 'Bottom', 'items-end'), opt('stretch', 'Stretch', 'items-stretch')],
  fallback: 'items-stretch',
}

export const OBJECT_FIT: TokenGroup = {
  id: 'fit',
  label: 'Fit',
  match: re(/^object-(?:cover|contain|fill|none|scale-down)$/),
  options: [opt('cover', 'Fill frame', 'object-cover'), opt('contain', 'Whole image', 'object-contain')],
}

export const ASPECT: TokenGroup = {
  id: 'aspect',
  label: 'Shape',
  match: re(/^aspect-\S+$/),
  options: [opt('auto', 'Original', 'aspect-auto'), opt('square', 'Square', 'aspect-square'), opt('video', 'Wide 16:9', 'aspect-video'), opt('photo', 'Photo 4:3', 'aspect-[4/3]'), opt('portrait', 'Portrait', 'aspect-[3/4]')],
  fallback: 'aspect-auto',
}

/** Which option a utility (or set of utilities) is; 'custom' when set but not a token; null when unset. */
export function optionFor(group: TokenGroup, value: string | null): string | null {
  if (!value) return null
  return group.options.find((o) => o.value === value)?.id ?? 'custom'
}

/** Every token class the panel can write, for the Tailwind safelist (globals.css @source inline). */
export function allTokenClasses(): string[] {
  const groups = [TEXT_COLOR, BG_COLOR, BORDER_COLOR, BORDER_WIDTH, RADIUS, OPACITY, TEXT_ALIGN, TEXT_SIZE, FONT_WEIGHT, GAP, WIDTH, MAX_WIDTH, MIN_HEIGHT, JUSTIFY, ITEMS, OBJECT_FIT, ASPECT]
  const out = new Set<string>()
  for (const g of groups) for (const o of g.options) for (const c of o.value.split(' ')) out.add(c)
  for (const t of TYPE_STYLES) for (const c of [t.size, t.weight, t.tracking, t.case]) out.add(c)
  for (const p of COLUMN_PRESETS) out.add(p.cols)
  return [...out]
}
