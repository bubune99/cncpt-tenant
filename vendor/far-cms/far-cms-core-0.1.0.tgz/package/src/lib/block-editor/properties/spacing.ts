/**
 * Padding and margin per side, per device. The site mixes shorthands
 * (`p-4`, `py-20`, `px-6`) with single sides (`pt-8`); to change one side
 * the shorthands are expanded at that layer, the side is set, then the
 * layer is folded back into the shortest classes (p- / px- / py-).
 * Pure; asserted by device-classes.assert.ts.
 */

import { classList, readAt, re, splitVariant, writeAt, type Device, type Scope } from './device-classes'

export type SpaceKind = 'p' | 'm'
export type Side = 't' | 'r' | 'b' | 'l'
export const SIDES: Side[] = ['t', 'r', 'b', 'l']

const LAYERS = ['', 'md:', 'lg:'] as const

/** `-mt-4` → { kind: 'm', axis: 't', value: '-4' }; null for anything else. */
function parse(utility: string): { kind: SpaceKind; axis: '' | 'x' | 'y' | Side; value: string } | null {
  const m = /^(-?)([pm])([xytrbl]?)-(.+)$/.exec(utility)
  if (!m) return null
  if (m[1] && m[2] === 'p') return null
  return { kind: m[2] as SpaceKind, axis: m[3] as '' | 'x' | 'y' | Side, value: `${m[1]}${m[4]}` }
}

function utilityFor(kind: SpaceKind, axis: string, value: string): string {
  const neg = value.startsWith('-')
  return `${neg ? '-' : ''}${kind}${axis}-${neg ? value.slice(1) : value}`
}

const sideMatcher = (kind: SpaceKind, side: Side) => re(new RegExp(`^-?${kind}${side}-`))

/** Per-side values of one layer, honouring CSS specificity order (p < px/py < pt…). */
function layerSides(list: string[], layer: string, kind: SpaceKind): Record<Side, string | null> {
  const out: Record<Side, string | null> = { t: null, r: null, b: null, l: null }
  const rank: Record<Side, number> = { t: -1, r: -1, b: -1, l: -1 }
  const weight = { '': 0, x: 1, y: 1, t: 2, r: 2, b: 2, l: 2 } as const
  const covers = { '': SIDES, x: ['l', 'r'], y: ['t', 'b'], t: ['t'], r: ['r'], b: ['b'], l: ['l'] } as const
  for (const c of list) {
    const v = splitVariant(c)
    if (v.layer !== layer) continue
    const p = parse(v.utility)
    if (!p || p.kind !== kind) continue
    for (const s of covers[p.axis]) {
      if (weight[p.axis] >= rank[s]) {
        out[s] = p.value
        rank[s] = weight[p.axis]
      }
    }
  }
  return out
}

function rewriteLayer(list: string[], layer: string, kind: SpaceKind, fold: boolean): string[] {
  const sides = layerSides(list, layer, kind)
  const kept = list.filter((c) => {
    const v = splitVariant(c)
    const p = v.layer === layer ? parse(v.utility) : null
    return !(p && p.kind === kind)
  })
  const add: string[] = []
  const { t, r, b, l } = sides
  if (fold && t !== null && t === r && t === b && t === l) add.push(utilityFor(kind, '', t))
  else {
    if (fold && t !== null && t === b) add.push(utilityFor(kind, 'y', t))
    else {
      if (t !== null) add.push(utilityFor(kind, 't', t))
      if (b !== null) add.push(utilityFor(kind, 'b', b))
    }
    if (fold && l !== null && l === r) add.push(utilityFor(kind, 'x', l))
    else {
      if (r !== null) add.push(utilityFor(kind, 'r', r))
      if (l !== null) add.push(utilityFor(kind, 'l', l))
    }
  }
  return [...kept, ...add.map((u) => `${layer}${u}`)]
}

function rewrite(className: string, kind: SpaceKind, fold: boolean): string {
  let list = classList(className)
  for (const layer of LAYERS) list = rewriteLayer(list, layer, kind, fold)
  return list.join(' ')
}

/** The value one side shows on this device ('4', '-2', 'auto', '[13px]'), or null. */
export function readSide(className: string | undefined, kind: SpaceKind, side: Side, device: Device): string | null {
  const expanded = rewrite(className ?? '', kind, false)
  const u = readAt(expanded, sideMatcher(kind, side), device)
  return u ? parse(u)?.value ?? null : null
}

/** Set some sides to one value (linked sides pass all four). */
export function writeSides(
  className: string | undefined,
  kind: SpaceKind,
  sides: Side[],
  value: string,
  device: Device,
  scope: Scope
): string {
  let next = rewrite(className ?? '', kind, false)
  for (const s of sides) next = writeAt(next, sideMatcher(kind, s), utilityFor(kind, s, value), device, scope, utilityFor(kind, s, '0'))
  return rewrite(next, kind, true)
}

/** Any md:/lg: padding (or margin) at all. */
export function spacingVaries(className: string | undefined, kind: SpaceKind): boolean {
  return classList(className).some((c) => {
    const v = splitVariant(c)
    const p = v.layer === 'md:' || v.layer === 'lg:' ? parse(v.utility) : null
    return !!p && p.kind === kind
  })
}

/** Every side gets what this device shows; the md:/lg: values go. */
export function resetSpacing(className: string | undefined, kind: SpaceKind, device: Device): string {
  const values = SIDES.map((s) => readSide(className, kind, s, device))
  let list = classList(className).filter((c) => {
    const v = splitVariant(c)
    const p = v.layer !== null ? parse(v.utility) : null
    return !(p && p.kind === kind)
  })
  SIDES.forEach((s, i) => {
    const v = values[i]
    if (v !== null) list = [...list, utilityFor(kind, s, v)]
  })
  return rewrite(list.join(' '), kind, true)
}
