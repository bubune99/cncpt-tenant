/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/properties/content.assert.ts
 */
import assert from 'node:assert/strict'
import type { Block } from '../types'
import { updateBlockInTree } from '../tree-utils'
import {
  anchorTaken,
  breadcrumb,
  buildHref,
  captionOf,
  countH1,
  elementType,
  imageLinkOf,
  newTabAttrs,
  pageAnchors,
  parseHref,
  setCaption,
  setImageLink,
  tabsFor,
  toAnchorId,
  wouldDuplicateH1,
} from './content'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
let seq = 0
const makeId = () => `new-${++seq}`

const page: Block[] = [
  {
    id: 'hero',
    tag: 'section',
    className: 'py-20 bg-[#022b39]',
    attrs: { id: 'top' },
    children: [
      { id: 'h1', tag: 'h1', className: 'text-6xl', textContent: 'Delivering Hope' },
      {
        id: 'row',
        tag: 'div',
        className: 'grid grid-cols-1 md:grid-cols-2 gap-8',
        children: [
          { id: 'img', tag: 'img', className: 'w-full', attrs: { src: '/a.jpg', alt: 'Kids reading' } },
          { id: 'cta', tag: 'a', className: 'px-6 py-3', textContent: 'Donate', attrs: { href: '/donate' } },
        ],
      },
    ],
  },
  { id: 'story', tag: 'section', className: 'py-12', attrs: { id: 'our-story' }, children: [{ id: 'h2', tag: 'h2', className: '', textContent: 'Our Story' }] },
]

check('element types decide the tabs, most used first', () => {
  assert.equal(elementType({ tag: 'h2', className: '' }), 'heading')
  assert.equal(elementType({ tag: 'a', className: '' }), 'button')
  assert.equal(elementType({ tag: 'div', className: 'grid grid-cols-1 md:grid-cols-2' }), 'row')
  assert.equal(elementType({ tag: 'section', className: 'py-20' }), 'section')
  assert.equal(elementType({ tag: 'div', className: '', componentName: 'FormBlock' }), 'smart')
  assert.deepEqual(tabsFor('heading').slice(0, 2), ['content', 'style'])
  assert.deepEqual(tabsFor('row')[0], 'layout')
  assert.ok(!tabsFor('section').includes('content'))
})

check('breadcrumb names each level the way a person would', () => {
  const path = [page[0], page[0].children![1], page[0].children![1].children![1]]
  assert.deepEqual(breadcrumb(path), [
    { id: 'hero', name: 'Hero' },
    { id: 'row', name: 'Row' },
    { id: 'cta', name: 'Button' },
  ])
})

check('one H1 per page: warn before a second one', () => {
  assert.equal(countH1(page), 1)
  assert.equal(wouldDuplicateH1(page, 'h2', 'h1'), true)
  assert.equal(wouldDuplicateH1(page, 'h1', 'h1'), false)
  assert.equal(wouldDuplicateH1(page, 'h2', 'h3'), false)
})

check('link destinations parse into kinds and back', () => {
  assert.deepEqual(parseHref('/donate'), { kind: 'page', value: '/donate' })
  assert.deepEqual(parseHref('mailto:hi@dzidzor.org'), { kind: 'email', value: 'hi@dzidzor.org' })
  assert.deepEqual(parseHref('tel:+15551234567'), { kind: 'phone', value: '+15551234567' })
  assert.deepEqual(parseHref('#our-story'), { kind: 'section', value: 'our-story' })
  assert.deepEqual(parseHref('https://x.org/a'), { kind: 'url', value: 'https://x.org/a' })
  assert.deepEqual(parseHref('#'), { kind: 'none', value: '' })
  assert.deepEqual(buildHref({ kind: 'email', value: ' hi@dzidzor.org ' }), { href: 'mailto:hi@dzidzor.org' })
  assert.deepEqual(buildHref({ kind: 'phone', value: '+1 (555) 123-4567' }), { href: 'tel:+15551234567' })
  assert.deepEqual(buildHref({ kind: 'url', value: 'gofundme.com/x' }), { href: 'https://gofundme.com/x' })
  assert.deepEqual(buildHref({ kind: 'section', value: 'our-story' }), { href: '#our-story' })
  assert.deepEqual(buildHref({ kind: 'page', value: 'about' }), { href: '/about' })
})

check('bad destinations are refused in plain words — never a script URL', () => {
  assert.ok('error' in buildHref({ kind: 'url', value: 'javascript:alert(1)' }))
  assert.ok('error' in buildHref({ kind: 'url', value: 'data:text/html,hi' }))
  assert.ok('error' in buildHref({ kind: 'url', value: 'localhost' }))
  assert.ok('error' in buildHref({ kind: 'email', value: 'not-an-email' }))
  assert.ok('error' in buildHref({ kind: 'phone', value: '12' }))
})

check('new tab sets target and rel together; turning it off removes both', () => {
  assert.deepEqual(newTabAttrs(true), { target: '_blank', rel: 'noopener noreferrer' })
  const on = updateBlockInTree(page, 'cta', { attrs: newTabAttrs(true) as Record<string, string> })
  const off = updateBlockInTree(on, 'cta', { attrs: newTabAttrs(false) as Record<string, string> })
  const cta = off[0].children![1].children![1]
  assert.equal('target' in (cta.attrs ?? {}), false)
  assert.equal('rel' in (cta.attrs ?? {}), false)
  assert.equal(cta.attrs?.href, '/donate')
})

check('anchors: the sections you can link to, slugged and unique', () => {
  assert.deepEqual(pageAnchors(page), [{ id: 'top', name: 'Hero' }, { id: 'our-story', name: 'Section' }])
  assert.equal(toAnchorId('  Our Story — Déjà vu! '), 'our-story-deja-vu')
  assert.equal(anchorTaken(page, 'our-story', 'hero'), true)
  assert.equal(anchorTaken(page, 'our-story', 'story'), false)
})

check('caption: wraps in a figure, edits it, unwraps when cleared', () => {
  const withCap = setCaption(page, 'img', 'Reading club, 2025', makeId)
  const row = withCap[0].children![1]
  const fig = row.children![0]
  assert.equal(fig.tag, 'figure')
  assert.equal(fig.children![0].id, 'img')
  assert.equal(captionOf(fig, 'img')?.textContent, 'Reading club, 2025')
  const edited = setCaption(withCap, 'img', 'Reading club', makeId)
  assert.equal(captionOf(edited[0].children![1].children![0], 'img')?.textContent, 'Reading club')
  assert.equal(edited[0].children![1].children![0].children!.length, 2)
  const cleared = setCaption(edited, 'img', '  ', makeId)
  assert.equal(cleared[0].children![1].children![0].id, 'img')
  assert.deepEqual(setCaption(page, 'nope', 'x', makeId), page)
})

check('image link: wraps in a link, changes it, unwraps when removed', () => {
  const linked = setImageLink(page, 'img', '/gallery', makeId)
  const a = linked[0].children![1].children![0]
  assert.equal(a.tag, 'a')
  assert.equal(imageLinkOf(a, 'img')?.attrs?.href, '/gallery')
  const moved = setImageLink(linked, 'img', '/donate', makeId)
  assert.equal(moved[0].children![1].children![0].attrs?.href, '/donate')
  const removed = setImageLink(moved, 'img', '', makeId)
  assert.equal(removed[0].children![1].children![0].id, 'img')
})

console.log(`\n${n} checks passed`)
