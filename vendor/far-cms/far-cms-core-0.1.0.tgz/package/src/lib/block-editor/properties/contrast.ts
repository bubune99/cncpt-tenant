/**
 * Text contrast against its background (WCAG 2.x relative luminance).
 * The panel warns below AA: 4.5:1 for body text, 3:1 for large text
 * (24px+, or 18.5px+ bold). Colours come from the block and its parents'
 * classes; a background image counts through its dark overlay, judged
 * against the worst case (a pure white or pure black photo).
 * Pure; asserted by contrast.assert.ts.
 */

import { readAt, type Device } from './device-classes'
import { BG_COLOR, TEXT_COLOR, TEXT_SIZE, FONT_WEIGHT } from './tokens'

export type RGB = [number, number, number]

const NAMED: Record<string, RGB> = { white: [255, 255, 255], black: [0, 0, 0] }

export function parseHex(hex: string): RGB | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return null
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1]
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as RGB
}

/** `text-[#022b39]` / `bg-white` → RGB; null for colours we can't resolve (palette names, opacity). */
export function colorOfUtility(utility: string | null): RGB | null {
  if (!utility) return null
  const v = utility.replace(/^(?:text|bg|border)-/, '')
  const hex = /^\[(#[0-9a-fA-F]{3,8})\]$/.exec(v)
  if (hex) return parseHex(hex[1])
  return NAMED[v] ?? null
}

function channel(c: number): number {
  const s = c / 255
  return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
}

export function luminance([r, g, b]: RGB): number {
  return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)
}

export function contrastRatio(a: RGB, b: RGB): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x)
  return (hi + 0.05) / (lo + 0.05)
}

/** A black overlay of this strength over a colour. */
export function darken(c: RGB, alpha: number): RGB {
  return c.map((v) => Math.round(v * (1 - alpha))) as RGB
}

/** "rgba(0,0,0,0.4)" ↔ 0.4 — the overlay's darkness, as the panel writes it. */
export function overlayDarkness(overlay: string | undefined): number {
  const m = /^rgba\(\s*0\s*,\s*0\s*,\s*0\s*,\s*([0-9.]+)\s*\)$/.exec(overlay ?? '')
  return m ? Math.min(1, Math.max(0, Number(m[1]))) : 0
}

export function overlayFor(darkness: number): string | undefined {
  const a = Math.round(Math.min(0.9, Math.max(0, darkness)) * 100) / 100
  return a > 0 ? `rgba(0,0,0,${a})` : undefined
}

const LARGE = new Set(['text-2xl', 'text-3xl', 'text-4xl', 'text-5xl', 'text-6xl', 'text-7xl', 'text-8xl', 'text-9xl'])
const BOLD = new Set(['font-bold', 'font-extrabold', 'font-black', 'font-semibold'])

/** WCAG "large text": 24px+, or bold at 18.5px+ (text-xl is 20px). */
export function isLargeText(className: string | undefined, device: Device, tag?: string): boolean {
  const size = readAt(className, TEXT_SIZE.match, device)
  const weight = readAt(className, FONT_WEIGHT.match, device)
  if (size && LARGE.has(size)) return true
  const bold = (weight ? BOLD.has(weight) : /^h[1-6]$/.test(tag ?? ''))
  return bold && size === 'text-xl'
}

export interface ContrastLayer {
  className?: string
  /** Background image overlay, e.g. "rgba(0,0,0,0.5)". */
  imageOverlay?: string
  hasImage?: boolean
}

export interface ContrastResult {
  ratio: number
  required: number
  passes: boolean
  /** True when judged against a background photo's worst case. */
  overImage: boolean
}

/**
 * Check the selected block's text against the nearest background, walking
 * from the block outwards (path is root → block). Null when either colour
 * can't be resolved — the panel says nothing rather than guess.
 */
export function checkContrast(path: ContrastLayer[], device: Device, tag?: string, pageText: RGB = [23, 23, 23]): ContrastResult | null {
  if (path.length === 0) return null
  const self = path[path.length - 1]
  let text: RGB | null = null
  for (let i = path.length - 1; i >= 0 && !text; i--) {
    const u = readAt(path[i].className, TEXT_COLOR.match, device)
    if (u) {
      text = colorOfUtility(u)
      if (!text) return null
    }
  }
  text = text ?? pageText
  let backgrounds: RGB[] | null = null
  let overImage = false
  for (let i = path.length - 1; i >= 0 && !backgrounds; i--) {
    const layer = path[i]
    if (layer.hasImage) {
      const a = overlayDarkness(layer.imageOverlay)
      backgrounds = [darken([255, 255, 255], a), darken([0, 0, 0], a)]
      overImage = true
      break
    }
    const u = readAt(layer.className, BG_COLOR.match, device)
    if (u && u !== 'bg-transparent') {
      const c = colorOfUtility(u)
      if (!c) return null
      backgrounds = [c]
    }
  }
  backgrounds = backgrounds ?? [[255, 255, 255]]
  const ratio = Math.min(...backgrounds.map((b) => contrastRatio(text!, b)))
  const required = isLargeText(self.className, device, tag) ? 3 : 4.5
  return { ratio: Math.round(ratio * 100) / 100, required, passes: ratio >= required, overImage }
}
