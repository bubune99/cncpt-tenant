/**
 * Rows of columns. A row is written as a grid on tablet and up and a
 * stack on phones (the site's own pattern: `grid grid-cols-1 md:grid-cols-3`).
 * Reversed stacking uses a reversed flex column on phones only:
 * `flex flex-col-reverse md:grid md:grid-cols-2`.
 * Pure; asserted by tokens.assert.ts.
 */

import { classList, splitVariant } from './device-classes'

export type ColumnPreset = '1' | '1:1' | '1:1:1' | '1:1:1:1' | '2:1' | '1:2'
export type StackOrder = 'stack' | 'reverse' | 'side-by-side'

export const COLUMN_PRESETS: ReadonlyArray<{ id: ColumnPreset; label: string; cols: string }> = [
  { id: '1', label: '1', cols: 'grid-cols-1' },
  { id: '1:1', label: '2', cols: 'grid-cols-2' },
  { id: '1:1:1', label: '3', cols: 'grid-cols-3' },
  { id: '1:1:1:1', label: '4', cols: 'grid-cols-4' },
  { id: '2:1', label: '2 : 1', cols: 'grid-cols-[2fr_1fr]' },
  { id: '1:2', label: '1 : 2', cols: 'grid-cols-[1fr_2fr]' },
]

const DISPLAY = /^(?:flex|grid|block|inline-flex|inline-grid)$/
const COLS = /^grid-cols-\S+$/
const DIRECTION = /^flex-(?:row|col|row-reverse|col-reverse)$/

function at(list: string[], layer: string, r: RegExp): string | null {
  let v: string | null = null
  for (const c of list) {
    const s = splitVariant(c)
    if (s.layer === layer && r.test(s.utility)) v = s.utility
  }
  return v
}

/** Side by side on desktop — a grid with 2+ columns, or a flex row. */
export function isRow(className: string | undefined): boolean {
  const list = classList(className)
  const desk = (r: RegExp) => at(list, 'lg:', r) ?? at(list, 'md:', r) ?? at(list, '', r)
  const display = desk(DISPLAY)
  if (display === 'grid' || display === 'inline-grid') {
    const cols = desk(COLS)
    return !!cols && cols !== 'grid-cols-1'
  }
  if (display === 'flex' || display === 'inline-flex') {
    const dir = desk(DIRECTION)
    return !dir || dir === 'flex-row' || dir === 'flex-row-reverse'
  }
  return false
}

/** The current preset and phone behaviour (null preset = something hand-made). */
export function readRow(className: string | undefined): { preset: ColumnPreset | null; stack: StackOrder } {
  const list = classList(className)
  const cols = at(list, 'lg:', COLS) ?? at(list, 'md:', COLS) ?? at(list, '', COLS)
  const preset = COLUMN_PRESETS.find((p) => p.cols === cols)?.id ?? null
  const baseDisplay = at(list, '', DISPLAY)
  const baseDir = at(list, '', DIRECTION)
  const baseCols = at(list, '', COLS)
  let stack: StackOrder = 'stack'
  if (baseDisplay === 'flex' && baseDir === 'flex-col-reverse') stack = 'reverse'
  else if (baseDisplay === 'grid' && baseCols && baseCols !== 'grid-cols-1') stack = 'side-by-side'
  return { preset, stack }
}

/** Write a row: drops display / direction / columns at every layer, keeps everything else. */
export function writeRow(className: string | undefined, preset: ColumnPreset, stack: StackOrder): string {
  const cols = COLUMN_PRESETS.find((p) => p.id === preset)?.cols ?? 'grid-cols-2'
  const kept = classList(className).filter((c) => {
    const s = splitVariant(c)
    if (s.layer === null) return true
    return !(DISPLAY.test(s.utility) || COLS.test(s.utility) || DIRECTION.test(s.utility))
  })
  const add =
    stack === 'side-by-side' || preset === '1'
      ? ['grid', cols]
      : stack === 'reverse'
        ? ['flex', 'flex-col-reverse', 'md:grid', `md:${cols}`]
        : ['grid', 'grid-cols-1', `md:${cols}`]
  return [...kept, ...add].join(' ')
}
