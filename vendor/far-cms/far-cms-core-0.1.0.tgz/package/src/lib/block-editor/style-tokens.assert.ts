/**
 * Run: npx -y tsx@4.23.15 src/lib/block-editor/style-tokens.assert.ts
 */
import assert from 'node:assert/strict'
import { BRAND_COLORS, applyAlign, applyColor, applySize, readStyle, styleKind } from './style-tokens'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const amber = BRAND_COLORS.find((c) => c.id === 'amber')!
const navy = BRAND_COLORS.find((c) => c.id === 'navy')!

check('each choice swaps one class group and keeps the rest', () => {
  const h = "text-4xl text-[#022b39] mb-6 font-['Fredoka_One']"
  assert.equal(applyColor(h, 'heading', amber), "text-4xl mb-6 font-['Fredoka_One'] text-[#b45309]")
  assert.equal(applySize(h, 'heading', 'XL'), "text-[#022b39] mb-6 font-['Fredoka_One'] text-6xl")
  assert.equal(applyAlign('text-left mb-2', 'center'), 'mb-2 text-center')
  assert.equal(applySize('py-20 bg-white', 'section', 'S'), 'bg-white py-8')
  assert.equal(applyColor('py-20 bg-white', 'section', navy), 'py-20 bg-[#022b39]')
})

check('size does not eat the colour, colour does not eat the size', () => {
  const t = applySize(applyColor('text-lg', 'text', amber), 'text', 'S')
  assert.equal(t, 'text-[#b45309] text-sm')
})

check('controls read back the current choice', () => {
  assert.deepEqual(readStyle("text-4xl text-[#022B39] text-center", 'heading'), { color: 'navy', size: 'L', align: 'center' })
  assert.deepEqual(readStyle('py-12 bg-[#f5f8ff]', 'section'), { color: 'mist', size: 'M', align: null })
})

check('kinds come from the tag', () => {
  assert.equal(styleKind('h2'), 'heading')
  assert.equal(styleKind('a'), 'button')
  assert.equal(styleKind('section'), 'section')
  assert.equal(styleKind('img'), 'image')
  assert.equal(styleKind('blockquote'), 'text')
})

console.log(`\n${n} checks passed`)
