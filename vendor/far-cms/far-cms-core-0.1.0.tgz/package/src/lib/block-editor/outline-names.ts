/**
 * Name page blocks the way a person would ("Hero — “Delivering Hope”"),
 * not by tag. Pure; asserted by outline-names.assert.ts.
 */

export interface NamedBlock {
  id?: string
  tag?: string
  label?: string
  textContent?: string
  componentName?: string
  className?: string
  attrs?: Record<string, string>
  children?: NamedBlock[]
}

const COMPONENT_NAMES: Record<string, string> = {
  InitiativeHighlights: "Initiative cards",
  InitiativeBlock: "Initiative",
  InitiativeCard: "Initiative card",
  InitiativeHeader: "Initiative header",
  InitiativeStats: "Initiative numbers",
  FormBlock: "Form",
  PartialReference: "Shared section",
  ProductGrid: "Products",
}

const TAG_NAMES: Record<string, string> = {
  h1: "Heading",
  h2: "Heading",
  h3: "Subheading",
  h4: "Subheading",
  p: "Text",
  a: "Button",
  button: "Button",
  img: "Image",
  video: "Video",
  iframe: "Video",
  blockquote: "Quote",
  ul: "List",
  ol: "List",
  form: "Form",
  header: "Header",
  footer: "Footer",
  nav: "Menu",
}

function walk(block: NamedBlock, visit: (b: NamedBlock) => void) {
  visit(block)
  for (const c of block.children ?? []) walk(c, visit)
}

function firstText(block: NamedBlock, tags: string[]): string | null {
  let found: string | null = null
  walk(block, (b) => {
    if (!found && b.tag && tags.includes(b.tag) && b.textContent?.trim()) found = b.textContent.trim()
  })
  return found
}

function has(block: NamedBlock, pred: (b: NamedBlock) => boolean): boolean {
  let hit = false
  walk(block, (b) => {
    if (!hit && b !== block && pred(b)) hit = true
  })
  return hit
}

export function shorten(text: string, max = 36): string {
  const t = text.replace(/\s+/g, " ").trim()
  return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t
}

/** What kind of thing this is, in plain words. */
export function blockKind(block: NamedBlock): string {
  if (block.label?.trim()) return block.label.trim()
  if (block.componentName) return COMPONENT_NAMES[block.componentName] ?? "Live content"
  const tag = block.tag ?? "div"
  if (tag === "section" || tag === "div") {
    if (has(block, (b) => b.tag === "h1") && /bg-cover|bg-\[url|backgroundImage/.test(`${block.className ?? ""} ${block.attrs?.style ?? ""}`)) return "Hero"
    if (has(block, (b) => b.tag === "h1")) return "Hero"
    if (has(block, (b) => b.tag === "iframe" || b.tag === "video")) return "Video"
    if (has(block, (b) => b.componentName === "FormBlock" || b.tag === "form")) return "Form"
    if (has(block, (b) => b.componentName?.startsWith("Initiative") ?? false)) return "Initiatives"
    if (has(block, (b) => b.tag === "blockquote")) return "Quote"
    const imgs = (() => {
      let n = 0
      walk(block, (b) => {
        if (b.tag === "img") n++
      })
      return n
    })()
    if (imgs >= 3) return "Gallery"
    if (imgs >= 1 && has(block, (b) => /^h[1-6]$/.test(b.tag ?? ""))) return "Photo + text"
    return tag === "section" ? "Section" : "Group"
  }
  return TAG_NAMES[tag] ?? "Element"
}

/** "Hero — “Delivering Hope”"; just the kind when there is nothing to quote. */
export function outlineName(block: NamedBlock): string {
  const kind = blockKind(block)
  const own = block.textContent?.trim()
  const quote = own || firstText(block, ["h1", "h2", "h3"]) || firstText(block, ["p", "a", "blockquote"])
  if (!quote || block.tag === "img") return block.tag === "img" && block.attrs?.alt ? `${kind} — ${shorten(block.attrs.alt)}` : kind
  return `${kind} — “${shorten(quote)}”`
}
