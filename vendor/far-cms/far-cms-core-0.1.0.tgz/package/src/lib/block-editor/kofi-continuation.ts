/**
 * Kofi client-side auto-continue + limit-error decisions. Pure and
 * client-safe (no server imports). Asserted by kofi-continuation.assert.ts.
 */

/** Automatic continuations the panel sends for one user message. */
export const MAX_CONTINUATIONS = 3

export interface ContinuationInput {
  /** finishReason of the run that just ended */
  finishReason: string | undefined
  /** server metadata: the token budget (not the model) ended the run */
  budgetStop: boolean
  /** server metadata: the runaway-loop guard ended the run */
  loopStop?: boolean
  /** continuations already sent for this user message */
  count: number
  max: number
  /** the user pressed stop */
  wasStopped: boolean
  /** the user queued a message while Kofi was streaming */
  queued: boolean
}

export type ContinuationDecision =
  | { continue: true; nextCount: number }
  | { continue: false; nextCount: 0; why: 'stopped' | 'queued' | 'budget' | 'loop' | 'finished' | 'max' }

export function decideAutoContinue(input: ContinuationInput): ContinuationDecision {
  if (input.wasStopped) return { continue: false, nextCount: 0, why: 'stopped' }
  if (input.queued) return { continue: false, nextCount: 0, why: 'queued' }
  // A budget stop reports finishReason "tool-calls" too; continuing it would
  // just start another capped run, so it is never continued.
  if (input.budgetStop) return { continue: false, nextCount: 0, why: 'budget' }
  // The loop guard stopped a model that was repeating itself or failing every
  // tool call; another run would just repeat it on the user's dime.
  if (input.loopStop) return { continue: false, nextCount: 0, why: 'loop' }
  if (input.finishReason !== 'length' && input.finishReason !== 'tool-calls') {
    return { continue: false, nextCount: 0, why: 'finished' }
  }
  if (input.count >= input.max) return { continue: false, nextCount: 0, why: 'max' }
  return { continue: true, nextCount: input.count + 1 }
}

/** Read the `kofiBudgetStop` flag from an assistant message's metadata. */
export function isBudgetStop(metadata: unknown): boolean {
  return Boolean(
    metadata && typeof metadata === 'object' && (metadata as { kofiBudgetStop?: unknown }).kofiBudgetStop === true,
  )
}

/** Read the `kofiLoopStop` flag from an assistant message's metadata. */
export function isLoopStop(metadata: unknown): boolean {
  return Boolean(
    metadata && typeof metadata === 'object' && (metadata as { kofiLoopStop?: unknown }).kofiLoopStop === true,
  )
}
