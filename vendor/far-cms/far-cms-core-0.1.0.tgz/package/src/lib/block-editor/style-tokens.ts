/**
 * Plain style choices for the bottom strip / Style & settings panel:
 * colour from the brand palette, size S/M/L/XL, alignment. Each choice
 * swaps exactly one Tailwind class group on the block, so the person never
 * sees class names and nothing else on the block changes.
 * Pure; asserted by style-tokens.assert.ts.
 */

export interface BrandColor {
  id: string
  name: string
  value: string
}

/** Dzidzor's palette (from the live site's own classes). */
export const BRAND_COLORS: ReadonlyArray<BrandColor> = [
  { id: 'navy', name: 'Navy', value: '#022b39' },
  { id: 'amber', name: 'Amber', value: '#b45309' },
  { id: 'sky', name: 'Sky', value: '#088cbc' },
  { id: 'mist', name: 'Mist', value: '#f5f8ff' },
  { id: 'white', name: 'White', value: '#ffffff' },
  { id: 'ink', name: 'Ink', value: '#1f2937' },
]

export type Size = 'S' | 'M' | 'L' | 'XL'
export type Align = 'left' | 'center' | 'right'
export type StyleKind = 'text' | 'heading' | 'button' | 'section' | 'image' | 'other'

const TEXT_TAGS = new Set(['p', 'span', 'li', 'blockquote', 'figcaption', 'label'])

export function styleKind(tag: string | undefined): StyleKind {
  if (!tag) return 'other'
  if (/^h[1-6]$/.test(tag)) return 'heading'
  if (TEXT_TAGS.has(tag)) return 'text'
  if (tag === 'a' || tag === 'button') return 'button'
  if (tag === 'img' || tag === 'video' || tag === 'iframe') return 'image'
  if (['section', 'div', 'header', 'footer', 'article', 'figure'].includes(tag)) return 'section'
  return 'other'
}

/** Plain name of what was clicked, for the strip's label. */
export const KIND_NAMES: Record<StyleKind, string> = {
  heading: 'Heading',
  text: 'Text',
  button: 'Button',
  section: 'Section',
  image: 'Image',
  other: 'Element',
}

const SIZES: Record<'heading' | 'text' | 'button' | 'section' | 'image', Record<Size, string>> = {
  heading: { S: 'text-2xl', M: 'text-3xl', L: 'text-4xl', XL: 'text-6xl' },
  text: { S: 'text-sm', M: 'text-base', L: 'text-lg', XL: 'text-2xl' },
  button: { S: 'px-4 py-2 text-sm', M: 'px-6 py-3 text-base', L: 'px-8 py-3 text-lg', XL: 'px-10 py-4 text-xl' },
  section: { S: 'py-8', M: 'py-12', L: 'py-20', XL: 'py-32' },
  image: { S: 'max-w-xs', M: 'max-w-md', L: 'max-w-2xl', XL: 'max-w-full' },
}

const TEXT_SIZE = /^(?:[a-z]+:)?text-(?:xs|sm|base|lg|[2-9]?xl)$/
const PAD_Y = /^(?:[a-z]+:)?(?:py|pt|pb)-\S+$/
const PAD_X = /^(?:[a-z]+:)?px-\S+$/
const MAX_W = /^(?:[a-z]+:)?max-w-\S+$/
const ALIGN = /^(?:[a-z]+:)?text-(?:left|center|right|justify)$/
const TEXT_COLOR = /^text-(?:\[#[0-9a-fA-F]{3,8}\]|white|black|(?:gray|slate|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-\d{2,3}|\[navy\])$/
const BG_COLOR = /^bg-(?:\[#[0-9a-fA-F]{3,8}\]|white|black|(?:gray|slate|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-\d{2,3})$/

function swap(className: string, drop: RegExp[], add: string): string {
  const kept = className.split(/\s+/).filter((c) => c && !drop.some((r) => r.test(c)))
  return [...kept, ...add.split(' ').filter(Boolean)].join(' ')
}

/** Text colour for words, background colour for sections and buttons. */
export function applyColor(className: string, kind: StyleKind, color: BrandColor): string {
  if (kind === 'section' || kind === 'button') return swap(className, [BG_COLOR], `bg-[${color.value}]`)
  return swap(className, [TEXT_COLOR], `text-[${color.value}]`)
}

export function applySize(className: string, kind: StyleKind, size: Size): string {
  if (kind === 'other') return className
  const add = SIZES[kind][size]
  if (kind === 'section') return swap(className, [PAD_Y], add)
  if (kind === 'button') return swap(className, [PAD_X, PAD_Y, TEXT_SIZE], add)
  if (kind === 'image') return swap(className, [MAX_W], add)
  return swap(className, [TEXT_SIZE], add)
}

export function applyAlign(className: string, align: Align): string {
  return swap(className, [ALIGN], `text-${align}`)
}

/** What is currently chosen, so the controls can show it. */
export function readStyle(className: string, kind: StyleKind): { color: string | null; size: Size | null; align: Align | null } {
  const cls = className.split(/\s+/)
  const colorClass = cls.find((c) => (kind === 'section' || kind === 'button' ? BG_COLOR : TEXT_COLOR).test(c))
  const hex = colorClass?.match(/#[0-9a-fA-F]{3,8}/)?.[0]?.toLowerCase() ?? null
  const color = hex ? BRAND_COLORS.find((c) => c.value === hex)?.id ?? null : null
  let size: Size | null = null
  if (kind !== 'other')
    for (const s of ['S', 'M', 'L', 'XL'] as Size[]) if (SIZES[kind][s].split(' ').every((c) => cls.includes(c))) size = s
  const alignClass = cls.find((c) => /^text-(left|center|right)$/.test(c))
  return { color, size, align: alignClass ? (alignClass.slice(5) as Align) : null }
}
