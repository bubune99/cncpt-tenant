/**
 * Assertions for admin sidebar visibility.
 * Run: npx -y tsx@4.23.15 src/lib/admin-nav-access.assert.ts
 */
import assert from 'node:assert/strict'
import {
  filterNavGroups,
  canSeeNavItem,
  NAV_PERMISSIONS,
  UNFINISHED_ADMIN_HREFS,
  crumbNavSource,
  withCoreNavItems,
  applyNavOverrides,
  type NavAccessOptions,
} from './admin-nav-access'
import { NAV_MANIFEST } from './admin-nav-manifest'
import { matchMenuItem } from './ade/ui/menu-match'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

const grants = (perms: string[]) => (p: string) =>
  perms.some((g) => g === p || (g.endsWith('.*') && p.startsWith(g.slice(0, -1))))

const editor: NavAccessOptions = {
  commerceEnabled: false,
  isSuperAdmin: false,
  can: grants(['pages.*', 'blog.*', 'media.*', 'categories.view', 'categories.edit']),
}
const superAdmin: NavAccessOptions = { commerceEnabled: false, isSuperAdmin: true, can: () => true }

const hrefs = (opts: NavAccessOptions) =>
  filterNavGroups(NAV_MANIFEST, opts).flatMap((g) => g.items.map((i) => i.href))

check('content editor sees only dashboard + content screens they can use', () => {
  assert.deepEqual(hrefs(editor), ['/admin', '/admin/todo', '/admin/pages', '/admin/records', '/admin/blog', '/admin/media'])
})
check('super admin with commerce off sees no commerce screens', () => {
  const seen = hrefs(superAdmin)
  for (const h of ['/admin/products', '/admin/orders', '/admin/order-workflows', '/admin/shipping', '/admin/customers']) {
    assert.equal(seen.includes(h), false, h)
  }
  assert.equal(seen.includes('/admin/settings'), true)
  assert.equal(seen.includes('/admin/events'), true)
})
check('commerce on brings the E-Commerce group back for a super admin', () => {
  const groups = filterNavGroups(NAV_MANIFEST, { ...superAdmin, commerceEnabled: true }).map((g) => g.name)
  assert.equal(groups.includes('E-Commerce'), true)
})
check('empty groups are dropped', () => {
  const groups = filterNavGroups(NAV_MANIFEST, editor).map((g) => g.name)
  assert.deepEqual(groups, ['Main', 'Content'])
})
check('unknown hrefs are super-admin only; hiddenHrefs hide for everyone', () => {
  assert.equal(canSeeNavItem('/admin/something-new', editor), false)
  assert.equal(canSeeNavItem('/admin/something-new', superAdmin), true)
  assert.equal(canSeeNavItem('/admin/plugins', { ...superAdmin, hiddenHrefs: ['/admin/plugins'] }), false)
})
check('every manifest item has an explicit permission rule', () => {
  // Events is deliberately super-admin only (its API is withSuperAdmin).
  const missing = NAV_MANIFEST.flatMap((g) => g.items.map((i) => i.href)).filter(
    (h) => h !== '/admin/events' && !(h in NAV_PERMISSIONS)
  )
  assert.deepEqual(missing, [])
})

check('unfinished screens are hidden from a super admin when passed', () => {
  const seen = hrefs({ ...superAdmin, hiddenHrefs: UNFINISHED_ADMIN_HREFS })
  for (const h of UNFINISHED_ADMIN_HREFS) assert.equal(seen.includes(h), false, h)
  assert.equal(seen.includes('/admin/pages'), true)
})

check('core ADE items are merged into DB-driven module nav once, after the first item', () => {
  const fromModules = [
    { name: 'Main', items: [{ href: '/admin', name: 'Dashboard' }, { href: '/admin/analytics', name: 'Analytics' }] },
    { name: 'Content', items: [{ href: '/admin/pages', name: 'Pages' }] },
  ]
  const manifest = NAV_MANIFEST.map((g) => ({ name: g.name, items: g.items.map((i) => ({ href: i.href, name: i.name })) }))
  const merged = withCoreNavItems(fromModules, manifest)
  assert.deepEqual(merged[0].items.map((i) => i.href), ['/admin', '/admin/todo', '/admin/analytics'])
  assert.deepEqual(merged[1].items.map((i) => i.href), ['/admin/pages', '/admin/records'])
  assert.deepEqual(withCoreNavItems(merged, manifest), merged, 'idempotent')
  assert.equal(fromModules[0].items.length, 2, 'input not mutated')
  assert.deepEqual(withCoreNavItems([], manifest)[0].items.map((i) => i.href), ['/admin/todo'])
})

check('a relabel that collides with another item falls back to its own name (no duplicate labels)', () => {
  const groups = [{ name: 'Content', items: [
    { href: '/admin/pages', name: 'Pages' },
    { href: '/admin/records', name: 'Initiatives' },
    { href: '/admin/blog', name: 'Blog' },
    { href: '/admin/media', name: 'Media' },
  ] }]
  const out = applyNavOverrides(groups, { '/admin/blog': { label: 'Initiatives', icon: 'Target' }, '/admin/media': { label: 'Photos' }, '/admin/pages': { hidden: true } })
  assert.deepEqual(out[0].items.map((i) => i.name), ['Initiatives', 'Blog', 'Photos'])
  assert.equal((out[0].items[1] as { icon?: string }).icon, 'Target', 'icon override still applies')
})

check('the bar can name Tours / Workflows / Plugins for the owner even though the menu hides them', () => {
  // What AdminShell does: the menu drops UNFINISHED_ADMIN_HREFS (that was the
  // "Admin" crumb on staging — nothing in the menu matched those paths)…
  const menu = filterNavGroups(NAV_MANIFEST, { ...superAdmin, hiddenHrefs: UNFINISHED_ADMIN_HREFS })
  for (const p of ['/admin/tours', '/admin/workflows', '/admin/plugins']) assert.equal(matchMenuItem(menu, p), null, p)
  // …while the breadcrumb's groups keep every screen this person may open.
  const crumbs = filterNavGroups(NAV_MANIFEST, superAdmin)
  assert.equal(matchMenuItem(crumbs, '/admin/tours')?.name, 'Tours')
  assert.equal(matchMenuItem(crumbs, '/admin/workflows/abc')?.name, 'Workflows')
  assert.equal(matchMenuItem(crumbs, '/admin/plugins')?.name, 'Plugins')
  assert.equal(matchMenuItem(crumbs, '/admin/order-workflows'), null, 'no prefix confusion with Order Workflows (commerce off)')
  assert.equal(matchMenuItem(crumbs, '/admin')?.name, 'Dashboard')
  assert.equal(matchMenuItem(crumbs, '/admin/nope')?.name ?? null, null, '/admin matches only itself')
  // Access still applies: an editor's crumb groups don't name screens they can't open.
  assert.equal(matchMenuItem(filterNavGroups(NAV_MANIFEST, editor), '/admin/tours'), null)
})

check('module rows as on staging (Events disabled; Tours/Workflows/Plugins never listed): the crumb still names them', () => {
  // cms_modules on staging, 2026-10-10 (read-only): enabled modules' hrefs only.
  const fromModules = [
    { name: 'Main', items: [{ href: '/admin', name: 'Dashboard' }, { href: '/admin/analytics', name: 'Analytics' }] },
    { name: 'Content', items: [{ href: '/admin/pages', name: 'Pages' }, { href: '/admin/import', name: 'Import' }, { href: '/admin/blog', name: 'Blog' }, { href: '/admin/forms', name: 'Forms' }, { href: '/admin/media', name: 'Media' }] },
    { name: 'System', items: [{ href: '/admin/users', name: 'Users' }, { href: '/admin/roles', name: 'Roles & Permissions' }, { href: '/admin/audit-log', name: 'Audit Log' }, { href: '/admin/settings', name: 'Settings' }] },
  ]
  const manifest = NAV_MANIFEST.map((g) => ({ name: g.name, items: g.items.map((i) => ({ href: i.href, name: i.name })) }))
  // The menu (module-driven + core items) has no Events / Tours for the owner — the visibility gap.
  const menu = filterNavGroups(withCoreNavItems(fromModules, manifest), { ...superAdmin, hiddenHrefs: UNFINISHED_ADMIN_HREFS })
  assert.equal(matchMenuItem(menu, '/admin/events'), null)
  // The crumb source is the code manifest + module extras.
  const crumbs = filterNavGroups(crumbNavSource(fromModules, manifest), superAdmin)
  assert.equal(matchMenuItem(crumbs, '/admin/events')?.name, 'Events')
  assert.equal(matchMenuItem(crumbs, '/admin/events/evt_123')?.name, 'Events')
  assert.equal(matchMenuItem(crumbs, '/admin/tours')?.name, 'Tours')
  assert.equal(matchMenuItem(crumbs, '/admin/workflows/w1')?.name, 'Workflows')
  assert.equal(matchMenuItem(crumbs, '/admin/import')?.name, 'Import', 'module-only items are kept')
  // Pure: inputs untouched, no duplicates.
  assert.equal(fromModules[1].items.length, 5)
  const all = crumbNavSource(fromModules, manifest).flatMap((g) => g.items.map((i) => i.href))
  assert.equal(all.length, new Set(all).size)
  assert.deepEqual(crumbNavSource(null, manifest).flatMap((g) => g.items.map((i) => i.href)), manifest.flatMap((g) => g.items.map((i) => i.href)))
})

console.log(`\n${n} assertions passed`)
