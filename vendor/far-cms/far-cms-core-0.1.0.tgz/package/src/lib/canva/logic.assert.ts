/**
 * Run: npx -y tsx@4.23.15 src/lib/canva/logic.assert.ts
 */
import assert from 'node:assert/strict'
import { canvaConfigStatus, canvaRedirectUri, canvaReturnUrl, exportFormat, importFilename, isDesignId, isExportFormat, isPermanentAuthFailure, parseCanvaUser } from './logic'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('setup status names what is missing, never values', () => {
  assert.deepEqual(canvaConfigStatus({}), { configured: false, missing: ['CANVA_CLIENT_ID', 'CANVA_CLIENT_SECRET'] })
  assert.deepEqual(canvaConfigStatus({ CANVA_CLIENT_ID: 'id', CANVA_CLIENT_SECRET: '  ' }), { configured: false, missing: ['CANVA_CLIENT_SECRET'] })
  assert.deepEqual(canvaConfigStatus({ CANVA_CLIENT_ID: 'id', CANVA_CLIENT_SECRET: 's' }), { configured: true, missing: [] })
})

check('redirect URL comes back to the host that started the flow', () => {
  const env = { NEXT_PUBLIC_APP_URL: 'https://www.projectdzidzor.org' }
  assert.equal(canvaRedirectUri(env, 'https://dzidzor-staging.vercel.app'), 'https://dzidzor-staging.vercel.app/api/canva/auth/callback')
  assert.equal(canvaRedirectUri(env, 'https://www.projectdzidzor.org/'), 'https://www.projectdzidzor.org/api/canva/auth/callback')
  assert.equal(canvaRedirectUri({ CANVA_REDIRECT_URI: 'https://x.test/cb' }, 'https://y.test'), 'https://x.test/cb')
  assert.equal(canvaReturnUrl('https://dzidzor-staging.vercel.app', { connected: true }), 'https://dzidzor-staging.vercel.app/admin/media?canva_connected=true')
  assert.ok(canvaReturnUrl('https://a.test', { error: 'No & no' }).endsWith('?canva_error=No%20%26%20no'))
})

check('users/me is { team_user: { user_id, team_id } }', () => {
  assert.deepEqual(parseCanvaUser({ team_user: { user_id: 'U1', team_id: 'T1' } }), { userId: 'U1', teamId: 'T1' })
  assert.deepEqual(parseCanvaUser({ user_id: 'flat' }), { userId: null, teamId: null })
  assert.deepEqual(parseCanvaUser(null), { userId: null, teamId: null })
})

check('export format matches the API: jpg quality is an integer 1–100', () => {
  assert.deepEqual(exportFormat({ format: 'jpg', quality: 80 }), { type: 'jpg', quality: 80 })
  assert.deepEqual(exportFormat({ format: 'jpg' }), { type: 'jpg', quality: 90 })
  assert.equal(exportFormat({ format: 'jpg', quality: 500 }).quality, 100)
  assert.ok(!('export_quality' in exportFormat({ format: 'jpg', quality: 80 })))
  assert.deepEqual(exportFormat({ format: 'png', width: 10, height: 99999 }), { type: 'png', width: 40, height: 25000, lossless: true })
  assert.deepEqual(exportFormat({ format: 'pdf', width: 800 }), { type: 'pdf' })
  assert.ok(isExportFormat('png') && !isExportFormat('svg'))
})

check('file names are never empty', () => {
  assert.equal(importFilename('Clean Water — Flyer!', 'png'), 'clean-water-flyer.png')
  assert.equal(importFilename('🎉🎉', 'jpg'), 'canva-design.jpeg')
  assert.equal(importFilename('Café poster', 'pdf'), 'cafe-poster.pdf')
})

check('only Canva refusing the refresh disconnects; blips do not', () => {
  assert.ok(isPermanentAuthFailure(400) && isPermanentAuthFailure(401))
  assert.ok(!isPermanentAuthFailure(500) && !isPermanentAuthFailure(429) && !isPermanentAuthFailure(undefined))
})

check('design ids are URL-safe', () => {
  assert.ok(isDesignId('DAFVztcvd9z'))
  assert.ok(!isDesignId('../users/me') && !isDesignId('') && !isDesignId(42))
})

console.log(`\n${n} checks passed`)
