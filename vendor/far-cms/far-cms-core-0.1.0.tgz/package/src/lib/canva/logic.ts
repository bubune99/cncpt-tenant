/**
 * Canva Connect — the rules, without I/O. Pure; asserted by logic.assert.ts.
 * Shapes checked against canva.dev Connect API reference (2026-10-10).
 */

import type { CanvaExportFormat } from './types'

export const CANVA_CALLBACK_PATH = '/api/canva/auth/callback'

type Env = Record<string, string | undefined>

/** Is the integration set up on this deployment, and if not, what's missing (names only). */
export function canvaConfigStatus(env: Env): { configured: boolean; missing: string[] } {
  const missing = ['CANVA_CLIENT_ID', 'CANVA_CLIENT_SECRET'].filter((k) => !env[k]?.trim())
  return { configured: missing.length === 0, missing }
}

/**
 * The redirect URL sent to Canva. An explicit CANVA_REDIRECT_URI wins;
 * otherwise the URL of the deployment handling the request — so staging
 * comes back to staging even when NEXT_PUBLIC_APP_URL names production
 * (the PKCE cookies only exist on the host that started the flow).
 */
export function canvaRedirectUri(env: Env, requestOrigin: string): string {
  const explicit = env.CANVA_REDIRECT_URI?.trim()
  if (explicit) return explicit
  return `${requestOrigin.replace(/\/+$/, '')}${CANVA_CALLBACK_PATH}`
}

/** Where the callback sends the person back to (same host). */
export function canvaReturnUrl(requestOrigin: string, outcome: { connected: true } | { error: string }): string {
  const base = `${requestOrigin.replace(/\/+$/, '')}/admin/media`
  return 'error' in outcome ? `${base}?canva_error=${encodeURIComponent(outcome.error.slice(0, 200))}` : `${base}?canva_connected=true`
}

/** GET /v1/users/me → { team_user: { user_id, team_id } }. */
export function parseCanvaUser(json: unknown): { userId: string | null; teamId: string | null } {
  const tu = (json as { team_user?: { user_id?: unknown; team_id?: unknown } } | null)?.team_user
  return {
    userId: typeof tu?.user_id === 'string' ? tu.user_id : null,
    teamId: typeof tu?.team_id === 'string' ? tu.team_id : null,
  }
}

const clampInt = (v: unknown, min: number, max: number): number | undefined => {
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() ? Number(v) : NaN
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : undefined
}

/**
 * The `format` object for POST /v1/exports. JPG needs `quality` (1–100) —
 * `export_quality` is 'regular' | 'pro', not a number. Width/height 40–25000.
 * PNG stays lossless (lossy needs a premium Canva plan).
 */
export function exportFormat(req: { format: CanvaExportFormat; width?: unknown; height?: unknown; quality?: unknown }): Record<string, unknown> {
  const f: Record<string, unknown> = { type: req.format }
  if (req.format === 'png' || req.format === 'jpg' || req.format === 'gif' || req.format === 'mp4') {
    const w = clampInt(req.width, 40, 25000)
    const h = clampInt(req.height, 40, 25000)
    if (w) f.width = w
    if (h) f.height = h
  }
  if (req.format === 'jpg') f.quality = clampInt(req.quality, 1, 100) ?? 90
  if (req.format === 'png') f.lossless = true
  return f
}

export const EXPORT_FORMATS: ReadonlyArray<CanvaExportFormat> = ['png', 'jpg', 'pdf', 'gif', 'pptx', 'mp4']

export function isExportFormat(v: unknown): v is CanvaExportFormat {
  return typeof v === 'string' && (EXPORT_FORMATS as readonly string[]).includes(v)
}

/** A file name from the design title; never empty. */
export function importFilename(title: string, format: CanvaExportFormat): string {
  const base = title
    .normalize('NFKD')
    .replace(/[^a-zA-Z0-9\s_-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .toLowerCase()
    .slice(0, 80)
  return `${base || 'canva-design'}.${format === 'jpg' ? 'jpeg' : format}`
}

/**
 * A refresh that Canva refused (bad/used refresh token, revoked access) means
 * the connection is gone; anything else (network, 5xx) is worth retrying and
 * must NOT delete the stored connection.
 */
export function isPermanentAuthFailure(status: number | undefined): boolean {
  return status === 400 || status === 401 || status === 403
}

/** Canva design ids are opaque but URL-safe; refuse anything that isn't. */
export function isDesignId(v: unknown): v is string {
  return typeof v === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(v)
}
