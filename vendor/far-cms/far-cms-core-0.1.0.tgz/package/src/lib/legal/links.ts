/**
 * The site's legal pages, where links to them go, and which ones a footer
 * already links to. Pure; asserted by links.assert.ts.
 *
 * The code routes live under /legal/* (app/(storefront)/legal). When the
 * owner publishes a reviewed page in the CMS under one of `cmsSlugs`, the
 * /legal/* route sends people there instead (lib/legal/cms-page).
 */

export type LegalKind = 'terms' | 'privacy' | 'cookies'

export interface LegalLink {
  kind: LegalKind
  label: string
  href: string
  /** CMS slugs that count as this page, most specific first. Never "legal/…": the code route would shadow it. */
  cmsSlugs: string[]
  /** How to spot an existing link to it in a footer. */
  match: RegExp
}

export const LEGAL_LINKS: ReadonlyArray<LegalLink> = [
  { kind: 'privacy', label: 'Privacy Policy', href: '/legal/privacy', cmsSlugs: ['privacy-policy', 'privacy'], match: /privacy/i },
  { kind: 'terms', label: 'Terms of Service', href: '/legal/terms', cmsSlugs: ['terms-of-service', 'terms-and-conditions', 'terms'], match: /terms|conditions/i },
  { kind: 'cookies', label: 'Cookie Policy', href: '/legal/cookies', cmsSlugs: ['cookie-policy', 'cookies'], match: /cookie-?policy|\/cookies\b/i },
]

export function legalLink(kind: LegalKind): LegalLink {
  const link = LEGAL_LINKS.find((l) => l.kind === kind)
  if (!link) throw new Error(`unknown legal page ${kind}`)
  return link
}

/** Every href in a footer's stored data (Block[] document or legacy props), however deep. */
export function hrefsIn(data: unknown): string[] {
  let json: string
  try {
    json = JSON.stringify(data ?? null)
  } catch {
    return []
  }
  const out: string[] = []
  const re = /"href"\s*:\s*"((?:[^"\\]|\\.)*)"/g
  for (let m = re.exec(json); m; m = re.exec(json)) out.push(m[1])
  return out
}

/** The legal pages a footer doesn't link to yet (in LEGAL_LINKS order). */
export function missingLegalLinks(footerData: unknown): LegalLink[] {
  const hrefs = hrefsIn(footerData)
  return LEGAL_LINKS.filter((l) => !hrefs.some((h) => l.match.test(h)))
}

/** CMS slug candidates for a page, with and without the leading slash (both are stored). */
export function cmsSlugCandidates(kind: LegalKind): string[] {
  return legalLink(kind).cmsSlugs.flatMap((s) => [s, `/${s}`])
}

/** The address of a CMS page from its stored slug. */
export function cmsHref(slug: string): string {
  return `/${slug.replace(/^\/+/, '')}`
}

/** Where a form's acceptance line says the visitor agrees to (or is told about). */
export type AcceptanceAction = 'sign-up' | 'donate' | 'pay' | 'subscribe' | 'form'

/** A line as text and links, in order: `{ link: 'terms' }` renders that page's link. */
export type AcceptancePart = string | { link: LegalKind }

/**
 * The short line under a form. Agreement wording only where there's a
 * transaction or an account; plain forms and the newsletter just point to
 * the privacy policy (a notice at collection, not a contract).
 */
export function acceptanceText(action: AcceptanceAction): AcceptancePart[] {
  const agree = (lead: string): AcceptancePart[] => [`${lead}, you agree to our `, { link: 'terms' }, ' and acknowledge our ', { link: 'privacy' }, '.']
  switch (action) {
    case 'sign-up':
      return agree('By creating an account')
    case 'donate':
      return agree('By donating')
    case 'pay':
      return agree('By placing this order')
    case 'subscribe':
      return ['We’ll use your email only to send you updates, and you can unsubscribe at any time. See our ', { link: 'privacy' }, '.']
    case 'form':
      return ['We use what you send us as described in our ', { link: 'privacy' }, '.']
  }
}

/** The line as plain text (labels for the links). */
export function acceptancePlain(action: AcceptanceAction): string {
  return acceptanceText(action).map((p) => (typeof p === 'string' ? p : legalLink(p.link).label)).join('')
}
