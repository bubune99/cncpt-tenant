/**
 * Run: npx -y tsx@4.23.15 src/lib/legal/links.assert.ts
 */
import assert from 'node:assert/strict'
import { LEGAL_LINKS, acceptancePlain, acceptanceText, cmsHref, cmsSlugCandidates, hrefsIn, missingLegalLinks } from './links'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('the three legal pages, at the site’s /legal/* addresses', () => {
  assert.deepEqual(LEGAL_LINKS.map((l) => l.href), ['/legal/privacy', '/legal/terms', '/legal/cookies'])
})

check('hrefs are found anywhere in a Block[] footer or legacy props', () => {
  const blocks = [{ type: 'div', children: [{ type: 'a', attrs: { href: '/privacy-policy' } }, { type: 'a', attrs: { href: 'https://x.org/terms' } }] }]
  assert.deepEqual(hrefsIn(blocks), ['/privacy-policy', 'https://x.org/terms'])
  assert.deepEqual(hrefsIn({ bottomLinks: [{ label: 'Privacy', href: '/legal/privacy' }] }), ['/legal/privacy'])
  assert.deepEqual(hrefsIn(null), [])
})

check('a footer with no legal links gets all three; one with privacy + terms gets only the cookie policy', () => {
  assert.deepEqual(missingLegalLinks([{ attrs: { href: '/about' } }]).map((l) => l.kind), ['privacy', 'terms', 'cookies'])
  assert.deepEqual(missingLegalLinks({ bottomLinks: [{ href: '/legal/privacy' }, { href: '/legal/terms' }] }).map((l) => l.kind), ['cookies'])
  assert.deepEqual(missingLegalLinks({ x: [{ href: '/terms-and-conditions' }, { href: '/privacy' }, { href: '/cookie-policy' }] }), [])
})

check('"Cookie settings" (#cookie-settings) is not a cookie policy link', () => {
  assert.deepEqual(missingLegalLinks([{ attrs: { href: '#cookie-settings' } }]).map((l) => l.kind), ['privacy', 'terms', 'cookies'])
})

check('CMS slugs: with and without the slash; never legal/* (the code route would shadow it, and redirect to itself)', () => {
  assert.deepEqual(cmsSlugCandidates('privacy'), ['privacy-policy', '/privacy-policy', 'privacy', '/privacy'])
  for (const l of LEGAL_LINKS) assert.ok(l.cmsSlugs.every((s) => !s.startsWith('legal')))
  assert.equal(cmsHref('/privacy-policy'), '/privacy-policy')
  assert.equal(cmsHref('terms'), '/terms')
})

check('acceptance lines: agreement only for accounts and money; notices elsewhere', () => {
  assert.equal(acceptancePlain('sign-up'), 'By creating an account, you agree to our Terms of Service and acknowledge our Privacy Policy.')
  assert.equal(acceptancePlain('donate'), 'By donating, you agree to our Terms of Service and acknowledge our Privacy Policy.')
  assert.ok(!acceptancePlain('subscribe').includes('agree'))
  assert.ok(!acceptancePlain('form').includes('agree'))
  assert.ok(acceptanceText('subscribe').some((p) => typeof p !== 'string' && p.link === 'privacy'))
})

console.log(`\n${n} checks passed`)
