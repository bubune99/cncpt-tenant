/**
 * Run: npx -y tsx@4.23.15 src/lib/pages/history-bridge.assert.ts
 */
import assert from 'node:assert/strict'
import { pageVersions, type PageSnapshot } from './history-bridge'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const snap = (id: string, minute: number, title: string, content: unknown, extra: Partial<PageSnapshot> = {}): PageSnapshot => ({
  id, title, slug: 'about', status: 'PUBLISHED', content, reason: 'save', createdById: 'u1', createdAt: new Date(Date.UTC(2026, 9, 11, 10, minute)), ...extra,
})

check('each snapshot is one change: before = it, after = the next snapshot or the page now', () => {
  const s1 = snap('a', 1, 'About', { blocks: [1] })
  const s2 = snap('b', 2, 'About us', { blocks: [1] })
  const now = { title: 'About us', slug: 'about', status: 'PUBLISHED', content: { blocks: [1, 2] } }
  const v = pageVersions([s2, s1], now) // any order in
  assert.deepEqual(v.map((x) => [x.version, x.id, x.changed]), [[2, 'b', ['content']], [1, 'a', ['title']]])
  assert.deepEqual(v[1].before, { title: 'About' })
  assert.deepEqual(v[1].after, { title: 'About us' })
})

check('restoring a version writes the state after it; the newest is how the page is now', () => {
  const s1 = snap('a', 1, 'One', { blocks: ['x'] })
  const s2 = snap('b', 2, 'Two', { blocks: ['y'] })
  const v = pageVersions([s1, s2], { title: 'Three', slug: 'about', status: 'PUBLISHED', content: { blocks: ['z'] } })
  assert.equal(v[0].restoreTo, null)
  assert.deepEqual(v[1].restoreTo, { title: 'Two', content: { blocks: ['y'] } })
})

check('a publish (status only) shows as a status change; no snapshots = no versions', () => {
  const s1 = snap('a', 1, 'About', { b: 1 }, { status: 'DRAFT', reason: 'publish' })
  const v = pageVersions([s1], { title: 'About', slug: 'about', status: 'PUBLISHED', content: { b: 1 } })
  assert.deepEqual(v[0].changed, ['status'])
  assert.equal(v[0].reason, 'publish')
  assert.deepEqual(pageVersions([], { title: 'x', slug: 'x', status: 'DRAFT', content: null }), [])
})

console.log(`\n${n} checks passed`)
