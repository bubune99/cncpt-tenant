/**
 * Page revision rules — pure, asserted by revision-rules.assert.ts.
 */

export const MAX_REVISIONS_PER_PAGE = 30

export type RevisionReason = 'save' | 'publish' | 'unpublish' | 'restore' | 'ai-edit'

interface PageState {
  status: string
  content: unknown
}

/**
 * Should saving `next` over `prev` keep a snapshot of `prev`?
 * Only when something a visitor could see changes: the content, or the
 * published status. Title/SEO-only edits don't create revisions.
 */
export function shouldSnapshot(prev: PageState, next: Partial<PageState>): boolean {
  const contentChanged =
    next.content !== undefined && JSON.stringify(next.content) !== JSON.stringify(prev.content ?? null)
  const statusChanged = next.status !== undefined && next.status !== prev.status
  return contentChanged || statusChanged
}

/** Name the change for the revision list. */
export function reasonFor(prevStatus: string, nextStatus: string | undefined): RevisionReason {
  if (nextStatus === 'PUBLISHED') return 'publish'
  if (prevStatus === 'PUBLISHED' && nextStatus && nextStatus !== 'PUBLISHED') return 'unpublish'
  return 'save'
}

/** Given revision ids newest-first, which to delete to keep `keep`. */
export function idsToPrune(idsNewestFirst: string[], keep = MAX_REVISIONS_PER_PAGE): string[] {
  return idsNewestFirst.slice(keep)
}
