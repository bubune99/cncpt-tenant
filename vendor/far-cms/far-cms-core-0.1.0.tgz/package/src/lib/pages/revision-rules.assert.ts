/**
 * Assertions for page revision rules.
 * Run: npx -y tsx@4.23.15 src/lib/pages/revision-rules.assert.ts
 */
import assert from 'node:assert/strict'
import { idsToPrune, MAX_REVISIONS_PER_PAGE, reasonFor, shouldSnapshot } from './revision-rules'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

const page = { status: 'PUBLISHED', content: { version: '2.0', blocks: [{ id: 'a' }] } }

check('content change snapshots', () => {
  assert.equal(shouldSnapshot(page, { content: { version: '2.0', blocks: [] } }), true)
})
check('identical content does not (autosave with no edits)', () => {
  assert.equal(shouldSnapshot(page, { content: { version: '2.0', blocks: [{ id: 'a' }] } }), false)
})
check('status change snapshots; title-only edit does not', () => {
  assert.equal(shouldSnapshot(page, { status: 'DRAFT' }), true)
  assert.equal(shouldSnapshot(page, {}), false)
})
check('first content on an empty page snapshots the empty state', () => {
  assert.equal(shouldSnapshot({ status: 'DRAFT', content: null }, { content: { blocks: [] } }), true)
})
check('reasons', () => {
  assert.equal(reasonFor('DRAFT', 'PUBLISHED'), 'publish')
  assert.equal(reasonFor('PUBLISHED', 'PUBLISHED'), 'publish')
  assert.equal(reasonFor('PUBLISHED', 'DRAFT'), 'unpublish')
  assert.equal(reasonFor('DRAFT', 'DRAFT'), 'save')
  assert.equal(reasonFor('DRAFT', undefined), 'save')
})
check('prune keeps the newest N', () => {
  const ids = Array.from({ length: 33 }, (_, i) => `r${i}`)
  assert.deepEqual(idsToPrune(ids), ['r30', 'r31', 'r32'])
  assert.deepEqual(idsToPrune(ids.slice(0, 5)), [])
  assert.equal(MAX_REVISIONS_PER_PAGE, 30)
})

console.log(`\n${n} assertions passed`)
