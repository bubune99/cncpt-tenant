/**
 * Pages in the shared History view, read from PageRevision (pure; asserted
 * by history-bridge.assert.ts). Pages already keep a full snapshot BEFORE
 * each change (capped per page), so their history is not stored twice: each
 * snapshot is one change — "before" is the snapshot, "after" is the next
 * snapshot (or the page now) — and restoring a version puts that "after"
 * back (title + blocks; the address and published status stay as they are,
 * like the page's own Revisions list).
 *
 * Version numbers count the snapshots still kept (the newest
 * MAX_REVISIONS_PER_PAGE), oldest = 1.
 */

import { diffState } from '../ade/history/revisions'

export interface PageState {
  title: string
  slug: string
  status: string
  content: unknown
}

export interface PageSnapshot extends PageState {
  id: string
  reason: string
  createdById: string | null
  createdAt: Date
}

export interface PageVersion {
  id: string
  version: number
  at: string
  userId: string | null
  reason: string
  changed: string[]
  before: Record<string, unknown>
  after: Record<string, unknown>
  /** What a restore of this version writes (null = it's how the page is now). */
  restoreTo: { title: string; content: unknown } | null
}

const state = (s: PageState): Record<string, unknown> => ({ title: s.title, slug: s.slug, status: s.status, content: s.content ?? null })

/** Each kept snapshot as a version, newest first. `snapshots` may come in any order. */
export function pageVersions(snapshots: readonly PageSnapshot[], current: PageState): PageVersion[] {
  const asc = [...snapshots].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime() || a.id.localeCompare(b.id))
  const out: PageVersion[] = asc.map((s, i) => {
    const next = asc[i + 1]
    const after = next ?? current
    const change = diffState(state(s), state(after))
    return {
      id: s.id,
      version: i + 1,
      at: s.createdAt.toISOString(),
      userId: s.createdById,
      reason: s.reason,
      changed: change?.changed ?? [],
      before: change?.before ?? {},
      after: change?.after ?? {},
      restoreTo: next ? { title: next.title, content: next.content } : null,
    }
  })
  return out.reverse()
}
