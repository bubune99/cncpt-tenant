/**
 * Assertions for commerce visibility rules.
 * Run: npx -y tsx@4.23.15 src/lib/commerce-paths.assert.ts
 */
import assert from 'node:assert/strict'
import {
  hideCommerceInLayout,
  isCommerceAdminPath,
  isCommerceStorefrontPath,
  parseFlag,
  resolveCommerceEnabled,
  stripCommerceLinks,
} from './commerce-paths'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

check('flag parsing accepts common spellings and JSON-quoted values', () => {
  assert.equal(parseFlag('true'), true)
  assert.equal(parseFlag('"true"'), true)
  assert.equal(parseFlag(' 1 '), true)
  assert.equal(parseFlag('false'), false)
  assert.equal(parseFlag('off'), false)
  assert.equal(parseFlag('maybe'), null)
  assert.equal(parseFlag(undefined), null)
})
check('DB value wins over env; default is OFF', () => {
  assert.equal(resolveCommerceEnabled('false', 'true'), false)
  assert.equal(resolveCommerceEnabled('true', 'false'), true)
  assert.equal(resolveCommerceEnabled(null, 'true'), true)
  assert.equal(resolveCommerceEnabled(null, undefined), false)
  assert.equal(resolveCommerceEnabled('garbage', undefined), false)
  // The app's default applies only when nothing is set (BYB: on; Dzidzor: off).
  assert.equal(resolveCommerceEnabled(null, undefined, true), true)
  assert.equal(resolveCommerceEnabled('false', undefined, true), false)
  assert.equal(resolveCommerceEnabled(null, 'false', true), false)
})
check('storefront commerce paths match by segment, not substring', () => {
  for (const p of ['/shop', '/shop/tee', '/merch', '/merch/', '/cart?x=1', '/checkout/success', '/account/orders/9', '/MERCH']) {
    assert.equal(isCommerceStorefrontPath(p), true, p)
  }
  for (const p of ['/', '/shopping-for-hope', '/merchandise-policy', '/donate', '/account', 'https://shop.example.com', '#cart', '//evil/shop']) {
    assert.equal(isCommerceStorefrontPath(p), false, p)
  }
})
check('admin commerce screens', () => {
  assert.equal(isCommerceAdminPath('/admin/products'), true)
  assert.equal(isCommerceAdminPath('/admin/orders/123'), true)
  assert.equal(isCommerceAdminPath('/admin/pages'), false)
  assert.equal(isCommerceAdminPath('/admin'), false)
})
check('header blocks lose the Merchandise link, keep the rest, input untouched', () => {
  const header = [
    { id: 'nav', tag: 'nav', attrs: {}, children: [
      { id: 'a1', tag: 'a', attrs: { href: '/about' } },
      { id: 'a2', tag: 'a', attrs: { href: '/merch' } },
      { id: 'a3', tag: 'a', attrs: { href: '/donate' } },
    ] },
  ]
  const before = JSON.stringify(header)
  const out = stripCommerceLinks(header)
  assert.deepEqual(out[0].children!.map((c) => c.attrs!.href), ['/about', '/donate'])
  assert.equal(JSON.stringify(header), before)
})
check('layout doc and legacy props are both handled', () => {
  const doc = hideCommerceInLayout({ version: '2.0', blocks: [{ tag: 'a', attrs: { href: '/shop' } }, { tag: 'a', attrs: { href: '/about' } }] }) as { blocks: unknown[] }
  assert.equal(doc.blocks.length, 1)
  const legacy = hideCommerceInLayout({ navLinks: [{ label: 'Shop', href: '/shop' }, { label: 'About', href: '/about' }], showCart: true }) as { navLinks: unknown[]; showCart: boolean }
  assert.equal(legacy.navLinks.length, 1)
  assert.equal(legacy.showCart, false)
  assert.equal(hideCommerceInLayout(null), null)
})

console.log(`\n${n} assertions passed`)
