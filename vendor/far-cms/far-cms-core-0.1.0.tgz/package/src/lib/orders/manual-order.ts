/**
 * Manual orders made in the admin: what an address needs, what Stripe Tax is asked, and the totals.
 * Owner, 2026-11-22: "Build it. We should be able to put generate tax based on the billing address".
 *
 * Prices are always the catalog's (the caller looks them up on the server); tax is Stripe Tax's answer
 * for the billing address. Pure, with Stripe passed in (checked by manual-order.assert.ts).
 */

export interface OrderLine {
  readonly productId: string
  readonly variantId?: string
  readonly title: string
  readonly quantity: number
  /** Catalog price of one, in cents. */
  readonly unitPrice: number
}

export interface PostalAddress {
  readonly name?: string
  readonly line1: string
  readonly line2?: string
  readonly city: string
  readonly state: string
  readonly postalCode: string
  /** Two-letter country code. */
  readonly country: string
}

/** The request sent to Stripe Tax (stripe.tax.calculations.create). */
export interface TaxRequest {
  currency: string
  line_items: { amount: number; quantity: number; reference: string; tax_behavior: 'exclusive' }[]
  customer_details: {
    address: { line1: string; line2?: string; city: string; state: string; postal_code: string; country: string }
    address_source: 'billing'
  }
  shipping_cost?: { amount: number }
}

export type TaxOutcome =
  | { ok: true; taxCents: number; calculationId: string | null }
  | { ok: false; reason: 'address' | 'unavailable'; message: string }

const blank = (s: string | undefined) => !s || !s.trim()

/** What the address still needs before tax can be worked out, in words for the form; null when complete. */
export function addressProblem(a: PostalAddress): string | null {
  if (blank(a.line1)) return 'Add the street address'
  if (blank(a.city)) return 'Add the town or city'
  if (blank(a.postalCode)) return 'Add the postal code'
  if (blank(a.country)) return 'Add the country'
  if (a.country.trim().toUpperCase() === 'US' && blank(a.state)) return 'Add the state'
  return null
}

export function taxRequest(lines: readonly OrderLine[], billing: PostalAddress, shippingCents: number, currency: string): TaxRequest {
  return {
    currency,
    line_items: lines.map((l) => ({
      amount: l.unitPrice * l.quantity,
      quantity: l.quantity,
      reference: l.variantId ? `${l.productId}:${l.variantId}` : l.productId,
      tax_behavior: 'exclusive' as const,
    })),
    customer_details: {
      address: {
        line1: billing.line1.trim(),
        line2: billing.line2?.trim() || undefined,
        city: billing.city.trim(),
        state: billing.state.trim(),
        postal_code: billing.postalCode.trim(),
        country: billing.country.trim().toUpperCase(),
      },
      address_source: 'billing',
    },
    ...(shippingCents > 0 ? { shipping_cost: { amount: shippingCents } } : {}),
  }
}

export function orderTotals(lines: readonly OrderLine[], taxCents: number, shippingCents: number) {
  const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.quantity, 0)
  const tax = Math.max(0, Math.round(taxCents) || 0)
  const shipping = Math.max(0, Math.round(shippingCents) || 0)
  return { subtotal, tax, shipping, total: subtotal + tax + shipping }
}

export async function workOutTax(
  lines: readonly OrderLine[],
  billing: PostalAddress,
  shippingCents: number,
  currency: string,
  calculate: (req: TaxRequest) => Promise<{ id: string; tax_amount_exclusive: number }>
): Promise<TaxOutcome> {
  if (lines.length === 0) return { ok: true, taxCents: 0, calculationId: null }
  const problem = addressProblem(billing)
  if (problem) return { ok: false, reason: 'address', message: problem }
  try {
    const r = await calculate(taxRequest(lines, billing, shippingCents, currency))
    return { ok: true, taxCents: Math.max(0, r.tax_amount_exclusive), calculationId: r.id }
  } catch (error) {
    console.error('[manual-order] Stripe Tax refused:', error instanceof Error ? error.message : error)
    return { ok: false, reason: 'unavailable', message: "Tax couldn't be worked out by Stripe Tax for this address" }
  }
}
