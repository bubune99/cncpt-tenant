/**
 * Checks for manual orders made in the admin (owner 2026-11-22: "Build it. We should be able to
 * put generate tax based on the billing address").
 * Run: node_modules/.bin/tsx src/lib/orders/manual-order.assert.ts
 */
import assert from 'node:assert/strict'
import { addressProblem, taxRequest, orderTotals, workOutTax, type OrderLine, type PostalAddress } from './manual-order'

const lines: OrderLine[] = [
  { productId: 'p1', title: 'Tee', quantity: 2, unitPrice: 2500 },
  { productId: 'p2', variantId: 'v9', title: 'Mug', quantity: 1, unitPrice: 1299 },
]
const home: PostalAddress = { line1: '1 Main St', city: 'Austin', state: 'TX', postalCode: '78701', country: 'US' }

// 1. An address needs a street, town, postal code and country before tax can be worked out; a US one needs its state.
assert.equal(addressProblem(home), null)
assert.equal(addressProblem({ ...home, postalCode: ' ' }), 'Add the postal code')
assert.equal(addressProblem({ ...home, line1: '' }), 'Add the street address')
assert.equal(addressProblem({ ...home, state: '' }), 'Add the state')
assert.equal(addressProblem({ ...home, state: '', country: 'GB', postalCode: 'SW1A 1AA', city: 'London' }), null)

// 2. What Stripe Tax is asked: each line's catalog amount (price x quantity), the billing address, shipping when charged.
{
  const r = taxRequest(lines, home, 800, 'usd')
  assert.equal(r.currency, 'usd')
  assert.deepEqual(r.line_items, [
    { amount: 5000, quantity: 2, reference: 'p1', tax_behavior: 'exclusive' },
    { amount: 1299, quantity: 1, reference: 'p2:v9', tax_behavior: 'exclusive' },
  ])
  assert.deepEqual(r.customer_details, { address: { line1: '1 Main St', line2: undefined, city: 'Austin', state: 'TX', postal_code: '78701', country: 'US' }, address_source: 'billing' })
  assert.deepEqual(r.shipping_cost, { amount: 800 })
  assert.equal(taxRequest(lines, home, 0, 'usd').shipping_cost, undefined)
}

// 3. Totals: subtotal from the lines, then tax and shipping added; never negative.
assert.deepEqual(orderTotals(lines, 523, 800), { subtotal: 6299, tax: 523, shipping: 800, total: 7622 })
assert.deepEqual(orderTotals(lines, -5, -1), { subtotal: 6299, tax: 0, shipping: 0, total: 6299 })

async function run() {
  // 4. Tax comes from Stripe's answer; a bad address is not sent; Stripe refusing says tax is unavailable.
  const ok = await workOutTax(lines, home, 800, 'usd', async (req) => {
    assert.equal(req.customer_details.address.postal_code, '78701')
    return { id: 'taxcalc_1', tax_amount_exclusive: 523 }
  })
  assert.deepEqual(ok, { ok: true, taxCents: 523, calculationId: 'taxcalc_1' })

  let called = false
  const bad = await workOutTax(lines, { ...home, postalCode: '' }, 0, 'usd', async () => { called = true; return { id: 'x', tax_amount_exclusive: 1 } })
  assert.deepEqual(bad, { ok: false, reason: 'address', message: 'Add the postal code' })
  assert.equal(called, false)

  const off = await workOutTax(lines, home, 0, 'usd', async () => { throw new Error('Stripe Tax has not been activated') })
  assert.equal(off.ok, false)
  assert.equal(off.ok === false && off.reason, 'unavailable')

  // 5. No lines, no tax to work out (and Stripe is not asked).
  const none = await workOutTax([], home, 0, 'usd', async () => { throw new Error('should not be called') })
  assert.deepEqual(none, { ok: true, taxCents: 0, calculationId: null })
}

run().then(() => console.log('manual-order: 5 checks passed')).catch((e) => { console.error(e); process.exit(1) })
