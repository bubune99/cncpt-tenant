/**
 * What the order page shows, worked out from the order the API sends (Prisma's shape: money in cents,
 * upper-case statuses, address rows, shipments). Pure; checked by order-view.assert.ts.
 */

export const ORDER_STATUSES = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'] as const
export type OrderStatusView = (typeof ORDER_STATUSES)[number]

const PAYMENT_LABELS: Record<string, string> = {
  UNPAID: 'Unpaid', PAID: 'Paid', PARTIALLY_REFUNDED: 'Partly refunded', REFUNDED: 'Refunded', FAILED: 'Failed',
}

type Str = string | null | undefined
interface RawAddress { firstName?: Str; lastName?: Str; company?: Str; street1?: Str; street2?: Str; city?: Str; state?: Str; zip?: Str; country?: Str; phone?: Str }
interface RawItem { id: string; title?: Str; variantTitle?: Str; sku?: Str; quantity?: number; price?: number; total?: number }

export interface RawOrder {
  id: string
  orderNumber: string
  email?: Str
  status?: Str
  paymentStatus?: Str
  subtotal?: number
  shippingTotal?: number
  taxTotal?: number
  discountTotal?: number
  total?: number
  internalNotes?: Str
  stripePaymentIntentId?: Str
  customer?: { firstName?: Str; lastName?: Str; email?: Str; phone?: Str } | null
  items?: RawItem[]
  shippingAddress?: RawAddress | null
  billingAddress?: RawAddress | null
  shipments?: { trackingNumber?: Str }[]
  createdAt?: string
  updatedAt?: string
  [key: string]: unknown
}

export interface AddressView { name: string; street: string; city: string; state: string; zip: string; country: string; phone: string | null }

export interface OrderView {
  id: string
  orderNumber: string
  status: OrderStatusView
  paymentStatus: string
  /** For filtering: 'paid' | 'unpaid' | 'refunded' (full or part) | 'failed'. */
  paymentKey: 'paid' | 'unpaid' | 'refunded' | 'failed'
  paid: boolean
  paymentMethod: string
  customer: { name: string; email: string; phone: string | null }
  items: { id: string; name: string; variant: string | null; sku: string | null; quantity: number; priceCents: number; totalCents: number }[]
  subtotalCents: number
  shippingCents: number
  taxCents: number
  discountCents: number
  totalCents: number
  shippingAddress: AddressView | null
  billingAddress: AddressView | null
  notes: string
  trackingNumber: string | null
  createdAt: string
  updatedAt: string
}

const clean = (s: Str) => (typeof s === 'string' ? s.trim() : '')
const joinName = (a: Str, b: Str) => [clean(a), clean(b)].filter(Boolean).join(' ')
const cents = (n: unknown) => (typeof n === 'number' && Number.isFinite(n) ? Math.round(n) : 0)

function addressView(a: RawAddress | null | undefined): AddressView | null {
  if (!a) return null
  return {
    name: joinName(a.firstName, a.lastName) || clean(a.company),
    street: [clean(a.street1), clean(a.street2)].filter(Boolean).join(', '),
    city: clean(a.city), state: clean(a.state), zip: clean(a.zip), country: clean(a.country),
    phone: clean(a.phone) || null,
  }
}

function statusView(s: Str): OrderStatusView {
  const lower = clean(s).toLowerCase()
  return (ORDER_STATUSES as readonly string[]).includes(lower) ? (lower as OrderStatusView) : 'pending'
}

/** How many items an order has, counting quantities (two of one product is two items). */
export function itemCount(v: Pick<OrderView, 'items'>): number {
  return v.items.reduce((n, i) => n + i.quantity, 0)
}

/** The value the API stores for a status the page offers; null for anything else. */
export function statusForApi(s: string): string | null {
  const lower = s.trim().toLowerCase()
  return (ORDER_STATUSES as readonly string[]).includes(lower) ? lower.toUpperCase() : null
}

export function toOrderView(o: RawOrder): OrderView {
  const ship = addressView(o.shippingAddress)
  const bill = addressView(o.billingAddress)
  const email = clean(o.customer?.email) || clean(o.email)
  const pay = clean(o.paymentStatus).toUpperCase()
  return {
    id: o.id,
    orderNumber: o.orderNumber,
    status: statusView(o.status),
    paymentStatus: PAYMENT_LABELS[pay] ?? (pay ? pay.toLowerCase() : 'Unpaid'),
    paymentKey: pay === 'PAID' ? 'paid' : pay === 'REFUNDED' || pay === 'PARTIALLY_REFUNDED' ? 'refunded' : pay === 'FAILED' ? 'failed' : 'unpaid',
    paid: pay === 'PAID',
    paymentMethod: clean(o.stripePaymentIntentId) ? 'Card (Stripe)' : 'Not paid online',
    customer: {
      name: joinName(o.customer?.firstName, o.customer?.lastName) || ship?.name || bill?.name || email,
      email,
      phone: clean(o.customer?.phone) || ship?.phone || bill?.phone || null,
    },
    items: (o.items ?? []).map((i) => ({
      id: i.id,
      name: clean(i.title) || 'Item',
      variant: clean(i.variantTitle) || null,
      sku: clean(i.sku) || null,
      quantity: i.quantity ?? 1,
      priceCents: cents(i.price),
      totalCents: typeof i.total === 'number' ? cents(i.total) : cents(i.price) * (i.quantity ?? 1),
    })),
    subtotalCents: cents(o.subtotal),
    shippingCents: cents(o.shippingTotal),
    taxCents: cents(o.taxTotal),
    discountCents: cents(o.discountTotal),
    totalCents: cents(o.total),
    shippingAddress: ship,
    billingAddress: bill,
    notes: clean(o.internalNotes),
    trackingNumber: (o.shipments ?? []).map((s) => clean(s.trackingNumber)).find(Boolean) ?? null,
    createdAt: o.createdAt ?? '',
    updatedAt: o.updatedAt ?? '',
  }
}
