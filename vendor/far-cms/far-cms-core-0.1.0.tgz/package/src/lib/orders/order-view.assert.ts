/**
 * The order page reads the order the API sends (Prisma's shape: cents, upper-case statuses, address rows,
 * shipments). Found 2026-11-22: the page was written for a made-up shape, so a real order (ORD-000001 on
 * staging, placed for a new email with no customer record) crashed it on customer.name.
 * Run: node_modules/.bin/tsx src/lib/orders/order-view.assert.ts
 */
import assert from 'node:assert/strict'
import { toOrderView, statusForApi, ORDER_STATUSES, itemCount } from './order-view'

const raw = {
  id: 'o1', orderNumber: 'ORD-000001', email: 'sample-order@example.org', status: 'PENDING', paymentStatus: 'UNPAID',
  subtotal: 1000, shippingTotal: 250, taxTotal: 90, discountTotal: 0, total: 1340, internalNotes: null,
  stripePaymentIntentId: null, customer: null, createdAt: '2026-11-22T18:32:26.541Z', updatedAt: '2026-11-22T18:32:26.541Z',
  items: [{ id: 'i1', title: 'SAMPLE product', variantTitle: 'Large', sku: null, quantity: 2, price: 500, total: 1000 }],
  shippingAddress: { firstName: 'SAMPLE', lastName: 'Buyer', company: null, street1: '1 Market St', street2: 'Suite 2', city: 'San Francisco', state: 'CA', zip: '94105', country: 'US', phone: '4155550100' },
  billingAddress: null, shipments: [], workflow: null, currentStage: null, progress: [],
}
const v = toOrderView(raw)
assert.equal(v.customer.name, 'SAMPLE Buyer', 'no customer record: the name comes from the shipping address')
assert.equal(v.customer.email, 'sample-order@example.org', 'and the email from the order')
assert.equal(v.customer.phone, '4155550100')
assert.deepEqual([v.subtotalCents, v.shippingCents, v.taxCents, v.totalCents], [1000, 250, 90, 1340], 'money stays in cents')
assert.equal(v.items[0].name, 'SAMPLE product')
assert.equal(v.items[0].variant, 'Large')
assert.equal(v.items[0].totalCents, 1000)
assert.equal(v.status, 'pending')
assert.equal(v.paymentStatus, 'Unpaid')
assert.equal(v.paid, false)
assert.equal(v.paymentKey, 'unpaid')
assert.equal(itemCount(v), 2, 'two of one product is two items')
assert.equal(v.shippingAddress?.street, '1 Market St, Suite 2')
assert.equal(v.billingAddress, null, 'no billing row: shown as missing, never invented')
assert.equal(v.trackingNumber, null)
assert.equal(v.notes, '')

const withCustomer = toOrderView({ ...raw, status: 'SHIPPED', paymentStatus: 'PARTIALLY_REFUNDED', customer: { firstName: 'Ama', lastName: null, email: 'ama@example.org', phone: null }, shipments: [{ trackingNumber: '1Z999' }], internalNotes: 'Gift' })
assert.equal(withCustomer.customer.name, 'Ama', 'a customer record wins over the address')
assert.equal(withCustomer.customer.email, 'ama@example.org')
assert.equal(withCustomer.status, 'shipped')
assert.equal(withCustomer.paymentStatus, 'Partly refunded')
assert.equal(withCustomer.paymentKey, 'refunded', 'a part refund files under refunded')
assert.equal(withCustomer.trackingNumber, '1Z999', 'tracking comes from the latest shipment')
assert.equal(withCustomer.notes, 'Gift')

const bare = toOrderView({ id: 'o2', orderNumber: 'ORD-2', email: 'x@example.org', status: 'WEIRD', paymentStatus: 'PAID', subtotal: 0, total: 0, items: [] })
assert.equal(bare.customer.name, 'x@example.org', 'nothing else known: the email names them')
assert.equal(bare.status, 'pending', 'an unknown status reads as pending rather than breaking the page')
assert.equal(bare.paid, true)
assert.equal(bare.paymentKey, 'paid')
assert.equal(itemCount(bare), 0)
assert.equal(bare.shippingAddress, null)

assert.equal(statusForApi('shipped'), 'SHIPPED')
assert.equal(statusForApi('refunded'), 'REFUNDED')
assert.equal(statusForApi('SHIPPED'), 'SHIPPED')
assert.equal(statusForApi('nonsense'), null, 'anything else is refused')
assert.equal(ORDER_STATUSES.length, 6)
console.log('order-view: 36 checks passed')
