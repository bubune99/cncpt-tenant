/**
 * Run: npx -y tsx@4.23.15 src/lib/security/settings-restore.assert.ts
 * R2-9: restoring an old version of a settings group can't flip a gated
 * field (direct changeMode, DB code execution, the visibility rules and
 * areas, RBAC off) — those are never restored.
 */
import assert from 'node:assert/strict'
import { planRestore, type RestorePolicy } from '../ade/history/policy'
import { SETTINGS_NEVER_RESTORE } from '../settings/group-access'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// Built the same way as lib/settings/history SETTINGS_POLICY (that module registers with the DB).
const POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: Object.fromEntries(Object.entries(SETTINGS_NEVER_RESTORE).map(([f, reason]) => [f, { class: 'never' as const, reason }])),
  defaultField: { class: 'restorable', type: 'json' },
}
const plan = (current: Record<string, unknown>, target: Record<string, unknown>) =>
  planRestore({ policy: POLICY, current, target, fromVersion: 1, targetSchemaVersion: 1, changedSince: new Set() })

check('the four audited fields (and RBAC off) are never restored', () => {
  for (const f of ['changeMode', 'allowDbCodeExecution', 'visibilityRules', 'privacyAreas', 'respectRbac']) assert.ok(Object.hasOwn(SETTINGS_NEVER_RESTORE, f), f)
})

check('an old ade version with direct mode + code execution on: both skipped, nothing selectable', () => {
  const p = plan({ changeMode: 'draft', allowDbCodeExecution: false, staleDraftDays: 14 }, { changeMode: 'direct', allowDbCodeExecution: true, staleDraftDays: 7 })
  const by = Object.fromEntries(p.fields.map((f) => [f.field, f]))
  assert.equal(by.changeMode.selectable, false)
  assert.equal(by.changeMode.skip?.reason, 'never')
  assert.equal(by.allowDbCodeExecution.selectable, false)
  assert.equal(by.staleDraftDays.selectable, true, 'ordinary fields still restore')
})

check('an old agent version with looser visibility: skipped (its own screen confirms loosening)', () => {
  const p = plan({ visibilityRules: [{ id: 'custom.notes', level: 'blocked' }], privacyAreas: { orders: 'blocked' }, respectRbac: true }, { visibilityRules: [], privacyAreas: { orders: 'readable' }, respectRbac: false })
  assert.ok(p.fields.every((f) => f.selectable === false && f.skip?.reason === 'never'))
})

console.log(`\n${n} checks passed`)
