/**
 * Security regression: review eligibility is never an oracle on someone
 * else's purchases (GET /api/reviews/product/:id?email=…).
 * Run: npx -y tsx@4.23.15 src/lib/security/review-eligibility.assert.ts
 */
import assert from 'node:assert/strict'
import { eligibilityRequest } from '../reviews/public'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const q = (s: string) => new URLSearchParams(s)

check('anonymous callers get no eligibility, whatever they pass', () => {
  for (const s of ['email=ama@example.org', 'userId=cust_1', 'eligibility=1', 'email=ama@example.org&userId=cust_1']) assert.deepEqual(eligibilityRequest(q(s), null), { kind: 'none' }, s)
})

check('someone else\'s address is refused; a customer id from the URL is never used', () => {
  assert.deepEqual(eligibilityRequest(q('email=kofi@example.org'), 'ama@example.org'), { kind: 'forbidden' })
  assert.deepEqual(eligibilityRequest(q('userId=cust_someone_else'), 'ama@example.org'), { kind: 'own', email: 'ama@example.org' })
})

check('the signed-in person may check their own (any case), or ask without naming an address', () => {
  assert.deepEqual(eligibilityRequest(q('email=AMA@Example.org'), 'ama@example.org'), { kind: 'own', email: 'ama@example.org' })
  assert.deepEqual(eligibilityRequest(q('eligibility=1'), 'Ama@Example.org'), { kind: 'own', email: 'ama@example.org' })
  assert.deepEqual(eligibilityRequest(q('page=2'), 'ama@example.org'), { kind: 'none' })
})

console.log(`\n${n} checks passed`)
