/**
 * Security regression (audit run-2 R2-4): a completed upload's key, URL,
 * bucket, provider and MIME type come from the server, and local deletes
 * can't leave public/uploads.
 * Run: npx -y tsx@4.23.15 src/lib/security/media-complete.assert.ts
 */
import assert from 'node:assert/strict'
import { isSafeLocalKey, mimeForKey, UPLOAD_KEY_RE, uploadTarget } from '../media/upload-key'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const KEY = 'uploads/2026-10-11/0f8e9b9a-4c3d-4e2f-9a1b-2c3d4e5f6a7b.jpg'

check('only keys we issue are accepted (a legacy asset\'s key or a path is refused)', () => {
  assert.ok(UPLOAD_KEY_RE.test(KEY))
  for (const bad of ['legacy/hero-banner.jpg', '../../etc/passwd', 'uploads/2026-10-11/../../x.jpg', '/abs/x.jpg', 'uploads/2026-10-11/not-a-uuid.jpg', ''])
    assert.ok(!UPLOAD_KEY_RE.test(bad), bad)
})

check('url / bucket / provider come from the storage settings, not the client', () => {
  assert.deepEqual(uploadTarget({ provider: 'r2', bucket: 'dzidzor-media', publicUrl: 'https://media.projectdzidzor.org/' }, KEY, 'https://x'), { provider: 'R2', bucket: 'dzidzor-media', url: `https://media.projectdzidzor.org/${KEY}` })
  assert.deepEqual(uploadTarget({ provider: 'S3', bucket: 'b', region: 'us-east-1' }, KEY, 'https://x'), { provider: 'S3', bucket: 'b', url: `https://b.s3.us-east-1.amazonaws.com/${KEY}` })
  assert.deepEqual(uploadTarget({ provider: null }, KEY, 'https://site.example/'), { provider: 'LOCAL', bucket: 'local', url: `https://site.example/uploads/${KEY}` })
  assert.ok('error' in uploadTarget({ provider: 'R2', bucket: 'b' }, KEY, 'https://x'))
})

check('the MIME type must fit the key\'s extension', () => {
  assert.equal(mimeForKey(KEY, 'image/jpeg'), 'image/jpeg')
  assert.equal(mimeForKey(KEY, 'text/html'), null)
  assert.equal(mimeForKey(KEY.replace('.jpg', '.svg'), 'image/svg+xml'), 'image/svg+xml')
  // Other extensions keep the claimed type (the server also re-runs the upload's type policy).
  assert.equal(mimeForKey(KEY.replace('.jpg', '.docx'), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
  assert.equal(mimeForKey(KEY.replace('.jpg', '.heic'), 'image/heic'), 'image/heic')
  assert.equal(mimeForKey(KEY, 'not a type'), null)
  assert.equal(mimeForKey(KEY, 42), null)
})

check('local deletes stay inside public/uploads', () => {
  assert.ok(isSafeLocalKey(KEY))
  for (const bad of ['../../.env', 'uploads/../../.env', '/etc/passwd', '\\\\server\\share', 'a/..', 'a\0b', ''])
    assert.ok(!isSafeLocalKey(bad), JSON.stringify(bad))
})

console.log(`\n${n} checks passed`)
