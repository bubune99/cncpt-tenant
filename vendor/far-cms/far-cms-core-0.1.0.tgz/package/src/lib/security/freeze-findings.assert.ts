/**
 * Security regressions for the freeze findings (dzidzor-freeze-prep.md 3b):
 * the exact payloads that found H-1, H-2 and H-3, run against the real code.
 * Run: npx -y tsx@4.23.15 src/lib/security/freeze-findings.assert.ts
 */
import assert from 'node:assert/strict'
import { decodeEntities, safeUrl, sanitizeHtml, sanitizeRichHtml } from '../sanitize-html'
import { neutraliseThemeCss, themeCssProblem } from '../theme-css'
import { reviewListQuery, safeReviewSort, toPublicReview } from '../reviews/public'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('H-1: the four reported payloads no longer survive the sanitizer (inline and rich text)', () => {
  for (const p of ['<a href=javascript:alert(1)>x</a>', '<a href="java&#115;cript:alert(1)">x</a>', '<a href=" javascript:alert(1)">x</a>', '<span style="background:url(javascript:alert(1))">x</span>']) {
    for (const out of [sanitizeHtml(p), sanitizeRichHtml(p)]) {
      assert.ok(!/javascript:/i.test(decodeEntities(out).replace(/\s+/g, '')), `${p} → ${out}`)
      assert.ok(!/url\s*\(/i.test(out), `${p} → ${out}`)
    }
  }
})

check('MED: block attrs use the same URL allow-list (href/src)', () => {
  for (const bad of ['javascript:alert(1)', ' JaVa&#83;cript:alert(1)', 'data:text/html,<script>alert(1)</script>', 'vbscript:x']) assert.equal(safeUrl(bad), null, bad)
  for (const ok of ['https://projectdzidzor.org', '/initiatives', '#top', 'mailto:a@b.co', 'tel:+1']) assert.ok(safeUrl(ok), ok)
})

check('H-2: theme CSS can neither be saved with a breakout nor render one', () => {
  const attack = '</style><script>alert(document.cookie)</script>'
  assert.ok(themeCssProblem(attack))
  assert.ok(!/<\/style|<script/i.test(neutraliseThemeCss(attack)))
})

check('H-3: public reviews are APPROVED only, without email/IP/UA, sorted by allow-listed fields', () => {
  assert.equal(reviewListQuery(new URLSearchParams('status=PENDING'), false).filters.status, 'APPROVED')
  assert.equal(safeReviewSort('reviewerEmail', 'asc').field, 'createdAt')
  const pub = toPublicReview({ id: 'r', reviewerName: 'A', reviewerEmail: 'a@b.co', ipAddress: '1.2.3.4', userAgent: 'UA' })
  assert.deepEqual(Object.keys(pub).sort(), ['id', 'reviewerName'])
})

console.log(`\n${n} checks passed`)
