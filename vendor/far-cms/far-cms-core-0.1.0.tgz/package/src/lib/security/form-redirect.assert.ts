/**
 * Security regression (audit run-2 R2-6): a form's "go to after sending"
 * address is http(s) or a page on this site — checked on save and before the
 * browser navigates.
 * Run: npx -y tsx@4.23.15 src/lib/security/form-redirect.assert.ts
 */
import assert from 'node:assert/strict'
import { redirectUrlProblem, safeRedirectUrl } from '../forms/redirect'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('script and scheme tricks are refused on save and never navigated to', () => {
  for (const bad of ['javascript:alert(document.cookie)', ' JavaScript:alert(1)', 'java\tscript:alert(1)', 'data:text/html,<script>alert(1)</script>', 'vbscript:x', '//evil.example/phish', '/\\evil.example', 'ftp://x.example', 'mailto:a@b.co', 42, { href: '/' }]) {
    assert.equal(safeRedirectUrl(bad), null, String(bad))
    assert.ok(redirectUrlProblem(bad), String(bad))
  }
})

check('real thank-you pages still work; empty clears it', () => {
  assert.equal(safeRedirectUrl('/thank-you'), '/thank-you')
  assert.equal(safeRedirectUrl('https://projectdzidzor.org/give?from=form'), 'https://projectdzidzor.org/give?from=form')
  assert.equal(safeRedirectUrl('http://example.org'), 'http://example.org/')
  for (const ok of [undefined, null, '', '  ', '/thanks', 'https://x.example/']) assert.equal(redirectUrlProblem(ok), null, String(ok))
})

console.log(`\n${n} checks passed`)
