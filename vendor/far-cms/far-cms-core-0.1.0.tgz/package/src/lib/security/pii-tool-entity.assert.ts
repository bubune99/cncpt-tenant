/**
 * Run: npx -y tsx@4.23.15 src/lib/security/pii-tool-entity.assert.ts
 * R2-8: every agent / MCP tool that returns people data (orders, customers,
 * users, submissions, subscribers) is mapped to its entity, so the
 * visibility areas ("assistant may not see orders") cover it.
 */
import assert from 'node:assert/strict'
import { TOOL_ENTITY, targetsOf } from '../ade-bindings/visibility-apply'
import { MCP_NATIVE_TOOLS, TOOL_REGISTRY } from '../ai/governance/tool-registry'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

/** Names that return people data. Polymorphic entity tools take entityType from their input instead. */
const PII = /order|customer|user|submission|subscriber|activity/i
const POLYMORPHIC = new Set(['getEntityDetails', 'searchEntities', 'getEntityStats'])
// The person's own mailbox tools (connectors branch) carry their own rules.
const OWN_MAILBOX = (name: string) => (TOOL_REGISTRY[name]?.domain as string | undefined) === 'email'
/** Names that match PII by accident, reviewed: they return no people records. */
const NOT_PEOPLE_DATA: Record<string, string> = {
  ask_user: 'the question form shown in the chat: returns the model\'s own checked questions (and library media urls), no records about people',
}

check('every registry or MCP tool returning people data maps to its entity', () => {
  const names = [...Object.keys(TOOL_REGISTRY), ...Object.keys(MCP_NATIVE_TOOLS)]
  const missing = names.filter((t) => PII.test(t) && !POLYMORPHIC.has(t) && !OWN_MAILBOX(t) && !Object.hasOwn(TOOL_ENTITY, t) && !Object.hasOwn(NOT_PEOPLE_DATA, t))
  assert.deepEqual(missing, [], `map these in TOOL_ENTITY: ${missing.join(', ')}`)
  // An exemption is only for a registered, non-mutating tool that really matched by name (never a blanket pass).
  for (const t of Object.keys(NOT_PEOPLE_DATA)) assert.ok(PII.test(t) && TOOL_REGISTRY[t] && TOOL_REGISTRY[t].mutation === false, `NOT_PEOPLE_DATA: ${t}`)
})

check('the order tools the audit named are covered', () => {
  for (const t of ['searchOrders', 'list_orders', 'get_order']) assert.deepEqual(targetsOf(t, {}), { entity: 'order' }, t)
  assert.deepEqual(targetsOf('getEntityDetails', { entityType: 'order' }), { entity: 'order' }, 'polymorphic tools use their input')
})

console.log(`\n${n} checks passed`)
