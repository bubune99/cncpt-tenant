/**
 * Run: npx -y tsx@4.23.15 src/lib/v0-agent/tools/fetch-v0.assert.ts
 */
import assert from 'node:assert/strict'
import { isV0Url } from './fetch-v0'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('only https v0.dev (and its subdomains) is fetched', () => {
  for (const ok of ['https://v0.dev/t/abc123', 'https://www.v0.dev/t/abc', 'https://V0.DEV/chat/x']) assert.equal(isV0Url(new URL(ok)), true, ok)
  for (const bad of ['https://v0.dev.evil.example/t/x', 'https://notv0.dev/t/x', 'http://v0.dev/t/x', 'https://evil.example/v0.dev', 'https://user:pw@v0.dev/t/x', 'https://v0.dev.169.254.169.254.nip.io/']) {
    assert.equal(isV0Url(new URL(bad)), false, bad)
  }
})

console.log(`\n${n} checks passed`)
