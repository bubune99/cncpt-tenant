/**
 * A blog post as ONE editable document — everything the post editor (and
 * the assistant's updateBlogPost) can change, except publishing, which is
 * its own change (blog-status). Drafts, the To-do review card and the apply
 * on approval all work on this shape. Pure; asserted by post-doc.assert.ts.
 *
 * Pictures are Media library items (ids), as the old PUT mapped them.
 */

export type PostVisibility = 'PUBLIC' | 'PRIVATE' | 'PASSWORD_PROTECTED' | 'MEMBERS_ONLY'

export interface PostDoc {
  title: string
  slug: string
  excerpt: string
  /** TipTap JSON (null when only HTML exists). */
  content: unknown
  contentHtml: string
  visibility: PostVisibility
  categoryIds: string[]
  tagIds: string[]
  authorId: string | null
  featured: boolean
  /** Position in home-page / featured lists (lower first); null = by date. */
  homeOrder: number | null
  allowComments: boolean
  metaTitle: string
  metaDescription: string
  coverMediaId: string | null
  shareMediaId: string | null
}

const VIS: ReadonlyArray<PostVisibility> = ['PUBLIC', 'PRIVATE', 'PASSWORD_PROTECTED', 'MEMBERS_ONLY']
const s = (v: unknown) => (typeof v === 'string' ? v : '')
const id = (v: unknown) => (typeof v === 'string' && v ? v : null)
const ids = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string' && x.length > 0) : [])

export function normalizeHomeOrder(v: unknown): number | null {
  if (v === null || v === undefined || v === '') return null
  const n = typeof v === 'number' ? v : Number(v)
  return Number.isInteger(n) && n >= 0 && n <= 999 ? n : null
}

/**
 * Anything (a DB row, a stored draft, a request body) → a complete document.
 * Deterministic, so stale checks compare cleanly. Rows may carry
 * featuredImageId / ogImageId and categories/tags relations instead.
 */
export function normalizePostDoc(raw: Record<string, unknown>): PostDoc {
  const rel = (list: unknown, key: 'category' | 'tag', idKey: 'categoryId' | 'tagId') =>
    Array.isArray(list) ? list.map((x) => (x as Record<string, unknown>)?.[idKey] ?? ((x as Record<string, unknown>)?.[key] as { id?: unknown } | undefined)?.id).filter((x): x is string => typeof x === 'string') : []
  return {
    title: s(raw.title),
    slug: s(raw.slug),
    excerpt: s(raw.excerpt),
    content: raw.content ?? null,
    contentHtml: s(raw.contentHtml),
    visibility: VIS.includes(raw.visibility as PostVisibility) ? (raw.visibility as PostVisibility) : 'PUBLIC',
    categoryIds: raw.categoryIds !== undefined ? ids(raw.categoryIds) : rel(raw.categories, 'category', 'categoryId'),
    tagIds: raw.tagIds !== undefined ? ids(raw.tagIds) : rel(raw.tags, 'tag', 'tagId'),
    authorId: id(raw.authorId),
    featured: raw.featured === true,
    homeOrder: normalizeHomeOrder(raw.homeOrder),
    allowComments: raw.allowComments !== false,
    metaTitle: s(raw.metaTitle),
    metaDescription: s(raw.metaDescription),
    coverMediaId: id(raw.coverMediaId ?? raw.featuredImageId),
    shareMediaId: id(raw.shareMediaId ?? raw.ogImageId),
  }
}

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/

/** `before` = the live post: an existing odd web address isn't re-judged unless it changes. */
export function validatePostDoc(doc: PostDoc, before?: PostDoc | null): string | null {
  if (!doc.title.trim()) return 'Give the post a title first.'
  if (doc.title.length > 200) return 'Keep the title under 200 characters.'
  if (doc.slug !== before?.slug && !SLUG.test(doc.slug)) return 'The web address can use lowercase letters, numbers and dashes only.'
  if (doc.metaTitle.length > 200 || doc.metaDescription.length > 500) return 'The search title or description is too long.'
  return null
}

/** Plain words for each field (review cards, "N unsaved changes"). */
export const POST_FIELD_WORDS: Record<keyof PostDoc, string> = {
  title: 'title',
  slug: 'web address',
  excerpt: 'summary',
  content: 'story',
  contentHtml: 'story',
  visibility: 'who can see it',
  categoryIds: 'categories',
  tagIds: 'tags',
  authorId: 'author',
  featured: 'home-page feature',
  homeOrder: 'home-page order',
  allowComments: 'comments',
  metaTitle: 'search title',
  metaDescription: 'search description',
  coverMediaId: 'cover',
  shareMediaId: 'share image',
}

const same = (a: unknown, b: unknown) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null)

/** What changed, in plain words, each once ("story" covers HTML + JSON). */
export function postDocChanges(before: PostDoc, after: PostDoc): string[] {
  const out: string[] = []
  for (const k of Object.keys(POST_FIELD_WORDS) as Array<keyof PostDoc>) {
    if (k === 'content') continue // the HTML is what people see; JSON follows it
    if (!same(before[k], after[k]) && !out.includes(POST_FIELD_WORDS[k])) out.push(POST_FIELD_WORDS[k])
  }
  return out
}

/**
 * The assistant's updateBlogPost fields → a partial document. Publishing is
 * NOT a field here (it's publishBlogPost); `status` is reported back.
 */
export function patchFromToolInput(input: Record<string, unknown>): { patch: Partial<PostDoc>; status?: unknown } {
  const p: Partial<PostDoc> = {}
  if (typeof input.title === 'string') p.title = input.title
  if (typeof input.slug === 'string') p.slug = input.slug
  if (typeof input.excerpt === 'string') p.excerpt = input.excerpt
  if (typeof input.featured === 'boolean') p.featured = input.featured
  if (input.homeOrder !== undefined) p.homeOrder = normalizeHomeOrder(input.homeOrder)
  if (typeof input.seoTitle === 'string') p.metaTitle = input.seoTitle
  if (typeof input.seoDescription === 'string') p.metaDescription = input.seoDescription
  if (Array.isArray(input.categoryIds)) p.categoryIds = ids(input.categoryIds)
  if (Array.isArray(input.tagIds)) p.tagIds = ids(input.tagIds)
  return { patch: p, ...(input.status !== undefined ? { status: input.status } : {}) }
}

/** The write for lib/blog updatePost: every field, empty text clears. */
export function docToUpdateInput(doc: PostDoc): Record<string, unknown> {
  return {
    title: doc.title.trim(),
    slug: doc.slug,
    excerpt: doc.excerpt.trim() || null,
    ...(doc.content !== null ? { content: doc.content } : {}),
    contentHtml: doc.contentHtml,
    visibility: doc.visibility,
    categoryIds: doc.categoryIds,
    tagIds: doc.tagIds,
    authorId: doc.authorId,
    featured: doc.featured,
    homeOrder: doc.homeOrder,
    allowComments: doc.allowComments,
    metaTitle: doc.metaTitle.trim() || null,
    metaDescription: doc.metaDescription.trim() || null,
    featuredImageId: doc.coverMediaId,
    ogImageId: doc.shareMediaId,
  }
}

/** Home-page / featured order: homeOrder first (lower first), then newest. */
export function compareHomeOrder(a: { homeOrder?: number | null; publishedAt?: Date | string | null }, b: { homeOrder?: number | null; publishedAt?: Date | string | null }): number {
  const ao = a.homeOrder ?? Number.POSITIVE_INFINITY
  const bo = b.homeOrder ?? Number.POSITIVE_INFINITY
  if (ao !== bo) return ao < bo ? -1 : 1
  const at = a.publishedAt ? new Date(a.publishedAt).getTime() : 0
  const bt = b.publishedAt ? new Date(b.publishedAt).getTime() : 0
  return bt - at
}
