/**
 * A category's post count on public pages counts only published posts, the same posts its page lists.
 * Found onboarding /posts on staging 2026-11-22: the sidebar said "Initiatives 5" and /categories/initiatives
 * said "0 posts" (the 5 were drafts). Run: node_modules/.bin/tsx src/lib/blog/public-count.assert.ts
 */
import assert from 'node:assert/strict'
import { PUBLISHED_POST_COUNT, publicPostCount } from './public-count'

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log('ok', n, '-', name) }

ok('the count asks the database for published posts only', () => {
  assert.deepEqual(PUBLISHED_POST_COUNT, { select: { posts: { where: { post: { status: 'PUBLISHED' } } } } })
})
ok('the count shown matches what the category page lists', () => {
  const posts = [{ status: 'PUBLISHED' }, { status: 'DRAFT' }, { status: 'DRAFT' }, { status: 'SCHEDULED' }, { status: 'PUBLISHED' }]
  assert.equal(publicPostCount(posts), 2)
  assert.equal(publicPostCount([{ status: 'DRAFT' }]), 0)
})
console.log(`\n${n} checks passed`)
