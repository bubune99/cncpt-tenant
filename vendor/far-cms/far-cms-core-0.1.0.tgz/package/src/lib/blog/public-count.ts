/**
 * How public pages count a blog category's posts: published only, the same set the category page lists
 * (status PUBLISHED). Use PUBLISHED_POST_COUNT as a category's `_count`. Check: src/lib/blog/public-count.assert.ts
 */
export const PUBLISHED_POST_COUNT = { select: { posts: { where: { post: { status: 'PUBLISHED' as const } } } } }

export function publicPostCount(posts: { status: string }[]): number {
  return posts.filter((p) => p.status === 'PUBLISHED').length
}
