/**
 * Run: npx -y tsx@4.23.15 src/lib/blog/post-doc.assert.ts
 */
import assert from 'node:assert/strict'
import { compareHomeOrder, docToUpdateInput, normalizeHomeOrder, normalizePostDoc, patchFromToolInput, postDocChanges, validatePostDoc } from './post-doc'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// A DB row shape (relations + image ids), as livePostDoc reads it.
const row = {
  title: 'Test post (temp)', slug: 'test-post-temp', excerpt: null, content: { type: 'doc' }, contentHtml: '<p>Hi</p>', visibility: 'PUBLIC',
  authorId: 'u1', featured: false, homeOrder: null, allowComments: true, metaTitle: null, metaDescription: null,
  featuredImageId: 'm1', ogImageId: null, categories: [{ categoryId: 'c1' }], tags: [{ tagId: 't1' }, { tagId: 't2' }],
}

check('a DB row becomes a complete, deterministic document', () => {
  const d = normalizePostDoc(row)
  assert.equal(d.excerpt, '')
  assert.equal(d.coverMediaId, 'm1')
  assert.equal(d.shareMediaId, null)
  assert.deepEqual(d.categoryIds, ['c1'])
  assert.deepEqual(d.tagIds, ['t1', 't2'])
  assert.deepEqual(normalizePostDoc(row), normalizePostDoc(JSON.parse(JSON.stringify(row))))
  // A stored draft (doc shape) round-trips unchanged.
  assert.deepEqual(normalizePostDoc(d as unknown as Record<string, unknown>), d)
})

check('changes are listed once, in plain words', () => {
  const before = normalizePostDoc(row)
  const after = { ...before, title: 'New', coverMediaId: 'm2', contentHtml: '<p>Bye</p>', content: { type: 'doc', x: 1 }, homeOrder: 2 }
  assert.deepEqual(postDocChanges(before, after), ['title', 'story', 'home-page order', 'cover'])
  assert.deepEqual(postDocChanges(before, before), [])
})

check('validation: title, new web addresses, but an odd existing address is left alone', () => {
  const d = normalizePostDoc(row)
  assert.equal(validatePostDoc(d, d), null)
  assert.ok(validatePostDoc({ ...d, title: ' ' }, d))
  assert.ok(validatePostDoc({ ...d, slug: 'Bad Slug' }, d))
  const legacy = { ...d, slug: 'Old_WP_Slug' }
  assert.equal(validatePostDoc(legacy, legacy), null)
})

check('the assistant edits fields, never publishing', () => {
  assert.deepEqual(patchFromToolInput({ id: 'x', seoTitle: 'S', homeOrder: 3 }).patch, { metaTitle: 'S', homeOrder: 3 })
  assert.equal(patchFromToolInput({ id: 'x', status: 'PUBLISHED' }).status, 'PUBLISHED')
})

check('the write clears empty text and maps pictures to ids', () => {
  const w = docToUpdateInput({ ...normalizePostDoc(row), metaTitle: '  ' })
  assert.equal(w.metaTitle, null)
  assert.equal(w.excerpt, null)
  assert.equal(w.featuredImageId, 'm1')
  assert.equal(w.ogImageId, null)
  assert.ok(!('status' in w), 'never writes status')
})

check('home-page order: numbered first (lower first), then newest', () => {
  const posts = [
    { id: 'a', homeOrder: null, publishedAt: '2026-10-01' },
    { id: 'b', homeOrder: 2, publishedAt: '2026-01-01' },
    { id: 'c', homeOrder: 0, publishedAt: '2025-01-01' },
    { id: 'd', homeOrder: null, publishedAt: '2026-10-05' },
  ]
  assert.deepEqual([...posts].sort(compareHomeOrder).map((p) => p.id), ['c', 'b', 'd', 'a'])
  assert.equal(normalizeHomeOrder('4'), 4)
  assert.equal(normalizeHomeOrder(-1), null)
  assert.equal(normalizeHomeOrder(''), null)
})

console.log(`\n${n} checks passed`)
