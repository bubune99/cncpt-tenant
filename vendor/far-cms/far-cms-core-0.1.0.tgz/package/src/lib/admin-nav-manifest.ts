/**
 * Canonical admin navigation manifest.
 *
 * Pure data (icon names as strings, no React imports) so it is safe to
 * import anywhere: AdminShell renders the sidebar from it, and the
 * Settings → Navigation editor lists exactly these items for relabeling.
 * Per-deployment overrides (label/icon/hidden) live in the `navigation`
 * settings group keyed by each item's href.
 */

export interface NavManifestItem {
  name: string;
  href: string;
  icon: string;
  badgeKey?: string;
  helpKey?: string;
  tourId?: string;
  /** CMSConfig.audienceLabel overrides this item's name when set */
  audienceLabeled?: boolean;
}

export interface NavManifestGroup {
  name: string;
  items: NavManifestItem[];
}

export const NAV_MANIFEST: NavManifestGroup[] = [
  {
    name: 'Main',
    items: [
      { name: 'Dashboard', href: '/admin', icon: 'LayoutDashboard', helpKey: 'admin.sidebar.dashboard' },
      { name: 'To-do', href: '/admin/todo', icon: 'ListChecks', badgeKey: 'todo', helpKey: 'admin.sidebar.todo' },
      { name: 'Analytics', href: '/admin/analytics', icon: 'BarChart3', helpKey: 'admin.analytics.dashboard' },
    ],
  },
  {
    name: 'E-Commerce',
    items: [
      { name: 'Products', href: '/admin/products', icon: 'Package', badgeKey: 'product', helpKey: 'admin.sidebar.products' },
      { name: 'Orders', href: '/admin/orders', icon: 'ShoppingCart', badgeKey: 'order', helpKey: 'admin.sidebar.orders' },
      { name: 'Order Workflows', href: '/admin/order-workflows', icon: 'Workflow', helpKey: 'admin.workflows' },
      { name: 'Shipping', href: '/admin/shipping', icon: 'Truck', badgeKey: 'shipping', helpKey: 'admin.shipping.page' },
      { name: 'Customers', href: '/admin/customers', icon: 'Users', badgeKey: 'customer', helpKey: 'admin.sidebar.customers', audienceLabeled: true },
    ],
  },
  {
    name: 'Content',
    items: [
      { name: 'Pages', href: '/admin/pages', icon: 'Layers', helpKey: 'admin.sidebar.pages' },
      { name: 'Initiatives', href: '/admin/records', icon: 'Target', helpKey: 'admin.sidebar.records' },
      { name: 'Blog', href: '/admin/blog', icon: 'FileText', helpKey: 'admin.sidebar.blog' },
      { name: 'Events', href: '/admin/events', icon: 'CalendarDays' },
      { name: 'Forms', href: '/admin/forms', icon: 'ClipboardList', badgeKey: 'form', helpKey: 'admin.forms' },
      { name: 'Media', href: '/admin/media', icon: 'Image', helpKey: 'admin.sidebar.media' },
      { name: 'Email Marketing', href: '/admin/email-marketing', icon: 'Mail', helpKey: 'admin.email-marketing.page' },
    ],
  },
  {
    name: 'System',
    items: [
      { name: 'Users', href: '/admin/users', icon: 'Users', helpKey: 'admin.users' },
      { name: 'Roles & Permissions', href: '/admin/roles', icon: 'Key', helpKey: 'admin.roles' },
      { name: 'Audit Log', href: '/admin/audit-log', icon: 'ClipboardList' },
      { name: 'Plugins', href: '/admin/plugins', icon: 'Puzzle' },
      { name: 'Workflows', href: '/admin/workflows', icon: 'GitBranch', helpKey: 'admin.workflows' },
      { name: 'Tours', href: '/admin/tours', icon: 'Compass', helpKey: 'admin.tours', tourId: 'nav-tours' },
      { name: 'Settings', href: '/admin/settings', icon: 'Settings', badgeKey: 'system', helpKey: 'admin.sidebar.settings' },
    ],
  },
];
