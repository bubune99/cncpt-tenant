/**
 * Run: npx -y tsx@4.23.15 src/lib/publishing/schedule.assert.ts
 * Scheduled publishing rules (owner 2026-10-20).
 */
import assert from 'node:assert/strict'
import { goesLiveLabel, isDue, isTimeZone, parseScheduleAt, safeTimeZone, toZonedInput, zoneName, zonedToUtc } from './schedule'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const now = new Date('2026-10-20T12:00:00Z')

check('no time, a past time or within a minute = publish now', () => {
  assert.deepEqual(parseScheduleAt(undefined, now), { ok: true, at: null })
  assert.deepEqual(parseScheduleAt('', now), { ok: true, at: null })
  assert.deepEqual(parseScheduleAt('2026-10-19T12:00:00Z', now), { ok: true, at: null })
  assert.deepEqual(parseScheduleAt('2026-10-20T12:00:30Z', now), { ok: true, at: null })
})

check('a later time schedules; nonsense and more than a year ahead are refused', () => {
  const r = parseScheduleAt('2026-10-21T09:00:00Z', now)
  assert.ok(r.ok && r.at?.toISOString() === '2026-10-21T09:00:00.000Z')
  assert.equal(parseScheduleAt('soon', now).ok, false)
  assert.equal(parseScheduleAt('2028-01-01T00:00:00Z', now).ok, false)
})

check('due when the time has come; never when not scheduled', () => {
  assert.equal(isDue(new Date('2026-10-20T11:59:00Z'), now), true)
  assert.equal(isDue(new Date('2026-10-20T12:05:00Z'), now), false)
  assert.equal(isDue(null, now), false)
})

check('the label reads in plain words and names the time zone', () => {
  assert.equal(goesLiveLabel(new Date('2026-10-21T09:00:00Z'), { timeZone: 'UTC' }), 'Goes live Wed 21 Oct, 9:00 UTC')
  assert.equal(goesLiveLabel(new Date('2026-10-21T13:00:00Z'), { timeZone: 'America/New_York' }), 'Goes live Wed 21 Oct, 9:00 New York time')
  assert.equal(goesLiveLabel(new Date('2026-10-21T09:00:00Z'), { timeZone: 'Not/AZone' }), 'Goes live Wed 21 Oct, 9:00 UTC')
})

check('a date and time on a chosen clock → the exact moment (summer, winter, half-hour zones)', () => {
  assert.equal(zonedToUtc('2026-07-01T09:00', 'America/New_York')?.toISOString(), '2026-07-01T13:00:00.000Z')
  assert.equal(zonedToUtc('2026-12-01T09:00', 'America/New_York')?.toISOString(), '2026-12-01T14:00:00.000Z')
  assert.equal(zonedToUtc('2026-10-21T09:00', 'Africa/Accra')?.toISOString(), '2026-10-21T09:00:00.000Z')
  assert.equal(zonedToUtc('2026-10-25T09:00', 'Europe/London')?.toISOString(), '2026-10-25T09:00:00.000Z')
  assert.equal(zonedToUtc('2026-10-24T09:00', 'Europe/London')?.toISOString(), '2026-10-24T08:00:00.000Z')
  assert.equal(zonedToUtc('2026-10-21T09:00', 'Asia/Kolkata')?.toISOString(), '2026-10-21T03:30:00.000Z')
  assert.equal(zonedToUtc('nonsense', 'UTC'), null)
  assert.equal(zonedToUtc('2026-10-21T09:00', 'Not/AZone'), null)
})

check('the picker shows a moment back on the chosen clock; zones are checked', () => {
  assert.equal(toZonedInput(new Date('2026-07-01T13:00:00Z'), 'America/New_York'), '2026-07-01T09:00')
  assert.equal(toZonedInput(new Date('2026-10-21T03:30:00Z'), 'Asia/Kolkata'), '2026-10-21T09:00')
  assert.equal(isTimeZone('Africa/Accra'), true)
  assert.equal(isTimeZone('Not/AZone'), false)
  assert.equal(isTimeZone(42), false)
  assert.equal(safeTimeZone('Europe/London'), 'Europe/London')
  assert.equal(safeTimeZone(undefined), 'UTC')
  assert.equal(zoneName('America/Los_Angeles'), 'Los Angeles time')
  assert.equal(zoneName('UTC'), 'UTC')
})

console.log(`\n${n} checks passed`)
