/**
 * Scheduled publishing (owner 2026-10-20): a page, blog post or initiative can be set to go live at a
 * date and time; one queued message (api/queues/scheduled) puts it live then. Scheduling
 * is a publish decision, so it goes through the same approval as publishing now.
 * Pure; asserted by schedule.assert.ts.
 */

/** Up to a year ahead. */
export const MAX_AHEAD_MS = 366 * 24 * 60 * 60 * 1000
/** A time within the next minute (or in the past) means "now". */
export const NOW_WINDOW_MS = 60 * 1000

export type ScheduleChoice = { ok: true; at: Date | null } | { ok: false; reason: string }

/** A requested go-live time → publish now (at: null), at a time, or why not. */
export function parseScheduleAt(raw: unknown, now: Date): ScheduleChoice {
  if (raw === undefined || raw === null || raw === '') return { ok: true, at: null }
  const at = raw instanceof Date ? raw : typeof raw === 'string' ? new Date(raw) : new Date(NaN)
  if (Number.isNaN(at.getTime())) return { ok: false, reason: 'That date and time could not be read.' }
  if (at.getTime() - now.getTime() <= NOW_WINDOW_MS) return { ok: true, at: null }
  if (at.getTime() - now.getTime() > MAX_AHEAD_MS) return { ok: false, reason: 'Schedule it within the next year.' }
  return { ok: true, at }
}

/** Due now: scheduled at or before `now`. */
export const isDue = (scheduledAt: Date | null | undefined, now: Date): boolean => !!scheduledAt && scheduledAt.getTime() <= now.getTime()

/** A real IANA time zone name ("Africa/Accra"). */
export function isTimeZone(tz: unknown): tz is string {
  if (typeof tz !== 'string' || !tz || tz.length > 64) return false
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz })
    return true
  } catch {
    return false
  }
}

/** The zone to show times in; anything unreadable falls back to UTC (and the label then says UTC). */
export const safeTimeZone = (tz: unknown): string => (isTimeZone(tz) ? tz : 'UTC')

/** "New York time", "Accra time", "UTC" — the zone in plain words. */
export function zoneName(tz: string): string {
  if (tz === 'UTC' || tz === 'Etc/UTC') return 'UTC'
  const city = tz.split('/').pop()?.replace(/_/g, ' ')
  return city ? `${city} time` : tz
}

/** "Goes live Wed 21 Oct, 9:00 Accra time" — the list badge and the approval wording. Without a zone it
 *  uses the runtime's own (the viewer's, in a browser). */
export function goesLiveLabel(at: Date, opts: { timeZone?: string; locale?: string } = {}): string {
  const timeZone = opts.timeZone === undefined ? Intl.DateTimeFormat().resolvedOptions().timeZone : safeTimeZone(opts.timeZone)
  const fmt = new Intl.DateTimeFormat(opts.locale ?? 'en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', timeZone })
  return `Goes live ${fmt.format(at)} ${zoneName(timeZone)}`
}

/** How far a zone's clock is ahead of UTC at a given moment (ms; daylight saving included). */
function zoneOffsetMs(at: Date, timeZone: string): number {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(at)
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value)
  const asUtc = Date.UTC(get('year'), get('month') - 1, get('day'), get('hour'), get('minute'), get('second'))
  return asUtc - Math.floor(at.getTime() / 1000) * 1000
}

/** "2026-10-21T09:00" on the clock of `timeZone` → the exact moment; null when either can't be read. */
export function zonedToUtc(local: string, timeZone: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(local)
  if (!m || !isTimeZone(timeZone)) return null
  const guess = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5])
  // Two passes settle the offset on either side of a clock change.
  let t = guess - zoneOffsetMs(new Date(guess), timeZone)
  t = guess - zoneOffsetMs(new Date(t), timeZone)
  return new Date(t)
}

/** A moment as an <input type="datetime-local"> value on the clock of `timeZone`. */
export function toZonedInput(d: Date, timeZone: string): string {
  const shifted = new Date(d.getTime() + zoneOffsetMs(d, safeTimeZone(timeZone)))
  return shifted.toISOString().slice(0, 16)
}

