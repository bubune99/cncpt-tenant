/**
 * HTML sanitizer that works in both SSR and client — an allow-list, not a
 * block-list. The input is tokenized and the output is REBUILT from the
 * allowed tags and attributes only (never passed through), so a payload the
 * patterns don't foresee is dropped rather than kept:
 *   - tags outside the allow-list are dropped (their text is kept), except
 *     script/style/iframe-like elements, which are dropped with their content;
 *   - attribute values are entity-decoded, then re-escaped on output;
 *   - href/src must be http(s), mailto, tel or a relative link, checked after
 *     decoding and after removing whitespace and control characters;
 *   - style keeps only allow-listed properties with plain values (no url(),
 *     expression(), backslash escapes or comments).
 * Asserted by sanitize-html.assert.ts.
 *
 * isomorphic-dompurify must NOT be used in server components: it requires
 * jsdom, whose dependency chain (html-encoding-sniffer -> @exodus/bytes ESM)
 * crashes the serverless runtime with ERR_REQUIRE_ESM.
 */

const BASE_ALLOWED_TAGS = [
  'b', 'i', 'u', 'em', 'strong', 's', 'del', 'a', 'br', 'span',
  'ul', 'ol', 'li', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'blockquote', 'code', 'pre', 'sub', 'sup', 'mark',
] as const;

// Rich-text documents (blog posts) additionally embed media and tables.
const RICH_TEXT_TAGS = [
  ...BASE_ALLOWED_TAGS,
  'img', 'figure', 'figcaption', 'hr', 'div',
  'table', 'thead', 'tbody', 'tr', 'th', 'td',
] as const;

const BASE_ALLOWED_ATTRS = ['href', 'target', 'rel', 'class', 'style'] as const;
const RICH_TEXT_ATTRS = [...BASE_ALLOWED_ATTRS, 'src', 'alt', 'title', 'width', 'height'] as const;

/** Elements whose content is code or foreign markup: dropped whole. */
const DROP_WITH_CONTENT = new Set(['script', 'style', 'iframe', 'object', 'embed', 'form', 'textarea', 'select', 'template', 'noscript', 'svg', 'math', 'noembed', 'noframes', 'xmp', 'title'])
const VOID = new Set(['br', 'hr', 'img', 'meta', 'col'])

/** Style properties text can carry; values are plain words, numbers, colours. */
const STYLE_PROPS = new Set([
  'color', 'background-color', 'text-align', 'font-weight', 'font-style', 'font-size', 'font-family', 'line-height',
  'text-decoration', 'text-transform', 'letter-spacing', 'white-space', 'vertical-align',
  'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
  'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
  'width', 'height', 'max-width', 'min-width', 'border', 'border-radius', 'display',
])

const NAMED: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: '\u00a0', colon: ':', tab: '\t', newline: '\n', lpar: '(', rpar: ')', sol: '/', bsol: '\\' }

/** Decode HTML entities (named, decimal, hex — with or without the trailing ";"). */
export function decodeEntities(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);?/gi, (m, e: string) => {
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)
      return Number.isFinite(code) && code > 0 && code < 0x110000 ? String.fromCodePoint(code) : ''
    }
    return NAMED[e.toLowerCase()] ?? m
  })
}

const escapeAttr = (s: string) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

/**
 * A link or image address that can't run code: http(s), mailto, tel, or a
 * relative path/anchor. Checked after decoding and with whitespace and
 * control characters removed (browsers ignore them inside the scheme).
 */
export function safeUrl(raw: string): string | null {
  const decoded = decodeEntities(raw).trim()
  const squashed = decoded.replace(/[\u0000-\u0020\u007f-\u009f]+/g, '').toLowerCase()
  if (!squashed) return null
  const scheme = /^([a-z][a-z0-9+.-]*):/.exec(squashed)?.[1]
  if (scheme) return ['http', 'https', 'mailto', 'tel'].includes(scheme) ? decoded : null
  // No scheme: relative ("/x", "#y", "?z", "page.html", or "//host/x", which is http(s)).
  return decoded
}

/** Keep only allow-listed declarations with plain values. */
export function safeStyle(raw: string): string {
  const decoded = decodeEntities(raw)
  if (/[\\<>]|\/\*|url\s*\(|expression\s*\(|javascript:|@import|behavior\s*:|-moz-binding/i.test(decoded)) {
    // One poisoned declaration discards the whole attribute: there is no safe partial parse of a hostile style.
    return ''
  }
  return decoded
    .split(';')
    .map((d) => d.trim())
    .filter(Boolean)
    .map((d) => {
      const i = d.indexOf(':')
      if (i < 1) return null
      const prop = d.slice(0, i).trim().toLowerCase()
      const value = d.slice(i + 1).trim()
      if (!STYLE_PROPS.has(prop) || !value || !/^[#\w\s.,%()'"+-]+$/.test(value)) return null
      return `${prop}: ${value}`
    })
    .filter((d): d is string => !!d)
    .join('; ')
}

/** CSS / inline style that can't run code or load anything but http(s). */
const CSS_POISON = /<|\\|expression\s*\(|javascript:|vbscript:|behavior\s*:|-moz-binding|@import|\/\*/i
const NON_HTTP_URL = /url\s*\(\s*(?!['"]?https?:\/\/)/i

/** An email's inline style: any property (mso-* included), plain values, url() only to http(s). */
export function safeEmailStyle(raw: string): string {
  const decoded = decodeEntities(raw)
  if (CSS_POISON.test(decoded) || /[{}>]/.test(decoded) || NON_HTTP_URL.test(decoded)) return ''
  return decoded
    .split(';')
    .map((d) => {
      const i = d.indexOf(':')
      if (i < 1) return null
      const prop = d.slice(0, i).trim().toLowerCase()
      const value = d.slice(i + 1).trim()
      return /^-?[a-z][a-z-]*$/.test(prop) && value ? `${prop}:${value}` : null
    })
    .filter((d): d is string => !!d)
    .join(';')
}

/** An email's <style> block (media queries for phones): kept only when it can't run code or close the element. */
export function safeEmailCss(css: string): string | null {
  return CSS_POISON.test(css) || NON_HTTP_URL.test(css) ? null : css
}

const ATTR_RE = /([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g

function cleanAttrs(tag: string, raw: string, allowed: Set<string>, email = false): string {
  const out: string[] = []
  let target: string | null = null
  for (const m of raw.matchAll(ATTR_RE)) {
    const name = m[1].toLowerCase()
    const known = allowed.has(name) || (email && /^data-[a-z0-9-]+$/.test(name))
    if (!known || out.some((a) => a.startsWith(`${name}=`))) continue
    const value = m[2] ?? m[3] ?? m[4] ?? ''
    let v: string | null
    switch (name) {
      case 'href':
      case 'src':
        v = safeUrl(value)
        break
      case 'style':
        v = (email ? safeEmailStyle(value) : safeStyle(value)) || null
        break
      case 'content':
        // A meta's content never carries a redirect target.
        v = tag === 'meta' && /url\s*=/i.test(decodeEntities(value)) ? null : decodeEntities(value)
        break
      case 'http-equiv':
        // Only the content type — never refresh (a redirect) or set-cookie.
        v = /^content-type$/i.test(value.trim()) ? value.trim() : null
        break
      case 'target':
        v = /^_(blank|self)$/i.test(value.trim()) ? value.trim().toLowerCase() : null
        if (v) target = v
        break
      case 'rel':
        v = null // set below for target=_blank; never taken from the input
        break
      case 'width':
      case 'height':
        v = /^\d{1,4}(%|px)?$/.test(value.trim()) ? value.trim() : null
        break
      case 'class':
        v = /^[\w\s:/.[\]%#-]*$/.test(decodeEntities(value)) ? decodeEntities(value).trim() : null
        break
      default:
        v = decodeEntities(value)
    }
    if (v != null && v !== '') out.push(`${name}="${escapeAttr(v)}"`)
  }
  if (tag === 'a' && target === '_blank') out.push('rel="noopener noreferrer"')
  return out.length ? ` ${out.join(' ')}` : ''
}

function sanitizeWith(html: string, allowedTags: Set<string>, allowedAttrs: Set<string>, email = false): string {
  let out = ''
  let i = 0
  const n = html.length
  while (i < n) {
    const lt = html.indexOf('<', i)
    if (lt === -1) {
      out += html.slice(i).replace(/>/g, '&gt;')
      break
    }
    out += html.slice(i, lt).replace(/>/g, '&gt;')
    // Comments, doctypes, CDATA, processing instructions: dropped.
    if (html.startsWith('<!--', lt)) {
      const end = html.indexOf('-->', lt + 4)
      // An email keeps Outlook's conditional comments (button padding), their inside sanitized the same way.
      const mso = email && end !== -1 ? /^<!--\[if ([^\]<>]*mso[^\]<>]*)\]>([\s\S]*)<!\[endif\]$/i.exec(html.slice(lt, end)) : null
      if (mso) out += `<!--[if ${mso[1]}]>${sanitizeWith(mso[2], allowedTags, allowedAttrs, true)}<![endif]-->`
      i = end === -1 ? n : end + 3
      continue
    }
    if (html[lt + 1] === '!' || html[lt + 1] === '?') {
      const end = html.indexOf('>', lt)
      const decl = end === -1 ? '' : html.slice(lt, end + 1)
      // An email keeps its DOCTYPE (it decides how clients lay it out).
      if (email && /^<!DOCTYPE html[^<>]*>$/i.test(decl)) out += decl
      i = end === -1 ? n : end + 1
      continue
    }
    const m = /^<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/.exec(html.slice(lt))
    if (!m) {
      // A "<" that doesn't open a tag is text.
      out += '&lt;'
      i = lt + 1
      continue
    }
    const closing = m[1] === '/'
    const tag = m[2].toLowerCase()
    i = lt + m[0].length
    if (email && tag === 'style') {
      // An email's own <style> (phone layout) is kept when its CSS is clean; otherwise dropped whole.
      if (!closing) {
        const close = /<\/style\s*>/i.exec(html.slice(i))
        const css = close ? html.slice(i, i + close.index) : ''
        const ok = close ? safeEmailCss(css) : null
        if (ok != null) out += `<style>${ok}</style>`
        i = close ? i + close.index + close[0].length : n
      }
      continue
    }
    if (DROP_WITH_CONTENT.has(tag)) {
      if (!closing) {
        const close = new RegExp(`</${tag}\\s*>`, 'i').exec(html.slice(i))
        i = close ? i + close.index + close[0].length : n
      }
      continue
    }
    if (!allowedTags.has(tag)) continue
    if (closing) {
      if (!VOID.has(tag)) out += `</${tag}>`
      continue
    }
    out += `<${tag}${cleanAttrs(tag, m[3], allowedAttrs, email)}>`
  }
  return out
}

const baseTags = new Set<string>(BASE_ALLOWED_TAGS);
const baseAttrs = new Set<string>(BASE_ALLOWED_ATTRS);
const richTags = new Set<string>(RICH_TEXT_TAGS);
const richAttrs = new Set<string>(RICH_TEXT_ATTRS);

/** Sanitize inline text content (block editor textContent fields). */
export function sanitizeHtml(html: string): string {
  return sanitizeWith(html, baseTags, baseAttrs);
}

/** Sanitize rich-text documents (blog post contentHtml): also allows images and tables. */
export function sanitizeRichHtml(html: string): string {
  return sanitizeWith(html, richTags, richAttrs);
}

// Whole email documents (campaigns, templates): layout tables, inline styles,
// the phone-layout <style> block and the DOCTYPE survive; script, event
// handlers, frames, forms and non-http(s) URLs don't.
const EMAIL_TAGS = new Set<string>([
  'html', 'head', 'body', 'meta', 'style', 'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'caption', 'colgroup', 'col',
  'div', 'span', 'p', 'a', 'img', 'br', 'hr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'b', 'em', 'i', 'u', 's', 'strike',
  'sub', 'sup', 'center', 'font', 'blockquote', 'ul', 'ol', 'li', 'pre', 'code', 'small', 'big', 'section', 'header', 'footer',
])
const EMAIL_ATTRS = new Set<string>([
  'align', 'alt', 'border', 'cellpadding', 'cellspacing', 'charset', 'class', 'content', 'dir', 'height', 'href', 'http-equiv', 'lang',
  'name', 'role', 'src', 'style', 'target', 'width', 'bgcolor', 'valign', 'color', 'face', 'size', 'id', 'title', 'colspan', 'rowspan',
])

/** Sanitize a whole email (campaign / template HTML) — keeps its layout. */
export function sanitizeEmailDocument(html: string): string {
  return sanitizeWith(html, EMAIL_TAGS, EMAIL_ATTRS, true)
}
