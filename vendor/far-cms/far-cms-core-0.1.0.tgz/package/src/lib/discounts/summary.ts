/**
 * Where a discount code stands, and the figures across every code. Pure; checked by
 * summary.assert.ts. The admin list used to count only the page of 20 it had loaded (and
 * only the filtered ones), so its totals were wrong once there were more codes (2026-11-22).
 */

export type DiscountStatus = 'active' | 'scheduled' | 'expired' | 'disabled' | 'depleted'

export interface DiscountFigures {
  enabled: boolean
  startsAt: Date
  expiresAt: Date | null
  usageLimit: number | null
  usageCount: number
  revenue: number
  stripePromotionCodeId: string | null
}

export interface DiscountSummary {
  total: number
  active: number
  /** Times redeemed, across every code. */
  usage: number
  /** Customer savings in cents, across every code. */
  revenue: number
  /** Codes with a Stripe promotion code. */
  synced: number
}

export function discountStatus(
  d: Pick<DiscountFigures, 'enabled' | 'startsAt' | 'expiresAt' | 'usageLimit' | 'usageCount'>,
  now: Date,
): DiscountStatus {
  if (!d.enabled) return 'disabled'
  if (d.usageLimit !== null && d.usageCount >= d.usageLimit) return 'depleted'
  if (d.startsAt > now) return 'scheduled'
  if (d.expiresAt && d.expiresAt < now) return 'expired'
  return 'active'
}

export function summarizeDiscounts(rows: readonly DiscountFigures[], now: Date): DiscountSummary {
  return rows.reduce<DiscountSummary>(
    (s, d) => ({
      total: s.total + 1,
      active: s.active + (discountStatus(d, now) === 'active' ? 1 : 0),
      usage: s.usage + d.usageCount,
      revenue: s.revenue + d.revenue,
      synced: s.synced + (d.stripePromotionCodeId ? 1 : 0),
    }),
    { total: 0, active: 0, usage: 0, revenue: 0, synced: 0 },
  )
}
