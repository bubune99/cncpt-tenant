/**
 * Checks for the discount status rule and the whole-catalog summary.
 * Run: node_modules/.bin/tsx src/lib/discounts/summary.assert.ts
 */
import assert from 'node:assert/strict'
import { discountStatus, summarizeDiscounts, type DiscountFigures } from './summary'

const now = new Date('2026-11-22T12:00:00Z')
const base = { enabled: true, startsAt: new Date('2026-01-01'), expiresAt: null, usageLimit: null, usageCount: 0, revenue: 0, stripePromotionCodeId: null }
const row = (o: Partial<DiscountFigures>): DiscountFigures => ({ ...base, ...o })

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; void name }

check('disabled wins', () => assert.equal(discountStatus(row({ enabled: false, usageLimit: 1, usageCount: 5 }), now), 'disabled'))
check('used up', () => assert.equal(discountStatus(row({ usageLimit: 3, usageCount: 3 }), now), 'depleted'))
check('not started', () => assert.equal(discountStatus(row({ startsAt: new Date('2027-01-01') }), now), 'scheduled'))
check('past end', () => assert.equal(discountStatus(row({ expiresAt: new Date('2026-11-01') }), now), 'expired'))
check('running', () => assert.equal(discountStatus(row({ expiresAt: new Date('2026-12-31') }), now), 'active'))

check('empty catalog is all zeros', () => assert.deepEqual(summarizeDiscounts([], now), { total: 0, active: 0, usage: 0, revenue: 0, synced: 0 }))

// 25 codes: more than one page of 20, so a page-only count would say 20.
const many = Array.from({ length: 25 }, (_, i) => row({ usageCount: 2, revenue: 100, enabled: i !== 0, stripePromotionCodeId: i < 5 ? `promo_${i}` : null }))
check('counts the whole catalog, not one page', () => {
  const s = summarizeDiscounts(many, now)
  assert.equal(s.total, 25)
  assert.equal(s.active, 24)
  assert.equal(s.usage, 50)
  assert.equal(s.revenue, 2500)
  assert.equal(s.synced, 5)
})

console.log(`${n} checks passed`)
