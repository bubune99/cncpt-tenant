/**
 * Scheduled work without polling (owner 2026-10-23: "we use webhooks when
 * needed and mitigate polling if not required").
 *
 * When something is scheduled — a page, blog post or initiative going live, an
 * email campaign starting — ONE Vercel Queues message is published to arrive at
 * the due time. The consumer (api/queues/scheduled) re-reads the database and
 * only acts if the item is still scheduled for exactly that time. A daily sweep
 * cron (api/cron/scheduled-sweep) catches anything a lost message missed.
 *
 * Queues limits (docs 2026-10): delay ≤ 7 days and ≤ the message's retention;
 * retention 60 s – 7 days; idempotency keys dedupe for min(retention, 24 h).
 * Further-out times chain: deliver as late as allowed, the consumer sends the
 * next hop.
 *
 * Pure: no Prisma, no Next, no network. `armJob` takes `send` injected.
 * Asserted in schedule-plan.assert.ts.
 */

export const SCHEDULED_TOPIC = 'scheduled-work'

export const MAX_RETENTION_S = 7 * 86_400
/** One hop's delay: an hour short of retention, so the message is visible before it expires. */
export const MAX_HOP_DELAY_S = MAX_RETENTION_S - 3_600
const MIN_RETENTION_S = 60
/** Retention beyond the delay: room for retries if the consumer fails. */
const RETRY_ROOM_S = 86_400
/** Arriving this early still counts as due (clock skew between Queues and our functions). */
export const DUE_TOLERANCE_MS = 2_000

export type ScheduledKind = 'page' | 'post' | 'record' | 'campaign' | 'feedback'

export interface ScheduledJob {
  v: 1
  kind: ScheduledKind
  id: string
  /** The go-live / start time this message is for (ISO); null = "run now / carry on". */
  at: string | null
}

export interface DeliveryPlan {
  delaySeconds: number
  retentionSeconds: number
  /** True when the due time is beyond one hop: the consumer will send the next hop. */
  chained: boolean
}

/** How to send a message that should arrive at `atMs` (now if in the past). */
export function planDelivery(atMs: number, nowMs: number): DeliveryPlan {
  const wait = Math.max(0, Math.ceil((atMs - nowMs) / 1000))
  const chained = wait > MAX_HOP_DELAY_S
  const delaySeconds = chained ? MAX_HOP_DELAY_S : wait
  const retentionSeconds = Math.min(MAX_RETENTION_S, Math.max(MIN_RETENTION_S, delaySeconds + RETRY_ROOM_S))
  return { delaySeconds, retentionSeconds, chained }
}

/** Hops still needed to reach `atMs` (0 = it arrives on time with this send). */
export function hopsLeft(atMs: number, nowMs: number): number {
  const wait = Math.max(0, Math.ceil((atMs - nowMs) / 1000))
  return wait <= MAX_HOP_DELAY_S ? 0 : Math.ceil(wait / MAX_HOP_DELAY_S) - 1
}

const KEY_MAX = 256

/**
 * Idempotency key. kind:id:at — a re-approve of the same time sends nothing new;
 * a reschedule has a new time, so a new key (the old message then finds the time
 * changed and does nothing). `suffix` separates follow-ups (a chain hop, the
 * next campaign batch) from the first message.
 */
export function idempotencyKey(job: Pick<ScheduledJob, 'kind' | 'id' | 'at'>, suffix?: string): string {
  const key = [job.kind, job.id, job.at ?? 'now', suffix].filter(Boolean).join(':')
  return key.length <= KEY_MAX ? key : key.slice(0, KEY_MAX)
}

/** Parse an incoming message; null when it is not one of ours. */
export function parseJob(raw: unknown): ScheduledJob | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as Record<string, unknown>
  const kinds: ScheduledKind[] = ['page', 'post', 'record', 'campaign', 'feedback']
  if (r.v !== 1 || !kinds.includes(r.kind as ScheduledKind)) return null
  if (typeof r.id !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(r.id)) return null
  if (r.at !== null && (typeof r.at !== 'string' || Number.isNaN(Date.parse(r.at)))) return null
  return { v: 1, kind: r.kind as ScheduledKind, id: r.id, at: r.at as string | null }
}

export type DeliveryDecision =
  | { action: 'skip'; reason: 'not-scheduled' | 'rescheduled' }
  | { action: 'run' }
  | { action: 'rearm'; plan: DeliveryPlan; hop: number }

/**
 * A timed message arrived. `scheduledAt` is what the database says NOW (null =
 * no longer scheduled: cancelled, published another way, deleted).
 */
export function decideDelivery(job: ScheduledJob, scheduledAt: Date | null, nowMs: number): DeliveryDecision {
  if (!scheduledAt) return { action: 'skip', reason: 'not-scheduled' }
  if (job.at !== null && scheduledAt.getTime() !== Date.parse(job.at)) return { action: 'skip', reason: 'rescheduled' }
  const atMs = scheduledAt.getTime()
  if (atMs <= nowMs + DUE_TOLERANCE_MS) return { action: 'run' }
  return { action: 'rearm', plan: planDelivery(atMs, nowMs), hop: hopsLeft(atMs, nowMs) }
}

// ---------------------------------------------------------------------------
// Campaign send: one batch per delivery, the next batch is the next message
// ---------------------------------------------------------------------------

export interface CampaignSendState {
  status: string
  audienceDone: boolean
  /** PENDING recipients due now (no retry wait). */
  pendingDue: number
  /** Earliest retry time (ms) among PENDING recipients waiting on backoff; null = none. */
  nextRetryAt: number | null
  /** Rows claimed by a worker (in flight, or a crashed worker's — released after the stale window). */
  queued: number
}

export type CampaignStep = { done: true; reason: 'not-sending' | 'nothing-left' } | { done: false; delaySeconds: number }

/**
 * After one run of a SENDING campaign: send the next batch message, and when.
 * `usedBudget` = the run went until its time budget (more work right away);
 * false = it stopped early (provider rate limit), so wait a little.
 */
export function nextCampaignStep(s: CampaignSendState, nowMs: number, opts: { usedBudget: boolean; staleClaimMs: number }): CampaignStep {
  if (s.status !== 'SENDING') return { done: true, reason: 'not-sending' }
  if (!s.audienceDone || s.pendingDue > 0) return { done: false, delaySeconds: opts.usedBudget ? 0 : 30 }
  if (s.nextRetryAt !== null) return { done: false, delaySeconds: Math.max(1, Math.ceil((s.nextRetryAt - nowMs) / 1000)) }
  // Someone else's batch in flight, or a crashed worker's: look again once a stale claim is released.
  if (s.queued > 0) return { done: false, delaySeconds: Math.ceil(opts.staleClaimMs / 1000) + 30 }
  // Nothing left: the run has finished the campaign (or failed it); the daily sweep is the backstop.
  return { done: true, reason: 'nothing-left' }
}

// ---------------------------------------------------------------------------
// Publishing a message (send injected)
// ---------------------------------------------------------------------------

export type QueueSend = (
  topic: string,
  payload: ScheduledJob,
  options: { delaySeconds: number; retentionSeconds: number; idempotencyKey: string },
) => Promise<{ messageId?: string | null } | unknown>

export type ArmResult = { ok: true; plan: DeliveryPlan; key: string } | { ok: false; error: string }

/**
 * Send the message for `job` to arrive at `atMs`. Never throws: a failed send
 * is logged by the caller and the daily sweep picks the work up.
 */
export async function armJob(send: QueueSend, job: ScheduledJob, atMs: number, nowMs: number, suffix?: string): Promise<ArmResult> {
  const plan = planDelivery(atMs, nowMs)
  const key = idempotencyKey(job, suffix)
  try {
    await send(SCHEDULED_TOPIC, job, { delaySeconds: plan.delaySeconds, retentionSeconds: plan.retentionSeconds, idempotencyKey: key })
    return { ok: true, plan, key }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? `${e.name}: ${e.message}`.slice(0, 300) : 'send failed' }
  }
}
