/**
 * Run: npx -y tsx@4.23.15 src/lib/queues/schedule-plan.assert.ts
 * Scheduled work arrives as one queued message at the due time — no polling crons (owner 2026-10-23).
 */
import assert from 'node:assert/strict'
import {
  armJob,
  decideDelivery,
  hopsLeft,
  idempotencyKey,
  MAX_HOP_DELAY_S,
  MAX_RETENTION_S,
  nextCampaignStep,
  parseJob,
  planDelivery,
  SCHEDULED_TOPIC,
  type CampaignSendState,
  type QueueSend,
  type ScheduledJob,
} from './schedule-plan'

let n = 0
const check = async (name: string, fn: () => void | Promise<void>) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }
const now = Date.parse('2026-10-23T12:00:00Z')
const MIN = 60_000
const DAY = 86_400_000
const job = (over: Partial<ScheduledJob> = {}): ScheduledJob => ({ v: 1, kind: 'page', id: 'pg_1', at: new Date(now + 10 * MIN).toISOString(), ...over })

async function main() {
  await check('10 minutes out: one message, delayed 600 s, kept a day past that for retries', () => {
    assert.deepEqual(planDelivery(now + 10 * MIN, now), { delaySeconds: 600, retentionSeconds: 600 + 86_400, chained: false })
  })

  await check('already due (or in the past): delivered now', () => {
    assert.equal(planDelivery(now, now).delaySeconds, 0)
    assert.equal(planDelivery(now - DAY, now).delaySeconds, 0)
    assert.ok(planDelivery(now - DAY, now).retentionSeconds >= 60)
  })

  await check('delay never reaches retention, retention never passes 7 days', () => {
    for (const ahead of [MIN, DAY, 6 * DAY, 6.9 * DAY, 7 * DAY, 30 * DAY, 365 * DAY]) {
      const p = planDelivery(now + ahead, now)
      assert.ok(p.retentionSeconds <= MAX_RETENTION_S, `retention ${ahead}`)
      assert.ok(p.delaySeconds < p.retentionSeconds, `visible before it expires (${ahead})`)
      assert.ok(p.delaySeconds <= MAX_HOP_DELAY_S)
    }
  })

  await check('beyond one hop: chained (delivered at the max, the consumer re-arms)', () => {
    const p = planDelivery(now + 30 * DAY, now)
    assert.equal(p.chained, true)
    assert.equal(p.delaySeconds, MAX_HOP_DELAY_S)
    assert.equal(planDelivery(now + 6 * DAY, now).chained, false)
    assert.equal(hopsLeft(now + 6 * DAY, now), 0)
    assert.equal(hopsLeft(now + 30 * DAY, now), 4, '30 days = 5 sends of < 7 days')
  })

  await check('chaining reaches the exact time: walk a 30-day schedule hop by hop', () => {
    const at = now + 30 * DAY + 123_000
    let t = now
    let sends = 0
    for (;;) {
      const d = decideDelivery(job({ at: new Date(at).toISOString() }), new Date(at), t)
      if (d.action === 'run') break
      assert.equal(d.action, 'rearm')
      if (d.action !== 'rearm') return
      sends++
      t += d.plan.delaySeconds * 1000
      assert.ok(sends < 10, 'terminates')
    }
    assert.ok(Math.abs(t - at) <= 1000, `fires on time (off by ${t - at} ms)`)
    assert.equal(sends, 5)
  })

  await check('idempotency key: kind:id:time — same approval twice = one message; a new time = a new key', () => {
    assert.equal(idempotencyKey(job()), `page:pg_1:${new Date(now + 10 * MIN).toISOString()}`)
    assert.equal(idempotencyKey(job()), idempotencyKey(job()))
    assert.notEqual(idempotencyKey(job()), idempotencyKey(job({ at: new Date(now + 11 * MIN).toISOString() })))
    assert.notEqual(idempotencyKey(job()), idempotencyKey(job({ kind: 'post' })))
    assert.notEqual(idempotencyKey(job()), idempotencyKey(job(), 'hop3'), 'a chain hop is its own message')
    assert.equal(idempotencyKey(job({ kind: 'campaign', at: null }), 'after:m1'), 'campaign:pg_1:now:after:m1')
    assert.ok(idempotencyKey(job({ id: 'x'.repeat(64) }), 'y'.repeat(400)).length <= 256)
  })

  await check('still due? the database decides, not the message', () => {
    const at = new Date(now + 10 * MIN)
    assert.deepEqual(decideDelivery(job(), null, at.getTime()), { action: 'skip', reason: 'not-scheduled' }, 'cancelled / published another way')
    assert.deepEqual(decideDelivery(job(), new Date(at.getTime() + MIN), at.getTime()), { action: 'skip', reason: 'rescheduled' }, 'the new time sent its own message')
    assert.deepEqual(decideDelivery(job(), at, at.getTime()), { action: 'run' })
    assert.deepEqual(decideDelivery(job(), at, at.getTime() - 1500), { action: 'run' }, 'a second early is on time')
    const early = decideDelivery(job(), at, at.getTime() - 5 * MIN)
    assert.equal(early.action, 'rearm', 'arrived early: wait the rest')
    if (early.action === 'rearm') assert.equal(early.plan.delaySeconds, 300)
    assert.deepEqual(decideDelivery(job({ at: null }), at, at.getTime() + MIN), { action: 'run' }, 'no time in the message = due if the database says so')
  })

  await check('parseJob accepts only our shape', () => {
    assert.deepEqual(parseJob(job()), job())
    assert.deepEqual(parseJob({ v: 1, kind: 'campaign', id: 'c1', at: null }), { v: 1, kind: 'campaign', id: 'c1', at: null })
    for (const bad of [null, 'x', {}, { ...job(), v: 2 }, { ...job(), kind: 'user' }, { ...job(), id: '../x' }, { ...job(), id: 'x'.repeat(65) }, { ...job(), at: 'soon' }, { ...job(), at: 5 }]) {
      assert.equal(parseJob(bad), null, JSON.stringify(bad))
    }
  })

  const sending = (over: Partial<CampaignSendState> = {}): CampaignSendState => ({ status: 'SENDING', audienceDone: true, pendingDue: 0, nextRetryAt: null, queued: 0, ...over })
  const opts = { usedBudget: true, staleClaimMs: 10 * MIN }
  await check('campaign: next batch right away while there is work, never once it stopped or finished', () => {
    assert.deepEqual(nextCampaignStep(sending({ pendingDue: 40 }), now, opts), { done: false, delaySeconds: 0 })
    assert.deepEqual(nextCampaignStep(sending({ audienceDone: false }), now, opts), { done: false, delaySeconds: 0 }, 'recipient list still being built')
    assert.deepEqual(nextCampaignStep(sending({ pendingDue: 40 }), now, { ...opts, usedBudget: false }), { done: false, delaySeconds: 30 }, 'rate-limited: wait, do not spin')
    for (const status of ['SENT', 'STOPPED', 'FAILED', 'CANCELLED', 'DRAFT', 'SCHEDULED']) {
      assert.deepEqual(nextCampaignStep(sending({ status, pendingDue: 40 }), now, opts), { done: true, reason: 'not-sending' }, status)
    }
    assert.deepEqual(nextCampaignStep(sending(), now, opts), { done: true, reason: 'nothing-left' })
  })

  await check('campaign: retries wait for their backoff; a stuck claim waits out the stale window', () => {
    assert.deepEqual(nextCampaignStep(sending({ nextRetryAt: now + 5 * MIN }), now, opts), { done: false, delaySeconds: 300 })
    assert.deepEqual(nextCampaignStep(sending({ nextRetryAt: now - 1 }), now, opts), { done: false, delaySeconds: 1 })
    assert.deepEqual(nextCampaignStep(sending({ queued: 3 }), now, opts), { done: false, delaySeconds: 630 })
  })

  await check('armJob sends one message with the plan and key; a failed send is reported, never thrown', async () => {
    const calls: unknown[][] = []
    const send: QueueSend = async (...a) => { calls.push(a); return { messageId: 'm1' } }
    const r = await armJob(send, job(), now + 10 * MIN, now)
    assert.equal(r.ok, true)
    assert.equal(calls.length, 1)
    assert.deepEqual(calls[0], [SCHEDULED_TOPIC, job(), { delaySeconds: 600, retentionSeconds: 87_000, idempotencyKey: idempotencyKey(job()) }])
    const failing: QueueSend = async () => { throw Object.assign(new Error('no OIDC token'), { name: 'UnauthorizedError' }) }
    assert.deepEqual(await armJob(failing, job(), now, now), { ok: false, error: 'UnauthorizedError: no OIDC token' })
  })

  console.log(`\n${n} checks passed`)
}

main().catch((e) => { console.error(e); process.exit(1) })
