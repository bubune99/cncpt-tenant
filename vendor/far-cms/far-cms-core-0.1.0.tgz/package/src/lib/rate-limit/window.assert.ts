/**
 * Assertions for session-window math and reset planning.
 * Run: npx -y tsx@4.23.15 src/lib/rate-limit/window.assert.ts
 */
import assert from 'node:assert/strict'
import {
  combineDecisions,
  currentAmount,
  decideWindow,
  formatResetText,
  releaseWindow,
  reserveWindow,
  resetAtFor,
  retryAfterSeconds,
  rollWindow,
} from './window'
import { planMatches, planReset } from './reset-plan'

let n = 0
function check(name: string, fn: () => void) {
  fn()
  n++
  console.log(`ok ${n} - ${name}`)
}

const H = 3_600_000
const T0 = Date.UTC(2026, 9, 8, 9, 0, 0) // 09:00 UTC

check('first hit opens a window at now', () => {
  assert.deepEqual(rollWindow(null, T0, 5 * H, 100), { windowStart: T0, windowMs: 5 * H, amount: 100 })
})
check('hits inside the window accumulate and keep windowStart', () => {
  const a = rollWindow(null, T0, 5 * H, 100)
  const b = rollWindow(a, T0 + 4 * H, 5 * H, 50)
  assert.deepEqual(b, { windowStart: T0, windowMs: 5 * H, amount: 150 })
})
check('window rolls over on its own at exactly windowStart + windowMs', () => {
  const a = rollWindow(null, T0, 5 * H, 100)
  const b = rollWindow(a, T0 + 5 * H, 5 * H, 7)
  assert.deepEqual(b, { windowStart: T0 + 5 * H, windowMs: 5 * H, amount: 7 })
})
check('rollover adopts the new windowMs (window length changed by env)', () => {
  const a = rollWindow(null, T0, 5 * H, 1)
  assert.equal(rollWindow(a, T0 + 6 * H, 24 * H, 1).windowMs, 24 * H)
  assert.equal(rollWindow(a, T0 + 1 * H, 24 * H, 1).windowMs, 5 * H, 'live window keeps its length')
})
check('readers see 0 after expiry, and resetAt = windowStart + windowMs', () => {
  const s = { windowStart: T0, windowMs: 5 * H, amount: 900 }
  assert.equal(currentAmount(s, T0 + 5 * H - 1), 900)
  assert.equal(currentAmount(s, T0 + 5 * H), 0)
  assert.equal(resetAtFor(s, T0 + H), T0 + 5 * H)
  assert.equal(resetAtFor(s, T0 + 6 * H), T0 + 6 * H, 'expired/absent resets now')
  assert.equal(resetAtFor(null, T0), T0)
})
check('rejects a non-positive window', () => {
  assert.throws(() => rollWindow(null, T0, 0, 1))
})
check('decideWindow: count after this request vs max', () => {
  assert.deepEqual(decideWindow(10, 10, T0 + H), { allowed: true, remaining: 0, resetAt: T0 + H })
  assert.deepEqual(decideWindow(11, 10, T0 + H), { allowed: false, remaining: 0, resetAt: T0 + H })
  assert.equal(decideWindow(NaN, 10, T0).allowed, false)
})
check('combineDecisions: durable refusal wins, memory refusal wins', () => {
  const okMem = { allowed: true, remaining: 5, resetAt: T0 + 60_000 }
  const noDur = { allowed: false, remaining: 0, resetAt: T0 + H }
  assert.equal(combineDecisions(okMem, noDur, false, T0).allowed, false)
  assert.equal(combineDecisions({ ...okMem, allowed: false }, { ...noDur, allowed: true }, false, T0).allowed, false)
})
check('combineDecisions: DB unavailable -> fail closed refuses, fail open uses memory', () => {
  const okMem = { allowed: true, remaining: 5, resetAt: T0 + 60_000 }
  const closed = combineDecisions(okMem, 'unavailable', true, T0)
  assert.equal(closed.allowed, false)
  assert.equal(closed.degraded, true)
  const open = combineDecisions(okMem, 'unavailable', false, T0)
  assert.equal(open.allowed, true)
  assert.equal(open.degraded, true)
})
check('retryAfterSeconds >= 1 and rounds up', () => {
  assert.equal(retryAfterSeconds(T0 + 1500, T0), 2)
  assert.equal(retryAfterSeconds(T0 - 5000, T0), 1)
})
check('formatResetText gives span + UTC clock time', () => {
  assert.equal(formatResetText(T0 + 3 * H + 12 * 60_000, T0), 'in 3h 12m (at 12:12 UTC)')
  assert.equal(formatResetText(T0 + 5 * H, T0), 'in 5h (at 14:00 UTC)')
  assert.equal(formatResetText(T0 + 30_000, T0), 'in 1m (at 09:00 UTC)')
})

// ---- reset scope ----
const rows: Array<[string, string]> = [
  ['tokens', 'user:u1'],
  ['tokens', 'user:u10'],
  ['tokens', 'global'],
  ['images', 'user:u1'],
  ['kofi-message', 'user:u1:msg:abc'],
  ['requests', 'kofi:user:u1'],
  ['requests', 'kofi:user:u10'],
  ['requests', 'cart:1.2.3.4'],
]
const select = (req: Parameters<typeof planReset>[0]) => {
  const p = planReset(req)
  assert.ok(p.ok, 'plan should be valid')
  return rows.filter(([k, id]) => planMatches(p.plan, k, id)).map(([k, id]) => `${k}|${id}`)
}
check("reset scope 'user' hits exactly that user's rows of every kind", () => {
  assert.deepEqual(select({ scope: 'user', identity: 'u1' }), [
    'tokens|user:u1',
    'images|user:u1',
    'kofi-message|user:u1:msg:abc',
    'requests|kofi:user:u1',
  ])
})
check("reset scope 'user' + kind narrows to that kind; never touches u10", () => {
  assert.deepEqual(select({ scope: 'user', identity: 'u1', kind: 'tokens' }), ['tokens|user:u1'])
})
check("reset scope 'global' hits only the global ceiling", () => {
  assert.deepEqual(select({ scope: 'global' }), ['tokens|global'])
})
check("reset scope 'all' hits everything (or one kind)", () => {
  assert.equal(select({ scope: 'all' }).length, rows.length)
  assert.deepEqual(select({ scope: 'all', kind: 'images' }), ['images|user:u1'])
})
check('reset rejects bad input (no identity, wildcard identity, unknown kind/scope)', () => {
  assert.equal(planReset({ scope: 'user' }).ok, false)
  assert.equal(planReset({ scope: 'user', identity: '%' }).ok, false)
  assert.equal(planReset({ scope: 'user', identity: 'a b' }).ok, false)
  assert.equal(planReset({ scope: 'all', kind: 'bogus' as never }).ok, false)
  assert.equal(planReset({ scope: 'nope' as never }).ok, false)
})
check('underscore in a user id is escaped (no single-char wildcard)', () => {
  const p = planReset({ scope: 'user', identity: 'a_b' })
  assert.ok(p.ok)
  assert.equal(planMatches(p.plan, 'requests', 'kofi:user:a_b'), true)
  assert.equal(planMatches(p.plan, 'requests', 'kofi:user:aXb'), false)
})

check('reserve: admits up to the limit exactly, refuses one past it', () => {
  const a = reserveWindow(null, T0, 5 * H, 30_000, 33_000)
  assert.deepEqual(a, { windowStart: T0, windowMs: 5 * H, amount: 30_000 })
  assert.deepEqual(reserveWindow(a, T0 + 1, 5 * H, 3_000, 33_000), { windowStart: T0, windowMs: 5 * H, amount: 33_000 })
  assert.equal(reserveWindow(a, T0 + 1, 5 * H, 3_001, 33_000), null)
})
check('reserve: an expired window counts from 0 and rolls over', () => {
  const a = { windowStart: T0, windowMs: 5 * H, amount: 33_000 }
  assert.equal(reserveWindow(a, T0 + 4 * H, 5 * H, 1, 33_000), null)
  assert.deepEqual(reserveWindow(a, T0 + 5 * H, 5 * H, 10, 33_000), { windowStart: T0 + 5 * H, windowMs: 5 * H, amount: 10 })
})
check('reserve: a single request larger than the limit is refused even on an empty window', () => {
  assert.equal(reserveWindow(null, T0, 5 * H, 40_000, 33_000), null)
})
check('release: gives back to the same window only, never below 0', () => {
  const a = { windowStart: T0, windowMs: 5 * H, amount: 10_000 }
  assert.deepEqual(releaseWindow(a, T0, 4_000), { windowStart: T0, windowMs: 5 * H, amount: 6_000 })
  assert.deepEqual(releaseWindow(a, T0, 50_000), { windowStart: T0, windowMs: 5 * H, amount: 0 })
  assert.equal(releaseWindow(a, T0 + 5 * H, 4_000), null) // window rolled over since the reservation
  assert.equal(releaseWindow(null, T0, 4_000), null) // row deleted (admin reset)
})

console.log(`\n${n} checks passed`)
