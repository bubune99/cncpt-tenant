/**
 * Which counter rows a reset touches. Pure — turns the admin's request into
 * a validated filter; store.ts executes it. Asserted by window.assert.ts.
 *
 * Counter identities follow one convention so a user's rows can be found:
 *   'global'                       site-wide AI ceiling
 *   'user:<id>'                    a user's tokens / images / v0 runs
 *   'user:<id>:msg:<messageId>'    a Kofi per-message budget
 *   '<prefix>:user:<id>'           a per-user request limiter (e.g. kofi:user:<id>)
 *   '<prefix>:<ip>'                a per-IP request limiter
 */

export const COUNTER_KINDS = ['tokens', 'images', 'v0-runs', 'requests', 'kofi-message'] as const
export type CounterKind = (typeof COUNTER_KINDS)[number]

export interface ResetRequest {
  scope?: 'user' | 'global' | 'all'
  /** Required for scope 'user': the local user id. */
  identity?: string
  /** Limit the reset to one kind of counter; omitted = every kind. */
  kind?: CounterKind
}

export interface ResetPlan {
  /** null = every kind */
  kinds: CounterKind[] | null
  /** Rows match when identity equals one of these… */
  exact: string[]
  /** …or is LIKE one of these (already escaped). Empty exact+likes = all rows. */
  likes: string[]
  description: string
}

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/

export function userIdentity(userId: string): string {
  return `user:${userId}`
}

export function planReset(req: ResetRequest): { ok: true; plan: ResetPlan } | { ok: false; error: string } {
  const scope = req.scope ?? 'user'
  if (req.kind !== undefined && !COUNTER_KINDS.includes(req.kind)) {
    return { ok: false, error: `Unknown kind '${String(req.kind)}'. Use one of: ${COUNTER_KINDS.join(', ')}` }
  }
  const kinds = req.kind ? [req.kind] : null
  const kindText = req.kind ?? 'all kinds'

  if (scope === 'all') {
    return { ok: true, plan: { kinds, exact: [], likes: [], description: `all counters (${kindText})` } }
  }
  if (scope === 'global') {
    return { ok: true, plan: { kinds, exact: ['global'], likes: [], description: `global counters (${kindText})` } }
  }
  if (scope !== 'user') return { ok: false, error: `Unknown scope '${String(scope)}'` }
  if (!req.identity || !ID_RE.test(req.identity)) {
    return { ok: false, error: 'scope "user" needs identity = the user id (letters, digits, _ and - only)' }
  }
  // ID_RE excludes % and _ is escaped, so the LIKE patterns cannot widen.
  const id = req.identity
  const esc = id.replace(/_/g, '\\_')
  return {
    ok: true,
    plan: {
      kinds,
      exact: [userIdentity(id)],
      likes: [`user:${esc}:%`, `%:user:${esc}`],
      description: `user ${id} (${kindText})`,
    },
  }
}

/** In-memory mirror of the SQL filter — used by the harness and for tests. */
export function planMatches(plan: ResetPlan, kind: string, identity: string): boolean {
  if (plan.kinds && !plan.kinds.includes(kind as CounterKind)) return false
  if (plan.exact.length === 0 && plan.likes.length === 0) return true
  if (plan.exact.includes(identity)) return true
  return plan.likes.some((pattern) => likeToRegExp(pattern).test(identity))
}

function likeToRegExp(pattern: string): RegExp {
  let re = ''
  for (let i = 0; i < pattern.length; i++) {
    const c = pattern[i]
    if (c === '\\' && i + 1 < pattern.length) {
      re += pattern[++i].replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    } else if (c === '%') re += '.*'
    else if (c === '_') re += '.'
    else re += c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  }
  return new RegExp(`^${re}$`)
}
