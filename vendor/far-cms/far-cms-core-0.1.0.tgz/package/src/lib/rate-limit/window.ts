/**
 * Session-window math shared by the durable rate limiter and AI spend
 * counters. Pure — no I/O, `now` is always injected — so it is asserted
 * directly by window.assert.ts.
 *
 * A counter row carries its own `windowStart` and `windowMs`. The window
 * opens on the first hit and lasts `windowMs`; the first hit at or after
 * `windowStart + windowMs` starts a fresh window at that moment (a
 * Claude-style session window). `rollWindow` is the exact mirror of the
 * upsert in store.ts, so the SQL and this function must change together.
 */

export interface CounterState {
  windowStart: number
  windowMs: number
  amount: number
}

export interface WindowDecision {
  allowed: boolean
  /** Units left in this window after this one (0 when refused). */
  remaining: number
  /** Epoch ms at which the window resets. */
  resetAt: number
}

/** True when the window that started at `windowStart` has ended by `nowMs`. */
export function isExpired(state: Pick<CounterState, 'windowStart' | 'windowMs'>, nowMs: number): boolean {
  return state.windowStart + state.windowMs <= nowMs
}

/** Mirror of the store's atomic upsert: add `add` units at `nowMs`. */
export function rollWindow(
  prev: CounterState | null,
  nowMs: number,
  windowMs: number,
  add: number,
): CounterState {
  if (!Number.isFinite(windowMs) || windowMs <= 0) {
    throw new Error(`windowMs must be a positive number, got ${windowMs}`)
  }
  if (!prev || isExpired(prev, nowMs)) {
    return { windowStart: nowMs, windowMs, amount: add }
  }
  return { ...prev, amount: prev.amount + add }
}

/**
 * Mirror of the store's atomic guarded reserve: add `add` units at `nowMs`
 * ONLY if the window's amount afterwards stays within `limit` (an expired
 * window counts from 0). Returns the new state, or null when refused.
 */
export function reserveWindow(
  prev: CounterState | null,
  nowMs: number,
  windowMs: number,
  add: number,
  limit: number,
): CounterState | null {
  if (currentAmount(prev, nowMs) + add > limit) return null
  return rollWindow(prev, nowMs, windowMs, add)
}

/**
 * Mirror of the store's release: give back up to `amount` units, but only to
 * the window the reservation was taken in (`windowStart`) — once a window has
 * rolled over its reservations went with it. Never below 0. Returns the new
 * state, or null when there is nothing to release from.
 */
export function releaseWindow(prev: CounterState | null, windowStart: number, amount: number): CounterState | null {
  if (!prev || prev.windowStart !== windowStart) return null
  return { ...prev, amount: Math.max(0, prev.amount - amount) }
}

/** Current amount as a reader sees it: an expired window reads as 0. */
export function currentAmount(state: CounterState | null, nowMs: number): number {
  return !state || isExpired(state, nowMs) ? 0 : state.amount
}

/** When the window resets. An absent/expired window "resets" now. */
export function resetAtFor(state: CounterState | null, nowMs: number): number {
  return !state || isExpired(state, nowMs) ? nowMs : state.windowStart + state.windowMs
}

/**
 * Decide a request given the window's running count AFTER this request was
 * counted (the value an atomic `amount = amount + n RETURNING amount` gives).
 */
export function decideWindow(
  countAfter: number,
  maxRequests: number,
  resetAt: number,
): WindowDecision {
  if (!Number.isFinite(countAfter) || countAfter > maxRequests) {
    return { allowed: false, remaining: 0, resetAt }
  }
  return { allowed: true, remaining: Math.max(0, maxRequests - countAfter), resetAt }
}

/**
 * Combine the in-memory (per-instance) and durable (shared) decisions. Either
 * layer refusing refuses. If the durable layer is unavailable, `failClosed`
 * decides: refuse (AI / money paths) or fall back to the memory layer alone.
 */
export function combineDecisions(
  memory: WindowDecision,
  durable: WindowDecision | 'unavailable',
  failClosed: boolean,
  nowMs: number,
): WindowDecision & { degraded: boolean } {
  const degraded = durable === 'unavailable'
  if (!memory.allowed) return { ...memory, degraded }
  if (durable === 'unavailable') {
    return failClosed
      ? { allowed: false, remaining: 0, resetAt: nowMs + 30_000, degraded }
      : { ...memory, degraded }
  }
  if (!durable.allowed) return { ...durable, degraded }
  return {
    allowed: true,
    remaining: Math.min(memory.remaining, durable.remaining),
    resetAt: Math.max(memory.resetAt, durable.resetAt),
    degraded,
  }
}

/** Seconds until `resetAt`, at least 1 (for Retry-After). */
export function retryAfterSeconds(resetAt: number, nowMs: number): number {
  return Math.max(1, Math.ceil((resetAt - nowMs) / 1000))
}

/** "in 3h 12m (at 14:05 UTC)" — human text for a reset time. */
export function formatResetText(resetAt: number, nowMs: number): string {
  const totalMin = Math.max(1, Math.ceil((resetAt - nowMs) / 60_000))
  const h = Math.floor(totalMin / 60)
  const m = totalMin % 60
  const span = h > 0 ? (m > 0 ? `${h}h ${m}m` : `${h}h`) : `${m}m`
  const d = new Date(resetAt)
  const hh = String(d.getUTCHours()).padStart(2, '0')
  const mm = String(d.getUTCMinutes()).padStart(2, '0')
  return `in ${span} (at ${hh}:${mm} UTC)`
}
