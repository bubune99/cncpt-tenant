/**
 * The dashboard's card library (owner 2026-10-19): each part of the admin offers at-a-glance cards that
 * invite you to continue there; each person picks the cards they want, their order and size. The
 * Dashboard holds the chosen ones; full charts and trends live in Analytics.
 *
 * Cards are DATA (id → section, words, who may see it, default size), so the library is a list, a
 * person's choice is a small saved record (AdeUserPref.prefs.dashboardCards), and cards people or the
 * assistant compose later (from the platform's own sources) slot into the same shape.
 *
 * Pure; asserted by cards.assert.ts.
 */

export type CardSize = 'small' | 'wide'

export type CardSectionId = 'today' | 'pages' | 'todo' | 'initiatives' | 'email' | 'forms' | 'site' | 'people' | 'shop'

export const CARD_SECTIONS: ReadonlyArray<{ id: CardSectionId; label: string }> = [
  { id: 'today', label: 'Today' },
  { id: 'pages', label: 'Pages' },
  { id: 'todo', label: 'To-do' },
  { id: 'initiatives', label: 'Initiatives' },
  { id: 'email', label: 'Email' },
  { id: 'forms', label: 'Forms & feedback' },
  { id: 'site', label: 'Site visits' },
  { id: 'people', label: 'People' },
  { id: 'shop', label: 'Shop' },
]

export interface CardDef {
  id: string
  section: CardSectionId
  title: string
  /** One line in the library: what the card tells you. */
  description: string
  /** Where "continue" goes. */
  href: string
  size: CardSize
  /** Any one of these lets a person see it (empty = every staff member). */
  permissions: readonly string[]
  /** Only while the shop is on. */
  commerce?: boolean
  /** On the dashboard until someone chooses otherwise. */
  defaultOn: boolean
}

export const CARD_LIBRARY: ReadonlyArray<CardDef> = [
  { id: 'today.needs', section: 'today', title: 'What needs you', description: 'Changes to approve and things to look at, with the actions right there.', href: '/admin/todo', size: 'wide', permissions: [], defaultOn: true },
  { id: 'today.ask', section: 'today', title: 'Ask the assistant', description: 'Type what you want done; the assistant takes it from there.', href: '/admin', size: 'wide', permissions: [], defaultOn: true },
  { id: 'today.create', section: 'today', title: 'Start something new', description: 'A new page, initiative or email in one click.', href: '/admin', size: 'small', permissions: ['pages.create', 'blog.create', 'email.create'], defaultOn: true },
  { id: 'pages.recent', section: 'pages', title: 'Recent pages', description: 'The pages edited last — jump back in.', href: '/admin/pages', size: 'wide', permissions: ['pages.view'], defaultOn: true },
  { id: 'pages.glance', section: 'pages', title: 'Pages at a glance', description: 'How many pages are live and how many are drafts.', href: '/admin/pages', size: 'small', permissions: ['pages.view'], defaultOn: false },
  { id: 'todo.glance', section: 'todo', title: 'To-do at a glance', description: 'How much is waiting for approval and how much to look at.', href: '/admin/todo', size: 'small', permissions: [], defaultOn: false },
  { id: 'initiatives.glance', section: 'initiatives', title: 'Initiatives', description: 'Active, ongoing and completed initiatives, and the latest one updated.', href: '/admin/records', size: 'small', permissions: ['blog.view'], defaultOn: true },
  { id: 'email.glance', section: 'email', title: 'Email', description: 'How the last campaign did and what is scheduled next.', href: '/admin/email-marketing', size: 'small', permissions: ['email.view'], defaultOn: true },
  { id: 'forms.glance', section: 'forms', title: 'Form submissions', description: 'Submissions across your forms.', href: '/admin/forms', size: 'small', permissions: ['forms.view'], defaultOn: false },
  { id: 'forms.feedback', section: 'forms', title: 'Feedback', description: 'New messages people sent about the site.', href: '/admin/todo', size: 'small', permissions: ['settings.general'], defaultOn: false },
  { id: 'site.week', section: 'site', title: 'This week on the site', description: 'Visitors, page views and the most-read page — the full picture in Analytics.', href: '/admin/analytics', size: 'small', permissions: ['analytics.view'], defaultOn: true },
  { id: 'people.glance', section: 'people', title: 'People', description: 'How many people can sign in to the admin.', href: '/admin/users', size: 'small', permissions: ['users.view'], defaultOn: false },
  { id: 'shop.orders', section: 'shop', title: 'Orders', description: 'Orders so far and the latest one.', href: '/admin/orders', size: 'small', permissions: ['orders.view'], commerce: true, defaultOn: true },
]

export const cardDef = (id: string): CardDef | undefined => CARD_LIBRARY.find((c) => c.id === id)

/** A person's dashboard: the cards they chose, in order, each with its size. */
export interface CardLayout {
  v: 1
  cards: ReadonlyArray<{ id: string; size: CardSize }>
}

/** What decides which cards a person may see. */
export interface CardContext {
  /** Does the person hold this permission (a super admin holds all). */
  can: (permission: string) => boolean
  commerce: boolean
}

export function cardAllowed(def: CardDef, ctx: CardContext): boolean {
  if (def.commerce && !ctx.commerce) return false
  return def.permissions.length === 0 || def.permissions.some((p) => ctx.can(p))
}

export const MAX_CARDS = 24

/** The starting dashboard: every default card in library order. */
export function defaultCardLayout(): CardLayout {
  return { v: 1, cards: CARD_LIBRARY.filter((c) => c.defaultOn).map((c) => ({ id: c.id, size: c.size })) }
}

/** A stored layout, cleaned: known cards only, once each, valid sizes. null = never chosen (use the default). */
export function normalizeCardLayout(raw: unknown): CardLayout | null {
  if (!raw || typeof raw !== 'object') return null
  const list = (raw as { cards?: unknown }).cards
  if (!Array.isArray(list)) return null
  const seen = new Set<string>()
  const cards: Array<{ id: string; size: CardSize }> = []
  for (const item of list) {
    const id = typeof item === 'string' ? item : (item as { id?: unknown })?.id
    if (typeof id !== 'string' || seen.has(id)) continue
    const def = cardDef(id)
    if (!def) continue
    seen.add(id)
    const s = typeof item === 'object' ? (item as { size?: unknown }).size : undefined
    cards.push({ id, size: s === 'small' || s === 'wide' ? s : def.size })
    if (cards.length >= MAX_CARDS) break
  }
  return { v: 1, cards }
}

/** The cards to draw for this person: their choice (or the default), only what they may see. */
export function cardsToShow(layout: CardLayout | null, ctx: CardContext): Array<{ def: CardDef; size: CardSize }> {
  return (layout ?? defaultCardLayout()).cards
    .map((c) => ({ def: cardDef(c.id), size: c.size }))
    .filter((c): c is { def: CardDef; size: CardSize } => !!c.def && cardAllowed(c.def, ctx))
}

/** The library, by section, marking what is already on the dashboard (only cards this person may see). */
export function libraryFor(layout: CardLayout | null, ctx: CardContext) {
  const on = new Set((layout ?? defaultCardLayout()).cards.map((c) => c.id))
  return CARD_SECTIONS.map((s) => ({
    section: s,
    cards: CARD_LIBRARY.filter((c) => c.section === s.id && cardAllowed(c, ctx)).map((def) => ({ def, added: on.has(def.id) })),
  })).filter((g) => g.cards.length > 0)
}

// ── changes (each returns a new layout) ──

const base = (l: CardLayout | null) => l ?? defaultCardLayout()

export function addCard(l: CardLayout | null, id: string): CardLayout {
  const cur = base(l)
  const def = cardDef(id)
  if (!def || cur.cards.some((c) => c.id === id) || cur.cards.length >= MAX_CARDS) return cur
  return { v: 1, cards: [...cur.cards, { id, size: def.size }] }
}

export function removeCard(l: CardLayout | null, id: string): CardLayout {
  const cur = base(l)
  return { v: 1, cards: cur.cards.filter((c) => c.id !== id) }
}

/** Move a card to a new position (clamped). */
export function moveCard(l: CardLayout | null, id: string, to: number): CardLayout {
  const cur = base(l)
  const from = cur.cards.findIndex((c) => c.id === id)
  if (from < 0) return cur
  const rest = cur.cards.filter((c) => c.id !== id)
  const at = Math.max(0, Math.min(to, rest.length))
  return { v: 1, cards: [...rest.slice(0, at), cur.cards[from], ...rest.slice(at)] }
}

export function resizeCard(l: CardLayout | null, id: string, size: CardSize): CardLayout {
  const cur = base(l)
  return { v: 1, cards: cur.cards.map((c) => (c.id === id ? { ...c, size } : c)) }
}
