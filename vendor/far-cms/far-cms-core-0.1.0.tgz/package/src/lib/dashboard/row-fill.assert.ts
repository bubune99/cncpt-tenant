/**
 * Dashboard rows never leave columns empty: a small card left alone at the end of a row (because a wide card
 * follows, or the list ends) stretches to fill it. Order and sizes stay the person's own.
 * Seen 2026-11-22: 'Start something new' sat alone in a 3-column row with two empty columns before Recent pages.
 * Run: node_modules/.bin/tsx src/lib/dashboard/row-fill.assert.ts
 */
import assert from 'node:assert/strict'
import { rowSpans } from './row-fill'

// The staging dashboard: What needs you (wide), Start something new, Recent pages (wide), Initiatives, Email, This week
const board = ['wide', 'small', 'wide', 'small', 'small', 'small'] as const
assert.deepEqual(rowSpans(board, 3), [3, 3, 3, 1, 1, 1], 'a lone small card before a wide one fills its row')
assert.deepEqual(rowSpans(board, 2), [2, 2, 2, 1, 1, 2], 'two columns: the last odd card fills its row too')
assert.deepEqual(rowSpans(board, 1), [1, 1, 1, 1, 1, 1], 'one column: nothing to fill')
assert.deepEqual(rowSpans(['small', 'small', 'wide'], 3), [1, 2, 3], 'two smalls before a wide: the second takes the rest')
assert.deepEqual(rowSpans(['small', 'small', 'small'], 3), [1, 1, 1], 'a full row is left alone')
assert.deepEqual(rowSpans([], 3), [], 'no cards')
console.log('row-fill: 6 checks passed')
