/**
 * How many columns each dashboard card spans so no row is left part-empty: a wide card takes the whole row;
 * a small card that ends a row early (a wide card follows, or the list ends) stretches over what is left.
 * The person's order and sizes are kept. Pure; checked by row-fill.assert.ts.
 */
import type { CardSize } from './cards'

export function rowSpans(sizes: ReadonlyArray<CardSize>, columns: number): number[] {
  const spans: number[] = []
  let used = 0
  const fillRow = () => {
    if (used > 0 && used < columns) spans[spans.length - 1] += columns - used
    used = 0
  }
  for (const size of sizes) {
    if (size === 'wide') {
      fillRow()
      spans.push(columns)
      continue
    }
    spans.push(1)
    used += 1
    if (used === columns) used = 0
  }
  fillRow()
  return spans
}
