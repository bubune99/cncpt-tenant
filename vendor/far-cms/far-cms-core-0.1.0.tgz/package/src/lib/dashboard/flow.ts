/**
 * Dashboard widgets flow into an auto-height grid (2 equal columns) instead
 * of fixed-height cells: each widget is as tall as its content, there are no
 * scrollbars inside cards, and no holes between widgets. Saved layouts keep
 * their order (top-to-bottom, left-to-right); wide widgets (w >= 7 of 12)
 * span both columns; a half-width widget left alone on its row stretches
 * across it. Pure; asserted by flow.assert.ts.
 */

export interface FlowInput {
  id: string
  x: number
  y: number
  w: number
  visible: boolean
}

export function flowWidgets<T extends FlowInput>(widgets: ReadonlyArray<T>): Array<T & { span: 1 | 2 }> {
  const ordered = widgets.filter((w) => w.visible).sort((a, b) => a.y - b.y || a.x - b.x)
  const out: Array<T & { span: 1 | 2 }> = []
  for (let i = 0; i < ordered.length; i++) {
    const w = ordered[i]
    if (w.w >= 7) {
      out.push({ ...w, span: 2 })
      continue
    }
    const next = ordered[i + 1]
    if (next && next.w < 7) {
      out.push({ ...w, span: 1 }, { ...next, span: 1 })
      i++
    } else {
      out.push({ ...w, span: 2 }) // alone on its row → no hole
    }
  }
  return out
}
