/**
 * Run: npx -y tsx@4.23.15 src/lib/dashboard/flow.assert.ts
 */
import assert from 'node:assert/strict'
import { flowWidgets } from './flow'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const w = (id: string, x: number, y: number, width: number, visible = true) => ({ id, x, y, w: width, visible })
const spans = (l: ReturnType<typeof flowWidgets>) => l.map((i) => `${i.id}:${i.span}`).join(' ')

check('keeps the saved order; wide widgets span both columns', () => {
  const l = flowWidgets([w('traffic', 0, 10, 8), w('metrics', 0, 0, 12), w('a', 0, 3, 6), w('b', 6, 3, 6)])
  assert.equal(spans(l), 'metrics:2 a:1 b:1 traffic:2')
})

check('no holes: a half widget alone on its row stretches', () => {
  // the owner's case: Quick Actions (6) + Content Stats (4) after shop widgets were hidden
  const l = flowWidgets([w('metrics', 0, 0, 12), w('actions', 0, 7, 6), w('traffic', 0, 10, 8), w('content', 8, 10, 4)])
  assert.equal(spans(l), 'metrics:2 actions:2 traffic:2 content:2')
  assert.equal(spans(flowWidgets([w('a', 0, 0, 4), w('b', 4, 0, 4), w('c', 8, 0, 4)])), 'a:1 b:1 c:2')
})

check('hidden widgets leave no gap', () => {
  assert.equal(spans(flowWidgets([w('a', 0, 0, 6), w('gone', 6, 0, 6, false), w('b', 0, 1, 6)])), 'a:1 b:1')
})

console.log(`\n${n} checks passed`)
