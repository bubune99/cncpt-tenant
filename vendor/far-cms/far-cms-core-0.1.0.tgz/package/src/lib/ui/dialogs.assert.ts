/**
 * Run: npx -y tsx@4.23.15 src/lib/ui/dialogs.assert.ts
 */
import assert from 'node:assert/strict'
import { createDialogQueue, toastParts } from './dialogs'

async function main() {
  let n = 0
  const ok = (cond: unknown, msg: string) => {
    assert.ok(cond, msg)
    n++
  }

  // No host → cancel at once, never hang, never proceed
  {
    const warned: string[] = []
    const q = createDialogQueue((m) => warned.push(m))
    ok((await q.confirm({ title: 'Delete?' })) === false, 'no host: confirm is false')
    ok((await q.prompt({ title: 'Link' })) === null, 'no host: prompt is null')
    ok(warned.length === 2, 'no host: warned')
  }

  // One at a time, oldest first; answers resolve the right promise
  {
    const q = createDialogQueue()
    const detach = q.attachHost()
    let ticks = 0
    q.subscribe(() => ticks++)
    const a = q.confirm({ title: 'Delete this tour?', body: 'This cannot be undone.', confirmLabel: 'Delete', destructive: true })
    const b = q.prompt({ title: 'Link', defaultValue: 'https://' })
    ok(q.pending() === 2 && ticks === 2, 'both queued, listeners told')
    const first = q.current()
    ok(first?.kind === 'confirm' && first.destructive && first.confirmLabel === 'Delete' && first.cancelLabel === 'Cancel', 'confirm request shape')
    q.resolve(first!.id, true)
    q.resolve(first!.id, false) // repeat ignored (Action click + close both answer)
    ok((await a) === true, 'confirm resolves true')
    const second = q.current()
    ok(second?.kind === 'prompt' && second.defaultValue === 'https://', 'then the prompt')
    q.resolve(second!.id, '/donate')
    ok((await b) === '/donate', 'prompt resolves text')
    ok(q.current() === null && q.pending() === 0, 'queue empty')
    ok(q.current() === q.current(), 'stable snapshot')

    // Host unmounting cancels what is still open
    const c = q.confirm({ title: 'Send now?' })
    const d = q.prompt({ title: 'Name' })
    detach()
    ok((await c) === false && (await d) === null, 'unmount cancels open requests')
    ok((await q.confirm({ title: 'x' })) === false, 'and later asks cancel (no host)')
  }

  // Defaults
  {
    const q = createDialogQueue()
    q.attachHost()
    void q.confirm({ title: 'Sure?' })
    const r = q.current()
    ok(r?.kind === 'confirm' && r.confirmLabel === 'OK' && r.destructive === false, 'confirm defaults')
  }

  // alert() text → toast parts
  assert.deepEqual(toastParts('Invitation URL copied to clipboard!'), { title: 'Invitation URL copied to clipboard!' })
  n++
  assert.deepEqual(toastParts('Workflow executed!\n\nSuccess: true\nDuration: 12ms\n\nResult: {}'), {
    title: 'Workflow executed!',
    description: 'Success: true\nDuration: 12ms\n\nResult: {}',
  })
  n++
  assert.deepEqual(toastParts('Execution failed: boom\n\nDetails: '), { title: 'Execution failed: boom', description: 'Details:' })
  n++
  assert.deepEqual(toastParts('Done\n\n   '), { title: 'Done' })
  n++

  console.log(`${n} assertions passed`)
}

void main().catch((e) => {
  console.error(e)
  process.exit(1)
})
