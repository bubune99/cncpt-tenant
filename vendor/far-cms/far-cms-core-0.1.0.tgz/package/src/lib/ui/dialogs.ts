/**
 * In-page confirm / prompt, in place of window.confirm / window.prompt.
 * Native dialogs block the page's JavaScript — the assistant's client tools
 * and the browser relay freeze until someone clicks — so admin code asks
 * through this queue and <DialogHost> (mounted once in the admin layout)
 * shows one request at a time.
 *
 * No host mounted → the request resolves as "cancel" at once (never hangs,
 * and never goes ahead with something the person wasn't asked about).
 * Asserted by dialogs.assert.ts.
 */

export interface ConfirmOptions {
  title: string
  body?: string
  confirmLabel?: string
  cancelLabel?: string
  /** Destructive actions keep a destructive (red) button. */
  destructive?: boolean
}

export interface PromptOptions {
  title: string
  body?: string
  /** The input's label (the question). */
  label?: string
  defaultValue?: string
  placeholder?: string
  confirmLabel?: string
  cancelLabel?: string
}

export type DialogRequest =
  | ({ id: number; kind: 'confirm' } & Required<Pick<ConfirmOptions, 'title' | 'confirmLabel' | 'cancelLabel' | 'destructive'>> & { body?: string })
  | ({ id: number; kind: 'prompt' } & Required<Pick<PromptOptions, 'title' | 'confirmLabel' | 'cancelLabel' | 'defaultValue'>> & {
      body?: string
      label?: string
      placeholder?: string
    })

export function createDialogQueue(warn: (msg: string) => void = () => {}) {
  let queue: DialogRequest[] = []
  const resolvers = new Map<number, (v: boolean | string | null) => void>()
  const listeners = new Set<() => void>()
  let hosts = 0
  let nextId = 1

  const emit = () => listeners.forEach((l) => l())

  function ask<T extends boolean | string | null>(req: DialogRequest, cancel: T): Promise<T> {
    if (hosts === 0) {
      warn(`dialogs: no <DialogHost> mounted; "${req.title}" treated as cancelled`)
      return Promise.resolve(cancel)
    }
    return new Promise<T>((resolve) => {
      resolvers.set(req.id, resolve as (v: boolean | string | null) => void)
      queue = [...queue, req]
      emit()
    })
  }

  return {
    confirm(o: ConfirmOptions): Promise<boolean> {
      return ask<boolean>(
        { id: nextId++, kind: 'confirm', title: o.title, body: o.body, confirmLabel: o.confirmLabel ?? 'OK', cancelLabel: o.cancelLabel ?? 'Cancel', destructive: o.destructive ?? false },
        false
      )
    },
    prompt(o: PromptOptions): Promise<string | null> {
      return ask<string | null>(
        {
          id: nextId++,
          kind: 'prompt',
          title: o.title,
          body: o.body,
          label: o.label,
          placeholder: o.placeholder,
          defaultValue: o.defaultValue ?? '',
          confirmLabel: o.confirmLabel ?? 'OK',
          cancelLabel: o.cancelLabel ?? 'Cancel',
        },
        null
      )
    },
    /** Answer a request (confirm: true/false; prompt: text or null). Repeat answers are ignored. */
    resolve(id: number, value: boolean | string | null) {
      const r = resolvers.get(id)
      if (!r) return
      resolvers.delete(id)
      queue = queue.filter((q) => q.id !== id)
      r(value)
      emit()
    },
    /** The request on screen (the oldest), or null. */
    current: (): DialogRequest | null => queue[0] ?? null,
    pending: () => queue.length,
    subscribe(l: () => void) {
      listeners.add(l)
      return () => {
        listeners.delete(l)
      }
    },
    /** A host calls this on mount; the returned function on unmount (cancels anything still open). */
    attachHost() {
      hosts++
      return () => {
        hosts--
        if (hosts > 0) return
        for (const q of queue) {
          const r = resolvers.get(q.id)
          resolvers.delete(q.id)
          r?.(q.kind === 'confirm' ? false : null)
        }
        queue = []
        emit()
      }
    },
  }
}

export const dialogs = createDialogQueue((m) => console.warn(m))

/** `if (!(await confirmDialog({ title, destructive: true }))) return` */
export const confirmDialog = (o: ConfirmOptions) => dialogs.confirm(o)
/** Resolves to the text entered, or null if cancelled. */
export const promptDialog = (o: PromptOptions) => dialogs.prompt(o)

/** A former alert() message as a toast: the first paragraph is the title, the rest the description. */
export function toastParts(message: string): { title: string; description?: string } {
  const text = message.trim()
  const cut = text.indexOf('\n\n')
  if (cut < 0) return { title: text }
  const description = text.slice(cut + 2).trim()
  return description ? { title: text.slice(0, cut).trim(), description } : { title: text.slice(0, cut).trim() }
}
