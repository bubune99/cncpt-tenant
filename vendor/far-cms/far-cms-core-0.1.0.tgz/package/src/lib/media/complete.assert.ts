/**
 * Run: npx -y tsx@4.23.15 src/lib/media/complete.assert.ts
 */
import assert from 'node:assert/strict'
import { completeDecision, isUniqueViolation } from './complete'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('first complete creates; a retry for the same key gets the same row', () => {
  assert.deepEqual(completeDecision(null, 'u1'), { kind: 'create' })
  assert.deepEqual(completeDecision({ id: 'm1', uploadedById: 'u1', deletedAt: null }, 'u1'), { kind: 'reuse', id: 'm1' })
})

check('another person’s key, or a removed file, is refused (never handed over, never revived)', () => {
  assert.equal(completeDecision({ id: 'm1', uploadedById: 'u2', deletedAt: null }, 'u1').kind, 'conflict')
  assert.equal(completeDecision({ id: 'm1', uploadedById: null, deletedAt: null }, 'u1').kind, 'conflict')
  assert.equal(completeDecision({ id: 'm1', uploadedById: 'u1', deletedAt: new Date() }, 'u1').kind, 'conflict')
})

check('a racing duplicate is recognised by its unique-index error', () => {
  assert.equal(isUniqueViolation({ code: 'P2002' }), true)
  assert.equal(isUniqueViolation(new Error('x')), false)
  assert.equal(isUniqueViolation(null), false)
})

console.log(`\n${n} checks passed`)
