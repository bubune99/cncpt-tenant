/**
 * Upload keys and where they live — decided by the server, never taken from
 * the client. A media row's url, bucket and provider come from the storage
 * settings that issued the key; the key itself must be one we hand out.
 * Pure; asserted by src/lib/security/media-complete.assert.ts.
 */

/** Keys we hand out live in a dated uploads/ namespace (generatePresignedUrl, MCP request_media_upload). */
export const UPLOAD_KEY_RE = /^uploads\/\d{4}-\d{2}-\d{2}\/[0-9a-f-]{36}\.[a-z0-9]{2,5}$/i

export type UploadProvider = 'S3' | 'R2' | 'LOCAL'

export interface UploadStorageSettings {
  provider?: string | null
  bucket?: string | null
  region?: string | null
  publicUrl?: string | null
}

/** The provider, bucket and public URL a key has under these storage settings (same rules as the upload URL). */
export function uploadTarget(settings: UploadStorageSettings, key: string, appUrl: string): { provider: UploadProvider; bucket: string; url: string } | { error: string } {
  const p = (settings.provider || 'local').toUpperCase()
  const provider: UploadProvider = p === 'S3' || p === 'R2' ? p : 'LOCAL'
  if (provider === 'LOCAL') return { provider, bucket: 'local', url: `${appUrl.replace(/\/$/, '')}/uploads/${key}` }
  if (!settings.bucket) return { error: 'Storage bucket is not configured.' }
  if (settings.publicUrl) return { provider, bucket: settings.bucket, url: `${settings.publicUrl.replace(/\/$/, '')}/${key}` }
  if (provider === 'R2') return { error: 'R2 public URL is not configured.' }
  return { provider, bucket: settings.bucket, url: `https://${settings.bucket}.s3.${settings.region}.amazonaws.com/${key}` }
}

const EXT_TYPES: Record<string, RegExp> = {
  jpg: /^image\/jpe?g$/, jpeg: /^image\/jpe?g$/, png: /^image\/png$/, gif: /^image\/gif$/, webp: /^image\/webp$/, avif: /^image\/avif$/,
  svg: /^image\/svg\+xml$/, mp4: /^video\/mp4$/, webm: /^(video|audio)\/webm$/, mov: /^video\/quicktime$/, mp3: /^audio\/mpeg$/,
  m4a: /^audio\/(mp4|x-m4a|aac)$/, wav: /^audio\/(wav|x-wav|wave)$/, pdf: /^application\/pdf$/,
}

/**
 * The MIME type a completed upload may be recorded with: a well-formed type
 * that, for a known media extension, matches it (".jpg" can't be recorded as
 * text/html). serverUploadFacts then re-runs the upload's own type policy
 * (validateFile), so blocked types stay blocked.
 */
export function mimeForKey(key: string, claimed: unknown): string | null {
  const ext = /\.([a-z0-9]{2,5})$/i.exec(key)?.[1]?.toLowerCase()
  if (!ext || typeof claimed !== 'string' || !/^[a-z]+\/[a-z0-9.+-]+$/i.test(claimed)) return null
  const type = claimed.toLowerCase()
  const re = EXT_TYPES[ext]
  return !re || re.test(type) ? type : null
}

/** A local storage key that can't climb out of public/uploads. */
export function isSafeLocalKey(key: string): boolean {
  return !!key && !key.startsWith('/') && !key.startsWith('\\') && !/(^|[\\/])\.\.([\\/]|$)/.test(key) && !key.includes('\0')
}
