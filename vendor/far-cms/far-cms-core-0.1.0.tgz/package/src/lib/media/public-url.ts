/**
 * Media URLs as visitors should see them. Images were uploaded while the
 * bucket was served from its r2.dev address; the same objects are now on the
 * site's media domain. Stored records keep whatever they were saved with —
 * this rewrites at render/serve time instead (owner: never edit stored
 * content to fix a design/serving issue). Pure and client-safe.
 */

/** The R2 custom domain for the project-dzidzor bucket (R2_PUBLIC_URL). */
export const MEDIA_ORIGIN = 'https://dzidzor-media.farsociety.com'

/** Old public hosts of the SAME bucket — only these are rewritten. */
export const LEGACY_MEDIA_HOSTS: readonly string[] = ['pub-89521fc08b10436cb278c7c927b1a037.r2.dev']

const MEDIA_HOST = new URL(MEDIA_ORIGIN).host

/** Rewrite a URL on a legacy bucket host to the media domain; anything else is returned unchanged. */
export function toMediaDomain(url: string): string
export function toMediaDomain(url: unknown): unknown
export function toMediaDomain(url: unknown): unknown {
  if (typeof url !== 'string' || !url) return url
  let u: URL
  try {
    u = new URL(url)
  } catch {
    return url
  }
  if (!LEGACY_MEDIA_HOSTS.includes(u.host)) return url
  return `${MEDIA_ORIGIN}${u.pathname}${u.search}${u.hash}`
}

/** True when the URL is (or will be served from) the media domain. */
export function isOnMediaDomain(url: unknown): boolean {
  const out = toMediaDomain(url)
  if (typeof out !== 'string' || !out) return false
  try {
    return new URL(out).host === MEDIA_HOST
  } catch {
    return false
  }
}

/** A copy of `data` with the listed URL fields served from the media domain. */
export function withMediaDomain<T extends Record<string, unknown>>(data: T, keys: readonly string[]): T {
  let out: T | null = null
  for (const k of keys) {
    const v = data[k]
    const next = toMediaDomain(v)
    if (next !== v) (out ??= { ...data })[k as keyof T] = next as T[keyof T]
  }
  return out ?? data
}
