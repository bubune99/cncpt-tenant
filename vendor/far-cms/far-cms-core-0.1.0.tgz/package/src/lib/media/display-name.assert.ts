/**
 * Run: npx -y tsx@4.23.15 src/lib/media/display-name.assert.ts
 */
import assert from 'node:assert/strict'
import { mediaDisplayName } from './display-name'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

check('title, then alt, then a tidy file name', () => {
  assert.equal(mediaDisplayName({ title: 'Akuse ward', filename: 'x.png' }), 'Akuse ward')
  assert.equal(mediaDisplayName({ alt: 'Nurses at the clinic', filename: 'x.png' }), 'Nurses at the clinic')
  assert.equal(mediaDisplayName({ filename: 'Homepage-Banner.png' }), 'Homepage banner')
  assert.equal(mediaDisplayName({ originalName: 'images/About-Image.jpeg' }), 'About image')
  assert.equal(mediaDisplayName({ originalName: 'images-Akuse-Hospital.jpg' }), 'Akuse hospital')
  assert.equal(mediaDisplayName({ originalName: 'IMG_2041 clinic visit.JPG', filename: 'a.jpg' }), 'Img 2041 clinic visit')
})

check('never a UUID or hash', () => {
  const name = mediaDisplayName({ filename: '3f2a9c1e-7b4d-4e2a-9f10-2c3d4e5f6a7b.png', mimeType: 'image/png', createdAt: '2026-07-23T10:00:00Z' })
  assert.doesNotMatch(name, /[0-9a-f]{8}-/)
  assert.match(name, /^Image added /)
  assert.equal(mediaDisplayName({ filename: 'cmv13e31n000106l5x0lnqvqo.webp', mimeType: 'image/webp' }), 'Untitled image')
  assert.equal(mediaDisplayName({ filename: '1721732400123-hero.jpg' }), 'Hero')
})

console.log(`\n${n} checks passed`)
