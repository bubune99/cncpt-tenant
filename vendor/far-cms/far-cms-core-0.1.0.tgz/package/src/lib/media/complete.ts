/**
 * Finishing a direct upload ('complete') is idempotent by the storage key
 * (pure; asserted by complete.assert.ts). A retry whose first reply was lost
 * gets the media row the first try made — never a second row for the same
 * object. The key is the server's own (from presign), so the only rows that
 * can match are the same upload's.
 */

export interface ExistingUpload {
  id: string
  uploadedById: string | null
  deletedAt: Date | null
}

export type CompleteDecision = { kind: 'create' } | { kind: 'reuse'; id: string } | { kind: 'conflict'; reason: string }

export function completeDecision(existing: ExistingUpload | null, uploaderId: string): CompleteDecision {
  if (!existing) return { kind: 'create' }
  // Someone else's upload: never hand their row to another person.
  if (existing.uploadedById !== uploaderId) return { kind: 'conflict', reason: 'This file was already added by someone else' }
  if (existing.deletedAt) return { kind: 'conflict', reason: 'This file was added and then removed' }
  return { kind: 'reuse', id: existing.id }
}

/** Prisma's unique-constraint error (two completes racing for one key). */
export function isUniqueViolation(e: unknown): boolean {
  return !!e && typeof e === 'object' && (e as { code?: unknown }).code === 'P2002'
}
