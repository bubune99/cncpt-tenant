/**
 * Checks for the media trash purge (owner 2026-11-22: "Empty the trash after 30 days").
 * Run: node_modules/.bin/tsx src/lib/media/trash-purge.assert.ts
 */
import assert from 'node:assert/strict'
import { TRASH_DAYS, trashCutoff, planTrashPurge, emptyTrash, type TrashedItem } from './trash-purge'

const day = 24 * 60 * 60 * 1000
const now = new Date('2026-11-22T03:30:00Z')
const item = (id: string, daysAgo: number, inUse = false): TrashedItem => ({ id, deletedAt: new Date(now.getTime() - daysAgo * day), inUse, key: `k/${id}`, bucket: 'b', provider: 'R2' })

// 1. Thirty days, counted from when it was put in the trash.
assert.equal(TRASH_DAYS, 30)
assert.equal(trashCutoff(now).toISOString(), '2026-10-23T03:30:00.000Z')

// 2. Only items in the trash longer than 30 days go; a day short stays.
{
  const p = planTrashPurge([item('old', 31), item('edge', 30), item('young', 29)], now)
  assert.deepEqual(p.purge.map((i) => i.id), ['old', 'edge'])
  assert.deepEqual(p.keptInUse, [])
}

// 3. Something in the trash that a page, product or post still shows is kept and reported, never removed.
{
  const p = planTrashPurge([item('used', 60, true), item('free', 60)], now)
  assert.deepEqual(p.purge.map((i) => i.id), ['free'])
  assert.deepEqual(p.keptInUse, ['used'])
}

// 4. The file is removed before the record; a file that fails to go keeps its record (so it can be tried again),
//    and one failure does not stop the rest.
async function run() {
  const calls: string[] = []
  const report = await emptyTrash(now, {
    findTrashedBefore: async (cutoff) => {
      assert.equal(cutoff.toISOString(), trashCutoff(now).toISOString())
      return [item('a', 40), item('b', 40), item('c', 40, true), { ...item('d', 40), key: null }]
    },
    removeFile: async (i) => { calls.push('file:' + i.id); if (i.id === 'b') throw new Error('storage down') },
    removeRecord: async (id) => { calls.push('record:' + id) },
  })
  assert.deepEqual(calls, ['file:a', 'record:a', 'file:b', 'record:d'])
  assert.deepEqual(report, { removed: ['a', 'd'], keptInUse: ['c'], failed: ['b'] })
}

run().then(() => console.log('trash-purge: 4 checks passed')).catch((e) => { console.error(e); process.exit(1) })
