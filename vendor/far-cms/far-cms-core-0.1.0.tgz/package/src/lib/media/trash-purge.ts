/**
 * The media trash empties itself: anything in the trash longer than TRASH_DAYS has its stored file
 * and its record removed. Owner, 2026-11-22: "Empty the trash after 30 days".
 *
 * Something in the trash that a page, product or post still shows is kept and reported, never removed.
 * The file goes first; if it cannot be removed the record stays, so the next night tries again and no
 * file is left in storage without a record. Dependencies are passed in (checked by trash-purge.assert.ts).
 */

export const TRASH_DAYS = 30

/** How many trashed items one night handles at most (the rest wait for the next night). */
export const TRASH_BATCH = 200

export interface TrashedItem {
  readonly id: string
  readonly deletedAt: Date
  /** A page, product, post or other record still points at it. */
  readonly inUse: boolean
  readonly key: string | null
  readonly bucket: string | null
  readonly provider: string | null
}

export interface TrashPlan {
  readonly purge: readonly TrashedItem[]
  readonly keptInUse: readonly string[]
}

export interface TrashReport {
  readonly removed: string[]
  readonly keptInUse: string[]
  readonly failed: string[]
}

export interface TrashDeps {
  findTrashedBefore(cutoff: Date, limit: number): Promise<readonly TrashedItem[]>
  removeFile(item: TrashedItem): Promise<void>
  removeRecord(id: string): Promise<void>
}

/** Items put in the trash at or before this moment are due. */
export function trashCutoff(now: Date, days: number = TRASH_DAYS): Date {
  return new Date(now.getTime() - days * 24 * 60 * 60 * 1000)
}

export function planTrashPurge(items: readonly TrashedItem[], now: Date, days: number = TRASH_DAYS): TrashPlan {
  const cutoff = trashCutoff(now, days).getTime()
  const due = items.filter((i) => i.deletedAt.getTime() <= cutoff)
  return {
    purge: due.filter((i) => !i.inUse),
    keptInUse: due.filter((i) => i.inUse).map((i) => i.id),
  }
}

export async function emptyTrash(now: Date, deps: TrashDeps, days: number = TRASH_DAYS): Promise<TrashReport> {
  const plan = planTrashPurge(await deps.findTrashedBefore(trashCutoff(now, days), TRASH_BATCH), now, days)
  const removed: string[] = []
  const failed: string[] = []
  for (const item of plan.purge) {
    try {
      if (item.key && item.bucket && item.provider) await deps.removeFile(item)
      await deps.removeRecord(item.id)
      removed.push(item.id)
    } catch (error) {
      console.error('[trash-purge] could not remove', item.id, error instanceof Error ? error.message : error)
      failed.push(item.id)
    }
  }
  return { removed, keptInUse: [...plan.keptInUse], failed }
}
