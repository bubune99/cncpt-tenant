/**
 * Run: npx -y tsx@4.23.15 src/lib/media/public-url.assert.ts
 */
import assert from 'node:assert/strict'
import { isOnMediaDomain, MEDIA_ORIGIN, toMediaDomain, withMediaDomain } from './public-url'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const OLD = 'https://pub-89521fc08b10436cb278c7c927b1a037.r2.dev'

check('legacy bucket URLs move to the media domain, path kept', () => {
  assert.equal(toMediaDomain(`${OLD}/images/Akuse%20Hospital.jpg?v=2#x`), `${MEDIA_ORIGIN}/images/Akuse%20Hospital.jpg?v=2#x`)
})

check('everything else is untouched', () => {
  for (const u of ['https://pub-other.r2.dev/a.jpg', `${MEDIA_ORIGIN}/a.jpg`, '/uploads/a.jpg', 'not a url', '', 'https://images.unsplash.com/x']) assert.equal(toMediaDomain(u), u)
  assert.equal(toMediaDomain(null), null)
  assert.equal(toMediaDomain(3), 3)
})

check('isOnMediaDomain: served-from check', () => {
  assert.ok(isOnMediaDomain(`${OLD}/a.jpg`))
  assert.ok(isOnMediaDomain(`${MEDIA_ORIGIN}/a.jpg`))
  assert.ok(!isOnMediaDomain('https://example.com/a.jpg'))
  assert.ok(!isOnMediaDomain(''))
  assert.ok(!isOnMediaDomain(undefined))
})

check('withMediaDomain copies only when something changes (never mutates)', () => {
  const data = { heroImageUrl: `${OLD}/a.jpg`, name: 'x' }
  const out = withMediaDomain(data, ['heroImageUrl', 'missing'])
  assert.notEqual(out, data)
  assert.equal(data.heroImageUrl, `${OLD}/a.jpg`)
  assert.equal(out.heroImageUrl, `${MEDIA_ORIGIN}/a.jpg`)
  const same = { heroImageUrl: `${MEDIA_ORIGIN}/a.jpg` }
  assert.equal(withMediaDomain(same, ['heroImageUrl']), same)
})

console.log(`\n${n} checks passed`)
