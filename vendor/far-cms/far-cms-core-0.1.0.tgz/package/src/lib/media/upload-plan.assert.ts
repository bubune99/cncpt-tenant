/**
 * Run: npx -y tsx@4.23.15 src/lib/media/upload-plan.assert.ts
 */
import assert from 'node:assert/strict'
import {
  MAX_FILE_BYTES, MAX_VIDEO_BYTES, PART_BYTES, maxBytesFor, sizeProblem, usesMultipart,
  partCount, partRange, checkParts, playbackNote, sendParts,
} from './upload-plan'

const MB = 1024 * 1024
let n = 0
const results: Promise<void>[] = []
const check = (name: string, fn: () => void | Promise<void>) => {
  results.push(Promise.resolve().then(fn).then(() => { n++; console.log(`ok - ${name}`) }))
}

check('videos may be 500 MB; images and documents stay at 50 MB', () => {
  assert.equal(maxBytesFor('video/mp4'), 500 * MB)
  assert.equal(maxBytesFor('image/jpeg'), 50 * MB)
  assert.equal(maxBytesFor('application/pdf'), 50 * MB)
  assert.equal(MAX_VIDEO_BYTES > MAX_FILE_BYTES, true)
})

check('a 2-minute 1080p phone video (~125 MB) is accepted; a 4K one (~380 MB) too; 600 MB is refused with a way out', () => {
  assert.equal(sizeProblem({ name: 'clip.mp4', type: 'video/mp4', size: 125 * MB }), null)
  assert.equal(sizeProblem({ name: 'clip.mov', type: 'video/quicktime', size: 380 * MB }), null)
  const msg = sizeProblem({ name: 'long.mp4', type: 'video/mp4', size: 600 * MB })
  assert.match(msg!, /600 MB/)
  assert.match(msg!, /500 MB/)
  assert.match(msg!, /YouTube/)
})

check('a 60 MB photo is still refused, and an empty file is refused', () => {
  assert.match(sizeProblem({ name: 'big.jpg', type: 'image/jpeg', size: 60 * MB })!, /50 MB/)
  assert.match(sizeProblem({ name: 'x.png', type: 'image/png', size: 0 })!, /empty/)
})

check('files from 20 MB go up in parts; smaller ones in one piece', () => {
  assert.equal(usesMultipart(5 * MB), false)
  assert.equal(usesMultipart(20 * MB), true)
  assert.equal(partCount(125 * MB), 13)
  assert.equal(partCount(500 * MB), 50)
  assert.equal(partCount(1), 1)
})

check('part ranges cover the file exactly once, the last part short', () => {
  const size = 25 * MB + 7
  const c = partCount(size)
  let covered = 0
  for (let i = 1; i <= c; i++) {
    const r = partRange(i, size)
    assert.equal(r.start, covered)
    covered = r.end
  }
  assert.equal(covered, size)
  assert.equal(partRange(c, size).end - partRange(c, size).start, 5 * MB + 7)
  assert.equal(partRange(1, size).end, PART_BYTES)
})

check('finishing needs exactly parts 1..n, once each, with receipts', () => {
  const ok = checkParts([{ partNumber: 2, etag: '"b"' }, { partNumber: 1, etag: '"a"' }], 2)
  assert.deepEqual(ok, { parts: [{ partNumber: 1, etag: '"a"' }, { partNumber: 2, etag: '"b"' }] })
  assert.ok('error' in checkParts([{ partNumber: 1, etag: 'a' }], 2))
  assert.ok('error' in checkParts([{ partNumber: 1, etag: 'a' }, { partNumber: 1, etag: 'b' }], 2))
  assert.ok('error' in checkParts([{ partNumber: 1, etag: 'a' }, { partNumber: 3, etag: 'b' }], 2))
  assert.ok('error' in checkParts([{ partNumber: 1, etag: '' }, { partNumber: 2, etag: 'b' }], 2))
  assert.ok('error' in checkParts('nope', 2))
})

check('.mov and other formats browsers can’t play get a note; MP4 none', () => {
  assert.match(playbackNote('video/quicktime', 'a.mov')!, /MP4/)
  assert.match(playbackNote('video/x-matroska', 'a.mkv')!, /MP4/)
  assert.equal(playbackNote('video/mp4', 'a.mp4'), null)
  assert.equal(playbackNote('image/jpeg', 'a.jpg'), null)
})

check('parts are all sent, a part that fails once is retried, results come back in order', async () => {
  const tries = new Map<number, number>()
  const waits: number[] = []
  const parts = await sendParts({
    count: 7,
    concurrency: 3,
    wait: async (ms) => { waits.push(ms) },
    send: async (p) => {
      tries.set(p, (tries.get(p) ?? 0) + 1)
      if (p === 4 && tries.get(p) === 1) throw new Error('network')
      return `e${p}`
    },
  })
  assert.deepEqual(parts.map((x) => x.partNumber), [1, 2, 3, 4, 5, 6, 7])
  assert.equal(parts[3].etag, 'e4')
  assert.equal(tries.get(4), 2)
  assert.deepEqual(waits, [1000])
})

check('a part that keeps failing stops the upload after its last attempt', async () => {
  let sent = 0
  await assert.rejects(sendParts({
    count: 20,
    concurrency: 2,
    attempts: 3,
    wait: async () => {},
    send: async (p) => { sent++; if (p === 2) throw new Error('down'); return 'e' },
  }), /down/)
  assert.ok(sent < 20 + 3, 'it stops instead of sending every remaining part')
})

check('never more than `concurrency` parts in flight', async () => {
  let live = 0
  let peak = 0
  await sendParts({
    count: 12,
    concurrency: 3,
    send: async () => { live++; peak = Math.max(peak, live); await new Promise((r) => setTimeout(r, 2)); live--; return 'e' },
  })
  assert.equal(peak, 3)
})

Promise.all(results).then(() => console.log(`\n${n} checks passed`), (e) => { console.error(e); process.exit(1) })
