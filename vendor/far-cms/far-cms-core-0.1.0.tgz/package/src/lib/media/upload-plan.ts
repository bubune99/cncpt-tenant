/**
 * Upload sizes and how a file travels to storage. Pure, shared by the browser
 * (checks before sending) and the server (the same rules, enforced).
 * Asserted by upload-plan.assert.ts.
 *
 * - Videos may be up to 500 MB; everything else up to 50 MB.
 * - Files from 20 MB go up in 10 MB parts (S3/R2 multipart), each part retried
 *   on its own, so one dropped connection doesn't restart a 300 MB upload.
 * - Only files up to 4 MB may go through our own server (Vercel's request
 *   body limit is 4.5 MB); anything bigger must go straight to storage.
 */

const MB = 1024 * 1024

export const MAX_FILE_BYTES = 50 * MB
export const MAX_VIDEO_BYTES = 500 * MB
export const PART_BYTES = 10 * MB
export const MULTIPART_FROM_BYTES = 20 * MB
export const MAX_VIA_SERVER_BYTES = 4 * MB
/** S3 and R2 refuse more parts than this. */
export const MAX_PARTS = 10_000

export function isVideo(mimeType: string): boolean {
  return /^video\//i.test(mimeType || '')
}

export function maxBytesFor(mimeType: string): number {
  return isVideo(mimeType) ? MAX_VIDEO_BYTES : MAX_FILE_BYTES
}

export function formatMb(bytes: number): string {
  const mb = bytes / MB
  return `${mb >= 10 ? Math.round(mb) : Math.round(mb * 10) / 10} MB`
}

/** Why this file can't be uploaded, in words for the person uploading; null when it can. */
export function sizeProblem(file: { name: string; type: string; size: number }): string | null {
  if (!Number.isFinite(file.size) || file.size <= 0) return `${file.name} is empty.`
  const max = maxBytesFor(file.type)
  if (file.size <= max) return null
  if (isVideo(file.type)) {
    return `${file.name} is ${formatMb(file.size)}. Videos can be up to ${formatMb(max)}. Export it smaller (720p or 1080p MP4), or put it on YouTube and use the link.`
  }
  return `${file.name} is ${formatMb(file.size)}. Files can be up to ${formatMb(max)}. Resize or compress it and try again.`
}

export function usesMultipart(size: number): boolean {
  return size >= MULTIPART_FROM_BYTES
}

/** How many parts a file of this size is sent in. */
export function partCount(size: number, partBytes = PART_BYTES): number {
  return Math.max(1, Math.ceil(size / partBytes))
}

/** The byte range [start, end) of part n (1-based). */
export function partRange(n: number, size: number, partBytes = PART_BYTES): { start: number; end: number } {
  const start = (n - 1) * partBytes
  return { start, end: Math.min(size, start + partBytes) }
}

export interface DonePart {
  partNumber: number
  etag: string
}

/**
 * The parts list a client hands back to finish a multipart upload: exactly
 * parts 1..expected, each once, each with an ETag. Returns them sorted, or
 * the reason they can't be used.
 */
export function checkParts(parts: unknown, expected: number): { parts: DonePart[] } | { error: string } {
  if (!Array.isArray(parts) || parts.length !== expected) return { error: 'The upload is missing parts.' }
  const seen = new Set<number>()
  const out: DonePart[] = []
  for (const p of parts) {
    const n = (p as { partNumber?: unknown })?.partNumber
    const etag = (p as { etag?: unknown })?.etag
    if (typeof n !== 'number' || !Number.isInteger(n) || n < 1 || n > expected || seen.has(n)) return { error: 'The upload parts are out of order.' }
    if (typeof etag !== 'string' || !etag || etag.length > 200) return { error: 'An upload part has no receipt.' }
    seen.add(n)
    out.push({ partNumber: n, etag })
  }
  return { parts: out.sort((a, b) => a.partNumber - b.partNumber) }
}

/** A note to show after a file uploads fine but may not play everywhere. */
export function playbackNote(mimeType: string, name: string): string | null {
  if (/^video\/quicktime$/i.test(mimeType) || /\.mov$/i.test(name)) {
    return 'Uploaded. Some browsers can’t play .mov files. If it doesn’t play, export it as MP4.'
  }
  if (/^video\/(x-msvideo|x-matroska|x-ms-wmv)$/i.test(mimeType)) {
    return 'Uploaded. Most browsers can’t play this video format. Export it as MP4 to show it on a page.'
  }
  return null
}

/**
 * Send every part with at most `concurrency` at once, retrying each part up
 * to `attempts` times. `send` uploads one part and returns its ETag.
 * Stops at the first part that fails every attempt. The waiting between
 * retries is injected so tests don't sleep.
 */
export async function sendParts(opts: {
  count: number
  concurrency?: number
  attempts?: number
  send: (partNumber: number, attempt: number) => Promise<string>
  wait?: (ms: number) => Promise<void>
  cancelled?: () => boolean
}): Promise<DonePart[]> {
  const { count, send } = opts
  const concurrency = Math.max(1, Math.min(opts.concurrency ?? 3, count))
  const attempts = Math.max(1, opts.attempts ?? 4)
  const wait = opts.wait ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)))
  const done: DonePart[] = []
  let next = 1
  let failed: unknown = null

  const worker = async () => {
    while (!failed && next <= count) {
      const n = next++
      for (let attempt = 1; ; attempt++) {
        if (opts.cancelled?.()) { failed = failed ?? new Error('Upload cancelled'); return }
        try {
          done.push({ partNumber: n, etag: await send(n, attempt) })
          break
        } catch (e) {
          if (attempt >= attempts || failed) { failed = failed ?? e; return }
          await wait(1000 * 2 ** (attempt - 1))
        }
      }
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker))
  if (failed) throw failed
  return done.sort((a, b) => a.partNumber - b.partNumber)
}
