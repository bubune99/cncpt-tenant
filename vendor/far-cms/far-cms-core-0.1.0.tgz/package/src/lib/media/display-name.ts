/**
 * A media item's name as a person reads it: its title, else its alt text,
 * else a tidied file name — never a UUID or hash.
 * Pure; asserted by display-name.assert.ts.
 */

const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi
const HASHY = /\b(?=[a-z0-9]*\d)[a-z0-9]{16,}\b/gi

function tidy(file: string | null | undefined): string {
  if (!file) return ''
  const base = file.split('/').pop() ?? file
  const words = base
    .replace(/\.[a-z0-9]{2,5}$/i, '')
    .replace(UUID, ' ')
    .replace(HASHY, ' ')
    .replace(/^\d{10,}[-_]?/, ' ')
    .replace(/[-_.]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  if (!words || /^\d+$/.test(words)) return ''
  // Upload folders leak into names ("images/About-Image" → "About image").
  const trimmed = words.replace(/^(images?|uploads?|media|files?)\s+(?=\S)/i, '')
  if (trimmed !== words) return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase()
  return words.charAt(0).toUpperCase() + words.slice(1).toLowerCase()
}

function kindOf(mimeType?: string | null): string {
  if (!mimeType) return 'File'
  if (mimeType.startsWith('image/')) return 'Image'
  if (mimeType.startsWith('video/')) return 'Video'
  if (mimeType.startsWith('audio/')) return 'Audio'
  if (mimeType === 'application/pdf') return 'PDF'
  return 'File'
}

export function mediaDisplayName(m: { title?: string | null; alt?: string | null; originalName?: string | null; filename?: string | null; mimeType?: string | null; createdAt?: string | Date | null }): string {
  const named = m.title?.trim() || m.alt?.trim() || tidy(m.originalName) || tidy(m.filename)
  if (named) return named
  const when = m.createdAt ? new Date(m.createdAt) : null
  return when && !Number.isNaN(when.getTime()) ? `${kindOf(m.mimeType)} added ${when.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}` : `Untitled ${kindOf(m.mimeType).toLowerCase()}`
}
