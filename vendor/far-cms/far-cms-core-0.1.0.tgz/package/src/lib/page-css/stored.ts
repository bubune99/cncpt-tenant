/**
 * Stored per-page CSS: kept inside the page's (or partial's) content JSON under
 * `pageCss`, so no schema change. Written only by the server after compiling; a client
 * never supplies it (content-safety strips it on every write).
 *
 * Neutral (no app imports): shared with BYB.
 */
import { hasScopedShape } from './scope'

export const STORED_KEY = 'pageCss'

export interface StoredCss {
  /** Output format (compile.ts PAGE_CSS_FORMAT). */
  v: number
  /** Theme + compiler (compile.ts themeKey). */
  theme: string
  /** Class-set hash the CSS was compiled for; also the scope value. */
  hash: string
  css: string
  compiledAt: string
  /** HMAC over v + theme + hash + css (sign.ts); render inlines only CSS that verifies. */
  sig?: string
}

const isStored = (x: unknown): x is StoredCss => {
  const s = x as StoredCss
  return !!s && typeof s === 'object' && typeof s.v === 'number' && typeof s.theme === 'string' && typeof s.hash === 'string' && typeof s.css === 'string' && (s.sig === undefined || typeof s.sig === 'string')
}

/** The stored CSS of a content document, if any. */
export function readStoredCss(content: unknown): StoredCss | null {
  if (!content || typeof content !== 'object' || Array.isArray(content)) return null
  const s = (content as Record<string, unknown>)[STORED_KEY]
  return isStored(s) ? s : null
}

/** Content without any pageCss (what a client may send). */
export function withoutStoredCss<T>(content: T): T {
  if (!content || typeof content !== 'object' || Array.isArray(content)) return content
  if (!(STORED_KEY in (content as object))) return content
  const copy = { ...(content as Record<string, unknown>) }
  delete copy[STORED_KEY]
  return copy as T
}

/** Content with this CSS stored (a block array is wrapped as a 2.0 document first). */
export function withStoredCss<T>(content: T, stored: StoredCss | null): T {
  if (!stored) return withoutStoredCss(content)
  if (Array.isArray(content)) return { version: '2.0', blocks: content, [STORED_KEY]: stored } as unknown as T
  if (!content || typeof content !== 'object') return content
  return { ...(content as Record<string, unknown>), [STORED_KEY]: stored } as T
}

/**
 * What to inline when rendering: the stored CSS only while it was made for exactly the
 * classes the page renders now, with this theme and format, its signature verifies
 * (`verify`, sign.ts), and it has the compiler's exact shape. Anything else → null, and
 * the page renders as it did before per-page CSS (the site stylesheet alone).
 */
export function cssForRender(
  stored: StoredCss | null,
  now: { hash: string; theme: string; format: number },
  verify: (stored: StoredCss) => boolean,
): { scope: string; css: string } | null {
  if (!stored || stored.v !== now.format || stored.theme !== now.theme || stored.hash !== now.hash) return null
  if (!verify(stored)) return null
  return hasScopedShape(stored.css, stored.hash) ? { scope: stored.hash, css: stored.css } : null
}

export interface StoredWrite<T> {
  content: T
  /** Set when compiling failed: the write goes ahead with the last good CSS. */
  warning?: string
}

/**
 * Content ready to write: any client-sent pageCss removed, freshly compiled CSS stored.
 * A failed compile never blocks the write — the previous document's CSS stays (render
 * uses it only while it still matches) and `warning` says so.
 */
export async function prepareStoredCss<T>(
  content: T,
  previous: unknown,
  compileFor: (content: T) => Promise<StoredCss>,
  onError: (err: unknown) => void,
  warning: string,
  /** Keep the previous CSS on failure only if this says it's genuine (its signature verifies). */
  trustPrevious: (stored: StoredCss) => boolean = () => false,
): Promise<StoredWrite<T>> {
  const clean = withoutStoredCss(content)
  // Only plain documents / block arrays (never Prisma's JsonNull and friends).
  if (!clean || typeof clean !== 'object' || (!Array.isArray(clean) && Object.getPrototypeOf(clean) !== Object.prototype)) return { content: clean }
  try {
    return { content: withStoredCss(clean, await compileFor(clean)) }
  } catch (err) {
    onError(err)
    const prev = readStoredCss(previous)
    return { content: withStoredCss(clean, prev && trustPrevious(prev) ? prev : null), warning }
  }
}
