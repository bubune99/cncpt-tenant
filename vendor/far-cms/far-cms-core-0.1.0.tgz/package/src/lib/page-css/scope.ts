/**
 * Scoping and escaping for per-page CSS.
 *
 * The page's stylesheet re-declares every class the page uses, in Tailwind's order,
 * after the site stylesheet. Scoped to the page's own wrapper so it can't reorder the
 * header, footer or admin chrome; smart blocks (shop, forms… — their insides are app
 * markup, not page classes) are left to the site stylesheet. Partial references are
 * page content and stay in scope. Rules go in `@layer utilities`, so the app's own
 * unlayered CSS still wins exactly as it does over the site's utilities.
 *
 * Neutral (no app imports): shared with BYB.
 */

/** The wrapper attribute; its value is the class-set hash. */
export const SCOPE_ATTR = 'data-page-css'
/** Marks a smart block's wrapper: its insides keep the site stylesheet. */
export const SMART_ATTR = 'data-page-css-skip'

interface Statement {
  head: string // selector or at-rule prelude (no braces)
  body: string | null // inner text, or null for a statement like `@layer properties;`
}

/** Split CSS text into top-level statements (brace-aware; strings and comments respected). */
export function topLevelStatements(css: string): Statement[] {
  const out: Statement[] = []
  let i = 0
  const n = css.length
  while (i < n) {
    // skip whitespace and comments
    if (/\s/.test(css[i])) { i++; continue }
    if (css.startsWith('/*', i)) { const e = css.indexOf('*/', i + 2); i = e < 0 ? n : e + 2; continue }
    let j = i
    let quote: string | null = null
    while (j < n) {
      const ch = css[j]
      if (quote) { if (ch === '\\') j++; else if (ch === quote) quote = null }
      else if (ch === '\\') j++ // an escaped character outside a string (\[ \' …) is just a character
      else if (ch === '"' || ch === "'") quote = ch
      else if (ch === '{' || ch === ';') break
      j++
    }
    const head = css.slice(i, j).trim()
    if (j >= n || css[j] === ';') { if (head) out.push({ head, body: null }); i = j + 1; continue }
    // matching brace
    let depth = 1
    let k = j + 1
    quote = null
    while (k < n && depth > 0) {
      const ch = css[k]
      if (quote) { if (ch === '\\') k++; else if (ch === quote) quote = null }
      else if (ch === '\\') k++
      else if (ch === '"' || ch === "'") quote = ch
      else if (ch === '{') depth++
      else if (ch === '}') depth--
      k++
    }
    out.push({ head, body: css.slice(j + 1, k - 1) })
    i = k
  }
  return out
}

/** Prefix each selector of a top-level rule with the page scope (smart blocks excluded). */
function scopeSelector(selector: string, scope: string): string {
  return selector
    .split(',')
    .map((s) => `[${SCOPE_ATTR}="${scope}"] ${s.trim()}:not([${SMART_ATTR}] *)`)
    .join(', ')
}

/**
 * Tailwind's build output → the page stylesheet: class rules scoped and put in
 * `@layer utilities`; @property and the properties layer kept as they are (global by
 * nature, identical to the site's); comments dropped.
 */
export function scopeCss(built: string, scope: string): string {
  if (!/^[a-z0-9]{1,32}$/.test(scope)) throw new Error('Bad scope')
  const rules: string[] = []
  const globals: string[] = []
  for (const st of topLevelStatements(built)) {
    if (st.body === null) continue // `@layer properties;` — the site already declares its layers
    const body = st.body.replace(/\n\s*/g, '') // Tailwind prints one declaration per line
    if (st.head.startsWith('@property') || st.head.startsWith('@layer properties')) globals.push(`${st.head}{${body}}`)
    else if (st.head.startsWith('@')) continue // nothing else is expected from utilities-only input
    else rules.push(`${scopeSelector(st.head, scope)}{${body}}`)
  }
  return `@layer utilities{${rules.join('')}}${globals.join('')}`
}

/**
 * The text that may go inside <style>. CSS from the allow-listed classes can't contain
 * these, so if it ever does, nothing is inlined (the page renders as before).
 */
export function styleSafe(css: string): string | null {
  if (!css) return null
  if (/<\/|<!--|-->|<script|<style/i.test(css)) return null
  return css
}

/** Never in page CSS, whatever the shape: anything that loads, runs or escapes. */
const NEVER_IN_OUTPUT = /url\(|image-set\(|image\(|cross-fade\(|element\(|src\(|@import|@font-face|@namespace|@charset|expression\(|javascript:|behavior\s*:|-moz-binding|\/\*/i

/** A string the compiler legitimately prints: @property syntax ("*", "<length>") and font names. */
const SAFE_STRING = /^[A-Za-z0-9 _*<>%+-]{0,60}$/
/** Characters Tailwind escapes in class selectors (\[ \] \: \/ …). No hex escapes, no braces. */
const SAFE_ESCAPED = /^[[\]#/.%:!(),&@*+=?^$|~<>'"]$/

/**
 * Replace every string with "" after checking it, the way a browser reads it: a string
 * ends at its closing quote; a newline or backslash inside makes the whole thing invalid
 * (security review: `content:"⏎}}body{…}` must not get a rule past the validator).
 * Outside strings, a backslash may only escape one of SAFE_ESCAPED. Null when invalid.
 */
function stripStrings(css: string): string | null {
  let out = ''
  for (let i = 0; i < css.length; i++) {
    const ch = css[i]
    if (ch === '\\') {
      if (!SAFE_ESCAPED.test(css[i + 1] ?? '')) return null
      out += ch + css[i + 1]
      i++
      continue
    }
    if (ch === '"' || ch === "'") {
      const end = css.indexOf(ch, i + 1)
      if (end < 0) return null
      const body = css.slice(i + 1, end)
      if (/[\n\r\f\\]/.test(body) || !SAFE_STRING.test(body)) return null
      out += '""'
      i = end
      continue
    }
    out += ch
  }
  return out
}

const DECL = /^(-{0,2}[a-z][a-z0-9-]*)\s*:\s*([^{}]*)$/i
const splitHeads = (head: string) => head.split(',').map((h) => h.trim())

/**
 * A nested selector that can only reach the element itself or what's inside / beside it:
 * it starts with `&` (&:hover, & > *, &::before), or it is exactly `:where(&…)` / `:is(&…)`
 * with no list inside (Tailwind's space-x/y: `:where(& > :not(:last-child))`). Never
 * `:not(&) body` (re-review: page-wide) or `:where(&, body)`.
 */
function sameElement(head: string): boolean {
  if (head.startsWith('&')) return true
  const m = /^:(where|is)\((.*)\)$/.exec(head)
  if (!m || !m[2].startsWith('&') || m[2].includes(',')) return false
  // The parentheses must balance inside, so the whole head is that one :where( … ).
  let depth = 0
  for (const ch of m[2]) {
    if (ch === '(') depth++
    else if (ch === ')' && --depth < 0) return false
  }
  return depth === 0
}

/** A rule body: declarations, and nested rules on the same element (&…, :where(&…)) or @media / @supports. */
function validBody(body: string, depth: number): boolean {
  if (depth > 6) return false
  for (const st of topLevelStatements(body)) {
    if (st.body === null) {
      if (!DECL.test(st.head)) return false
      continue
    }
    const atRule = /^@(media|supports)\s/.test(st.head)
    if (!atRule && !splitHeads(st.head).every(sameElement)) return false
    if (!validBody(st.body, depth + 1)) return false
  }
  return true
}

/**
 * Does stored CSS have exactly the shape scopeCss produces? Checked again at render (after
 * the signature), so nothing but compiler-shaped, scoped rules is ever inlined:
 *  - one `@layer utilities` of rules whose every selector is `[data-page-css="<scope>"] …
 *    :not([data-page-css-skip] *)`, with bodies of declarations and nested rules on the same
 *    element (&…) or @media / @supports only;
 *  - then `@property --tw-*` blocks (syntax / inherits / initial-value only) and
 *    `@layer properties` blocks (`@supports` → `*, ::before, ::after, ::backdrop` → `--tw-*`
 *    declarations only);
 *  - strings only as the compiler prints them, no url()/image-set()/@import/expression(),
 *    no comments, no hex escapes.
 */
export function hasScopedShape(css: string, scope: string): boolean {
  if (!/^[a-z0-9]{1,32}$/.test(scope) || !styleSafe(css)) return false
  const text = stripStrings(css)
  if (text === null || NEVER_IN_OUTPUT.test(text)) return false
  const top = topLevelStatements(text)
  if (top.length === 0 || top[0].head !== '@layer utilities' || top[0].body === null) return false
  const prefix = `[${SCOPE_ATTR}=""] `
  const suffix = `:not([${SMART_ATTR}] *)`
  // The scope value sits in a string, so it was stripped: check it against the original text.
  if (!css.startsWith(`@layer utilities{[${SCOPE_ATTR}="${scope}"] `) && top[0].body.trim() !== '') return false
  if ((css.match(/\[data-page-css="([a-z0-9]*)"\]/g) ?? []).some((m) => m !== `[${SCOPE_ATTR}="${scope}"]`)) return false
  for (const st of topLevelStatements(top[0].body)) {
    if (st.body === null) return false
    if (!splitHeads(st.head).every((h) => h.startsWith(prefix) && h.endsWith(suffix) && h.length > prefix.length + suffix.length)) return false
    if (!validBody(st.body, 0)) return false
  }
  for (const st of top.slice(1)) {
    if (st.body === null) return false
    if (/^@property --tw-[a-z0-9-]+$/.test(st.head)) {
      const decls = topLevelStatements(st.body)
      if (!decls.every((d) => d.body === null && /^(syntax|inherits|initial-value)\s*:/.test(d.head) && DECL.test(d.head))) return false
      continue
    }
    if (st.head !== '@layer properties') return false
    for (const sup of topLevelStatements(st.body)) {
      if (sup.body === null || !/^@supports\s/.test(sup.head)) return false
      for (const rule of topLevelStatements(sup.body)) {
        if (rule.body === null || rule.head.replace(/\s+/g, ' ') !== '*, ::before, ::after, ::backdrop') return false
        if (!topLevelStatements(rule.body).every((d) => d.body === null && /^--tw-[a-z0-9-]+\s*:/.test(d.head) && DECL.test(d.head))) return false
      }
    }
  }
  return true
}
