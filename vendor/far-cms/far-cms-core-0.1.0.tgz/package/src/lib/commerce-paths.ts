/**
 * Commerce visibility rules — pure data + functions, no I/O.
 *
 * Used with the `commerce.enabled` flag (src/lib/features.ts). When commerce
 * is off, storefront commerce routes 404, links to them are removed from the
 * global header/footer, and commerce screens are dropped from the admin nav.
 * Nothing here deletes commerce code or data.
 *
 * Asserted by commerce-paths.assert.ts.
 */

/** Storefront paths that only make sense with a shop. */
export const COMMERCE_STOREFRONT_PREFIXES = [
  '/shop',
  '/merch',
  '/cart',
  '/checkout',
  '/products',
  '/product',
  '/track',
  '/account/orders',
  '/account/addresses',
] as const

/** Admin screens that only make sense with a shop. */
export const COMMERCE_ADMIN_PREFIXES = [
  '/admin/products',
  '/admin/orders',
  '/admin/order-workflows',
  '/admin/shipping',
  '/admin/inventory',
  '/admin/customers',
  '/admin/discounts',
  '/admin/reviews',
] as const

/** Settings tabs that only configure commerce. */
export const COMMERCE_SETTINGS_TABS = ['shipping', 'taxes', 'notifications'] as const

/** Parse a boolean-ish flag value ("true", "1", "on", true). Unknown → null. */
export function parseFlag(value: unknown): boolean | null {
  if (typeof value === 'boolean') return value
  if (typeof value !== 'string') return null
  let v = value.trim().toLowerCase()
  // Setting rows store JSON — '"true"' arrives quoted.
  if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1)
  if (['true', '1', 'on', 'yes'].includes(v)) return true
  if (['false', '0', 'off', 'no'].includes(v)) return false
  return null
}

/** Resolve the flag: DB value wins, then env, then the APP's default (Dzidzor: off — lib/ade-bindings/app-config). */
export function resolveCommerceEnabled(dbValue: unknown, envValue: string | undefined, appDefault = false): boolean {
  return parseFlag(dbValue) ?? parseFlag(envValue) ?? appDefault
}

function matchesPrefix(path: string, prefixes: readonly string[]): boolean {
  return prefixes.some((p) => path === p || path.startsWith(p + '/'))
}

/** Normalize an href to a site-relative pathname, or null for external/anchor links. */
export function hrefPath(href: string | undefined | null): string | null {
  if (!href) return null
  const h = href.trim()
  if (!h.startsWith('/') || h.startsWith('//')) return null
  const path = h.split(/[?#]/)[0].replace(/\/+$/, '')
  return (path || '/').toLowerCase()
}

export function isCommerceStorefrontPath(href: string | undefined | null): boolean {
  const path = hrefPath(href)
  return path !== null && matchesPrefix(path, COMMERCE_STOREFRONT_PREFIXES)
}

export function isCommerceAdminPath(href: string | undefined | null): boolean {
  const path = hrefPath(href)
  return path !== null && matchesPrefix(path, COMMERCE_ADMIN_PREFIXES)
}

interface LinkBlockLike {
  tag?: string
  attrs?: Record<string, string>
  children?: LinkBlockLike[]
}

/**
 * Remove links (and buttons carrying an href) to commerce paths from a block
 * tree. Returns new arrays/objects; the input is not mutated.
 */
export function stripCommerceLinks<T extends LinkBlockLike>(blocks: T[]): T[] {
  const out: T[] = []
  for (const block of blocks) {
    if ((block.tag === 'a' || block.tag === 'button') && isCommerceStorefrontPath(block.attrs?.href)) {
      continue
    }
    if (block.children && block.children.length > 0) {
      out.push({ ...block, children: stripCommerceLinks(block.children as T[]) })
    } else {
      out.push(block)
    }
  }
  return out
}

/**
 * Apply commerce visibility to a stored header/footer value: either a block
 * document ({ version, blocks }) or legacy props ({ navLinks, showCart, … }).
 */
export function hideCommerceInLayout(data: unknown): unknown {
  if (!data || typeof data !== 'object') return data
  const doc = data as Record<string, unknown>
  if (Array.isArray(doc.blocks)) {
    return { ...doc, blocks: stripCommerceLinks(doc.blocks as LinkBlockLike[]) }
  }
  const next: Record<string, unknown> = { ...doc }
  if (Array.isArray(doc.navLinks)) {
    next.navLinks = (doc.navLinks as { href?: string }[]).filter((l) => !isCommerceStorefrontPath(l?.href))
  }
  if ('showCart' in doc) next.showCart = false
  if (Array.isArray(doc.columns)) {
    next.columns = (doc.columns as { links?: { href?: string }[] }[]).map((col) =>
      Array.isArray(col?.links) ? { ...col, links: col.links.filter((l) => !isCommerceStorefrontPath(l?.href)) } : col
    )
  }
  return next
}
