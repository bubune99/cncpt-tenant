/**
 * Run: npx -y tsx@4.23.15 src/lib/analytics/visitors.assert.ts
 */
import assert from 'node:assert/strict'
import { countUniqueVisitors, visitorKey, type VisitorRow } from './visitors'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
const row = (sessionId: string | null, extra: Record<string, unknown> = {}): VisitorRow => ({ sessionId, ...extra }) as VisitorRow

check('only visitors who accepted analytics (they have a session id) are counted', () => {
  assert.equal(countUniqueVisitors([row('a'), row('a'), row('b')]), 2)
})

check('owner rule 2026-11-05: rows without consent are NOT told apart by IP hash + browser any more', () => {
  const rows = [
    row(null, { ipAddress: 'h1.k.aaa', userAgent: 'Chrome 155' }),
    row(null, { ipAddress: 'h1.k.bbb', userAgent: 'Safari 26' }),
  ]
  assert.equal(countUniqueVisitors(rows), 0)
  assert.equal(visitorKey(rows[0]), null)
})

check('a consented visitor and an anonymous view: one visitor', () => {
  assert.equal(countUniqueVisitors([row('s1'), row(null)]), 1)
})

check('empty range = 0', () => assert.equal(countUniqueVisitors([]), 0))

console.log(`\n${n} checks passed`)
