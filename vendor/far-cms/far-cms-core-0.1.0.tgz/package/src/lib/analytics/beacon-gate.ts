/**
 * Which page-view beacons are worth a database write (owner 2026-10-30: the
 * database should sleep when nobody is working, so a view must not wake it
 * unless it is a person seeing a page for the first time in a moment).
 *
 * Every check here runs in memory BEFORE the rate limiter and the insert —
 * both of which touch Postgres — so dropped traffic costs no DB time at all:
 *   - crawlers, link-preview fetchers, monitors and headless browsers;
 *   - prefetch / prerender requests;
 *   - a visitor re-sending the page they last reported within
 *     DEDUPE_WINDOW_MS (double effects, quick reloads). Going A → B → A
 *     still counts A twice: only an immediate repeat is dropped.
 *
 * The dedupe memory lives in one function instance only (no shared store —
 * that would be another thing to wake). On Fluid compute an instance serves
 * many requests, so it catches most repeats; a repeat landing on another
 * instance is still written, which keeps the count honest-but-slightly-high
 * rather than ever losing a real view.
 *
 * Pure: no Next, no Prisma, the clock is passed in. Asserted by
 * beacon-gate.assert.ts.
 */

/** A visitor's immediate repeat of the same page inside this window counts once. */
export const DEDUPE_WINDOW_MS = 30_000
/** Upper bound on remembered views per instance (memory stays small). */
export const DEDUPE_MAX_ENTRIES = 5_000

/**
 * Non-human user agents. Deliberately broader than lib/ade/privacy/ua's
 * "Bot" rule, whose `\bbot\b` misses "Googlebot", "bingbot", "AhrefsBot"
 * (no word boundary before "bot").
 */
const NON_HUMAN_UA =
  /bot\b|bot\/|crawl|spider|slurp|scrape|fetcher|curl\/|wget|python|java\/|go-http|okhttp|axios|node-fetch|undici|httpclient|libwww|headless|phantomjs|puppeteer|playwright|selenium|lighthouse|pagespeed|gtmetrix|pingdom|uptime|monitor|statuscake|facebookexternalhit|facebookcatalog|embedly|quora link preview|whatsapp|telegrambot|discordbot|slackbot|skypeuripreview|vercel-(?:screenshot|favicon)|preview/i

export function isNonHumanUa(ua: string | null | undefined): boolean {
  if (!ua || !ua.trim()) return true // real browsers always send one
  return NON_HUMAN_UA.test(ua)
}

/**
 * Paths that are not public pages, so a view of them is not a visit: the admin, the
 * sign-in handler, the API and the change previews shown inside the admin (/ade-preview —
 * found 2026-11-22 to be most of the recorded page views on staging). The browser beacon and
 * the server both use this list.
 */
export const UNTRACKED_PREFIXES = ['/admin', '/handler', '/api', '/ade-preview'] as const

/** True for a public page (a path, or a full address on this site). */
export function isTrackedPath(pathOrUrl: string): boolean {
  let path = pathOrUrl
  if (/^https?:\/\//i.test(path)) {
    try { path = new URL(path).pathname } catch { return true }
  }
  path = path.split(/[?#]/)[0] || '/'
  return !UNTRACKED_PREFIXES.some((p) => path === p || path.startsWith(`${p}/`))
}

/**
 * Where-clause for reports: page views of public pages only (rows with no address are kept).
 * Plain object so this module stays free of Prisma; it matches the analyticsEvent where input.
 * Hides the internal views already recorded before the beacon skipped them; deletes nothing.
 */
export function publicPageWhere() {
  return {
    OR: [
      { pageUrl: null },
      { NOT: UNTRACKED_PREFIXES.flatMap((p) => [{ pageUrl: { equals: p } }, { pageUrl: { startsWith: `${p}/` } }, { pageUrl: { startsWith: `${p}?` } }]) },
    ],
  }
}

type HeaderGet = (name: string) => string | null

/** Speculative loads the person may never see. */
export function isPrefetch(get: HeaderGet): boolean {
  const purpose = `${get('sec-purpose') ?? ''} ${get('purpose') ?? ''} ${get('x-purpose') ?? ''} ${get('x-moz') ?? ''}`.toLowerCase()
  if (/prefetch|prerender|preview/.test(purpose)) return true
  return get('next-router-prefetch') !== null
}

export type GateVerdict = 'write' | 'bot' | 'prefetch' | 'duplicate' | 'internal'

export interface Dedupe {
  /**
   * True when `page` is what this visitor last reported, inside the window.
   * Records the view either way (a repeat does not extend the window).
   */
  seen(visitor: string, page: string, nowMs: number): boolean
  readonly size: number
}

/** A bounded, time-windowed "visitor → last page" memory. */
export function createDedupe(windowMs = DEDUPE_WINDOW_MS, maxEntries = DEDUPE_MAX_ENTRIES): Dedupe {
  const last = new Map<string, { page: string; at: number }>()
  const prune = (nowMs: number) => {
    for (const [k, v] of last) {
      if (nowMs - v.at < windowMs && last.size <= maxEntries) break // Map keeps insertion order: oldest first
      last.delete(k)
    }
  }
  return {
    seen(visitor, page, nowMs) {
      const prev = last.get(visitor)
      const hit = prev !== undefined && prev.page === page && nowMs - prev.at < windowMs
      if (!hit) {
        last.delete(visitor) // re-insert at the end so order stays oldest-first
        last.set(visitor, { page, at: nowMs })
        prune(nowMs)
      }
      return hit
    },
    get size() {
      return last.size
    },
  }
}

export interface BeaconFacts {
  userAgent: string | null
  header: HeaderGet
  /** Anonymous visitor id for dedupe: session id, else IP + UA (memory only, never stored). */
  visitor: string
  pageUrl: string | undefined
  eventName: string
}

/** Decide whether a beacon earns a write. Only page views are deduped. */
export function gateBeacon(facts: BeaconFacts, dedupe: Dedupe, nowMs: number): GateVerdict {
  if (isNonHumanUa(facts.userAgent)) return 'bot'
  if (isPrefetch(facts.header)) return 'prefetch'
  if (facts.eventName === 'page_view' && facts.pageUrl && !isTrackedPath(facts.pageUrl)) return 'internal'
  if (facts.eventName === 'page_view' && dedupe.seen(facts.visitor, facts.pageUrl ?? '', nowMs)) return 'duplicate'
  return 'write'
}
