/**
 * Run: npx -y tsx@4.23.15 src/lib/analytics/beacon-gate.assert.ts
 */
import assert from 'node:assert/strict'
import { createDedupe, DEDUPE_WINDOW_MS, gateBeacon, isNonHumanUa, isPrefetch, isTrackedPath, publicPageWhere, UNTRACKED_PREFIXES, type BeaconFacts } from './beacon-gate'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const CHROME = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36'
const IPHONE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1'
const ANDROID = 'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.0.0 Mobile Safari/537.36'
const FIREFOX = 'Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0'
const EDGE = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0'
const noHeaders = () => null
const headers = (h: Record<string, string>) => (name: string) => h[name] ?? null
const facts = (over: Partial<BeaconFacts> = {}): BeaconFacts => ({ userAgent: CHROME, header: noHeaders, visitor: 'v1', pageUrl: '/', eventName: 'page_view', ...over })

check('real browsers are human', () => {
  for (const ua of [CHROME, IPHONE, ANDROID, FIREFOX, EDGE]) assert.equal(isNonHumanUa(ua), false, ua)
})

check('crawlers the old \\bbot\\b rule missed are caught', () => {
  for (const ua of [
    'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
    'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',
    'Mozilla/5.0 (compatible; YandexBot/3.0)',
    'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)',
    'WhatsApp/2.23.20.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; moto g power (2022)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36 Chrome-Lighthouse',
    'curl/8.4.0',
    'python-requests/2.31',
    'Slackbot-LinkExpanding 1.0 (+https://api.slack.com/robots)',
    'Mozilla/5.0 (compatible; UptimeRobot/2.0; http://www.uptimerobot.com/)',
  ]) assert.equal(isNonHumanUa(ua), true, ua)
})

check('no user agent at all = not a browser', () => {
  assert.equal(isNonHumanUa(null), true)
  assert.equal(isNonHumanUa('  '), true)
})

check('prefetch / prerender headers are skipped; a normal beacon is not', () => {
  assert.equal(isPrefetch(headers({ 'sec-purpose': 'prefetch;prerender' })), true)
  assert.equal(isPrefetch(headers({ purpose: 'prefetch' })), true)
  assert.equal(isPrefetch(headers({ 'x-purpose': 'preview' })), true)
  assert.equal(isPrefetch(headers({ 'x-moz': 'prefetch' })), true)
  assert.equal(isPrefetch(headers({ 'next-router-prefetch': '1' })), true)
  assert.equal(isPrefetch(noHeaders), false)
  assert.equal(isPrefetch(headers({ 'content-type': 'application/json' })), false)
})

check('same visitor + same page inside the window: written once', () => {
  const d = createDedupe()
  assert.equal(gateBeacon(facts(), d, 0), 'write')
  assert.equal(gateBeacon(facts(), d, 1_000), 'duplicate')
  assert.equal(gateBeacon(facts(), d, DEDUPE_WINDOW_MS - 1), 'duplicate')
})

check('after the window, or a different page, or a different visitor: written', () => {
  const d = createDedupe()
  gateBeacon(facts(), d, 0)
  assert.equal(gateBeacon(facts({ visitor: 'v2' }), d, 20), 'write')
  assert.equal(gateBeacon(facts({ pageUrl: '/about' }), d, 10), 'write')
  assert.equal(gateBeacon(facts({ pageUrl: '/about' }), d, 10 + DEDUPE_WINDOW_MS), 'write')
})

check('A → B → A inside the window counts A twice (only an immediate repeat is dropped)', () => {
  const d = createDedupe()
  assert.equal(gateBeacon(facts({ pageUrl: '/a' }), d, 0), 'write')
  assert.equal(gateBeacon(facts({ pageUrl: '/b' }), d, 1_000), 'write')
  assert.equal(gateBeacon(facts({ pageUrl: '/a' }), d, 2_000), 'write')
  assert.equal(gateBeacon(facts({ pageUrl: '/a' }), d, 3_000), 'duplicate')
})

check('a duplicate does not extend its own window (a stuck tab cannot hide views forever)', () => {
  const d = createDedupe()
  gateBeacon(facts(), d, 0)
  gateBeacon(facts(), d, DEDUPE_WINDOW_MS - 10)
  assert.equal(gateBeacon(facts(), d, DEDUPE_WINDOW_MS + 1), 'write')
})

check('only page views are deduped (a purchase event is never dropped as a repeat)', () => {
  const d = createDedupe()
  assert.equal(gateBeacon(facts({ eventName: 'purchase' }), d, 0), 'write')
  assert.equal(gateBeacon(facts({ eventName: 'purchase' }), d, 1), 'write')
})

check('bots and prefetch are refused before dedupe records anything', () => {
  const d = createDedupe()
  assert.equal(gateBeacon(facts({ userAgent: 'Googlebot/2.1' }), d, 0), 'bot')
  assert.equal(gateBeacon(facts({ header: headers({ 'sec-purpose': 'prefetch' }) }), d, 0), 'prefetch')
  assert.equal(d.size, 0)
})

check('memory stays bounded: oldest entries go first', () => {
  const d = createDedupe(DEDUPE_WINDOW_MS, 100)
  for (let i = 0; i < 1_000; i++) d.seen(`k${i}`, '/', i)
  assert.ok(d.size <= 100, `size ${d.size}`)
  assert.equal(d.seen('k999', '/', 1_000), true, 'the newest is still remembered')
  assert.equal(d.seen('k0', '/', 1_000), false, 'the oldest was evicted')
})

check('expired entries are pruned as time passes', () => {
  const d = createDedupe(1_000, 100)
  for (let i = 0; i < 50; i++) d.seen(`k${i}`, '/', 0)
  d.seen('fresh', '/', 5_000)
  assert.equal(d.size, 1)
})

check('internal screens and previews are not visits (2026-11-22: /ade-preview was counted)', () => {
  for (const p of ['/ade-preview/initiatives/test?set=abc', '/ade-preview', '/admin', '/admin/pages', '/handler/sign-in', '/api/analytics', 'https://www.projectdzidzor.org/ade-preview/donate'])
    assert.equal(isTrackedPath(p), false, p)
})
check('public pages are visits, including look-alike names', () => {
  for (const p of ['/', '/donate', '/initiatives/akuse-hospital?utm_source=x', '/administration-team', '/api-docs', 'https://www.projectdzidzor.org/about'])
    assert.equal(isTrackedPath(p), true, p)
})
check('a page view of an internal screen is dropped before the insert; other events are not', () => {
  assert.equal(gateBeacon(facts({ pageUrl: '/ade-preview/initiatives/test?set=1' }), createDedupe(), 0), 'internal')
  assert.equal(gateBeacon(facts({ pageUrl: '/admin/todo' }), createDedupe(), 0), 'internal')
  assert.equal(gateBeacon(facts({ pageUrl: '/donate' }), createDedupe(), 0), 'write')
  assert.equal(gateBeacon(facts({ pageUrl: '/ade-preview/x', eventName: 'purchase' }), createDedupe(), 0), 'write')
})

check('the report filter keeps rows with no address and excludes each internal prefix by segment', () => {
  const w = publicPageWhere()
  assert.deepEqual(w.OR[0], { pageUrl: null })
  const not = (w.OR[1] as { NOT: Array<{ pageUrl: Record<string, string> }> }).NOT
  assert.equal(not.length, UNTRACKED_PREFIXES.length * 3)
  assert.ok(not.some((c) => c.pageUrl.startsWith === '/ade-preview/'))
  assert.ok(not.some((c) => c.pageUrl.equals === '/admin'))
  assert.ok(!not.some((c) => c.pageUrl.startsWith === '/admin'), 'no bare prefix, so /administration-team still counts')
})

console.log(`\n${n} checks passed`)
