/**
 * Run: npx -y tsx@4.23.15 src/lib/analytics/kpis.assert.ts
 */
import assert from 'node:assert/strict'
import { API_RANGE, analyticsKpis, trafficShares } from './kpis'

let n = 0
const check = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

// What GET /api/analytics returns today (lib/analytics getAnalyticsSummary): flat, no overview, no trends.
const TODAY = { pageViews: 1200, uniqueVisitors: 340, purchases: 0, revenue: 0, topReferrers: [{ referrer: 'google.com', count: 30 }, { referrer: 'instagram.com', count: 10 }] }

check('shop off: only what the site measures — visitors and page views', () => {
  const k = analyticsKpis(TODAY, { commerceEnabled: false })
  assert.deepEqual(k.map((c) => [c.key, c.value]), [['visitors', 340], ['pageviews', 1200]])
})

check('visitors are never called customers', () => {
  const k = analyticsKpis(TODAY, { commerceEnabled: true })
  assert.equal(k.find((c) => c.key === 'customers'), undefined)
  assert.equal(k.find((c) => c.key === 'visitors')?.label, 'Unique visitors (who accepted analytics)')
})

check('owner rule 2026-11-05: the visitors number says who it counts, and how many declined', () => {
  const k = analyticsKpis({ ...TODAY, declinedTracking: 1234 }, { commerceEnabled: false })
  const v = k.find((c) => c.key === 'visitors')
  assert.equal(v?.note, '1,234 declined tracking')
  assert.equal(analyticsKpis(TODAY, { commerceEnabled: false }).find((c) => c.key === 'visitors')?.note, undefined, 'unknown count: no note, never a fake 0')
  assert.equal(analyticsKpis({ ...TODAY, declinedTracking: 0 }, { commerceEnabled: false }).find((c) => c.key === 'visitors')?.note, '0 declined tracking')
})

check('unmeasured numbers are null, not 0; no invented trends', () => {
  const k = analyticsKpis(TODAY, { commerceEnabled: true })
  const by = Object.fromEntries(k.map((c) => [c.key, c]))
  assert.equal(by.conversion.value, null)
  assert.equal(by['avg-order'].value, null) // 0 orders: no average
  assert.equal(by.revenue.value, 0) // measured: really 0
  assert.ok(k.every((c) => c.change === null))
})

check('measured numbers pass through; the average comes from real revenue and orders', () => {
  const k = analyticsKpis({ revenue: 500, purchases: 4, uniqueVisitors: 9, overview: { revenueChange: 12.5, customers: 3 } }, { commerceEnabled: true })
  const by = Object.fromEntries(k.map((c) => [c.key, c]))
  assert.equal(by['avg-order'].value, 125)
  assert.equal(by.revenue.change, 12.5)
  assert.equal(by.customers.value, 3)
})

check('every date choice reaches the API as itself (12 months was silently 7 days)', () => {
  assert.equal(API_RANGE['12m'], 'year')
  assert.equal(API_RANGE.today, '24h')
  assert.equal(API_RANGE['30d'], '30d')
})

check('traffic shares are computed from the counts, not shown as 0%', () => {
  assert.deepEqual(trafficShares(TODAY.topReferrers).map((t) => t.percentage), [75, 25])
  assert.deepEqual(trafficShares([]), [])
})

console.log(`\n${n} checks passed`)
