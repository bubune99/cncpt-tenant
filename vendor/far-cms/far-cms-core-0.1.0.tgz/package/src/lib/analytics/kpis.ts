/**
 * What the admin Analytics screen may claim — only numbers the API actually
 * measured (owner rule: nothing presents fake data as real). A number the
 * API doesn't provide is `null` (shown as "—", "Not tracked yet"), a trend
 * the API doesn't provide is `null` (no "+0.0% from last period"), and
 * shop numbers only show while the shop is on. Pure; asserted by
 * kpis.assert.ts.
 */

type OverviewKey =
  | 'revenue'
  | 'orders'
  | 'customers'
  | 'avgOrderValue'
  | 'conversionRate'
  | 'pageViews'

/** GET /api/analytics, as far as this screen reads it. */
export interface AnalyticsSummaryLike {
  overview?: Partial<Record<OverviewKey | `${OverviewKey}Change`, number>>
  revenue?: number
  purchases?: number
  /** Distinct visitors who accepted analytics. */
  uniqueVisitors?: number
  /** Decline presses in the range (anonymous count); null = couldn't read. */
  declinedTracking?: number | null
  pageViews?: number
  topReferrers?: Array<{ referrer: string; count: number }>
}

export type KpiKey = 'revenue' | 'orders' | 'customers' | 'visitors' | 'avg-order' | 'conversion' | 'pageviews'

export interface KpiCell {
  key: KpiKey
  label: string
  /** null = not measured. */
  value: number | null
  format: 'currency' | 'number' | 'percent'
  /** % change from the last period; null = not measured. */
  change: number | null
  /** A shop number (hidden while the shop is off). */
  commerce: boolean
  /** A short line under the number ("12 declined tracking"). */
  note?: string
}

/** The honest visitors label: only people who accepted analytics have an id to count. */
export const VISITORS_LABEL = 'Unique visitors (who accepted analytics)'

/** "12 declined tracking" — what the visitors number leaves out. */
export function declinedNote(declined: unknown): string | undefined {
  const n = num(declined)
  return n === null ? undefined : `${n.toLocaleString('en-US')} declined tracking`
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null)

export function analyticsKpis(raw: AnalyticsSummaryLike, { commerceEnabled }: { commerceEnabled: boolean }): KpiCell[] {
  const o = raw.overview ?? {}
  const revenue = num(o.revenue) ?? num(raw.revenue)
  const orders = num(o.orders) ?? num(raw.purchases)
  const customers = num(o.customers)
  const avgOrder = num(o.avgOrderValue) ?? (revenue !== null && orders ? revenue / orders : null)

  const cells: KpiCell[] = [
    { key: 'revenue', label: 'Revenue', value: revenue, format: 'currency', change: num(o.revenueChange), commerce: true },
    { key: 'orders', label: 'Orders', value: orders, format: 'number', change: num(o.ordersChange), commerce: true },
    // The API counts distinct visitors, not customers: say which one it is.
    customers !== null
      ? { key: 'customers', label: 'Customers', value: customers, format: 'number', change: num(o.customersChange), commerce: true }
      : { key: 'visitors', label: VISITORS_LABEL, value: num(raw.uniqueVisitors), format: 'number', change: null, commerce: false, note: declinedNote(raw.declinedTracking) },
    { key: 'avg-order', label: 'Avg. order', value: avgOrder, format: 'currency', change: num(o.avgOrderValueChange), commerce: true },
    { key: 'conversion', label: 'Conversion', value: num(o.conversionRate), format: 'percent', change: num(o.conversionRateChange), commerce: true },
    { key: 'pageviews', label: 'Page views', value: num(o.pageViews) ?? num(raw.pageViews), format: 'number', change: num(o.pageViewsChange), commerce: false },
  ]
  return commerceEnabled ? cells : cells.filter((c) => !c.commerce)
}

/** The screen's date-range choices → the API's (unknown ranges silently became 7 days). */
export const API_RANGE: Record<string, string> = { today: '24h', '7d': '7d', '30d': '30d', '90d': '90d', '12m': 'year' }

/** Referrers with their real share of the total (the API gives counts only). */
export function trafficShares(referrers: ReadonlyArray<{ referrer: string; count: number }>): Array<{ source: string; visitors: number; percentage: number }> {
  const total = referrers.reduce((s, r) => s + r.count, 0)
  return referrers.map((r) => ({ source: r.referrer, visitors: r.count, percentage: total ? Math.round((r.count / total) * 1000) / 10 : 0 }))
}
