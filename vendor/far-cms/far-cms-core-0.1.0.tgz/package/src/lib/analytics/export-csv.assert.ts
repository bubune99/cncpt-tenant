/**
 * Analytics › Export downloads what the screen shows, as a spreadsheet file. Found 2026-11-22: the Export button
 * had no handler at all. Run: node_modules/.bin/tsx src/lib/analytics/export-csv.assert.ts
 */
import assert from 'node:assert/strict'
import { analyticsCsv, csvCell, exportFileName } from './export-csv'
import type { KpiCell } from './kpis'

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log('ok', n, '-', name) }
const kpi = (label: string, value: number | null, change: number | null = null): KpiCell =>
  ({ key: 'pageviews', label, value, format: 'number', change, commerce: false })

ok('a cell with a comma, quote or line break is quoted, quotes doubled', () => {
  assert.equal(csvCell('a,b'), '"a,b"')
  assert.equal(csvCell('say "hi"'), '"say ""hi"""')
  assert.equal(csvCell('two\nlines'), '"two\nlines"')
  assert.equal(csvCell(12), '12')
})
ok('a cell that a spreadsheet would run as a formula is made plain text', () => {
  assert.equal(csvCell('=HYPERLINK("x")'), `"'=HYPERLINK(""x"")"`)
  assert.equal(csvCell('+1'), "'+1")
  assert.equal(csvCell('@SUM'), "'@SUM")
})
ok('the file holds the period, each number shown, the sources and the pages', () => {
  const csv = analyticsCsv({
    period: 'Last 30 days',
    kpis: [kpi('Page views', 120, 5.5), kpi('Unique visitors', null)],
    sources: [{ source: 'google.com', visitors: 9, percentage: 75 }],
    pages: [{ url: '/about', views: 40 }],
  })
  const lines = csv.trim().split('\r\n')
  assert.equal(lines[0], 'Period,Last 30 days')
  assert.ok(lines.includes('Page views,120,5.5'))
  assert.ok(lines.includes('Unique visitors,not measured,'), 'a number not measured says so, never 0')
  assert.ok(lines.includes('google.com,9,75'))
  assert.ok(lines.includes('/about,40'))
})
ok('the file name says what and when', () => {
  assert.equal(exportFileName('Last 30 days', new Date('2026-11-22T08:00:00Z')), 'analytics-last-30-days-2026-11-22.csv')
})
console.log(`\n${n} checks passed`)
