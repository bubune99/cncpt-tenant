/**
 * Unique visitors = distinct per-tab session ids, and a session id exists
 * only for visitors who accepted Analytics (lib/privacy/consent-decision).
 *
 * Owner rule (2026-11-05): no tracking without consent. An earlier version
 * (40f7b0b2) also told visitors apart by the stored IP hash + browser, which
 * counted people who never accepted. That is reverted: the number is
 * "unique visitors who accepted analytics", labelled as such, and shown next
 * to the anonymous "declined tracking" count.
 *
 * Pure; asserted by visitors.assert.ts.
 */

export interface VisitorRow {
  sessionId: string | null
}

/** The key a row counts under, or null (no consent → no id → not counted). */
export function visitorKey(row: VisitorRow): string | null {
  return row.sessionId ? `s:${row.sessionId}` : null
}

export function countUniqueVisitors(rows: ReadonlyArray<VisitorRow>): number {
  const keys = new Set<string>()
  for (const row of rows) {
    const key = visitorKey(row)
    if (key) keys.add(key)
  }
  return keys.size
}
