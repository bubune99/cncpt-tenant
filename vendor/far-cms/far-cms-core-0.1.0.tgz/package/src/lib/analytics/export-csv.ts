/**
 * Analytics › Export: the figures on screen as a CSV file (opens in any spreadsheet). Pure; asserted by
 * export-csv.assert.ts. A number that was not measured is written as "not measured", never as 0.
 */
import type { KpiCell } from './kpis'

/** One CSV cell: quoted when it holds a comma, quote or line break; a leading = + - @ is made plain text so a
 *  spreadsheet does not run it as a formula (referrer and page addresses come from visitors). */
export function csvCell(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return ''
  let s = String(value)
  if (typeof value === 'string' && /^[=+\-@\t\r]/.test(s)) s = `'${s}`
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

const row = (cells: Array<string | number | null | undefined>) => cells.map(csvCell).join(',')

export interface AnalyticsExport {
  period: string
  kpis: ReadonlyArray<KpiCell>
  sources: ReadonlyArray<{ source: string; visitors: number; percentage: number }>
  pages: ReadonlyArray<{ url: string; views: number }>
}

export function analyticsCsv({ period, kpis, sources, pages }: AnalyticsExport): string {
  const lines = [
    row(['Period', period]),
    '',
    row(['Figure', 'Value', 'Change from last period (%)']),
    ...kpis.map((k) => row([k.label, k.value === null ? 'not measured' : k.value, k.change])),
    '',
    row(['Traffic source', 'Visitors', 'Share (%)']),
    ...sources.map((s) => row([s.source, s.visitors, s.percentage])),
    '',
    row(['Page', 'Views']),
    ...pages.map((p) => row([p.url, p.views])),
  ]
  return lines.join('\r\n') + '\r\n'
}

export function exportFileName(period: string, now: Date): string {
  const slug = period.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
  return `analytics-${slug}-${now.toISOString().slice(0, 10)}.csv`
}
