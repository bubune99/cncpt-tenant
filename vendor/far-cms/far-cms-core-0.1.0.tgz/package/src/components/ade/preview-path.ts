/**
 * Which storefront page the split-pane preview shows. Per-browser
 * convenience (localStorage), broadcast to the open preview via an event.
 */

const KEY = 'ade-preview-path';
export const PREVIEW_PATH_EVENT = 'ade:preview-path';

const BLOCKED_PREFIXES = ['/admin', '/api', '/mcp', '/handler'];

/**
 * Only same-site storefront paths: never let a stored or broadcast value
 * point the iframe (or the "open in new tab" link) off-site. Rejects
 * protocol-relative and backslash/whitespace tricks ("/\\evil.com",
 * "/\t/evil.com") that browsers resolve to another origin.
 */
export function normalizePreviewPath(value: unknown): string {
  if (typeof value !== 'string') return '/';
  const v = value.trim();
  if (!/^\/(?![\/\\])[^\s\\]*$/.test(v)) return '/';
  if (BLOCKED_PREFIXES.some((p) => v === p || v.startsWith(`${p}/`) || v.startsWith(`${p}?`))) return '/';
  if (typeof window !== 'undefined') {
    try {
      if (new URL(v, window.location.origin).origin !== window.location.origin) return '/';
    } catch {
      return '/';
    }
  }
  return v;
}

export function getPreviewPath(): string {
  try {
    return normalizePreviewPath(window.localStorage.getItem(KEY));
  } catch {
    return '/';
  }
}

export function setPreviewPath(path: string): void {
  const next = normalizePreviewPath(path);
  try {
    window.localStorage.setItem(KEY, next);
  } catch {
    /* storage blocked — the event still updates an open preview */
  }
  window.dispatchEvent(new CustomEvent(PREVIEW_PATH_EVENT, { detail: next }));
}

/** URL of the proposed render for a storefront path ('/' → the home page). */
export function proposedPathFor(path: string, setId?: string | null): string {
  const clean = path.split('?')[0].replace(/\/+$/, '')
  const base = `/ade-preview${clean === '' || clean === '/' ? '' : clean}`
  return setId ? `${base}?set=${encodeURIComponent(setId)}` : base
}
