/**
 * Assertions for the split-pane preview path filter (no off-site framing).
 * Run: npx -y tsx@4.23.15 src/components/ade/preview-path.assert.ts
 */
import { normalizePreviewPath as n } from './preview-path'
const cases: Array<[unknown, string]> = [['/about', '/about'], ['/', '/'], ['/\\evil.com', '/'], ['/\t/evil.com', '/'], ['//evil.com', '/'], ['https://evil.com', '/'], ['/admin', '/'], ['/admin/pages', '/'], ['/api/x', '/'], ['/mcp', '/'], ['/administrators', '/administrators'], ['/posts/a?b=1', '/posts/a?b=1'], [null, '/'], ['/a b', '/']]
let bad = 0
for (const [i, o] of cases) { const r = n(i); if (r !== o) { bad++; console.log('FAIL', JSON.stringify(i), r) } }
console.log(bad ? `${bad} failed` : `${cases.length} ok`)
if (bad) process.exit(1)
