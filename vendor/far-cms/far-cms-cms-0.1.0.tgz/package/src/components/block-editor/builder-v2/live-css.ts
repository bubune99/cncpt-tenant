'use client';

/**
 * The canvas's own CSS, live: the same scoped stylesheet a save stores
 * (POST /api/admin/page-css), so custom values (p-[13px], text-[#1f6f6b], 1.5rem…) and
 * steps the site stylesheet never generated show while editing. Asked for only when the
 * canvas's class set changes (debounced); on failure the canvas keeps the site stylesheet
 * and `offline` lets the shell say so quietly.
 */
import { useEffect, useRef, useState } from 'react';
import type { Block } from '../../../lib/block-editor/types';
import { classSetHash, collectPageClasses, type CssBlock } from '../../../lib/page-css/collect';
import { hasScopedShape } from '../../../lib/page-css/scope';

export const LIVE_CSS_DEBOUNCE_MS = 250;

export interface LiveCss {
  scope: string | null;
  css: string | null;
  offline: boolean;
}

export function useLiveCanvasCss(blocks: ReadonlyArray<Block>): LiveCss {
  const [live, setLive] = useState<LiveCss>({ scope: null, css: null, offline: false });
  const lastHash = useRef<string | null>(null);
  const classes = collectPageClasses(blocks as unknown as CssBlock[], {}, { renderer: false });
  const hash = classSetHash(classes);

  useEffect(() => {
    if (hash === lastHash.current) return;
    const ctrl = new AbortController();
    const t = setTimeout(async () => {
      try {
        const res = await fetch('/api/admin/page-css', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ classes }),
          signal: ctrl.signal,
        });
        if (!res.ok) throw new Error(String(res.status));
        const out = (await res.json()) as { scope?: string; css?: string };
        if (!out.scope || !out.css || !hasScopedShape(out.css, out.scope)) throw new Error('bad shape');
        lastHash.current = hash;
        setLive({ scope: out.scope, css: out.css, offline: false });
      } catch (err) {
        if ((err as Error).name === 'AbortError') return;
        setLive((l) => ({ ...l, offline: true }));
      }
    }, LIVE_CSS_DEBOUNCE_MS);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
    // `classes` is derived from the same blocks as `hash`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hash]);

  return live;
}
