'use client';

/**
 * Builder v2's movable tray tabs: the layout (lib/ade/ui/tray-dock), the drag
 * in progress, and which zones are on screen. The layout is a per-person UI
 * preference kept in this browser's localStorage — every read and write is
 * guarded, and anything unreadable falls back to the default.
 */

import { create } from 'zustand';
import {
  defaultTrayDock, normalizeTrayDock, reduceTrayDock, TRAY_DOCK_STORAGE_KEY,
  type DockAction, type DockConfig, type DockPanelId, type DockZoneId, type TrayDock,
} from '../../../../lib/ade/ui/tray-dock';

/** v2: Saved / Sections / Ideas / Outline start under the page; Style (the Design panel) starts on the right. */
export const V2_DOCK: DockConfig = { panels: ['saved', 'sections', 'ideas', 'outline', 'style'], home: 'below', homes: { style: 'right' }, first: 'sections' };
const KEY = `${TRAY_DOCK_STORAGE_KEY}.builder-v2`;

function load(): TrayDock {
  try {
    const raw = window.localStorage.getItem(KEY);
    return normalizeTrayDock(raw ? JSON.parse(raw) : null, V2_DOCK);
  } catch {
    return defaultTrayDock(V2_DOCK);
  }
}

function save(d: TrayDock): void {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(d));
  } catch {
    // Private mode / storage full: the layout just isn't remembered.
  }
}

export interface DockDrag {
  /** The tab dragged by its name — or, with `group`, the active tab of a group dragged by its grip. */
  panel: DockPanelId;
  group?: DockPanelId[];
  from: DockZoneId;
  x: number;
  y: number;
  over: DockZoneId | null;
  index: number;
}

interface DockStore {
  layout: TrayDock;
  hydrated: boolean;
  hydrate: () => void;
  dispatch: (a: DockAction) => void;
  /** Zones mounted on screen right now (a host per zone). */
  hosts: ReadonlyArray<DockZoneId>;
  setHost: (zone: DockZoneId, on: boolean) => void;
  drag: DockDrag | null;
  setDrag: (d: DockDrag | null) => void;
}

export const useTrayDock = create<DockStore>()((set, get) => ({
  layout: defaultTrayDock(V2_DOCK),
  hydrated: false,
  hydrate: () => {
    if (get().hydrated || typeof window === 'undefined') return;
    set({ layout: load(), hydrated: true });
  },
  dispatch: (a) => {
    const next = reduceTrayDock(get().layout, a, V2_DOCK);
    if (next === get().layout) return;
    set({ layout: next });
    save(next);
  },
  hosts: [],
  setHost: (zone, on) =>
    set((s) => {
      const has = s.hosts.includes(zone);
      if (has === on) return s;
      return { hosts: on ? [...s.hosts, zone] : s.hosts.filter((z) => z !== zone) };
    }),
  drag: null,
  setDrag: (drag) => set({ drag }),
}));

/** The zone elements, for the drop maths (module-level: DOM nodes don't belong in state). */
export const zoneElements = new Map<DockZoneId, HTMLElement>();
