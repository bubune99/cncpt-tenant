'use client';

/**
 * A Library card being dragged onto the canvas. The block itself can't travel in
 * dataTransfer (only strings), so the drag carries a marker type and the maker
 * waits here until the drop asks for it. Same window, one drag at a time.
 */

import type { Block } from '../../../../lib/block-editor/types';

/** Our own drag type: the old palette's types (template-id, palette-label…) stay EditorCanvas's. */
export const V2_BLOCK_DRAG = 'application/x-v2-block';

let maker: (() => Block) | null = null;

export function startLibraryDrag(e: React.DragEvent, make: () => Block): void {
  maker = make;
  e.dataTransfer.setData(V2_BLOCK_DRAG, '1');
  e.dataTransfer.effectAllowed = 'copy';
}

/** Is this drag one of ours? (types are readable during dragover; data only on drop.) */
export const isLibraryDrag = (e: DragEvent): boolean => !!maker && Array.from(e.dataTransfer?.types ?? []).includes(V2_BLOCK_DRAG);

/** The dragged block, minted fresh once, and the drag cleared. */
export function takeLibraryBlock(): Block | null {
  const make = maker;
  maker = null;
  return make ? make() : null;
}

export function endLibraryDrag(): void {
  maker = null;
}
