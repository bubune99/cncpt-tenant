'use client';

/**
 * Builder v2 → the REAL assistant: fill its composer with a request about the selected
 * block, the block attached as a reference chip. Never sends (owner 2026-10-18).
 */

import { askAssistant } from '../../../ade/workspace/ask';
import { REF_MARKERS } from '../../../ade/workspace/pick-mode';
import { snapshotElement } from '../../../../lib/ade/chat/capture';
import { toUnitRef } from '../../../../lib/ade/chat/references';
import { askText, type AskInput } from '../../../../lib/ade/blocks/ask-assistant';

export function askKofiAbout(blockId: string, input: AskInput): void {
  const el = typeof document === 'undefined' ? null : document.querySelector(`[data-block-id="${CSS.escape(blockId)}"]`);
  const ref = el ? toUnitRef(snapshotElement(el, REF_MARKERS, window.location.pathname, true), REF_MARKERS, input.blockName) : null;
  askAssistant(askText(input), { send: false, ...(ref ? { refs: [ref] } : {}) });
}
