'use client'

/**
 * Maps the admin CMS `/api/chat` stream onto the shared chat panel view-model,
 * so the admin assistant renders with the same design as the page builder.
 *
 * Mapping:
 *   reasoning            -> thinking
 *   text                 -> text
 *   approval-requested   -> approval part (governance needsApproval)
 *   drafted / recorded   -> the message's change widgets (changes: metadata, else its parts),
 *                           only for a stored change record; never from the tool's words
 *   navigation           -> nav chip (the spotlight interceptor navigates)
 *   spotlight / reveal   -> the message's "Pointed at …" widget (spots: metadata, else its parts)
 *   read/search tools    -> skipped (the agent narrates results as text)
 *   every tool call      -> the message's thought chain (with the plan, carried across messages)
 */

import { statusBadge } from '../../../lib/ade/ui/status-badge'
import { isToolUIPart, type UIMessage } from 'ai'
import type { ChatMessageVM, ChatPart, EntityRow, StatRow } from './types'
import { messageRunId } from '../../../lib/ade-bindings/agent-activity'
import { READING_SCREEN, awaitingBrowser, declinedAck, incompleteRunLine, needsNoAnswerFallback } from '../../../lib/ai/step-plan'
import { showUnitFallbackLine } from '../../../lib/ade/ui/control'
import { dropSpotNarration, spotsFromMetadata, spotsFromParts } from '../../../lib/ade/ui/spots'
import { dropSelfCorrections, partsBringFacts } from '../../../lib/ade/chat/settled-history'
import { changeRefsFromMetadata, changeRefsFromOutput, changeRefsFromParts } from '../../../lib/ade/chat/change-widgets'
import { NAV_AREAS } from '../../../lib/ade-bindings/nav-areas'
import { sendOutcome } from '../../../lib/ade/mobile/approval'
import { buildChain } from '../../../lib/ade/chat/thought-chain'
import type { Plan } from '../../../lib/ade/chat/plan'
import { CHAIN_STEP_DEPS } from '../../../lib/ade-bindings/chain-steps'
import { ASK_TOOL, askFormFromOutput, askStatuses } from '../../../lib/ade/chat/ask-form'

const toolName = (t: string) => t.replace(/^tool-/, '')

function humanize(name: string): string {
  return name.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase()).trim()
}

const money = (cents: unknown) =>
  typeof cents === 'number' ? `$${(cents / 100).toFixed(2)}` : ''

/**
 * Map a read/search/navigation tool result to a rich widget part.
 * Returns null when the output has no card-worthy shape (agent narrates it).
 */
function widgetFor(id: string, name: string, out: Record<string, unknown>): ChatPart | null {
  // Navigation + spotlight tools (client-executed): render a confirmation chip.
  if (name === 'navigate_to_route' || name === 'navigateTo') {
    const args = (out.arguments as Record<string, unknown>) || {}
    const path = String(args.path ?? out.path ?? '')
    return path ? { id, kind: 'nav', path } : null
  }
  // spotlight_steps: shown as the message's "Pointed at …" widget (spots); its "Take me there" offer
  // (lib/ade/assistant/pointing, set by code) is the quiet nav link — a real action, not words.
  if (name === 'spotlight_steps') {
    const offer = out.offer as { path?: unknown; label?: unknown } | undefined
    const path = typeof offer?.path === 'string' && /^\/admin(?:[/?]|$)/.test(offer.path) ? offer.path : null
    return path ? { id, kind: 'nav', path, label: typeof offer?.label === 'string' ? offer.label : 'Take me there' } : null
  }

  // Search results → entity list cards.
  if (Array.isArray(out.products)) {
    const items: EntityRow[] = (out.products as Array<Record<string, unknown>>).map((p) => ({
      id: String(p.id),
      title: String(p.title ?? p.id),
      subtitle: p.sku ? `SKU ${p.sku}` : undefined,
      meta: typeof p.price === 'number' ? `$${p.price.toFixed(2)}` : undefined,
      badge: statusBadge(p.status),
      href: p.adminUrl ? String(p.adminUrl) : undefined,
    }))
    return { id, kind: 'entities', title: 'Products', count: Number(out.count ?? items.length), items }
  }
  if (Array.isArray(out.orders)) {
    const items: EntityRow[] = (out.orders as Array<Record<string, unknown>>).map((o) => ({
      id: String(o.id),
      title: o.orderNumber ? `#${o.orderNumber}` : String(o.id),
      subtitle: o.email ? String(o.email) : undefined,
      meta: money(o.total),
      badge: statusBadge(o.status),
      href: o.adminUrl ? String(o.adminUrl) : undefined,
    }))
    return { id, kind: 'entities', title: 'Orders', count: Number(out.count ?? items.length), items }
  }
  if (Array.isArray(out.results) && out.results.length > 0 && typeof out.results[0] === 'object') {
    // Rows with nothing to show (no name, no link) are noise — e.g. a settings hit that rendered "Setting · 1 result · —".
    const items: EntityRow[] = (out.results as Array<Record<string, unknown>>).flatMap((r, i) => {
      const name = r.title ?? r.name ?? r.label ?? r.email ?? r.orderNumber
      if ((name === undefined || name === null || String(name).trim() === '') && !r.adminUrl) return []
      return [{
        id: String(r.id ?? i),
        title: String(name ?? r.id ?? 'Untitled'),
        subtitle: r.email && r.name ? String(r.email) : r.slug ? String(r.slug) : undefined,
        badge: statusBadge(r.status),
        href: r.adminUrl ? String(r.adminUrl) : undefined,
      }]
    })
    // No card at all rather than an empty one.
    if (items.length === 0) return null
    return { id, kind: 'entities', title: String(out.entityType ? humanize(String(out.entityType)) : 'Results'), count: Number(out.count ?? items.length), items }
  }

  // Dashboard stats → metric grid.
  if (name === 'getDashboardStats' && typeof out.orders !== 'undefined') {
    const stats: StatRow[] = [
      { label: 'Orders', value: String(out.orders ?? 0) },
      { label: 'Revenue', value: money(out.revenue) || '$0.00' },
      { label: 'Active products', value: String(out.activeProducts ?? 0) },
      { label: 'Total users', value: String(out.totalUsers ?? 0) },
    ]
    return { id, kind: 'stats', title: `Stats · this ${String(out.period ?? 'month')}`, stats }
  }

  return null
}

export interface AdminMapOpts {
  openThinking: Set<string>
  /** A request is in flight (submitted / streaming): the last message may still be continuing. */
  busy?: boolean
}

export function mapAdminMessages(messages: UIMessage[], opts: AdminMapOpts): ChatMessageVM[] {
  // While a continuation streams, the last message still carries the previous request's
  // finishReason: it must not show the incomplete-run line before the real answer arrives.
  const continuingId = opts.busy ? messages[messages.length - 1]?.id : undefined
  // The plan is code-held state across the conversation: each reply's chain starts from the one before.
  let plan: Plan | null = null
  // Question forms: open, answered (their answers message folds into the form's "Your answers" line, so it
  // isn't shown again as a bubble) or passed (lib/ade/chat/ask-form).
  const asks = askStatuses(messages as never)
  const answerMessages = new Set([...asks.values()].flatMap((a) => (a.state === 'answered' && a.messageId ? [a.messageId] : [])))
  // A restored turn that only ran tools (lib/ade/chat/history restoreMessages) is
  // hidden: its short note is for the model, not the person.
  return messages.filter((msg) => !(msg.metadata as { toolTurn?: unknown } | undefined)?.toolTurn && !answerMessages.has(msg.id)).map((msg) => {
    const id = msg.id
    const parts = (msg.parts || []) as Array<Record<string, unknown>>

    if (msg.role === 'user') {
      const texts = parts.filter((p) => p.type === 'text').map((p) => String(p.text || ''))
      // With attachments / references, the typed words are the last text part;
      // the rest (file text, reference details) shows as chips.
      const chips = (msg.metadata as { chips?: Array<{ label: string }> } | undefined)?.chips
      if (chips?.length) {
        return { id, role: 'user', text: texts[texts.length - 1] ?? '', chips: chips.map((c, i) => ({ id: `${id}-c${i}`, label: c.label, tag: c.label })) }
      }
      return { id, role: 'user', text: texts.join('') }
    }
    if (msg.role !== 'assistant') return { id, role: 'system', text: '' }

    const tail: ChatPart[] = []
    const approvals: ChatPart[] = []
    // The server says when this turn read outside text (every change then asks): shown on its cards.
    const taintReason = (msg.metadata as { taint?: { reason?: unknown } } | undefined)?.taint?.reason
    const taintReasonText = typeof taintReason === 'string' ? taintReason.slice(0, 200) : undefined
    let thinkAccum = ''

    parts.forEach((p, i) => {
      const type = String(p.type || '')
      if (type === 'reasoning') { thinkAccum += String(p.text || ''); return }
      if (type === 'text') {
        const t = String(p.text || '').trim()
        // The same paragraph twice in one reply (a forced tool step, then the answer repeating it) shows once.
        if (t && !tail.some((x) => x.kind === 'text' && x.text === t)) tail.push({ id: `${id}-t${i}`, kind: 'text', text: t })
        return
      }
      if (isToolUIPart(p as never)) {
        const rec = p as Record<string, unknown>
        const name = toolName(type)
        const state = String(rec.state || '')
        // The card stays (resolved) once it is answered — and once the server has settled a "no" (output-denied).
        if (state === 'approval-requested' || state === 'approval-responded' || state === 'output-denied') {
          // addToolApprovalResponse matches on approval.id (NOT toolCallId) — see AI SDK v6.
          const approval = (rec.approval as { id?: string; approved?: boolean } | undefined) || {}
          approvals.push({
            id: `${id}-ap-${rec.toolCallId}`,
            kind: 'approval',
            toolCallId: String(rec.toolCallId || ''),
            approvalId: approval.id ? String(approval.id) : undefined,
            toolName: name,
            input: (rec.input as Record<string, unknown>) || {},
            resolved: state === 'output-denied' ? 'denied' : state === 'approval-responded' ? (approval.approved ? 'approved' : 'denied') : undefined,
            ...(taintReasonText ? { reason: taintReasonText } : {}),
          })
          return
        }
        if (state === 'output-available') {
          const out = (rec.output as Record<string, unknown>) || {}
          // The question form: one per reply, rendered from its checked result.
          if (name === ASK_TOOL) {
            const form = askFormFromOutput(out)
            const status = asks.get(String(rec.toolCallId || ''))
            if (form && status && !tail.some((t) => t.kind === 'ask')) tail.push({ id: `${id}-ask${i}`, kind: 'ask', formId: String(rec.toolCallId), form, status })
            return
          }
          // An approved send says what happened (sent / not sent and why), whatever the agent says next.
          const outcome = sendOutcome(name, out)
          if (outcome) { tail.push({ id: `${id}-send${i}`, kind: 'text', text: outcome.text }); return }
          // A stored change (drafted or recorded) → the message's change widgets, below.
          if (changeRefsFromOutput(out).length) return
          // Read/search/navigation tools: render a rich widget when the
          // output has a card-worthy shape; otherwise the agent narrates it.
          const widget = widgetFor(`${id}-w${i}`, name, out)
          if (widget) tail.push(widget)
        }
      }
    })

    // Its steps and plan, from what the run really did (lib/ade/chat/thought-chain).
    const built = buildChain({ parts, planBefore: plan, busy: id === continuingId, deps: CHAIN_STEP_DEPS, idPrefix: `${id}-` })
    plan = built.planAfter

    const partsOut: ChatPart[] = []
    if (thinkAccum.trim()) partsOut.push({ id: `${id}-think`, kind: 'thinking', text: thinkAccum, open: opts.openThinking.has(`${id}-think`) })
    partsOut.push(...approvals)
    partsOut.push(...tail)
    // Cut off by the step / budget cap with nothing said: say so instead of a blank reply.
    // Paused while the browser reads the screen (same finishReason): a quiet line, not the fallback.
    const finishReason = (msg.metadata as { finishReason?: unknown } | undefined)?.finishReason
    const capped = (msg.metadata as { capped?: unknown } | undefined)?.capped
    // A plan shown first is waiting for Go — not an unfinished run.
    if (id !== continuingId && built.chain?.phase !== 'proposed' && needsNoAnswerFallback(parts as Array<{ type: string }>, finishReason, capped)) {
      // What was done, what is left, the manual path — from the chain's recorded steps.
      const steps = built.chain?.steps ?? []
      const text = incompleteRunLine({
        done: steps.filter((s) => s.state === 'done').map((s) => s.title),
        left: steps.filter((s) => s.state === 'current' || s.state === 'ahead' || s.state === 'needs-you').map((s) => s.title),
        manual: built.chain?.problem?.manual,
      })
      partsOut.push({ id: `${id}-fallback`, kind: 'text', text })
    } else if (awaitingBrowser(parts as Array<{ type: string }>, finishReason)) {
      partsOut.push({ id: `${id}-reading`, kind: 'text', text: READING_SCREEN })
    }
    // A where-is answer the model left wordless gets one line from code (staging 81b58185 P3).
    const pointed = id !== continuingId ? showUnitFallbackLine(parts) : null
    if (pointed) partsOut.push({ id: `${id}-pointed`, kind: 'text', text: pointed })
    // A declined card closes the turn with a short line when the model said nothing after it.
    const ack = declinedAck(parts as Array<{ type: string }>)
    if (ack) partsOut.push({ id: `${id}-declined`, kind: 'text', text: ack })

    // What it pointed at: kept on the metadata (survives reloads), else read from this session's parts.
    const spots = spotsFromMetadata(msg.metadata) ?? spotsFromParts(parts, null, NAV_AREAS)
    // What it changed: kept on the metadata (survives reloads), else this session's tool results.
    const changes = changeRefsFromMetadata(msg.metadata) ?? changeRefsFromParts(parts)
    // The model's words: beside a "Pointed at …" row they never narrate the pointing ("I've pointed at it again"),
    // and a reply whose own tools brought no new facts never opens a paragraph by correcting earlier turns
    // (lib/ade/chat/settled-history; staging 73a8d81b).
    const freshFacts = partsBringFacts(parts)
    const shownParts = partsOut.flatMap((p) => {
      if (p.kind !== 'text' || !p.id.startsWith(`${id}-t`)) return [p]
      const text = dropSelfCorrections(spots ? dropSpotNarration(p.text) : p.text, freshFacts)
      return text ? [{ ...p, text }] : []
    })
    // How long the run took (1a header / fold line): the server's start / finish stamps on the reply.
    const meta = (msg.metadata ?? {}) as { startedAt?: unknown; finishedAt?: unknown }
    const timing = {
      ...(typeof meta.startedAt === 'number' ? { startedAt: meta.startedAt } : {}),
      ...(typeof meta.finishedAt === 'number' ? { finishedAt: meta.finishedAt } : {}),
    }
    const chain = built.chain && timing.startedAt !== undefined ? { ...built.chain, timing } : built.chain
    return { id, role: 'assistant', parts: shownParts, runId: messageRunId(msg), spots, changes, chain }
  })
}
