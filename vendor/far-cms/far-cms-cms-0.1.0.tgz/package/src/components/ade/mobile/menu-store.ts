'use client';

/**
 * The admin menu as this person may see it (AdminShell computes it: module
 * nav + RBAC + relabels), shared with the phone's Manage hub so both list
 * exactly the same areas.
 */

import { create } from 'zustand';
import type { MenuGroupIn } from '../../../lib/ade/mobile/nav';

interface MenuState {
  groups: MenuGroupIn[];
  /** False until permissions have loaded (no flash of areas this person can't open). */
  ready: boolean;
  setMenu: (groups: MenuGroupIn[], ready: boolean) => void;
}

export const useAdminMenu = create<MenuState>()((set) => ({
  groups: [],
  ready: false,
  setMenu: (groups, ready) => set({ groups, ready }),
}));
