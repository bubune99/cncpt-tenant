'use client';

/**
 * Coverage check, in the browser: walk the screen in front of the person
 * (read-only reveals from read_view's navigation tools — never saves), map
 * it to the platform with the same findAction the assistant uses, classify,
 * store the result (coverage data + one To-do item; nothing on the site),
 * and optionally play the walk-through of one hidden control.
 */

import { readView, readViewFresh, revealUnit, UNIT_ATTR } from '../../../lib/ade/ui/view-dom';
import { walkPlan, type ViewUnit } from '../../../lib/ade/ui/view-units';
import { VIEW_MARKERS } from '../../../lib/ade-bindings/view-markers';
import { runRevealAction } from '../../../lib/ai/client-tool-handlers';
import { findAction, type PlatformEntry } from '../../../lib/ade/platform-map';
import { coverageReportNote, coverageSentence, privateRow, type PlatformAction, type TourStep } from '../../../lib/ade/coverage/logic';
import { safeLabel } from '../../../lib/ade/coverage/walk';
import { runScreenCoverage, type ScreenCoverage } from '../../../lib/ade/coverage/run';
import type { ReadViewLike, ViewUnitLike, WalkStepLike } from '../../../lib/ade/coverage/walk';
import { platformMatcher, type FindAction } from '../../../lib/ade-bindings/coverage-platform';
import { routeIsBlocked } from '../../../lib/ade-bindings/view-policy-source';
import { useSpotlightStore } from '../../../stores/spotlight-store';

interface PlatformInfo {
  entry: PlatformEntry | null;
  actions: PlatformAction[];
  toolNames: string[];
  sweepRoutes: string[];
}

export async function fetchPlatformInfo(route: string): Promise<PlatformInfo> {
  const res = await fetch(`/api/admin/ade/coverage/platform?route=${encodeURIComponent(route)}`, { cache: 'no-store' });
  const j = await res.json().catch(() => null);
  if (!j?.success) throw new Error(j?.error || `Couldn't load the platform map (${res.status})`);
  return j as PlatformInfo;
}

/**
 * Units inside the site canvas are the site's content (a page's blocks, a form's own
 * fields and its Send button), not controls of the admin: the walk never sees them.
 */
function withoutCanvas(units: ViewUnit[]): ViewUnit[] {
  return units
    .filter((u) => !document.querySelector(`[${UNIT_ATTR}="${u.id}"]`)?.closest(`[${VIEW_MARKERS.canvas}]`))
    .map((u) => (u.children ? { ...u, children: withoutCanvas(u.children) } : u));
}

const asView = (v: { ok: boolean; route?: string; units?: ViewUnit[] }): ReadViewLike => ({ ok: v.ok, route: v.route ?? window.location.pathname, units: withoutCanvas(v.units ?? []) as unknown as ViewUnitLike[] });

export interface CoverageRun extends ScreenCoverage {
  sentence: string;
  saved: boolean;
  /** The agent may not read this route: nothing was read; stored as "private (not checked)". */
  private?: boolean;
  /** Parts of the screen (sections, tabs) the visibility rules keep private: not read, not checked. */
  privateParts?: string[];
  /** The screen's coverage report (its To-do item), when the server saved one. */
  reportHref?: string;
}

// ---------------------------------------------------------------------------
// Visibility policy hook (governance): by default the app's visibility rules
// (the screen tools' cached rules; strictest view when they can't load). A
// blocked route is never read — not even walked — and is reported as
// "private (not checked)".
// ---------------------------------------------------------------------------

/** Gets pathname + search (?section=mcp can be blocked when /admin/settings isn't). */
export type CoverageRoutePolicy = (url: string) => boolean | Promise<boolean>;
let routeBlocked: CoverageRoutePolicy = routeIsBlocked;

/** Replace the "is this route blocked for the agent?" check; null restores the app's rules (never "allow all"). */
export function setCoverageRoutePolicy(fn: CoverageRoutePolicy | null): void {
  routeBlocked = fn ?? routeIsBlocked;
}

/** A read the policy refused (the screen tools return private:true and stamp nothing). */
class PrivateScreen extends Error {}

async function privateRun(route: string): Promise<CoverageRun> {
  const row = privateRow(route, new Date().toISOString());
  const { saved } = await postRow({ row });
  return {
    private: true,
    saved,
    sentence: coverageSentence(row),
    row,
    result: { route: row.route, mapped: [], toolGaps: [], uiGaps: [], hiddenOnly: [] },
    units: [],
    tour: null,
    needsStableTarget: [],
    walk: { steps: 0, truncated: false, failed: [] },
  };
}

async function postRow(body: unknown): Promise<{ saved: boolean; href?: string }> {
  const res = await fetch('/api/admin/ade/coverage', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).catch(() => null);
  if (!res?.ok) return { saved: false };
  const j = (await res.json().catch(() => null)) as { href?: unknown } | null;
  return { saved: true, ...(typeof j?.href === 'string' ? { href: j.href } : {}) };
}

/** No size cap: the walk must see every section (nothing here goes to the model). */
const WHOLE_SCREEN = { maxChars: Number.POSITIVE_INFINITY };

/** Run the check on the screen that is open now. Read-only on the site. */
export async function runCoverageHere(opts: { maxSteps?: number } = {}): Promise<CoverageRun> {
  const route = window.location.pathname;
  if (await routeBlocked(route + window.location.search)) return privateRun(route);
  const info = await fetchPlatformInfo(route);
  const read = async () => {
    const out = await readViewFresh(VIEW_MARKERS, WHOLE_SCREEN);
    // The policy can also refuse at read time (its rules changed since the route check).
    if (out.private) throw new PrivateScreen();
    return asView(out);
  };
  const privateParts: string[] = [];
  let cov: ScreenCoverage;
  try {
    cov = await runScreenCoverage({
      // Settled + route-checked: never the previous screen during a sweep.
      // The whole tree: read_view's size cap (for the model) would drop sections.
      read,
      plan: (units) => walkPlan(units as unknown as ViewUnit[]) as unknown as WalkStepLike[],
      act: async (step) => {
        // After a private section's read nothing is stamped: find the control again by its stable selector.
        if (step.stable && !document.querySelector(`[${UNIT_ATTR}="${step.unit}"]`)) document.querySelector(step.stable)?.setAttribute(UNIT_ATTR, step.unit);
        // The reveal itself, then ONE settled read of the whole screen (the reveal tool's own
        // capped read would double every step's wait on a screen that keeps changing).
        const r = await revealUnit(step.action, step.unit, VIEW_MARKERS);
        if (!r.ok) return { ok: false };
        // A reveal that lands on a blocked section: that step is skipped (listed as failed), the rest of the screen stands.
        const after = await readViewFresh(VIEW_MARKERS, WHOLE_SCREEN);
        if (after.private) privateParts.push(safeLabel(step.label));
        return { ok: !after.private, view: after.private ? { ok: false, route, units: [] } : asView(after) };
      },
      maxSteps: opts.maxSteps,
      actionsFor: () => info.actions,
      matcherFor: (_r, actions) => platformMatcher(info.entry, findAction as unknown as FindAction, actions),
      toolNames: new Set(info.toolNames),
    });
  } catch (e) {
    if (e instanceof PrivateScreen) return privateRun(route);
    throw e;
  }
  // Put the screen back the way it was (menus closed).
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  // Stored: control labels, roles, routes and selectors only (never values, cells or copy).
  const { saved, href } = await postRow({ row: cov.row, units: cov.units, tour: cov.tour });
  // Private parts were skipped on purpose — they are not failures.
  const walk = { ...cov.walk, failed: cov.walk.failed.filter((l) => !privateParts.includes(safeLabel(l))) };
  return { ...cov, walk, sentence: coverageSentence(cov.row), saved, ...(href ? { reportHref: href } : {}), ...(privateParts.length ? { privateParts } : {}) };
}

const REVEAL: Record<string, 'open_tab' | 'expand' | 'open_menu' | 'scroll_to'> = { 'open-tab': 'open_tab', expand: 'expand', 'open-menu': 'open_menu', scroll: 'scroll_to', 'open-panel': 'expand', click: 'expand' };

/**
 * Play a walk-through: perform each reveal for real (view-only, spotlit with
 * its caption by the reveal tool), then spotlight the control itself.
 */
export async function playTour(steps: ReadonlyArray<TourStep>): Promise<{ ok: boolean; failed?: string }> {
  for (const step of steps) {
    const reveal = step.meta?.reveal;
    if (!reveal) {
      useSpotlightStore.getState().enqueueAll([{ target: step.target, tooltip: { content: step.caption, position: step.position ?? 'auto' } }], { intent: 'teach' });
      continue;
    }
    readView(VIEW_MARKERS); // stamp fresh ids
    const el = document.querySelector(reveal.target) as HTMLElement | null;
    const id = el?.getAttribute(UNIT_ATTR);
    if (!id) return { ok: false, failed: reveal.label };
    const r = await runRevealAction(REVEAL[reveal.action] ?? 'expand', id, { spotlight: true });
    if (!r.ok) return { ok: false, failed: reveal.label };
    await new Promise((res) => window.setTimeout(res, 900));
  }
  return { ok: true };
}

/** The compact answer the assistant gets (the full detail is stored). */
export function coverageForModel(run: CoverageRun) {
  const cap = (xs: string[]) => xs.slice(0, 15).map(safeLabel);
  if (run.private) return { ok: true, route: run.row.route, private: true, summary: run.sentence, note: 'This screen is private to the assistant (visibility policy): it was not read or checked.' };
  return {
    ok: true,
    route: run.row.route,
    summary: run.sentence,
    noToolFor: cap(run.row.toolGaps),
    toolButNotOnScreen: cap(run.row.uiGaps),
    onlyThroughHiddenUi: cap(run.row.hiddenOnly),
    needsDataUiForTours: cap(run.needsStableTarget),
    walk: {
      steps: run.walk.steps,
      truncated: run.walk.truncated,
      failed: cap(run.walk.failed),
      // Why a screen was slow (a list that keeps changing never settles): the reveals that took longest.
      ...(run.walk.outOfTime ? { outOfTime: true } : {}),
      ...(run.walk.slow?.length ? { slowest: [...run.walk.slow].sort((a, b) => b.ms - a.ms).slice(0, 5).map((x) => `${safeLabel(x.label)} (${Math.round(x.ms / 100) / 10} s)`) } : {}),
    },
    ...(run.privateParts?.length ? { privateNotChecked: cap(run.privateParts) } : {}),
    tour: run.tour ? { title: run.tour.title, steps: run.tour.steps.map((s) => s.caption) } : null,
    saved: run.saved,
    ...coverageReportNote(run.reportHref),
  };
}
