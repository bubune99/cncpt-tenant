'use client';

/**
 * The one way layout prefs are saved (sidebar mode, dock side, widths,
 * dividers, dock zones) — skipped inside a Preview sizes frame, so a capture
 * never changes how the person's own admin looks (lib/ade/ui/preview-sizes
 * layoutWriteAllowed). The preview-only layout override lives here too.
 */

import { layoutWriteAllowed, previewFrameNow } from '../../../lib/ade/ui/preview-sizes';
import { parseLayoutOverride, type AdminLayoutOverride } from '../../../lib/ade/ui/dock-side';
import { stagingToolsEnabled } from '../../../lib/ade/staging-tools';

export function canWriteLayout(): boolean {
  return layoutWriteAllowed(previewFrameNow());
}

/** PUT /api/admin/ade/prefs — a no-op in a preview frame. */
export function putLayoutPref(body: Record<string, unknown>): Promise<Response | void> {
  if (!canWriteLayout()) return Promise.resolve();
  return fetch('/api/admin/ade/prefs', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).catch(() => undefined);
}

let cached: { search: string; value: AdminLayoutOverride | null } | null = null;

/** ?ade=classic|workspace / ?ade-side=left|right — only in a preview frame (else null). */
export function layoutOverride(): AdminLayoutOverride | null {
  if (typeof window === 'undefined') return null;
  if (cached?.search === window.location.search) return cached.value;
  // Staging only (lib/ade/staging-tools): in production ?ade= / ?ade-side= mean nothing.
  const value = parseLayoutOverride(window.location.search, stagingToolsEnabled() && previewFrameNow());
  cached = { search: window.location.search, value };
  return value;
}
