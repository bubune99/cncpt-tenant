'use client';

/**
 * The attention controller's store: one state per screen (lib/ade/ui/attention),
 * mirrored on the root as `data-attention="idle|highlight|spotlight"`.
 *
 * Callers:
 *   - the spotlight store asks `gateSpotlight` before it opens anything
 *     (a "where is X" or anything inside a fill becomes a highlight);
 *   - a fill calls `attention.work(target)` / `attention.workDone(target)`;
 *   - the chat calls `attention.runStart(text)` / `attention.runEnd()`.
 * The spotlight store registers how to close itself (`registerSpotlightCloser`),
 * so this module never imports it (no cycle).
 */

import { create } from 'zustand';
import { attentionMode, IDLE, reduceAttention, type AttentionEvent, type AttentionIntent, type AttentionState, type Channel } from '../../../lib/ade/ui/attention';

export const useAttention = create<AttentionState>()(() => IDLE);

let closeSpotlight: (() => void) | null = null;
let flashTimer = 0;

/** The spotlight store hands over how to close itself (called once at its module load). */
export function registerSpotlightCloser(fn: () => void): void {
  closeSpotlight = fn;
}

function syncRoot(s: AttentionState) {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.attention = attentionMode(s);
}

function dispatch(e: AttentionEvent): Channel | undefined {
  const r = reduceAttention(useAttention.getState(), e);
  useAttention.setState(r.state, true);
  syncRoot(r.state);
  if (r.closeSpotlight) closeSpotlight?.();
  return r.channel;
}

/**
 * Before the spotlight store opens a set: spotlight, or a highlight instead.
 * Returns 'spotlight' only when the store should go ahead.
 */
export function gateSpotlight(id: string, steps: ReadonlyArray<{ target: string; title?: string; label?: string }>, opts?: { intent?: AttentionIntent; commit?: boolean; waitId?: string }): Channel {
  return dispatch({ type: 'spotlight.request', id, steps, intent: opts?.intent ?? null, commit: opts?.commit, waitId: opts?.waitId }) ?? 'highlight';
}

export const attention = {
  /** The person sent a message: a new run (no spotlight survives it); their words set the intent. */
  runStart: (ask?: string | null) => void dispatch({ type: 'run.start', ask }),
  /** The reply finished: no spotlight left behind unless it is teaching (waiting for Got it). */
  runEnd: () => void dispatch({ type: 'run.end' }),
  /** Kofi is about to type into this field: close any spotlight, show the working ring. */
  work: (target: string) => void dispatch({ type: 'work.start', target }),
  /** The field landed: the ring goes (the page's KOFI mark takes over). */
  workDone: (target: string) => void dispatch({ type: 'work.done', target }),
  /** The spotlight closed (Got it, Esc, the scrim, the run). */
  spotlightClosed: () => void dispatch({ type: 'spotlight.closed' }),
  /** A brief cue the app raises itself (no run, no report): rings on `targets` for `ms`. */
  flash: (targets: ReadonlyArray<string>, ms: number) => {
    window.clearTimeout(flashTimer);
    dispatch({ type: 'flash', targets });
    flashTimer = window.setTimeout(() => void dispatch({ type: 'rings.clear', kind: 'flash' }), ms);
  },
  /** The person moved on: finding rings go. */
  clearLocate: () => void dispatch({ type: 'rings.clear', kind: 'locate' }),
  reset: () => {
    useAttention.setState(IDLE, true);
    syncRoot(IDLE);
  },
};
