/**
 * The assistant briefing as data — pure; asserted by briefing-rows.assert.ts.
 *
 * Open To-do tasks become rows the person can act on. How each task source
 * looks (dot tone, buttons, whether same-source tasks merge into one row) is
 * app data (lib/ade-bindings/app-config briefingTasks); anything unlisted gets
 * an "Open" link. The sentence counts the same things the rows show, so the
 * briefing and the dashboard never disagree.
 */

import type { BriefingAction, BriefingTaskStyle } from '../../../lib/ade-bindings/app-config'

export interface BriefingTaskInput {
  id: string
  kind: 'task' | 'approval'
  lane: string
  title: string
  detail: string | null
  href: string | null
  priority?: number
  source?: string
}

export interface BriefingButton {
  label: string
  primary: boolean
  href?: string
  ask?: string
}

export interface BriefingRow {
  key: string
  tone: 'accent' | 'bad' | 'warn'
  title: string
  detail: string | null
  buttons: BriefingButton[]
}

const NUM = ['No', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten']

const quoted = (title: string) => title.match(/[“"](.+?)[”"]/)?.[1] ?? title
const fill = (t: string, row: { title: string; detail: string | null }) => t.replace('{title}', row.title).replace('{detail}', row.detail ?? '').replace(/\s*\(\)/, '')

function buttonsFor(actions: ReadonlyArray<BriefingAction>, row: { title: string; detail: string | null }, href: string | null): BriefingButton[] {
  const out: BriefingButton[] = []
  for (const a of actions) {
    if (a.ask) out.push({ label: a.label, primary: !!a.primary, ask: fill(a.ask, row) })
    else if (a.to === 'task') {
      if (href) out.push({ label: a.label, primary: !!a.primary, href })
    } else if (a.to) out.push({ label: a.label, primary: !!a.primary, href: a.to })
  }
  return out
}

/** Open tasks → rows (merged by source where the app says so), most urgent first, at most `limit`. */
export function briefingRows(items: ReadonlyArray<BriefingTaskInput>, styles: Readonly<Record<string, BriefingTaskStyle>> = {}, limit = 3): BriefingRow[] {
  const open = items.filter((i) => i.kind === 'task' && i.lane !== 'done')
  const rows: Array<BriefingRow & { rank: number }> = []
  const merged = new Map<string, BriefingTaskInput[]>()
  for (const t of open) {
    const style = t.source ? styles[t.source] : undefined
    if (style?.merge && t.source) {
      merged.set(t.source, [...(merged.get(t.source) ?? []), t])
      continue
    }
    const row = { title: t.title, detail: t.detail }
    rows.push({
      key: t.id,
      tone: style?.tone ?? (t.priority !== undefined && t.priority <= 1 ? 'bad' : 'accent'),
      ...row,
      buttons: style ? buttonsFor(style.actions, row, t.href) : t.href ? [{ label: 'Open', primary: false, href: t.href }] : [],
      rank: t.priority ?? 2,
    })
  }
  for (const [source, list] of merged) {
    const style = styles[source]
    const n = list.length
    const title = (n === 1 ? style.merge!.one : style.merge!.many).replace('{n}', String(n))
    const row = { title, detail: list.map((t) => quoted(t.title)).join(' · ') }
    rows.push({ key: `merged:${source}`, tone: style.tone, ...row, buttons: buttonsFor(style.actions, row, list[0].href), rank: Math.min(...list.map((t) => t.priority ?? 3)) })
  }
  return rows
    .sort((a, b) => a.rank - b.rank)
    .slice(0, limit)
    .map(({ rank: _rank, ...r }) => r)
}

/** One count for every "what needs you" number: the headline, the tiles and the To-do badge (owner 2026-10-17). */
export interface BriefingCounts {
  /** Changes waiting for approval (not parked with "Not now"). */
  approvals: number
  needsLook: number
  drafts: number
  messages: number
  /** Everything else open that needs the person: needs a look + drafts + messages. */
  toLook: number
}

export function briefingCounts(items: ReadonlyArray<{ kind: string; lane: string; targetGone?: boolean }>): BriefingCounts {
  // An approval whose page/record was deleted can only be discarded: it stays in the list, out of the count.
  const approvals = items.filter((i) => i.kind === 'approval' && i.lane === 'approve' && !i.targetGone).length
  const needsLook = items.filter((i) => i.kind === 'task' && i.lane === 'attention').length
  const drafts = items.filter((i) => i.lane === 'drafts').length
  const messages = items.filter((i) => i.lane === 'messages').length
  return { approvals, needsLook, drafts, messages, toLook: needsLook + drafts + messages }
}

/** "Good evening, Bubune. 4 changes to approve, 7 things to look at." — split by kind, from briefingCounts. */
export function briefingHeadline(name: string | null, hour: number, approvals: number, toLook: number): string {
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'
  const hello = name ? `${greet}, ${name}.` : `${greet}.`
  if (!approvals && !toLook) return `${hello} Nothing is waiting on you. What would you like to do?`
  return `${hello} ${briefingCountsLine(approvals, toLook)}`
}

/** "4 changes to approve, 10 things to look at." — the counts part alone (the walk-through starts with it). */
export function briefingCountsLine(approvals: number, toLook: number): string {
  if (!approvals && !toLook) return 'Nothing is waiting on you.'
  const bits: string[] = []
  if (approvals) bits.push(`${approvals} change${approvals === 1 ? '' : 's'} to approve`)
  if (toLook) bits.push(`${toLook} thing${toLook === 1 ? '' : 's'} to look at`)
  return `${bits.join(', ')}.`
}

/**
 * The chat briefing, as the design has it (owner 2026-10-17): ONE line (greeting + the
 * briefingCounts headline) and ONE quiet link to the To-do list. No cards, tiles or rows:
 * the To-do page is where the list lives. The walk-through slot stays off until pointing
 * lands, so there is never a button that does nothing.
 */
export const BRIEFING_VIEW = {
  listLabel: 'Show the list',
  listHref: '/admin/todo',
  loading: 'Looking at what needs you…',
  /** A failed load must never read as "nothing is waiting". */
  failed: 'I couldn’t load what needs you just now.',
  walkthrough: { label: 'Walk me through the to-do', enabled: true },
} as const

export type BriefingLoad = 'loading' | 'failed' | 'ready'

export interface BriefingView {
  line: string
  /** Muted (still loading, or the load failed): not a statement about the work. */
  muted: boolean
  list: { label: string; href: string } | null
  walkthrough: { label: string } | null
}

export function briefingView({ name, hour, load, counts, walkthrough = BRIEFING_VIEW.walkthrough.enabled }: {
  name: string | null
  hour: number
  load: BriefingLoad
  counts: BriefingCounts | null
  walkthrough?: boolean
}): BriefingView {
  const list = { label: BRIEFING_VIEW.listLabel, href: BRIEFING_VIEW.listHref }
  if (load === 'loading' || (load === 'ready' && !counts)) return { line: BRIEFING_VIEW.loading, muted: true, list: null, walkthrough: null }
  // Failed: say so, and still offer the list (it may load there).
  if (load === 'failed' || !counts) return { line: BRIEFING_VIEW.failed, muted: true, list, walkthrough: null }
  const waiting = counts.approvals + counts.toLook > 0
  return {
    line: briefingHeadline(name, hour, counts.approvals, counts.toLook),
    muted: false,
    list: waiting ? list : null,
    walkthrough: waiting && walkthrough ? { label: BRIEFING_VIEW.walkthrough.label } : null,
  }
}

/** How many rows the dashboard lists per group (its lists are a top-N, said in the heading). */
export const DASHBOARD_TOP = { approvals: 6, look: 5 } as const

export interface DashboardWhatNeedsYou<T> {
  counts: BriefingCounts
  /** "4 changes to approve, 14 things to look at." / the empty line. */
  summary: string
  approvals: { shown: T[]; total: number }
  look: { shown: T[]; total: number; heading: string }
}

/**
 * The dashboard's "what needs you", from the SAME feed and count as the briefing
 * and the To-do (owner 2026-10-17: one count). Open items only; approvals = the
 * approve lane; "Also needs a look" = everything briefingCounts calls toLook
 * (needs a look, drafts, messages). A shortened list says "5 of 14".
 */
export function dashboardWhatNeedsYou<T extends { kind: string; lane: string; targetGone?: boolean }>(items: ReadonlyArray<T>, top = DASHBOARD_TOP): DashboardWhatNeedsYou<T> {
  const open = items.filter((i) => i.lane !== 'done')
  const counts = briefingCounts(open)
  const approvals = open.filter((i) => i.kind === 'approval' && i.lane === 'approve' && !i.targetGone)
  const look = open.filter((i) => (i.kind === 'task' && i.lane === 'attention') || i.lane === 'drafts' || i.lane === 'messages')
  const shownLook = look.slice(0, top.look)
  return {
    counts,
    summary: counts.approvals + counts.toLook ? `You have ${briefingCountsLine(counts.approvals, counts.toLook)}` : 'Nothing needs you right now — the site is in good shape.',
    approvals: { shown: approvals.slice(0, top.approvals), total: approvals.length },
    look: { shown: shownLook, total: look.length, heading: look.length > shownLook.length ? `Also needs a look · ${shownLook.length} of ${look.length}` : 'Also needs a look' },
  }
}
