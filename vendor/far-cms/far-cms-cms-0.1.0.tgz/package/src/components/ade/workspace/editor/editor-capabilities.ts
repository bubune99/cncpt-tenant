'use client';

/**
 * What the assistant can do in the editor — the same calls a click or a drag
 * makes: select a block, move it up/down among its neighbours (a draft, with
 * Undo, exactly like dragging it), open an editing panel, change the device.
 */

import { toast } from 'sonner';
import type { Block } from '../../../../lib/block-editor/types';
import type { useEditor } from '../../../../lib/block-editor/editor-context';
import { findParentBlock } from '../../../../lib/block-editor/tree-utils';
import { moveMessage } from '../../../../lib/block-editor/move';
import { outlineName } from '../../../../lib/block-editor/outline-names';
import { useUiCapability } from '../ui-dispatch';
import { useWorkspace } from '../store';

type Editor = ReturnType<typeof useEditor>;

function flatten(blocks: Block[]): Block[] {
  return blocks.flatMap((b) => [b, ...flatten(b.children ?? [])]);
}

/** A block by id, by its outline name, or by words it contains. */
export function findBlock(blocks: Block[], q: string): Block | null {
  const all = flatten(blocks);
  const needle = q.trim().toLowerCase();
  return (
    all.find((b) => b.id === q) ??
    all.find((b) => outlineName(b).toLowerCase() === needle) ??
    all.find((b) => (b.label ?? '').toLowerCase() === needle) ??
    all.find((b) => outlineName(b).toLowerCase().includes(needle)) ??
    all.find((b) => (b.textContent ?? '').toLowerCase().includes(needle)) ??
    null
  );
}

// Blocks | Templates | Outline | Style (owner 2026-10-19); the old names still land on the right tab.
const TAB = { blocks: 'blocks', templates: 'add', sections: 'add', saved: 'add', outline: 'outline', style: 'style' } as const;

export function useEditorCapabilities(editor: Editor, canEdit: boolean) {
  const setAgentTab = useWorkspace((s) => s.setAgentTab);
  const setDevice = useWorkspace((s) => s.setDevice);

  useUiCapability('editor.select_block', (a) => {
    const b = findBlock(editor.state.blocks, String(a.block));
    if (!b) return { ok: false, message: `No block matches “${a.block}”.` };
    editor.selectBlock(b.id);
    window.setTimeout(() => document.querySelector(`[data-block-id="${b.id}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 50);
    return { ok: true, message: `Selected ${outlineName(b)}.` };
  });

  useUiCapability('editor.move_block', (a) => {
    if (!canEdit) return { ok: false, message: 'This page is open elsewhere — I can’t change it here.' };
    const blocks = editor.state.blocks;
    const b = findBlock(blocks, String(a.block));
    if (!b) return { ok: false, message: `No block matches “${a.block}”.` };
    const parent = findParentBlock(blocks, b.id);
    const siblings = parent ? parent.children ?? [] : blocks;
    const at = siblings.findIndex((s) => s.id === b.id);
    const to = a.direction === 'up' ? at - 1 : at + 1;
    if (to < 0 || to >= siblings.length) return { ok: false, message: `It’s already at the ${a.direction === 'up' ? 'top' : 'bottom'}.` };
    const message = moveMessage(siblings, b.id, siblings[to].id) ?? 'Moved it.';
    editor.moveBlock(b.id, parent?.id ?? null, to);
    editor.selectBlock(b.id);
    toast.success(message, { action: { label: 'Undo', onClick: () => editor.undo() } });
    return { ok: true, message };
  });

  useUiCapability('editor.open_dock_tab', (a) => {
    const tab = TAB[a.tab as keyof typeof TAB];
    if (!tab) return { ok: false, message: 'No such panel.' };
    if (tab === 'style' && !editor.state.selectedBlockId) return { ok: false, message: 'Style needs a selected block first.' };
    setAgentTab(tab);
    return { ok: true, message: `Opened ${a.tab}.` };
  });

  useUiCapability('editor.set_device', (a) => {
    if (a.device !== 'desktop' && a.device !== 'tablet' && a.device !== 'phone') return { ok: false, message: 'No such device.' };
    setDevice(a.device);
    return { ok: true, message: `Showing ${a.device}.` };
  });
}
