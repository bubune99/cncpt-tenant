'use client';

/**
 * Hand a prompt to the assistant from anywhere in the admin (agent home's
 * prompt box, quick actions). The chat panel may not be mounted yet, so the
 * prompt waits in a one-slot mailbox until the panel takes it.
 */

import { useChatStore } from '../../../lib/ai/chat-store';
import type { ElementRef } from '../../../lib/ade/chat/references';

export const ADE_ASK_EVENT = 'ade:ask';
export interface PendingAsk {
  text: string;
  send: boolean;
  /** Things on screen the question is about (attached like pick mode does). */
  refs?: ElementRef[];
}

let pending: PendingAsk | null = null;

/**
 * send=false only places the text in the composer (the person finishes the
 * question) — nothing runs until they press send.
 */
export function askAssistant(text: string, opts: { workspace?: boolean; send?: boolean; refs?: ElementRef[]; keepLayout?: boolean } = {}) {
  pending = { text, send: opts.send !== false, ...(opts.refs?.length ? { refs: opts.refs } : {}) };
  // keepLayout: asked from beside the open chat (a spot's card) — leave the layout as it is.
  if (!opts.keepLayout) useChatStore.getState().setMode('split');
  window.dispatchEvent(new CustomEvent(ADE_ASK_EVENT));
}

/** The chat panel calls this on mount and on ADE_ASK_EVENT. */
export function takePendingAsk(): PendingAsk | null {
  const t = pending;
  pending = null;
  return t;
}
