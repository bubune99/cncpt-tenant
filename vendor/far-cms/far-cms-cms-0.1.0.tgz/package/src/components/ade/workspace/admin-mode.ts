'use client';

/**
 * How the admin is laid out — one continuum, driven by the sidebar and the
 * assistant:
 *
 *   sidebar shown                 → Classic: the full CMS with its sidebar
 *                                   (the assistant, if open, is a side panel)
 *   sidebar collapsed             → the CMS full width under an action bar
 *                                   with the ☰ menu
 *   …and the assistant opened     → agent-first: assistant left, CMS right
 *   …and the assistant full page  → the assistant takes the whole screen
 *
 * "Workspace" = sidebar collapsed + assistant open; "Classic" = sidebar
 * shown. The person's choice is remembered on the server; without one, their
 * role's default applies. Switching remounts the screen, so it goes through
 * the unsaved-changes guard.
 */

import { create } from 'zustand';
import { useChatStore } from '../../../lib/ai/chat-store';
import { assistantOpensNow, layoutForMode, type AdminMode } from '../../../lib/ade/admin-mode';
import { OVERLAY_BELOW } from '../../../lib/ade/ui/split';
import { normalizeAgentSide, type AgentSide } from '../../../lib/ade/ui/dock-side';
import { useUnsavedGuard } from './unsaved-guard';
import { canWriteLayout, layoutOverride, putLayoutPref } from './layout-prefs';
import { normalizeOverlayDismiss, type OverlayDismiss } from '../../../lib/ade/ui/overlay-dismiss';

export const MODE_SWITCH_PREFIX = '__mode__:';

// Only the person's own "close the sidebar" is remembered (owner 2026-10-17).
// The old key also held mode defaults ("Workspace" wrote 1), so it is ignored.
const CLOSED_BY_ME_KEY = 'admin:sidebar-closed-by-me';
const OLD_COLLAPSED_KEY = 'admin:sidebar-collapsed';

interface LayoutState {
  /** Sidebar collapsed into the ☰ menu (the action-bar layout). */
  collapsed: boolean;
  /** The assistant takes the whole page (agent-first, CMS hidden). */
  agentFull: boolean;
  /** "Full view": the assistant column steps aside; the action bar stays. */
  cmsFull: boolean;
  /** Which side the assistant column docks on (per person; lib/ade/ui/dock-side). */
  agentSide: AgentSide;
  /** How the laptop slide-over closes, for this person (lib/ade/ui/overlay-dismiss). */
  overlayDismiss: OverlayDismiss;
  setOverlayDismiss: (v: OverlayDismiss) => void;
  /** Collapse or show the sidebar; `remember` only when the person did it themselves. */
  setCollapsed: (v: boolean, opts?: { remember?: boolean }) => void;
  /** Change the dock side and remember it (not from a preview frame). */
  setAgentSide: (side: AgentSide) => void;
  setAgentFull: (v: boolean) => void;
  setCmsFull: (v: boolean) => void;
}

export const useAdminLayout = create<LayoutState>()((set) => ({
  collapsed: false,
  agentFull: false,
  cmsFull: false,
  agentSide: 'left',
  overlayDismiss: 'button',
  setOverlayDismiss: (overlayDismiss) => {
    set({ overlayDismiss });
    void putLayoutPref({ overlayDismiss });
  },
  setCollapsed: (collapsed, opts) => {
    try {
      if (opts?.remember && canWriteLayout()) localStorage.setItem(CLOSED_BY_ME_KEY, collapsed ? '1' : '0');
    } catch {
      /* private mode: just don't remember */
    }
    set(collapsed ? { collapsed } : { collapsed, agentFull: false });
  },
  setAgentSide: (side) => {
    set({ agentSide: side });
    void putLayoutPref({ agentSide: side });
  },
  setAgentFull: (agentFull) => set(agentFull ? { agentFull, cmsFull: false } : { agentFull }),
  setCmsFull: (cmsFull) => set(cmsFull ? { cmsFull, agentFull: false } : { cmsFull }),
}));

function closedByMe(): boolean {
  try {
    return localStorage.getItem(CLOSED_BY_ME_KEY) === '1';
  } catch {
    return false;
  }
}

/** Read the remembered sidebar state (after mount; localStorage is client-only). */
export function hydrateAdminLayout() {
  try {
    useAdminLayout.setState({ collapsed: closedByMe() });
    if (canWriteLayout()) localStorage.removeItem(OLD_COLLAPSED_KEY);
  } catch {
    /* ignore */
  }
  // A capture's override side shows at once (never saved).
  const o = layoutOverride();
  if (o?.side) useAdminLayout.setState({ agentSide: o.side });
}

interface ModeState {
  mode: AdminMode | null;
  loaded: boolean;
  set: (mode: AdminMode) => void;
}

export const useAdminMode = create<ModeState>()((set) => ({
  mode: null,
  loaded: false,
  set: (mode) => set({ mode, loaded: true }),
}));

/** Make the layout match a mode. */
function applyLayout(mode: AdminMode, asked = false) {
  const chat = useChatStore.getState();
  const layout = useAdminLayout.getState();
  // A mode's layout is a default, never stored as the person's own choice.
  const next = layoutForMode(mode, closedByMe());
  layout.setCollapsed(next.collapsed);
  if (next.openAssistant) {
    // Below the slide-over width the CMS gets the screen; the assistant opens on request
    // (pressing Open workspace is that request: it opens as the slide-over).
    const roomy = typeof window === 'undefined' || window.innerWidth >= OVERLAY_BELOW;
    if (assistantOpensNow({ openAssistant: next.openAssistant, roomy, asked }) && chat.mode !== 'split') chat.setMode('split');
  } else {
    layout.setAgentFull(false);
    // Classic = the CMS with its sidebar, assistant closed (one assistant layout:
    // opening it again gives the agent-first column on the person's side).
    if (chat.mode !== 'collapsed') chat.setMode('collapsed');
  }
}

let loading: Promise<void> | null = null;

/** Once per session: the remembered mode (or the role default) sets the layout. */
export function loadAdminMode(): Promise<void> {
  loading ??= fetch('/api/admin/ade/prefs', { cache: 'no-store' })
    .then((r) => r.json())
    .then((j) => {
      // A preview frame's override (?ade=…, ?ade-side=…) wins over the saved prefs, for that frame only.
      const o = layoutOverride();
      const mode: AdminMode = o?.mode ?? (j?.adminMode === 'workspace' ? 'workspace' : 'classic');
      useAdminLayout.setState({ agentSide: o?.side ?? normalizeAgentSide(j?.agentSide), overlayDismiss: normalizeOverlayDismiss(j?.overlayDismiss) });
      useAdminMode.getState().set(mode);
      applyLayout(mode);
    })
    .catch(() => {
      // Prefs unreadable: keep whatever layout is showing.
      const mode: AdminMode = useChatStore.getState().mode === 'split' ? 'workspace' : 'classic';
      useAdminMode.getState().set(mode);
    });
  return loading;
}

/** Apply a mode now and remember it (called directly, or after the guard). */
export function commitAdminMode(mode: AdminMode) {
  useAdminMode.getState().set(mode);
  // The person chose Classic: their own "sidebar shown", so a stale "closed by me" can't come back.
  if (mode === 'classic') useAdminLayout.getState().setCollapsed(false, { remember: true });
  applyLayout(mode, true);
  void putLayoutPref({ adminMode: mode });
}

/**
 * The person collapsed or showed the sidebar themselves: that IS their mode
 * from now on (owner: remember sidebar collapse as the mode). The layout has
 * already changed, so this only records it.
 */
export function rememberModeFromSidebar(collapsed: boolean) {
  const mode: AdminMode = collapsed ? 'workspace' : 'classic';
  if (useAdminMode.getState().mode === mode) return;
  useAdminMode.getState().set(mode);
  void putLayoutPref({ adminMode: mode });
}

/** Switch modes, asking first about unsaved edits (the screen remounts). */
export function switchAdminMode(mode: AdminMode) {
  const { dirty, setPending } = useUnsavedGuard.getState();
  if (dirty) setPending(`${MODE_SWITCH_PREFIX}${mode}`);
  else commitAdminMode(mode);
}

/** The outage notice's "Show the sidebar": for now only — no saved mode, no "closed by me" (owner 2026-10-17). */
export const SIDEBAR_FOR_NOW = 'classic-now';

export function showSidebarForNow() {
  const layout = useAdminLayout.getState();
  layout.setCollapsed(false);
  layout.setAgentFull(false);
  const chat = useChatStore.getState();
  if (chat.mode !== 'collapsed') chat.setMode('collapsed');
}

/** Same, asking first about unsaved edits (the screen remounts). */
export function switchToSidebarForNow() {
  const { dirty, setPending } = useUnsavedGuard.getState();
  if (dirty) setPending(`${MODE_SWITCH_PREFIX}${SIDEBAR_FOR_NOW}`);
  else showSidebarForNow();
}
