'use client';

/**
 * The browser side of the control layer (lib/ade/ui/control): the page I/O
 * (run a screen capability, read a unit back by its data-ui, let the page
 * settle) and the actions built on it —
 *
 * - showUnit (the show_unit tool): resolve the unit the model named, run its
 *   reveal path step by step with read-back and one retry, and answer in the
 *   SAME turn: shown, or one plain sentence and the way to do it by hand.
 * - revealUnitInBackground (spotlight_steps aimed at a unit).
 * - verifyOnPage (fill: the field really shows the value).
 *
 * The runner only runs read / edit-draft capabilities; commit, destructive and
 * money are refused here too (lib/ade/ui/control AGENT_MAY).
 */

import { UI_CAPABILITIES } from '../../lib/ade-bindings/ui-capabilities';
import { agentMay, notFound, planShow, pointedLine, resolveUnit, riskOfEffect, runPlan, verify, type ControlIO, type ControlResult, type ControlUnit, type Readback, type ShowUnitOutput } from '../../lib/ade/ui/control';
import { useScreenContext } from './workspace/screen-context';
import { dispatchUi, dispatchUiDirect } from './workspace/ui-dispatch';
import { withTimeout } from '../../lib/ade/chat/client-timeouts';

function onScreen(el: Element): boolean {
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0 && r.right > 0 && r.bottom > 0 && r.left < window.innerWidth && r.top < window.innerHeight;
}

function all(selector: string): Element[] {
  try {
    return Array.from(document.querySelectorAll(selector));
  } catch {
    return [];
  }
}

/** What a unit shows: an input's value, else its text. */
function shownValue(el: Element): string {
  const v = (el as HTMLInputElement).value;
  return (typeof v === 'string' && el.matches('input, textarea, select') ? v : (el.textContent ?? '')).replace(/\s+/g, ' ').trim();
}

/** One reveal step: only look / draft capabilities; anything that commits is the person's to press. */
async function actWith(step: Parameters<ControlIO['act']>[0], send: typeof dispatchUi) {
  const cap = UI_CAPABILITIES.find((c) => c.id === step.capability);
  if (!cap) return { ok: false, message: `There is no “${step.capability}” here.` };
  if (agentMay(riskOfEffect(cap.effect)) !== 'act') return { ok: false, message: `“${cap.label}” is for the person to press.` };
  const r = await send({ capability: step.capability, args: step.args }, 'assistant');
  return { ok: r.ok, message: r.message };
}

/** A direct act may take this long before the reveal reports it didn't happen (lane B's fill deadline). */
export const DIRECT_ACT_MS = 4_500;

export const pageIO: ControlIO = {
  // Queued behind other screen steps — right for show_unit, which runs outside any capability.
  act: (step) => actWith(step, dispatchUi),
  read(r: Readback) {
    if (r.kind === 'visible') return all(r.selector).some(onScreen);
    if (r.kind === 'mounted') return all(r.selector).some((el) => el.getClientRects().length > 0);
    if (r.kind === 'text') {
      const want = r.equals.replace(/\s+/g, ' ').trim();
      return all(r.selector).some((el) => shownValue(el) === want || shownValue(el.querySelector('input, textarea, select, [contenteditable]') ?? el) === want);
    }
    return window.location.pathname.replace(/\/+$/, '') === r.path.replace(/\/+$/, '');
  },
  settle: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
};

/**
 * The same IO, but each act runs NOW (not queued) and has a deadline — for
 * reveals made from inside a running capability (record.fill revealing a
 * Details field). Queued, the act waits behind the capability that is
 * waiting on it: a deadlock (staging 49b9da13, lane B dd08eacf).
 */
export const directIO: ControlIO = {
  ...pageIO,
  act: (step) => withTimeout(actWith(step, dispatchUiDirect), DIRECT_ACT_MS, () => ({ ok: false, message: `“${step.what}” didn’t happen in time.` })),
};

/**
 * show_unit: the unit named (key, label, the type's aliases, or its selector)
 * on the screen the person has open. Revealed and checked; the spot itself is
 * drawn from this result (the reply's "Pointed at …").
 */
export async function showUnit(args: unknown): Promise<ShowUnitOutput> {
  const a = (args ?? {}) as { unit?: unknown; sentence?: unknown };
  const asked = typeof a.unit === 'string' ? a.unit.slice(0, 80) : '';
  const ctx = useScreenContext.getState().ctx;
  const unit = resolveUnit(asked, (ctx?.units ?? []) as ReadonlyArray<ControlUnit>);
  if (!unit) return notFound(asked, null);
  const res = await runPlan(planShow(unit), pageIO, unit.label);
  if (!res.ok) return { ok: false, error: res.sentence };
  // Mounted may be below the fold (the drawer scrolls): bring it into view before the spot is drawn.
  try {
    document.querySelector(unit.selector)?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  } catch {
    /* an odd selector: the spot still aims at it */
  }
  const sentence = typeof a.sentence === 'string' && a.sentence.trim() ? a.sentence.trim().slice(0, 240) : undefined;
  return { ok: true, shown: unit.label, selector: unit.selector, line: pointedLine(unit.label, unit.revealPath), ...(sentence ? { sentence } : {}) };
}

/** A spotlight step aimed at a unit that isn't on screen yet: run its reveal path (checked) while the spotlight waits. */
export function revealUnitInBackground(unit: ControlUnit): void {
  void runPlan(planShow(unit), pageIO, unit.label);
}

/**
 * Make one unit of this screen reachable before acting on it — e.g. a Details
 * field while the record drawer is closed or open on another tab ("Ready to
 * publish"): its reveal path switches the drawer to the right tab, then checks
 * the field is mounted (staging 49b9da13). Shared by show_unit and lane B's
 * fill. Bounded (CONTROL_LIMITS); never presses a commit control. Called
 * from inside a capability (the fill), pass { direct: true } or your own
 * unqueued { io } — never the queued pageIO, which would wait on you.
 */
export async function revealScreenUnit(key: string, opts: { direct?: boolean; io?: ControlIO } = {}): Promise<ControlResult> {
  const units = (useScreenContext.getState().ctx?.units ?? []) as ReadonlyArray<ControlUnit>;
  const unit = units.find((u) => u.key === key) ?? resolveUnit(key, units);
  if (!unit) return { ok: false, steps: 0, failedAt: 0, sentence: `I can’t find “${key.slice(0, 80)}” on this screen.`, manual: '' };
  // From inside a capability (a fill): act directly, never through the queue it is holding.
  // The caller's own IO wins (e.g. the fill's, acting on the record page directly).
  return runPlan(planShow(unit), opts.io ?? (opts.direct ? directIO : pageIO), unit.label);
}

/** Lane B's fill: read back that each field shows its value (retrying a few times). */
export function verifyOnPage(readbacks: ReadonlyArray<Readback>) {
  return verify(readbacks, pageIO);
}
