/**
 * Form Smart Blocks
 *
 * Barrel export that registers the FormBlock with the registry.
 * Side-effect imported by block-page-renderer (and the editor) so admin-built
 * forms can be dropped onto any page.
 */

import { registerSmartBlock } from '../../../lib/block-editor/smart-blocks/registry'
import type { Block } from '../../../lib/block-editor/types'

import FormBlock from './FormBlock'
import NewsletterSignup from './NewsletterSignup'

registerSmartBlock({
  componentName: 'FormBlock',
  displayName: 'Form',
  category: 'content',
  icon: 'clipboard-list',
  component: FormBlock,
  dataRequirements: (block: Block) => [
    {
      key: 'form',
      fetcher: 'fetchForm',
      args: {
        slug: block.attrs?.['data-form-slug'],
        id: block.attrs?.['data-form-id'],
      },
    },
  ],
  defaultBlock: {
    tag: 'div',
    className: 'w-full max-w-xl mx-auto py-8',
    componentName: 'FormBlock',
    label: 'Form',
    attrs: {},
  },
  editorConfig: {
    fields: [
      {
        key: 'data-form-slug',
        label: 'Form',
        type: 'form-select',
        defaultValue: '',
        target: 'attrs',
      },
      {
        key: 'data-show-title',
        label: 'Show form name',
        type: 'select',
        defaultValue: 'true',
        options: [
          { label: 'Yes', value: 'true' },
          { label: 'No', value: 'false' },
        ],
        target: 'attrs',
      },
      {
        key: 'data-display',
        label: 'Display as',
        type: 'select',
        defaultValue: 'inline',
        options: [
          { label: 'Inline block', value: 'inline' },
          { label: 'Popup', value: 'popup' },
        ],
        target: 'attrs',
      },
      {
        key: 'data-popup-trigger-delay',
        label: 'Popup delay (seconds)',
        type: 'number',
        defaultValue: '5',
        min: 0,
        max: 600,
        step: 1,
        target: 'attrs',
        showIf: { key: 'data-display', equals: 'popup' },
      },
      {
        key: 'data-popup-frequency',
        label: 'Show popup',
        type: 'select',
        defaultValue: 'session',
        options: [
          { label: 'Every page view', value: 'always' },
          { label: 'Once per session', value: 'session' },
          { label: 'Once per visitor', value: 'visitor' },
        ],
        target: 'attrs',
        showIf: { key: 'data-display', equals: 'popup' },
      },
      {
        key: 'data-popup-duration',
        label: 'Auto-dismiss after (seconds, 0 = never)',
        type: 'number',
        defaultValue: '0',
        min: 0,
        max: 600,
        step: 1,
        target: 'attrs',
        showIf: { key: 'data-display', equals: 'popup' },
      },
    ],
  },
})

registerSmartBlock({
  componentName: 'NewsletterSignup',
  displayName: 'Newsletter signup',
  category: 'content',
  icon: 'mail',
  component: NewsletterSignup,
  dataRequirements: () => [],
  defaultBlock: {
    tag: 'div',
    className: 'w-full',
    componentName: 'NewsletterSignup',
    label: 'Newsletter signup',
    attrs: {},
  },
  editorConfig: {
    fields: [
      { key: 'data-placeholder', label: 'Placeholder', type: 'text', defaultValue: 'Email address', target: 'attrs' },
      { key: 'data-button-text', label: 'Button text', type: 'text', defaultValue: 'Sign Up', target: 'attrs' },
      { key: 'data-success-text', label: 'Thank-you message', type: 'text', defaultValue: 'Thanks — you’re on the list!', target: 'attrs' },
    ],
  },
})

export { FormBlock, NewsletterSignup }
