/**
 * Shared helpers for blocks BOUND to a record (ADE placements): the record
 * comes from the fetchRecord data; per-placement overrides from the block's
 * data-overrides attribute. Client-safe (pure).
 */

import { readOverrides, resolveBound } from '../../../lib/ade/records/logic'
import type { Block } from '../../../lib/block-editor/types'
import type { SerializedRecord } from '../../../lib/block-editor/smart-blocks/records-data'

export function boundRecord(data: Record<string, unknown>): SerializedRecord | null {
  return (data.record as SerializedRecord | null | undefined) ?? null
}

/** Field reader that prefers this placement's override; tracks which fields are customized. */
export function fieldReader(block: Block, record: SerializedRecord | null) {
  const overrides = readOverrides(block.attrs)
  const customized = Object.keys(overrides)
  const text = (field: string): string => {
    const { value } = resolveBound(record?.data, field, overrides)
    return typeof value === 'string' ? value : value === null || value === undefined ? '' : String(value)
  }
  return { text, raw: (field: string) => resolveBound(record?.data, field, overrides).value, customized }
}

export const STAGE_STYLES: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-800',
  ongoing: 'bg-amber-100 text-amber-800',
  completed: 'bg-slate-200 text-slate-700',
}

export function formatDate(iso: string): string {
  const t = Date.parse(`${iso}T00:00:00Z`)
  return Number.isNaN(t) ? iso : new Date(t).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' })
}
