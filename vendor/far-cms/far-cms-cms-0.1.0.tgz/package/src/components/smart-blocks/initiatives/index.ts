/**
 * Initiative Smart Blocks
 *
 * Barrel export that registers the InitiativeBlock with the registry.
 * Side-effect imported by block-page-renderer, the page builder, and the
 * storefront pages so initiative highlights can live on any page while
 * staying in sync with the Initiatives workflow (shared record = the
 * bi-directional link between page builder and wizard).
 */

import { registerSmartBlock } from '../../../lib/block-editor/smart-blocks/registry'
import type { Block } from '../../../lib/block-editor/types'

import InitiativeBlock from './InitiativeBlock'
import InitiativeHighlights from './InitiativeHighlights'
import RecordField from './RecordField'
import InitiativeHeader from './InitiativeHeader'
import InitiativeStats from './InitiativeStats'
import InitiativeGoal from './InitiativeGoal'
import InitiativeGallery from './InitiativeGallery'
import InitiativeCard from './InitiativeCard'

// ── Placements bound to a record (ADE records) — one source of truth ──────
const boundRequirement = (block: Block) => [
  { key: 'record', fetcher: 'fetchRecord', args: { ref: block.attrs?.['data-record'] } },
]
const recordRefField = {
  key: 'data-record',
  label: 'Record (type:id)',
  type: 'text' as const,
  defaultValue: '',
  target: 'attrs' as const,
}

registerSmartBlock({
  componentName: 'RecordField',
  displayName: 'Record field',
  category: 'content',
  icon: 'link',
  component: RecordField,
  dataRequirements: boundRequirement,
  defaultBlock: { tag: 'span', className: '', componentName: 'RecordField', label: 'Record field', attrs: { 'data-field': 'name' } },
  editorConfig: {
    fields: [
      recordRefField,
      { key: 'data-field', label: 'Field', type: 'text', defaultValue: 'name', target: 'attrs' },
    ],
  },
})

registerSmartBlock({
  componentName: 'InitiativeHeader',
  displayName: 'Initiative header',
  category: 'content',
  icon: 'image',
  component: InitiativeHeader,
  dataRequirements: boundRequirement,
  defaultBlock: { tag: 'section', className: '', componentName: 'InitiativeHeader', label: 'Initiative header' },
  editorConfig: { fields: [recordRefField] },
})

registerSmartBlock({
  componentName: 'InitiativeStats',
  displayName: 'Initiative stats',
  category: 'content',
  icon: 'bar-chart',
  component: InitiativeStats,
  dataRequirements: boundRequirement,
  defaultBlock: { tag: 'section', className: '', componentName: 'InitiativeStats', label: 'Impact stats' },
  editorConfig: { fields: [recordRefField] },
})

registerSmartBlock({
  componentName: 'InitiativeGoal',
  displayName: 'Initiative goal',
  category: 'content',
  icon: 'target',
  component: InitiativeGoal,
  dataRequirements: boundRequirement,
  defaultBlock: { tag: 'section', className: '', componentName: 'InitiativeGoal', label: 'Goal' },
  editorConfig: { fields: [recordRefField] },
})

registerSmartBlock({
  componentName: 'InitiativeGallery',
  displayName: 'Initiative photo gallery',
  category: 'content',
  icon: 'images',
  component: InitiativeGallery,
  dataRequirements: boundRequirement,
  defaultBlock: { tag: 'section', className: '', componentName: 'InitiativeGallery', label: 'Photo gallery' },
  editorConfig: { fields: [recordRefField] },
})

registerSmartBlock({
  componentName: 'InitiativeCard',
  displayName: 'Initiative card',
  category: 'content',
  icon: 'square',
  component: InitiativeCard,
  dataRequirements: boundRequirement,
  defaultBlock: { tag: 'div', className: '', componentName: 'InitiativeCard', label: 'Initiative card' },
  editorConfig: {
    fields: [
      recordRefField,
      {
        key: 'data-show-link',
        label: 'Link to the initiative page',
        type: 'select',
        defaultValue: 'true',
        options: [{ label: 'Yes', value: 'true' }, { label: 'No', value: 'false' }],
        target: 'attrs',
      },
    ],
  },
})

registerSmartBlock({
  componentName: 'InitiativeBlock',
  displayName: 'Initiative',
  category: 'content',
  icon: 'target',
  component: InitiativeBlock,
  dataRequirements: (block: Block) => [
    {
      key: 'initiative',
      fetcher: 'fetchInitiative',
      args: {
        slug: block.attrs?.['data-initiative-slug'],
      },
    },
  ],
  defaultBlock: {
    tag: 'div',
    className: 'bg-white rounded-xl shadow-sm p-8',
    componentName: 'InitiativeBlock',
    label: 'Initiative',
    attrs: { 'data-variant': 'stat' },
  },
  editorConfig: {
    fields: [
      {
        key: 'data-initiative-slug',
        label: 'Initiative',
        type: 'initiative-select',
        defaultValue: '',
        target: 'attrs',
      },
      {
        key: 'data-variant',
        label: 'Show as',
        type: 'select',
        defaultValue: 'stat',
        options: [
          { label: 'Impact stat card', value: 'stat' },
          { label: 'Name + summary', value: 'summary' },
        ],
        target: 'attrs',
      },
      {
        key: 'data-stat-index',
        label: 'Which stat (1st, 2nd…)',
        type: 'number',
        defaultValue: '0',
        min: 0,
        max: 3,
        step: 1,
        target: 'attrs',
        showIf: { key: 'data-variant', equals: 'stat' },
      },
      {
        key: 'data-show-stage',
        label: 'Show stage badge',
        type: 'select',
        defaultValue: 'false',
        options: [
          { label: 'No', value: 'false' },
          { label: 'Yes', value: 'true' },
        ],
        target: 'attrs',
      },
      {
        key: 'data-show-link',
        label: 'Link to initiative page',
        type: 'select',
        defaultValue: 'true',
        options: [
          { label: 'Yes (when published)', value: 'true' },
          { label: 'No', value: 'false' },
        ],
        target: 'attrs',
      },
    ],
  },
})

registerSmartBlock({
  componentName: 'InitiativeHighlights',
  displayName: 'Initiative Highlights',
  category: 'content',
  icon: 'sparkles',
  component: InitiativeHighlights,
  dataRequirements: (block: Block) => [
    {
      key: 'initiatives',
      fetcher: 'fetchFeaturedInitiatives',
      args: {
        max: block.attrs?.['data-max'] || '8',
        source: block.attrs?.['data-source'] || 'featured',
        // Placement rules (lib/ade/records/rules), when set, decide instead.
        rules: block.attrs?.['data-rules'] || '',
      },
    },
  ],
  defaultBlock: {
    tag: 'div',
    className: 'w-full',
    componentName: 'InitiativeHighlights',
    label: 'Initiative Highlights',
    attrs: { 'data-mode': 'stats' },
  },
  editorConfig: {
    fields: [
      {
        key: 'data-source',
        label: 'Which initiatives',
        type: 'select',
        defaultValue: 'featured',
        options: [
          { label: 'Starred highlights (dashboard order)', value: 'featured' },
          { label: 'All published (starred first, then newest)', value: 'all' },
        ],
        target: 'attrs',
      },
      {
        key: 'data-mode',
        label: 'Show as',
        type: 'select',
        defaultValue: 'stats',
        options: [
          { label: 'Impact stat cards', value: 'stats' },
          { label: 'Initiative summaries', value: 'initiatives' },
          { label: 'Full showcase (photo + story)', value: 'showcase' },
        ],
        target: 'attrs',
      },
      {
        key: 'data-max',
        label: 'Max initiatives',
        type: 'number',
        defaultValue: '8',
        min: 1,
        max: 12,
        step: 1,
        target: 'attrs',
      },
      {
        key: 'data-show-link',
        label: 'Cards link to initiative pages',
        type: 'select',
        defaultValue: 'true',
        options: [
          { label: 'Yes', value: 'true' },
          { label: 'No', value: 'false' },
        ],
        target: 'attrs',
      },
    ],
  },
})

export { InitiativeBlock }
export { InitiativeHighlights }
export { RecordField, InitiativeHeader, InitiativeStats, InitiativeGoal, InitiativeGallery, InitiativeCard }
