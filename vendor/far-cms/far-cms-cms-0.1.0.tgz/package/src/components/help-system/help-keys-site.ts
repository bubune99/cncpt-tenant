/**
 * Help keys: customers, pages, settings, analytics, users and roles, block editor, common actions and UI, help system. Data only, moved from help-key-registry.ts on 2026-11-22 (size check);
 * the registry combines the parts in their original order.
 */
import type { HelpKeyDefinition } from './help-key-registry'

export const HELP_KEYS_SITE: HelpKeyDefinition[] = [
  // Customers
  {
    key: 'admin.customers.page',
    category: 'customers',
    location: 'Customers page - main container',
    description: 'Customers page container',
  },
  {
    key: 'admin.customers.actions',
    category: 'customers',
    location: 'Customers page - action buttons',
    description: 'Customer action buttons',
  },
  {
    key: 'admin.customers.create',
    category: 'customers',
    location: 'Customers page - create button',
    description: 'Create new customer button',
  },
  {
    key: 'admin.customers.export',
    category: 'customers',
    location: 'Customers page - export button',
    description: 'Export customers button',
  },
  {
    key: 'admin.customers.stats',
    category: 'customers',
    location: 'Customers page - stats cards',
    description: 'Customer statistics cards',
  },
  {
    key: 'admin.customers.filters',
    category: 'customers',
    location: 'Customers page - filter section',
    description: 'Customer filter controls',
  },
  {
    key: 'admin.customers.search',
    category: 'customers',
    location: 'Customers page - search input',
    description: 'Customer search input',
  },
  {
    key: 'admin.customers.table',
    category: 'customers',
    location: 'Customers page - customers table',
    description: 'Customers data table',
  },

  // Pages
  {
    key: 'admin.pages.page',
    category: 'pages',
    location: 'Pages page - main container',
    description: 'Pages management page container',
  },
  {
    key: 'admin.pages.actions',
    category: 'pages',
    location: 'Pages page - action buttons',
    description: 'Page action buttons',
  },
  {
    key: 'admin.pages.new',
    category: 'pages',
    location: 'Pages page - new button',
    description: 'Create new page button',
  },
  {
    key: 'admin.pages.layout',
    category: 'pages',
    location: 'Pages page - layout section',
    description: 'Pages layout container',
  },
  {
    key: 'admin.pages.stats',
    category: 'pages',
    location: 'Pages page - stats cards',
    description: 'Page statistics cards',
  },
  {
    key: 'admin.pages.filters',
    category: 'pages',
    location: 'Pages page - filter section',
    description: 'Page filter controls',
  },
  {
    key: 'admin.pages.search',
    category: 'pages',
    location: 'Pages page - search input',
    description: 'Page search input',
  },
  {
    key: 'admin.pages.table',
    category: 'pages',
    location: 'Pages page - pages table',
    description: 'Pages data table',
  },

  // Settings
  {
    key: 'admin.settings.page',
    category: 'settings',
    location: 'Settings page - main container',
    description: 'Settings page container',
  },
  {
    key: 'admin.settings.header',
    category: 'settings',
    location: 'Settings page - header',
    description: 'Settings page header section',
  },
  {
    key: 'admin.settings.tabs',
    category: 'settings',
    location: 'Settings page - tab navigation',
    description: 'Settings category tabs',
  },
  {
    key: 'admin.settings.branding-tab',
    category: 'settings',
    location: 'Settings - branding tab',
    description: 'Branding and logo settings',
  },
  {
    key: 'admin.settings.email-tab',
    category: 'settings',
    location: 'Settings - email tab',
    description: 'Email provider settings',
  },
  {
    key: 'admin.settings.ai-tab',
    category: 'settings',
    location: 'Settings - AI tab',
    description: 'AI assistant settings',
  },
  {
    key: 'admin.settings.store-tab',
    category: 'settings',
    location: 'Settings - store tab',
    description: 'Store information settings',
  },
  {
    key: 'admin.settings.store-info',
    category: 'settings',
    location: 'Settings - store info card',
    description: 'Store information configuration',
  },
  {
    key: 'admin.settings.notifications-tab',
    category: 'settings',
    location: 'Settings - notifications tab',
    description: 'Notification settings',
  },
  {
    key: 'admin.settings.email-notifications',
    category: 'settings',
    location: 'Settings - email notifications card',
    description: 'Email notification preferences',
  },
  {
    key: 'admin.settings.push-notifications',
    category: 'settings',
    location: 'Settings - push notifications card',
    description: 'Push notification settings',
  },
  {
    key: 'admin.settings.shipping-tab',
    category: 'settings',
    location: 'Settings - shipping tab',
    description: 'Shipping settings tab',
  },
  {
    key: 'admin.settings.shipping-config',
    category: 'settings',
    location: 'Settings - shipping config card',
    description: 'Shipping configuration',
  },
  {
    key: 'admin.settings.taxes-tab',
    category: 'settings',
    location: 'Settings - taxes tab',
    description: 'Tax settings tab',
  },
  {
    key: 'admin.settings.tax-config',
    category: 'settings',
    location: 'Settings - tax config card',
    description: 'Tax configuration',
  },
  {
    key: 'admin.settings.environment-tab',
    category: 'settings',
    location: 'Settings - environment tab',
    description: 'Environment variables settings',
  },
  {
    key: 'admin.settings.appearance-tab',
    category: 'settings',
    location: 'Settings - appearance tab',
    description: 'Theme and appearance settings',
  },
  {
    key: 'admin.settings.theme-config',
    category: 'settings',
    location: 'Settings - theme config card',
    description: 'Theme configuration',
  },
  {
    key: 'admin.settings.security-tab',
    category: 'settings',
    location: 'Settings - security tab',
    description: 'Security settings tab',
  },
  {
    key: 'admin.settings.security-config',
    category: 'settings',
    location: 'Settings - security config card',
    description: 'Security configuration',
  },
  {
    key: 'admin.settings.danger-zone',
    category: 'settings',
    location: 'Settings - danger zone card',
    description: 'Dangerous actions like data export and store deletion',
  },
  {
    key: 'admin.settings.actions',
    category: 'settings',
    location: 'Settings - action buttons',
    description: 'Settings save/cancel buttons',
  },
  {
    key: 'admin.settings.save',
    category: 'settings',
    location: 'Settings - save button',
    description: 'Save settings button',
  },
  {
    key: 'admin.settings.cancel',
    category: 'settings',
    location: 'Settings - cancel button',
    description: 'Cancel settings changes button',
  },
  {
    key: 'admin.settings.general',
    category: 'settings',
    location: 'Settings - general tab',
    description: 'General store settings',
  },
  {
    key: 'admin.settings.payments',
    category: 'settings',
    location: 'Settings - payments tab',
    description: 'Payment configuration',
  },
  {
    key: 'admin.settings.shipping',
    category: 'settings',
    location: 'Settings - shipping tab',
    description: 'Shipping configuration',
  },
  {
    key: 'admin.settings.email',
    category: 'settings',
    location: 'Settings - email tab',
    description: 'Email settings',
  },

  // Analytics
  {
    key: 'admin.analytics.dashboard',
    category: 'analytics',
    location: 'Analytics page',
    description: 'Analytics dashboard',
  },
  {
    key: 'admin.analytics.actions',
    category: 'analytics',
    location: 'Analytics page - action buttons',
    description: 'Analytics action buttons (date range, refresh, export)',
  },
  {
    key: 'admin.analytics.date-range',
    category: 'analytics',
    location: 'Analytics page - date range picker',
    description: 'Date range selection for analytics data',
  },
  {
    key: 'admin.analytics.refresh',
    category: 'analytics',
    location: 'Analytics page - refresh button',
    description: 'Refresh analytics data',
  },
  {
    key: 'admin.analytics.export',
    category: 'analytics',
    location: 'Analytics page - export button',
    description: 'Export analytics data',
  },
  {
    key: 'admin.analytics.stats',
    category: 'analytics',
    location: 'Analytics page - stats cards',
    description: 'Analytics statistics cards grid',
  },
  {
    key: 'admin.analytics.tabs',
    category: 'analytics',
    location: 'Analytics page - tabs',
    description: 'Analytics view tabs (overview, products, traffic, customers)',
  },
  {
    key: 'admin.analytics.integrations',
    category: 'analytics',
    location: 'Analytics page - integrations section',
    description: 'Analytics integrations configuration',
  },

  // Users & Roles
  {
    key: 'admin.users',
    category: 'system',
    location: 'Users management page',
    description: 'User account management',
  },
  {
    key: 'admin.users.page',
    category: 'users',
    location: 'Users page - main container',
    description: 'Users management page container',
  },
  {
    key: 'admin.users.header',
    category: 'users',
    location: 'Users page - header',
    description: 'Users page header section',
  },
  {
    key: 'admin.users.actions',
    category: 'users',
    location: 'Users page - action buttons',
    description: 'User management action buttons',
  },
  {
    key: 'admin.users.refresh',
    category: 'users',
    location: 'Users page - refresh button',
    description: 'Refresh users list',
  },
  {
    key: 'admin.users.stats',
    category: 'users',
    location: 'Users page - stats cards',
    description: 'User statistics cards',
  },
  {
    key: 'admin.users.filters',
    category: 'users',
    location: 'Users page - filter section',
    description: 'User filter controls',
  },
  {
    key: 'admin.users.search',
    category: 'users',
    location: 'Users page - search input',
    description: 'User search input',
  },
  {
    key: 'admin.users.table',
    category: 'users',
    location: 'Users page - users table',
    description: 'Users data table',
  },
  {
    key: 'admin.users.quick-actions',
    category: 'users',
    location: 'Users page - quick actions',
    description: 'Quick action buttons for user management',
  },
  {
    key: 'admin.roles',
    category: 'system',
    location: 'Roles & permissions page',
    description: 'Role and permission management',
  },
  {
    key: 'admin.roles.page',
    category: 'roles',
    location: 'Roles page - main container',
    description: 'Roles management page container',
  },
  {
    key: 'admin.roles.header',
    category: 'roles',
    location: 'Roles page - header',
    description: 'Roles page header section',
  },
  {
    key: 'admin.roles.actions',
    category: 'roles',
    location: 'Roles page - action buttons',
    description: 'Role management action buttons',
  },
  {
    key: 'admin.roles.seed',
    category: 'roles',
    location: 'Roles page - seed button',
    description: 'Seed built-in roles button',
  },
  {
    key: 'admin.roles.refresh',
    category: 'roles',
    location: 'Roles page - refresh button',
    description: 'Refresh roles list',
  },
  {
    key: 'admin.roles.create',
    category: 'roles',
    location: 'Roles page - create button',
    description: 'Create new role button',
  },
  {
    key: 'admin.roles.stats',
    category: 'roles',
    location: 'Roles page - stats cards',
    description: 'Role statistics cards',
  },
  {
    key: 'admin.roles.filters',
    category: 'roles',
    location: 'Roles page - filter section',
    description: 'Role filter controls',
  },
  {
    key: 'admin.roles.search',
    category: 'roles',
    location: 'Roles page - search input',
    description: 'Role search input',
  },
  {
    key: 'admin.roles.list',
    category: 'roles',
    location: 'Roles page - roles list',
    description: 'Roles listing view',
  },
  {
    key: 'admin.roles.help-section',
    category: 'roles',
    location: 'Roles page - help section',
    description: 'About Roles & Permissions info card',
  },
  {
    key: 'admin.workflows',
    category: 'system',
    location: 'Workflows page',
    description: 'Workflow automation',
  },
  {
    key: 'admin.workflows.page',
    category: 'workflows',
    location: 'Workflows page - main container',
    description: 'Workflows page container',
  },
  {
    key: 'admin.workflows.header',
    category: 'workflows',
    location: 'Workflows page - header',
    description: 'Workflows page header section',
  },
  {
    key: 'admin.workflows.new',
    category: 'workflows',
    location: 'Workflows page - new button',
    description: 'Create new workflow button',
  },
  {
    key: 'admin.workflows.table',
    category: 'workflows',
    location: 'Workflows page - workflows table',
    description: 'Workflows data table',
  },
  {
    key: 'admin.workflows.empty',
    category: 'workflows',
    location: 'Workflows page - empty state',
    description: 'Empty state when no workflows exist',
  },
  {
    key: 'admin.forms',
    category: 'content',
    location: 'Forms page',
    description: 'Form builder and submissions',
  },
  {
    key: 'admin.forms.page',
    category: 'forms',
    location: 'Forms page - main container',
    description: 'Forms page container',
  },
  {
    key: 'admin.forms.header',
    category: 'forms',
    location: 'Forms page - header',
    description: 'Forms page header section',
  },
  {
    key: 'admin.forms.actions',
    category: 'forms',
    location: 'Forms page - action buttons',
    description: 'Form management action buttons',
  },
  {
    key: 'admin.forms.refresh',
    category: 'forms',
    location: 'Forms page - refresh button',
    description: 'Refresh forms list',
  },
  {
    key: 'admin.forms.new',
    category: 'forms',
    location: 'Forms page - new button',
    description: 'Create new form button',
  },
  {
    key: 'admin.forms.stats',
    category: 'forms',
    location: 'Forms page - stats cards',
    description: 'Form statistics cards',
  },
  {
    key: 'admin.forms.filters',
    category: 'forms',
    location: 'Forms page - filter section',
    description: 'Form filter controls',
  },
  {
    key: 'admin.forms.search',
    category: 'forms',
    location: 'Forms page - search input',
    description: 'Form search input',
  },
  {
    key: 'admin.forms.table',
    category: 'forms',
    location: 'Forms page - forms table',
    description: 'Forms data table',
  },
  {
    key: 'admin.forms.types-info',
    category: 'forms',
    location: 'Forms page - types info section',
    description: 'Form types information card',
  },

  // Block Editor
  {
    key: 'puck.editor',
    category: 'editor',
    location: 'Block editor',
    description: 'Main block editor interface',
  },
  {
    key: 'puck.components',
    category: 'editor',
    location: 'Block editor - component library',
    description: 'Component library panel',
  },

  // Common Actions
  {
    key: 'action.save',
    category: 'actions',
    location: 'Various - save buttons',
    description: 'Save action button',
  },
  {
    key: 'action.publish',
    category: 'actions',
    location: 'Various - publish buttons',
    description: 'Publish action button',
  },
  {
    key: 'action.delete',
    category: 'actions',
    location: 'Various - delete buttons',
    description: 'Delete action button',
  },

  // Form Elements
  {
    key: 'form.required',
    category: 'forms',
    location: 'Various forms - required fields',
    description: 'Required field indicator',
  },

  // Common UI
  {
    key: 'ui.search',
    category: 'ui',
    location: 'Various - search inputs',
    description: 'Generic search input',
  },
  {
    key: 'ui.filter',
    category: 'ui',
    location: 'Various - filter controls',
    description: 'Generic filter controls',
  },
  {
    key: 'ui.pagination',
    category: 'ui',
    location: 'Various - pagination',
    description: 'Pagination controls',
  },
  {
    key: 'ui.bulk.actions',
    category: 'ui',
    location: 'Various - bulk action bars',
    description: 'Bulk actions panel',
  },

  // Help System
  {
    key: 'admin.help.mode',
    category: 'help',
    location: 'Help mode overlay',
    description: 'Help mode interface',
  },
  {
    key: 'admin.chat.assistant',
    category: 'help',
    location: 'AI chat assistant',
    description: 'AI chat assistant panel',
  },
]
