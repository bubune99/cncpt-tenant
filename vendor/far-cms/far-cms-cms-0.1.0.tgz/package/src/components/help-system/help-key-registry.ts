/**
 * Help Key Registry
 *
 * Central registry of all help keys used in the application.
 * This enables:
 * - AI tools to discover available help keys
 * - Validation of help keys
 * - Categorization for organization
 * - Tracking coverage
 * - AI guidance for content generation
 */

import { HELP_KEYS_ADMIN } from './help-keys-admin'
import { HELP_KEYS_SITE } from './help-keys-site'

export interface HelpKeyDefinition {
  key: string
  category: string
  location: string // Where in the UI this key is used
  description: string // Brief description for AI context

  // AI Guidance fields (optional, for enhanced AI content generation)
  aiGuidance?: string // Instructions for AI when writing help for this element
  commonQuestions?: string[] // Common questions users ask about this element
  relatedKeys?: string[] // Related help keys for cross-referencing
  difficulty?: 'basic' | 'intermediate' | 'advanced' // Complexity level
  entityAware?: boolean // Can have entity-specific content (e.g., help for specific product)
  suggestedFormat?: 'brief' | 'detailed' | 'tutorial' // Recommended content format
  includeMedia?: boolean // Suggests video/image would help
}

/**
 * AI Guidance definitions for categories
 * These provide default guidance when individual keys don't have specific guidance
 */
export const categoryGuidance: Record<string, {
  aiGuidance: string
  suggestedFormat: 'brief' | 'detailed' | 'tutorial'
  difficulty: 'basic' | 'intermediate' | 'advanced'
}> = {
  header: {
    aiGuidance: 'Keep explanations brief. Focus on what the action does and keyboard shortcuts if available.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  },
  sidebar: {
    aiGuidance: 'Explain what section this navigates to and what users can do there. Keep brief.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  },
  dashboard: {
    aiGuidance: 'Explain what the metric shows and how to interpret it. Include tips for improving numbers if relevant.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  },
  products: {
    aiGuidance: 'Product management is core to the store. Explain clearly with examples. Users often struggle with variants, pricing, and inventory.',
    suggestedFormat: 'detailed',
    difficulty: 'intermediate',
  },
  orders: {
    aiGuidance: 'Order management is time-sensitive. Focus on status meanings, next actions, and common workflows.',
    suggestedFormat: 'detailed',
    difficulty: 'intermediate',
  },
  customers: {
    aiGuidance: 'Customer data is sensitive. Emphasize what can be viewed vs edited. Explain relationship to orders.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  },
  pages: {
    aiGuidance: 'Page building uses the block editor. Explain the visual editor concept and how to add/arrange components.',
    suggestedFormat: 'tutorial',
    difficulty: 'intermediate',
  },
  blog: {
    aiGuidance: 'Blog supports both simple and visual (block) editors. Explain SEO implications of titles, slugs, and categories.',
    suggestedFormat: 'detailed',
    difficulty: 'intermediate',
  },
  workflows: {
    aiGuidance: 'Workflows are advanced automation. Explain triggers, conditions, and actions clearly. This is power-user territory.',
    suggestedFormat: 'tutorial',
    difficulty: 'advanced',
  },
  forms: {
    aiGuidance: 'Form builder creates data collection forms. Explain field types and where submissions go.',
    suggestedFormat: 'detailed',
    difficulty: 'intermediate',
  },
  media: {
    aiGuidance: 'Media library stores images and files. Explain upload limits, formats supported, and how to use media in content.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  },
  settings: {
    aiGuidance: 'Settings affect the entire store. Be careful to explain implications of changes. Some settings require technical knowledge.',
    suggestedFormat: 'detailed',
    difficulty: 'advanced',
  },
  shipping: {
    aiGuidance: 'Shipping configuration affects checkout. Explain carrier integrations, zones, and rate calculations.',
    suggestedFormat: 'detailed',
    difficulty: 'advanced',
  },
  analytics: {
    aiGuidance: 'Analytics help understand store performance. Explain what metrics mean and how to use insights.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  },
  users: {
    aiGuidance: 'User management controls who can access admin. Explain roles, permissions, and security implications.',
    suggestedFormat: 'detailed',
    difficulty: 'intermediate',
  },
  roles: {
    aiGuidance: 'Role-based access control is advanced. Explain permission inheritance and the principle of least privilege.',
    suggestedFormat: 'tutorial',
    difficulty: 'advanced',
  },
  'email-marketing': {
    aiGuidance: 'Email marketing involves campaigns, templates, and lists. Explain deliverability and compliance (CAN-SPAM, GDPR).',
    suggestedFormat: 'detailed',
    difficulty: 'intermediate',
  },
}

/**
 * Get AI guidance for a help key
 * Returns specific guidance if available, otherwise category guidance
 */
export function getAIGuidance(key: string): {
  aiGuidance: string
  suggestedFormat: 'brief' | 'detailed' | 'tutorial'
  difficulty: 'basic' | 'intermediate' | 'advanced'
  commonQuestions?: string[]
  relatedKeys?: string[]
} {
  const keyDef = helpKeyRegistry.find(k => k.key === key)

  if (keyDef?.aiGuidance) {
    return {
      aiGuidance: keyDef.aiGuidance,
      suggestedFormat: keyDef.suggestedFormat || 'brief',
      difficulty: keyDef.difficulty || 'basic',
      commonQuestions: keyDef.commonQuestions,
      relatedKeys: keyDef.relatedKeys,
    }
  }

  const category = keyDef?.category || key.split('.')[1] || 'general'
  const catGuidance = categoryGuidance[category]

  if (catGuidance) {
    return {
      ...catGuidance,
      commonQuestions: keyDef?.commonQuestions,
      relatedKeys: keyDef?.relatedKeys,
    }
  }

  return {
    aiGuidance: 'Provide clear, concise help for this UI element. Focus on what it does and how to use it.',
    suggestedFormat: 'brief',
    difficulty: 'basic',
  }
}

/**
 * All registered help keys organized by category
 */
export const helpKeyRegistry: HelpKeyDefinition[] = [...HELP_KEYS_ADMIN, ...HELP_KEYS_SITE]

/**
 * Get all help keys as a simple array
 */
export function getAllHelpKeys(): string[] {
  return helpKeyRegistry.map(def => def.key)
}

/**
 * Get help keys by category
 */
export function getHelpKeysByCategory(category: string): HelpKeyDefinition[] {
  return helpKeyRegistry.filter(def => def.category === category)
}

/**
 * Get all categories
 */
export function getHelpCategories(): string[] {
  return [...new Set(helpKeyRegistry.map(def => def.category))]
}

/**
 * Check if a help key is registered
 */
export function isValidHelpKey(key: string): boolean {
  return helpKeyRegistry.some(def => def.key === key)
}

/**
 * Get help key definition
 */
export function getHelpKeyDefinition(key: string): HelpKeyDefinition | undefined {
  return helpKeyRegistry.find(def => def.key === key)
}

/**
 * Get help keys summary for AI context
 */
export function getHelpKeysSummary(): {
  total: number
  categories: { name: string; count: number }[]
  keys: { key: string; category: string; description: string }[]
} {
  const categories = getHelpCategories().map(cat => ({
    name: cat,
    count: helpKeyRegistry.filter(def => def.category === cat).length,
  }))

  return {
    total: helpKeyRegistry.length,
    categories,
    keys: helpKeyRegistry.map(def => ({
      key: def.key,
      category: def.category,
      description: def.description,
    })),
  }
}
