/**
 * Help keys: admin header, sidebar, dashboard, products, orders, customers, pages, blog, media, email, shipping. Data only, moved from help-key-registry.ts on 2026-11-22 (size check);
 * the registry combines the parts in their original order.
 */
import type { HelpKeyDefinition } from './help-key-registry'

export const HELP_KEYS_ADMIN: HelpKeyDefinition[] = [
  // Admin Header
  {
    key: 'admin.header.search',
    category: 'header',
    location: 'Admin header - search bar',
    description: 'Global search input in the admin header',
  },
  {
    key: 'admin.header.notifications',
    category: 'header',
    location: 'Admin header - notifications button',
    description: 'Notifications bell icon button',
  },
  {
    key: 'admin.header.help',
    category: 'header',
    location: 'Admin header - help button',
    description: 'Help mode toggle button',
  },

  // Admin Sidebar
  {
    key: 'admin.sidebar.user-info',
    category: 'sidebar',
    location: 'Admin sidebar - user info section',
    description: 'Logged-in user info display',
  },
  {
    key: 'admin.sidebar.view-site',
    category: 'sidebar',
    location: 'Admin sidebar - view site link',
    description: 'Link to view the live storefront',
  },
  {
    key: 'admin.sidebar.sign-out',
    category: 'sidebar',
    location: 'Admin sidebar - sign out button',
    description: 'Sign out/logout button',
  },
  {
    key: 'admin.sidebar.collapse',
    category: 'sidebar',
    location: 'Admin sidebar - collapse toggle',
    description: 'Sidebar expand/collapse toggle',
  },
  {
    key: 'admin.sidebar.dashboard',
    category: 'sidebar',
    location: 'Admin sidebar - dashboard link',
    description: 'Navigation link to dashboard',
  },
  {
    key: 'admin.sidebar.products',
    category: 'sidebar',
    location: 'Admin sidebar - products link',
    description: 'Navigation link to products',
  },
  {
    key: 'admin.sidebar.orders',
    category: 'sidebar',
    location: 'Admin sidebar - orders link',
    description: 'Navigation link to orders',
  },
  {
    key: 'admin.sidebar.customers',
    category: 'sidebar',
    location: 'Admin sidebar - customers link',
    description: 'Navigation link to customers',
  },
  {
    key: 'admin.sidebar.pages',
    category: 'sidebar',
    location: 'Admin sidebar - pages link',
    description: 'Navigation link to pages',
  },
  {
    key: 'admin.sidebar.blog',
    category: 'sidebar',
    location: 'Admin sidebar - blog link',
    description: 'Navigation link to blog',
  },
  {
    key: 'admin.sidebar.media',
    category: 'sidebar',
    location: 'Admin sidebar - media link',
    description: 'Navigation link to media library',
  },
  {
    key: 'admin.sidebar.settings',
    category: 'sidebar',
    location: 'Admin sidebar - settings link',
    description: 'Navigation link to settings',
  },

  // Dashboard Page
  {
    key: 'admin.dashboard.metrics',
    category: 'dashboard',
    location: 'Dashboard page - metrics section',
    description: 'Performance metrics and charts',
  },
  {
    key: 'admin.dashboard.quick-actions',
    category: 'dashboard',
    location: 'Dashboard page - quick actions panel',
    description: 'Quick action buttons panel',
  },
  {
    key: 'admin.dashboard.stats',
    category: 'dashboard',
    location: 'Dashboard page - stats grid',
    description: 'Overview statistics cards grid',
  },
  {
    key: 'admin.dashboard.stat.users',
    category: 'dashboard',
    location: 'Dashboard page - users stat card',
    description: 'Total users statistic card',
  },
  {
    key: 'admin.dashboard.stat.products',
    category: 'dashboard',
    location: 'Dashboard page - products stat card',
    description: 'Total products statistic card',
  },
  {
    key: 'admin.dashboard.stat.orders',
    category: 'dashboard',
    location: 'Dashboard page - orders stat card',
    description: 'Total orders statistic card',
  },
  {
    key: 'admin.dashboard.stat.blog',
    category: 'dashboard',
    location: 'Dashboard page - blog stat card',
    description: 'Total blog posts statistic card',
  },
  {
    key: 'admin.dashboard.quick-links',
    category: 'dashboard',
    location: 'Dashboard page - quick links card',
    description: 'Quick navigation links card',
  },
  {
    key: 'admin.dashboard.content-management',
    category: 'dashboard',
    location: 'Dashboard page - content management card',
    description: 'Content management links card',
  },

  // Products Page
  {
    key: 'admin.products.actions',
    category: 'products',
    location: 'Products page - action buttons',
    description: 'Product action buttons (refresh, add)',
  },
  {
    key: 'admin.products.refresh',
    category: 'products',
    location: 'Products page - refresh button',
    description: 'Refresh product list button',
  },
  {
    key: 'admin.products.add',
    category: 'products',
    location: 'Products page - add button',
    description: 'Add new product button',
  },
  {
    key: 'admin.products.tabs',
    category: 'products',
    location: 'Products page - status tabs',
    description: 'Product status filter tabs',
  },
  {
    key: 'admin.products.filters',
    category: 'products',
    location: 'Products page - filter section',
    description: 'Product filter controls',
  },
  {
    key: 'admin.products.search',
    category: 'products',
    location: 'Products page - search input',
    description: 'Product search input',
  },
  {
    key: 'admin.products.table',
    category: 'products',
    location: 'Products page - products table',
    description: 'Products data table',
  },
  {
    key: 'admin.products.list',
    category: 'products',
    location: 'Products page - product list',
    description: 'Product listing view',
  },
  {
    key: 'admin.products.create',
    category: 'products',
    location: 'Products - create form',
    description: 'New product creation form',
  },
  {
    key: 'admin.products.variants',
    category: 'products',
    location: 'Product detail - variants section',
    description: 'Product variants management',
    aiGuidance: 'Variants are product variations like size, color, or material. Explain the relationship between options (attributes) and variants (combinations). Users often struggle with: setting different prices per variant, managing inventory per variant, and understanding that variants are generated from option combinations.',
    commonQuestions: [
      'How do I set different prices for each variant?',
      'Can variants have their own images?',
      'How do I track inventory per variant?',
      'What happens if I add a new option to an existing product?',
    ],
    relatedKeys: ['admin.products.inventory', 'admin.products.pricing', 'admin.products.create'],
    difficulty: 'intermediate',
    entityAware: true,
    suggestedFormat: 'detailed',
    includeMedia: true,
  },
  {
    key: 'admin.products.inventory',
    category: 'products',
    location: 'Product detail - inventory section',
    description: 'Product inventory management',
    aiGuidance: 'Inventory tracking helps prevent overselling. Explain the difference between tracked and untracked inventory, low stock alerts, and how inventory syncs with variants. Mention that inventory can be managed per-variant if variants exist.',
    commonQuestions: [
      'How do I set low stock alerts?',
      'What happens when inventory reaches zero?',
      'Can I allow backorders?',
      'How do I adjust inventory after a physical count?',
    ],
    relatedKeys: ['admin.products.variants', 'admin.orders.fulfillment'],
    difficulty: 'intermediate',
    entityAware: true,
    suggestedFormat: 'detailed',
  },
  {
    key: 'admin.products.pricing',
    category: 'products',
    location: 'Product detail - pricing section',
    description: 'Product pricing configuration',
    aiGuidance: 'Pricing affects checkout and can be complex with variants. Explain base price vs variant prices, compare-at prices (for sales), cost tracking for margin calculations, and tax settings. Currency is configured at store level.',
    commonQuestions: [
      'How do I put a product on sale?',
      'Can different variants have different prices?',
      'How do I track product costs for margin reporting?',
      'Are prices inclusive or exclusive of tax?',
    ],
    relatedKeys: ['admin.products.variants', 'admin.settings.taxes'],
    difficulty: 'intermediate',
    entityAware: true,
    suggestedFormat: 'detailed',
  },

  // Orders Page
  {
    key: 'admin.orders.actions',
    category: 'orders',
    location: 'Orders page - action buttons',
    description: 'Order action buttons',
  },
  {
    key: 'admin.orders.refresh',
    category: 'orders',
    location: 'Orders page - refresh button',
    description: 'Refresh orders button',
  },
  {
    key: 'admin.orders.export',
    category: 'orders',
    location: 'Orders page - export button',
    description: 'Export orders to CSV button',
  },
  {
    key: 'admin.orders.new',
    category: 'orders',
    location: 'Orders page - new order button',
    description: 'Create new order button',
  },
  {
    key: 'admin.orders.stats',
    category: 'orders',
    location: 'Orders page - stats cards',
    description: 'Order statistics cards',
  },
  {
    key: 'admin.orders.tabs',
    category: 'orders',
    location: 'Orders page - status tabs',
    description: 'Order status filter tabs',
  },
  {
    key: 'admin.orders.filters',
    category: 'orders',
    location: 'Orders page - filter section',
    description: 'Order filter controls',
  },
  {
    key: 'admin.orders.search',
    category: 'orders',
    location: 'Orders page - search input',
    description: 'Order search input',
  },
  {
    key: 'admin.orders.bulk-actions',
    category: 'orders',
    location: 'Orders page - bulk actions bar',
    description: 'Bulk order actions panel',
  },
  {
    key: 'admin.orders.table',
    category: 'orders',
    location: 'Orders page - orders table',
    description: 'Orders data table',
  },
  {
    key: 'admin.orders.list',
    category: 'orders',
    location: 'Orders page - order list',
    description: 'Order listing view',
  },
  {
    key: 'admin.orders.details',
    category: 'orders',
    location: 'Order detail page',
    description: 'Single order detail view',
  },
  {
    key: 'admin.orders.status',
    category: 'orders',
    location: 'Order - status section',
    description: 'Order status display/management',
  },
  {
    key: 'admin.orders.refund',
    category: 'orders',
    location: 'Order - refund dialog',
    description: 'Order refund processing',
  },

  // Customers
  {
    key: 'admin.customers.list',
    category: 'customers',
    location: 'Customers page - customer list',
    description: 'Customer listing view',
  },
  {
    key: 'admin.customers.profile',
    category: 'customers',
    location: 'Customer detail page',
    description: 'Individual customer profile',
  },

  // Pages
  {
    key: 'admin.pages.list',
    category: 'pages',
    location: 'Pages page - page list',
    description: 'CMS pages listing',
  },
  {
    key: 'admin.pages.editor',
    category: 'pages',
    location: 'Page editor (block editor)',
    description: 'Visual page editor',
  },

  // Blog
  {
    key: 'admin.blog.page',
    category: 'blog',
    location: 'Blog page - main container',
    description: 'Blog posts page container',
  },
  {
    key: 'admin.blog.actions',
    category: 'blog',
    location: 'Blog page - action buttons',
    description: 'Blog action buttons (categories, tags, refresh, new)',
  },
  {
    key: 'admin.blog.categories',
    category: 'blog',
    location: 'Blog page - categories button',
    description: 'Navigate to blog categories',
  },
  {
    key: 'admin.blog.tags',
    category: 'blog',
    location: 'Blog page - tags button',
    description: 'Navigate to blog tags',
  },
  {
    key: 'admin.blog.refresh',
    category: 'blog',
    location: 'Blog page - refresh button',
    description: 'Refresh blog posts list',
  },
  {
    key: 'admin.blog.new',
    category: 'blog',
    location: 'Blog page - new post button',
    description: 'Create new blog post',
  },
  {
    key: 'admin.blog.tabs',
    category: 'blog',
    location: 'Blog page - status tabs',
    description: 'Blog post status filter tabs',
  },
  {
    key: 'admin.blog.filters',
    category: 'blog',
    location: 'Blog page - filter section',
    description: 'Blog post filter controls',
  },
  {
    key: 'admin.blog.search',
    category: 'blog',
    location: 'Blog page - search input',
    description: 'Blog post search input',
  },
  {
    key: 'admin.blog.status-filter',
    category: 'blog',
    location: 'Blog page - status filter',
    description: 'Blog post status filter dropdown',
  },
  {
    key: 'admin.blog.table',
    category: 'blog',
    location: 'Blog page - posts table',
    description: 'Blog posts data table',
  },
  {
    key: 'admin.blog.list',
    category: 'blog',
    location: 'Blog page - post list',
    description: 'Blog posts listing',
  },
  {
    key: 'admin.blog.editor',
    category: 'blog',
    location: 'Blog post editor',
    description: 'Blog post editor',
  },

  // Media
  {
    key: 'admin.media.page',
    category: 'media',
    location: 'Media page - main container',
    description: 'Media manager page container',
  },
  {
    key: 'admin.media.header',
    category: 'media',
    location: 'Media page - header',
    description: 'Media manager header section',
  },
  {
    key: 'admin.media.manager',
    category: 'media',
    location: 'Media page - manager component',
    description: 'Media manager component',
  },
  {
    key: 'admin.media.library',
    category: 'media',
    location: 'Media library page',
    description: 'Media file management',
  },

  // Email Marketing
  {
    key: 'admin.email-marketing.page',
    category: 'email-marketing',
    location: 'Email Marketing page - main container',
    description: 'Email marketing page container',
  },
  {
    key: 'admin.email-marketing.header',
    category: 'email-marketing',
    location: 'Email Marketing page - header',
    description: 'Email marketing page header section',
  },
  {
    key: 'admin.email-marketing.actions',
    category: 'email-marketing',
    location: 'Email Marketing page - action buttons',
    description: 'Email marketing action buttons',
  },
  {
    key: 'admin.email-marketing.refresh',
    category: 'email-marketing',
    location: 'Email Marketing page - refresh button',
    description: 'Refresh campaigns list',
  },
  {
    key: 'admin.email-marketing.new',
    category: 'email-marketing',
    location: 'Email Marketing page - new campaign button',
    description: 'Create new email campaign',
  },
  {
    key: 'admin.email-marketing.stats',
    category: 'email-marketing',
    location: 'Email Marketing page - stats cards',
    description: 'Email marketing statistics cards',
  },
  {
    key: 'admin.email-marketing.tabs',
    category: 'email-marketing',
    location: 'Email Marketing page - tabs',
    description: 'Email marketing tabs (campaigns, automated, templates, subscribers)',
  },
  {
    key: 'admin.email-marketing.campaigns-tab',
    category: 'email-marketing',
    location: 'Email Marketing page - campaigns tab',
    description: 'All campaigns tab content',
  },
  {
    key: 'admin.email-marketing.filters',
    category: 'email-marketing',
    location: 'Email Marketing page - filter section',
    description: 'Campaign filter controls',
  },
  {
    key: 'admin.email-marketing.search',
    category: 'email-marketing',
    location: 'Email Marketing page - search input',
    description: 'Campaign search input',
  },
  {
    key: 'admin.email-marketing.status-filter',
    category: 'email-marketing',
    location: 'Email Marketing page - status filter',
    description: 'Campaign status filter dropdown',
  },
  {
    key: 'admin.email-marketing.type-filter',
    category: 'email-marketing',
    location: 'Email Marketing page - type filter',
    description: 'Campaign type filter dropdown',
  },
  {
    key: 'admin.email-marketing.table',
    category: 'email-marketing',
    location: 'Email Marketing page - campaigns table',
    description: 'Campaigns data table',
  },
  {
    key: 'admin.email-marketing.automated-tab',
    category: 'email-marketing',
    location: 'Email Marketing page - automated tab',
    description: 'Automated workflows tab',
  },
  {
    key: 'admin.email-marketing.automated-workflows',
    category: 'email-marketing',
    location: 'Email Marketing page - automated workflows',
    description: 'Automated email workflows configuration',
  },
  {
    key: 'admin.email-marketing.templates-tab',
    category: 'email-marketing',
    location: 'Email Marketing page - templates tab',
    description: 'Email templates tab',
  },
  {
    key: 'admin.email-marketing.templates',
    category: 'email-marketing',
    location: 'Email Marketing page - templates',
    description: 'Email templates management',
  },
  {
    key: 'admin.email-marketing.subscribers-tab',
    category: 'email-marketing',
    location: 'Email Marketing page - subscribers tab',
    description: 'Subscribers tab',
  },
  {
    key: 'admin.email-marketing.subscribers',
    category: 'email-marketing',
    location: 'Email Marketing page - subscribers',
    description: 'Email subscribers management',
  },

  // Shipping
  {
    key: 'admin.shipping.page',
    category: 'shipping',
    location: 'Shipping page - main container',
    description: 'Shipping page container',
  },
  {
    key: 'admin.shipping.tabs',
    category: 'shipping',
    location: 'Shipping page - tabs',
    description: 'Shipping tabs (create, settings, shipments)',
  },
  {
    key: 'admin.shipping.create',
    category: 'shipping',
    location: 'Shipping page - create tab',
    description: 'Create shipment tab',
  },
  {
    key: 'admin.shipping.settings',
    category: 'shipping',
    location: 'Shipping page - settings tab',
    description: 'Shipping settings tab',
  },
  {
    key: 'admin.shipping.shipments-list',
    category: 'shipping',
    location: 'Shipping page - shipments list tab',
    description: 'Shipments list tab',
  },
  {
    key: 'admin.shipping.api-config',
    category: 'shipping',
    location: 'Shipping page - API config',
    description: 'Shipping API configuration',
  },
  {
    key: 'admin.shipping.from-address',
    category: 'shipping',
    location: 'Shipping page - from address',
    description: 'Default from address configuration',
  },
  {
    key: 'admin.shipping.carriers',
    category: 'shipping',
    location: 'Shipping page - carriers',
    description: 'Shipping carriers configuration',
  },
  {
    key: 'admin.shipping.save',
    category: 'shipping',
    location: 'Shipping page - save button',
    description: 'Save shipping settings button',
  },
]
