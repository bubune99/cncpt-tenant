/**
 * Theme-aware Recharts styling for the admin dashboard. The admin theme
 * tokens are oklch values (globals.css), so colours read them via var()
 * directly — `hsl(var(--x))` is invalid and rendered black/unreadable.
 */

export const CHART_TOOLTIP = {
  contentStyle: {
    background: 'var(--popover)',
    color: 'var(--popover-foreground)',
    border: '1px solid var(--border)',
    borderRadius: 8,
    fontSize: 12,
    boxShadow: '0 4px 16px rgb(0 0 0 / 0.15)',
  },
  labelStyle: { color: 'var(--popover-foreground)', fontWeight: 600 },
  itemStyle: { color: 'var(--popover-foreground)' },
  cursor: { stroke: 'var(--border)', fill: 'var(--muted)', fillOpacity: 0.4 },
} as const

export const CHART_TICK = { fontSize: 11, fill: 'var(--muted-foreground)' } as const

export const CHART_PRIMARY = 'var(--primary)'
