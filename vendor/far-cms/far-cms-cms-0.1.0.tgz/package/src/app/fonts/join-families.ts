/**
 * Joins a font's Latin and Latin Extended faces into one font-family list:
 * the Latin face, then the extended face, then the Latin face's size-matched fallback.
 * The fallback (a local font with no unicode-range) must come last, or it would catch
 * ɖ ɛ ɔ ŋ before the extended face does. Pure; asserted by fonts.assert.ts.
 */
export function joinSubsetFamilies(latin: string, latinExt: string): string {
  const [primary, ...fallbacks] = latin.split(',').map((s) => s.trim()).filter(Boolean);
  const ext = latinExt.split(',').map((s) => s.trim()).filter(Boolean);
  return [primary, ...ext, ...fallbacks].filter(Boolean).join(', ');
}
