/** Who may read / restore an entity's history (rules: lib/ade-bindings/history-access). */
import type { AuthContext } from '../../../../lib/permissions/middleware'
import { canReadHistory, canRestoreHistory } from '../../../../lib/ade-bindings/history-access'

export const ID = /^[A-Za-z0-9_:-]{1,120}$/

export function canRead(auth: AuthContext, entityType: string, entityId: string): boolean {
  return canReadHistory(auth.permissions, entityType, entityId)
}

export function canRestore(auth: AuthContext, entityType: string, entityId: string): boolean {
  return canRestoreHistory(auth.permissions, entityType, entityId)
}
