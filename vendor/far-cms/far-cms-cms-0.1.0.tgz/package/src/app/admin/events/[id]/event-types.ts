// Types and shared values for the event editor (src/app/admin/events/[id]/page.tsx).

export interface EventData {
  id: string;
  title: string;
  slug: string;
  description?: string;
  shortDescription?: string;
  /** The API's name (lib/events/form-fields): there is no `type`. */
  eventType?: "IN_PERSON" | "VIRTUAL" | "HYBRID";
  status: "DRAFT" | "PUBLISHED" | "CANCELLED" | "COMPLETED";
  startDate?: string;
  endDate?: string;
  timezone?: string;
  capacity?: number;
  featuredImageUrl?: string;
  metaTitle?: string;
  metaDescription?: string;
  venueName?: string;
  venueAddress?: string;
  venueCity?: string;
  venueState?: string;
  venueCountry?: string;
  venueZip?: string;
  virtualUrl?: string;
  virtualPlatform?: string;
  organizerName?: string;
  organizerEmail?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TicketType {
  id: string;
  name: string;
  description?: string;
  price: number;
  quantity?: number;
  maxPerOrder?: number;
  salesStart?: string;
  salesEnd?: string;
  active: boolean;
  _count?: { registrations: number };
}

export interface ScheduleItem {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime?: string;
  location?: string;
  day: number;
  speakerId?: string;
  speaker?: Speaker;
}

export interface Speaker {
  id: string;
  name: string;
  title?: string;
  bio?: string;
  avatarUrl?: string;
  company?: string;
  website?: string;
  twitter?: string;
  linkedin?: string;
}

export interface Registration {
  id: string;
  name: string;
  email: string;
  status: "PENDING" | "CONFIRMED" | "CANCELLED" | "REFUNDED" | "WAITLISTED";
  amount: number;
  checkedIn: boolean;
  createdAt: string;
  ticketType?: { name: string };
}

export const REG_TONE: Record<string, 'neutral' | 'good' | 'warn' | 'strong'> = {
  PENDING: 'neutral',
  CONFIRMED: 'good',
  CANCELLED: 'warn',
  REFUNDED: 'neutral',
  WAITLISTED: 'strong',
};

export interface TicketForm {
  name: string;
  description: string;
  price: number;
  quantity: string;
  maxPerOrder: string;
  salesStart: string;
  salesEnd: string;
  active: boolean;
}

export interface ScheduleForm {
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  location: string;
  day: number;
  speakerId: string;
}

export interface SpeakerForm {
  name: string;
  title: string;
  bio: string;
  avatarUrl: string;
  company: string;
  website: string;
  twitter: string;
  linkedin: string;
}

export const formatPrice = (cents: number) => {
  if (cents === 0) return "Free";
  return `$${(cents / 100).toFixed(2)}`;
};
