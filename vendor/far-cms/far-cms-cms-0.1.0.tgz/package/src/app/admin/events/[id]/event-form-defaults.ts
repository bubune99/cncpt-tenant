/** Empty forms for an event's tickets, schedule items and speakers (split from page.tsx, 2026-11-22, size rule). */

export const emptyTicketForm = () => ({
  name: "",
  description: "",
  price: 0,
  quantity: "",
  maxPerOrder: "",
  salesStart: "",
  salesEnd: "",
  active: true,
});

export const emptyScheduleForm = (day: number) => ({
  title: "",
  description: "",
  startTime: "",
  endTime: "",
  location: "",
  day,
  speakerId: "",
});

export const emptySpeakerForm = () => ({
  name: "",
  title: "",
  bio: "",
  avatarUrl: "",
  company: "",
  website: "",
  twitter: "",
  linkedin: "",
});
