/**
 * Authenticated Routes Module
 *
 * Provides hardcoded authenticated areas with dynamic
 * CMS page integration and permission-based navigation.
 */

// Types
export type {
  NavItem,
  NavGroup,
  AuthenticatedAreaConfig,
  DynamicPageRegistration,
  NavigationState,
  NavigationUserContext,
  FilteredNavigation,
} from './types';

// Configuration
export {
  authenticatedAreas,
  dashboardArea,
  appArea,
  getAreaConfig,
  getAreaByPath,
  isAuthenticatedPath,
  getDynamicPagesPath,
} from './config';

// Navigation
export {
  getDynamicPagesForArea,
  mergeNavigation,
  filterNavigationByPermissions,
  getAreaNavigation,
  registerPageForArea,
  getBreadcrumbs,
} from './navigation';
