/**
 * Authenticated Areas Configuration
 *
 * Defines the hardcoded authenticated areas with their
 * static navigation and dynamic page settings.
 */

import type { AuthenticatedAreaConfig } from './types';

/**
 * Dashboard Area - Customer/User facing portal
 */
export const dashboardArea: AuthenticatedAreaConfig = {
  id: 'dashboard',
  name: 'Dashboard',
  basePath: '/dashboard',
  dynamicPagesPath: '/dashboard/pages',
  permission: undefined, // Any authenticated user
  allowDynamicPages: true,
  dynamicPagesNavGroup: 'pages',
  layout: {
    showSidebar: true,
    sidebarWidth: 240,
    showHeader: true,
    showBreadcrumbs: true,
  },
  staticNavGroups: [
    {
      id: 'main',
      label: 'Main',
      order: 0,
      collapsible: false,
      defaultExpanded: true,
      items: [
        {
          id: 'dashboard-home',
          label: 'Home',
          href: '/dashboard',
          icon: 'Home',
          order: 0,
        },
        {
          id: 'dashboard-profile',
          label: 'My Profile',
          href: '/account/profile',
          icon: 'User',
          order: 1,
        },
      ],
    },
    {
      id: 'pages',
      label: 'Pages',
      order: 1,
      collapsible: true,
      defaultExpanded: true,
      items: [
        // Dynamic CMS pages will be added here
      ],
    },
    {
      id: 'account',
      label: 'Account',
      order: 2,
      collapsible: true,
      defaultExpanded: false,
      items: [
        // My Orders lives on the account home, shown only while the shop is on (lib/account/account-home).
        {
          id: 'dashboard-settings',
          label: 'Settings',
          href: '/account/settings',
          icon: 'Settings',
          order: 1,
        },
      ],
    },
  ],
};

/**
 * App Area - Application workspace
 */
export const appArea: AuthenticatedAreaConfig = {
  id: 'app',
  name: 'App',
  basePath: '/app',
  dynamicPagesPath: '/app/pages',
  permission: undefined,
  allowDynamicPages: true,
  dynamicPagesNavGroup: 'workspace',
  layout: {
    showSidebar: true,
    sidebarWidth: 260,
    showHeader: true,
    showBreadcrumbs: true,
  },
  staticNavGroups: [
    {
      id: 'main',
      label: 'Main',
      order: 0,
      collapsible: false,
      defaultExpanded: true,
      items: [
        {
          id: 'app-home',
          label: 'Home',
          href: '/app',
          icon: 'LayoutDashboard',
          order: 0,
        },
      ],
    },
    {
      id: 'workspace',
      label: 'Workspace',
      order: 1,
      collapsible: true,
      defaultExpanded: true,
      items: [
        // Dynamic CMS pages will be added here
      ],
    },
    // A Tools group (Files, Calendar) was listed here with no pages behind it (404); add it back with its pages.
  ],
};

/**
 * All authenticated areas
 */
export const authenticatedAreas: AuthenticatedAreaConfig[] = [
  dashboardArea,
  appArea,
];

/**
 * Get area configuration by ID
 */
export function getAreaConfig(areaId: string): AuthenticatedAreaConfig | undefined {
  return authenticatedAreas.find(area => area.id === areaId);
}

/**
 * Get area configuration by path
 */
export function getAreaByPath(path: string): AuthenticatedAreaConfig | undefined {
  return authenticatedAreas.find(area => path.startsWith(area.basePath));
}

/**
 * Check if a path is within an authenticated area
 */
export function isAuthenticatedPath(path: string): boolean {
  return authenticatedAreas.some(area => path.startsWith(area.basePath));
}

/**
 * Get the dynamic pages path for an area
 */
export function getDynamicPagesPath(areaId: string): string | undefined {
  const area = getAreaConfig(areaId);
  return area?.dynamicPagesPath;
}
