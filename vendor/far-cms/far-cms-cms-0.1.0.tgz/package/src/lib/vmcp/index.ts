/**
 * VMCP - Virtualized Model Context Protocol
 *
 * Database-driven dynamic tool management for AI agents.
 * Allows agents to create, edit, and manage their own tools at runtime.
 *
 * Based on: https://github.com/farcncpt/vmcp
 */

import { tool } from 'ai';
import { z } from 'zod';
import * as registry from './registry';
import { executeTool } from './runtime';
import { vmcpTools } from './tools';
import type { MountedTool, JSONSchema } from './types';
import { reservedToolNameReason, toolKeyFor } from './reserved-names';

// Re-export types
export * from './types';

// Re-export registry functions
export {
  initializeRegistry,
  listTools,
  getTool,
  createTool,
  updateTool,
  deleteTool,
  mountTool,
  dismountTool,
  getMountedTools,
  searchTools,
  getStats,
} from './registry';

// Re-export runtime functions
export { executeTool, testTool } from './runtime';

// Re-export management tools
export { vmcpTools } from './tools';

// Re-export permission functions (simplified - native AI SDK v6 handles approvals)
export {
  getVmcpSettings,
  updateVmcpSettings,
  enableAutonomousMode,
  disableAutonomousMode,
  isAutonomousMode,
  type VmcpPermissionMode,
  type VmcpSettings,
} from './permissions';

/**
 * Convert a mounted primitive to an AI SDK tool
 */
function primitiveToAiTool(mounted: MountedTool) {
  const primitive = mounted.primitive;
  const schema = primitive.inputSchema as unknown as JSONSchema;

  // Convert JSON Schema to Zod schema
  const zodProperties: Record<string, z.ZodTypeAny> = {};

  if (schema.properties) {
    for (const [key, prop] of Object.entries(schema.properties)) {
      let zodType: z.ZodTypeAny;

      switch (prop.type) {
        case 'string':
          zodType = z.string();
          break;
        case 'number':
          zodType = z.number();
          break;
        case 'integer':
          zodType = z.number().int();
          break;
        case 'boolean':
          zodType = z.boolean();
          break;
        case 'array':
          zodType = z.array(z.unknown());
          break;
        case 'object':
          zodType = z.record(z.string(), z.unknown());
          break;
        default:
          zodType = z.unknown();
      }

      if (prop.description) {
        zodType = zodType.describe(prop.description);
      }

      if (!schema.required?.includes(key)) {
        zodType = zodType.optional();
      }

      zodProperties[key] = zodType;
    }
  }

  const inputSchema = z.object(zodProperties);

  return tool({
    description: primitive.description,
    inputSchema,
    execute: async (input) => {
      const result = await executeTool(
        primitive,
        input as Record<string, unknown>
      );

      if (!result.success) {
        return { error: result.error };
      }

      return result.output;
    },
  });
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyTool = ReturnType<typeof tool<any, any>>;

/**
 * Get all dynamic tools as AI SDK tools
 * Combines VMCP management tools with mounted primitives
 */
export async function getDynamicTools(): Promise<Record<string, AnyTool>> {
  // Initialize registry if needed
  const mounted = registry.getMountedTools();

  if (mounted.length === 0) {
    await registry.initializeRegistry();
  }

  // Convert mounted primitives to AI tools
  const dynamicTools: Record<string, AnyTool> = {};

  for (const mountedTool of registry.getMountedTools()) {
    try {
      // Sanitize tool name: AI providers require [a-zA-Z0-9_-]+ (no dots)
      const toolName = toolKeyFor(mountedTool.primitive.name);
      // A stored tool never takes a built-in's name (it would inherit the built-in's rules).
      if (reservedToolNameReason(toolName)) {
        console.warn(`[VMCP] Skipping stored tool "${toolName}": the name is reserved`);
        continue;
      }
      dynamicTools[toolName] = primitiveToAiTool(mountedTool);
    } catch (error) {
      console.error(
        `[VMCP] Failed to convert tool ${mountedTool.primitive.name}:`,
        error
      );
    }
  }

  return dynamicTools;
}

/**
 * Get all tools (management + dynamic)
 */
export async function getAllVmcpTools(): Promise<Record<string, AnyTool>> {
  const dynamicTools = await getDynamicTools();

  return {
    ...(vmcpTools as Record<string, AnyTool>),
    ...dynamicTools,
  };
}

/**
 * Seed initial tools for the CMS
 */
export async function seedDefaultTools(): Promise<void> {
  const existingTools = await registry.listTools({ limit: 1 });

  if (existingTools.length > 0) {
    console.log('[VMCP] Tools already exist, skipping seed');
    return;
  }

  console.log('[VMCP] Seeding default tools...');

  // Product tools
  await registry.createTool({
    name: 'get_product_by_sku',
    description: 'Get a product by its SKU code',
    category: 'commerce',
    tags: ['product', 'lookup'],
    inputSchema: {
      type: 'object',
      properties: {
        sku: { type: 'string', description: 'Product SKU code' },
      },
      required: ['sku'],
    },
    handler: `
const product = await context.db.products.findUnique({
  where: { sku: input.sku },
  include: { variants: true, images: true }
});

if (!product) {
  return { error: 'Product not found' };
}

return {
  id: product.id,
  title: product.title,
  sku: product.sku,
  price: context.utils.formatCurrency(product.basePrice),
  status: product.status,
  variantCount: product.variants.length,
  imageCount: product.images.length,
  adminUrl: '/admin/products/' + product.id
};
`,
  });

  // Order tools
  await registry.createTool({
    name: 'get_order_details',
    description: 'Get details of an order by ID',
    category: 'commerce',
    tags: ['order', 'lookup'],
    inputSchema: {
      type: 'object',
      properties: {
        orderId: { type: 'string', description: 'Order ID' },
      },
      required: ['orderId'],
    },
    handler: `
const order = await context.db.orders.findUnique({
  where: { id: input.orderId }
});

if (!order) {
  return { error: 'Order not found' };
}

return {
  id: order.id,
  orderNumber: order.orderNumber,
  status: order.status,
  total: context.utils.formatCurrency(order.total),
  createdAt: context.utils.formatDate(order.createdAt),
  adminUrl: '/admin/orders/' + order.id
};
`,
  });

  // Content tools
  await registry.createTool({
    name: 'search_blog_posts',
    description: 'Search blog posts by title or status',
    category: 'content',
    tags: ['blog', 'content', 'search'],
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search query for blog post title' },
        status: { type: 'string', description: 'Filter by status: DRAFT, PUBLISHED, ARCHIVED' },
        limit: { type: 'integer', description: 'Max results (default: 10)' },
      },
    },
    handler: `
const where = {};
if (input.query) {
  where.title = { contains: input.query, mode: 'insensitive' };
}
if (input.status) {
  where.status = input.status;
}

const posts = await context.db.blogPosts.findMany({
  where,
  take: input.limit || 10,
  orderBy: { createdAt: 'desc' }
});

return {
  count: posts.length,
  posts: posts.map(p => ({
    id: p.id,
    title: p.title,
    slug: p.slug,
    status: p.status,
    createdAt: context.utils.formatDate(p.createdAt),
    adminUrl: '/admin/blog/' + p.id
  }))
};
`,
  });

  // Analytics tool
  await registry.createTool({
    name: 'get_sales_summary',
    description: 'Get a summary of sales for a given period',
    category: 'analytics',
    tags: ['sales', 'analytics', 'report'],
    inputSchema: {
      type: 'object',
      properties: {
        days: { type: 'integer', description: 'Number of days to look back (default: 30)' },
      },
    },
    handler: `
const days = input.days || 30;
const startDate = new Date();
startDate.setDate(startDate.getDate() - days);

const orders = await context.db.orders.findMany({
  where: {
    createdAt: { gte: startDate },
    status: { not: 'CANCELLED' }
  }
});

const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
const avgOrderValue = orders.length > 0 ? totalRevenue / orders.length : 0;

return {
  period: days + ' days',
  totalOrders: orders.length,
  totalRevenue: context.utils.formatCurrency(totalRevenue),
  averageOrderValue: context.utils.formatCurrency(avgOrderValue),
  ordersPerDay: (orders.length / days).toFixed(1)
};
`,
  });

  console.log('[VMCP] Default tools seeded successfully');
}
