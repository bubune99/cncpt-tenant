/**
 * Version history for media items ('media'): what people write about a file
 * — title, alt text, caption, description — plus where it is filed, its
 * tags and whether it's in the bin. The file itself isn't versioned
 * (storage keeps one copy), so a restore never brings back an old image.
 */

import { prisma } from '../db'
import { historyRecorder, registerHistory } from '../ade-bindings/history'
import type { RestorePolicy } from '../ade/history'

type Obj = Record<string, unknown>

async function loadMedia(id: string): Promise<Obj | null> {
  const m = await prisma.media.findUnique({
    where: { id },
    select: { title: true, alt: true, caption: true, description: true, folderId: true, deletedAt: true, tags: { select: { tagId: true } } },
  })
  if (!m) return null
  const { tags, ...rest } = m
  return { ...rest, tagIds: tags.map((t) => t.tagId).sort() }
}

export const mediaHistory = historyRecorder('media', loadMedia)

/** What a media restore may write (never the file itself). */
export const MEDIA_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    title: { class: 'restorable', type: 'string' },
    alt: { class: 'restorable', type: 'string' },
    caption: { class: 'restorable', type: 'string' },
    description: { class: 'restorable', type: 'string' },
    folderId: { class: 'restorable', type: 'string' },
    tagIds: { class: 'restorable', type: 'string[]' },
    deletedAt: { class: 'guarded', type: 'date', consequence: 'It moves into or out of the bin — pages using it are affected' },
  },
}

registerHistory({
  entityType: 'media',
  policy: MEDIA_POLICY,
  missingRefs: async (t) => {
    const out: Record<string, string> = {}
    if (typeof t.folderId === 'string' && !(await prisma.mediaFolder.findUnique({ where: { id: t.folderId }, select: { id: true } }))) out.folderId = 'That folder was deleted'
    const tags = Array.isArray(t.tagIds) ? (t.tagIds as string[]) : []
    if (tags.length && (await prisma.mediaTag.count({ where: { id: { in: tags } } })) < tags.length) out.tagIds = 'A tag in that version was deleted'
    return out
  },
  editPermission: 'media.edit',
  ignore: new Set(['id', 'createdAt', 'updatedAt']),
  // Undoing a newly made file (e.g. a picture the assistant generated) moves it to the bin.
  undoCreate: async (id, actor, reason) => {
    const { deleteMedia } = await import('./index')
    await deleteMedia(id, false, { actor, reason })
  },
  isUndoneCreate: (now) => !now || !!now.deletedAt,
  load: loadMedia,
  nameOf: async (id) => {
    const m = await prisma.media.findUnique({ where: { id }, select: { title: true, originalName: true } })
    return m ? m.title || m.originalName : null
  },
  fieldLabels: {
    title: 'Title',
    alt: 'Description for screen readers',
    caption: 'Caption',
    description: 'Notes',
    folderId: 'Folder',
    deletedAt: 'In the bin',
    tagIds: 'Tags',
  },
  async save(id, patch, actor, reason) {
    const { tagIds, folderId, ...fields } = patch
    await mediaHistory.update(id, { actor, reason }, async () => {
      // A folder or tag deleted since is skipped (the item goes to the top level / loses that tag).
      const folderOk = folderId === undefined || folderId === null || !!(await prisma.mediaFolder.findUnique({ where: { id: String(folderId) }, select: { id: true } }))
      await prisma.$transaction(async (tx) => {
        const data = { ...fields, ...(folderId !== undefined ? { folderId: folderOk ? (folderId as string | null) : null } : {}) }
        if (Object.keys(data).length) await tx.media.update({ where: { id }, data })
        if (Array.isArray(tagIds)) {
          await tx.mediaTagOnMedia.deleteMany({ where: { mediaId: id } })
          const exist = (await tx.mediaTag.findMany({ where: { id: { in: tagIds as string[] } }, select: { id: true } })).map((t) => t.id)
          if (exist.length) await tx.mediaTagOnMedia.createMany({ data: exist.map((tagId) => ({ mediaId: id, tagId })) })
        }
      })
    })
  },
})
