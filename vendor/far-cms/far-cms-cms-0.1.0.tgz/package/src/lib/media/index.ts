/**
 * Media Library - Core CRUD Operations
 */

import { mediaSearchWhere, type MediaSearchClause } from './search'
import { prisma } from '../db'
import type {
  MediaFilters,
  MediaWithRelations,
  MediaListResponse,
  MediaCreateInput,
  MediaUpdateInput,
} from './types'

// Type augmentation for Prisma client with extended Media model
// This allows the code to compile before prisma generate is run with new schema
type PrismaWithMedia = typeof prisma & {
  media: {
    findMany: (args: any) => Promise<any[]>
    findUnique: (args: any) => Promise<any | null>
    create: (args: any) => Promise<any>
    update: (args: any) => Promise<any>
    delete: (args: any) => Promise<any>
    updateMany: (args: any) => Promise<{ count: number }>
    deleteMany: (args: any) => Promise<{ count: number }>
    count: (args: any) => Promise<number>
    groupBy: (args: any) => Promise<any[]>
    aggregate: (args: any) => Promise<any>
  }
  mediaTagOnMedia: {
    createMany: (args: any) => Promise<{ count: number }>
    deleteMany: (args: any) => Promise<{ count: number }>
  }
}

const db = prisma as PrismaWithMedia

// Type for media where input
interface MediaWhereInput {
  id?: { in: string[] }
  deletedAt?: null | Date | { gte?: Date }
  folderId?: string | null
  mimeType?: { startsWith?: string; contains?: string } | string
  OR?: any[]
  AND?: MediaSearchClause[]
  tags?: { some: { tagId: { in: string[] } } }
  createdAt?: { gte?: Date }
}

// Type for media order by
interface MediaOrderByInput {
  originalName?: 'asc' | 'desc'
  size?: 'asc' | 'desc'
  mimeType?: 'asc' | 'desc'
  createdAt?: 'asc' | 'desc'
}

// =============================================================================
// LIST MEDIA
// =============================================================================

export async function listMedia(filters: MediaFilters = {}): Promise<MediaListResponse> {
  const {
    folderId,
    type,
    search,
    tagIds,
    includeDeleted = false,
    page = 1,
    limit = 50,
    sortBy = 'createdAt',
    sortOrder = 'desc',
  } = filters

  const where: MediaWhereInput = {}

  // Soft delete filter
  if (!includeDeleted) {
    where.deletedAt = null
  }

  // Folder filter
  if (folderId !== undefined) {
    where.folderId = folderId
  }

  // Type filter (by mime type prefix)
  if (type) {
    switch (type) {
      case 'image':
        where.mimeType = { startsWith: 'image/' }
        break
      case 'video':
        where.mimeType = { startsWith: 'video/' }
        break
      case 'audio':
        where.mimeType = { startsWith: 'audio/' }
        break
      case 'document':
        where.OR = [
          { mimeType: 'application/pdf' },
          { mimeType: { contains: 'document' } },
          { mimeType: { contains: 'spreadsheet' } },
          { mimeType: { contains: 'presentation' } },
          { mimeType: { contains: 'word' } },
          { mimeType: { contains: 'excel' } },
          { mimeType: { contains: 'powerpoint' } },
          { mimeType: 'text/plain' },
          { mimeType: 'text/csv' },
        ]
        break
    }
  }

  // Search filter: every word, each in any name field (lib/media/search). Added to
  // AND so it never replaces the file-type filter's own OR.
  if (search) {
    const words = mediaSearchWhere(search)
    if (words.length > 0) where.AND = [...(where.AND ?? []), ...words]
  }

  // Tag filter
  if (tagIds && tagIds.length > 0) {
    where.tags = {
      some: {
        tagId: { in: tagIds },
      },
    }
  }

  // Sort
  const orderBy: MediaOrderByInput = {}
  switch (sortBy) {
    case 'name':
      orderBy.originalName = sortOrder
      break
    case 'size':
      orderBy.size = sortOrder
      break
    case 'type':
      orderBy.mimeType = sortOrder
      break
    case 'createdAt':
    default:
      orderBy.createdAt = sortOrder
      break
  }

  const skip = (page - 1) * limit

  const [media, total] = await Promise.all([
    db.media.findMany({
      where,
      include: {
        folder: true,
        tags: {
          include: {
            tag: true,
          },
        },
        uploadedBy: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        _count: {
          select: {
            usages: true,
          },
        },
      },
      orderBy,
      skip,
      take: limit,
    }),
    db.media.count({ where }),
  ])

  return {
    media: media as MediaWithRelations[],
    total,
    page,
    limit,
    hasMore: skip + media.length < total,
  }
}

// =============================================================================
// GET SINGLE MEDIA
// =============================================================================

export async function getMedia(id: string, includeUsage = true): Promise<MediaWithRelations | null> {
  const media = await db.media.findUnique({
    where: { id },
    include: {
      folder: true,
      tags: {
        include: {
          tag: true,
        },
      },
      usages: includeUsage,
      uploadedBy: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  })

  return media as MediaWithRelations | null
}

// =============================================================================
// CREATE MEDIA
// =============================================================================

/** Who and why, for the version history (lib/media/history); defaults to the chat run or an unknown user. */
type MediaHistory = import('../ade-bindings/history').WriteContext
const mediaHistory = async () => (await import('./history')).mediaHistory

export async function createMedia(input: MediaCreateInput, history: MediaHistory = {}): Promise<MediaWithRelations> {
  const { tagIds, ...data } = input

  const media = await db.media.create({
    data: {
      ...data,
      tags: tagIds?.length
        ? {
            create: tagIds.map((tagId) => ({ tagId })),
          }
        : undefined,
    },
    include: {
      folder: true,
      tags: {
        include: {
          tag: true,
        },
      },
      uploadedBy: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  })

  // The uploader is the author unless the caller says otherwise.
  const { actorFor } = await import('../ade-bindings/history')
  await (await mediaHistory()).created(media.id, history.actor ? history : { ...history, actor: actorFor(input.uploadedById ?? null) })
  return media as MediaWithRelations
}

/**
 * Finish a direct upload: create its row, or — when a retry's first reply
 * was lost — return the row the first try made (same storage key, same
 * uploader). `created` says which.
 */
export async function completeMediaUpload(input: MediaCreateInput & { uploadedById: string }): Promise<{ ok: true; media: MediaWithRelations; created: boolean } | { ok: false; status: 409; error: string }> {
  const { completeDecision, isUniqueViolation } = await import('./complete')
  const lookup = async () => {
    if (!input.key) return { kind: 'create' as const }
    const existing = await db.media.findUnique({ where: { key: input.key }, select: { id: true, uploadedById: true, deletedAt: true } })
    return completeDecision(existing, input.uploadedById)
  }
  const reuse = async (d: Awaited<ReturnType<typeof lookup>>) => {
    if (d.kind === 'conflict') return { ok: false as const, status: 409 as const, error: d.reason }
    const media = d.kind === 'reuse' ? await getMedia(d.id, false) : null
    return media ? { ok: true as const, media, created: false } : null
  }
  const first = await reuse(await lookup())
  if (first) return first
  try {
    return { ok: true, media: await createMedia(input), created: true }
  } catch (e) {
    // Two completes for one key at once: the loser returns the winner's row.
    if (!isUniqueViolation(e)) throw e
    const again = await reuse(await lookup())
    if (again) return again
    throw e
  }
}

// =============================================================================
// UPDATE MEDIA
// =============================================================================

export async function updateMedia(id: string, input: MediaUpdateInput, history: MediaHistory = {}): Promise<MediaWithRelations> {
  return (await mediaHistory()).update(id, history, () => updateMediaUnrecorded(id, input))
}

async function updateMediaUnrecorded(id: string, input: MediaUpdateInput): Promise<MediaWithRelations> {
  const { tagIds, ...data } = input

  // If tagIds is provided, replace all tags
  if (tagIds !== undefined) {
    await db.mediaTagOnMedia.deleteMany({
      where: { mediaId: id },
    })

    if (tagIds.length > 0) {
      await db.mediaTagOnMedia.createMany({
        data: tagIds.map((tagId) => ({ mediaId: id, tagId })),
      })
    }
  }

  const media = await db.media.update({
    where: { id },
    data,
    include: {
      folder: true,
      tags: {
        include: {
          tag: true,
        },
      },
      usages: true,
      uploadedBy: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  })

  return media as MediaWithRelations
}

// =============================================================================
// DELETE MEDIA
// =============================================================================

export async function deleteMedia(id: string, hard = false, history: MediaHistory = {}): Promise<void> {
  const h = await mediaHistory()
  if (hard) {
    // Hard delete - permanently remove
    await h.remove(id, history, () =>
      db.media.delete({
        where: { id },
      })
    )
  } else {
    // Soft delete - mark as deleted
    await h.update(id, history, () =>
      db.media.update({
        where: { id },
        data: { deletedAt: new Date() },
      })
    )
  }
}

// =============================================================================
// RESTORE MEDIA
// =============================================================================

export async function restoreMedia(id: string, history: MediaHistory = {}): Promise<MediaWithRelations> {
  return (await mediaHistory()).update(id, history, () => restoreMediaUnrecorded(id))
}

async function restoreMediaUnrecorded(id: string): Promise<MediaWithRelations> {
  const media = await db.media.update({
    where: { id },
    data: { deletedAt: null },
    include: {
      folder: true,
      tags: {
        include: {
          tag: true,
        },
      },
      uploadedBy: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  })

  return media as MediaWithRelations
}

// =============================================================================
// BULK OPERATIONS
// =============================================================================

export async function bulkDeleteMedia(ids: string[], hard = false, history: MediaHistory = {}): Promise<number> {
  const h = await mediaHistory()
  if (hard) {
    let count = 0
    for (const id of ids) {
      const r = await h.remove(id, history, () => db.media.deleteMany({ where: { id } }))
      count += r.count
    }
    return count
  } else {
    const result = await h.updateMany(ids, history, () =>
      db.media.updateMany({
        where: { id: { in: ids } },
        data: { deletedAt: new Date() },
      })
    )
    return result.count
  }
}

export async function bulkMoveMedia(ids: string[], folderId: string | null, history: MediaHistory = {}): Promise<number> {
  const result = await (await mediaHistory()).updateMany(ids, history, () =>
    db.media.updateMany({
      where: { id: { in: ids } },
      data: { folderId },
    })
  )
  return result.count
}

export async function bulkTagMedia(ids: string[], tagIds: string[], history: MediaHistory = {}): Promise<number> {
  return (await mediaHistory()).updateMany(ids, history, () => bulkTagMediaUnrecorded(ids, tagIds))
}

async function bulkTagMediaUnrecorded(ids: string[], tagIds: string[]): Promise<number> {
  // Create tag associations for each media item
  const data = ids.flatMap((mediaId) =>
    tagIds.map((tagId) => ({ mediaId, tagId }))
  )

  await db.mediaTagOnMedia.createMany({
    data,
    skipDuplicates: true,
  })

  return ids.length
}

export async function bulkUntagMedia(ids: string[], tagIds: string[], history: MediaHistory = {}): Promise<number> {
  const result = await (await mediaHistory()).updateMany(ids, history, () =>
    db.mediaTagOnMedia.deleteMany({
      where: {
        mediaId: { in: ids },
        tagId: { in: tagIds },
      },
    })
  )
  return result.count
}

export async function bulkRestoreMedia(ids: string[], history: MediaHistory = {}): Promise<number> {
  const result = await (await mediaHistory()).updateMany(ids, history, () =>
    db.media.updateMany({
      where: { id: { in: ids } },
      data: { deletedAt: null },
    })
  )
  return result.count
}

// =============================================================================
// STATS
// =============================================================================

export async function getMediaStats() {
  const [total, byType, totalSize, recentCount] = await Promise.all([
    db.media.count({ where: { deletedAt: null } }),
    db.media.groupBy({
      by: ['mimeType'],
      where: { deletedAt: null },
      _count: { id: true },
    }),
    db.media.aggregate({
      where: { deletedAt: null },
      _sum: { size: true },
    }),
    db.media.count({
      where: {
        deletedAt: null,
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
  ])

  // Group by media type
  const typeStats = {
    image: 0,
    video: 0,
    audio: 0,
    document: 0,
    other: 0,
  }

  for (const item of byType) {
    if (item.mimeType.startsWith('image/')) {
      typeStats.image += item._count.id
    } else if (item.mimeType.startsWith('video/')) {
      typeStats.video += item._count.id
    } else if (item.mimeType.startsWith('audio/')) {
      typeStats.audio += item._count.id
    } else if (
      item.mimeType === 'application/pdf' ||
      item.mimeType.includes('document') ||
      item.mimeType.includes('word')
    ) {
      typeStats.document += item._count.id
    } else {
      typeStats.other += item._count.id
    }
  }

  return {
    total,
    totalSize: totalSize._sum.size || 0,
    recentCount,
    byType: typeStats,
  }
}

// Re-export types
export * from './types'
