/**
 * What the media library shows: placeholders while loading, a failure message
 * when the load failed and nothing is on screen, the empty message only when
 * the load came back with no files. Pure; asserted by load-state.assert.ts.
 */
export type MediaView = 'loading' | 'failed' | 'empty' | 'files'

export interface MediaLoad {
  loading: boolean
  error: string | null
  count: number
}

export function mediaView({ loading, error, count }: MediaLoad): MediaView {
  if (loading) return 'loading'
  if (count > 0) return 'files'
  return error ? 'failed' : 'empty'
}
