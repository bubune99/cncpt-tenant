/**
 * Where focus goes back to when a dialog closes: the element that had focus when
 * it opened, or, when that was an item in a menu (gone once the menu closes), the
 * button that opened the menu. null leaves it to Radix. Pure; asserted by
 * focus-return.assert.ts.
 */
export interface FocusNode {
  closest(selector: string): { id?: string } | null
}

export function focusReturnTarget<T extends FocusNode>(
  opener: T | null,
  find: (selector: string) => T | null,
): T | null {
  if (!opener) return null
  const menu = opener.closest('[role="menu"]')
  if (!menu) return opener
  return menu.id ? find(`[aria-controls="${menu.id}"]`) : null
}
