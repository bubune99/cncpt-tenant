/**
 * An icon component, whichever way it is typed: lucide's own
 * (ForwardRefExoticComponent) or the React 19 shim in
 * src/types/lucide-react.d.ts (ComponentType<IconProps>). A map that mixes
 * icons from both needs this; `LucideIcon` alone rejects the shim's.
 */

import type { ComponentType, SVGProps } from 'react'
import type { LucideIcon } from 'lucide-react'

export type IconLike = LucideIcon | ComponentType<SVGProps<SVGSVGElement>>
