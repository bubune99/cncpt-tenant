/**
 * Version history for the site layout row (SiteSettings), split into the
 * parts people edit separately — entityType 'site-layout', entityId one of:
 *   header · footer · announcement · identity (name, logo, social links,
 *   contact, SEO defaults, tracking ids).
 * Every write goes through updateSiteSettings, which records each part it
 * changed; restore writes back through it too.
 */

import { Prisma } from '@prisma/client'
import { prisma } from '../db'
import type { Actor, RestorePolicy } from '../ade/history'
import { actorFor, recordRevision, registerHistory } from '../ade-bindings/history'

export interface SiteSettingsWriteContext {
  actor?: Actor
  reason?: string
  changeSetId?: string | null
}

export const LAYOUT_PART_FIELDS = {
  header: ['header'],
  footer: ['footer'],
  announcement: ['announcementBar', 'showAnnouncementBar'],
  identity: [
    'siteName', 'siteTagline', 'logoUrl', 'logoAlt', 'faviconUrl', 'socialLinks',
    'defaultMetaTitle', 'defaultMetaDescription', 'defaultOgImage',
    'contactEmail', 'contactPhone', 'businessAddress', 'googleAnalyticsId', 'facebookPixelId',
  ],
} as const

export type SiteLayoutPart = keyof typeof LAYOUT_PART_FIELDS
const PARTS = Object.keys(LAYOUT_PART_FIELDS) as SiteLayoutPart[]
const isPart = (v: string): v is SiteLayoutPart => (PARTS as string[]).includes(v)

type Row = Record<string, unknown>

/** The whole row's versioned fields (null when it doesn't exist yet). */
export async function readSiteRow(): Promise<Row | null> {
  return (await prisma.siteSettings.findUnique({ where: { id: 'default' } })) as Row | null
}

const pick = (row: Row | null, part: SiteLayoutPart): Row | null =>
  row ? Object.fromEntries(LAYOUT_PART_FIELDS[part].map((f) => [f, row[f] ?? null])) : null

/** Record each part that changed between two reads of the row. Never throws. */
export async function recordSiteChange(before: Row | null, after: Row | null, ctx: SiteSettingsWriteContext = {}) {
  for (const part of PARTS) {
    await recordRevision({
      entityType: 'site-layout',
      entityId: part,
      before: pick(before, part),
      after: pick(after, part),
      actor: ctx.actor ?? actorFor(null),
      changeSetId: ctx.changeSetId,
      reason: ctx.reason ?? 'save',
    })
  }
}

const PART_NAME: Record<SiteLayoutPart, string> = {
  header: 'Site header',
  footer: 'Site footer',
  announcement: 'Announcement bar',
  identity: 'Site name, logo, contact & SEO',
}

/** What a site-layout restore may write: everything here is site config; tracking ids are guarded. */
export const SITE_LAYOUT_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    ...Object.fromEntries([...LAYOUT_PART_FIELDS.header, ...LAYOUT_PART_FIELDS.footer, 'announcementBar', 'socialLinks', 'businessAddress'].map((f) => [f, { class: 'restorable' as const, type: 'json' as const }])),
    showAnnouncementBar: { class: 'restorable', type: 'boolean' },
    ...Object.fromEntries(['siteName', 'siteTagline', 'logoUrl', 'logoAlt', 'faviconUrl', 'defaultMetaTitle', 'defaultMetaDescription', 'defaultOgImage', 'contactEmail', 'contactPhone'].map((f) => [f, { class: 'restorable' as const, type: 'string' as const }])),
    googleAnalyticsId: { class: 'guarded', type: 'string', consequence: 'Visits are counted in a different analytics account' },
    facebookPixelId: { class: 'guarded', type: 'string', consequence: 'Visits are sent to a different Facebook pixel' },
  },
}

registerHistory({
  entityType: 'site-layout',
  policy: SITE_LAYOUT_POLICY,
  editPermission: 'settings.general',
  ignore: new Set(['id', 'createdAt', 'updatedAt']),
  load: async (part) => (isPart(part) ? pick((await readSiteRow()) ?? {}, part) : null),
  nameOf: async (part) => (isPart(part) ? PART_NAME[part] : null),
  fieldLabels: {
    header: 'Header',
    footer: 'Footer',
    announcementBar: 'Announcement',
    showAnnouncementBar: 'Show the announcement',
    siteName: 'Site name',
    siteTagline: 'Tagline',
    logoUrl: 'Logo',
    logoAlt: 'Logo description',
    faviconUrl: 'Browser tab icon',
    socialLinks: 'Social links',
    defaultMetaTitle: 'Search title',
    defaultMetaDescription: 'Search description',
    defaultOgImage: 'Sharing image',
    contactEmail: 'Contact email',
    contactPhone: 'Contact phone',
    businessAddress: 'Address',
    googleAnalyticsId: 'Google Analytics id',
    facebookPixelId: 'Facebook pixel id',
  },
  async save(part, patch, actor, reason) {
    if (!isPart(part)) throw new Error(`Unknown site layout part ${part}`)
    const allowed = new Set<string>(LAYOUT_PART_FIELDS[part])
    // JSON columns are cleared with DbNull (a plain null is refused by Prisma).
    const JSON_FIELDS = new Set(['header', 'footer', 'announcementBar', 'socialLinks', 'businessAddress'])
    const data = Object.fromEntries(
      Object.entries(patch)
        .filter(([k]) => allowed.has(k))
        .map(([k, v]) => [k, v == null && JSON_FIELDS.has(k) ? Prisma.DbNull : v])
    )
    const { updateSiteSettings } = await import('./index')
    await updateSiteSettings(data, { actor, reason })
    const { revalidateStorefront } = await import('../revalidate')
    revalidateStorefront()
  },
})
