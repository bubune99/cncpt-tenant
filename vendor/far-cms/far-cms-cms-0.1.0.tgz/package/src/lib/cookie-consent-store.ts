/**
 * Cookie consent storage utilities.
 * Separated from the React hook to avoid circular dependencies
 * (the analytics provider needs to check consent, and the hook
 * needs to call the analytics consent update).
 */

import {
  CONSENT_COOKIE,
  CONSENT_COOKIE_MAX_AGE,
  SESSION_ID_KEY,
  analyticsCookiesToClear,
  analyticsDecision,
  consentCookieValue,
  consentFromStored,
  readCookie,
  type AnalyticsDecision,
} from './privacy/consent-decision'

export interface CookieConsentState {
  essential: boolean // Always true, cannot be toggled
  analytics: boolean
  marketing: boolean
  functional: boolean
}

const STORAGE_KEY = 'cookie-consent'
const CONSENT_VERSION = 1

interface StoredConsent {
  version: number
  consent: CookieConsentState
  timestamp: number
  /** The site's privacy policy version this choice was made under (absent = 1). */
  policyVersion?: number
  /** Random id tying this choice to its compliance record — no personal data. */
  consentId?: string
}

export const DEFAULT_CONSENT: CookieConsentState = {
  essential: true,
  analytics: false,
  marketing: false,
  functional: false,
}

let listeners: Array<() => void> = []

// Cache the last snapshot to ensure referential stability for useSyncExternalStore.
// Without this, getSnapshot() returns a new JSON.parse() object every call,
// causing React to think the value changed → infinite re-render loop (error #185).
let cachedRaw: string | null = null
let cachedSnapshot: StoredConsent | null = null

function emitChange() {
  // Invalidate cache so next getSnapshot() reads fresh data
  cachedRaw = null
  cachedSnapshot = null
  for (const listener of listeners) {
    listener()
  }
}

export function getStoredConsent(): StoredConsent | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed: StoredConsent = JSON.parse(raw)
    if (parsed.version !== CONSENT_VERSION) return null
    return parsed
  } catch {
    return null
  }
}

function newConsentId(): string {
  try {
    return crypto.randomUUID()
  } catch {
    return `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`
  }
}

/** Remember the visitor's choice; returns the stored record (with its consent id). */
export function setStoredConsent(consent: CookieConsentState, policyVersion = 1): StoredConsent | undefined {
  if (typeof window === 'undefined') return
  const stored: StoredConsent = {
    version: CONSENT_VERSION,
    consent: { ...consent, essential: true },
    timestamp: Date.now(),
    policyVersion,
    consentId: getStoredConsent()?.consentId ?? newConsentId(),
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stored))
  writeConsentCookie(stored.consent)
  if (!stored.consent.analytics) clearAnalyticsStorage()
  emitChange()
  return stored
}

// ---------------------------------------------------------------------------
// The server's copy of the choice, GPC, and what may be recorded
// (rules: lib/privacy/consent-decision)
// ---------------------------------------------------------------------------

function writeConsentCookie(consent: { analytics: boolean }) {
  try {
    const secure = window.location.protocol === 'https:' ? '; Secure' : ''
    document.cookie = `${CONSENT_COOKIE}=${consentCookieValue(consent)}; Max-Age=${CONSENT_COOKIE_MAX_AGE}; Path=/; SameSite=Lax${secure}`
  } catch {
    // Cookies blocked: the browser side still follows the stored choice.
  }
}

/**
 * Choices made before the server copy existed live only in localStorage:
 * write the cookie so the server sees them too. Cheap; call before sending.
 */
export function syncConsentCookie(): void {
  if (typeof window === 'undefined') return
  const stored = getStoredConsent()
  if (!stored) return
  const want = consentCookieValue(stored.consent)
  if (readCookie(document.cookie, CONSENT_COOKIE) !== want) writeConsentCookie(stored.consent)
}

/** Global Privacy Control is on in this browser. */
export function browserGpc(): boolean {
  if (typeof navigator === 'undefined') return false
  return (navigator as Navigator & { globalPrivacyControl?: boolean }).globalPrivacyControl === true
}

/** The site's "track only after Accept" setting, handed over by the banner (Settings › Cookie & privacy banner). */
let trackOnlyAfterAccept = false
export function setTrackOnlyAfterAccept(value: boolean): void {
  trackOnlyAfterAccept = value
}

/** What this browser may record right now. */
export function clientAnalyticsDecision(): AnalyticsDecision {
  return analyticsDecision({ consent: consentFromStored(getStoredConsent()), gpc: browserGpc(), trackOnlyAfterAccept })
}

/** Remove analytics ids from this device: our per-tab id and known analytics cookies. */
export function clearAnalyticsStorage(): void {
  if (typeof window === 'undefined') return
  try {
    sessionStorage.removeItem(SESSION_ID_KEY)
  } catch {
    // Storage blocked: nothing was stored either.
  }
  try {
    const names = document.cookie.split(';').map((c) => c.split('=')[0]?.trim() ?? '').filter(Boolean)
    const host = window.location.hostname
    const parts = host.split('.')
    // Analytics tools set cookies on the parent domain too (".example.org").
    const domains = ['', host, ...(parts.length > 2 ? [`.${parts.slice(-2).join('.')}`] : []), `.${host}`]
    for (const name of analyticsCookiesToClear(names)) {
      for (const d of domains) {
        document.cookie = `${name}=; Max-Age=0; Path=/${d ? `; Domain=${d}` : ''}`
      }
    }
  } catch {
    // Never break the banner.
  }
}

export function getSnapshot(): StoredConsent | null {
  if (typeof window === 'undefined') return null
  const raw = localStorage.getItem(STORAGE_KEY)
  // Return cached object if the raw string hasn't changed
  if (raw === cachedRaw) return cachedSnapshot
  cachedRaw = raw
  if (!raw) {
    cachedSnapshot = null
    return null
  }
  try {
    const parsed: StoredConsent = JSON.parse(raw)
    if (parsed.version !== CONSENT_VERSION) {
      cachedSnapshot = null
      return null
    }
    cachedSnapshot = parsed
    return parsed
  } catch {
    cachedSnapshot = null
    return null
  }
}

export function getServerSnapshot(): StoredConsent | null {
  return null
}

export function subscribe(listener: () => void): () => void {
  listeners = [...listeners, listener]
  return () => {
    listeners = listeners.filter((l) => l !== listener)
  }
}

/**
 * Check if a specific consent category is granted.
 * Can be used outside of React components.
 */
export function hasConsentFor(category: keyof CookieConsentState): boolean {
  if (category === 'essential') return true
  const stored = getStoredConsent()
  if (!stored) return false
  return stored.consent[category] ?? false
}

/**
 * Check if the user has made any consent decision at all.
 */
export function hasConsentDecision(): boolean {
  return getStoredConsent() !== null
}
