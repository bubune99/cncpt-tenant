/**
 * Card 6: the admin areas moved onto the skin keep no fixed Tailwind palette colors (bg-green-700, text-amber-600 …),
 * which ignore the skin and were unreadable on CNCPT's dark Grainy admin. Status uses success / warning / destructive
 * fills for badges and their *-text colors for text and icons. Add an area here once it is moved.
 * Run: tsx packages/cms/src/lib/theme/fixed-colors.assert.ts
 */
import assert from "node:assert/strict"
import { readdirSync, readFileSync, statSync } from "node:fs"
import { join } from "node:path"
import { fileURLToPath } from "node:url"

const admin = fileURLToPath(new URL("../../app/admin", import.meta.url))
const CLEAN = ["orders", "forms", "analytics", "pages", "discounts", "customers", "email-marketing", "partials"]
/** Files that draw the public site, which is always light whatever the admin's theme (e788a648): fixed light colors are right there. */
const PUBLIC_PREVIEW = new Set(["pages/layout/page.tsx"])
const FIXED = /\b(?:bg|text|border|ring|fill|stroke)-(?:red|green|blue|yellow|amber|orange|purple|pink|indigo|emerald|teal|sky|gray|slate|zinc|neutral|stone)-\d{2,3}\b/g
const walk = (d: string): string[] => readdirSync(d).flatMap((x) => { const p = join(d, x); return statSync(p).isDirectory() ? walk(p) : /\.tsx?$/.test(x) ? [p] : [] })

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }
ok(`no fixed palette colors in ${CLEAN.length} admin areas on the skin`, () => {
  const found = CLEAN.flatMap((a) => walk(join(admin, a)).filter((f) => !PUBLIC_PREVIEW.has(f.slice(admin.length + 1))).flatMap((f) => (readFileSync(f, "utf8").match(FIXED) ?? []).map((m) => `${f.slice(admin.length + 1)}: ${m}`)))
  assert.deepEqual(found, [])
})
ok("the pattern catches what it is for and leaves skin names alone", () => {
  assert.deepEqual("bg-green-700 text-amber-600 bg-success text-success-text border-border".match(FIXED), ["bg-green-700", "text-amber-600"])
})
console.log(`${n} checks passed`)
