'use server';

/**
 * Chat Actions
 *
 * Server actions for chat operations.
 * Adapted from ChatSDK for Prisma/Stack Auth.
 */

import { prisma } from '../db';
import { stackServerApp } from '../stack';
import { ChatVisibility } from '@prisma/client';
import type { VisibilityType } from '../../components/chatsdk/visibility-selector';

// Map UI visibility type to Prisma enum
function toDbVisibility(visibility: VisibilityType): ChatVisibility {
  return visibility === 'public' ? ChatVisibility.PUBLIC : ChatVisibility.PRIVATE;
}

/**
 * A server action is callable by any HTTP client with its action id, so it
 * resolves the caller itself and only touches that person's conversation.
 * The delete / read-any-chat actions this module used to export had no
 * callers and are gone (lib/chatsdk/db/queries has the non-action helpers;
 * a per-chat Delete must go through an authenticated, owner-checked route).
 */
async function currentUserId(): Promise<string> {
  const user = await stackServerApp.getUser();
  if (!user) throw new Error('Sign in to change this chat');
  const dbUser = await prisma.user.findFirst({ where: { stackAuthId: user.id }, select: { id: true } });
  if (!dbUser) throw new Error('Sign in to change this chat');
  return dbUser.id;
}

export async function updateChatVisibility({
  chatId,
  visibility,
}: {
  chatId: string;
  visibility: VisibilityType;
}) {
  const userId = await currentUserId();
  await prisma.aiConversation.updateMany({
    where: { id: chatId, userId },
    data: { visibility: toDbVisibility(visibility) },
  });
}
