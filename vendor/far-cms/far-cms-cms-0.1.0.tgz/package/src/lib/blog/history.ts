/**
 * Version history for blog posts (initiatives are blog posts too):
 * entityType 'blog-post', entityId = the post id. Every writer — the blog
 * service (admin API), the assistant's approved drafts and direct tools,
 * the MCP server, initiatives and plugins — wraps its write in
 * withPostHistory, so each change has a version and can be restored.
 *
 * Versioned: the post's own fields plus its categories and tags (as id
 * lists). Derived fields (contentHtml, word count, reading time) are
 * versioned with the content so a restore brings back a consistent post.
 * Counters (views, likes, comments) are not.
 */

import { Prisma } from '@prisma/client'
import { prisma } from '../db'
import type { Actor, RestorePolicy } from '../ade/history'
import { actorFor, recordRevision, registerHistory } from '../ade-bindings/history'
import { noteVersionMissing, versionRequired, withoutVersionRequired } from '../ade-bindings/revision-capture'

export interface BlogWriteContext {
  actor?: Actor
  reason?: string
  changeSetId?: string | null
}

const SCALARS = {
  title: true,
  slug: true,
  excerpt: true,
  content: true,
  contentHtml: true,
  authorId: true,
  featuredImageId: true,
  status: true,
  visibility: true,
  metaTitle: true,
  metaDescription: true,
  canonicalUrl: true,
  noIndex: true,
  ogTitle: true,
  ogDescription: true,
  ogImageId: true,
  publishedAt: true,
  scheduledAt: true,
  readingTime: true,
  wordCount: true,
  allowComments: true,
  featured: true,
  pinned: true,
  homeOrder: true,
} as const

type Versioned = Record<string, unknown>

export async function loadPostVersioned(id: string): Promise<Versioned | null> {
  const p = await prisma.blogPost.findUnique({
    where: { id },
    select: {
      ...SCALARS,
      categories: { select: { categoryId: true, position: true }, orderBy: { position: 'asc' } },
      tags: { select: { tagId: true } },
    },
  })
  if (!p) return null
  const { categories, tags, ...rest } = p
  return {
    ...rest,
    categoryIds: categories.map((c) => c.categoryId),
    tagIds: tags.map((t) => t.tagId).sort(),
  }
}

/** Record a post's change between two loads. Never throws. */
export async function recordPostChange(id: string, before: Versioned | null, after: Versioned | null, ctx: BlogWriteContext = {}, fallbackReason = 'save') {
  const actor = ctx.actor ?? actorFor(null)
  return recordRevision({
    entityType: 'blog-post',
    entityId: id,
    before,
    after,
    actor,
    changeSetId: ctx.changeSetId,
    reason: ctx.reason ?? (actor.kind === 'agent' && fallbackReason === 'save' ? 'ai-edit' : fallbackReason),
  })
}

/** Run a write to an existing post and record it as a version. */
export async function withPostHistory<T>(id: string, ctx: BlogWriteContext, write: () => Promise<T>): Promise<T> {
  const before = await loadPostVersioned(id)
  const out = await write()
  const after = await loadPostVersioned(id)
  const rec = await recordPostChange(id, before, after, ctx)
  // An Auto edit must leave a version Undo can restore: if none was recorded, put the old values back.
  if (!rec && before && after && versionRequired()) {
    const patch = Object.fromEntries(Object.keys(before).filter((k) => JSON.stringify(before[k]) !== JSON.stringify(after[k])).map((k) => [k, before[k]]))
    if (Object.keys(patch).length > 0) {
      noteVersionMissing()
      await withoutVersionRequired(() => savePost(id, patch, actorFor(null), 'Auto edit put back: no version'))
    }
  }
  return out
}

/** Record a newly created post as version 1. */
export async function recordPostCreated(id: string, ctx: BlogWriteContext = {}) {
  return recordPostChange(id, null, await loadPostVersioned(id), ctx, 'create')
}

/** Run a delete; the history keeps a last version saying it was deleted. */
export async function withPostDeleteHistory<T>(id: string, ctx: BlogWriteContext, del: () => Promise<T>): Promise<T> {
  const before = await loadPostVersioned(id)
  const out = await del()
  if (before) await recordPostChange(id, before, null, ctx, 'delete')
  return out
}

/** Write a restore patch back (fields, then categories/tags in their order). */
async function savePost(id: string, patch: Versioned, actor: Actor, reason: string) {
  const { categoryIds, tagIds, ...fields } = patch
  await withPostHistory(id, { actor, reason }, async () => {
    await prisma.$transaction(async (tx) => {
      // A JSON column is cleared with DbNull, not null.
      const data = { ...fields, ...('content' in fields && fields.content == null ? { content: Prisma.DbNull } : {}) }
      if (Object.keys(data).length) await tx.blogPost.update({ where: { id }, data: data as Prisma.BlogPostUncheckedUpdateInput })
      if (Array.isArray(categoryIds)) {
        await tx.blogPostCategory.deleteMany({ where: { postId: id } })
        const ids = (categoryIds as string[]).filter((c) => typeof c === 'string')
        const exist = new Set((await tx.blogCategory.findMany({ where: { id: { in: ids } }, select: { id: true } })).map((c) => c.id))
        const keep = ids.filter((c) => exist.has(c))
        if (keep.length) await tx.blogPostCategory.createMany({ data: keep.map((categoryId, position) => ({ postId: id, categoryId, position })) })
      }
      if (Array.isArray(tagIds)) {
        await tx.blogPostTag.deleteMany({ where: { postId: id } })
        const ids = (tagIds as string[]).filter((t) => typeof t === 'string')
        const exist = new Set((await tx.blogTag.findMany({ where: { id: { in: ids } }, select: { id: true } })).map((t) => t.id))
        const keep = ids.filter((t) => exist.has(t))
        if (keep.length) await tx.blogPostTag.createMany({ data: keep.map((tagId) => ({ postId: id, tagId })) })
      }
    })
  })
  const { revalidateStorefront } = await import('../revalidate')
  revalidateStorefront()
}

const str = (f: string) => [f, { class: 'restorable' as const, type: 'string' as const }] as const

/** What a post restore may write. */
export const BLOG_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    ...Object.fromEntries(['title', 'excerpt', 'contentHtml', 'metaTitle', 'metaDescription', 'canonicalUrl', 'ogTitle', 'ogDescription', 'featuredImageId', 'ogImageId'].map(str)),
    content: { class: 'restorable', type: 'json' },
    readingTime: { class: 'restorable', type: 'number' },
    wordCount: { class: 'restorable', type: 'number' },
    noIndex: { class: 'restorable', type: 'boolean' },
    allowComments: { class: 'restorable', type: 'boolean' },
    featured: { class: 'restorable', type: 'boolean' },
    pinned: { class: 'restorable', type: 'boolean' },
    homeOrder: { class: 'restorable', type: 'number' },
    tagIds: { class: 'restorable', type: 'string[]' },
    categoryIds: { class: 'guarded', type: 'string[]', consequence: 'Which lists the post appears in changes (initiatives are a category)' },
    slug: { class: 'guarded', type: 'string', consequence: 'The post’s web address changes — links to the old one stop working', followUp: 'redirect' },
    status: { class: 'guarded', type: 'enum', values: ['DRAFT', 'PUBLISHED', 'SCHEDULED', 'ARCHIVED'], gateValues: ['PUBLISHED', 'SCHEDULED'], gateReason: 'Publish it from the editor, where its checks run', consequence: 'Whether the post is on the site changes' },
    visibility: { class: 'guarded', type: 'enum', values: ['PUBLIC', 'PRIVATE', 'PASSWORD_PROTECTED'], consequence: 'Who can read the post changes' },
    scheduledAt: { class: 'guarded', type: 'date', consequence: 'When it goes live changes' },
    authorId: { class: 'guarded', type: 'string', consequence: 'The post’s author changes' },
    publishedAt: { class: 'never', reason: 'When it was published is a record, not a setting' },
  },
}

/** Pictures and categories/tags an old version points at that no longer exist. */
async function blogMissingRefs(target: Record<string, unknown>): Promise<Record<string, string>> {
  const out: Record<string, string> = {}
  for (const f of ['featuredImageId', 'ogImageId'] as const) {
    const id = target[f]
    if (typeof id === 'string' && !(await prisma.media.findFirst({ where: { id, deletedAt: null }, select: { id: true } }))) out[f] = 'That picture was deleted from Media'
  }
  const ids = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [])
  const cats = ids(target.categoryIds)
  if (cats.length && (await prisma.blogCategory.count({ where: { id: { in: cats } } })) < cats.length) out.categoryIds = 'A category in that version was deleted'
  const tags = ids(target.tagIds)
  if (tags.length && (await prisma.blogTag.count({ where: { id: { in: tags } } })) < tags.length) out.tagIds = 'A tag in that version was deleted'
  return out
}

registerHistory({
  entityType: 'blog-post',
  policy: BLOG_POLICY,
  missingRefs: blogMissingRefs,
  editPermission: 'blog.edit',
  ignore: new Set(['id', 'createdAt', 'updatedAt', 'viewCount', 'likeCount', 'commentCount']),
  load: loadPostVersioned,
  nameOf: async (id) => (await prisma.blogPost.findUnique({ where: { id }, select: { title: true } }))?.title ?? null,
  fieldLabels: {
    title: 'Title',
    slug: 'Web address',
    excerpt: 'Summary',
    content: 'Text',
    contentHtml: 'Text (as shown)',
    authorId: 'Author',
    featuredImageId: 'Main image',
    status: 'Status',
    visibility: 'Who can see it',
    metaTitle: 'Search title',
    metaDescription: 'Search description',
    canonicalUrl: 'Original address',
    noIndex: 'Hidden from search engines',
    ogTitle: 'Sharing title',
    ogDescription: 'Sharing description',
    ogImageId: 'Sharing image',
    publishedAt: 'Published',
    scheduledAt: 'Scheduled for',
    readingTime: 'Reading time (minutes)',
    wordCount: 'Words',
    allowComments: 'Comments',
    featured: 'Featured',
    pinned: 'Pinned',
    homeOrder: 'Home page position',
    categoryIds: 'Categories',
    tagIds: 'Tags',
  },
  save: savePost,
})
