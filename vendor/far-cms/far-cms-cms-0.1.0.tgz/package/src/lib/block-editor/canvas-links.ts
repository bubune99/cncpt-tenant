/**
 * What a click in the editor canvas must not do: follow a link or send a form. The click still
 * selects the block (the canvas prevents only the default action). Asserted by canvas-links.assert.ts.
 */
export const CANVAS_INERT_SELECTOR = 'a[href], form button:not([type="button"]), form input[type="submit"]'
