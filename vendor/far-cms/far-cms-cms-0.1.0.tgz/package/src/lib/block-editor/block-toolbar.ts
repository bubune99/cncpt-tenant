/**
 * Where a block's toolbar sits. It goes above the block, unless there is no room above inside the
 * canvas (a block at the top, such as anything in a header), where it would be cut off: then below.
 * Found 2026-11-17 in the Header editor: a selected link's toolbar was half hidden under the editor's
 * own bar. Asserted by block-toolbar.assert.ts.
 */
export const BLOCK_TOOLBAR_GAP = 34

export function blockToolbarSide(blockTop: number, canvasTop: number, room: number = BLOCK_TOOLBAR_GAP): 'above' | 'below' {
  return blockTop - canvasTop >= room ? 'above' : 'below'
}
