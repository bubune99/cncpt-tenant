/**
 * Content Adapters
 *
 * Factory functions that return ContentAdapter instances for different content sources.
 * Each adapter provides load/save for a specific content type (partial, site header/footer).
 */

import type { ContentAdapter } from "./editor-context"
import type { Block } from "./types"

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

interface BlockDocument {
  version: string
  blocks: Block[]
}

function toBlockDocument(blocks: Block[]): BlockDocument {
  return { version: "2.0", blocks }
}

function fromBlockDocument(content: unknown): Block[] {
  if (!content || typeof content !== "object") return []
  const doc = content as Record<string, unknown>
  if (doc.version === "2.0" && Array.isArray(doc.blocks)) {
    return doc.blocks as Block[]
  }
  return []
}

/**
 * Save a shared block document through review (the same approval engine as
 * pages and the assistant): it becomes a draft in To-do, not a live change.
 */
async function draftForReview(target: string, blocks: Block[]): Promise<void> {
  const res = await fetch("/api/admin/ade/editor-draft", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ target, content: toBlockDocument(blocks) }),
  })
  const j = await res.json().catch(() => ({}))
  if (!res.ok || j.success === false) throw new Error(j.error || "Your edits could not be saved")
}

/* ------------------------------------------------------------------ */
/*  Partial Adapter                                                    */
/* ------------------------------------------------------------------ */

/** Adapter for editing a Partial record */
export function partialAdapter(partialId: string): ContentAdapter {
  return {
    async load() {
      const res = await fetch(`/api/admin/partials/${partialId}`)
      if (!res.ok) throw new Error("Failed to load partial")
      const data = await res.json()
      return {
        blocks: fromBlockDocument(data.content),
        title: data.name || "Untitled Partial",
        id: data.id,
      }
    },
    async save(blocks: Block[]) {
      await draftForReview(`partial:${partialId}`, blocks)
      return { id: partialId }
    },
  }
}

/* ------------------------------------------------------------------ */
/*  Site Header Adapter                                                */
/* ------------------------------------------------------------------ */

/** Adapter for editing the global header (SiteSettings.header) as Block[] */
export function siteHeaderAdapter(): ContentAdapter {
  return {
    async load() {
      const res = await fetch("/api/admin/site-settings/header")
      if (!res.ok) throw new Error("Failed to load header settings")
      const data = await res.json()
      const blocks = fromBlockDocument(data.header)
      return {
        blocks,
        title: "Global Header",
        id: "site-header",
      }
    },
    async save(blocks: Block[]) {
      await draftForReview("layout:header", blocks)
      return { id: "site-header" }
    },
  }
}

/* ------------------------------------------------------------------ */
/*  Site Footer Adapter                                                */
/* ------------------------------------------------------------------ */

/** Adapter for editing the global footer (SiteSettings.footer) as Block[] */
export function siteFooterAdapter(): ContentAdapter {
  return {
    async load() {
      const res = await fetch("/api/admin/site-settings/footer")
      if (!res.ok) throw new Error("Failed to load footer settings")
      const data = await res.json()
      const blocks = fromBlockDocument(data.footer)
      return {
        blocks,
        title: "Global Footer",
        id: "site-footer",
      }
    },
    async save(blocks: Block[]) {
      await draftForReview("layout:footer", blocks)
      return { id: "site-footer" }
    },
  }
}
