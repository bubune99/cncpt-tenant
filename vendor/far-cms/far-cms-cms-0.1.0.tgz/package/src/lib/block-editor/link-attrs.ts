/**
 * A link's destination as a person edits it (properties-panel's Link section). Pure; asserted by
 * link-attrs.assert.ts. Attributes are never changed in place.
 */
export type Attrs = Record<string, string>

export function linkOf(attrs: Attrs | undefined): { href: string; newTab: boolean } {
  return { href: attrs?.href ?? '', newTab: attrs?.target === '_blank' }
}

export function withLink(attrs: Attrs | undefined, link: { href: string; newTab: boolean }): Attrs {
  const { target: _target, rel: _rel, ...rest } = attrs ?? {}
  void _target
  void _rel
  const next: Attrs = { ...rest, href: link.href }
  return link.newTab ? { ...next, target: '_blank', rel: 'noopener noreferrer' } : next
}
