// Moved to @far-cms/core (far-cms packages/core/src/lib/block-editor/block-templates-commerce.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/block-editor/block-templates-commerce'
