/**
 * Form Block Drag/Drop Contract
 *
 * Shared between the block palette's Forms section (which sets the payload)
 * and the canvas drop handlers (which decode it). Mirrors the existing
 * "application/partial-id" mechanism: the payload carries the form slug and
 * the drop site builds the FormBlock itself.
 */

import type { Block } from './types'
import { generateId } from './tree-utils'

/** dataTransfer type carrying the slug of a form dragged from the palette. */
export const FORM_SLUG_DRAG_TYPE = 'application/form-slug'

/** Build a FormBlock bound to a specific admin-built form. */
export function createFormBlock(slug: string): Block {
  return {
    id: generateId(),
    tag: 'div',
    className: 'w-full max-w-xl mx-auto py-8',
    componentName: 'FormBlock',
    label: 'Form',
    attrs: { 'data-form-slug': slug },
  }
}
