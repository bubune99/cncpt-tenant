/**
 * Form Data Fetcher
 *
 * Server-side Prisma query for the FormBlock smart block. Loads an ACTIVE
 * form by slug (or id) and normalizes the admin-builder field shape into
 * the FormDefinition consumed by <DynamicForm>.
 *
 * The normalization itself lives in @/lib/forms/normalize so the admin
 * builder's live preview renders the identical shape.
 */

import { prisma } from '../../db'
import { registerFetcher } from './data-resolver'
import { buildFormDefinition } from '../../forms/normalize'
import type { FormDefinition } from '../../forms/types'

export interface FormDisplayConfig {
  mode?: 'inline' | 'popup'
  popupDelay?: number
  popupFrequency?: 'always' | 'session' | 'visitor'
  popupDuration?: number
}

export interface SerializedForm extends FormDefinition {
  status: string
  /** Form-level display default (Settings → Display); block attrs override. */
  display?: FormDisplayConfig | null
}

async function fetchForm(args: Record<string, unknown>): Promise<SerializedForm | null> {
  const slug = args.slug as string | undefined
  const id = args.id as string | undefined
  if (!slug && !id) return null

  const form = await prisma.form.findFirst({
    where: {
      status: 'ACTIVE',
      ...(slug ? { slug } : { id }),
    },
  })
  if (!form) return null

  return {
    ...buildFormDefinition(form),
    status: form.status,
    display: (form as { display?: unknown }).display as FormDisplayConfig | null,
  }
}

/** Register all form fetchers with the data resolver. */
export function registerFormFetchers(): void {
  registerFetcher('fetchForm', fetchForm)
}
