/**
 * What a pinned Initiative card (InitiativeBlock) draws. Pure.
 *
 * - A pinned card shows its initiative whatever its status (draft or
 *   published): the homepage "Our Impact" cards point at initiatives kept as
 *   drafts on purpose since 2026-07-29, and only a published one links to its
 *   page. Archived initiatives are gone.
 * - When the initiative is missing (or archived), visitors see nothing; only
 *   the editor and the admin preview show the "not found" box.
 */

/** What the PUBLIC fetcher returns for a missing / archived initiative (the admin preview returns null). */
export const HIDDEN_FOR_VISITORS = { hiddenForVisitors: true } as const
export type HiddenForVisitors = typeof HIDDEN_FOR_VISITORS

export function isHiddenForVisitors(v: unknown): v is HiddenForVisitors {
  return !!v && typeof v === 'object' && (v as { hiddenForVisitors?: unknown }).hiddenForVisitors === true
}

/** show = render the initiative; placeholder = the editor's "not found" box; nothing = render nothing (public). */
export function initiativeCardState(value: unknown): 'show' | 'placeholder' | 'nothing' {
  if (isHiddenForVisitors(value)) return 'nothing'
  if (value && typeof value === 'object' && 'data' in value && (value as { data?: unknown }).data) return 'show'
  return 'placeholder'
}

/** Who a fetcher answers for: public pages, or the admin preview / editor. */
export type Audience = 'public' | 'admin'

/** A missing initiative, as the given audience should receive it. */
export function missingInitiativeFor(audience: Audience): HiddenForVisitors | null {
  return audience === 'public' ? HIDDEN_FOR_VISITORS : null
}
