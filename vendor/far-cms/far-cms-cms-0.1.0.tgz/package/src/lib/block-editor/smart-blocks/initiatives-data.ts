/**
 * Initiative Data Fetcher
 *
 * Server-side query for the InitiativeBlock smart block. An initiative is a
 * BlogPost in the "Initiatives" category whose structured answers live in
 * content JSON as { initiativeData }. Blocks reference it by slug, so pages
 * always render the CURRENT record — edit the initiative in the wizard (or
 * via the AI agent) and every page block showing it updates automatically.
 * That shared record is the bi-directional sync between the page builder
 * and the initiative workflow.
 */

import { prisma } from '../../db'
import { registerFetcher } from './data-resolver'
import { parseInitiativeData, type InitiativeData } from '../../initiatives/types'
import { dbRecordSource, recordFetchers, type RecordSource, type SerializedRecord } from './records-data'
import { applyRules, parseRules, placementFields } from '../../ade/records/rules'
import { getRecordType } from '../../ade-bindings/record-types'
import { missingInitiativeFor, type Audience, type HiddenForVisitors } from './initiative-card'

export interface SerializedInitiative {
  id: string
  slug: string
  status: string
  data: InitiativeData
  /** The initiative's page (records); legacy blog-backed ones use /posts/<slug>. */
  href?: string
}

function fromRecord(r: SerializedRecord): SerializedInitiative {
  return { id: r.id, slug: r.slug, status: r.status, href: r.href, data: r.data as unknown as InitiativeData }
}

/**
 * Initiative fetchers over a record source. Once initiative RECORDS exist
 * they are the one source of truth (featured flag + order live on the
 * record); until then the legacy blog-backed fetchers below are used.
 */
export function initiativeFetchers(source: RecordSource, opts: { audience?: Audience } = {}) {
  const audience = opts.audience ?? 'admin'
  return {
    /**
     * A PINNED card (InitiativeBlock) shows its initiative whatever its status — draft or
     * published — by design: the homepage "Our Impact" cards point at initiatives kept as
     * drafts since 2026-07-29 (only a published one links to its page). Archived ones are
     * gone. Missing → visitors get HIDDEN_FOR_VISITORS (render nothing); the admin preview
     * gets null (the editor's "not found" box). Lists (fetchFeaturedInitiatives) are live-only.
     */
    async fetchInitiative(args: Record<string, unknown>): Promise<SerializedInitiative | HiddenForVisitors | null> {
      if (!(await source.hasAny('initiative'))) return (await fetchInitiative(args)) ?? missingInitiativeFor(audience)
      const slug = args.slug as string | undefined
      const rec = slug ? await source.bySlug('initiative', slug) : null
      return rec ? fromRecord(rec) : missingInitiativeFor(audience)
    },
    async fetchFeaturedInitiatives(args: Record<string, unknown>): Promise<SerializedInitiative[]> {
      if (!(await source.hasAny('initiative'))) return fetchFeaturedInitiatives(args)
      // Declarative placement rules win when the block has them.
      const rules = parseRules(args.rules)
      if (rules && rules.type === 'initiative') return applyRules(await source.list('initiative'), rules, placementFields(getRecordType('initiative'))).map(fromRecord)
      const max = Math.min(12, Math.max(1, Number(args.max) || 8))
      const published = (await source.list('initiative')).filter((r) => r.status === 'PUBLISHED')
      const order = (r: SerializedRecord) => (r.data.featured === true ? Number(r.data.featuredOrder ?? 999) : Infinity)
      const featured = published.filter((r) => r.data.featured === true).sort((a, b) => order(a) - order(b))
      const ordered =
        args.source === 'all'
          ? [...featured, ...published.filter((r) => r.data.featured !== true)]
          : featured.length > 0
            ? featured
            : published
      return ordered.slice(0, max).map(fromRecord)
    },
  }
}

async function fetchInitiative(args: Record<string, unknown>): Promise<SerializedInitiative | null> {
  const slug = args.slug as string | undefined
  if (!slug) return null

  const post = await prisma.blogPost.findFirst({
    where: {
      slug,
      categories: { some: { category: { slug: 'initiatives' } } },
    },
    select: { id: true, slug: true, status: true, content: true },
  })
  if (!post) return null

  const data = parseInitiativeData(post.content)
  if (!data) return null

  return { id: post.id, slug: post.slug, status: post.status, data }
}

async function fetchFeaturedInitiatives(args: Record<string, unknown>): Promise<SerializedInitiative[]> {
  const max = Math.min(12, Math.max(1, Number(args.max) || 8))
  // source 'all' = every published initiative (the /initiatives archive),
  // ordered starred-first then newest. Default 'featured' = starred only
  // (falls back to latest published while nothing is starred).
  const showAll = args.source === 'all'

  const { getInitiativesSettings } = await import('../../settings')
  const { featured } = await getInitiativesSettings()

  const filterToFeatured = !showAll && featured.length > 0
  const posts = await prisma.blogPost.findMany({
    where: {
      status: 'PUBLISHED',
      categories: { some: { category: { slug: 'initiatives' } } },
      ...(filterToFeatured ? { slug: { in: featured } } : {}),
    },
    select: { id: true, slug: true, status: true, content: true, publishedAt: true },
    // 'all' fetches everything (starred-first ordering happens below, then
    // the max clamp); otherwise let the DB order + cap the fallback.
    ...(filterToFeatured ? {} : { orderBy: { publishedAt: 'desc' as const }, ...(showAll ? {} : { take: max }) }),
  })

  const bySlug = new Map(posts.map((p) => [p.slug, p]))
  const ordered = filterToFeatured
    ? (featured.map((slug) => bySlug.get(slug)).filter(Boolean) as typeof posts)
    : showAll
      ? [
          ...(featured.map((slug) => bySlug.get(slug)).filter(Boolean) as typeof posts),
          ...posts.filter((p) => !featured.includes(p.slug)),
        ]
      : posts

  return ordered
    .map((post): SerializedInitiative | null => {
      const data = parseInitiativeData(post.content)
      return data ? { id: post.id, slug: post.slug, status: String(post.status), data } : null
    })
    .filter((x): x is SerializedInitiative => x !== null)
    .slice(0, max)
}

/** Register the initiative + record fetchers with the data resolver. */
export function registerInitiativeFetchers(): void {
  // Registered fetchers serve public pages; the admin preview passes its own (audience 'admin').
  const initiatives = initiativeFetchers(dbRecordSource, { audience: 'public' })
  registerFetcher('fetchInitiative', initiatives.fetchInitiative)
  registerFetcher('fetchFeaturedInitiatives', initiatives.fetchFeaturedInitiatives)
  registerFetcher('fetchRecord', recordFetchers(dbRecordSource).fetchRecord)
}
