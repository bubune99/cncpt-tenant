/**
 * Button variants — solid, outline, text — in one brand colour. The label
 * colour on a solid button is whichever of white / ink reads better on it.
 * Pure; asserted by tokens.assert.ts.
 */

import { BRAND_COLORS, type BrandColor } from '../style-tokens'
import { readAt, writeAt, type Device, type Scope } from './device-classes'
import { contrastRatio, parseHex } from './contrast'
import { BG_COLOR, BORDER_COLOR, BORDER_WIDTH, TEXT_COLOR } from './tokens'

export type ButtonVariant = 'solid' | 'outline' | 'text'

export const BUTTON_VARIANTS: ReadonlyArray<{ id: ButtonVariant; label: string }> = [
  { id: 'solid', label: 'Solid' },
  { id: 'outline', label: 'Outline' },
  { id: 'text', label: 'Text link' },
]

const hexOf = (u: string | null) => /#[0-9a-fA-F]{3,8}/.exec(u ?? '')?.[0]?.toLowerCase() ?? null

export function readButton(className: string | undefined, device: Device): { variant: ButtonVariant; color: string | null } {
  const bg = readAt(className, BG_COLOR.match, device)
  const border = readAt(className, BORDER_WIDTH.match, device)
  const brand = (u: string | null) => BRAND_COLORS.find((c) => c.value === hexOf(u))?.id ?? null
  if (bg && bg !== 'bg-transparent') return { variant: 'solid', color: brand(bg) }
  if (border && border !== 'border-0') return { variant: 'outline', color: brand(readAt(className, BORDER_COLOR.match, device)) }
  return { variant: 'text', color: brand(readAt(className, TEXT_COLOR.match, device)) }
}

/** White or ink, whichever has more contrast on the colour. */
export function labelOn(color: BrandColor): BrandColor {
  const ink = BRAND_COLORS.find((c) => c.id === 'ink')!
  const white = BRAND_COLORS.find((c) => c.id === 'white')!
  const c = parseHex(color.value)!
  return contrastRatio(parseHex(white.value)!, c) >= contrastRatio(parseHex(ink.value)!, c) ? white : ink
}

export function writeButton(className: string | undefined, variant: ButtonVariant, color: BrandColor, device: Device, scope: Scope): string {
  const set = (cls: string, match: (u: string) => boolean, v: string, fallback?: string) => writeAt(cls, match, v, device, scope, fallback)
  let c = className ?? ''
  if (variant === 'solid') {
    c = set(c, BG_COLOR.match, `bg-[${color.value}]`, 'bg-transparent')
    c = set(c, TEXT_COLOR.match, `text-[${labelOn(color).value}]`)
    c = set(c, BORDER_WIDTH.match, 'border-0', 'border-0')
  } else {
    c = set(c, BG_COLOR.match, 'bg-transparent', 'bg-transparent')
    c = set(c, TEXT_COLOR.match, `text-[${color.value}]`)
    c = set(c, BORDER_WIDTH.match, variant === 'outline' ? 'border-2' : 'border-0', 'border-0')
    if (variant === 'outline') c = set(c, BORDER_COLOR.match, `border-[${color.value}]`)
  }
  return c
}
