// Moved to @far-cms/core (far-cms packages/core/src/lib/block-editor/canvas-breakpoints.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/block-editor/canvas-breakpoints'
