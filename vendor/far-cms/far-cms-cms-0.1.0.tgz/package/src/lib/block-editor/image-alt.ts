/**
 * The description (alt text) of a picture block after a picture is chosen.
 * Pure; asserted by image-alt.assert.ts.
 */

/** What the Image template starts with (block-templates.ts). */
export const PLACEHOLDER_ALT = 'Placeholder image'

/**
 * The editor's own words are kept. Otherwise the chosen picture's description
 * from the media library is used, and the template's placeholder never stays
 * on a real picture: with nothing better it becomes empty, to be written.
 */
export function altAfterPick(current: string | null | undefined, picked: string | null | undefined): string {
  const mine = (current ?? '').trim()
  const theirs = (picked ?? '').trim()
  if (mine && mine !== PLACEHOLDER_ALT) return mine
  return theirs
}
