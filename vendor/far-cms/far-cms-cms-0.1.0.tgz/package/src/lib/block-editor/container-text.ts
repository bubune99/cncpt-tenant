/**
 * Is this block drawn as a container (its child blocks, or the builder's empty drop zone), or as its words?
 *
 * A list item, a quote or a div can be written either way: with child blocks, or with words of its own
 * and no children. Treating every such tag as a container drew nothing for the second kind, on the public
 * page as well as in the builder. Child blocks still win when there are any.
 * Pure; asserted by container-text.assert.tsx.
 */
import { isContainerTag, type Block } from './types'

export function drawsAsContainer(block: Pick<Block, 'tag' | 'children' | 'textContent'>): boolean {
  if (block.children && block.children.length > 0) return true
  if (!isContainerTag(block.tag)) return false
  return !(typeof block.textContent === 'string' && block.textContent.trim().length > 0)
}
