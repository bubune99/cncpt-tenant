/**
 * Has the owner published a reviewed legal page in the CMS? Then the code
 * route (/legal/terms …) sends people there, so the approved text is what
 * the site shows. Slugs: lib/legal/links › cmsSlugs. Any DB failure → null
 * (the code route renders as before).
 */

import { prisma } from '../db'
import { cmsHref, cmsSlugCandidates, type LegalKind } from './links'
import { getSettings } from '../settings'
import { contactFromStored } from '../settings/site-identity'

export async function publishedLegalPageHref(kind: LegalKind): Promise<string | null> {
  const candidates = cmsSlugCandidates(kind)
  try {
    const pages = await prisma.page.findMany({
      where: { slug: { in: candidates }, status: 'PUBLISHED' },
      select: { slug: true },
    })
    // Most specific slug first (the order in cmsSlugs).
    const found = candidates.find((c) => pages.some((p: { slug: string }) => p.slug === c))
    return found ? cmsHref(found) : null
  } catch {
    return null
  }
}

/** The site's contact email for "our terms are being finalised" (Settings › Contact), or ''. */
export async function legalContactEmail(): Promise<string> {
  try {
    // Only what the owner saved (Settings › Contact) — never a code default.
    return contactFromStored(await getSettings<Record<string, unknown>>('general', {})).supportEmail.trim()
  } catch {
    return ''
  }
}
