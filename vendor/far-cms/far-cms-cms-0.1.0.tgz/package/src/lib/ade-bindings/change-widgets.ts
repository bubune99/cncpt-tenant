// Moved to @far-cms/core (far-cms packages/core/src/lib/ade-bindings/change-widgets.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/ade-bindings/change-widgets'
