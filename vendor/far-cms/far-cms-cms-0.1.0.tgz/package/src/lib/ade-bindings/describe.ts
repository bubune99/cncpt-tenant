/**
 * Plain-language descriptions of change sets for non-technical staff.
 * Asserted by describe.assert.ts.
 *
 * Rules: never show raw field names (textContent, slug…), never show empty
 * "— → —" rows, never say "change(s)/step(s)". New things are described as
 * what they will be; edits list only the facts that actually change.
 */

import { IMPORT_NOTE, sourcePhrase } from './import-page'
import type { BlockChange, FieldChange } from '../ade'
import { RECORD_TYPES } from './record-types'

export interface DescribableItem {
  targetType: string
  operation: string
  category: string
  status: string
  summary: string
  before: unknown
  after: unknown
  input: Record<string, unknown>
  fieldChanges: FieldChange[]
  blockChanges: BlockChange[]
  previewPath: string | null
}

export interface DetailRow {
  label: string
  before: string | null
  after: string
}

const FIELD_LABELS: Record<string, string> = {
  title: 'Title',
  metaTitle: 'Search engine title',
  metaDescription: 'Search engine description',
  status: 'Visibility',
  slug: 'Web address',
  excerpt: 'Short description',
  featured: 'Featured',
  parentId: 'Parent page',
  pageStatus: 'Page visibility',
  textContent: 'Text',
  className: 'Styling',
  attrs: 'Link or image',
  hidden: 'Hidden',
  label: 'Name in the editor',
  tag: 'Kind of element',
}

/** Human label for a field key (record types first, then common page fields). */
export function fieldLabel(key: string): string {
  for (const def of Object.values(RECORD_TYPES)) {
    const f = def.fields.find((x) => x.key === key)
    if (f) return f.label
  }
  return FIELD_LABELS[key] ?? key.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, (c) => c.toUpperCase())
}

const STATUS_WORDS: Record<string, string> = { PUBLISHED: 'Live', DRAFT: 'Draft (hidden)', ARCHIVED: 'Archived', SCHEDULED: 'Scheduled' }

/** A value as a person would read it; '' for "nothing". */
export function humanValue(v: unknown): string {
  if (v === null || v === undefined || v === '') return ''
  if (typeof v === 'boolean') return v ? 'Yes' : 'No'
  if (typeof v === 'string') return STATUS_WORDS[v] ?? v
  if (Array.isArray(v)) {
    const parts = v.map((x) => (x && typeof x === 'object' && 'value' in x ? `${(x as { value: string }).value} ${(x as { label?: string }).label ?? ''}`.trim() : humanValue(x))).filter(Boolean)
    return parts.join(', ')
  }
  if (typeof v === 'object') {
    const o = v as Record<string, unknown>
    if (typeof o.href === 'string') return o.href
    if (typeof o.src === 'string') return o.src
    return ''
  }
  return String(v)
}

/** Detail rows: only fields that really change, human-labelled, no empty rows. */
export function detailRows(item: DescribableItem): DetailRow[] {
  if (item.targetType === 'blog-post' && item.operation === 'update') {
    const rows = blogRows(item.before, item.after)
    if (rows.length) return rows
  }
  const rows: DetailRow[] = []
  for (const c of item.fieldChanges) {
    if (['featuredOrder', 'pageId', 'record'].includes(c.field)) continue
    const before = humanValue(c.before)
    const after = humanValue(c.after)
    if (before === after || (!before && !after)) continue
    rows.push({ label: fieldLabel(c.field), before: item.operation === 'create' ? null : before || null, after: after || '(removed)' })
  }
  for (const b of item.blockChanges) {
    const what = b.label || (b.tag && /^h[1-6]$/.test(b.tag) ? 'Heading' : b.tag === 'p' ? 'Paragraph' : b.tag === 'img' ? 'Image' : b.tag === 'a' ? 'Link' : 'Section')
    if (b.kind === 'added') {
      const text = b.fields.find((f) => f.field === 'textContent')?.after
      rows.push({ label: `New ${what.toLowerCase()}`, before: null, after: humanValue(text) || 'added' })
      continue
    }
    if (b.kind === 'removed') {
      rows.push({ label: what, before: 'shown', after: '(removed)' })
      continue
    }
    for (const f of b.fields) {
      if (f.field === 'className') {
        rows.push({ label: `${what} styling`, before: null, after: 'adjusted' })
        continue
      }
      const before = humanValue(f.before)
      const after = humanValue(f.after)
      if (before === after || (!before && !after)) continue
      rows.push({ label: f.field === 'textContent' ? what : `${what} · ${fieldLabel(f.field)}`, before: before || null, after: after || '(removed)' })
    }
  }
  return rows
}

function recordLabel(type: string): string {
  return RECORD_TYPES[type]?.label.toLowerCase() ?? 'item'
}

function pageName(item: DescribableItem): string {
  const m = /(?:on|to|from) “([^”]+)”\s*$/.exec(item.summary) ?? /page “([^”]+)”/.exec(item.summary) ?? /“([^”]+)”/.exec(item.summary)
  return m ? m[1] : 'a page'
}

/** "the About page", but "the SAMPLE walk page" for a title that already ends in "page" (walk 2026-11-19). */
function thePage(name: string): string {
  return /\bpage$/i.test(name) ? `the ${name}` : `the ${name} page`
}

/** What a person calls an added block that has no section name (walk 2026-11-19: not "a new part"). */
const TAG_PART: Record<string, string> = {
  h1: 'a heading', h2: 'a heading', h3: 'a heading', h4: 'a heading', h5: 'a heading', h6: 'a heading',
  p: 'a paragraph', img: 'a picture', video: 'a video', a: 'a link', button: 'a button', ul: 'a list', ol: 'a list',
  blockquote: 'a quote', hr: 'a divider', form: 'a form', section: 'a section', table: 'a table',
}

/** A saved form placed on a page is 'a form' (its block is a div carrying data-form-slug). */
function partOf(b: { tag?: string; fields: Array<{ field: string; after: unknown }> }): string | undefined {
  const attrs = b.fields.find((f) => f.field === 'attrs')?.after as Record<string, unknown> | undefined
  if (attrs && typeof attrs === 'object' && 'data-form-slug' in attrs) return 'a form'
  return b.tag ? TAG_PART[b.tag.toLowerCase()] : undefined
}

function list(parts: string[]): string {
  if (parts.length <= 1) return parts[0] ?? ''
  return `${parts.slice(0, -1).join(', ')} and ${parts[parts.length - 1]}`
}

/** A form edit in one phrase: "changes 2 questions of the “Contact” form". */
export function formPhrase(item: Pick<DescribableItem, 'input' | 'after'>): string {
  const name = String(item.input.name ?? (item.after as { doc?: { name?: string } } | null)?.doc?.name ?? '')
  const changes = Array.isArray(item.input.changes) ? (item.input.changes as unknown[]).map(String) : []
  const isRule = (c: string) => /automation “|^turns (on|off) “/.test(c)
  const questions = changes.filter((c) => /^(adds|removes|edits) “/.test(c) && !isRule(c)).length
  // Turning the form on or off is said as that, not 'changes whether it is on' (walk 2026-11-19).
  const onOff = changes.includes('changes whether it is on')
  const nowOn = (item.after as { doc?: { status?: string } } | null)?.doc?.status === 'ACTIVE'
  const settings = changes.filter((c) => c.startsWith('changes ') && !isRule(c) && c !== 'changes whether it is on').map((c) => c.slice('changes '.length))
  const rules = changes.filter(isRule)
  const parts: string[] = []
  if (questions) parts.push(`changes ${questions === 1 ? 'one question' : `${questions} questions`}`)
  if (changes.includes('reorders the questions')) parts.push('reorders the questions')
  if (settings.length) parts.push(`changes ${list(settings)}`)
  if (rules.length) parts.push(rules.length === 1 ? rules[0] : `changes ${rules.length} automations`)
  const title = `the “${name || 'untitled'}” form`
  if (onOff && !parts.length) return `${nowOn ? 'turns on' : 'turns off'} ${title}`
  const what = list(parts) || 'edits'
  // "of" for the form's own content; automations sit "on" it.
  const prep = questions || settings.length || changes.includes('reorders the questions') ? 'of' : 'on'
  return `${what} ${prep} ${title}${onOff ? ` and ${nowOn ? 'turns it on' : 'turns it off'}` : ''}`
}

// --- blog posts ------------------------------------------------------------

const POST_ROW_LABELS: Record<string, string> = {
  title: 'Title', slug: 'Web address', excerpt: 'Summary', contentHtml: 'Story', visibility: 'Who can see it',
  categoryIds: 'Categories', tagIds: 'Tags', authorId: 'Author', featured: 'Feature on the home page',
  homeOrder: 'Home-page order', allowComments: 'Comments', metaTitle: 'Search title', metaDescription: 'Search description',
  coverMediaId: 'Cover', shareMediaId: 'Share image',
}
const VISIBILITY_WORDS: Record<string, string> = { PUBLIC: 'Everyone', PRIVATE: 'Only staff', PASSWORD_PROTECTED: 'With a password', MEMBERS_ONLY: 'Members only' }

/** The post's name from a blog item (doc title, input title, or the summary). */
function postName(item: Pick<DescribableItem, 'input' | 'after' | 'summary'>): string {
  const doc = (item.after as { doc?: { title?: unknown } } | null)?.doc
  const t = typeof doc?.title === 'string' && doc.title ? doc.title : typeof item.input.title === 'string' ? item.input.title : ''
  return t || (/“([^”]+)”/.exec(item.summary)?.[1] ?? 'untitled')
}

/** "changes the title and cover of the post “X”" — from the plain-word list the drafter recorded. */
export function blogPhrase(item: Pick<DescribableItem, 'operation' | 'input' | 'after' | 'summary'>): string {
  if (item.operation === 'create') return `drafts a new post “${postName(item)}”`
  const changes = Array.isArray(item.input.changes) ? (item.input.changes as unknown[]).map(String) : []
  return changes.length ? `changes the ${list(changes)} of the post “${postName(item)}”` : `edits the post “${postName(item)}”`
}

/** Review-card rows for a post edit: one per changed field, never raw ids or HTML. */
export function blogRows(before: unknown, after: unknown): DetailRow[] {
  const b = (before as { doc?: Record<string, unknown> } | null)?.doc
  const a = (after as { doc?: Record<string, unknown> } | null)?.doc
  if (!b || !a) return []
  const rows: DetailRow[] = []
  for (const [key, label] of Object.entries(POST_ROW_LABELS)) {
    const x = b[key]
    const y = a[key]
    if (JSON.stringify(x ?? null) === JSON.stringify(y ?? null)) continue
    if (key === 'contentHtml') rows.push({ label, before: null, after: 'rewritten' })
    else if (key === 'coverMediaId' || key === 'shareMediaId') rows.push({ label, before: null, after: y ? 'new picture' : '(removed)' })
    else if (key === 'categoryIds' || key === 'tagIds') {
      const n = Array.isArray(y) ? y.length : 0
      rows.push({ label, before: null, after: n ? `${n} chosen` : '(none)' })
    } else if (key === 'authorId') rows.push({ label, before: null, after: 'changed' })
    else if (key === 'visibility') rows.push({ label, before: VISIBILITY_WORDS[String(x)] ?? null, after: VISIBILITY_WORDS[String(y)] ?? String(y) })
    else if (key === 'homeOrder') rows.push({ label, before: x === null || x === undefined ? 'by date' : `#${Number(x) + 1}`, after: y === null || y === undefined ? 'by date' : `#${Number(y) + 1}` })
    else {
      const hb = humanValue(x)
      const ha = humanValue(y)
      rows.push({ label, before: hb || null, after: ha || '(removed)' })
    }
  }
  return rows
}

/** The library blocks a page draft adds (block-drafters input.library), each with its shelf: "“Donate” from the Sections library (a copy)". */
export function libraryAdds(raw: unknown): string[] {
  if (!Array.isArray(raw)) return []
  return raw.flatMap((x) => {
    const o = (x ?? {}) as { name?: unknown; shelf?: unknown; mode?: unknown }
    if (typeof o.name !== 'string' || !o.name.trim()) return []
    const name = `“${o.name.trim().slice(0, 80)}”`
    if (o.shelf === 'saved') return [`your saved block ${name} (${o.mode === 'copy' ? 'a copy' : 'linked'})`]
    if (o.shelf === 'sections' || o.shelf === 'ideas') return [`${name} from the ${o.shelf === 'sections' ? 'Sections' : 'Ideas'} library (a copy)`]
    return [name]
  })
}

/** One sentence describing a whole change set. */
const PART_BY_TAG: Record<string, string> = { h1: 'heading', h2: 'heading', h3: 'heading', h4: 'heading', h5: 'heading', h6: 'heading', p: 'paragraph', a: 'link', button: 'button', li: 'list item', blockquote: 'quote', span: 'text', img: 'picture' }
const WORDS_MAX = 40

/** A single changed part whose text changed: its plain name and the new words (clipped). */
function namedTextEdit(b: BlockChange): { part: string; words: string } | null {
  const text = b.fields.find((f) => f.field === 'textContent')
  if (!text || typeof text.after !== 'string' || !text.after.trim()) return null
  const part = (b.label && /^[A-Za-z ]{2,30}$/.test(b.label) ? b.label.toLowerCase() : PART_BY_TAG[b.tag ?? '']) ?? null
  if (!part) return null
  const w = text.after.trim().replace(/\s+/g, ' ')
  return { part, words: w.length > WORDS_MAX ? `${w.slice(0, WORDS_MAX)}…` : w }
}

export function describeChangeSet(items: ReadonlyArray<DescribableItem>): string {
  const open = items.filter((i) => i.status === 'pending' || i.status === 'saved')
  const all = open.length ? open : items
  const recordCreate = all.find((i) => i.targetType === 'record' && i.operation === 'create')
  if (recordCreate) {
    const snap = recordCreate.after as { type?: string; data?: Record<string, unknown> }
    const data = snap.data ?? {}
    const name = String(data.name ?? data.title ?? 'it')
    const where = typeof data.location === 'string' && data.location ? ` in ${data.location}` : ''
    const extras = ['its own page']
    if (all.some((i) => i.targetType === 'page-content' && /card/i.test(i.summary))) extras.push('a card on the home page')
    const publishes = all.some((i) => i.category === 'publish')
    return `Adds a new ${recordLabel(snap.type ?? '')}, ${name}${where}, with ${list(extras)}${publishes ? ' — published when you approve' : ''}.`
  }

  const phrases: string[] = []
  const samePageEdit = new Map<string, string[]>()
  for (const i of all) {
    if (i.targetType === 'record') {
      const snap = i.after as { type?: string; data?: Record<string, unknown> }
      const fields = i.fieldChanges.filter((c) => !['featuredOrder'].includes(c.field)).map((c) => fieldLabel(c.field).toLowerCase())
      phrases.push(`updates the ${list(fields)} of the ${recordLabel(snap.type ?? '')} ${String(snap.data?.name ?? '')}`.replace(/\s+/g, ' ').trim())
    } else if (i.targetType === 'record-status' || i.targetType === 'page-status' || i.targetType === 'blog-status') {
      const after = (i.after ?? {}) as { status?: string; scheduledAt?: string | null }
      const s = String(after.status ?? '')
      // A page or record being scheduled keeps its current status (DRAFT) and gains a go-live time — it isn't unpublished.
      const scheduled = s === 'SCHEDULED' || (s !== 'PUBLISHED' && !!after.scheduledAt)
      const verb = scheduled ? 'schedules' : s === 'PUBLISHED' ? 'publishes' : s === 'ARCHIVED' ? 'archives' : 'unpublishes'
      const what = i.summary
        .replace(/^(Publish|Unpublish|Schedule|Archive)\s+/i, '')
        .replace(/\s+and its page$/, ' and its page')
        .replace(/\s+—\s+Goes live\s+/, ' to go live ')
      phrases.push(`${verb} ${i.targetType === 'blog-status' ? what.replace(/^post /, 'the post ') : what}`)
    } else if (i.targetType === 'site-layout') {
      phrases.push(`changes the site ${String(i.input.part ?? 'header')} (every page)`)
    } else if (i.targetType === 'page-content') {
      const ops = Array.isArray(i.input.ops) ? (i.input.ops as Array<{ tool?: string; value?: unknown }>) : []
      if (ops.length && ops.every((o) => o.tool === 'setOverride')) {
        phrases.push(ops.some((o) => o.value === null) ? `resets a customized part of ${pageName(i)} to the record` : `customizes how ${pageName(i)} shows a detail`)
        continue
      }
      // Code imported from outside (importPageCode): say where from, and that it is outside code (import-page).
      const imported = i.input.imported as { source?: unknown } | undefined
      if (imported && typeof imported.source === 'string') {
        phrases.push(`replaces ${thePage(pageName(i))} with ${sourcePhrase(imported.source)} (${IMPORT_NOTE})`)
        continue
      }
      // Blocks added from the library: the sentence names the shelf, as the chat reply does (P4).
      const lib = libraryAdds(i.input.library)
      if (lib.length) {
        const what = `adds ${list(lib)}`
        samePageEdit.set(what, [...(samePageEdit.get(what) ?? []), pageName(i)])
        phrases.push(`${what} to ${thePage(pageName(i))}`)
        continue
      }
      // Named sections ("a Hero banner") read better than counting nested parts.
      const addedRaw = i.blockChanges.filter((b) => b.kind === 'added')
      // A plain, unnamed section added along with parts is their wrapper, not a part (walk 2026-11-19).
      const wraps = (b: (typeof addedRaw)[number]) => !b.label && (b.tag ?? '').toLowerCase() === 'section'
      const addedAll = addedRaw.some((b) => !wraps(b)) ? addedRaw.filter((b) => !wraps(b)) : addedRaw
      const labelled = addedAll.filter((b) => b.label).map((b) => `a ${b.label!.toLowerCase()}`)
      // No section names: name each part by what it is, when that reads as one short list with no repeats.
      const byTag = addedAll.map((b) => partOf(b))
      const tagNamed = !labelled.length && addedAll.length > 0 && addedAll.length <= 3 && byTag.every(Boolean) && new Set(byTag).size === byTag.length ? (byTag as string[]) : []
      const named = labelled.length ? labelled : tagNamed
      const added = named.length ? 0 : addedAll.length
      const changed = i.blockChanges.filter((b) => b.kind === 'changed').length
      // The assistant's removeBlock / moveBlock (2026-11-16): said, not folded into 'edits'.
      const moved = i.blockChanges.filter((b) => b.kind === 'moved').length
      const removed = i.blockChanges.filter((b) => b.kind === 'removed').length
      // One part with new words: name the part and the words, so two edits on one page differ (walk 2026-11-16).
      const textEdit = changed === 1 && !addedAll.length ? namedTextEdit(i.blockChanges.find((b) => b.kind === 'changed')!) : null
      if (textEdit) {
        phrases.push(`changes the ${textEdit.part} of ${thePage(pageName(i))} to “${textEdit.words}”`)
        continue
      }
      const bits = [
        changed ? `changes ${changed === 1 ? 'one part' : `${changed} parts`}` : '',
        named.length ? `adds ${list(Array.from(new Set(named)))}` : added ? `adds ${added === 1 ? 'a new part' : `${added} new parts`}` : '',
        moved ? `moves ${moved === 1 ? 'one part' : `${moved} parts`}` : '',
        removed ? `removes ${removed === 1 ? 'one part' : `${removed} parts`}` : '',
      ].filter(Boolean)
      const what = list(bits) || 'edits'
      // The same edit on several pages reads as one phrase (grouped below).
      samePageEdit.set(what, [...(samePageEdit.get(what) ?? []), pageName(i)])
      // Only added: 'to'; added and changed: 'on' (walk 2026-11-19: not 'adds a paragraph of the page'); else 'of'.
      const where = (named.length || added) && !changed ? `to ${thePage(pageName(i))}` : (named.length || added) && changed ? `on ${thePage(pageName(i))}` : `of ${thePage(pageName(i))}`
      phrases.push(`${what} ${where}`.replace(/(of|to) the a page\b/, 'on a page'))
    } else if (i.targetType === 'page' && i.operation === 'create') {
      phrases.push(`creates a new page${typeof i.input.slug === 'string' ? ` at ${i.input.slug}` : ''}`)
    } else if (i.targetType === 'page') {
      phrases.push(`updates the ${list(i.fieldChanges.map((c) => fieldLabel(c.field).toLowerCase()))} of ${thePage(pageName(i))}`)
    } else if (i.targetType === 'blog-post') {
      phrases.push(blogPhrase(i))
    } else if (i.targetType === 'form') {
      phrases.push(formPhrase(i))
    } else if (i.targetType === 'record-featured') {
      phrases.push('changes which initiatives are featured on the home page')
    } else {
      phrases.push(i.summary.charAt(0).toLowerCase() + i.summary.slice(1))
    }
  }
  for (const [what, pages] of samePageEdit) {
    if (pages.length < 2) continue
    const mine = new Set(pages.flatMap((p) => [`${what} of ${thePage(p)}`, `${what} to ${thePage(p)}`]))
    const at = phrases.findIndex((ph) => mine.has(ph))
    const rest = phrases.filter((ph) => !mine.has(ph))
    rest.splice(Math.max(0, at), 0, `${what} on ${pages.length} pages (${list(pages)})`)
    phrases.splice(0, phrases.length, ...rest)
  }
  // "…to the X page and publishes page “X”" → "…and publishes it" (walk 2026-11-19).
  for (let k = 0; k < phrases.length; k++) {
    const m = /^publishes page “([^”]+)”$/.exec(phrases[k])
    if (m && phrases.some((ph, j) => j !== k && ph.includes(thePage(m[1])))) phrases[k] = 'publishes it'
  }
  const sentence = list(Array.from(new Set(phrases)))
  return sentence ? sentence.charAt(0).toUpperCase() + sentence.slice(1) + '.' : 'A change from the assistant.'
}
