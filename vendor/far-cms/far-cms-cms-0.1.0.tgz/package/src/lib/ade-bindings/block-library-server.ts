/**
 * Saved blocks from the database: the site's SECTION partials (Partial.content
 * holds the blocks and a small meta — lib/ade/blocks/library savedMetaOf),
 * with how many pages use each linked. Read-only.
 */

import { prisma } from '../db'
import { savedMetaOf, usageOf, type LibraryBlock } from '../ade/blocks/library'
import type { Block } from '../block-editor/types'
import { sectionsCatalog } from './block-library'

const PAGE_SCAN = 1000

export async function savedCatalog(): Promise<LibraryBlock[]> {
  const [parts, pages] = await Promise.all([
    prisma.partial.findMany({ where: { category: 'SECTION' }, select: { id: true, name: true, description: true, content: true, updatedAt: true }, orderBy: { updatedAt: 'desc' }, take: 200 }),
    prisma.page.findMany({ select: { content: true }, take: PAGE_SCAN }),
  ])
  return parts.flatMap((p) => {
    const blocks = ((p.content ?? {}) as { blocks?: Block[] }).blocks ?? []
    if (!blocks.length) return []
    const meta = savedMetaOf(p.content)
    // Several top-level blocks are kept together under one wrapper for the preview and a copy.
    const tree: Block = blocks.length === 1 ? blocks[0] : ({ id: `${p.id}-wrap`, tag: 'div', className: '', children: blocks } as Block)
    return [{
      id: p.id,
      shelf: 'saved' as const,
      name: p.name,
      category: meta?.category ?? 'other',
      summary: p.description ?? '',
      tree,
      mode: meta?.mode ?? 'linked',
      usage: usageOf(pages, p.id),
      savedOn: p.updatedAt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    }]
  })
}

/** Saved blocks, then the starting layouts (Ideas are made on demand). */
export async function libraryCatalog(): Promise<LibraryBlock[]> {
  return [...(await savedCatalog()), ...sectionsCatalog()]
}
