/**
 * Which images the assistant's text may show in Dzidzor: only files on the
 * site's own media domain (old r2.dev links are rewritten to it first).
 * Client-safe.
 */

import { safeChatImageSrc } from '../ade/chat/safe-links'
import { MEDIA_ORIGIN, toMediaDomain } from '../media/public-url'

export const CHAT_MEDIA_PREFIXES: readonly string[] = [`${MEDIA_ORIGIN}/`]

export const chatImageSrc = (src: unknown): string | null => safeChatImageSrc(toMediaDomain(src), CHAT_MEDIA_PREFIXES)
