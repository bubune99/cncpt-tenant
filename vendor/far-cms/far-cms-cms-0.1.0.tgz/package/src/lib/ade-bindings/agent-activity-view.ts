/**
 * Agent activity (/admin/agent-activity) — the runs list and one run's trace.
 * Pure: shapes from the runs API, how they read in the table, and how spans
 * become the Agent Trace's input. Asserted by agent-activity-view.assert.ts.
 */

import type { TraceSpan } from '../../components/ui/agent-trace'

export type RunStatus = 'ok' | 'error' | 'aborted' | 'budget' | (string & {})
export type SpanEffect = 'read' | 'draft' | 'write' | 'irreversible' | (string & {})

export interface AgentRunRow {
  id: string
  at: string
  /** Both null for a run with no signed-in person (e.g. a scheduled job). */
  user: { id: string | null; name: string | null } | null
  area: string | null
  request: string
  model: string | null
  steps: number
  durationMs: number
  tokens: number
  status: RunStatus
  changes: { drafts: number; writes: number }
}

export interface AgentActivityStats {
  runsToday: number
  /** 0–1 */
  errorRate: number
  tokens: number
  /** USD */
  cost: number
  topTools: Array<{ name: string; count: number }>
  draftsPending: number
}

export interface AgentSpanRow {
  id: string
  parentId: string | null
  kind: string
  label: string
  startMs: number
  endMs: number
  status: string
  attempt?: number | null
  tokens?: number | null
  detail?: string | null
  effect?: SpanEffect | null
  changeSetId?: string | null
  auditLogId?: string | null
  seq?: number
  /** Redacted by the server, capped. */
  input?: unknown
  /** One-line summary. */
  output?: string | null
}

export interface AgentRunFull extends AgentRunRow {
  endedAt?: string | null
  route?: string | null
  effort?: string | null
  error?: string | null
  tokensIn?: number
  tokensOut?: number
  cacheRead?: number
  cacheWrite?: number
  cost?: number
  toolGroupsLoaded?: string[]
  conversationId?: string | null
  droppedSpans?: number
}

export interface RunChangeSet {
  id: string
  title?: string | null
  status?: string | null
  items?: number
  href?: string | null
}

export interface RunAuditRow {
  id: string
  action: string
  targetType?: string | null
  targetId?: string | null
  at?: string
}

export interface AgentRunDetail {
  run: AgentRunFull
  spans: AgentSpanRow[]
  changeSets: RunChangeSet[]
  audit: RunAuditRow[]
}

/** Tolerates missing arrays so a partial response still renders. */
export function normalizeDetail(d: Partial<AgentRunDetail> & { run: AgentRunFull }): AgentRunDetail {
  return {
    run: d.run,
    spans: Array.isArray(d.spans) ? d.spans : [],
    changeSets: Array.isArray(d.changeSets) ? d.changeSets : [],
    audit: Array.isArray(d.audit) ? d.audit : [],
  }
}

/** What one span links to: its change set and audit row, when the run has them. */
export function spanLinks(d: AgentRunDetail, span: AgentSpanRow): { changeSet: RunChangeSet | null; audit: RunAuditRow | null } {
  const changeSet = span.changeSetId ? (d.changeSets.find((c) => c.id === span.changeSetId) ?? { id: span.changeSetId }) : null
  const audit = span.auditLogId ? (d.audit.find((a) => a.id === span.auditLogId) ?? { id: span.auditLogId, action: '' }) : null
  return { changeSet, audit }
}

export interface RunFilters {
  person: string
  /** Runs that touched one change set (links from Review). */
  changeSet: string
  area: string
  status: string
  effect: '' | 'read' | 'draft' | 'write' | 'irreversible'
  /** YYYY-MM-DD (date inputs); sent as the day's ISO bounds. */
  from: string
  to: string
}

export const NO_FILTERS: RunFilters = { person: '', changeSet: '', area: '', status: '', effect: '', from: '', to: '' }

export type ServerSort = 'newest' | 'oldest' | 'tokens' | 'duration'

/** The column sorts the API can do across all pages; others sort the loaded rows only. */
export function serverSort(s: Sort): ServerSort {
  if (s.key === 'at') return s.dir === 'asc' ? 'oldest' : 'newest'
  if (s.key === 'tokens' && s.dir === 'desc') return 'tokens'
  if (s.key === 'durationMs' && s.dir === 'desc') return 'duration'
  return 'newest'
}

/** A local date (YYYY-MM-DD) as the ISO instant its day starts, or ends. */
export function dayBound(day: string, end: boolean): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day)
  if (!m) return ''
  const d = end ? new Date(+m[1], +m[2] - 1, +m[3], 23, 59, 59, 999) : new Date(+m[1], +m[2] - 1, +m[3])
  return d.toISOString()
}

/** The list request: only the filters that are set, the sort, and the page cursor. */
export function runsQuery(f: RunFilters, sort: ServerSort = 'newest', cursor?: string | null): string {
  const p = new URLSearchParams()
  for (const k of ['person', 'area', 'status', 'effect', 'changeSet'] as const) if (f[k]) p.set(k, f[k])
  if (f.from && dayBound(f.from, false)) p.set('from', dayBound(f.from, false))
  if (f.to && dayBound(f.to, true)) p.set('to', dayBound(f.to, true))
  if (sort !== 'newest') p.set('sort', sort)
  if (cursor) p.set('cursor', cursor)
  return p.toString()
}

export function hasFilters(f: RunFilters): boolean {
  return Object.values(f).some(Boolean)
}

/** Who asked, for a run with or without a person. */
export function personName(u: AgentRunRow['user']): string {
  return u?.name || (u?.id ? 'Unnamed' : 'Automatic')
}

/** "Rewrite the hero copy for the clean water…" — one line, about 60 characters, cut at a word. */
export function shortRequest(text: string | null | undefined, max = 60): string {
  const one = (text ?? '').replace(/\s+/g, ' ').trim()
  if (one.length <= max) return one
  const cut = one.slice(0, max)
  const space = cut.lastIndexOf(' ')
  return `${(space > max * 0.6 ? cut.slice(0, space) : cut).replace(/[\s,.;:–-]+$/, '')}…`
}

export function formatDuration(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) return '—'
  if (ms < 1000) return `${Math.round(ms)}ms`
  if (ms < 60_000) return `${(ms / 1000).toFixed(ms < 10_000 ? 1 : 0)}s`
  const m = Math.floor(ms / 60_000)
  const s = Math.round((ms % 60_000) / 1000)
  return s ? `${m}m ${s}s` : `${m}m`
}

/** 950 → "950", 12_400 → "12.4k", 2_300_000 → "2.3M". */
export function formatTokens(n: number): string {
  if (!Number.isFinite(n)) return '—'
  if (n < 1000) return String(Math.round(n))
  if (n < 1_000_000) return `${(n / 1000).toFixed(n < 10_000 ? 1 : 0).replace(/\.0$/, '')}k`
  return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`
}

export function formatCost(usd: number): string {
  if (!Number.isFinite(usd)) return '—'
  if (usd > 0 && usd < 0.01) return '< $0.01'
  return `$${usd.toFixed(2)}`
}

export function formatRate(r: number): string {
  if (!Number.isFinite(r)) return '—'
  const pct = r * 100
  return `${pct > 0 && pct < 1 ? pct.toFixed(1) : Math.round(pct)}%`
}

const STATUS_LABEL: Record<string, string> = { ok: 'Done', error: 'Failed', aborted: 'Stopped', budget: 'Budget hit' }
export function statusLabel(s: RunStatus): string {
  return STATUS_LABEL[s] ?? s.charAt(0).toUpperCase() + s.slice(1)
}
/** Failed reads strongest; normal runs stay quiet. */
export function statusTone(s: RunStatus): 'neutral' | 'good' | 'warn' | 'strong' {
  if (s === 'error') return 'strong'
  if (s === 'budget') return 'warn'
  return 'neutral'
}

/** "2 drafts · 1 write", or "" when the run changed nothing. */
export function changesLabel(c: { drafts: number; writes: number }): string {
  const out: string[] = []
  if (c.drafts) out.push(`${c.drafts} draft${c.drafts === 1 ? '' : 's'}`)
  if (c.writes) out.push(`${c.writes} write${c.writes === 1 ? '' : 's'}`)
  return out.join(' · ')
}

export type SortKey = 'at' | 'user' | 'area' | 'model' | 'steps' | 'durationMs' | 'tokens' | 'status' | 'changes'
export interface Sort {
  key: SortKey
  dir: 'asc' | 'desc'
}
export const DEFAULT_SORT: Sort = { key: 'at', dir: 'desc' }

function sortValue(r: AgentRunRow, k: SortKey): string | number {
  switch (k) {
    case 'at': return Date.parse(r.at) || 0
    case 'user': return (r.user?.name ?? '').toLowerCase()
    case 'area': return (r.area ?? '').toLowerCase()
    case 'model': return (r.model ?? '').toLowerCase()
    case 'status': return r.status
    case 'changes': return r.changes.writes * 1000 + r.changes.drafts
    default: return r[k]
  }
}

/** A new array, sorted; ties keep the API order (newest first). */
export function sortRuns(runs: readonly AgentRunRow[], s: Sort): AgentRunRow[] {
  const sign = s.dir === 'asc' ? 1 : -1
  return runs
    .map((r, i) => ({ r, i }))
    .sort((a, b) => {
      const x = sortValue(a.r, s.key)
      const y = sortValue(b.r, s.key)
      return x < y ? -sign : x > y ? sign : a.i - b.i
    })
    .map(({ r }) => r)
}

/** Clicking a column: same column flips, a new one starts at its natural order. */
export function nextSort(cur: Sort, key: SortKey): Sort {
  if (cur.key === key) return { key, dir: cur.dir === 'asc' ? 'desc' : 'asc' }
  return { key, dir: key === 'user' || key === 'area' || key === 'model' || key === 'status' ? 'asc' : 'desc' }
}

/** The people and areas seen so far, for the filter selects. */
export function filterOptions(runs: readonly AgentRunRow[]): { users: Array<{ id: string; name: string }>; areas: string[] } {
  const users = new Map<string, string>()
  const areas = new Set<string>()
  for (const r of runs) {
    if (r.user?.id) users.set(r.user.id, r.user.name || 'Unnamed')
    if (r.area) areas.add(r.area)
  }
  return {
    users: [...users].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name)),
    areas: [...areas].sort((a, b) => a.localeCompare(b)),
  }
}

const KINDS = new Set(['agent', 'model', 'tool', 'io'])

/** API spans → the Agent Trace's spans. Offsets are clamped so a bad row can't break the timeline. */
export function toTraceSpans(spans: readonly AgentSpanRow[]): TraceSpan[] {
  return spans.map((s) => {
    const start = Math.max(0, Number(s.startMs) || 0)
    const end = Math.max(start, Number(s.endMs) || start)
    const status = s.status === 'error' || s.status === 'cached' ? s.status : 'ok'
    return {
      id: s.id,
      label: s.label,
      start,
      end,
      kind: (KINDS.has(s.kind) ? s.kind : 'tool') as TraceSpan['kind'],
      status,
      ...(s.parentId ? { parentId: s.parentId } : {}),
      ...(s.detail ? { detail: s.detail } : {}),
      ...(typeof s.tokens === 'number' && s.tokens > 0 ? { tokens: s.tokens } : {}),
      ...(typeof s.attempt === 'number' && s.attempt > 1 ? { attempt: s.attempt } : {}),
    }
  })
}

export function runDuration(spans: readonly AgentSpanRow[], fallback: number): number {
  return Math.max(fallback || 0, ...spans.map((s) => Number(s.endMs) || 0), 1)
}

const EFFECT_LABEL: Record<string, string> = {
  read: 'Read only',
  draft: 'Made a draft',
  write: 'Changed the site',
  irreversible: 'Can’t be undone',
}
export function effectLabel(e: SpanEffect | null | undefined): string {
  return e ? (EFFECT_LABEL[e] ?? e) : ''
}
export function effectTone(e: SpanEffect | null | undefined): 'neutral' | 'warn' | 'strong' {
  return e === 'irreversible' ? 'strong' : e === 'write' ? 'warn' : 'neutral'
}

/** Redacted input as readable text (it is already redacted by the server; this only formats it). */
export function formatInput(input: unknown): string {
  if (input == null || input === '') return ''
  if (typeof input === 'string') return input
  try {
    return JSON.stringify(input, null, 2)
  } catch {
    return String(input)
  }
}

/** Where a change set is reviewed: the API's own link when it is an admin path, else the Review redirect. */
export function reviewHref(cs: { id: string; href?: string | null }): string {
  if (cs.href && /^\/admin\/[^/]/.test(cs.href) && !cs.href.startsWith('//')) return cs.href
  return `/admin/review?set=${encodeURIComponent(cs.id)}`
}

