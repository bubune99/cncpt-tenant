/**
 * This site's block library (lib/ade/blocks/library): its starting layouts
 * (the editor's SECTIONS), the styles Ideas are drawn with, and the shelf
 * categories. Saved blocks come from the database (block-library-server).
 * BYB passes its own (product grids, promo strips, size guides).
 */

import { SECTIONS, SITE_STYLES } from '../block-editor/sections'
import type { IdeaTheme, LibraryBlock } from '../ade/blocks/library'

export const IDEA_THEME: IdeaTheme = {
  heading: SITE_STYLES.heading,
  body: 'text-lg text-[#36454f]',
  button: SITE_STYLES.button,
  buttonAlt: SITE_STYLES.buttonDark,
  dark: 'bg-[#022b39] text-white',
  light: 'bg-white',
  wrap: SITE_STYLES.wrap,
}

/** What each starting layout is for (the category the agent and the filter chips use). */
const SECTION_CATEGORY: Readonly<Record<string, string>> = {
  hero: 'hero',
  'photo-text': 'story',
  'initiative-cards': 'initiatives',
  'donate-band': 'call to action',
  gallery: 'photos',
  quote: 'quote',
  faq: 'questions',
  'contact-form': 'form',
  newsletter: 'signup',
  stats: 'numbers',
  cta: 'call to action',
  video: 'video',
}

/** Filter chips on the Saved shelf (category values; "All" is implicit). */
export const SAVED_CATEGORIES: ReadonlyArray<{ value: string; label: string }> = [
  { value: 'call to action', label: 'Calls to action' },
  { value: 'hero', label: 'Heroes' },
  { value: 'signup', label: 'Sign-ups' },
  { value: 'numbers', label: 'Numbers' },
  { value: 'other', label: 'Other' },
]

/** The starting layouts as library blocks (a fresh tree each call). */
export function sectionsCatalog(): LibraryBlock[] {
  return SECTIONS.map((s) => ({ id: s.id, shelf: 'sections' as const, name: s.name, category: SECTION_CATEGORY[s.id] ?? 'section', summary: s.description, tree: s.build() }))
}

/** The Ideas shelf's line naming who suggests them (the assistant's name is an app value). */
export const IDEA_SUGGESTIONS_LABEL = 'Kofi’s suggestions'
