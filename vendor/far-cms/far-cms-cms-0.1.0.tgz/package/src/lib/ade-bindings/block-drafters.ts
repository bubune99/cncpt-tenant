/**
 * Drafting with the block library (lib/ade/blocks/library, R23). Every call is a
 * draft change like any other edit; nothing is applied until approved.
 *   add_block   place a saved block (linked or copy), a starting layout or an
 *               idea on a page — its words and pictures change on the INSTANCE
 *   save_block  keep a section of a page as a saved block (a SECTION Partial),
 *               or — only when asked, managers only — update a saved block's
 *               definition everywhere, naming the pages it changes
 */

import { prisma } from '../db'
import type { ChangeSetItemRecord, Drafter, ProposedChange, TargetAdapter } from '../ade'
import { resolvePage } from '../ai/tools/block-tools'
import { findBlock, type PageContent } from '../ai/tools/block-ops'
import { generateId } from '../block-editor/tree-utils'
import type { Block } from '../block-editor/types'
import { LIBRARY_COPY, cleanOverrides, ideaById, insertTreeAt, instanceOf, savedContent, type BlockMode, type LibraryBlock } from '../ade/blocks/library'
import { writePartial } from '../partials/write'
import { prepareContentForWrite } from '../block-editor/content-safety'
import { revalidateStorefront } from '../revalidate'
import { IDEA_THEME, sectionsCatalog } from './block-library'
import { savedCatalog } from './block-library-server'

const str = (v: unknown, max = 300) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : undefined)

/** A library item by id: an idea id, a starting layout, else a saved block. */
async function libraryItem(id: string): Promise<LibraryBlock | null> {
  if (id.startsWith('idea:')) return ideaById(id, IDEA_THEME, generateId)
  const section = sectionsCatalog().find((s) => s.id === id)
  if (section) return section
  return (await savedCatalog()).find((s) => s.id === id) ?? null
}

async function addBlockTarget(input: Record<string, unknown>) {
  const ref = str(input.page)
  if (!ref) return { error: 'A page id or slug is required' }
  const page = await resolvePage(ref)
  return page ? { targetType: 'page-content', targetId: page.id } : { error: `Page not found: ${ref}` }
}

async function draftAddBlock(input: Record<string, unknown>, pending: ChangeSetItemRecord | null): Promise<ProposedChange | { error: string }> {
  const page = await resolvePage(str(input.page) ?? '')
  if (!page) return { error: 'Page not found' }
  const id = str(input.blockId, 120) ?? str(input.ideaId, 120)
  if (!id) return { error: 'blockId (from find_blocks) or ideaId (from suggest_layouts) is required' }
  const item = await libraryItem(id)
  if (!item) return { error: `No block ${id} in the library — call find_blocks or suggest_layouts first` }
  const mode: BlockMode = item.shelf !== 'saved' ? 'copy' : input.mode === 'copy' ? 'copy' : input.mode === 'linked' ? 'linked' : item.mode ?? 'linked'
  const block = instanceOf(item, mode, cleanOverrides(input.overrides), generateId)
  const before = pending ? pending.before : { content: page.content ?? null }
  const base = pending ? (pending.after as { content: unknown }).content : page.content
  const pos = (input.position && typeof input.position === 'object' ? input.position : {}) as { after?: unknown; at?: unknown }
  const placed = insertTreeAt(base, block, { after: str(pos.after, 120), at: typeof pos.at === 'number' ? pos.at : undefined })
  if ('error' in placed) return { error: placed.error }
  const priorOps = Array.isArray(pending?.input.ops) ? (pending!.input.ops as unknown[]) : []
  // Which library blocks this draft adds, with their shelf — To-do's sentence names it (describeChangeSet, P4).
  const priorLibrary = Array.isArray(pending?.input.library) ? (pending!.input.library as unknown[]) : []
  return {
    targetType: 'page-content',
    targetId: page.id,
    operation: 'update',
    category: 'pages',
    before,
    after: { content: placed.content },
    // replaceContent replays in the proposed view (lib/ade-bindings/proposed).
    input: { page: page.id, ops: [...priorOps, { tool: 'replaceContent', content: placed.content }], library: [...priorLibrary, { name: item.name, shelf: item.shelf, mode }] },
    blockIds: [...new Set([...(pending?.blockIds ?? []), block.id])],
    // Names the shelf (Saved / Sections / Ideas) and linked or copy — the model's reply repeats it.
    summary: LIBRARY_COPY.addSummary(item.name, item.shelf, mode, page.title),
  }
}

/** Pages that use a saved block linked (titles), for "this changes N pages". */
async function pagesUsing(partialId: string): Promise<string[]> {
  const pages = await prisma.page.findMany({ select: { title: true, content: true }, take: 1000 })
  type Node = { partialId?: string; children?: Node[] }
  const uses = (b: Node): boolean => b.partialId === partialId || (b.children ?? []).some(uses)
  return pages.filter((p) => ((((p.content ?? {}) as PageContent).blocks ?? []) as Node[]).some(uses)).map((p) => p.title)
}

async function saveBlockTarget(input: Record<string, unknown>) {
  const updates = str(input.updates, 120)
  if (updates) {
    const p = await prisma.partial.findUnique({ where: { id: updates }, select: { id: true } })
    return p ? { targetType: 'saved-block', targetId: p.id } : { error: 'No such saved block' }
  }
  return null // a create
}

async function draftSaveBlock(input: Record<string, unknown>): Promise<ProposedChange | { error: string }> {
  const page = await resolvePage(str(input.page) ?? '')
  if (!page) return { error: 'Page not found' }
  const fromId = str(input.fromBlockId, 120)
  const found = fromId ? findBlock(((page.content ?? {}) as PageContent).blocks, fromId)?.block : null
  if (!found) return { error: `No block ${fromId} on “${page.title}”` }
  const name = str(input.name, 80)
  if (!name) return { error: 'A name for the saved block is required' }
  const mode: BlockMode = input.mode === 'copy' ? 'copy' : 'linked'
  const category = str(input.category, 40) ?? 'other'
  const content = savedContent(found as Block, { mode, category })
  const updates = str(input.updates, 120)
  if (updates) {
    // Changing a saved block's definition: every page using it linked changes — say which.
    const existing = await prisma.partial.findUnique({ where: { id: updates }, select: { name: true, content: true } })
    if (!existing) return { error: 'No such saved block' }
    const used = await pagesUsing(updates)
    return {
      targetType: 'saved-block',
      targetId: updates,
      operation: 'update',
      category: 'pages',
      before: { content: existing.content },
      after: { content },
      input: { updates, name, pagesAffected: used },
      blockIds: [found.id ?? fromId!],
      summary: `Update the saved “${existing.name}” everywhere — changes ${used.length} ${used.length === 1 ? 'page' : 'pages'}${used.length ? `: ${used.slice(0, 5).join(', ')}${used.length > 5 ? '…' : ''}` : ''}`,
    }
  }
  return {
    targetType: 'saved-block',
    targetId: null,
    operation: 'create',
    category: 'pages',
    before: null,
    after: { content },
    input: { partialId: generateId(), name, content, description: str(input.description, 200) ?? null },
    blockIds: [found.id ?? fromId!],
    summary: `Save “${name}” as a reusable ${category === 'other' ? 'block' : category} (${mode})`,
  }
}

export const BLOCK_DRAFTERS: Readonly<Record<string, Drafter>> = {
  add_block: { target: addBlockTarget, draft: draftAddBlock },
  save_block: { target: saveBlockTarget, draft: draftSaveBlock },
}

const slugFor = (name: string, id: string) => `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'block'}-${id.slice(-6).toLowerCase()}`

/** Saved blocks are SECTION Partials: a create makes one; an update rewrites its content (a revision is kept). */
export const savedBlockAdapter: TargetAdapter = {
  async snapshot(id) {
    const p = await prisma.partial.findUnique({ where: { id }, select: { content: true } })
    return p ? { content: p.content ?? null } : null
  },
  async apply(item, actor) {
    if (item.operation === 'create') {
      const id = String(item.input.partialId)
      const name = String(item.input.name)
      // Stored content is sanitized on the way in, as the partials API does (lib/block-editor/content-safety).
      const safe = prepareContentForWrite(item.input.content)
      if (!safe.ok) throw new Error(safe.error)
      // content-safe: content from prepareContentForWrite (safe.content)
      await prisma.partial.create({
        data: { id, name, slug: slugFor(name, id), category: 'SECTION', status: 'PUBLISHED', description: (item.input.description as string | null) ?? null, content: safe.content as object },
        select: { id: true },
      })
      return { resultId: id }
    }
    const id = item.targetId!
    const safe = prepareContentForWrite((item.after as { content: object }).content)
    if (!safe.ok) throw new Error(safe.error)
    const { revision } = await writePartial({ id }, { content: safe.content as object }, { actor: { kind: 'agent', userId: actor.id }, changeSetId: item.changeSetId, reason: 'ai-edit' })
    revalidateStorefront()
    return { resultId: id, revisionId: revision?.revisionId ?? null, version: revision?.version ?? null }
  },
}
