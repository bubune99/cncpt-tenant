/**
 * Dzidzor ↔ ADE bindings: the Prisma store, page/blog drafters + adapters,
 * the code-exec gate backed by the `ade` settings group, and the drafting
 * hook the governed tool wrappers (chat + MCP) call.
 */

import { agentRefusal, createChangeSetService, type ChangeMode, type ChangeSource } from '../ade'
import { agentLockCheck } from './locks'
import { draftedResult } from './drafted-result'
import { getAdeSettings } from '../settings'
import { prismaChangeSetStore } from './store'
import { prisma } from '../db'
import { ADAPTERS as TARGET_ADAPTERS, DRAFTERS } from './targets'
import { withChangeApply } from './history'
import type { TargetAdapter } from '../ade'

/** Every apply runs as the agent's change, so the versions it records say so (lib/ade-bindings/history). */
const ADAPTERS: Readonly<Record<string, TargetAdapter>> = Object.fromEntries(
  Object.entries(TARGET_ADAPTERS).map(([type, a]) => [
    type,
    { ...a, apply: async (item, actor) => withChangeApply(item, actor, () => a.apply(item, actor), await draftAuthor(item.changeSetId)) } satisfies TargetAdapter,
  ])
)

/** A draft a person made in an editor (source 'admin') is theirs; the assistant's drafts stay the assistant's. */
async function draftAuthor(changeSetId: string): Promise<{ userId: string | null } | null> {
  if (changeSetId === 'direct') return null
  const cs = await prisma.adeChangeSet.findUnique({ where: { id: changeSetId }, select: { source: true, ownerId: true } })
  return cs?.source === 'admin' ? { userId: cs.ownerId } : null
}

export const changeSets = createChangeSetService({
  store: prismaChangeSetStore,
  drafters: DRAFTERS,
  adapters: ADAPTERS,
})

export { codeExecGate, CodeExecutionDisabledError } from './code-exec'

/** What the governed tool wrappers need to hold agent edits as drafts. */
export interface DraftingHook {
  mode: ChangeMode
  canDraft(toolName: string): boolean
  /** Refusal text when someone else is editing the tool's target, else null (direct mode checks this too). */
  checkLock(toolName: string, input: Record<string, unknown>): Promise<string | null>
  propose(toolName: string, input: Record<string, unknown>, opts?: { why?: string }): Promise<Record<string, unknown>>
}

/** Build the drafting hook for one request (chat turn or MCP call). */
export async function draftingHookFor(ownerId: string | null, source: ChangeSource): Promise<DraftingHook> {
  const settings = await getAdeSettings().catch(() => null)
  // Settings unreadable → stay in draft mode (the safe side).
  const mode: ChangeMode = settings?.changeMode ?? 'draft'
  // The assistant acts for its user: it shares their edit claim and must not
  // touch a page or record someone else is editing.
  const checkLock = async (toolName: string, input: Record<string, unknown>): Promise<string | null> => {
    const drafter = DRAFTERS[toolName]
    if (!drafter) return null
    const target = await drafter.target(input).catch(() => null)
    if (!target || 'error' in target) return null
    const r = await agentLockCheck(target.targetType, target.targetId ?? null, ownerId)
    return r.ok ? null : agentRefusal(r.holder)
  }
  return {
    mode,
    canDraft: (name) => changeSets.canDraft(name),
    checkLock,
    async propose(toolName, input, opts) {
      const refusal = await checkLock(toolName, input)
      if (refusal) return { success: false, error: refusal, locked: true }
      const r = await changeSets.propose({ ownerId, source, toolName, input, why: opts?.why })
      if (!r.ok) return { success: false, error: r.error }
      return draftedResult(toolName, input, r)
    },
  }
}

/**
 * Direct mode (no review queue): draft the change(s) exactly as draft mode
 * would, then apply them in order through the same adapters. One code path
 * for both modes, so direct and reviewed changes can't drift apart.
 */
export async function applyDirect(
  toolName: string,
  input: Record<string, unknown>,
  /** The person pressing Publish (editor routes); omitted inside a chat run. */
  by: { id: string | null; email: string | null } = { id: null, email: null }
): Promise<Record<string, unknown>> {
  const drafter = DRAFTERS[toolName]
  if (!drafter) return { success: false, error: `'${toolName}' has no drafter` }
  const drafted = await drafter.draft(input, null)
  if ('error' in drafted) return { success: false, error: drafted.error }
  const drafts = 'bundle' in drafted ? drafted.bundle : [drafted]
  const results: Array<{ targetType: string; resultId?: string }> = []
  // The revision each apply recorded: the chat's change widgets are built from these.
  const changes: Array<{ kind: 'revision'; revisionId: string; entityType: string; entityId: string; version?: number }> = []
  for (const change of drafts) {
    const adapter = ADAPTERS[change.targetType]
    if (!adapter) return { success: false, error: `No adapter for ${change.targetType}`, applied: results, ...(changes.length ? { changes } : {}) }
    const { resultId, revisionId, version } = await adapter.apply(
      {
        id: 'direct',
        changeSetId: 'direct',
        targetType: change.targetType,
        targetId: change.targetId,
        operation: change.operation,
        category: change.category,
        toolName,
        input: change.input,
        before: change.before,
        after: change.after,
        blockIds: change.blockIds,
        rationale: change.summary,
        status: 'pending',
        error: null,
        resultId: null,
      },
      by
    )
    results.push({ targetType: change.targetType, resultId })
    const entityId = resultId ?? change.targetId
    // Pages number their versions when read, so a page change has no version here.
    if (revisionId && entityId) changes.push({ kind: 'revision', revisionId, entityType: change.targetType, entityId, ...(version ? { version } : {}) })
  }
  return { success: true, applied: results, ...(changes.length ? { changes } : {}), message: drafts.map((c) => c.summary).join('; ') }
}
