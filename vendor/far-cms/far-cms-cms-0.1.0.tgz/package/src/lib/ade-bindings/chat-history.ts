/**
 * The chat history list's calls, for this app (Dzidzor: /api/chat). The
 * component (components/admin-chat/conversation-history) is identical
 * across apps; only this file differs.
 */

export interface ConversationItem {
  id: string
  title: string
  contextType: string
  updatedAt: string
  lastMessage: string
  pinned?: boolean
}

export const CHAT_HISTORY_LIST_KEY = '/api/chat'

type Result = { ok: true; title?: string } | { ok: false; error: string }

async function call(url: string, init: RequestInit, fallback: string): Promise<Result> {
  try {
    const res = await fetch(url, init)
    const body = (await res.json().catch(() => null)) as { title?: string; message?: string; error?: string } | null
    if (!res.ok) return { ok: false, error: body?.message || body?.error || fallback }
    return { ok: true, ...(body?.title ? { title: body.title } : {}) }
  } catch {
    return { ok: false, error: fallback }
  }
}

const json = (body: unknown): RequestInit => ({ method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })

export const chatHistoryApi = {
  rename: (id: string, title: string) => call('/api/chat', json({ id, title }), 'Couldn’t rename it'),
  setPinned: (id: string, pinned: boolean) => call('/api/chat', json({ id, pinned }), pinned ? 'Couldn’t pin it' : 'Couldn’t unpin it'),
  remove: (id: string) => call(`/api/chat?id=${encodeURIComponent(id)}`, { method: 'DELETE' }, 'Couldn’t delete it'),
}
