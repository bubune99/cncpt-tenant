/**
 * Shared bits of the /api/connectors routes: provider from the path, and
 * provider errors → plain answers (never the provider's own text, which can
 * quote addresses).
 */

import { NextResponse } from 'next/server'
import { ConnectorError, isConnectorProvider, isSameSiteRequest, type ConnectorProvider } from '../ade/connectors'
import type { NextRequest } from 'next/server'

export function providerParam(v: unknown): ConnectorProvider | null {
  return isConnectorProvider(v) ? v : null
}

export function connectorErrorResponse(e: unknown, where: string): NextResponse {
  if (e instanceof ConnectorError) {
    if (e.kind === 'not-found' && e.message === 'Not connected') return NextResponse.json({ success: false, error: 'not-connected' }, { status: 404 })
    if (e.kind === 'reconnect') return NextResponse.json({ success: false, error: 'reconnect' }, { status: 409 })
    if (e.kind === 'not-found') return NextResponse.json({ success: false, error: 'Not found in your mailbox' }, { status: 404 })
    if (e.kind === 'rate-limited') return NextResponse.json({ success: false, error: e.message }, { status: 429 })
  }
  console.error(`[connectors] ${where} failed:`, e instanceof ConnectorError ? `${e.kind} ${e.status ?? ''}` : e instanceof Error ? e.name : 'error')
  return NextResponse.json({ success: false, error: 'Your mailbox didn’t answer. Try again.' }, { status: 502 })
}

/** Addresses from a request body: strings only, at most 50. */
export function addressList(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string').slice(0, 50) : []
}

/** 403 for a state-changing call that didn't come from our own pages (CSRF), else null. */
export function crossSiteRefusal(request: NextRequest): NextResponse | null {
  const ok = isSameSiteRequest({ secFetchSite: request.headers.get('sec-fetch-site'), origin: request.headers.get('origin') }, request.nextUrl.origin)
  return ok ? null : NextResponse.json({ success: false, error: 'cross_site' }, { status: 403 })
}
