/** The drafting hook's result shape (lib/ade-bindings/index propose). Pure. */

/**
 * What a drafting tool returns to the model and the chat. A bundle (one tool
 * call drafting several items, e.g. a record AND its page) lists EVERY item id:
 * the chat card's Approve / Reject act on exactly these, so a bundle can never be
 * half-rejected into a "partial" set whose rest has no card. Pure; asserted.
 */
export function draftedResult(
  toolName: string,
  input: Record<string, unknown>,
  r: { changeSetId: string; itemId: string; itemIds?: string[]; change: { summary: string; input: Record<string, unknown> } },
): Record<string, unknown> {
  const ops = Array.isArray(r.change.input.ops) ? (r.change.input.ops as Array<{ newBlockId?: string }>) : []
  const inserted = ops[ops.length - 1]?.newBlockId
  const itemIds = [...new Set([r.itemId, ...(r.itemIds ?? [])])]
  return {
    success: true,
    drafted: true,
    changeSetId: r.changeSetId,
    itemId: r.itemId,
    itemIds,
    ...(toolName === 'insertBlock' && inserted ? { blockId: inserted } : {}),
    ...(toolName === 'updateBlock' ? { blockId: input.blockId } : {}),
    reviewUrl: `/admin/todo?view=all&item=${r.changeSetId}`,
    message:
      `Drafted for review — NOT live yet: ${r.change.summary}. ` +
      'A person approves it in Admin → To-do before it is applied. ' +
      'Further edits to the same page or post fold into this draft (block ids from it can be used in the next call).',
  }
}
