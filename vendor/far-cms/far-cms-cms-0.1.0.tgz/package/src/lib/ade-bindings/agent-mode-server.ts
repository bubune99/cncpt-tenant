/**
 * The assistant's mode for one person, resolved on the server (lib/ai/governance/agent-modes).
 * Used by the chat route on EVERY request and by the preferences route that feeds the composer's switch,
 * so what the switch offers and what the route enforces come from the same call. The client's pick is
 * only ever an input here.
 */

import { getAdeSettings } from '../settings'
import { DEFAULT_AGENT_MODE_SETTINGS, resolveMode, type AgentModeSettings, type ResolvedMode } from '../ai/governance/agent-modes'
import { getAgentModePref } from './queries'

export interface AgentModeResolution {
  settings: AgentModeSettings
  resolved: ResolvedMode
}

export async function resolveAgentModeFor(userId: string, roles: readonly string[], requested?: unknown): Promise<AgentModeResolution> {
  // Settings that cannot be read are NOT the old behaviour: they are the safe defaults, switched on (Accept changes).
  const settings = await getAdeSettings().then((s) => s.agentModes).catch(() => ({ ...DEFAULT_AGENT_MODE_SETTINGS, enabled: true }))
  const saved = await getAgentModePref(userId).catch(() => null)
  return { settings, resolved: resolveMode({ settings, roles, requested, saved }) }
}
