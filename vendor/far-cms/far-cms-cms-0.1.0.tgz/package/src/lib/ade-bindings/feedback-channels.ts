/**
 * Dzidzor's client-feedback forwarding (core: lib/ade/feedback/forward):
 * the owner's AI Project Planner (a todo in the Dzidzor project) and email
 * to FEEDBACK_NOTIFY_EMAIL through the send guard. The feedback row is
 * stored by the feedback API first; this forwards it, records each
 * channel's delivery, and a queued message at each retry time
 * (api/queues/scheduled) retries; the daily sweep (api/cron/scheduled-sweep)
 * is the backstop and sends the digest.
 *
 * Env (all optional — without them the To-do shows "Not set up yet"):
 *   PLANNER_API_URL, PLANNER_API_KEY, PLANNER_FEEDBACK_PROJECT_ID
 *   FEEDBACK_NOTIFY_EMAIL
 */

import 'server-only'
import type { ClientFeedback } from '@prisma/client'
import { prisma } from '../db'
import { FEEDBACK_KIND_LABEL } from '../ade/feedback/feedback'
import { sendEmail } from '../email'
import { renderEmailTemplateBySlug } from '../email/templates/render'
import { getAdeSettings } from '../settings'
import { armScheduled } from '../queues/scheduled-queue'
import {
  DeliveryRefused,
  deliveryLabel,
  digestDue,
  displayNameOnly,
  formatDigest,
  forwardFeedback as coreForward,
  retryDelivery,
  type DeliveryLabel,
  type DeliveryRow,
  type DeliveryState,
  type DeliveryStore,
  type FeedbackChannel,
  type FeedbackChannelName,
  type FeedbackItem,
  type ForwardDeps,
  type ForwardMessage,
} from '../ade/feedback/forward'
import { plannerChannel, plannerConfigFrom } from '../ade/feedback/planner'

export const FEEDBACK_TEMPLATE_SLUG = 'client-feedback'

const escapeHtml = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] as string)
const adminUrl = () => (process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000').replace(/\/+$/, '')

/** The owner's address, or null when unset / not one address. */
export function feedbackNotifyEmail(env: Record<string, string | undefined> = process.env): string | null {
  const v = env.FEEDBACK_NOTIFY_EMAIL?.trim() ?? ''
  return /^[^\s@,;<>]+@[^\s@,;<>]+\.[a-z]{2,}$/i.test(v) ? v : null
}

// ── Store (feedback_deliveries) ────────────────────────────────────────────

const toRow = (r: { feedbackId: string; channel: string; status: string; attempts: number; nextAttemptAt: Date; lockedUntil: Date | null; externalId: string | null; lastError: string | null }): DeliveryRow => ({
  ...r,
  channel: r.channel as FeedbackChannelName,
  status: r.status as DeliveryRow['status'],
})

export const deliveryStore: DeliveryStore = {
  async ensure(feedbackId, channel, now) {
    const r = await prisma.feedbackDelivery.upsert({
      where: { feedbackId_channel: { feedbackId, channel } },
      create: { feedbackId, channel, nextAttemptAt: now },
      update: {},
    })
    return toRow(r)
  },
  async claim(feedbackId, channel, now, lockMs) {
    // One conditional UPDATE: only one caller can move the row to 'sending'.
    const { count } = await prisma.feedbackDelivery.updateMany({
      where: {
        feedbackId,
        channel,
        OR: [
          { status: { in: ['pending', 'not-set-up'] }, nextAttemptAt: { lte: now } },
          { status: 'sending', lockedUntil: { lte: now } },
        ],
      },
      data: { status: 'sending', lockedUntil: new Date(now.getTime() + lockMs) },
    })
    if (count !== 1) return null
    const r = await prisma.feedbackDelivery.findUnique({ where: { feedbackId_channel: { feedbackId, channel } } })
    return r ? toRow(r) : null
  },
  async update(feedbackId, channel, patch) {
    await prisma.feedbackDelivery.update({ where: { feedbackId_channel: { feedbackId, channel } }, data: patch })
  },
  async setFeedbackStatus(feedbackId, status) {
    // new → sent only, with forwardedAt: a row the owner already triaged keeps its status.
    await prisma.clientFeedback.updateMany({ where: { id: feedbackId, status: 'new' }, data: { status, forwardedAt: new Date() } })
  },
}

// ── The feedback rows (owned by the client-feedback feature) ──────────────

/** Exactly the columns forwarding needs — no email field is ever read. */
const FEEDBACK_SELECT = { id: true, kind: true, screen: true, route: true, unitRef: true, note: true, senderName: true, createdAt: true, screenshotMediaId: true } as const
type FeedbackRow = Pick<ClientFeedback, keyof typeof FEEDBACK_SELECT>

const kindLabel = (k: string) => (FEEDBACK_KIND_LABEL as Record<string, string>)[k] ?? 'Feedback'

const itemOf = (r: FeedbackRow): FeedbackItem => ({
  id: r.id,
  kind: kindLabel(r.kind),
  screen: r.screen,
  route: r.route,
  unitRef: r.unitRef,
  note: r.note,
  // The stored display name; one that looks like an address is never forwarded.
  senderName: displayNameOnly(r.senderName),
  createdAt: r.createdAt,
  // The column keeps its first name; it holds a private FeedbackScreenshot id (never a public Media file).
  screenshotId: r.screenshotMediaId,
})

async function loadItem(id: string): Promise<FeedbackItem | null> {
  if (typeof id !== 'string' || !id || id.length > 64) return null
  const r = await prisma.clientFeedback.findUnique({ where: { id }, select: FEEDBACK_SELECT })
  return r ? itemOf(r) : null
}

// ── Channels ──────────────────────────────────────────────────────────────

/**
 * One email through the send guard (transactional; outside production only
 * the test allow-list). The recipient is ALWAYS the owner's
 * FEEDBACK_NOTIFY_EMAIL, read here — never an address from the feedback.
 */
async function sendFeedbackEmail(message: ForwardMessage): Promise<{ externalId: string | null }> {
  const to = feedbackNotifyEmail()
  if (!to) throw new Error('FEEDBACK_NOTIFY_EMAIL is not set')
  let subject = message.title
  let html = `<h2>${escapeHtml(message.title)}</h2>\n${message.html}`
  // The system template "client-feedback" (editable in Email › Templates) wraps the pre-escaped body.
  const rendered = await renderEmailTemplateBySlug(FEEDBACK_TEMPLATE_SLUG, { feedback: { title: message.title, titleHtml: escapeHtml(message.title), bodyHtml: message.html, ref: message.ref } }).catch(() => null)
  if (rendered?.html) {
    html = rendered.html
    if (rendered.subject) subject = rendered.subject.replace(/[\r\n]+/g, ' ').slice(0, 200)
  }
  const r = await sendEmail({ to: { email: to }, subject, html, text: message.text, category: 'transactional', tags: ['client-feedback'], metadata: { ref: message.ref } })
  if (r.success) return { externalId: r.messageId ?? null }
  if (r.errorCode === 'GUARD_DROPPED') throw new DeliveryRefused('Held: on this test site, email only goes to the test allow-list (EMAIL_TEST_ALLOWLIST).')
  throw new Error(`Email not sent (${r.errorCode ?? 'provider error'})`)
}

function emailChannel(): FeedbackChannel {
  return {
    name: 'email',
    configured: () => feedbackNotifyEmail() !== null,
    atMostOnce: true,
    send: (m) => sendFeedbackEmail(m),
  }
}

const channels = (): FeedbackChannel[] => [plannerChannel(() => plannerConfigFrom(process.env)), emailChannel()]

const deps = (): ForwardDeps => ({ load: loadItem, store: deliveryStore, channels: channels(), now: () => new Date(), adminUrl: adminUrl() })

// ── API for the feedback feature ──────────────────────────────────────────

/**
 * Forward one stored feedback item (call after its row is committed).
 * Never throws; calling it again never sends twice.
 */
export async function forwardFeedback(id: string): Promise<Partial<Record<FeedbackChannelName, DeliveryState>>> {
  try {
    return await coreForward(deps(), id)
  } catch (e) {
    console.error('[feedback] forward failed:', e instanceof Error ? e.name : 'error')
    return {}
  } finally {
    await armNextRetry(id)
  }
}

/** A channel left waiting for a retry: one queued message at its retry time (no polling). Never throws. */
async function armNextRetry(id: string): Promise<void> {
  try {
    const [pending, sending] = await Promise.all([
      prisma.feedbackDelivery.aggregate({ where: { feedbackId: id, status: 'pending' }, _min: { nextAttemptAt: true } }),
      prisma.feedbackDelivery.aggregate({ where: { feedbackId: id, status: 'sending' }, _min: { lockedUntil: true } }),
    ])
    const times = [pending._min.nextAttemptAt, sending._min.lockedUntil].filter((t): t is Date => !!t)
    if (times.length) await armScheduled('feedback', id, new Date(Math.min(...times.map((t) => t.getTime()))))
  } catch (e) {
    console.warn('[feedback] retry not queued (the daily sweep retries):', e instanceof Error ? e.name : 'error')
  }
}

/** The To-do label per item: Sent / Sending / Feedback not delivered / Not set up yet. */
export async function feedbackDeliveryStatus(ids: readonly string[]): Promise<Record<string, { label: DeliveryLabel; detail?: string }>> {
  const list = [...new Set(ids)].filter((x) => typeof x === 'string' && x.length <= 64).slice(0, 500)
  if (!list.length) return {}
  const rows = await prisma.feedbackDelivery.findMany({ where: { feedbackId: { in: list } }, select: { feedbackId: true, channel: true, status: true, lastError: true } })
  const out: Record<string, { label: DeliveryLabel; detail?: string }> = {}
  for (const id of list) {
    const mine = rows.filter((r) => r.feedbackId === id).map((r) => ({ channel: r.channel as FeedbackChannelName, status: r.status as DeliveryRow['status'], lastError: r.lastError }))
    // No rows yet: stored, forwarding not started (the daily sweep picks it up).
    out[id] = mine.length ? deliveryLabel(mine) : { label: 'Sending' }
  }
  return out
}

/** Owner's "Try again" on an item whose delivery failed. */
export async function retryFeedbackDelivery(id: string): Promise<Partial<Record<FeedbackChannelName, DeliveryState>>> {
  const now = new Date()
  const failed = await prisma.feedbackDelivery.findMany({ where: { feedbackId: id, status: 'failed' }, select: { channel: true } })
  for (const r of failed) await retryDelivery(deliveryStore, id, r.channel as FeedbackChannelName, now)
  return forwardFeedback(id)
}

// ── Daily sweep: missed retries, late starts, the daily digest ───────────

/**
 * Called by the daily sweep (api/cron/scheduled-sweep). Retries due deliveries, starts any stored
 * feedback that never got forwarded (the request ended first), re-tries
 * "not set up" ones once their channel is configured, and sends the daily
 * digest when the setting is on.
 */
export async function runFeedbackForwarder(opts: { budgetMs: number }): Promise<{ forwarded: number; digest: string | null }> {
  const started = Date.now()
  const now = new Date()
  const ready = channels().filter((c) => c.configured()).map((c) => c.name)
  const due = await prisma.feedbackDelivery.findMany({
    where: {
      OR: [
        { status: 'pending', nextAttemptAt: { lte: now } },
        { status: 'sending', lockedUntil: { lte: now } },
        ...(ready.length ? [{ status: 'not-set-up', channel: { in: ready } }] : []),
      ],
    },
    select: { feedbackId: true },
    take: 200,
  })
  const unstarted = await prisma.clientFeedback.findMany({ where: { status: 'new', createdAt: { lte: new Date(now.getTime() - 60_000) } }, orderBy: { createdAt: 'asc' }, take: 200, select: { id: true } })
  const known = new Set((await prisma.feedbackDelivery.findMany({ where: { feedbackId: { in: unstarted.map((u) => u.id) } }, select: { feedbackId: true } })).map((r) => r.feedbackId))
  const ids = [...new Set([...due.map((d) => d.feedbackId), ...unstarted.map((u) => u.id).filter((id) => !known.has(id))])]
  let forwarded = 0
  for (const id of ids) {
    if (Date.now() - started > opts.budgetMs) break
    await forwardFeedback(id)
    forwarded++
  }
  return { forwarded, digest: await sendDigestIfDue(now).catch(() => null) }
}

async function sendDigestIfDue(now: Date): Promise<string | null> {
  if (!feedbackNotifyEmail() || !(await getAdeSettings()).feedbackDigest) return null
  const last = await prisma.feedbackDigest.findFirst({ orderBy: { day: 'desc' }, select: { day: true } })
  const day = digestDue(now, last?.day ?? null)
  if (!day) return null
  const from = new Date(`${day}T00:00:00.000Z`)
  const items = await prisma.clientFeedback.findMany({ where: { createdAt: { gte: from, lt: new Date(from.getTime() + 86_400_000) } }, orderBy: { createdAt: 'asc' }, take: 100, select: FEEDBACK_SELECT })
  // Claim the day first (its id is unique): two cron runs never both send it.
  try {
    await prisma.feedbackDigest.create({ data: { day, count: items.length } })
  } catch {
    return null
  }
  const message = formatDigest(items.map(itemOf), day, { adminUrl: adminUrl() })
  if (!message) return day
  try {
    await sendFeedbackEmail(message)
  } catch (e) {
    console.warn('[feedback] digest not sent:', e instanceof Error ? e.message : 'error')
    // A failed send releases the day (a manual sweep run that day retries it); a staging allow-list hold stays claimed.
    if (!(e instanceof DeliveryRefused)) await prisma.feedbackDigest.delete({ where: { day } }).catch(() => {})
    return null
  }
  return day
}
