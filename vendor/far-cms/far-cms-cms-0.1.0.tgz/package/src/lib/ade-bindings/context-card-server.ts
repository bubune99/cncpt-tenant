/**
 * The context card for one chat request (lib/ade/assistant/context-card),
 * with this app's data. Each bundle's data is loaded only when the question
 * needs it — the To-do list on to-do questions, the last run on "what
 * changed", the page on edits — so a plain question costs no extra reads.
 * Read-only.
 */

import { prisma } from '../db'
import type { UserWithPermissions } from '../permissions/types'
import { checkPermission } from '../permissions'
import { ASSISTANT_DEFAULTS } from '../ade/assistant/defaults'
import { buildContextCard, bundlesFor, cardIntents, classifyIntents, type ChangesBundleInput, type ContextCard, type EditBundleInput } from '../ade/assistant/context-card'
import { shellPicture } from '../ade/ui/shell-units'
import { parseScreenContext, screenCardLines } from '../ade/ui/screen-context'
import { coreFrom, shellSnapshotFrom, todoCardInput, uiShellSchema, type UiShell } from './context-card'
import { SHELL_TOP_UNITS } from './shell-units'
import { buildTodo } from './todo'
import { askedSection, askedUnit, onSection, type AskedSection } from '../ade/assistant/pointing'
import { dzidzorPlatformMap } from './platform-map'
import { AGENT_ACTIVITY_PERMISSION } from './agent-activity-access'

export interface CardRequest {
  question: string
  /** The raw uiShell from the request body: checked here; anything malformed is ignored, never fatal. */
  uiShell: unknown
  phone: boolean
  route: string | null
  conversationId: string
  userId: string
  /** Null when they couldn't be loaded: no To-do or edit bundle, role unknown. */
  perms: UserWithPermissions | null
  editing?: { pageId?: string; title?: string; selectedBlockId?: string | null; selectedName?: string | null; unsaved?: boolean } | null
  /** This conversation's drafts and what happened to them ("About page: approved"). */
  draftOutcomes: ReadonlyArray<string>
  budget: { tokensLeft: number; daily: number | null }
  /** The raw uiScreenCtx from the request: checked here (parseScreenContext); malformed → ignored. */
  uiScreenCtx?: unknown
  /** The open plan's line (lib/ade/chat/plan planContextLine), or null. */
  plan?: string | null
  /** Earlier messages from the person in this conversation (newest last). */
  recentQuestions?: ReadonlyArray<string>
  /** The section the question names (askedSectionFor), when it names one. */
  asked?: AskedSection | null
}

/**
 * The menu section a where/go question names, from the person's words (platform
 * map: names + synonyms, with this site's relabels) and the menu the page
 * reported. Other questions, or no menu: null.
 */
export async function askedSectionFor(question: string, uiShellRaw: unknown, perms: UserWithPermissions | null): Promise<AskedSection | null> {
  const intents = classifyIntents(question)
  if (!intents.includes('where') && !intents.includes('go')) return null
  const groups = parseUiShell(uiShellRaw)?.groups ?? []
  if (!groups.length) return null
  try {
    const [{ getNavigationSettings }, { isCommerceEnabled }, { MOBILE_INBOX }] = await Promise.all([import('../settings'), import('../features'), import('./mobile-inbox')])
    const [{ overrides }, commerceEnabled] = await Promise.all([getNavigationSettings(), isCommerceEnabled()])
    const access = perms ? { isOwner: checkPermission(perms, 'plugins.install').allowed, agentActivity: checkPermission(perms, AGENT_ACTIVITY_PERMISSION).allowed } : { isOwner: false }
    return askedSection(question, groups, dzidzorPlatformMap({ commerceEnabled, access, overrides, emailInbox: MOBILE_INBOX.emailSegment }))
  } catch {
    // Without the map, the person's own menu names still resolve.
    return askedSection(question, groups, [])
  }
}

export function parseUiShell(raw: unknown): UiShell | undefined {
  const r = uiShellSchema.safeParse(raw)
  return r.success ? r.data : undefined
}

async function lastRunSteps(conversationId: string, userId: string): Promise<string[]> {
  const run = await prisma.agentRun.findFirst({ where: { conversationId, userId, endedAt: { not: null } }, orderBy: { startedAt: 'desc' }, select: { id: true } })
  if (!run) return []
  const spans = await prisma.agentSpan.findMany({ where: { runId: run.id, kind: 'tool' }, orderBy: { seq: 'asc' }, take: ASSISTANT_DEFAULTS.card.lastRunSteps, select: { label: true, effect: true, status: true } })
  return spans.map((s) => `${s.label}${s.effect ? ` (${s.effect})` : ''}${s.status === 'error' ? ' failed' : ''}`)
}

async function editInput(req: CardRequest): Promise<EditBundleInput | null> {
  const e = req.editing
  if (!e?.pageId || !req.perms) return null
  const page = await prisma.page.findUnique({ where: { id: e.pageId }, select: { title: true, status: true } }).catch(() => null)
  if (!page) return null
  const canPublish = checkPermission(req.perms!, 'pages.publish').allowed
  return {
    target: e.selectedName ? `block ${e.selectedName} on page ${page.title}` : `page ${page.title}`,
    status: `${String(page.status).toLowerCase()}${e.unsaved ? ', unsaved edits open' : ''}`,
    values: [['title', page.title]],
    approver: canPublish ? 'you (you may publish pages)' : 'someone who may publish pages (not you)',
  }
}

/** The screen block, plus — when the question names one of the screen's parts — which one, so the spot rings it (and opens its drawer). */
function screenBlock(question: string, ctx: ReturnType<typeof parseScreenContext>): string | null {
  const base = screenCardLines(ctx)
  const u = askedUnit(question, ctx?.units)
  if (!base || !u) return base
  return `${base}\nThey mean ${u.label}: show_unit("${u.label}")${u.where === 'drawer' ? ` — it is under ${u.tab ?? 'the drawer'}, and that opens it for you` : ''}. Don't press buttons or tabs to get there.`
}

/** The card for this request; a loader that fails leaves its bundle out (named as missing), never the turn. */
export async function contextCardFor(req: CardRequest): Promise<ContextCard> {
  const ui = parseUiShell(req.uiShell)
  const need = new Set(bundlesFor(cardIntents(req.question, req.recentQuestions)))
  const snap = shellSnapshotFrom(ui, req.phone)
  const safe = <T>(p: Promise<T>) => p.catch(() => null)
  const [todo, steps, edit] = await Promise.all([
    need.has('todo') && req.perms ? safe(buildTodo(req.perms, req.userId)) : Promise.resolve(null),
    need.has('changes') ? safe(lastRunSteps(req.conversationId, req.userId)) : Promise.resolve(null),
    need.has('edit') ? safe(editInput(req)) : Promise.resolve(null),
  ])
  const changes: ChangesBundleInput | null = need.has('changes') && (steps || req.draftOutcomes.length) ? { items: req.draftOutcomes, lastRun: steps ?? [] } : null
  return buildContextCard({
    question: req.question,
    core: coreFrom({ ui, phone: req.phone, route: req.route, roles: req.perms?.roles ?? [], editing: req.editing }),
    where: snap && need.has('where') ? shellPicture(snap, SHELL_TOP_UNITS, { maxChars: ASSISTANT_DEFAULTS.card.bundleMaxChars.where }) : null,
    todo: todo ? todoCardInput(todo, Date.now(), ASSISTANT_DEFAULTS.card.todoTopN) : null,
    changes,
    edit,
    budget: req.budget,
    screen: screenBlock(req.question, parseScreenContext(req.uiScreenCtx)),
    plan: req.plan ?? null,
    recentQuestions: req.recentQuestions,
    asked: req.asked ? { name: req.asked.name, href: req.asked.href, here: onSection(req.asked, req.route) } : null,
  })
}
