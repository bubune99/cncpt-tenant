/**
 * Change widgets: stored change references → views for one person, masked.
 * Server only. The view assembly is pure (change-widgets.ts).
 */

import { onlyRemovedTargets } from '../ade/todo/orphan-review'
import { removedTargetItemIds } from './orphans'
import type { UserWithPermissions } from '../permissions/types'
import { prisma } from '../db'
import { maskData } from '../ade/governance/visibility'
import type { ChangeRef, ChangeView } from '../ade/chat/change-widgets'
import { ownerLabel, proposer, type DeckCard } from '../ade/mobile/review-deck'
import { ATTACHMENTS_KIND, parseAttachments } from '../ade/mobile/attachments'
import { phoneFacts } from './mobile/phone-facts'
import { recordChecklist, relaxForPhone } from './record-checklist'
import { formatMoney } from '../ade/records/goal'
import { checkPermission } from '../permissions'
import { canApprove, canViewItem, listReviewSets } from './queries'
import { maskForPerson, privacyAreas, viewerRole } from './visibility'
import { VISIBILITY_FLOOR } from './visibility-rules'
// history-adapters, not history: importing it registers each entity's adapter.
import { getRevision, revisionTarget } from './history-adapters'
import { historyRightsFor } from './history-access'
import { itemsOf, PAGE_TARGETS, pickPageSnapshot, pickRevision, primaryOf, viewFromItems, viewFromRevision, withRevision, type WidgetItem } from './change-widgets'

/**
 * Field values, masked as this person's screens mask them (confidential
 * areas they lack), and never a secret or password (the floor), whoever looks.
 */
async function maskItems(items: WidgetItem[], perms: UserWithPermissions): Promise<WidgetItem[]> {
  const areaIds = (await privacyAreas()).map((a) => a.id)
  const floor = VISIBILITY_FLOOR.filter((r) => r.target.kind === 'field')
  return Promise.all(
    items.map(async (i) => {
      // Masking goes by key, so each change becomes { [field]: value } before and after.
      const side = (pick: 'before' | 'after') => Object.fromEntries(i.fieldChanges.map((c) => [c.field, c[pick]]))
      const masked = await maskForPerson({ before: side('before'), after: side('after') }, perms, areaIds)
      const safe = maskData(masked, floor, viewerRole(perms)).data
      return { ...i, fieldChanges: i.fieldChanges.map((c) => ({ field: c.field, before: safe.before[c.field], after: safe.after[c.field] })) }
    })
  )
}

async function changeSetView(ref: Extract<ChangeRef, { kind: 'changeset' }>, perms: UserWithPermissions): Promise<ChangeView | null> {
  const [set] = await listReviewSets(perms, { setId: ref.changeSetId, scope: 'all' })
  if (!set) return null
  const view = viewFromItems(ref, await maskItems(set.items, perms), set.why)
  if (!view || view.status !== 'applied') return view
  // Approved: the version its apply recorded, for Compare / Restore — read
  // through the History API, so pages (PageRevision) count as well.
  const primary = primaryOf(itemsOf(ref, set.items))
  const id = await appliedRevisionId(ref.changeSetId, primary)
  const target = id ? await revisionTarget(id) : null
  if (!id || !target) return view
  const rights = historyRightsFor(perms, target.entityType, target.entityId)
  if (!rights.read) return view
  const rev = await getRevision(id, perms)
  return rev ? withRevision(view, { id: rev.id, version: rev.version }, rights.restore) : view
}

/**
 * The version an approved item's apply recorded: the item's own revisionId
 * (kept since 20261011400000_change_set_item_revision_id). Rows applied
 * before it: ade_revisions by change set, else (pages) the snapshot its apply
 * took, matched by approver and time.
 */
async function appliedRevisionId(changeSetId: string, primary: { id: string; targetType: string; targetId: string | null }): Promise<string | null> {
  const item = await prisma.adeChangeSetItem.findUnique({ where: { id: primary.id }, select: { revisionId: true, decidedAt: true, decidedById: true } })
  if (item?.revisionId) return item.revisionId
  const revs = await prisma.adeRevision.findMany({ where: { changeSetId }, select: { id: true, entityType: true, entityId: true, version: true } })
  const rev = pickRevision(revs, primary.targetType, primary.targetId)
  if (rev) return rev.id
  if (!PAGE_TARGETS.has(primary.targetType) || !primary.targetId || !item?.decidedAt) return null
  const snaps = await prisma.pageRevision.findMany({
    where: { pageId: primary.targetId, reason: 'ai-edit', createdAt: { lte: item.decidedAt } },
    orderBy: { createdAt: 'desc' },
    take: 10,
    select: { id: true, createdAt: true, createdById: true, reason: true },
  })
  return pickPageSnapshot(snaps, item)?.id ?? null
}

async function revisionView(ref: Extract<ChangeRef, { kind: 'revision' }>, perms: UserWithPermissions): Promise<ChangeView | null> {
  // Masked for this person by getRevision; secrets were never stored.
  const rev = await getRevision(ref.revisionId, perms)
  if (!rev) return null
  const rights = historyRightsFor(perms, rev.entityType, rev.entityId)
  if (!rights.read) return null
  return viewFromRevision(ref, rev, rights.restore)
}

export async function resolveChangeViews(refs: readonly ChangeRef[], perms: UserWithPermissions): Promise<ChangeView[]> {
  const views = await Promise.all(refs.map((r) => (r.kind === 'changeset' ? changeSetView(r, perms) : revisionView(r, perms))))
  return views.filter((v): v is ChangeView => !!v)
}

/**
 * The mobile Review deck: every open change set this person may see, as
 * cards (who, when, why, the change masked for them). Approve / Reject show
 * only where they may review (view.canApprove); the rest are read-only.
 */
export async function reviewDeckCards(perms: UserWithPermissions): Promise<DeckCard[]> {
  const sets = await listReviewSets(perms, { scope: 'open' })
  const cards: DeckCard[] = []
  for (const set of sets) {
    // Its target was deleted: it can't be approved, so it waits in To-do with Discard instead.
    if (onlyRemovedTargets(set.items)) continue
    const items = await maskItems(set.items, perms)
    const view = viewFromItems({ kind: 'changeset', changeSetId: set.id, itemIds: [] }, items, set.why)
    if (!view) continue
    const lead = set.items.find((i) => i.status === 'pending' || i.status === 'saved') ?? set.items[0]
    cards.push({
      id: set.id,
      who: proposer(set.source, ownerLabel(set.ownerName, set.ownerEmail), set.ownerId === perms.id),
      at: set.createdAt,
      why: lead?.summary?.trim() || set.title || null,
      view,
    })
  }
  return withPhoneDetails(cards, sets, perms)
}

/** Story sections a phone draft can leave for the web (warnings, not blockers). */
function laterFor(type: string, fields: Record<string, unknown>): string[] {
  const full = recordChecklist(type, { data: fields })
  return full ? relaxForPhone(full, type).later.map((i) => i.label) : []
}

/** Drafts sent from a phone: who sent them "from your phone", with their photos, voice notes and facts. */
async function withPhoneDetails(cards: DeckCard[], sets: Awaited<ReturnType<typeof listReviewSets>>, perms: UserWithPermissions): Promise<DeckCard[]> {
  const ids = cards.map((c) => c.id)
  if (!ids.length) return cards
  const [handoffs, notes] = await Promise.all([
    prisma.adeHandoff.findMany({ where: { changeSetId: { in: ids }, device: 'phone' }, select: { changeSetId: true } }),
    prisma.adeChangeComment.findMany({ where: { changeSetId: { in: ids }, kind: ATTACHMENTS_KIND }, select: { changeSetId: true, body: true } }),
  ])
  const fromPhone = new Set(handoffs.map((h) => h.changeSetId))
  const canPublish = checkPermission(perms, 'pages.publish').allowed
  return cards.map((c) => {
    if (!fromPhone.has(c.id)) return c
    const set = sets.find((s) => s.id === c.id)
    const a = parseAttachments(notes.find((n) => n.changeSetId === c.id)?.body)
    // The new record's facts as drafted (its record:create item's snapshot).
    const create = set?.items.find((i) => i.targetType === 'record' && i.operation === 'create')
    const fields = ((create?.after as { data?: Record<string, unknown> } | null | undefined)?.data ?? (create?.input as { fields?: Record<string, unknown> } | undefined)?.fields ?? {}) as Record<string, unknown>
    const mine = set?.ownerId === perms.id
    const name = set ? ownerLabel(set.ownerName, set.ownerEmail) : null
    return {
      ...c,
      who: mine ? 'You · from your phone' : `${name ?? 'Someone'} · from their phone`,
      phone: { photos: a?.photos ?? [], voice: a?.voice ?? [], facts: phoneFacts(fields, a, formatMoney), canPublish, publishEndpoint: create ? '/api/admin/mobile/records/approve-publish' : null, later: laterFor((create?.after as { type?: string } | null | undefined)?.type ?? 'initiative', fields) },
    }
  })
}

/**
 * The Review tab's badge: open change sets with something THIS person may
 * approve. One light query (no diffs, no masking) — the shell calls it on
 * mount and on each route change.
 */
export async function reviewCount(perms: UserWithPermissions): Promise<number> {
  const rows = await prisma.adeChangeSetItem.findMany({
    where: { status: 'pending' },
    select: { id: true, changeSetId: true, targetType: true, targetId: true, operation: true, status: true, toolName: true, input: true },
    take: 500,
  })
  // Changes to something deleted since are not counted: they can't be approved (To-do offers Discard).
  const removed = await removedTargetItemIds(rows.map((r) => ({ id: r.id, changeSetId: r.changeSetId, targetType: r.targetType, targetId: r.targetId, operation: r.operation, status: r.status })))
  const sets = new Set<string>()
  for (const r of rows) {
    if (removed.has(r.id)) continue
    const item = { targetType: r.targetType, toolName: r.toolName, input: (r.input ?? {}) as Record<string, unknown> }
    if (canViewItem(perms, item) && canApprove(perms, item)) sets.add(r.changeSetId)
  }
  return sets.size
}
