/**
 * This app's MailboxSource for the Inbox "My email" tab: the email connector
 * routes (settings-n), which only ever return the signed-in person's own
 * mailbox. Never cached (no-store); mail is text, rendered as text.
 */

import { mailProblem, mailboxState, problemMessage, type ConnectorInfo, type MailDraft, type MailProvider, type MailResult, type MailThread, type MailThreadSummary, type MailboxSource } from '../ade/mobile/mailbox'

async function call<T>(url: string, init: RequestInit | undefined, pick: (j: Record<string, unknown>) => T | null): Promise<MailResult<T>> {
  const res = await fetch(url, { cache: 'no-store', ...init }).catch(() => null)
  if (!res) return { ok: false, problem: 'error', message: problemMessage('error') }
  const j = (await res.json().catch(() => null)) as Record<string, unknown> | null
  if (!res.ok || !j || j.success === false) {
    const problem = mailProblem(res.status, j as { error?: unknown } | null)
    // A held send (staging allow-list) or a provider refusal carries its own words.
    const message = problem === 'error' && typeof j?.error === 'string' && j.error.length < 300 ? j.error : problemMessage(problem)
    return { ok: false, problem, message }
  }
  const value = pick(j)
  return value === null ? { ok: false, problem: 'error', message: problemMessage('error') } : { ok: true, value }
}

/** This app shows My email (Inbox and desktop To-do). Client-safe: no server imports here. */
export const MAILBOX_ENABLED = true

const json = (body: unknown): RequestInit => ({ method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })

export const appMailboxSource: MailboxSource = {
  async state(returnTo) {
    const res = await fetch('/api/connectors', { cache: 'no-store' }).catch(() => null)
    // No connector API on this deployment yet = not set up.
    if (!res || res.status === 404) return { kind: 'not-set-up' }
    const j = (await res.json().catch(() => null)) as { connectors?: ConnectorInfo[]; providers?: ConnectorInfo[] } | ConnectorInfo[] | null
    const list = Array.isArray(j) ? j : j?.connectors ?? j?.providers ?? []
    return mailboxState(Array.isArray(list) ? list : [], returnTo)
  },
  threads(provider, opts = {}) {
    const p = new URLSearchParams({ provider })
    if (opts.q) p.set('q', opts.q)
    if (opts.cursor) p.set('cursor', opts.cursor)
    return call(`/api/connectors/mail/threads?${p}`, undefined, (j) =>
      Array.isArray(j.threads) ? { threads: j.threads as MailThreadSummary[], next: typeof j.next === 'string' ? j.next : null } : null,
    )
  },
  thread(provider, id) {
    return call(`/api/connectors/mail/threads/${encodeURIComponent(id)}?provider=${provider}`, undefined, (j) => (j.thread && typeof j.thread === 'object' ? (j.thread as MailThread) : null))
  },
  saveDraft(provider: MailProvider, draft: MailDraft) {
    return call('/api/connectors/mail/drafts', json({ provider, ...draft }), (j) => {
      const d = j.draft as { id?: unknown } | undefined
      return typeof d?.id === 'string' ? { id: d.id } : null
    })
  },
  sendDraft(provider, draftId) {
    return call(`/api/connectors/mail/drafts/${encodeURIComponent(draftId)}/send`, json({ provider }), (j) => (j.sent === true ? (true as const) : null))
  },
}
