/**
 * Dzidzor's side of personal email connectors (lib/ade/connectors): where
 * tokens live (connector_accounts, encrypted), the state secret, redirect
 * URIs per deployment, and the send guard on every send.
 *
 * Only ever called with the signed-in person's own id. There is no "list
 * everyone's connections" and no admin read path: a mailbox is its owner's.
 */

import 'server-only'
import { createHmac } from 'node:crypto'
import { prisma } from '../db'
import { decrypt, encrypt } from '../encryption'
import { getEmailSettings } from '../settings'
import { decide, parseAllowList } from '../email/send-guard'
import {
  CONNECTOR_PROVIDERS,
  PROVIDERS,
  capabilitiesOf,
  connectorSecretsReadyIn,
  disconnect as coreDisconnect,
  mailboxFor,
  providerConfigStatus,
  type ConnectorProvider,
  type ConnectorStore,
  type DraftDetail,
  type MailAdapter,
  type MailCapability,
} from '../ade/connectors'

const SCOPE = 'personal'

/**
 * Secrets present? Mailbox tokens, the PKCE cookie and OAuth state need a real
 * ENCRYPTION_KEY everywhere but local development and tests — staging and
 * previews included (the library's built-in fallback key is public).
 */
const relaxed = () => process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'development'
export const connectorSecretsReady = () => connectorSecretsReadyIn(process.env)
function assertKey() {
  if (!connectorSecretsReady()) throw new Error('ENCRYPTION_KEY is not set: refusing to handle mailbox tokens')
}
/** Encrypt for connector use (tokens, the PKCE cookie) — refuses without a real key. */
export const encryptConnectorSecret = (s: string) => (assertKey(), encrypt(s))
const enc = encryptConnectorSecret
const dec = (s: string | null | undefined) => (s ? decrypt(s) : null)

export const connectorStore: ConnectorStore = {
  async get(userId, provider) {
    const r = await prisma.connectorAccount.findUnique({ where: { userId_provider_scope: { userId, provider, scope: SCOPE } } })
    if (!r) return null
    return {
      accessToken: dec(r.accessTokenEnc) ?? '',
      refreshToken: dec(r.refreshTokenEnc),
      expiresAt: r.expiresAt,
      grantedScopes: r.grantedScopes,
      status: r.status === 'needs-reconnect' ? 'needs-reconnect' : 'active',
      account: dec(r.accountEnc),
      connectedAt: r.connectedAt,
    }
  },
  async save(userId, provider, c) {
    const data = {
      accessTokenEnc: enc(c.accessToken),
      refreshTokenEnc: c.refreshToken ? enc(c.refreshToken) : null,
      expiresAt: c.expiresAt,
      grantedScopes: c.grantedScopes,
      accountEnc: c.account ? enc(c.account) : null,
      status: 'active',
    }
    await prisma.connectorAccount.upsert({
      where: { userId_provider_scope: { userId, provider, scope: SCOPE } },
      create: { userId, provider, scope: SCOPE, ...data },
      update: data,
    })
  },
  async update(userId, provider, c) {
    // Only an ACTIVE row: a refresh that finishes after Disconnect or "needs reconnect" changes nothing.
    const r = await prisma.connectorAccount.updateMany({
      where: { userId, provider, scope: SCOPE, status: 'active' },
      data: { accessTokenEnc: enc(c.accessToken), refreshTokenEnc: c.refreshToken ? enc(c.refreshToken) : null, expiresAt: c.expiresAt, grantedScopes: c.grantedScopes },
    })
    return r.count > 0
  },
  async markReconnect(userId, provider) {
    await prisma.connectorAccount.updateMany({ where: { userId, provider, scope: SCOPE }, data: { status: 'needs-reconnect' } })
  },
  async remove(userId, provider) {
    await prisma.connectorAccount.deleteMany({ where: { userId, provider, scope: SCOPE } })
  },
}

/**
 * The key that signs OAuth state: CONNECTOR_STATE_SECRET, else derived from
 * ENCRYPTION_KEY (labelled, so it is never the encryption key itself).
 */
export function stateSecret(): string {
  const explicit = process.env.CONNECTOR_STATE_SECRET?.trim()
  if (explicit) return explicit
  const key = process.env.ENCRYPTION_KEY?.trim()
  if (key) return createHmac('sha256', key).update('connector-oauth-state/v1').digest('hex')
  if (!relaxed()) throw new Error('No CONNECTOR_STATE_SECRET or ENCRYPTION_KEY: refusing to sign OAuth state')
  return 'dev-only-connector-state'
}

/** Signs send previews (lib/ade/connectors/preview): its own label off the state secret. */
export function previewSecret(): string {
  return createHmac('sha256', stateSecret()).update('send-preview/v1').digest('hex')
}

export const CONNECTOR_CALLBACK = (p: ConnectorProvider) => `/api/connectors/${p}/callback`
export const DEFAULT_RETURN = '/admin/settings?section=connectors'

/**
 * Redirect URI for this deployment: CONNECTOR_REDIRECT_BASE when set (one
 * fixed URL registered with the provider), else the host handling the
 * request — staging comes back to staging, production to production. Each
 * must be registered with the provider (email-connectors-setup.md).
 */
export function redirectUri(provider: ConnectorProvider, requestOrigin: string): string {
  const base = (process.env.CONNECTOR_REDIRECT_BASE?.trim() || requestOrigin).replace(/\/+$/, '')
  return `${base}${CONNECTOR_CALLBACK(provider)}`
}

export interface ConnectorStatusRow {
  provider: ConnectorProvider
  label: string
  configured: boolean
  connected: boolean
  status: 'active' | 'needs-reconnect' | null
  account: string | null
  can: MailCapability[]
  connectedAt: string | null
  via: 'mcp' | 'api' | null
}

/** This person's own connections (and which providers are set up on this deployment). */
export async function connectorStatusFor(userId: string): Promise<ConnectorStatusRow[]> {
  const rows = await prisma.connectorAccount.findMany({ where: { userId, scope: SCOPE } })
  return CONNECTOR_PROVIDERS.map((provider) => {
    const r = rows.find((x) => x.provider === provider)
    // A row we can't decrypt (key rotated, corrupt) shows as "needs reconnect" — the list never breaks.
    let account: string | null = null
    let unreadable = false
    try {
      account = r ? dec(r.accountEnc) : null
    } catch {
      unreadable = true
    }
    return {
      provider,
      label: PROVIDERS[provider].label,
      configured: providerConfigStatus(provider, process.env).configured && connectorSecretsReady(),
      connected: Boolean(r),
      status: r ? (r.status === 'needs-reconnect' || unreadable ? 'needs-reconnect' : 'active') : null,
      account,
      can: r ? capabilitiesOf(provider, r.grantedScopes) : [],
      connectedAt: r ? r.connectedAt.toISOString() : null,
      via: r ? 'api' : null,
    }
  })
}

/** The person's own mailbox (throws ConnectorError 'not-found' when not connected). */
export function mailboxOf(userId: string, provider: ConnectorProvider): MailAdapter {
  return mailboxFor(connectorStore, userId, provider, process.env)
}

export const disconnectConnector = (userId: string, provider: ConnectorProvider) => coreDisconnect(connectorStore, userId, provider)

/**
 * Send one draft — only past the send guard: outside production every
 * recipient must be on the test allow-list (EMAIL_TEST_ALLOWLIST / the email
 * setting). Personal mail is not marketing, so production sends as normal.
 */
export type DraftSendOutcome =
  | { sent: true; id: string; draft: DraftDetail }
  | { sent: false; held: true; reason: string }
  | { sent: false; refused: true; changed: boolean; reason: string }

/**
 * `approve` sees the SAME read the guard checks and the provider then sends
 * (one read, no window between "approved" and "sent" beyond the send call):
 * the assistant passes its preview/token + recipient checks here.
 */
export async function sendDraftGuarded(
  userId: string,
  provider: ConnectorProvider,
  draftId: string,
  approve?: (draft: DraftDetail) => { ok: true } | { ok: false; changed?: boolean; reason: string }
): Promise<DraftSendOutcome> {
  const box = mailboxOf(userId, provider)
  const draft = await box.getDraft(draftId)
  const verdict = approve ? approve(draft) : { ok: true as const }
  if (!verdict.ok) return { sent: false, refused: true, changed: verdict.changed === true, reason: verdict.reason }
  const settings = await getEmailSettings()
  const allowList = parseAllowList(process.env.EMAIL_TEST_ALLOWLIST, settings.testAllowList)
  const env = { NODE_ENV: process.env.NODE_ENV, VERCEL_ENV: process.env.VERCEL_ENV }
  // Every recipient, Bcc included: nobody is copied past the guard unseen.
  if (decide({ env, to: [...draft.to, ...draft.cc, ...draft.bcc], category: 'transactional', allowList }) === 'drop') {
    return { sent: false, held: true, reason: 'Held: on this test site, email only goes to the test allow-list (EMAIL_TEST_ALLOWLIST). The draft is still in your mailbox.' }
  }
  const r = await box.sendDraft(draftId)
  return { sent: true, id: r.id, draft }
}

/**
 * Before a person (User row) is deleted or erased: revoke each of their
 * connections at the provider, then delete our copies. The table cascades on
 * user delete, which would drop the tokens WITHOUT revoking; an erasure that
 * only anonymises the row would keep them. Every such path calls this or
 * eraseConnectorsFor (asserted by lib/security/connectors-user-delete.assert.ts).
 */
export async function revokeAllConnectorsFor(userId: string): Promise<void> {
  for (const provider of CONNECTOR_PROVIDERS) {
    try {
      await disconnectConnector(userId, provider)
    } catch (e) {
      console.error('[connectors] revoke before user delete failed:', provider, e instanceof Error ? e.name : 'error')
    }
  }
}

/**
 * Erasure (account delete, privacy subject delete): revoke at the provider,
 * then remove every stored connection row even if a revoke failed — the
 * encrypted tokens must not outlive the person's data.
 */
export async function eraseConnectorsFor(userId: string): Promise<number> {
  await revokeAllConnectorsFor(userId)
  return (await prisma.connectorAccount.deleteMany({ where: { userId } })).count
}
