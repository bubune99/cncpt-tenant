/**
 * Who sees agent activity (owner, 2026-10-11): "the trace is strictly
 * governance for platform managers… accessed in settings or analytics."
 * The same permission opens Preview sizes (/admin/viewport-harness).
 * One permission gates the page, its APIs, the "View run" links, the daily
 * report section and the assistant's pointers to it. The owner (super admin,
 * '*') has it; no other built-in role does. Pure; asserted by
 * agent-activity-access.assert.ts.
 */

export const AGENT_ACTIVITY_PERMISSION = 'agent.activity.view'

/** The same matching as lib/permissions (exact, '*', or 'resource.*'). */
export function grants(held: ReadonlyArray<string>, required: string): boolean {
  return held.some((p) => p === required || p === '*' || (p.endsWith('.*') && required.startsWith(p.slice(0, -1))))
}

export function canSeeAgentActivity(held: ReadonlyArray<string>): boolean {
  return grants(held, AGENT_ACTIVITY_PERMISSION)
}

/** Every surface that shows runs, tokens or failures, for one viewer. */
export function agentActivitySurfaces(canSee: boolean) {
  return {
    /** /admin/agent-activity and its APIs. */
    page: canSee,
    /** "View run" on chat messages and audit rows (the runId stays on the message either way). */
    viewRunLinks: canSee,
    /** The Agent activity section of the dashboard / assistant briefing. */
    report: canSee,
    /** The entry in Settings › Assistant and the link on Analytics. */
    entryPoints: canSee,
    /** Preview sizes (/admin/viewport-harness) and its Settings entry. */
    previewSizes: canSee,
  }
}

/** The "View run" link for a message or audit row, or null when the viewer can't open runs. */
export function viewRunHref(runId: string | null | undefined, canSee: boolean, href: (id: string) => string): string | null {
  return canSee && runId ? href(runId) : null
}
