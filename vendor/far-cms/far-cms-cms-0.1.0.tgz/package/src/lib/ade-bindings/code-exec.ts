/**
 * DB-stored code execution gate, backed by the `ade` settings group.
 * Kept separate from the rest of the bindings so the vMCP / workflow /
 * plugin runtimes can import it without pulling in the agent tool graph.
 */

import { createCodeExecGate } from '../ade/code-exec/flag'
import { getAdeSettings } from '../settings'

export { CodeExecutionDisabledError, CodeActorRefusedError, assertCodeActor, type CodeActor } from '../ade/code-exec/flag'

/** The caller as the code gate sees them (super admin = holds '*'). */
export const codeActorOf = (permissions: { permissions: ReadonlySet<string> }) => ({ isSuperAdmin: permissions.permissions.has('*') })

/** OFF unless a super admin enables it; a failed settings read counts as OFF. */
export const codeExecGate = createCodeExecGate({
  load: async () => (await getAdeSettings()).allowDbCodeExecution,
})
