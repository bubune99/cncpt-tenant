/**
 * This app's inputs to the context card (lib/ade/assistant/context-card):
 * the chrome the page reported (checked: only menu names and paths, only
 * known top-bar selectors), the To-do counted exactly as the To-do page
 * counts it, the selection, the role. Pure; asserted by
 * context-card.assert.ts. The server loaders are in context-card-server.ts.
 */

import { z } from 'zod'
import type { CardCore, TodoBundleInput } from '../ade/assistant/context-card'
import { assistantStateOf, viewportOf } from '../ade/assistant/context-card'
import type { ShellSnapshot } from '../ade/ui/shell-units'
import { needYouCount, type TodoLane } from './todo-lanes'
import { SHELL_TOP_UNITS } from './shell-units'

const LABEL = z.string().max(60).regex(/^[^\r\n\t<>`[\]]*$/)
const ADMIN_PATH = z.string().max(120).regex(/^\/admin[\w\-./]*$/)

/** What the page says about its chrome (components/ade/shell-spots shellForRequest). Capped. */
export const uiShellSchema = z.object({
  mode: z.enum(['workspace', 'classic']).optional(),
  chat: z.enum(['collapsed', 'minimized', 'side', 'full', 'split']).optional(),
  agentFull: z.boolean().optional(),
  agentSide: z.enum(['left', 'right']).optional(),
  width: z.number().int().min(0).max(20000).optional(),
  layout: z.enum(['sidebar', 'drawer', 'menu', 'phone']).optional(),
  menuOpen: z.boolean().optional(),
  drawerOpen: z.boolean().optional(),
  groups: z.array(z.object({ name: LABEL, items: z.array(z.object({ name: LABEL, href: ADMIN_PATH })).max(40) })).max(12).optional(),
  rendered: z.array(ADMIN_PATH).max(120).optional(),
  shown: z.array(z.string().max(120)).max(60).optional(),
})
export type UiShell = z.infer<typeof uiShellSchema>

const KNOWN_SELECTORS = new Set(SHELL_TOP_UNITS.flatMap((u) => Object.values(u.places).flatMap((ps) => ps?.map((p) => p.selector) ?? [])))

/** The chrome snapshot from the request: unknown top-bar selectors dropped (never prompt text from the page). */
export function shellSnapshotFrom(ui: UiShell | undefined, phone: boolean): ShellSnapshot | null {
  const layout = phone ? 'phone' : ui?.layout
  if (!layout) return null
  return {
    layout,
    menuOpen: !!ui?.menuOpen,
    drawerOpen: !!ui?.drawerOpen,
    groups: ui?.groups ?? [],
    rendered: ui?.rendered ?? [],
    shown: (ui?.shown ?? []).filter((s) => KNOWN_SELECTORS.has(s)),
  }
}

/** "block b12" while editing with a block selected; "record initiative:abc" on a record's screen; else null. */
export function selectionOf(route: string | null, editing?: { pageId?: string; selectedBlockId?: string | null } | null): string | null {
  const id = (s: string) => s.replace(/[^\w-]/g, '').slice(0, 60)
  if (editing?.selectedBlockId) return `block ${id(editing.selectedBlockId)}`
  const rec = route ? /^\/admin\/records\/([\w-]+)\/([\w-]+)(?:[/?#]|$)/.exec(route) : null
  if (rec && rec[2] !== 'new') return `record ${id(rec[1])}:${id(rec[2])}`
  if (editing?.pageId) return `page ${id(editing.pageId)}`
  return null
}

export function coreFrom(input: { ui: UiShell | undefined; phone: boolean; route: string | null; roles: ReadonlyArray<{ displayName?: string | null; name?: string | null }>; editing?: { pageId?: string; selectedBlockId?: string | null } | null }): CardCore {
  const ui = input.ui
  const roles = input.roles.map((r) => (r.displayName || r.name || '').trim()).filter(Boolean)
  return {
    mode: input.phone ? 'Workspace' : ui?.mode === 'workspace' ? 'Workspace' : ui?.mode === 'classic' ? 'Classic' : null,
    route: input.route,
    assistant: assistantStateOf({ mode: ui?.chat, agentFull: ui?.agentFull, agentSide: ui?.agentSide, phone: input.phone }),
    layout: input.phone ? 'phone' : ui?.layout ?? null,
    viewport: viewportOf(ui?.width, input.phone),
    selection: selectionOf(input.route, input.editing),
    role: roles.length ? roles.join(', ').slice(0, 80) : null,
  }
}

interface TodoLike {
  kind: 'approval' | 'task'
  lane: TodoLane
  title: string
  headline: string
  createdAt: string | null
  priority?: number
}

/** Lanes that need the person, with their words for one / many. */
const COUNT_LABELS: ReadonlyArray<[TodoLane, string, string]> = [
  ['approve', 'to approve', 'to approve'],
  ['messages', 'message', 'messages'],
  ['drafts', 'draft', 'drafts'],
  ['attention', 'needs a look', 'need a look'],
]

/**
 * The To-do bundle from the To-do's own items: "N need you" exactly as the
 * page counts it (needYouCount), counts by lane, and the top items
 * (approvals first, then by priority, then oldest).
 */
export function todoCardInput(items: ReadonlyArray<TodoLike>, now: number, topN: number): TodoBundleInput {
  const open = items.filter((i) => COUNT_LABELS.some(([l]) => l === i.lane))
  const ageDays = (iso: string | null) => {
    const t = iso ? Date.parse(iso) : NaN
    return Number.isFinite(t) ? Math.max(0, (now - t) / 86_400_000) : null
  }
  const rank = (i: TodoLike) => (i.kind === 'approval' ? 0 : 1)
  const top = [...open]
    .sort((a, b) => rank(a) - rank(b) || (a.priority ?? 9) - (b.priority ?? 9) || (Date.parse(a.createdAt ?? '') || 0) - (Date.parse(b.createdAt ?? '') || 0))
    .slice(0, topN)
    .map((i) => ({ title: i.title, kind: i.kind === 'approval' ? 'approval' : i.headline.toLowerCase(), ageDays: ageDays(i.createdAt) }))
  return {
    needYou: needYouCount(items),
    counts: COUNT_LABELS.map(([lane, one, many]) => {
      const n = items.filter((i) => i.lane === lane).length
      return { label: n === 1 ? one : many, n }
    }),
    top,
  }
}
