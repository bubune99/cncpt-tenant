/**
 * Coverage check results (lib/ade/coverage) — stored per admin route (the
 * coverage table), and ONE "Coverage report" To-do item for the whole sweep,
 * updated in place (a sweep used to add one item per route: 74 on BYB's
 * Today). Server only. The
 * coverage runner is read-only on the SITE: this writes only our own
 * coverage rows and the To-do item, never content.
 */

import { Prisma } from '@prisma/client'
import { prisma } from '../db'
import { COVERAGE_REPORT_KEY, coverageReportTask, coverageTable } from '../ade/coverage/logic'
import { parseCoveragePayload, type CoveragePayload } from './coverage-payload'
import { stagingToolsEnabled } from '../ade/staging-tools'

/** Staging only (owner): the AdeCoverage table is never read or written in production. */
function assertStaging(): void {
  if (!stagingToolsEnabled()) throw new Error('The coverage check is a staging tool')
}

export { parseCoveragePayload, type CoveragePayload }

export const COVERAGE_TASK_SOURCE = 'coverage'

/** Stores the route's row, then brings the one Coverage report item up to date; returns its id (the report the person opens). */
export async function saveCoverage(p: CoveragePayload, userId: string | null): Promise<{ taskId: string | null }> {
  assertStaging()
  const { row } = p
  const data = {
    result: p as unknown as Prisma.InputJsonValue,
    units: row.units,
    toolGaps: row.toolGaps.length,
    uiGaps: row.uiGaps.length,
    hidden: row.hiddenOnly.length,
    runBy: userId,
  }
  await prisma.adeCoverage.upsert({ where: { route: row.route }, create: { route: row.route, ...data }, update: data })

  return { taskId: await syncCoverageReport() }
}

/**
 * The one Coverage report item, from every stored row: open (or reopened)
 * while any screen has a gap, closed when all are clean. Returns its id.
 */
export async function syncCoverageReport(): Promise<string | null> {
  assertStaging()
  const stored = await prisma.adeCoverage.findMany({ select: { result: true }, take: 500 })
  const rows = stored.map((r) => parseCoveragePayload(r.result)?.row).filter((r): r is NonNullable<typeof r> => !!r)
  const report = coverageReportTask(rows)
  if (report) {
    const task = await prisma.adeTask.upsert({
      where: { dedupeKey: COVERAGE_REPORT_KEY },
      create: { source: COVERAGE_TASK_SOURCE, ...report, dedupeKey: COVERAGE_REPORT_KEY, targetType: 'coverage', targetId: 'report', priority: 3, permission: 'settings.view' },
      update: { ...report, status: 'open', completedAt: null },
      select: { id: true },
    })
    return task.id
  }
  await prisma.adeTask.updateMany({ where: { dedupeKey: COVERAGE_REPORT_KEY, status: 'open' }, data: { status: 'done', completedAt: new Date() } })
  return (await prisma.adeTask.findUnique({ where: { dedupeKey: COVERAGE_REPORT_KEY }, select: { id: true } }))?.id ?? null
}

/** The sweep: latest row per route + the tool-gap list across routes. */
export async function listCoverage() {
  assertStaging()
  const rows = await prisma.adeCoverage.findMany({ orderBy: { route: 'asc' }, take: 500 })
  const parsed = rows.map((r) => parseCoveragePayload(r.result)).filter((p): p is CoveragePayload => p !== null)
  return { ...coverageTable(parsed.map((p) => p.row)), detail: Object.fromEntries(parsed.map((p) => [p.row.route, p])) }
}
