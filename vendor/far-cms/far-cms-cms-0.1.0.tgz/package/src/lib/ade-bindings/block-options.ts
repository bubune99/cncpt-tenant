/**
 * This app's block option definitions for the block control panel (prototype,
 * owner 2026-10-18) — Banner, Text and Button — plus the brand palette and the
 * site pages the link field offers. Data only, shaped like the future schema
 * (lib/ade/blocks/options-schema); another app ships its own copy.
 * The lab page is a throwaway: nothing here is real content.
 */

import type { BlockTypeDef, FieldDef, GroupDef, Option, Preset } from '../ade/blocks/options-schema'
import { SHOW_ON } from '../ade/blocks/options-schema'

/** Brand colours first in every colour picker (Settings › Identity & brand later). */
export const BRAND_PALETTE: ReadonlyArray<{ name: string; value: string }> = [
  { name: 'Ink', value: '#1f1a17' },
  { name: 'Clay', value: '#b5562f' },
  { name: 'Sand', value: '#e9dcc6' },
  { name: 'Cream', value: '#f7f1e6' },
  { name: 'Teal', value: '#1f6f6b' },
  { name: 'White', value: '#ffffff' },
]

/** The assistant's per-group entry in the block panel. */
export const PANEL_ASK_LABEL = 'Ask Kofi'

/** The site's pages for link fields (mock list for the lab; the real list comes from Pages in step 2). */
export const LAB_PAGES: ReadonlyArray<{ title: string; path: string }> = [
  { title: 'Home', path: '/' },
  { title: 'About us', path: '/about' },
  { title: 'Initiatives', path: '/initiatives' },
  { title: 'Get involved', path: '/get-involved' },
  { title: 'Donate', path: '/donate' },
  { title: 'Contact', path: '/contact' },
]

const SPACE: ReadonlyArray<Preset> = [
  { id: 'S', value: 16 },
  { id: 'M', value: 32 },
  { id: 'L', value: 56 },
  { id: 'XL', value: 96 },
]
const CORNERS: ReadonlyArray<Preset> = [
  { id: 'S', value: 4 },
  { id: 'M', value: 12 },
  { id: 'L', value: 20 },
  { id: 'XL', value: 32 },
]
const ANIMATIONS: ReadonlyArray<Option> = [
  { value: 'none', label: 'None' },
  { value: 'fade', label: 'Fade in' },
  { value: 'rise', label: 'Rise up' },
  { value: 'zoom', label: 'Gentle zoom' },
]

const padding = (d: number): FieldDef => ({ key: 'padding', label: 'Inner spacing', control: 'preset-slider', default: d, presets: SPACE, min: 0, max: 160, step: 4, unit: 'px', deviceAware: true, mapsTo: { kind: 'class', scale: 'padding' } })
const corners = (d: number): FieldDef => ({ key: 'corners', label: 'Rounded corners', control: 'preset-slider', default: d, presets: CORNERS, min: 0, max: 48, step: 2, unit: 'px', deviceAware: false, mapsTo: { kind: 'class', scale: 'radius' } })
const border: FieldDef = { key: 'border', label: 'Border', control: 'segmented', default: 'none', options: [{ value: 'none', label: 'None' }, { value: 'thin', label: 'Thin' }, { value: 'thick', label: 'Thick' }], deviceAware: false, mapsTo: { kind: 'class', scale: 'border' } }
const shadow: FieldDef = { key: 'shadow', label: 'Shadow', control: 'segmented', default: 'none', options: [{ value: 'none', label: 'None' }, { value: 'soft', label: 'Soft' }, { value: 'lifted', label: 'Lifted' }], deviceAware: false, mapsTo: { kind: 'class', scale: 'shadow' } }
const motion = (extra: FieldDef[] = []): GroupDef => ({
  id: 'motion',
  fields: [
    { key: 'animation', label: 'Entrance', control: 'select', default: 'none', options: ANIMATIONS, hint: 'How the block appears as visitors scroll to it.', deviceAware: false, mapsTo: { kind: 'attr', name: 'data-animate' } },
    ...extra,
  ],
})
const visibility: GroupDef = { id: 'visibility', fields: [{ key: 'showOn', label: 'Show on', control: 'show-on', default: 'all', options: SHOW_ON, deviceAware: false, mapsTo: { kind: 'class', scale: 'display' } }] }
const advanced: GroupDef = {
  id: 'advanced',
  fields: [
    { key: 'anchor', label: 'Anchor name', control: 'text', default: '', hint: 'Lets a link jump straight here, e.g. “donate” → /page#donate.', deviceAware: false, mapsTo: { kind: 'attr', name: 'id' } },
    { key: 'extraClasses', label: 'Extra classes', control: 'text', default: '', hint: 'For developers. Most changes belong in the groups above.', deviceAware: false, mapsTo: { kind: 'class', scale: 'raw' } },
  ],
}

export const BANNER: BlockTypeDef = {
  type: 'banner',
  label: 'Banner',
  groups: [
    {
      id: 'content',
      fields: [
        { key: 'heading', label: 'Heading', control: 'text', default: 'Care that reaches every village', deviceAware: false, mapsTo: { kind: 'text', slot: 'heading' } },
        { key: 'headingSize', label: 'Heading size', control: 'preset-slider', default: 48, presets: [{ id: 'S', value: 28 }, { id: 'M', value: 40 }, { id: 'L', value: 48 }, { id: 'XL', value: 64 }], min: 20, max: 88, step: 2, unit: 'px', deviceAware: true, mapsTo: { kind: 'class', scale: 'text-size' } },
        { key: 'subheading', label: 'Supporting line', control: 'textarea', default: 'Mobile clinics, clean water and school support across the Volta Region.', deviceAware: false, mapsTo: { kind: 'text', slot: 'subheading' } },
        { key: 'buttonLabel', label: 'Button text', control: 'text', default: 'See our work', hint: 'Leave empty for no button.', deviceAware: false, mapsTo: { kind: 'text', slot: 'button' } },
      ],
    },
    {
      id: 'layout',
      fields: [
        { key: 'height', label: 'Height', control: 'preset-slider', default: 520, presets: [{ id: 'S', value: 360 }, { id: 'M', value: 440 }, { id: 'L', value: 520 }, { id: 'XL', value: 680 }], min: 240, max: 900, step: 10, unit: 'px', deviceAware: true, mapsTo: { kind: 'class', scale: 'min-height' } },
        { key: 'textPosition', label: 'Text position', control: 'align-grid', default: 'middle-left', hint: 'Where the words sit on the picture.', deviceAware: true, mapsTo: { kind: 'class', scale: 'place' } },
        { key: 'textWidth', label: 'Text width', control: 'segmented', default: 'medium', options: [{ value: 'narrow', label: 'Narrow' }, { value: 'medium', label: 'Medium' }, { value: 'wide', label: 'Wide' }], deviceAware: false, mapsTo: { kind: 'class', scale: 'max-width' } },
        padding(56),
      ],
    },
    {
      id: 'background',
      fields: [
        { key: 'image', label: 'Background image', control: 'media', default: { url: null, alt: '', focal: { x: 50, y: 50 } }, hint: 'Drag the dot to the part of the picture that must always show.', deviceAware: false, mapsTo: { kind: 'style', prop: 'background-image' } },
        { key: 'overlay', label: 'Overlay color', control: 'color', default: { color: '#1f1a17', opacity: 45 }, hint: 'Darkens the picture so the words stay readable.', deviceAware: false, mapsTo: { kind: 'style', prop: 'overlay' } },
        { key: 'video', label: 'Background video', control: 'text', default: '', hint: 'A YouTube link or a video from the media library. Plays muted, on a loop.', deviceAware: false, mapsTo: { kind: 'attr', name: 'data-bg-video' } },
      ],
    },
    {
      id: 'style',
      fields: [
        corners(0),
        { key: 'divider', label: 'Shape divider (bottom)', control: 'select', default: 'none', options: [{ value: 'none', label: 'None' }, { value: 'wave', label: 'Wave' }, { value: 'curve', label: 'Curve' }, { value: 'slant', label: 'Slant' }], hint: 'A soft edge into the next section.', deviceAware: false, mapsTo: { kind: 'attr', name: 'data-divider' } },
        { key: 'textColor', label: 'Text color', control: 'color', default: { color: '#ffffff', opacity: 100 }, deviceAware: false, mapsTo: { kind: 'style', prop: 'color' } },
      ],
    },
    { id: 'link', fields: [{ key: 'link', label: 'Button goes to', control: 'link', default: { kind: 'page', path: '/initiatives' }, deviceAware: false, mapsTo: { kind: 'attr', name: 'href' } }] },
    motion(),
    visibility,
    advanced,
  ],
}

export const TEXT: BlockTypeDef = {
  type: 'text',
  label: 'Text',
  groups: [
    {
      id: 'content',
      fields: [
        { key: 'text', label: 'Text', control: 'textarea', default: 'Since 2014 our volunteers have run weekly clinics in villages without a health post. Every visit is planned with the community, and every cedi you give goes to medicine, transport and local staff.', deviceAware: false, mapsTo: { kind: 'text', slot: 'body' } },
        { key: 'textSize', label: 'Text size', control: 'preset-slider', default: 18, presets: [{ id: 'S', value: 15 }, { id: 'M', value: 18 }, { id: 'L', value: 21 }, { id: 'XL', value: 26 }], min: 12, max: 36, step: 1, unit: 'px', deviceAware: true, mapsTo: { kind: 'class', scale: 'text-size' } },
      ],
    },
    {
      id: 'layout',
      fields: [
        { key: 'align', label: 'Alignment', control: 'segmented', default: 'left', options: [{ value: 'left', label: 'Left' }, { value: 'center', label: 'Center' }, { value: 'right', label: 'Right' }], deviceAware: true, mapsTo: { kind: 'class', scale: 'text-align' } },
        { key: 'width', label: 'Reading width', control: 'segmented', default: 'medium', options: [{ value: 'narrow', label: 'Narrow' }, { value: 'medium', label: 'Medium' }, { value: 'full', label: 'Full' }], hint: 'Narrower lines are easier to read.', deviceAware: false, mapsTo: { kind: 'class', scale: 'max-width' } },
        padding(32),
      ],
    },
    { id: 'background', fields: [{ key: 'background', label: 'Background color', control: 'color', default: { color: '#f7f1e6', opacity: 100 }, deviceAware: false, mapsTo: { kind: 'style', prop: 'background-color' } }] },
    { id: 'style', fields: [corners(12), border, shadow, { key: 'textColor', label: 'Text color', control: 'color', default: { color: '#1f1a17', opacity: 100 }, deviceAware: false, mapsTo: { kind: 'style', prop: 'color' } }] },
    { id: 'link', fields: [{ key: 'link', label: 'Whole block links to', control: 'link', default: { kind: 'none' }, hint: 'Optional. Makes the whole block clickable.', deviceAware: false, mapsTo: { kind: 'attr', name: 'href' } }] },
    motion(),
    visibility,
    advanced,
  ],
}

export const BUTTON: BlockTypeDef = {
  type: 'button',
  label: 'Button',
  groups: [
    {
      id: 'content',
      fields: [
        { key: 'label', label: 'Button text', control: 'text', default: 'Donate today', deviceAware: false, mapsTo: { kind: 'text', slot: 'label' } },
        { key: 'icon', label: 'Icon', control: 'segmented', default: 'arrow', options: [{ value: 'none', label: 'None' }, { value: 'arrow', label: 'Arrow' }, { value: 'heart', label: 'Heart' }], deviceAware: false, mapsTo: { kind: 'attr', name: 'data-icon' } },
      ],
    },
    {
      id: 'layout',
      fields: [
        { key: 'size', label: 'Size', control: 'segmented', default: 'md', options: [{ value: 'sm', label: 'Small' }, { value: 'md', label: 'Medium' }, { value: 'lg', label: 'Large' }], deviceAware: true, mapsTo: { kind: 'class', scale: 'button-size' } },
        { key: 'align', label: 'Alignment', control: 'segmented', default: 'center', options: [{ value: 'left', label: 'Left' }, { value: 'center', label: 'Center' }, { value: 'right', label: 'Right' }], deviceAware: true, mapsTo: { kind: 'class', scale: 'justify' } },
        { key: 'fullWidth', label: 'Full width', control: 'toggle', default: false, hint: 'Often easier to tap on phones.', deviceAware: true, mapsTo: { kind: 'class', scale: 'width' } },
      ],
    },
    { id: 'background', fields: [{ key: 'fill', label: 'Button color', control: 'color', default: { color: '#b5562f', opacity: 100 }, deviceAware: false, mapsTo: { kind: 'style', prop: 'background-color' } }] },
    {
      id: 'style',
      fields: [
        { key: 'shape', label: 'Shape', control: 'segmented', default: 'rounded', options: [{ value: 'square', label: 'Square' }, { value: 'rounded', label: 'Rounded' }, { value: 'pill', label: 'Pill' }], deviceAware: false, mapsTo: { kind: 'class', scale: 'radius' } },
        border,
        shadow,
        { key: 'textColor', label: 'Text color', control: 'color', default: { color: '#ffffff', opacity: 100 }, deviceAware: false, mapsTo: { kind: 'style', prop: 'color' } },
      ],
    },
    {
      id: 'link',
      fields: [
        { key: 'link', label: 'Goes to', control: 'link', default: { kind: 'page', path: '/donate' }, deviceAware: false, mapsTo: { kind: 'attr', name: 'href' } },
        { key: 'newTab', label: 'Open in a new tab', control: 'toggle', default: false, hint: 'Only for other websites.', deviceAware: false, mapsTo: { kind: 'attr', name: 'target' } },
      ],
    },
    motion([{ key: 'hover', label: 'On hover', control: 'segmented', default: 'lift', options: [{ value: 'none', label: 'None' }, { value: 'lift', label: 'Lift' }, { value: 'glow', label: 'Glow' }], deviceAware: false, mapsTo: { kind: 'class', scale: 'hover' } }]),
    visibility,
    advanced,
  ],
}

export const LAB_BLOCK_TYPES: ReadonlyArray<BlockTypeDef> = [BANNER, TEXT, BUTTON]

/** The throwaway lab page: one of each block, in order. */
export const LAB_PAGE: ReadonlyArray<{ id: string; type: string }> = [
  { id: 'lab-banner', type: 'banner' },
  { id: 'lab-text', type: 'text' },
  { id: 'lab-button', type: 'button' },
]
