/**
 * The Connectors screen's calls to the connector core (settings-n's API,
 * review/email-connectors-2026-10-11). One place to align when its routes
 * change; the screen and the view model (lib/settings/connectors) don't know
 * the URLs.
 *
 * Every call is for the signed-in person only — the server decides whose
 * connection it is from the session, never from a parameter.
 */

import { microsoftManageUrl, type ConnectorProvider, type ConnectorStatus } from '../settings/connectors'

const BASE = '/api/connectors'
export const CONNECTORS_RETURN_TO = '/admin/settings?section=connectors'

const PROVIDERS: ReadonlyArray<ConnectorProvider> = ['google', 'microsoft']

/** This person's connections, one per provider (a provider the API leaves out is shown as not set up). */
export async function fetchConnectors(): Promise<ConnectorStatus[]> {
  const res = await fetch(BASE, { cache: 'no-store', credentials: 'same-origin' })
  const j = (await res.json().catch(() => null)) as { success?: boolean; providers?: ConnectorStatus[]; error?: string } | null
  if (!res.ok || !j?.success || !Array.isArray(j.providers)) throw new Error(j?.error || `Couldn’t load your connections (${res.status})`)
  return PROVIDERS.map((p) => j.providers!.find((c) => c.provider === p) ?? { provider: p, configured: false, connected: false })
}

/**
 * "Connect" is a same-origin form POST (the core refuses GET and cross-site
 * posts), carrying where to come back to; the core answers 303 to the
 * provider's sign-in, then returns here.
 */
export function connectForm(provider: ConnectorProvider): { action: string; returnTo: string } {
  return { action: `${BASE}/${provider}/connect`, returnTo: CONNECTORS_RETURN_TO }
}

/**
 * Disconnect: the core revokes at the provider where it can (Google) and
 * deletes the stored sign-in. Microsoft can't be revoked per app, so it
 * answers with the page where the person removes the access themselves.
 */
export async function disconnectConnector(provider: ConnectorProvider): Promise<{ ok: true; manageUrl?: string } | { ok: false; error: string }> {
  const res = await fetch(`${BASE}/${provider}`, { method: 'DELETE', credentials: 'same-origin' }).catch(() => null)
  if (!res) return { ok: false, error: 'Couldn’t reach the server. Try again.' }
  const j = (await res.json().catch(() => null)) as { success?: boolean; error?: string; manageUrl?: unknown } | null
  if (!res.ok || j?.success === false) return { ok: false, error: j?.error || 'Couldn’t disconnect. Try again.' }
  const manageUrl = microsoftManageUrl(j?.manageUrl)
  return manageUrl ? { ok: true, manageUrl } : { ok: true }
}
