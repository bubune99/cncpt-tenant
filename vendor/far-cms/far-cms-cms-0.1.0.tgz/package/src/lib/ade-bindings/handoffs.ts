/**
 * Phone → desktop handoffs (Dzidzor storage for lib/ade/mobile/handoff).
 * A person only ever sees and changes their own.
 */

import { prisma } from '../db'
import type { Handoff } from '../ade/mobile/handoff'

type Row = Awaited<ReturnType<typeof prisma.adeHandoff.findFirstOrThrow>>

const shape = (r: Row): Handoff => ({
  id: r.id,
  kind: r.kind,
  title: r.title,
  device: r.device === 'desktop' ? 'desktop' : 'phone',
  changeSetId: r.changeSetId,
  conversationId: r.conversationId,
  href: r.href,
  status: r.status === 'picked' || r.status === 'dismissed' ? r.status : 'open',
  createdAt: r.createdAt.toISOString(),
})

export async function createHandoff(userId: string, h: { kind: string; title: string; changeSetId?: string | null; conversationId?: string | null; href?: string | null; device?: 'phone' | 'desktop'; clientKey?: string | null }): Promise<Handoff> {
  // One open handoff per draft: saving the same draft again updates it.
  const existing = h.changeSetId ? await prisma.adeHandoff.findFirst({ where: { userId, changeSetId: h.changeSetId, status: 'open' } }) : null
  const data = { kind: h.kind.slice(0, 40), title: h.title.slice(0, 200), device: h.device ?? 'phone', changeSetId: h.changeSetId ?? null, conversationId: h.conversationId ?? null, href: h.href ?? null }
  const row = existing ? await prisma.adeHandoff.update({ where: { id: existing.id }, data }) : await prisma.adeHandoff.create({ data: { userId, ...data, clientKey: h.clientKey ?? null } })
  return shape(row)
}

/** The handoff a phone save with this key already made (a retry after a dropped signal), if any. */
export async function handoffByClientKey(userId: string, clientKey: string): Promise<Handoff | null> {
  const row = await prisma.adeHandoff.findUnique({ where: { userId_clientKey: { userId, clientKey } } })
  return row ? shape(row) : null
}

export async function listHandoffs(userId: string, filter: { device?: string; status?: string } = {}): Promise<Handoff[]> {
  const rows = await prisma.adeHandoff.findMany({
    where: { userId, ...(filter.device ? { device: filter.device } : {}), ...(filter.status ? { status: filter.status } : {}), createdAt: { gte: new Date(Date.now() - 30 * 86_400_000) } },
    orderBy: { createdAt: 'desc' },
    take: 20,
  })
  // A draft that was decided (approved/rejected) elsewhere isn't waiting any more.
  const sets = rows.map((r) => r.changeSetId).filter((x): x is string => !!x)
  const open = new Set((await prisma.adeChangeSet.findMany({ where: { id: { in: sets }, status: { in: ['pending', 'partial', 'saved'] } }, select: { id: true } })).map((s) => s.id))
  return rows.filter((r) => !r.changeSetId || open.has(r.changeSetId)).map(shape)
}

export async function setHandoffStatus(userId: string, id: string, status: 'picked' | 'dismissed'): Promise<boolean> {
  const r = await prisma.adeHandoff.updateMany({ where: { id, userId }, data: { status } })
  return r.count > 0
}
