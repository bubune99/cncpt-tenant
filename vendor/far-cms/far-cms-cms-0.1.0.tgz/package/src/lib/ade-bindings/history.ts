/**
 * Versioning & history for Dzidzor — binds the pure core (lib/ade/history)
 * to the database: record / list / get / restore, per-entity adapters, the
 * visibility floor for secrets (never stored) and the viewer's rules for
 * masking personal data on read.
 *
 * Writes go through each entity's chokepoint (e.g. lib/forms/write.ts),
 * which loads the row before, writes, and calls recordRevision with the
 * actor. Restore writes through the same chokepoint, so it is recorded like
 * any other change (a NEW version, reason "restore of vN").
 */

import { AsyncLocalStorage } from 'node:async_hooks'
import { Prisma } from '@prisma/client'
import { prisma } from '../db'
import { DRIFT_REASON, HistoryRefusal, NEVER_RESTORABLE_ENTITIES, planRestore, selectRestore, stateAt, type RestorePlan, type RestorePolicy, diffState, driftChange, maskChange, restoreReason, type Actor, type RevisionRow } from '../ade/history'
import { PRIVATE_VALUE, matchField, maskData } from '../ade/governance/visibility'
import { VISIBILITY_FLOOR } from './visibility-rules'
import { visibilityContext } from './visibility'
import { activeChatRun } from '../ai/agent-runs'
import { noteRevision } from './revision-capture'
import type { UserWithPermissions } from '../permissions/types'

type Obj = Record<string, unknown>

export interface HistoryAdapter {
  entityType: string
  /** Versioned fields of the entity now (null = gone). */
  load(id: string): Promise<Obj | null>
  /** Write fields through the entity's chokepoint, recording the revision with `reason`. */
  save(id: string, patch: Obj, actor: Actor, reason: string): Promise<void>
  /** Permission needed to restore (the entity's edit permission); may depend on the entity. */
  editPermission: string | ((entityId: string) => string)
  /** Only the site owner may restore this entity (governance: who/what can see what). */
  ownerOnly?: (entityId: string) => boolean
  /** Fields never versioned (ids, timestamps, counters). */
  ignore: ReadonlySet<string>
  /** Why it can't be restored right now (e.g. a campaign that was sent), or null. */
  restoreBlocked?(id: string): Promise<string | null>
  /** What people call it ("Volunteer sign-up"), for the timeline and change widgets. */
  nameOf?(id: string): Promise<string | null>
  /** Readable labels for its fields ("fields" → "Questions"). */
  fieldLabels?: Readonly<Record<string, string>>
  /**
   * What a restore may write, field by field (lib/ade/history/policy). No
   * policy = restore is paused for this kind of record (history still shows).
   */
  policy?: RestorePolicy
  /** Fields whose referenced records no longer exist in `target` (field → what's missing). */
  missingRefs?(target: Obj): Promise<Record<string, string | undefined>>
  /**
   * Undoing the version that CREATED it (before = null): writing the empty 'before' back cannot
   * remove it, so the kind says how (media: to the bin, itself undoable). Without it, undo says so.
   */
  undoCreate?(id: string, actor: Actor, reason: string): Promise<void>
  /** After undoCreate: whether the item now reads as undone (gone or in the bin). */
  isUndoneCreate?(now: Obj | null): boolean
}

async function entityNameOf(entityType: string, entityId: string): Promise<string | null> {
  try {
    return (await adapters.get(entityType)?.nameOf?.(entityId)) ?? null
  } catch {
    return null
  }
}

const adapters = new Map<string, HistoryAdapter>()

export function registerHistory(a: HistoryAdapter): void {
  // Customer-owned records are never versioned for restore (lib/ade/history/policy).
  if (NEVER_RESTORABLE_ENTITIES.has(a.entityType)) throw new Error(`${a.entityType} can never be restored — don't register it`)
  adapters.set(a.entityType, a)
}

/** A restore in progress: its new revision records what was restored and skipped. */
const restoring = new AsyncLocalStorage<{ meta: Obj }>()

/** A version kept somewhere else (e.g. pages' own PageRevision snapshots). */
export interface SourceRevision {
  id: string
  version: number
  at: string
  actor: Actor
  reason: string | null
  changed: string[]
  before: Obj
  after: Obj
}

/**
 * An entity whose versions live in its own store: the History API reads
 * them from here instead of ade_revisions (nothing is stored twice), and a
 * restore goes through the source's own restore.
 */
export interface HistorySource {
  entityType: string
  /** Newest first. */
  list(entityId: string): Promise<SourceRevision[]>
  /** Which entity a version id belongs to (null = not this source's). */
  find(id: string): Promise<{ entityId: string } | null>
  /** The entity now and as it was right after version `id`, for planning a restore. */
  restoreState(id: string, viewerId: string | null): Promise<{ version: number; current: Obj; target: Obj; targetSchemaVersion: number; changedSince: string[] } | null>
  /** Write a restore's ticked fields through the source's own path; returns its new version. */
  write(entityId: string, patch: Obj, actor: Actor, reason: string, meta: Obj): Promise<{ revisionId: string | null; version: number | null }>
}

const sources = new Map<string, HistorySource>()

export function registerHistorySource(s: HistorySource): void {
  sources.set(s.entityType, s)
}

async function findInSources(id: string): Promise<{ source: HistorySource; entityId: string } | null> {
  for (const source of sources.values()) {
    const f = await source.find(id)
    if (f) return { source, entityId: f.entityId }
  }
  return null
}

/** Which entity a version id belongs to (ade_revisions or a source), for access checks. */
export async function revisionTarget(id: string): Promise<{ entityType: string; entityId: string } | null> {
  const r = await prisma.adeRevision.findUnique({ where: { id }, select: { entityType: true, entityId: true } })
  if (r) return r
  const f = await findInSources(id)
  return f ? { entityType: f.source.entityType, entityId: f.entityId } : null
}

export function historyAdapter(entityType: string): HistoryAdapter | undefined {
  return adapters.get(entityType)
}

/** The permission that guards editing (and restoring) one entity. */
export function editPermissionFor(entityType: string, entityId: string): string | null {
  const a = adapters.get(entityType)
  if (!a) return null
  return typeof a.editPermission === 'function' ? a.editPermission(entityId) : a.editPermission
}

/** A field the visibility floor blocks (secrets, passwords, payment, sessions): only "changed" is stored. */
export function isSecretField(field: string): boolean {
  return VISIBILITY_FLOOR.some((r) => r.target.kind === 'field' && r.level === 'blocked' && matchField(r.target.name, field))
}

/** Set while an agent change is applied: every write it causes is the agent's. */
const applying = new AsyncLocalStorage<{ actor: Actor; changeSetId: string | null; reason?: string }>()

/**
 * Run an agent change's apply so every revision it causes — however deep the
 * write path — is recorded as the agent's: an approved change links its
 * change set (→ the run that proposed it, approver as the person), a direct-
 * mode change links the chat run itself.
 */
export function withChangeApply<T>(
  item: { changeSetId: string },
  approver: { id?: string | null },
  fn: () => Promise<T>,
  /** A person's own draft (source 'admin'): they are the author, not the assistant. */
  author?: { userId: string | null } | null
): Promise<T> {
  const direct = item.changeSetId === 'direct'
  const run = activeChatRun()
  // Direct mode outside a chat run = a person pressing Publish in an editor.
  const person = author ?? (direct && !run ? { userId: approver.id ?? null } : null)
  const actor: Actor = person
    ? { kind: 'user', userId: person.userId }
    : direct && run
      ? { kind: 'agent', userId: run.userId, runId: run.runId }
      : { kind: 'agent', userId: approver.id ?? null }
  return applying.run({ actor, changeSetId: direct ? null : item.changeSetId, ...(person ? { reason: 'save' } : {}) }, fn)
}

/** The change being applied right now, if any (who and why) — for stores outside ade_revisions (pages). */
export function currentApply(): { actor: Actor; reason?: string } | null {
  const s = applying.getStore()
  return s ? { actor: s.actor, reason: s.reason } : null
}

/** Who is writing, from the request context: the change being applied, the chat run if inside one, else the signed-in user. */
export function actorFor(userId: string | null | undefined): Actor {
  const applied = applying.getStore()
  if (applied) return applied.actor
  const run = activeChatRun()
  return run ? { kind: 'agent', userId: run.userId, runId: run.runId } : { kind: 'user', userId: userId ?? null }
}

export interface WriteContext {
  actor?: Actor
  reason?: string
  changeSetId?: string | null
}

/**
 * Record helpers for an entity whose writers are spread across routes:
 * wrap an update, record a create, record a delete — each one version, the
 * actor defaulting to the change being applied / the chat run / the user.
 */
export function historyRecorder(entityType: string, load: (id: string) => Promise<Obj | null>) {
  const record = (id: string, before: Obj | null, after: Obj | null, ctx: WriteContext, fallback: string) => {
    const actor = ctx.actor ?? actorFor(null)
    return recordRevision({ entityType, entityId: id, before, after, actor, changeSetId: ctx.changeSetId, reason: ctx.reason ?? (actor.kind === 'agent' && fallback === 'save' ? 'ai-edit' : fallback) })
  }
  return {
    load,
    /** Run a write to an existing entity and record it as a version. */
    async update<T>(id: string, ctx: WriteContext, write: () => Promise<T>): Promise<T> {
      const before = await load(id)
      const out = await write()
      await record(id, before, await load(id), ctx, 'save')
      return out
    },
    /** Run a write that changes several entities (bulk move, tag, bin…): one version each. */
    async updateMany<T>(ids: readonly string[], ctx: WriteContext, write: () => Promise<T>): Promise<T> {
      const unique = [...new Set(ids)]
      const before = await Promise.all(unique.map((id) => load(id)))
      const out = await write()
      for (let i = 0; i < unique.length; i++) await record(unique[i], before[i], await load(unique[i]), ctx, 'save')
      return out
    },
    /** Record a just-created entity as version 1. */
    async created(id: string, ctx: WriteContext = {}) {
      return record(id, null, await load(id), ctx, 'create')
    },
    /** Run a delete; the history keeps a last version saying it was deleted. */
    async remove<T>(id: string, ctx: WriteContext, del: () => Promise<T>): Promise<T> {
      const before = await load(id)
      const out = await del()
      if (before) await record(id, before, null, ctx, 'delete')
      return out
    },
  }
}

function isUnique(e: unknown): boolean {
  return e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002'
}

async function rowsFor(entityType: string, entityId: string): Promise<RevisionRow[]> {
  const rows = await prisma.adeRevision.findMany({
    where: { entityType, entityId },
    select: { id: true, version: true, changed: true, before: true, after: true },
    orderBy: { version: 'asc' },
  })
  return rows.map((r) => ({ id: r.id, version: r.version, changed: r.changed, before: r.before as Obj, after: r.after as Obj }))
}

/**
 * Record one change. Detects a write the history didn't see (drift) and
 * records it first, so rebuilding old versions stays right. Never throws —
 * a failed history write is logged, the user's save stands.
 */
export async function recordRevision(args: {
  entityType: string
  entityId: string
  before: Obj | null
  after: Obj | null
  actor: Actor
  changeSetId?: string | null
  reason?: string
  /** Extra fields to treat as secrets (e.g. encrypted settings keys). */
  secretFields?: readonly string[]
}): Promise<{ revisionId: string; version: number } | null> {
  try {
    const a = adapters.get(args.entityType)
    const extra = new Set(args.secretFields ?? [])
    const opts = { ignore: a?.ignore, isSecret: (k: string) => extra.has(k) || isSecretField(k) }
    const change = diffState(args.before, args.after, opts)
    if (!change) return null
    // Inside an agent change's apply, that change is the author (see withChangeApply).
    const scope = applying.getStore()
    const actor = scope?.actor ?? args.actor
    const changeSetId = scope ? scope.changeSetId : args.changeSetId === 'direct' ? null : (args.changeSetId ?? null)
    let runId = actor.runId ?? null
    if (!runId && changeSetId) {
      // An approved agent draft: link the run that proposed it.
      const span = await prisma.agentSpan.findFirst({ where: { changeSetId }, select: { runId: true } })
      runId = span?.runId ?? null
    }
    for (let attempt = 0; attempt < 4; attempt++) {
      const existing = await rowsFor(args.entityType, args.entityId)
      let version = existing.reduce((m, r) => Math.max(m, r.version), 0)
      const drift = args.before ? driftChange(existing, args.before, opts) : null
      try {
        const created = await prisma.$transaction(async (tx) => {
          if (drift) {
            version++
            await tx.adeRevision.create({ data: { entityType: args.entityType, entityId: args.entityId, version, changed: drift.changed, before: drift.before as Prisma.InputJsonValue, after: drift.after as Prisma.InputJsonValue, actorKind: 'system', reason: DRIFT_REASON } })
          }
          version++
          return tx.adeRevision.create({
            data: {
              entityType: args.entityType,
              entityId: args.entityId,
              version,
              changed: change.changed,
              before: change.before as Prisma.InputJsonValue,
              after: change.after as Prisma.InputJsonValue,
              actorKind: actor.kind,
              actorUserId: actor.userId ?? null,
              runId,
              changeSetId,
              reason: scope?.reason ?? args.reason ?? null,
              schemaVersion: a?.policy?.schemaVersion ?? 1,
              ...(restoring.getStore() ? { meta: restoring.getStore()!.meta as Prisma.InputJsonValue } : {}),
            },
            select: { id: true, version: true },
          })
        })
        // The agent tool call that wrote it (if any) reports it: the chat's change card.
        noteRevision({ revisionId: created.id, version: created.version, entityType: args.entityType, entityId: args.entityId })
        return { revisionId: created.id, version: created.version }
      } catch (e) {
        if (isUnique(e) && attempt < 3) continue // two writes raced for the same version: take the next one
        throw e
      }
    }
    return null
  } catch (e) {
    console.error('[history] could not record a revision:', args.entityType, args.entityId, e instanceof Error ? e.message : e)
    return null
  }
}

const PAGE = 50

/** Who each person is, for "Ama changed…" (name, else email). */
async function peopleNames(ids: (string | null)[]): Promise<Map<string, string>> {
  const unique = [...new Set(ids.filter((x): x is string => !!x))]
  if (!unique.length) return new Map()
  const users = await prisma.user.findMany({ where: { id: { in: unique } }, select: { id: true, name: true, email: true } })
  return new Map(users.map((u) => [u.id, u.name?.trim() || u.email]))
}

/** Newest first, without the values (for the timeline). */
export async function listRevisions(entityType: string, entityId: string, opts: { limit?: number; cursor?: number } = {}) {
  const limit = Math.min(Math.max(opts.limit ?? PAGE, 1), 100)
  const source = sources.get(entityType)
  if (source) {
    const all = (await source.list(entityId)).filter((r) => !opts.cursor || r.version < opts.cursor)
    const page = all.slice(0, limit)
    const names = await peopleNames(page.map((r) => r.actor.userId ?? null))
    return {
      entityName: await entityNameOf(entityType, entityId),
      fieldLabels: adapters.get(entityType)?.fieldLabels ?? {},
      revisions: page.map((r) => ({
        id: r.id,
        version: r.version,
        at: r.at,
        actor: { kind: r.actor.kind, userId: r.actor.userId ?? null, runId: r.actor.runId ?? null, name: (r.actor.userId && names.get(r.actor.userId)) || null },
        reason: r.reason,
        changeSetId: null,
        changed: r.changed,
      })),
      nextCursor: all.length > limit ? page[page.length - 1].version : null,
    }
  }
  const rows = await prisma.adeRevision.findMany({
    where: { entityType, entityId, ...(opts.cursor ? { version: { lt: opts.cursor } } : {}) },
    orderBy: { version: 'desc' },
    take: limit + 1,
    select: { id: true, version: true, changed: true, actorKind: true, actorUserId: true, runId: true, changeSetId: true, reason: true, createdAt: true },
  })
  const page = rows.slice(0, limit)
  const names = await peopleNames(page.map((r) => r.actorUserId))
  return {
    entityName: await entityNameOf(entityType, entityId),
    fieldLabels: adapters.get(entityType)?.fieldLabels ?? {},
    revisions: page.map((r) => ({
      id: r.id,
      version: r.version,
      at: r.createdAt.toISOString(),
      actor: { kind: r.actorKind, userId: r.actorUserId, runId: r.runId, name: (r.actorUserId && names.get(r.actorUserId)) || null },
      reason: r.reason,
      changeSetId: r.changeSetId,
      changed: r.changed,
    })),
    nextCursor: rows.length > limit ? page[page.length - 1].version : null,
  }
}

/** One revision with its changed values, private ones masked for the viewer. */
export async function getRevision(id: string, viewer: UserWithPermissions | null) {
  const r = await prisma.adeRevision.findUnique({ where: { id } })
  if (!r) return getSourceRevision(id, viewer)
  const ctx = await visibilityContext(viewer)
  const names = await peopleNames([r.actorUserId])
  const masked = maskChange({ changed: r.changed, before: r.before as Obj, after: r.after as Obj }, (fields) => maskData(fields, ctx.rules, ctx.role).data)
  return {
    id: r.id,
    entityType: r.entityType,
    entityId: r.entityId,
    entityName: await entityNameOf(r.entityType, r.entityId),
    fieldLabels: adapters.get(r.entityType)?.fieldLabels ?? {},
    version: r.version,
    at: r.createdAt.toISOString(),
    actor: { kind: r.actorKind, userId: r.actorUserId, runId: r.runId, name: (r.actorUserId && names.get(r.actorUserId)) || null },
    reason: r.reason,
    changeSetId: r.changeSetId,
    changed: masked.changed,
    before: masked.before,
    after: masked.after,
  }
}

/** A version kept by a source, shaped and masked like getRevision's. */
async function getSourceRevision(id: string, viewer: UserWithPermissions | null) {
  const f = await findInSources(id)
  if (!f) return null
  const r = (await f.source.list(f.entityId)).find((x) => x.id === id)
  if (!r) return null
  const ctx = await visibilityContext(viewer)
  const names = await peopleNames([r.actor.userId ?? null])
  const masked = maskChange({ changed: r.changed, before: r.before, after: r.after }, (fields) => maskData(fields, ctx.rules, ctx.role).data)
  return {
    id: r.id,
    entityType: f.source.entityType,
    entityId: f.entityId,
    entityName: await entityNameOf(f.source.entityType, f.entityId),
    fieldLabels: adapters.get(f.source.entityType)?.fieldLabels ?? {},
    version: r.version,
    at: r.at,
    actor: { kind: r.actor.kind, userId: r.actor.userId ?? null, runId: r.actor.runId ?? null, name: (r.actor.userId && names.get(r.actor.userId)) || null },
    reason: r.reason,
    changeSetId: null,
    changed: masked.changed,
    before: masked.before,
    after: masked.after,
  }
}

/**
 * A version kept by a source (pages' own snapshots) with its REAL values — for Undo
 * (lib/ade-bindings/undo), which plans and writes from them; never returned to a person as is.
 */
export async function sourceRevisionFor(id: string): Promise<{ source: HistorySource; entityType: string; entityId: string; revision: SourceRevision } | null> {
  const f = await findInSources(id)
  if (!f) return null
  const revision = (await f.source.list(f.entityId)).find((x) => x.id === id)
  return revision ? { source: f.source, entityType: f.source.entityType, entityId: f.entityId, revision } : null
}

/** Make the entity look like it did at `version` (0 = before history began). Records a NEW version. */
/** What the person picks from, with values masked for them. */
export interface PlanResult {
  ok: true
  entityType: string
  entityId: string
  plan: RestorePlan
  fieldLabels: Record<string, string>
}
type Refused = { ok: false; status: 400 | 403 | 404 | 409 | 422; error: string }

/** The state to plan from: an ade_revisions version, or a source's own (pages). */
interface RestoreBasis {
  entityType: string
  entityId: string
  version: number
  current: Obj
  target: Obj
  targetSchemaVersion: number
  /** Fields someone other than `viewer` changed after the version. */
  changedSince: Set<string>
  source?: HistorySource
}

async function basisFor(id: string, viewerId: string | null): Promise<RestoreBasis | Refused> {
  const r = await prisma.adeRevision.findUnique({ where: { id }, select: { entityType: true, entityId: true, version: true, schemaVersion: true } })
  if (!r) {
    const f = await findInSources(id)
    if (!f) return { ok: false, status: 404, error: 'No such version' }
    const b = await f.source.restoreState(id, viewerId)
    if (!b) return { ok: false, status: 404, error: 'It no longer exists' }
    return { ...b, entityType: f.source.entityType, entityId: f.entityId, changedSince: new Set(b.changedSince), source: f.source }
  }
  const a = adapters.get(r.entityType)
  if (!a) return { ok: false, status: 422, error: 'This kind of item has no history yet' }
  const current = await a.load(r.entityId)
  if (!current) return { ok: false, status: 404, error: 'It no longer exists' }
  let target: Obj
  try {
    target = stateAt(current, await rowsFor(r.entityType, r.entityId), r.version)
  } catch (e) {
    return { ok: false, status: 409, error: e instanceof Error ? e.message : 'The history can’t rebuild that version' }
  }
  const later = await prisma.adeRevision.findMany({ where: { entityType: r.entityType, entityId: r.entityId, version: { gt: r.version } }, select: { changed: true, actorUserId: true } })
  const changedSince = new Set(later.filter((x) => !viewerId || x.actorUserId !== viewerId).flatMap((x) => x.changed))
  const drop = (o: Obj) => Object.fromEntries(Object.entries(o).filter(([k]) => !a.ignore.has(k)))
  return { entityType: r.entityType, entityId: r.entityId, version: r.version, current: drop(current), target: drop(target), targetSchemaVersion: r.schemaVersion, changedSince }
}

/**
 * What restoring version `id` would do, field by field, for this viewer
 * (lib/ade/history/policy): restorable ticked, guarded unticked with their
 * consequence, conflicts flagged, deleted references / gated values /
 * removed or reshaped fields skipped with why. Values are masked for them.
 */
export async function planRevisionRestore(id: string, viewer: UserWithPermissions | null): Promise<PlanResult | Refused> {
  const b = await basisFor(id, viewer?.id ?? null)
  if (!('version' in b)) return b
  const a = adapters.get(b.entityType)
  if (!a?.policy) return { ok: false, status: 403, error: 'Restoring this kind of item is paused while its restore rules are being set' }
  const blocked = (await a.restoreBlocked?.(b.entityId)) ?? null
  if (blocked) return { ok: false, status: 409, error: blocked }
  const ctx = await visibilityContext(viewer)
  const seen = maskData(b.target, ctx.rules, ctx.role).data as Obj
  const hidden = new Set(Object.keys(b.target).filter((k) => !(k in seen) || seen[k] === PRIVATE_VALUE))
  const plan = planRestore({
    policy: a.policy,
    current: b.current,
    target: b.target,
    fromVersion: b.version,
    targetSchemaVersion: b.targetSchemaVersion,
    changedSince: b.changedSince,
    missingRefs: (await a.missingRefs?.(b.target)) ?? {},
    hidden,
  })
  // What they see: values masked like every other read.
  const shown = plan.fields.map((f) =>
    f.skip?.reason === 'hidden' ? { ...f, current: undefined, restored: undefined } : { ...f, ...(maskData({ current: f.current, restored: f.restored }, ctx.rules, ctx.role).data as Obj) }
  )
  return { ok: true, entityType: b.entityType, entityId: b.entityId, plan: { ...plan, fields: shown as RestorePlan['fields'] }, fieldLabels: { ...(a.fieldLabels ?? {}) } }
}

export type RestoreResult =
  | { ok: true; revisionId: string | null; version: number | null; restored: string[]; skipped: Array<{ field: string; reason: string }>; followUps: string[] }
  | Refused

/**
 * Restore the fields the person ticked from version `id` — never a whole
 * snapshot: only selectable fields of the plan are written. Records a NEW
 * version whose meta says what was restored, from which version, and what
 * was skipped and why.
 */
export async function restoreRevisionFields(id: string, fields: readonly string[], actor: Actor, viewer: UserWithPermissions | null): Promise<RestoreResult> {
  const planned = await planRevisionRestore(id, viewer)
  if (!planned.ok) return planned
  let sel
  try {
    sel = selectRestore(planned.plan, fields)
  } catch (e) {
    return { ok: false, status: 400, error: e instanceof Error ? e.message : 'Choose the fields to restore' }
  }
  // The real (unmasked) values come from the basis, never from what was shown.
  const b = await basisFor(id, viewer?.id ?? null)
  if (!('version' in b)) return b
  const patch = Object.fromEntries(sel.restored.map((k) => [k, b.target[k]]))
  const meta = { restoredFrom: planned.plan.fromVersion, restored: sel.restored, skipped: sel.skipped, followUps: sel.followUps }
  const reason = restoreReason(planned.plan.fromVersion)
  try {
    if (b.source) {
      const w = await b.source.write(b.entityId, patch, actor, reason, meta)
      return { ok: true, revisionId: w.revisionId, version: w.version, restored: sel.restored, skipped: sel.skipped, followUps: sel.followUps }
    }
    const a = adapters.get(b.entityType)!
    await restoring.run({ meta }, () => a.save(b.entityId, patch, actor, reason))
  } catch (e) {
    // An adapter's refusal is the person's answer, not a server error.
    if (e instanceof HistoryRefusal) return { ok: false, status: 403, error: e.message }
    throw e
  }
  const latest = await prisma.adeRevision.findFirst({ where: { entityType: b.entityType, entityId: b.entityId }, orderBy: { version: 'desc' }, select: { id: true, version: true } })
  return { ok: true, revisionId: latest?.id ?? null, version: latest?.version ?? null, restored: sel.restored, skipped: sel.skipped, followUps: sel.followUps }
}

/**
 * Restore version `version` of an entity with the plan's default ticks (or
 * the given fields) — for scripts and tests; people go through
 * restoreRevisionFields with their own ticks.
 */
export async function restoreTo(entityType: string, entityId: string, version: number, actor: Actor, fields?: readonly string[]): Promise<RestoreResult> {
  const r = await prisma.adeRevision.findUnique({ where: { entityType_entityId_version: { entityType, entityId, version } }, select: { id: true } })
  if (!r) return { ok: false, status: 404, error: 'No such version' }
  const planned = await planRevisionRestore(r.id, null)
  if (!planned.ok) return planned
  const ticks = fields ?? planned.plan.fields.filter((f) => f.selected).map((f) => f.field)
  if (!ticks.length) return { ok: true, revisionId: null, version: null, restored: [], skipped: [], followUps: [] }
  return restoreRevisionFields(r.id, ticks, actor, null)
}
