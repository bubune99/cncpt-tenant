/**
 * Dzidzor's storage for the chat history (lib/ade/chat/history
 * ConversationStore): ai_conversations, whose messages, votes and streams
 * cascade; agent_runs by conversation, whose spans cascade. Server only.
 * Another app binds its own tables here; the route and the component stay
 * the same.
 */

import { prisma } from '../db'
import type { ConversationStore } from '../ade/chat/history'

export const chatConversationStore: ConversationStore = {
  async findOwned(userId, id) {
    const row = await prisma.aiConversation.findFirst({ where: { id, userId }, select: { id: true } })
    return row?.id ?? null
  },
  async removeOwned(userId, id) {
    await prisma.$transaction([
      prisma.agentRun.deleteMany({ where: { conversationId: id, userId } }),
      prisma.aiConversation.deleteMany({ where: { id, userId } }),
    ])
  },
}

/** Newest message contents for a list row's preview (lib/ade/chat/history lastPreview skips empty ones). */
export const PREVIEW_LOOKBACK = 6
