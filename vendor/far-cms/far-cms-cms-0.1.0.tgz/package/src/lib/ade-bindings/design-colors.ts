/**
 * This app's design-system colours for the builder's colour picker ("Design system
 * colors"): the site theme's Tailwind colour tokens, by name. Picking one stores the
 * token (text-primary), never a hex. Data only; another app lists its own.
 */

export const DESIGN_COLORS: ReadonlyArray<{ token: string; label: string }> = [
  { token: 'primary', label: 'Brand / Primary' },
  { token: 'secondary', label: 'Brand / Secondary' },
  { token: 'accent', label: 'Brand / Accent' },
  { token: 'foreground', label: 'Text / Default' },
  { token: 'muted-foreground', label: 'Text / Muted' },
  { token: 'primary-foreground', label: 'Text / On primary' },
  { token: 'background', label: 'Surface / Page' },
  { token: 'card', label: 'Surface / Card' },
  { token: 'muted', label: 'Surface / Muted' },
  { token: 'border', label: 'Line / Border' },
  { token: 'destructive', label: 'State / Danger' },
  { token: 'success', label: 'State / Success' },
]

export const designColorLabel = (token: string): string => DESIGN_COLORS.find((c) => c.token === token)?.label ?? token
