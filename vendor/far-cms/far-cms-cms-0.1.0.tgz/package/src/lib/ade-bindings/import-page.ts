/**
 * Importing outside code into a page (the main assistant's importPageCode). The code is written
 * by outsiders, so parts that run script are dropped before anything is drafted, and the draft
 * replaces the page as one To-do item that says where the code came from.
 * Pure: no network, no database. Check: import-page.assert.ts.
 */

type Node = { tag?: string; attrs?: Record<string, string>; children?: Node[]; [k: string]: unknown }

/** Tags that run script or pull in other pages. */
const DROPPED_TAGS = new Set(['script', 'style', 'iframe', 'object', 'embed', 'frame', 'frameset', 'base', 'meta', 'link'])

export const IMPORT_NOTE = 'outside code: check it before approving'

export function cleanImportedBlocks<T extends Node>(blocks: ReadonlyArray<T>): { blocks: T[]; removed: string[] } {
  const removed = new Set<string>()
  const walk = (list: ReadonlyArray<Node>): Node[] =>
    list.flatMap((b) => {
      if (!b || typeof b !== 'object') return []
      const tag = typeof b.tag === 'string' ? b.tag.toLowerCase() : ''
      if (DROPPED_TAGS.has(tag)) {
        removed.add(`<${tag}>`)
        return []
      }
      const next: Node = { ...b }
      if (b.attrs && typeof b.attrs === 'object') {
        const attrs: Record<string, string> = {}
        for (const [k, v] of Object.entries(b.attrs)) {
          if (/^on/i.test(k)) removed.add(k.toLowerCase())
          else attrs[k] = v
        }
        next.attrs = attrs
      }
      if (Array.isArray(b.children)) next.children = walk(b.children)
      return [next]
    })
  return { blocks: walk(blocks) as T[], removed: [...removed] }
}

/** The page's content with its blocks replaced; its other settings (version, layout, CSS) kept. */
export function importedContent(existing: unknown, blocks: unknown[]): Record<string, unknown> {
  const base = existing && typeof existing === 'object' && !Array.isArray(existing) ? (existing as Record<string, unknown>) : { version: '2.0' }
  return { ...base, blocks }
}

/** Where the code came from, in words: "pasted code" or "code imported from github:…". */
export function sourcePhrase(source: string): string {
  return source === 'paste' ? 'pasted code' : `code imported from ${source}`
}

export function importSummary(title: string, source: string): string {
  return `Replace “${title}” with ${sourcePhrase(source)}`
}
