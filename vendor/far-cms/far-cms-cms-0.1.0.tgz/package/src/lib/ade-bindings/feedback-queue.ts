/**
 * 'feedback.send' on the offline queue: the Send feedback button queues it
 * (after the part's picture, if any, as 'feedback.screenshot' in the same
 * group — stored privately, never in the public media library),
 * so feedback from a phone with a weak signal goes when the signal allows.
 * Client side; imported once by the admin shell.
 */

import { registerQueueAction } from '../ade/offline/queue'
import { ApiError, classifyApiError } from '../ade/mobile/phone-draft'
import { feedbackBody, type FeedbackKind, type FeedbackUnit } from '../ade/feedback/feedback'

export const FEEDBACK_QUEUE_TYPE = 'feedback.send'
export const FEEDBACK_SHOT_TYPE = 'feedback.screenshot'

export interface FeedbackQueuePayload {
  kind: FeedbackKind
  note: string
  route: string
  unit: FeedbackUnit | null
  /** The part's picture's queue key (its 'feedback.screenshot' dedupeKey). */
  shotKey?: string
}

// The picture: raw bytes to the private screenshot store (security review F-4), result { id }.
registerQueueAction({
  type: FEEDBACK_SHOT_TYPE,
  run: async (_item, { blob, signal }) => {
    if (!blob) throw new ApiError('The picture is no longer on this device', 410)
    const res = await fetch('/api/admin/feedback/screenshots', { method: 'POST', headers: { 'Content-Type': blob.type || 'image/jpeg' }, body: blob, signal })
    const data = (await res.json().catch(() => ({}))) as { id?: string; error?: string }
    if (!res.ok || !data.id) throw new ApiError(data.error || 'The picture couldn’t be sent', res.status)
    return { id: data.id }
  },
  retry: { max: 8 },
  classify: classifyApiError,
})

registerQueueAction({
  type: FEEDBACK_QUEUE_TYPE,
  run: async (item, { resultOf, signal }) => {
    const p = item.payload as FeedbackQueuePayload
    const shot = p.shotKey ? (resultOf(p.shotKey) as { id?: string } | undefined)?.id ?? null : null
    const res = await fetch('/api/admin/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // The queue item id is the idempotency key: a retry after a lost response returns the first row (F-6).
      body: JSON.stringify(feedbackBody({ ...p, dedupeKey: item.id }, shot)),
      signal,
    })
    const data = (await res.json().catch(() => ({}))) as { id?: string; error?: string }
    if (!res.ok) throw new ApiError(data.error || 'The feedback couldn’t be sent', res.status)
    return { id: data.id }
  },
  retry: { max: 8 },
  classify: classifyApiError,
})
