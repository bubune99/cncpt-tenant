/**
 * Loads every entity's history adapter (each registers itself next to its
 * write chokepoint). Import this wherever history is read or restored.
 */
import '../forms/write'
import '../settings/history'
import '../partials/write'
import '../site-settings/history'
import '../blog/history'
import '../email/history'
import '../media/history'
import '../permissions/history'
import '../pages/history'

export { editPermissionFor, historyAdapter, listRevisions, getRevision, planRevisionRestore, restoreRevisionFields, restoreTo, revisionTarget, sourceRevisionFor } from './history'
