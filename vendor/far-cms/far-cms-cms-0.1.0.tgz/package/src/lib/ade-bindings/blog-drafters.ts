/**
 * Blog posts through review. A person's edits in the post editor and the
 * assistant's updateBlogPost both draft the WHOLE post document
 * (lib/blog/post-doc) as one `blog-post` item; approval in To-do writes it.
 * Publishing / unpublishing is its own `blog-status` item (publishBlogPost)
 * — never part of an edit, so "the assistant can't publish without
 * approval" holds for people too.
 *
 *   blog-post    snapshot = { doc }        (saveBlogDraft, updateBlogPost)
 *   blog-status  snapshot = { status, scheduledAt }   (publishBlogPost)
 */

import type { Prisma } from '@prisma/client'
import { prisma } from '../db'
import type { ChangeSetItemRecord, Drafter, ProposedChange, TargetAdapter } from '../ade'
import { docToUpdateInput, normalizePostDoc, patchFromToolInput, postDocChanges, validatePostDoc, type PostDoc } from '../blog/post-doc'
import { revalidateStorefront } from '../revalidate'
import { withPostHistory } from '../blog/history'
import { goesLiveLabel, isTimeZone, safeTimeZone } from '../publishing/schedule'

export interface PostSnapshot {
  doc: PostDoc
}

const ID = /^[A-Za-z0-9_-]{1,80}$/

/** The live post as a document (deterministic, so stale checks compare cleanly). */
export async function livePostDoc(id: string): Promise<PostDoc | null> {
  const row = await prisma.blogPost.findUnique({
    where: { id },
    select: {
      title: true, slug: true, excerpt: true, content: true, contentHtml: true, visibility: true, authorId: true,
      featured: true, homeOrder: true, allowComments: true, metaTitle: true, metaDescription: true,
      featuredImageId: true, ogImageId: true,
      categories: { select: { categoryId: true }, orderBy: { position: 'asc' } },
      tags: { select: { tagId: true } },
    },
  })
  return row ? normalizePostDoc(row as unknown as Record<string, unknown>) : null
}

/** Pictures must be Media library items that still exist. */
async function checkMedia(doc: PostDoc): Promise<string | null> {
  const want = [doc.coverMediaId, doc.shareMediaId].filter((x): x is string => !!x)
  if (!want.length) return null
  const found = await prisma.media.count({ where: { id: { in: want }, deletedAt: null } })
  return found === new Set(want).size ? null : 'Choose the picture from the Media library (upload it there first).'
}

async function draftDoc(id: string, doc: PostDoc, pending: ChangeSetItemRecord | null, by: 'editor' | 'assistant'): Promise<ProposedChange | { error: string }> {
  const live = await livePostDoc(id)
  if (!live) return { error: 'Blog post not found' }
  const before: PostSnapshot = pending ? (pending.before as PostSnapshot) : { doc: live }
  const invalid = validatePostDoc(doc, before.doc) ?? (await checkMedia(doc))
  if (invalid) return { error: invalid }
  const changes = postDocChanges(before.doc, doc)
  if (!changes.length && !pending) return { error: 'Nothing has changed' }
  return {
    targetType: 'blog-post',
    targetId: id,
    operation: 'update',
    category: pending?.category === 'publish' ? 'publish' : 'blog',
    before,
    after: { doc } satisfies PostSnapshot,
    input: { post: id, title: doc.title, changes, by },
    blockIds: [],
    summary: `Edit post “${doc.title || live.title}”`,
  }
}

/** The post editor: the whole document. */
const draftEditor: Drafter['draft'] = async (input, pending) => {
  const id = typeof input.post === 'string' && ID.test(input.post) ? input.post : null
  if (!id) return { error: 'post is required' }
  if (!input.doc || typeof input.doc !== 'object') return { error: 'doc is required' }
  return draftDoc(id, normalizePostDoc(input.doc as Record<string, unknown>), pending, 'editor')
}

/** The assistant: the named fields on top of the pending draft (or live post). */
const draftToolUpdate: Drafter['draft'] = async (input, pending) => {
  const id = typeof input.id === 'string' && ID.test(input.id) ? input.id : null
  if (!id) return { error: 'A blog post id is required' }
  const { patch, status } = patchFromToolInput(input)
  if (status !== undefined) return { error: 'Publishing or unpublishing is its own step: use publishBlogPost (status PUBLISHED, DRAFT or ARCHIVED).' }
  if (!Object.keys(patch).length) return { error: 'No fields to change were provided' }
  const base = pending ? (pending.after as PostSnapshot).doc : await livePostDoc(id)
  if (!base) return { error: 'Blog post not found' }
  return draftDoc(id, { ...base, ...patch }, pending, 'assistant')
}

const byPost = (key: 'post' | 'id') => async (input: Record<string, unknown>) =>
  typeof input[key] === 'string' && ID.test(input[key] as string) ? { targetType: 'blog-post', targetId: input[key] as string } : { error: 'A blog post id is required' }

/** Write a post document (approval). Same rules as the old PUT: unique web address, word count. */
async function applyPostDoc(id: string, doc: PostDoc): Promise<void> {
  const existing = await prisma.blogPost.findUnique({ where: { id }, select: { slug: true } })
  if (!existing) throw new Error('The post no longer exists')
  if (doc.slug !== existing.slug && (await prisma.blogPost.findFirst({ where: { slug: doc.slug, NOT: { id } }, select: { id: true } }))) {
    throw new Error(`Another post already uses /posts/${doc.slug}`)
  }
  const media = await checkMedia(doc)
  if (media) throw new Error(media)
  const data = docToUpdateInput(doc)
  const words = doc.contentHtml ? doc.contentHtml.replace(/<[^>]*>/g, ' ').split(/\s+/).filter(Boolean).length : 0
  const { categoryIds, tagIds, ...fields } = data as Record<string, unknown> & { categoryIds: string[]; tagIds: string[] }
  await withPostHistory(id, {}, () => prisma.$transaction([
    prisma.blogPostCategory.deleteMany({ where: { postId: id } }),
    prisma.blogPostTag.deleteMany({ where: { postId: id } }),
    prisma.blogPost.update({
      where: { id },
      data: {
        ...(fields as Prisma.BlogPostUncheckedUpdateInput),
        wordCount: words,
        readingTime: Math.ceil(words / 200),
        categories: { create: categoryIds.map((categoryId, position) => ({ categoryId, position })) },
        tags: { create: tagIds.map((tagId) => ({ tagId })) },
      },
    }),
  ]))
}

export const BLOG_DRAFTERS: Readonly<Record<string, Drafter>> = {
  saveBlogDraft: { target: byPost('post'), draft: draftEditor },
  updateBlogPost: { target: byPost('id'), draft: draftToolUpdate },
}

/**
 * Updates write the document; creates still run the assistant's tool
 * (createBlogPost — a new DRAFT post).
 */
export function blogPostAdapter(createViaTool: (input: Record<string, unknown>) => Promise<string | undefined>): TargetAdapter {
  return {
    async snapshot(id) {
      const doc = await livePostDoc(id)
      return doc ? ({ doc } satisfies PostSnapshot) : null
    },
    async apply(item) {
      if (item.operation === 'create') return { resultId: await createViaTool(item.input) }
      const id = item.targetId!
      await applyPostDoc(id, normalizePostDoc((item.after as PostSnapshot).doc as unknown as Record<string, unknown>))
      revalidateStorefront()
      return { resultId: id }
    },
  }
}

// ---------------------------------------------------------------------------
// blog-status: publish / schedule / unpublish (one publish change)
// ---------------------------------------------------------------------------

export interface BlogStatusSnapshot {
  status: unknown
  scheduledAt: string | null
}

export async function blogStatus(id: string): Promise<BlogStatusSnapshot | null> {
  const post = await prisma.blogPost.findUnique({ where: { id }, select: { status: true, scheduledAt: true } })
  return post ? { status: post.status, scheduledAt: post.scheduledAt ? post.scheduledAt.toISOString() : null } : null
}

const STATUS_WORD: Record<string, string> = { PUBLISHED: 'Publish', DRAFT: 'Unpublish', ARCHIVED: 'Archive' }

export const draftPublishBlogPost: Drafter['draft'] = async (input, pending) => {
  const id = typeof input.id === 'string' && ID.test(input.id) ? input.id : null
  if (!id) return { error: 'A blog post id is required' }
  const post = await prisma.blogPost.findUnique({ where: { id }, select: { title: true } })
  const live = await blogStatus(id)
  if (!post || !live) return { error: 'Blog post not found' }
  const scheduledAt = typeof input.scheduledAt === 'string' ? input.scheduledAt : undefined
  if (scheduledAt && Number.isNaN(new Date(scheduledAt).getTime())) return { error: 'Invalid date format' }
  const status = input.status === undefined ? 'PUBLISHED' : String(input.status)
  if (!(status in STATUS_WORD)) return { error: 'status must be PUBLISHED, DRAFT or ARCHIVED' }
  if (scheduledAt && status !== 'PUBLISHED') return { error: 'Only publishing can be scheduled' }
  const after: BlogStatusSnapshot = scheduledAt
    ? { status: 'SCHEDULED', scheduledAt: new Date(scheduledAt).toISOString() }
    : { status, scheduledAt: status === 'PUBLISHED' ? live.scheduledAt : null }
  return {
    targetType: 'blog-status',
    targetId: id,
    operation: 'update',
    category: 'publish',
    before: pending ? (pending.before as BlogStatusSnapshot) : live,
    after,
    input: { id, ...(scheduledAt ? { scheduledAt, ...(isTimeZone(input.tz) ? { tz: input.tz } : {}) } : {}), ...(status !== 'PUBLISHED' ? { status } : {}) },
    blockIds: [],
    summary: scheduledAt ? `Schedule post “${post.title}” — ${goesLiveLabel(new Date(scheduledAt), { timeZone: safeTimeZone(input.tz) })}` : `${STATUS_WORD[status]} post “${post.title}”`,
  }
}

/** Publish/schedule runs the assistant's tool; unpublish/archive writes the status. */
export function blogStatusAdapter(publishViaTool: (input: Record<string, unknown>) => Promise<void>): TargetAdapter {
  return {
    snapshot: (id) => blogStatus(id),
    async apply(item) {
      const id = item.targetId!
      const status = item.input.status
      if (status === 'DRAFT' || status === 'ARCHIVED') {
        await withPostHistory(id, {}, () => prisma.blogPost.update({ where: { id }, data: { status, scheduledAt: null } }))
      } else {
        await publishViaTool(item.input)
      }
      revalidateStorefront()
      return { resultId: id }
    },
  }
}
