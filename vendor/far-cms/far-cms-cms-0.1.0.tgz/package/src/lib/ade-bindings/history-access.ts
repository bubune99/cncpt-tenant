/**
 * Who may read / restore an entity's history: its edit permission; audit
 * readers may read; governance (ownerOnly) is owner-only to restore. One
 * rule for the history routes and the chat's change cards.
 */
import { checkPermission } from '../permissions'
import type { UserWithPermissions } from '../permissions/types'
import { editPermissionFor, historyAdapter } from './history-adapters'
import { viewerRole } from './visibility'

export function canReadHistory(perms: UserWithPermissions, entityType: string, entityId: string): boolean {
  const perm = editPermissionFor(entityType, entityId)
  if (!perm) return false
  return checkPermission(perms, perm).allowed || checkPermission(perms, 'audit.view').allowed
}

export function canRestoreHistory(perms: UserWithPermissions, entityType: string, entityId: string): boolean {
  const a = historyAdapter(entityType)
  const perm = editPermissionFor(entityType, entityId)
  if (!a || !perm || !checkPermission(perms, perm).allowed) return false
  // A restore can loosen who/what sees what: only the owner, as on the screens themselves.
  if (a.ownerOnly?.(entityId) && viewerRole(perms) !== 'owner') return false
  return true
}

/** Both rights at once: the history routes and the chat's change cards. */
export function historyRightsFor(perms: UserWithPermissions, entityType: string, entityId: string): { read: boolean; restore: boolean } {
  return { read: canReadHistory(perms, entityType, entityId), restore: canRestoreHistory(perms, entityType, entityId) }
}
