/**
 * Forms through review: a person's (or the assistant's) edits to a form —
 * questions, settings, placement, automations — are drafted as ONE whole
 * document (lib/forms/doc) and applied on approval, like partials.
 *
 * Target type `form`: snapshot = { doc }, apply = write the document's
 * columns (never the slug or the submission counter). The plain-words list
 * of what changed rides along in input.changes for the review card.
 */

import type { Prisma } from '@prisma/client'
import { prisma } from '../db'
import type { ChangeSetItemRecord, Drafter, ProposedChange, TargetAdapter } from '../ade'
import { docRowPatch, docToRow, formDocChanges, normalizeFormDoc, type FormDoc } from '../forms/doc'
import { writeForm } from '../forms/write'
import { normalizeRules } from '../forms/automations'
import { revalidateStorefront } from '../revalidate'

export interface FormSnapshot {
  doc: FormDoc
}

const ID = /^[A-Za-z0-9_-]{1,80}$/

async function liveForm(id: string) {
  return prisma.form.findUnique({
    where: { id },
    select: { id: true, name: true, description: true, status: true, submitButtonText: true, successMessage: true, notifyEmails: true, fields: true, display: true, automations: true, captchaEnabled: true, retentionMonths: true },
  })
}

/** The live form as a document (deterministic, so stale checks compare cleanly). */
export async function liveFormDoc(id: string): Promise<FormDoc | null> {
  const row = await liveForm(id)
  return row ? normalizeFormDoc(row as unknown as Record<string, unknown>) : null
}

async function draftForm(input: Record<string, unknown>, pending: ChangeSetItemRecord | null): Promise<ProposedChange | { error: string }> {
  const id = typeof input.form === 'string' && ID.test(input.form) ? input.form : null
  if (!id) return { error: 'form is required' }
  if (!input.doc || typeof input.doc !== 'object') return { error: 'doc is required' }
  const live = await liveFormDoc(id)
  if (!live) return { error: 'Form not found' }
  const before: FormSnapshot = pending ? (pending.before as FormSnapshot) : { doc: live }
  const after = normalizeFormDoc(input.doc as Record<string, unknown>)
  const changes = formDocChanges(before.doc, after)
  if (!changes.length && !pending) return { error: 'Nothing has changed' }
  return {
    targetType: 'form',
    targetId: id,
    operation: 'update',
    category: 'forms',
    before,
    after: { doc: after } satisfies FormSnapshot,
    input: { form: id, name: after.name, changes },
    blockIds: [],
    summary: `Your changes to the “${after.name}” form`,
  }
}

/** A form by id, slug or (exact, case-insensitive) name — the assistant's way of naming it. */
export async function findFormRow(ref: string) {
  const r = ref.trim()
  if (!r) return null
  return (
    (await prisma.form.findFirst({ where: { OR: [{ id: r }, { slug: r }] }, select: { id: true, slug: true } })) ??
    (await prisma.form.findFirst({ where: { name: { equals: r, mode: 'insensitive' } }, select: { id: true, slug: true } }))
  )
}

/** The assistant's automations edit: the pending draft (or live form) with its rules replaced. */
async function draftAutomations(input: Record<string, unknown>, pending: ChangeSetItemRecord | null): Promise<ProposedChange | { error: string }> {
  const row = typeof input.form === 'string' ? await findFormRow(input.form) : null
  if (!row) return { error: 'Form not found' }
  if (!Array.isArray(input.automations)) return { error: 'automations is required' }
  const base = pending ? (pending.after as FormSnapshot).doc : await liveFormDoc(row.id)
  if (!base) return { error: 'Form not found' }
  const automations = normalizeRules(input.automations)
  if (automations.length < input.automations.length) return { error: 'Some rules were not valid (unknown action or missing details) — call getForm for the catalog.' }
  return draftForm({ form: row.id, doc: { ...base, automations } }, pending)
}

export const FORM_DRAFTERS: Readonly<Record<string, Drafter>> = {
  saveFormDraft: {
    target: async (input) => (typeof input.form === 'string' && ID.test(input.form) ? { targetType: 'form', targetId: input.form } : { error: 'form is required' }),
    draft: draftForm,
  },
  setFormAutomations: {
    target: async (input) => {
      const row = typeof input.form === 'string' ? await findFormRow(input.form) : null
      return row ? { targetType: 'form', targetId: row.id } : { error: 'Form not found' }
    },
    draft: draftAutomations,
  },
}

export const formAdapter: TargetAdapter = {
  async snapshot(id) {
    const doc = await liveFormDoc(id)
    return doc ? ({ doc } satisfies FormSnapshot) : null
  },
  async apply(item, actor) {
    const id = item.targetId!
    const live = await liveFormDoc(id)
    if (!live) throw new Error('The form no longer exists')
    const doc = normalizeFormDoc((item.after as FormSnapshot).doc as unknown as Record<string, unknown>)
    // Write only what the draft changes: normalizing defaults is not a change.
    const patch = docRowPatch(live, doc)
    if (!Object.keys(patch).length) return { resultId: id, revisionId: null, version: null }
    // The agent's draft, approved by `actor`: one version, linked to its change set (and run).
    const { revision } = await writeForm(id, patch as unknown as Prisma.FormUpdateInput, {
      actor: { kind: 'agent', userId: actor.id },
      changeSetId: item.changeSetId,
      reason: 'ai-edit',
    })
    revalidateStorefront()
    return { resultId: id, revisionId: revision?.revisionId ?? null, version: revision?.version ?? null }
  },
}
