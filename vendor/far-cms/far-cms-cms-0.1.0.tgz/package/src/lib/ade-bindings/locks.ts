/**
 * Edit locks, stored (ade_edit_locks). The rules live in lib/ade/locks; this
 * file only reads and writes claims, race-safely: a claim is created on the
 * primary key, or replaced only when it still looks exactly as we read it
 * (optimistic check), so two people opening a page at once can't both win.
 * `now` is injectable so the scenario tests can step time.
 */

import { prisma } from '../db'
import {
  agentMayEdit,
  approvalWarning,
  decideAcquire,
  lockKeyFor,
  lockStateFor,
  type Claimant,
  type EditLock,
  type LockState,
} from '../ade'

export type LockView = LockState | { kind: 'free' }

function toLock(row: {
  targetKey: string
  userId: string
  userName: string | null
  tabId: string
  heartbeatAt: Date
  requestedById: string | null
  requestedByName: string | null
}): EditLock {
  return { ...row }
}

export async function readLock(targetKey: string): Promise<EditLock | null> {
  const row = await prisma.adeEditLock.findUnique({ where: { targetKey } })
  return row ? toLock(row) : null
}

export async function viewLock(targetKey: string, me: Claimant, now = new Date()): Promise<LockView> {
  return lockStateFor(await readLock(targetKey), me, now)
}

/** Take or renew a claim. Returns how the target looks to `me` afterwards. */
export async function acquireLock(
  targetKey: string,
  me: Claimant,
  opts: { now?: Date; moveFromOtherTab?: boolean } = {},
  attempt = 0
): Promise<LockView> {
  const now = opts.now ?? new Date()
  const existing = await readLock(targetKey)
  const decision = decideAcquire(existing, me, now, { moveFromOtherTab: opts.moveFromOtherTab })
  if (!decision.granted) return decision.state
  const data = {
    userId: me.userId,
    userName: me.userName,
    tabId: me.tabId,
    heartbeatAt: now,
    requestedById: decision.lock.requestedById ?? null,
    requestedByName: decision.lock.requestedByName ?? null,
    requestedAt: decision.lock.requestedById ? undefined : null,
  }
  try {
    if (!existing) {
      // skipDuplicates: someone created it between our read and write → decide again.
      const c = await prisma.adeEditLock.createMany({ data: [{ targetKey, ...data, requestedAt: null }], skipDuplicates: true })
      if (c.count === 0) throw new Error('raced')
    } else {
      // Only replace the claim we decided on; if it moved meanwhile, decide again.
      const r = await prisma.adeEditLock.updateMany({
        where: { targetKey, userId: existing.userId, tabId: existing.tabId, heartbeatAt: existing.heartbeatAt },
        data: existing.userId === me.userId && existing.tabId === me.tabId ? { heartbeatAt: now, userName: me.userName } : { ...data, acquiredAt: now },
      })
      if (r.count === 0) throw new Error('raced')
    }
  } catch (error) {
    if (attempt < 2) return acquireLock(targetKey, me, opts, attempt + 1)
    throw error
  }
  return { kind: 'mine', lock: { targetKey, ...data } as EditLock }
}

/** Let go of my claim (leaving the page, handing it over). */
export async function releaseLock(targetKey: string, me: Pick<Claimant, 'userId' | 'tabId'>): Promise<void> {
  await prisma.adeEditLock.deleteMany({ where: { targetKey, userId: me.userId, tabId: me.tabId } })
}

/** Ask the holder to hand over. */
export async function requestLock(targetKey: string, me: Claimant, now = new Date()): Promise<LockView> {
  await prisma.adeEditLock.updateMany({
    where: { targetKey, NOT: { userId: me.userId } },
    data: { requestedById: me.userId, requestedByName: me.userName, requestedAt: now },
  })
  return viewLock(targetKey, me, now)
}

/** The holder keeps editing: dismiss the request. */
export async function clearLockRequest(targetKey: string, me: Pick<Claimant, 'userId'>): Promise<void> {
  await prisma.adeEditLock.updateMany({ where: { targetKey, userId: me.userId }, data: { requestedById: null, requestedByName: null, requestedAt: null } })
}

/** Can the assistant (acting for `userId`) change this target? */
export async function agentLockCheck(targetType: string, targetId: string | null, userId: string | null, now = new Date()) {
  const key = lockKeyFor(targetType, targetId)
  if (!key) return { ok: true as const }
  return agentMayEdit(await readLock(key), userId, now)
}

/** Warnings for approving items whose page/record someone else is editing. */
export async function approvalLockWarnings(
  items: ReadonlyArray<{ targetType: string; targetId: string | null }>,
  reviewerId: string | null,
  now = new Date()
): Promise<string[]> {
  const keys = Array.from(new Set(items.map((i) => lockKeyFor(i.targetType, i.targetId)).filter((k): k is string => !!k)))
  if (!keys.length) return []
  const rows = await prisma.adeEditLock.findMany({ where: { targetKey: { in: keys } } })
  return Array.from(new Set(rows.map((r) => approvalWarning(toLock(r), reviewerId, now)).filter((w): w is string => !!w)))
}
