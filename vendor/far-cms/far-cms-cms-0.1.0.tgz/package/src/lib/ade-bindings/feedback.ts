/**
 * Client feedback, stored: the row is written FIRST (status 'new'), then
 * forwarded to the owner's planner + email by settings-n's channels
 * (lib/ade-bindings/feedback-channels: never throws, idempotent, the hourly
 * cron retries anything still 'new'). Nothing is lost when forwarding
 * fails. Server only.
 */

import { runAfter } from '../http/run-after'
import { prisma } from '../db'
import { DUPLICATE_NOTE_WINDOW_MS, type FeedbackInput } from '../ade/feedback/feedback'
import { entryForRoute } from '../ade/platform-map'
import { dzidzorPlatformMap } from './platform-map'
import { MOBILE_INBOX } from './mobile-inbox'
import { feedbackNotifyEmail, forwardFeedback } from './feedback-channels'
import { plannerConfigFrom } from '../ade/feedback/planner'

export interface FeedbackSender {
  id: string
  /** Display name only — the email never goes into feedback. */
  name: string | null
}

/** The screen's name as the menu shows it ("Initiatives"), from the route — never a record's own title. */
export async function screenNameFor(route: string): Promise<string> {
  try {
    const { getNavigationSettings } = await import('../settings')
    const { overrides } = await getNavigationSettings()
    // Names aren't secret: every area is in the map, whoever is asking.
    const map = dzidzorPlatformMap({ commerceEnabled: true, access: { isOwner: true, agentActivity: true }, overrides, emailInbox: MOBILE_INBOX.emailSegment })
    return entryForRoute(map, route)?.name ?? ''
  } catch {
    return ''
  }
}

/**
 * F-4/F-5: a screenshot id is kept only if it is a private feedback screenshot
 * (FeedbackScreenshot) this person uploaded in the last day; anything else is dropped.
 */
async function ownScreenshot(senderId: string, id: string | null): Promise<string | null> {
  if (!id) return null
  const row = await prisma.feedbackScreenshot.findFirst({ where: { id, createdById: senderId, createdAt: { gte: new Date(Date.now() - 86_400_000) } }, select: { id: true } })
  return row?.id ?? null
}

/**
 * The row for this send: a retry with the same client key (F-6), or the same
 * note from the same person within DUPLICATE_NOTE_WINDOW_MS (F-2), returns
 * the first row instead of filing it twice.
 */
async function existingFor(sender: FeedbackSender, input: FeedbackInput, key: string | null): Promise<{ id: string } | null> {
  if (key) {
    const byKey = await prisma.clientFeedback.findUnique({ where: { dedupeKey: key }, select: { id: true } })
    if (byKey) return byKey
  }
  return prisma.clientFeedback.findFirst({
    where: { createdById: sender.id, note: input.note, createdAt: { gte: new Date(Date.now() - DUPLICATE_NOTE_WINDOW_MS) } },
    select: { id: true },
  })
}

export async function saveFeedback(sender: FeedbackSender, input: FeedbackInput): Promise<{ id: string; duplicate: boolean }> {
  // Scoped to the sender, so one person's key can never claim another's.
  const key = input.clientKey ? `${sender.id}:${input.clientKey}`.slice(0, 160) : null
  const existing = await existingFor(sender, input, key)
  if (existing) return { ...existing, duplicate: true }
  try {
    const row = await prisma.clientFeedback.create({
      data: {
        createdById: sender.id,
        senderName: (sender.name ?? '').trim().slice(0, 120),
        route: input.route,
        screen: (await screenNameFor(input.route)).slice(0, 120),
        unitRef: input.unitRef,
        note: input.note,
        kind: input.kind,
        screenshotMediaId: await ownScreenshot(sender.id, input.screenshotMediaId),
        dedupeKey: key,
        status: 'new',
      },
      select: { id: true },
    })
    return { ...row, duplicate: false }
  } catch (e) {
    // Two sends with one key at once: the loser returns the winner's row.
    if (key && (e as { code?: string })?.code === 'P2002') {
      const row = await prisma.clientFeedback.findUnique({ where: { dedupeKey: key }, select: { id: true } })
      if (row) return { ...row, duplicate: true }
    }
    throw e
  }
}

/** Store, then forward after the response (the cron picks up anything that didn't go). A repeat is never forwarded twice. */
export async function fileFeedback(sender: FeedbackSender, input: FeedbackInput): Promise<{ id: string; duplicate: boolean }> {
  const saved = await saveFeedback(sender, input)
  if (saved.duplicate) return saved
  // With forwarding not set up, the owner's To-do task shows it now — not after the next refresh.
  if (Object.values(feedbackSetup()).some((ok) => !ok)) {
    await import('./queries').then((q) => q.refreshFeedbackSetupTask()).catch((e) => console.warn('[feedback] To-do task not refreshed:', e instanceof Error ? e.name : 'error'))
  }
  try {
    runAfter(() => forwardFeedback(saved.id))
  } catch {
    // Outside a request (scripts): forward now; it never throws.
    await forwardFeedback(saved.id)
  }
  return saved
}

/** Which forwarding channels have their settings (env vars) — names only, never values. */
export function feedbackSetup(env: Record<string, string | undefined> = process.env): { planner: boolean; email: boolean } {
  return { planner: plannerConfigFrom(env) !== null, email: feedbackNotifyEmail(env) !== null }
}

// ── The owner's list (To-do › Client feedback; settings.general) ──────────

export interface FeedbackListItem {
  id: string
  kind: string
  screen: string
  route: string
  unitRef: string | null
  note: string
  senderName: string
  createdAt: string
  status: string
  screenshotId: string | null
  delivery: { label: string; detail?: string }
}

export async function listFeedback(limit = 100): Promise<FeedbackListItem[]> {
  const rows = await prisma.clientFeedback.findMany({
    orderBy: { createdAt: 'desc' },
    take: Math.min(Math.max(limit, 1), 200),
    select: { id: true, kind: true, screen: true, route: true, unitRef: true, note: true, senderName: true, createdAt: true, status: true, screenshotMediaId: true },
  })
  const { feedbackDeliveryStatus } = await import('./feedback-channels')
  const delivery = await feedbackDeliveryStatus(rows.map((r) => r.id))
  return rows.map((r) => ({
    id: r.id,
    kind: r.kind,
    screen: r.screen,
    route: r.route,
    unitRef: r.unitRef,
    note: r.note,
    senderName: r.senderName,
    createdAt: r.createdAt.toISOString(),
    status: r.status,
    screenshotId: r.screenshotMediaId,
    delivery: delivery[r.id] ?? { label: 'Sending' },
  }))
}

/** Triaged: the owner has seen it. Forwarding never touches a triaged row again. */
export async function markFeedbackTriaged(id: string): Promise<boolean> {
  const r = await prisma.clientFeedback.updateMany({ where: { id }, data: { status: 'triaged' } })
  return r.count === 1
}

/** Delete an item with its delivery rows and its private screenshot (nothing else points at them). */
export async function deleteFeedback(id: string): Promise<boolean> {
  const row = await prisma.clientFeedback.findUnique({ where: { id }, select: { screenshotMediaId: true } })
  if (!row) return false
  await prisma.$transaction([
    prisma.feedbackDelivery.deleteMany({ where: { feedbackId: id } }),
    ...(row.screenshotMediaId ? [prisma.feedbackScreenshot.deleteMany({ where: { id: row.screenshotMediaId } })] : []),
    prisma.clientFeedback.delete({ where: { id } }),
  ])
  return true
}
