/**
 * "Approve and publish" for an initiative sent from a phone (mock 10): one
 * tap for an approver who may publish — approve the draft (record + page),
 * then publish it through the same governed path as the desktop
 * (publishRecord, after the ready-to-publish checklist). If the checklist
 * isn't met, it stays approved as a draft and says what's missing.
 */

import { prisma } from '../../db'
import { checkPermission } from '../../permissions'
import type { UserWithPermissions } from '../../permissions/types'
import { blockingItems } from '../../ade/records/checklist'
import { changeSets } from '..'
import { canApprove, loadItems } from '../queries'
import { approvalLockWarnings } from '../locks'
import { removedTargetItemIds } from '../orphans'
import { getRecordRow, snapshotOf } from '../records'
import { effectiveRecordData } from '../record-drafters'
import { recordChecklist, relaxForPhone, REVIEWED_ITEM } from '../record-checklist'

export type ApprovePublishOutcome =
  | { ok: true; published: boolean; recordId: string | null; notYet?: string; later?: string[] }
  | { ok: false; status: number; error: string; lockWarnings?: string[] }

export async function approveAndPublish(perms: UserWithPermissions, actor: { id: string; email: string | null }, changeSetId: string, opts: { acknowledgeLocks?: boolean } = {}): Promise<ApprovePublishOutcome> {
  if (!checkPermission(perms, 'pages.publish').allowed) return { ok: false, status: 403, error: 'Only someone who can publish pages can approve and publish.' }
  const rows = await prisma.adeChangeSetItem.findMany({ where: { changeSetId, status: { in: ['pending', 'saved'] } }, select: { id: true } })
  if (!rows.length) return { ok: false, status: 404, error: 'Nothing is waiting in this draft.' }
  const items = await loadItems(rows.map((r) => r.id))
  if (!items.every((i) => canApprove(perms, i))) return { ok: false, status: 403, error: 'You can’t approve every part of this draft.' }
  if ((await removedTargetItemIds(items)).size) return { ok: false, status: 409, error: 'Part of this draft points at something that was deleted.' }
  if (!opts.acknowledgeLocks) {
    const warnings = await approvalLockWarnings(items, actor.id)
    if (warnings.length) return { ok: false, status: 409, error: warnings[0], lockWarnings: warnings }
  }
  const outcomes = await changeSets.review(items.map((i) => i.id), 'approve', actor)
  const failed = outcomes.find((o) => o.status !== 'approved')
  if (failed) return { ok: false, status: 400, error: failed.error || 'The draft couldn’t be approved.' }

  // The record the approval made (record:create's target).
  const createItem = items.find((i) => i.targetType === 'record' && i.operation === 'create')
  const made = createItem ? await prisma.adeChangeSetItem.findUnique({ where: { id: createItem.id }, select: { targetId: true } }) : null
  const recordId = outcomes.find((o) => o.itemId === createItem?.id)?.resultId ?? made?.targetId ?? null
  const row = recordId ? await getRecordRow(recordId) : null
  if (!row) return { ok: true, published: false, recordId, notYet: 'Approved as a draft — publish it from Initiatives.' }

  const full = recordChecklist(row.type, { data: await effectiveRecordData(row.id, snapshotOf(row).data) }, { [REVIEWED_ITEM]: true })
  // From a phone, story sections are warnings (owner decision): publish, and list them to fill in on the web.
  const relaxed = full ? relaxForPhone(full, row.type) : null
  const later = relaxed ? relaxed.later.map((i) => (i.hint ? `${i.label} — ${i.hint}` : i.label)) : []
  const blocking = relaxed ? blockingItems(relaxed.result) : []
  if (blocking.length) return { ok: true, published: false, recordId, notYet: `Approved as a draft. Not ready to publish yet: ${blocking.map((b) => b.label).join('; ')}.` }
  const p = await changeSets.propose({ ownerId: actor.id, source: 'admin', toolName: 'publishRecord', input: { id: row.id, publish: true } })
  if (!p.ok) return { ok: true, published: false, recordId, notYet: `Approved as a draft. ${p.error}` }
  const pub = await changeSets.review([p.itemId], 'approve', actor)
  return pub[0]?.status === 'approved' ? { ok: true, published: true, recordId, later } : { ok: true, published: false, recordId, notYet: `Approved as a draft. ${pub[0]?.error ?? 'Publishing didn’t go through.'}` }
}
