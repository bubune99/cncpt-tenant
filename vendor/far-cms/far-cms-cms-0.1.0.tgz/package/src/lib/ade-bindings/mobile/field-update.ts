/**
 * A field update from the phone (mock 12): on an ongoing initiative, a
 * photo and a voice note become the page's "Progress so far" update — a
 * draft for approval (updateRecord), never written straight to the site.
 * The new words go on top of what's there; the photos join the gallery and
 * travel with the draft (with the voice notes) for Review and To-do.
 */

import { generateText } from 'ai'
import { getLanguageModel } from '../../ai/providers'
import { MODEL_ROUTES } from '../../ai/models'
import { admitAiRequest, recordAiTokens } from '../../ai/spend'
import { tokensFromUsage } from '../../ai/spend-policy'
import { getAiSettings } from '../../settings'
import { prisma } from '../../db'
import { addProgressUpdate, addToGallery } from '../../ade/records/progress'
import { ATTACHMENTS_KIND, cleanAttachments } from '../../ade/mobile/attachments'
import { getRecordRow, snapshotOf } from '../records'
import { getRecordType } from '../record-types'
import { changeSets } from '..'
import { createHandoff, handoffByClientKey } from '../handoffs'

const DEFAULT_DAILY_TOKEN_BUDGET = 500_000
const MAX_UPDATE = 600

export type UpdateDraftOutcome = { ok: true; update: string; ms: number } | { ok: false; status: number; error: string }

/** The notes (typed + voice) → one or two sentences for "Progress so far". No write. */
export async function draftFieldUpdate(userId: string, input: { id: string; notes: string }): Promise<UpdateDraftOutcome> {
  const t0 = Date.now()
  const row = await getRecordRow(input.id)
  if (!row) return { ok: false, status: 404, error: 'Initiative not found' }
  const notes = input.notes.trim().slice(0, 4000)
  if (!notes) return { ok: false, status: 400, error: 'Say or type what happened first.' }
  const budget = (await getAiSettings()).dailyTokenBudget ?? DEFAULT_DAILY_TOKEN_BUDGET
  const admission = await admitAiRequest(userId, budget)
  if (!admission.ok) return { ok: false, status: admission.status, error: 'The assistant’s limit is reached — type the update yourself, or try later.' }
  const data = snapshotOf(row).data as Record<string, unknown>
  // Plain text (not structured output, which stalled drafts on staging): just the sentence or two.
  const { text, usage } = await generateText({
    model: getLanguageModel(MODEL_ROUTES.title),
    system: [
      'You turn a nonprofit staff member’s quick field note into the newest line of the initiative page’s "Progress so far".',
      'One or two plain sentences, past tense, in the organization’s voice. Only what the note says — never invent numbers, names, places or dates.',
      'Reply with only those sentences.',
    ].join('\n'),
    prompt: `Initiative: ${String(data.name ?? row.slug)}${data.location ? ` (${String(data.location)})` : ''}\nProgress so far, most recent first:\n${String(data.progress ?? '(nothing yet)').slice(0, 1500)}\n\nField note:\n${notes}`,
    maxOutputTokens: 250,
    maxRetries: 1,
    abortSignal: AbortSignal.timeout(30_000),
  })
  await recordAiTokens(userId, tokensFromUsage(usage), 'mobile-field-update')
  console.info('[mobile-update] draft ms', Date.now() - t0)
  return { ok: true, update: text.trim().replace(/^"|"$/g, '').slice(0, MAX_UPDATE), ms: Date.now() - t0 }
}

export type UpdateSaveOutcome = { ok: true; changeSetId: string } | { ok: false; status: number; error: string }

/** Send the update for approval: progress (new on top) + new photos in the gallery, with the attachments. Idempotent by clientKey. */
export async function saveFieldUpdate(userId: string, input: { id: string; update: string; photos?: unknown; attachments?: unknown; clientKey?: string | null }): Promise<UpdateSaveOutcome> {
  const clientKey = input.clientKey && /^[A-Za-z0-9_-]{6,80}$/.test(input.clientKey) ? input.clientKey : null
  if (clientKey) {
    const prior = await handoffByClientKey(userId, clientKey)
    if (prior?.changeSetId) return { ok: true, changeSetId: prior.changeSetId }
  }
  const row = await getRecordRow(input.id)
  if (!row) return { ok: false, status: 404, error: 'Initiative not found' }
  const def = getRecordType(row.type)
  if (!def) return { ok: false, status: 400, error: 'Unknown kind of record' }
  const update = input.update.trim().slice(0, MAX_UPDATE)
  const attachments = cleanAttachments(input.attachments)
  const photos = attachments?.photos ?? []
  if (!update && !photos.length) return { ok: false, status: 400, error: 'Nothing to send yet — add a photo or an update.' }
  const data = snapshotOf(row).data as Record<string, unknown>
  const progressField = def.fields.find((f) => f.key === 'progress')
  const galleryField = def.fields.find((f) => f.key === 'gallery')
  const fields: Record<string, unknown> = {}
  if (update) fields.progress = addProgressUpdate(data.progress, update, progressField?.max ?? 2000)
  if (photos.length && galleryField) fields.gallery = addToGallery(data.gallery, photos, galleryField.max ?? 12)
  const r = await changeSets.propose({ ownerId: userId, source: 'admin', toolName: 'updateRecord', input: { id: row.id, type: row.type, fields } })
  if (!r.ok) return { ok: false, status: 400, error: r.error }
  await createHandoff(userId, { kind: `${def.key}-update`, title: `Update · ${String(data[def.titleField] ?? row.slug)}`, changeSetId: r.changeSetId, href: `/admin/todo?item=${encodeURIComponent(r.changeSetId)}`, clientKey })
  if (attachments) await prisma.adeChangeComment.create({ data: { changeSetId: r.changeSetId, authorId: userId, kind: ATTACHMENTS_KIND, body: JSON.stringify(attachments) } })
  return { ok: true, changeSetId: r.changeSetId }
}
