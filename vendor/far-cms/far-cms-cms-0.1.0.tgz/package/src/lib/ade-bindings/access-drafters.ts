/**
 * Access changes through review: the assistant proposes who may see a
 * private area (lib/ade/governance/access) as a change set the owner
 * approves in To-do — never applied directly.
 *
 * Target type `access`, targetId `user:<id>` | `role:<id>`.
 *   user → per-person exceptions (UserPermission GRANT/DENY rows)
 *   role → the role's permission list
 * Only privacy.<area>.see|agent keys can be changed this way.
 */

import { roleHistory, userAccessHistory } from '../permissions/history'
import { prisma } from '../db'
import { invalidateUserPermissions, logAuditEvent } from '../permissions'
import type { ChangeSetItemRecord, Drafter, ProposedChange, TargetAdapter } from '../ade'
import { applyToOverrides, applyToRole, checkAccessChange, describeChange, type AccessChange } from '../ade/governance/access'
import { PRIVACY_AREAS } from './visibility-rules'

type Subject = { kind: 'user'; id: string; label: string } | { kind: 'role'; id: string; label: string }

/** A person by email / id / name, or a role by name / display name / id. */
export async function findSubject(input: Record<string, unknown>): Promise<Subject | { error: string }> {
  const who = typeof input.user === 'string' ? input.user.trim() : ''
  const role = typeof input.role === 'string' ? input.role.trim() : ''
  if (who) {
    const u = await prisma.user.findFirst({
      where: { OR: [{ id: who }, { email: { equals: who, mode: 'insensitive' } }, { name: { equals: who, mode: 'insensitive' } }] },
      select: { id: true, name: true, email: true },
    })
    return u ? { kind: 'user', id: u.id, label: u.name || u.email } : { error: `No admin person matches “${who}”` }
  }
  if (role) {
    const r = await prisma.role.findFirst({
      where: { OR: [{ id: role }, { name: { equals: role, mode: 'insensitive' } }, { displayName: { equals: role, mode: 'insensitive' } }] },
      select: { id: true, displayName: true },
    })
    return r ? { kind: 'role', id: r.id, label: r.displayName } : { error: `No role matches “${role}”` }
  }
  return { error: 'Say which person (user) or role' }
}

interface AccessSnapshot {
  /** user: their exceptions; role: its permission list. */
  overrides?: Array<{ permission: string; type: 'GRANT' | 'DENY' }>
  permissions?: string[]
}

async function snapshot(targetId: string): Promise<AccessSnapshot | null> {
  const [kind, id] = targetId.split(':')
  if (kind === 'user') {
    const rows = await prisma.userPermission.findMany({ where: { userId: id }, select: { permission: true, type: true } })
    return { overrides: rows.map((r) => ({ permission: r.permission, type: r.type as 'GRANT' | 'DENY' })) }
  }
  if (kind === 'role') {
    const r = await prisma.role.findUnique({ where: { id }, select: { permissions: true } })
    return r ? { permissions: (r.permissions as string[]) ?? [] } : null
  }
  return null
}

async function draftAccess(input: Record<string, unknown>, pending: ChangeSetItemRecord | null): Promise<ProposedChange | { error: string }> {
  const subject = await findSubject(input)
  if ('error' in subject) return subject
  const checked = checkAccessChange(PRIVACY_AREAS, input)
  if (!checked.ok) return { error: checked.error }
  const targetId = `${subject.kind}:${subject.id}`
  const before = pending ? (pending.before as AccessSnapshot) : await snapshot(targetId)
  if (!before) return { error: 'Not found' }
  const base = pending ? (pending.after as AccessSnapshot) : before
  const change = checked.change
  const after: AccessSnapshot = subject.kind === 'user' ? { overrides: applyToOverrides(base.overrides ?? [], change) } : { permissions: applyToRole(base.permissions ?? [], change) }
  const lines = describeChange(PRIVACY_AREAS, change)
  return {
    targetType: 'access',
    targetId,
    operation: 'update',
    category: 'access',
    before,
    after,
    input: { subject: subject.label, kind: subject.kind, ...(change as AccessChange), changes: lines, reason: typeof input.reason === 'string' ? input.reason.slice(0, 300) : undefined },
    blockIds: [],
    summary: `${subject.kind === 'user' ? '' : 'Role '}${subject.label}: ${lines.join('; ')}`,
  }
}

export const ACCESS_DRAFTERS: Readonly<Record<string, Drafter>> = {
  draft_access_change: {
    target: async (input) => {
      const s = await findSubject(input)
      return 'error' in s ? s : { targetType: 'access', targetId: `${s.kind}:${s.id}` }
    },
    draft: draftAccess,
  },
}

export const accessAdapter: TargetAdapter = {
  snapshot,
  async apply(item, actor) {
    const [kind, id] = (item.targetId ?? '').split(':')
    const after = item.after as AccessSnapshot
    if (kind === 'user') {
      const keys = new Set((item.input.grant as string[] | undefined ?? []).concat(item.input.deny as string[] ?? [], item.input.clear as string[] ?? []))
      await userAccessHistory.update(id, {}, () => prisma.$transaction([
        prisma.userPermission.deleteMany({ where: { userId: id, permission: { in: [...keys] } } }),
        ...(after.overrides ?? [])
          .filter((o) => keys.has(o.permission))
          .map((o) => prisma.userPermission.create({ data: { userId: id, permission: o.permission, type: o.type, grantedBy: actor.id ?? undefined, reason: 'Approved access change' } })),
      ]))
      invalidateUserPermissions(id)
    } else if (kind === 'role') {
      await roleHistory.update(id, {}, () => prisma.role.update({ where: { id }, data: { permissions: after.permissions ?? [] } }))
      invalidateUserPermissions()
    } else {
      throw new Error('Unknown access target')
    }
    await logAuditEvent({
      userId: actor.id ?? undefined,
      userEmail: actor.email ?? undefined,
      action: kind === 'user' ? 'permission.grant' : 'role.update',
      targetType: kind === 'user' ? 'user' : 'role',
      targetId: id,
      details: { via: 'access-change', changes: item.input.changes },
    }).catch(() => {})
    return { resultId: id }
  },
}
