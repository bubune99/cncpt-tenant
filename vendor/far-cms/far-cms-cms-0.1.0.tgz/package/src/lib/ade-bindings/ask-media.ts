/**
 * Media for the question form (lib/ai/tools/ask-tools): an id the model
 * offers becomes a picture only when it is an image in this site's media
 * library (not deleted) and this person may view the library. Read-only.
 */

import { prisma } from '../db'
import { checkPermission } from '../permissions'
import type { UserWithPermissions } from '../permissions/types'
import type { AskMediaInfo } from '../ade/chat/ask-form'

export function askMediaResolver(perms: UserWithPermissions | null) {
  return async (ids: string[]): Promise<ReadonlyMap<string, AskMediaInfo>> => {
    if (!ids.length || !perms || !checkPermission(perms, 'media.view').allowed) return new Map()
    const rows = await prisma.media.findMany({
      where: { id: { in: ids }, deletedAt: null, mimeType: { startsWith: 'image/' } },
      select: { id: true, url: true, alt: true, title: true },
      take: ids.length,
    })
    return new Map(rows.map((r) => [r.id, { url: r.url, ...(r.alt || r.title ? { alt: (r.alt || r.title)! } : {}) }]))
  }
}
