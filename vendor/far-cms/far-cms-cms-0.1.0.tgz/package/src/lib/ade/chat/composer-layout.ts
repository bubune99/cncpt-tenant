/**
 * The composer's size rules: empty, it is one row (text box + its buttons
 * inline, ~52px tall); it grows only as the text wraps, up to 140px, then
 * scrolls. Chips (context, attachments, references) get a row above only
 * when there are any. Host-agnostic. Pure; asserted by composer-layout.assert.ts.
 */

/**
 * One line of text: a 22px line plus 4px above and below = the 30px box, so
 * the placeholder and typed text sit in the middle of the bar (owner
 * 2026-10-17). A taller line or more padding without a taller box pushes the
 * text up and clips it — keep the three in step.
 */
export const TEXTAREA_LINE = 22
export const TEXTAREA_PAD_Y = 4
export const TEXTAREA_MIN = TEXTAREA_LINE + TEXTAREA_PAD_Y * 2
export const TEXTAREA_MAX = 140

/**
 * The empty chat's centred composer (owner 2026-10-17): 15.5px text on a 24px
 * line with 5px above and below — a 34px box, still centred in its 58px bar.
 */
export const HERO_TEXTAREA_LINE = 24
export const HERO_TEXTAREA_PAD_Y = 5
export const HERO_TEXTAREA_MIN = HERO_TEXTAREA_LINE + HERO_TEXTAREA_PAD_Y * 2

/** Height for the text box given its content height (scrollHeight). */
export function textareaHeight(scrollHeight: number, min: number = TEXTAREA_MIN): number {
  if (!Number.isFinite(scrollHeight) || scrollHeight <= 0) return min
  return Math.min(TEXTAREA_MAX, Math.max(min, Math.ceil(scrollHeight)))
}

/** Past the max the box scrolls instead of growing. */
export function textareaScrolls(scrollHeight: number): boolean {
  return scrollHeight > TEXTAREA_MAX
}

/** The chip row shows only when something is in it. */
export function showChipRow(c: { contextLabel?: string | null; chips?: number; attachments?: number; refs?: number }): boolean {
  return !!c.contextLabel?.trim() || (c.chips ?? 0) > 0 || (c.attachments ?? 0) > 0 || (c.refs ?? 0) > 0
}

/** Outer padding (top + bottom) + card border and padding + one row: the empty composer's height. */
export const EMPTY_COMPOSER_HEIGHT = 6 + 4 + (1 + 5) * 2 + Math.max(TEXTAREA_MIN, 30)

/**
 * The narrowest the typing box gets beside the composer's buttons; narrower, the buttons wrap
 * below it. At 120 a phone left a 123px box and a question wrapped after two words (2026-11-17).
 */
export const TEXTAREA_MIN_WIDTH = 180
