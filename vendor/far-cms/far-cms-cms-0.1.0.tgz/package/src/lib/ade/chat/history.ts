/**
 * Saved conversations: turning stored rows back into chat messages, naming
 * conversations, pinning, and where a conversation opened from history
 * goes among the thread tabs.
 *
 * Host-agnostic. Pure; asserted by history.assert.ts.
 */

import { MAX_THREADS, type Thread } from './threads'

// ── Stored rows → chat messages ──────────────────────────────────────

export interface StoredMessage {
  id: string
  role: string
  content: string | null
  metadata?: unknown
}

export interface RestoredMessage {
  id: string
  role: 'user' | 'assistant'
  parts: Array<{ type: 'text'; text: string }>
  metadata?: unknown
}

/** "Did 3 steps" for a turn that only ran tools (its run has the details). */
export function stepsLine(steps: unknown): string {
  const n = typeof steps === 'number' && Number.isFinite(steps) && steps > 0 ? Math.floor(steps) : 0
  return n ? `Did ${n} step${n === 1 ? '' : 's'}` : 'Worked on the site'
}

/**
 * What the server kept (the words of each turn) as messages the chat can
 * show and continue from. Tool calls aren't stored, so a turn that only ran
 * tools comes back as a short note for the MODEL (so the conversation stays
 * valid) marked metadata.toolTurn — the chat hides it. runId / steps stay
 * on the message.
 */
/** A run that ended waiting for the person (an approval, a step on the page) when the conversation closed. */
export const STOPPED_WAITING = 'This was waiting for you (an approval or a step on the page) when the conversation was closed, so it did not finish. Ask again to carry on.'

export function restoreMessages(rows: readonly StoredMessage[]): RestoredMessage[] {
  // A turn that ran tools, said nothing, and has no assistant row after it before the person's next
  // message stopped there waiting (an approval after which the work went on is saved as a new run, so
  // "last row of its run" was wrong: walk 2026-11-16).
  const stopped = new Set<string>()
  rows.forEach((r, i) => {
    if (r.role !== 'assistant' || (r.content ?? '').trim()) return
    const m = r.metadata && typeof r.metadata === 'object' ? (r.metadata as Record<string, unknown>) : null
    if (m?.finishReason !== 'tool-calls') return
    const next = rows.slice(i + 1).find((x) => x.role === 'user' || x.role === 'assistant')
    if (!next || next.role === 'user') stopped.add(r.id)
  })
  const out: RestoredMessage[] = []
  const seen = new Set<string>()
  // The last person turn, and whether the assistant has answered it in words since.
  let lastUser: string | null = null
  let answered = false
  for (const r of rows) {
    if (r.role !== 'user' && r.role !== 'assistant') continue
    if (seen.has(r.id)) continue
    seen.add(r.id)
    const text = (r.content ?? '').trim()
    const meta = r.metadata && typeof r.metadata === 'object' ? (r.metadata as Record<string, unknown>) : null
    if (r.role === 'user' && text) {
      // A repeat of the same words with no answer in between is the old double save
      // (each browser-tool continuation saved the prompt again), not a second ask.
      if (text === lastUser && !answered) continue
      lastUser = text
      answered = false
    } else if (r.role === 'assistant' && text) answered = true
    if (!text) {
      if (r.role === 'user') continue
      if (stopped.has(r.id)) {
        out.push({ id: r.id, role: 'assistant', parts: [{ type: 'text', text: STOPPED_WAITING }], metadata: { ...meta, stoppedWaiting: true } })
        continue
      }
      const line = stepsLine(meta?.steps)
      out.push({ id: r.id, role: 'assistant', parts: [{ type: 'text', text: line.startsWith('Did') ? `(${line} on the site.)` : `(${line}.)` }], metadata: { ...meta, toolTurn: { line } } })
      continue
    }
    out.push({
      id: r.id,
      role: r.role,
      parts: [{ type: 'text', text }],
      ...(meta ? { metadata: meta } : {}),
    })
  }
  return out
}

/**
 * The person turn a chat request should save: its LAST message, only when
 * that is the person's. A continuation (after an approval or a browser
 * tool) ends with the assistant's message and saves nothing — saving "the
 * last user message" there stored the same prompt again on every step.
 */
export function userTurnToSave<T extends { role: string }>(messages: readonly T[]): T | null {
  const last = messages[messages.length - 1]
  return last && last.role === 'user' ? last : null
}

/** A client message id fit to key the saved row (idempotent saves); otherwise null. */
export function savableId(id: unknown): string | null {
  return typeof id === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(id) ? id : null
}

// ── Previews ─────────────────────────────────────────────────────────

/** A message as one plain line for the history list: no markdown, no tags, clipped. */
export function plainPreview(text: string | null | undefined, max = 100): string {
  const plain = (text ?? '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/^\s{0,3}(#{1,6}|>|[-*+]|\d+[.)])\s+/gm, '')
    .replace(/(\*\*|\*|~~|`)(?=\S)([^]*?\S)\1/g, '$2')
    // Underscores only as emphasis (_word_ / __word__), never inside snake_case.
    .replace(/(^|[^\w])(__?)(?=\S)([^]*?\S)\2(?=[^\w]|$)/g, '$1$3')
    .replace(/[`*]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
  return plain.length > max ? `${plain.slice(0, max - 1).trimEnd()}…` : plain
}

// ── Names ────────────────────────────────────────────────────────────

const ANSWER_LIKE = /^(i\b|i'm|i’m|i am|sorry|sure|okay|ok\b|yes\b|no\b|here|hello|hi\b|as an ai)|don['’]t have access|can['’]t |cannot |not able to/i

/**
 * A generated title is only kept if it reads like a title — short, a few
 * words, not a reply ("I don't have access…") or a one-word echo ("TWO").
 * Otherwise the first message names the conversation.
 */
export function chooseTitle(generated: string | null | undefined, firstMessage: string): string {
  const g = (generated ?? '').replace(/^["'“”‘’\s]+|["'“”‘’\s.]+$/g, '').replace(/\s+/g, ' ')
  const words = g ? g.split(' ').length : 0
  const ok = g.length >= 3 && g.length <= 60 && words >= 2 && words <= 8 && !ANSWER_LIKE.test(g) && !/[.!?]\s/.test(g)
  if (ok) return g
  const m = firstMessage.replace(/\s+/g, ' ').trim()
  if (!m) return 'New chat'
  if (m.length <= 48) return m
  // Cut at a word, not mid-word.
  const cut = m.slice(0, 47)
  return `${(cut.lastIndexOf(' ') > 20 ? cut.slice(0, cut.lastIndexOf(' ')) : cut).trimEnd()}…`
}

export type TitleCheck = { ok: true; title: string } | { ok: false; error: string }

/** A rename typed by a person: trimmed, 1–80 characters. */
export function checkRename(input: unknown): TitleCheck {
  if (typeof input !== 'string') return { ok: false, error: 'A name is required' }
  const t = input.replace(/\s+/g, ' ').trim()
  if (!t) return { ok: false, error: 'A name is required' }
  if (t.length > 80) return { ok: false, error: 'Keep the name under 80 characters' }
  return { ok: true, title: t }
}

// ── Pins ─────────────────────────────────────────────────────────────

export const MAX_PINS = 30

/** Pin or unpin; the newest pin goes first; bounded. */
export function togglePin(pins: readonly string[], id: string, on: boolean): string[] {
  const rest = pins.filter((p) => p !== id)
  return (on ? [id, ...rest] : rest).slice(0, MAX_PINS)
}

/** Pinned first (in pin order), then the rest as given (most recent first). */
export function sortWithPins<T extends { id: string }>(list: readonly T[], pins: readonly string[]): Array<T & { pinned: boolean }> {
  const byId = new Map(list.map((c) => [c.id, c]))
  const pinned = pins.flatMap((id) => (byId.has(id) ? [{ ...byId.get(id)!, pinned: true }] : []))
  const rest = list.filter((c) => !pins.includes(c.id)).map((c) => ({ ...c, pinned: false }))
  return [...pinned, ...rest]
}

// ── Opening from history ─────────────────────────────────────────────

export type Placement =
  | { action: 'activate'; id: string }
  | { action: 'replace'; replaceId: string; id: string }
  | { action: 'open'; id: string }

/**
 * Where a conversation picked from history goes: its tab if it's open; the
 * tab you're on if that's an unused new thread (or the tabs are full);
 * otherwise a new tab.
 */
export function placeFromHistory(threads: readonly Pick<Thread, 'id' | 'title' | 'status'>[], activeId: string | null, id: string): Placement {
  if (threads.some((t) => t.id === id)) return { action: 'activate', id }
  const active = threads.find((t) => t.id === activeId) ?? threads[0]
  if (!active) return { action: 'open', id }
  const unused = active.status === 'idle' && active.title === 'New thread'
  if (unused || threads.length >= MAX_THREADS) return { action: 'replace', replaceId: active.id, id }
  return { action: 'open', id }
}

/**
 * The list row's preview: the newest message that has words (newest
 * first). Tool-only and empty turns are skipped, so a thread with turns
 * never reads "No messages"; '' only when none has any.
 */
export function lastPreview(contents: ReadonlyArray<string | null | undefined>, max = 100): string {
  for (const c of contents) {
    const p = plainPreview(c, max)
    if (p) return p
  }
  return ''
}

/** What deleting a conversation needs from the app's storage (lib/ade-bindings/chat-history-server). */
export interface ConversationStore {
  /** The conversation's id when it belongs to this person; null otherwise (missing or someone else's — same answer). */
  findOwned(userId: string, id: string): Promise<string | null>
  /** Remove it with its messages, votes, streams and agent runs (and their spans). */
  removeOwned(userId: string, id: string): Promise<void>
}

/** Delete one of this person's conversations: 'not-found' for anything that isn't theirs (never confirms another's id). */
export async function deleteConversationFor(store: ConversationStore, userId: string, id: string): Promise<'deleted' | 'not-found'> {
  if (!userId || !id || id.length > 100) return 'not-found'
  const owned = await store.findOwned(userId, id)
  if (!owned) return 'not-found'
  await store.removeOwned(userId, owned)
  return 'deleted'
}

/**
 * The history list's groups: with more than one pinned conversation they
 * get their own "Pinned" group at the top (then "Recent"); otherwise one
 * plain list (a single pin just sorts first, marked with its icon).
 */
export function historyGroups<T extends { pinned?: boolean }>(items: readonly T[]): Array<{ label: string | null; items: T[] }> {
  const pinned = items.filter((i) => i.pinned)
  if (pinned.length < 2) return [{ label: null, items: [...items] }]
  const rest = items.filter((i) => !i.pinned)
  return [{ label: 'Pinned', items: pinned }, ...(rest.length ? [{ label: 'Recent', items: rest }] : [])]
}

/** The Clear-all confirm's words. */
export function clearAllCopy(n: number): { title: string; body: string; confirmLabel: string } {
  const all = n === 1 ? 'the 1 conversation and its runs' : `all ${n} conversations and their runs`
  return { title: 'Clear all conversation history?', body: `This deletes ${all}. This can’t be undone.`, confirmLabel: 'Delete all' }
}
