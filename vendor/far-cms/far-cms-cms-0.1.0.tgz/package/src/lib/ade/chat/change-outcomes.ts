/**
 * What happened to the assistant's drafts, told back to the assistant.
 *
 * A draft is decided outside the conversation (Approve / Reject on the
 * chat card, the To-do list, the phone deck), and a reopened chat carries
 * only its words, not its earlier tool calls. Without this the model sees
 * "I drafted the summary change", finds no tool call behind it, decides it
 * never made it, and drafts the REJECTED change again (golden run 2c).
 * So every change set the conversation made is reported with its real
 * outcome, and a rejected one is not to be proposed again unless asked.
 * Pure; asserted by change-outcomes.assert.ts.
 */

import { changeRefsFromMetadata, changeRefsFromParts, fieldLabel } from './change-widgets'

interface MessageLike {
  role: string
  parts?: readonly unknown[]
  metadata?: unknown
}

/** Every change set this conversation drafted: from tool results in this session, and from saved turns' metadata. */
export function changeSetIdsIn(messages: readonly MessageLike[]): string[] {
  const ids = new Set<string>()
  for (const m of messages) {
    if (m.role !== 'assistant') continue
    for (const r of [...changeRefsFromParts(m.parts ?? []), ...(changeRefsFromMetadata(m.metadata) ?? [])]) {
      if (r.kind === 'changeset') ids.add(r.changeSetId)
    }
  }
  return [...ids]
}

export type ItemStatus = 'pending' | 'approved' | 'saved' | 'rejected' | 'stale' | 'failed'

export interface OutcomeItem {
  status: string
  /** The fields it changes (keys of its proposed values). */
  fields: readonly string[]
}
export interface OutcomeSet {
  id: string
  title: string
  items: readonly OutcomeItem[]
}

const WORDS: Record<string, string> = {
  pending: 'still waiting for the person’s review',
  approved: 'APPROVED — it is live',
  saved: 'APPROVED — it is live',
  rejected: 'REJECTED by the person',
  stale: 'NOT APPLIED — it went out of date',
  failed: 'NOT APPLIED — it failed to apply',
}

/** One item's outcome in plain words. */
export function outcomeWords(status: string): string {
  return WORDS[status] ?? `status: ${status}`
}

function line(set: OutcomeSet, item: OutcomeItem): string {
  const what = item.fields.length ? `${item.fields.slice(0, 6).map(fieldLabel).join(', ')}` : 'the change'
  return `- “${set.title.slice(0, 120)}” (${what}): ${outcomeWords(item.status)}.`
}

/** The prompt section; null when the conversation drafted nothing. */
export function decisionsPrompt(sets: readonly OutcomeSet[]): string | null {
  const lines = sets.flatMap((s) => s.items.map((i) => line(s, i)))
  if (!lines.length) return null
  const rejected = sets.some((s) => s.items.some((i) => i.status === 'rejected'))
  return [
    '[Your drafts in this conversation, and what happened to them] These are the real outcomes — your earlier tool calls may not be shown, but these drafts WERE made:',
    ...lines,
    rejected ? 'Do NOT propose a rejected change again unless the person asks for it. Never re-include it in a new draft.' : null,
  ]
    .filter(Boolean)
    .join('\n')
}

/**
 * The same outcome on the tool results the model sees in this session:
 * a drafted result gains `reviewOutcome` ("rejected", "approved", …).
 */
export function annotateDraftOutputs<M extends MessageLike>(messages: readonly M[], statusBySet: ReadonlyMap<string, string>): M[] {
  if (!statusBySet.size) return [...messages]
  return messages.map((m) => {
    if (m.role !== 'assistant' || !m.parts?.length) return m
    let changed = false
    const parts = m.parts.map((p) => {
      const part = p as { type?: unknown; state?: unknown; output?: unknown }
      if (typeof part.type !== 'string' || !part.type.startsWith('tool-') || part.state !== 'output-available') return p
      const ref = changeRefsFromParts([p]).find((r) => r.kind === 'changeset')
      const status = ref && ref.kind === 'changeset' ? statusBySet.get(ref.changeSetId) : undefined
      if (!status || !part.output || typeof part.output !== 'object') return p
      changed = true
      return { ...part, output: { ...(part.output as object), reviewOutcome: status, reviewOutcomeWords: outcomeWords(status) } }
    })
    return changed ? { ...m, parts } : m
  })
}

/** A set's overall status for the tool results: rejected if all its items were, else the most telling one. */
export function setStatus(items: readonly OutcomeItem[]): string {
  const s = new Set(items.map((i) => i.status))
  if (!s.size) return 'pending'
  if (s.size === 1) return [...s][0]
  if (s.has('pending')) return 'partly decided, some still pending'
  return [...s].join(' / ')
}
