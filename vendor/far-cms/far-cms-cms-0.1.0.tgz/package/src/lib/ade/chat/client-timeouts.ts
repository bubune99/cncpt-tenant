/**
 * No browser tool waits forever (staging 49b9da13: show_unit sat on "Reading
 * the screen…" for 35 s+, its span "Waiting for the screen", no result ever
 * posted). Screen tools get a client-side time limit and answer with a plain
 * reason; a screen step that never settles can't jam the queue behind it; and
 * the server closes a run still waiting on the screen long after.
 *
 * Pacing waits (walk-through step, question form, card) are the person's to
 * answer and are never timed out here.
 *
 * Pure, client-safe. Run: npx -y tsx@4.23.15 src/lib/ade/chat/client-timeouts.assert.ts
 */

import { isWaitTool } from './wait-tools'
import { ASK_TOOL } from './ask-form'
import { FILL_LIMITS } from '../records/fill'
import { spotClientTimeoutMs } from '../ui/spot-target'

/** Per-tool limits for browser-answered tools (ms). */
export const CLIENT_TOOL_TIMEOUT_MS: Readonly<Record<string, number>> = {
  show_unit: 15_000,
  // One step's worth; the real limit scales with the set (clientTimeoutFor → spotClientTimeoutMs), always above
  // the spot's own wait (components/spotlight runSpotCall), which answers first with what it saw.
  spotlight_steps: spotClientTimeoutMs(1),
  read_view: 15_000,
  scan_page: 15_000,
  capture_view: 20_000,
  open_tab: 12_000,
  expand: 12_000,
  collapse: 12_000,
  scroll_to: 12_000,
  open_menu: 12_000,
  coverage_check: 90_000,
}
export const DEFAULT_CLIENT_TOOL_TIMEOUT_MS = 20_000

/** One screen step (a capability handler: open a drawer, set the stage…) may take this long before the queue moves on. */
export const UI_HANDLER_TIMEOUT_MS = 20_000

/**
 * A fill runs within its own bounds: the 25 s run budget plus ~8 s on the last
 * field (reveal, read-back, ring). Its cap sits well above that, so a long but
 * healthy fill is never reported as "didn't respond" while it is still typing.
 */
export const FILL_HANDLER_TIMEOUT_MS = Math.max(45_000, FILL_LIMITS.runMs + 20_000)

/** Capabilities with their own run bound get a cap above it; every other one gets UI_HANDLER_TIMEOUT_MS. */
export const HANDLER_TIMEOUT_MS: Readonly<Record<string, number>> = {
  'record.fill': FILL_HANDLER_TIMEOUT_MS,
}

export const handlerTimeoutFor = (capability: string): number => (Object.hasOwn(HANDLER_TIMEOUT_MS, capability) ? HANDLER_TIMEOUT_MS[capability] : UI_HANDLER_TIMEOUT_MS)

/** After this, a run still waiting on the SCREEN (not on the person) is closed by the server. */
export const ABANDONED_AFTER_MS = 120_000

/** The person's own answers — never timed out. */
export const isPersonWait = (name: string): boolean => isWaitTool(name) || name === ASK_TOOL

/** The limit for a browser tool, or null for a person's wait. A screen step (operate_ui) gets its capability's cap plus a margin. */
export function clientTimeoutFor(name: string, input?: unknown): number | null {
  if (isPersonWait(name)) return null
  if (name === 'operate_ui') {
    const cap = (input as { capability?: unknown } | null | undefined)?.capability
    return handlerTimeoutFor(typeof cap === 'string' ? cap : '') + 5_000
  }
  if (name === 'spotlight_steps') {
    const steps = (input as { steps?: unknown } | null | undefined)?.steps
    return spotClientTimeoutMs(Array.isArray(steps) ? steps.length : 1)
  }
  return Object.hasOwn(CLIENT_TOOL_TIMEOUT_MS, name) ? CLIENT_TOOL_TIMEOUT_MS[name] : DEFAULT_CLIENT_TOOL_TIMEOUT_MS
}

const clip = (s: unknown, n: number) => (typeof s === 'string' ? s.trim().slice(0, n) : '')

/** What the model gets when a browser tool ran out of time: a plain reason, never silence. */
export function timeoutOutput(name: string, input: unknown): Record<string, unknown> {
  const o = (input ?? {}) as Record<string, unknown>
  if (name === 'show_unit') {
    const unit = clip(o.unit, 80) || 'that part of the screen'
    return { ok: false, timedOut: true, error: `Couldn’t reach “${unit}” — the screen didn’t respond in time. It may be behind a closed panel or another tab.` }
  }
  if (name === 'spotlight_steps') {
    return { ok: false, timedOut: true, reason: 'timeout', error: 'The screen didn’t answer in time, so nothing may be highlighted. Never say you pointed at it.' }
  }
  if (name === 'read_view' || name === 'scan_page' || name === 'capture_view') {
    return { ok: false, timedOut: true, error: 'The screen didn’t answer in time, so I couldn’t read it. Say what you see, or try again.' }
  }
  return { ok: false, timedOut: true, error: 'The screen didn’t respond in time, so that step didn’t happen.' }
}

/** A capability handler that never finished: the queue moves on with this. */
export const handlerTimeoutMessage = (label: string): string => `“${label}” didn’t finish in time, so it may not have happened.`

/** Race a promise against a timer; the fallback value wins if the timer does. Timers are injectable for asserts. */
export function withTimeout<T>(
  p: Promise<T>,
  ms: number,
  fallback: () => T,
  timer: { set: (fn: () => void, ms: number) => unknown; clear: (h: unknown) => void } = { set: (fn, t) => setTimeout(fn, t), clear: (h) => clearTimeout(h as ReturnType<typeof setTimeout>) },
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let done = false
    const h = timer.set(() => {
      if (done) return
      done = true
      resolve(fallback())
    }, ms)
    p.then(
      (v) => {
        if (done) return
        done = true
        timer.clear(h)
        resolve(v)
      },
      (e) => {
        if (done) return
        done = true
        timer.clear(h)
        reject(e)
      },
    )
  })
}

/**
 * Server backstop: is this waiting run abandoned? Only when it waits on a
 * screen tool (not a person's step / form) and has waited past the limit.
 */
export function abandonedRun(r: { waitingLabels: readonly string[]; waitingSince: number; now: number }): boolean {
  if (!r.waitingLabels.length) return false
  if (r.waitingLabels.some((l) => isPersonWait(l))) return false
  return r.now - r.waitingSince > ABANDONED_AFTER_MS
}

export const ABANDONED_ERROR = 'The screen never answered, so this step was closed.'
