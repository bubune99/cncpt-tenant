/**
 * WCAG 2.x contrast, pure. Reads the colours the chat tokens are written in
 * (#rgb / #rrggbb and oklch(L C h [/ alpha])) and returns real ratios, so an
 * assert can fail a palette that is unreadable instead of someone eyeballing it.
 */

export interface Rgba { r: number; g: number; b: number; a: number }

const clamp01 = (n: number) => Math.min(1, Math.max(0, n))

/** sRGB transfer (linear -> encoded, 0..1). */
function encode(c: number): number {
  const v = clamp01(c)
  return v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055
}
/** sRGB transfer (encoded -> linear, 0..1). */
function decode(c: number): number {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
}

/** oklch -> sRGB (0..1 per channel, gamut-clipped). */
function oklchToRgb(l: number, c: number, hDeg: number): { r: number; g: number; b: number } {
  const h = (hDeg * Math.PI) / 180
  const a = c * Math.cos(h)
  const b = c * Math.sin(h)
  const l_ = l + 0.3963377774 * a + 0.2158037573 * b
  const m_ = l - 0.1055613458 * a - 0.0638541728 * b
  const s_ = l - 0.0894841775 * a - 1.291485548 * b
  const L = l_ ** 3
  const M = m_ ** 3
  const S = s_ ** 3
  return {
    r: encode(4.0767416621 * L - 3.3077115913 * M + 0.2309699292 * S),
    g: encode(-1.2684380046 * L + 2.6097574011 * M - 0.3413193965 * S),
    b: encode(-0.0041960863 * L - 0.7034186147 * M + 1.707614701 * S),
  }
}

export function parseColor(input: string): Rgba {
  const s = input.trim().toLowerCase()
  const hex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/.exec(s)
  if (hex) {
    const h = hex[1].length === 3 ? hex[1].split('').map((x) => x + x).join('') : hex[1]
    return { r: parseInt(h.slice(0, 2), 16) / 255, g: parseInt(h.slice(2, 4), 16) / 255, b: parseInt(h.slice(4, 6), 16) / 255, a: 1 }
  }
  const ok = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)\s+([\d.]+)(?:deg)?\s*(?:\/\s*([\d.]+)(%?))?\s*\)$/.exec(s)
  if (ok) {
    const l = ok[2] ? Number(ok[1]) / 100 : Number(ok[1])
    const alpha = ok[5] === undefined ? 1 : ok[6] ? Number(ok[5]) / 100 : Number(ok[5])
    return { ...oklchToRgb(l, Number(ok[3]), Number(ok[4])), a: alpha }
  }
  throw new Error(`contrast: cannot parse color "${input}"`)
}

/** `fg` (with its alpha) laid over an opaque `bg`. */
export function over(fg: Rgba, bg: Rgba): Rgba {
  const a = fg.a
  return { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a), a: 1 }
}

/** `color-mix(in srgb, fg pct%, bg)`: the same arithmetic the browser uses for the tints and rings. */
export function mix(fg: string, pct: number, bg: string | Rgba): Rgba {
  const f = parseColor(fg)
  const b = typeof bg === 'string' ? parseColor(bg) : bg
  return over({ ...f, a: f.a * (pct / 100) }, over(b, { r: 1, g: 1, b: 1, a: 1 }))
}

export function luminance(c: Rgba): number {
  return 0.2126 * decode(c.r) + 0.7152 * decode(c.g) + 0.0722 * decode(c.b)
}

/** WCAG contrast ratio of two opaque colours (strings or already-resolved). */
export function ratio(a: string | Rgba, b: string | Rgba): number {
  const ca = typeof a === 'string' ? parseColor(a) : a
  const cb = typeof b === 'string' ? parseColor(b) : b
  const la = luminance(ca)
  const lb = luminance(cb)
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
}
