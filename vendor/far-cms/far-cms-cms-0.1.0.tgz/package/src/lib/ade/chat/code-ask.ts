/**
 * A question form shown by CODE, not by a model call (R7): when a page action
 * (the record fill) needs choices only the person can make, it shows the chat's
 * own form at once — the same form ask_user shows, rendered and answered the
 * same way ("My answers: …" as their next message). Pure; asserted.
 */

import { ASK_TOOL } from './ask-form'

/** The window event a screen dispatches with { line, form }; the chat adds the message. */
export const CODE_ASK_EVENT = 'ade:code-ask'

export interface CodeAskDetail {
  line: string
  form: { title?: string; questions: unknown[] }
}

/** The assistant message the chat adds: one line, then the form as a settled ask_user call. */
export function codeAskMessage(detail: CodeAskDetail, id: string) {
  return {
    id: `code-ask-${id}`,
    role: 'assistant' as const,
    parts: [
      { type: 'text', text: detail.line },
      { type: `tool-${ASK_TOOL}`, toolCallId: `code-ask-${id}`, state: 'output-available', input: detail.form, output: { shown: true, form: detail.form, message: 'The form was shown to the person by the page.' } },
    ],
  }
}
