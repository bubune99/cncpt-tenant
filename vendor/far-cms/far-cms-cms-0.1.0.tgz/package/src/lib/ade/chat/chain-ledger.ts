/**
 * The 1a "Quiet ledger": what the thought chain shows, decided here so the
 * view only draws it. Reads the chain view-model (lib/ade/chat/thought-chain)
 * plus a clock; never guesses. Pure; asserted by chain-ledger.assert.ts.
 *
 *  - progress segments: one per counted step (skipped steps leave the bar),
 *    done ink, current ink 35%, upcoming 10%, needs-you amber;
 *  - the time label ("8s", "1m 05s") from the run's own start/finish stamps;
 *  - the header ("Working on it" + tabular-nums "2 of 4 · 8s") and the folded line
 *    under the answer ("3 steps · 14s");
 *  - which steps fold (all of them, once the reply is done or stopped) and
 *    which open a Details box (finished steps with recorded facts);
 *  - the needs-you row's one filled button + "Skip this step";
 *  - step ↔ change links: a step that made a change links "Review ›" to its
 *    card, and the card links back to the step (sourceStepId).
 */

import { CHAIN_COPY } from './chain-constants'
import type { ChainStep, ChainTiming, ChainVM } from './thought-chain'

const L = CHAIN_COPY.ledger

// ── Progress ─────────────────────────────────────────────────────────

export type SegmentKind = 'done' | 'current' | 'ahead' | 'needs-you' | 'failed'

/**
 * A step really waiting on the person: an approval card. A step that FAILED
 * also comes as needs-you (with problem) from buildChain, but nothing waits
 * on the person there: the run carries on or ends. Only an approval is
 * "Waiting on you" / paused (staging 2026-10-23: a failed search read
 * "Waiting on you · 3 of 3 · paused" with nothing to press).
 */
export const isWaiting = (s: ChainStep): boolean => s.state === 'needs-you' && !s.problem
export const isFailed = (s: ChainStep): boolean => s.state === 'needs-you' && !!s.problem

/** Steps that count toward "N of M" and the bar: everything but skipped. */
export const countedSteps = (steps: readonly ChainStep[]): ChainStep[] => steps.filter((s) => s.state !== 'skipped')

/** One segment per counted step. */
export function progressSegments(steps: readonly ChainStep[]): SegmentKind[] {
  return countedSteps(steps).map((s) => (s.state === 'done' ? 'done' : s.state === 'current' ? 'current' : isFailed(s) ? 'failed' : isWaiting(s) ? 'needs-you' : 'ahead'))
}

/** "2 of 4": the step being worked on (or waiting on you); with none, the next one; all done → M of M. */
export function ledgerPosition(steps: readonly ChainStep[]): { at: number; of: number } {
  const counted = countedSteps(steps)
  const live = counted.findIndex((s) => s.state === 'current' || s.state === 'needs-you')
  // (a failed step counts as where the run got to, like the one being worked on)
  const done = counted.filter((s) => s.state === 'done').length
  return { at: live >= 0 ? live + 1 : Math.min(done + 1, counted.length), of: counted.length }
}

// ── Time ─────────────────────────────────────────────────────────────

/** "0s" · "8s" · "59s" · "1m 05s" · "1h 02m". Negative or not finite (clock skew, no stamps) → null. */
export function elapsedLabel(ms: number | null | undefined): string | null {
  if (typeof ms !== 'number' || !Number.isFinite(ms) || ms < 0) return null
  const s = Math.floor(ms / 1000)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ${String(s % 60).padStart(2, '0')}s`
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`
}

/**
 * How long the run has taken: finished → finish − start; still running →
 * now − start (clamped at 0, the stamps are the server's clock). No start → null.
 */
export function chainElapsedMs(timing: ChainTiming | undefined, now: number, running: boolean): number | null {
  const start = timing?.startedAt
  if (typeof start !== 'number' || !Number.isFinite(start)) return null
  const end = !running && typeof timing?.finishedAt === 'number' ? timing.finishedAt : running ? now : null
  return end === null ? null : Math.max(0, end - start)
}

/**
 * The start stamp for this request: a continuation (after an approval or a
 * screen read) carries on the last assistant message, so it keeps that
 * message's start, moved forward by the time it sat waiting (finish → now):
 * "14s" is the time the assistant worked, not the time you took to decide.
 * Anything else starts now.
 */
export function runStartedAt(messages: ReadonlyArray<{ role?: unknown; metadata?: unknown }>, now: number): number {
  const last = messages[messages.length - 1]
  const meta = last?.role === 'assistant' ? (last.metadata as { startedAt?: unknown; finishedAt?: unknown } | undefined) : undefined
  const start = meta?.startedAt
  if (typeof start !== 'number' || !Number.isFinite(start) || start <= 0 || start > now) return now
  const end = meta?.finishedAt
  const waited = typeof end === 'number' && Number.isFinite(end) && end >= start && end <= now ? now - end : 0
  return Math.min(now, start + waited)
}

// ── Mode, header, fold ───────────────────────────────────────────────

export type LedgerMode = 'thinking' | 'proposed' | 'running' | 'folded'

/** Done or stopped: the steps fold under the answer behind one line. */
export const chainFolds = (chain: Pick<ChainVM, 'phase'>): boolean => chain.phase === 'done' || chain.phase === 'stopped'

export function ledgerMode(chain: Pick<ChainVM, 'phase'>): LedgerMode {
  if (chain.phase === 'thinking') return 'thinking'
  if (chain.phase === 'proposed') return 'proposed'
  return chainFolds(chain) ? 'folded' : 'running'
}

/** The run's clock ticks only while it is really running (not paused, not waiting on an approval). */
export function clockRuns(chain: Pick<ChainVM, 'phase' | 'steps'>): boolean {
  return (chain.phase === 'working' || chain.phase === 'plan') && !chain.steps.some(isWaiting)
}

export interface LedgerHeader {
  title: string
  /** Tabular numbers, right-aligned: "2 of 4 · 8s", "3 of 4 · paused", "step 2 · 8s". */
  meta: string
}

/** Running / paused / waiting header. Proposed and folded chains have none (their own words). */
export function ledgerHeader(chain: ChainVM, elapsedMs: number | null): LedgerHeader | null {
  if (ledgerMode(chain) !== 'running') return null
  const waiting = chain.steps.some(isWaiting)
  const paused = chain.phase === 'paused'
  const { at, of } = ledgerPosition(chain.steps)
  const pos = chain.style === 'planned' ? L.position(at, of) : L.flyPosition(Math.max(1, at))
  const time = paused || waiting ? L.pausedMeta : elapsedLabel(elapsedMs)
  return {
    title: waiting ? L.waiting : paused ? L.paused : L.working,
    meta: [pos, time].filter(Boolean).join(' · '),
  }
}

/** The folded line under the answer: "3 steps · 14s", "4 steps · 1 skipped · 20s". */
export function foldLine(chain: ChainVM, elapsedMs: number | null): string {
  return [chain.fold, elapsedLabel(elapsedMs)].filter(Boolean).join(' · ')
}

// ── Rows ─────────────────────────────────────────────────────────────

/** A finished step with recorded facts opens a Details box ("Looked at / Effect"). */
export const stepHasDetails = (step: ChainStep): boolean => step.state === 'done' && !!step.trace

/** Plan changes are muted lines; the notes come from plan.ts in the right words already. */
export const planChangeLines = (chain: Pick<ChainVM, 'notes'>): string[] => chain.notes.filter((n) => n.trim().length > 0)

export interface NeedsYouActions {
  /** review = scroll to the approval card; retry = ask it to try the step again. */
  primary: { kind: 'review' | 'retry'; label: string }
  /** The prompt the primary button sends (retry only). */
  primaryPrompt?: string
  skip: { label: string; prompt: string }
}

/**
 * A step waiting on you gets exactly one filled button and "Skip this step".
 * An approval: always (Review). A failed step: only once the run has ended
 * (Try again); while it still runs there is nothing for you to do yet.
 */
export function needsYouActions(step: ChainStep, opts: { running: boolean } = { running: false }): NeedsYouActions | null {
  if (step.state !== 'needs-you') return null
  const skip = { label: L.skip, prompt: L.skipPrompt(step.title) }
  if (step.problem) return opts.running ? null : { primary: { kind: 'retry', label: L.retry }, primaryPrompt: L.retryPrompt(step.title), skip }
  return { primary: { kind: 'review', label: L.reviewApproval }, skip }
}

/** Under a waiting chain: "2 steps done · Add a card is next" (the first step still ahead). */
export function waitingSummary(steps: readonly ChainStep[]): string | null {
  if (!steps.some(isWaiting)) return null
  const done = steps.filter((s) => s.state === 'done').length
  const next = steps.find((s) => s.state === 'ahead')
  return L.doneNext(done, next?.title ?? null)
}

// ── Step ↔ change links ──────────────────────────────────────────────

export interface StepSource {
  /** sourceStepId: the step that made the change. */
  stepId: string
  /** 1-based, as the ledger numbers it. */
  n: number
  title: string
}

export interface StepChangeLinks {
  /** stepId → the change keys its "Review ›" link points at (first is the target). */
  byStep: Record<string, string[]>
  /** change key → the step that made it (the first step, when several drafted into one change set). */
  byChange: Record<string, StepSource>
}

export function stepChangeLinks(steps: readonly ChainStep[]): StepChangeLinks {
  const byStep: Record<string, string[]> = {}
  const byChange: Record<string, StepSource> = {}
  steps.forEach((s, i) => {
    const keys = [...new Set(s.changeKeys ?? [])]
    if (!keys.length) return
    byStep[s.id] = keys
    for (const k of keys) if (!byChange[k]) byChange[k] = { stepId: s.id, n: i + 1, title: s.title }
  })
  return { byStep, byChange }
}

/** The card's back-link words: "From step 2: Draft the initiative". */
export const sourceLabel = (src: StepSource): string => L.fromStep(src.n, src.title)
