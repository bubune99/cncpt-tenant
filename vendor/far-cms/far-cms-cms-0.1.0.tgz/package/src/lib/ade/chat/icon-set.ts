/** The assistant's icon set rules, in one pure place (components/block-editor/chat/icons.tsx draws with them). */
export const ICON_SIZES = [14, 16, 18] as const
export type IconSize = (typeof ICON_SIZES)[number]
export const ICON_STROKE = 1.75
