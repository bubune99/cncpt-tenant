/**
 * Browser side of click-to-reference: turn a clicked element into the plain
 * snapshot references.ts understands, and take a small cropped screenshot of
 * it. Host-agnostic (DOM + html-to-image only).
 */

import { toJpeg } from 'html-to-image'
import { MAX_INLINE_IMAGE_BYTES } from './attachments'
import type { ElementSnapshot, NodeSnapshot, RefMarkers } from './references'

const KEEP_ATTRS = ['aria-label', 'role', 'alt', 'name']

function nthOfType(el: Element): number {
  let i = 1
  for (let s = el.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === el.tagName) i++
  return i
}

/** The element a click refers to: the block, the named control, or the element itself. */
export function resolveTarget(target: Element, markers: RefMarkers): Element {
  if (target.closest(`[${markers.canvas}]`)) {
    const block = target.closest(`[${markers.block}]`)
    if (block) return block
  }
  for (const a of markers.controls) {
    const c = target.closest(`[${a}]`)
    if (c) return c
  }
  return target
}

/** `exact`: the target already is the thing (a snapped unit) — take its own text, not a named ancestor's. */
export function snapshotElement(target: Element, markers: RefMarkers, screen: string, exact = false): ElementSnapshot {
  const keep = [markers.block, markers.canvas, ...markers.controls, ...KEEP_ATTRS]
  const chain: NodeSnapshot[] = []
  for (let el: Element | null = target; el && el !== document.body && chain.length < 24; el = el.parentElement) {
    const attrs: Record<string, string> = {}
    for (const a of keep) {
      const v = el.getAttribute(a)
      if (v !== null) attrs[a] = v.slice(0, 120)
    }
    chain.push({ tag: el.tagName.toLowerCase(), id: el.id || undefined, attrs, nth: nthOfType(el) })
  }
  const resolved = (exact ? target : resolveTarget(target, markers)) as HTMLElement
  const text = (resolved.innerText ?? resolved.textContent ?? '').replace(/\s+/g, ' ').trim().slice(0, 400)
  return { chain, text, screen }
}

/**
 * A cropped JPEG of the element, at most 800px wide and under the inline
 * size limit; null when the browser can't draw it (e.g. cross-origin images).
 */
export async function captureElement(el: HTMLElement, timeoutMs = 3000): Promise<string | null> {
  const rect = el.getBoundingClientRect()
  if (rect.width < 4 || rect.height < 4) return null
  const ratio = Math.min(1, 800 / rect.width, 1200 / rect.height)
  const shot = async (quality: number) =>
    toJpeg(el, { pixelRatio: ratio, quality, backgroundColor: '#ffffff', cacheBust: false, skipFonts: true })
  try {
    const timer = new Promise<null>((resolve) => setTimeout(() => resolve(null), timeoutMs))
    for (const q of [0.75, 0.5]) {
      const url = await Promise.race([shot(q), timer])
      if (!url) return null
      if (url.length * 0.75 <= MAX_INLINE_IMAGE_BYTES) return url
    }
    return null
  } catch {
    return null
  }
}
