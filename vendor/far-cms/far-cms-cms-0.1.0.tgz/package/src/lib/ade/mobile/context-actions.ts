/**
 * The long-press sheet's actions: one registry for every surface, so the
 * page editor, Review cards and chat messages show the same menu where they
 * share actions and apps add their own. An action shows only when its
 * target supplies what it needs (an Edit needs an onEdit…), so nothing in
 * the menu is a dead end; none of them does anything irreversible — Hide on
 * phone and Move are drafts, Ask opens the assistant, Copy copies.
 * Pure (no React); asserted by context-actions.assert.ts.
 */

export type ContextTargetKind = 'unit' | 'section' | 'message'

/** What a long-pressed thing offers; actions read from it. */
export interface ContextTarget {
  kind: ContextTargetKind
  /** What it is called on screen ("Hero heading", "Donate button", "your message"). */
  label: string
  /** Its text (a message's words, a heading's text): Copy, Reply, Use as reference. */
  text?: string
  /** A link to it (Copy link). */
  href?: string
  /** It shows a photo (Replace photo). */
  image?: boolean
  // The surface's own handlers; an action needing one is hidden without it.
  onAsk?: () => void
  onEdit?: () => void
  onReplacePhoto?: () => void
  onMove?: () => void
  onHideOnPhone?: () => void
  onOpenOnDesktop?: () => void
  onReply?: () => void
  onUseAsReference?: () => void
}

export interface ContextAction {
  id: string
  label: string
  /** lucide icon name. */
  icon: string
  /** Lower first. */
  order: number
  kinds: readonly ContextTargetKind[]
  /** Shown for this target? (Has what it needs.) */
  available: (t: ContextTarget) => boolean
  run: (t: ContextTarget, env: ContextEnv) => void | Promise<void>
}

/** What actions may use from the host (injected, so core stays app-free). */
export interface ContextEnv {
  copy: (text: string) => Promise<void> | void
  /** Say something quietly ("Link copied"). */
  notify: (message: string) => void
}

const registry = new Map<string, ContextAction>()

export function registerContextAction(a: ContextAction): void {
  registry.set(a.id, a)
}

/** The sheet's rows for this target, in order: only those it can do. */
export function contextActions(t: ContextTarget): ContextAction[] {
  return [...registry.values()].filter((a) => a.kinds.includes(t.kind) && a.available(t)).sort((a, b) => a.order - b.order || a.label.localeCompare(b.label))
}

const unitish = ['unit', 'section'] as const

// The owner's list (2026-10-11): Ask about this · Edit · Replace photo · Move · Hide on phone · Copy link · Open on desktop.
registerContextAction({ id: 'ask', label: 'Ask about this', icon: 'Sparkles', order: 10, kinds: unitish, available: (t) => !!t.onAsk, run: (t) => t.onAsk?.() })
registerContextAction({ id: 'edit', label: 'Edit', icon: 'Pencil', order: 20, kinds: unitish, available: (t) => !!t.onEdit, run: (t) => t.onEdit?.() })
registerContextAction({ id: 'replace-photo', label: 'Replace photo', icon: 'ImagePlus', order: 30, kinds: unitish, available: (t) => !!t.image && !!t.onReplacePhoto, run: (t) => t.onReplacePhoto?.() })
registerContextAction({ id: 'move', label: 'Move', icon: 'ArrowUpDown', order: 40, kinds: unitish, available: (t) => !!t.onMove, run: (t) => t.onMove?.() })
registerContextAction({ id: 'hide-on-phone', label: 'Hide on phone', icon: 'EyeOff', order: 50, kinds: unitish, available: (t) => !!t.onHideOnPhone, run: (t) => t.onHideOnPhone?.() })
registerContextAction({
  id: 'copy-link',
  label: 'Copy link',
  icon: 'Link',
  order: 60,
  kinds: unitish,
  available: (t) => !!t.href,
  run: async (t, env) => {
    await env.copy(t.href!)
    env.notify('Link copied')
  },
})
registerContextAction({ id: 'open-desktop', label: 'Open on desktop', icon: 'Laptop', order: 70, kinds: unitish, available: (t) => !!t.onOpenOnDesktop, run: (t) => t.onOpenOnDesktop?.() })

// Chat messages: Reply · Use as reference · Copy.
registerContextAction({ id: 'reply', label: 'Reply', icon: 'Reply', order: 10, kinds: ['message'], available: (t) => !!t.onReply, run: (t) => t.onReply?.() })
registerContextAction({ id: 'use-as-reference', label: 'Use as reference', icon: 'Quote', order: 20, kinds: ['message'], available: (t) => !!t.onUseAsReference, run: (t) => t.onUseAsReference?.() })
registerContextAction({
  id: 'copy',
  label: 'Copy',
  icon: 'Copy',
  order: 30,
  kinds: ['message'],
  available: (t) => !!t.text?.trim(),
  run: async (t, env) => {
    await env.copy(t.text!)
    env.notify('Copied')
  },
})

/** A message quoted for a reply: its first lines as a markdown quote, then the cursor's line. */
export function replyQuote(text: string, maxChars = 280): string {
  const t = text.replace(/\s+\n/g, '\n').trim()
  const clipped = t.length > maxChars ? `${t.slice(0, maxChars - 1).trimEnd()}…` : t
  return `${clipped.split('\n').map((l) => `> ${l}`).join('\n')}\n\n`
}

/** A message used as a reference for the next prompt: said so, then quoted. */
export function referenceQuote(text: string): string {
  return `Use this as a reference:\n${replyQuote(text)}`
}
