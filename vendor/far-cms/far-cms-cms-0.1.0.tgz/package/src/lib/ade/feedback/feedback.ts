/**
 * Client feedback: what the people running the site send the site's builder
 * (the "Send feedback" button, the assistant's send_feedback_to_owner).
 * Pure validation and shaping; storage and forwarding live in the app
 * bindings. Feedback is always stored first, forwarded after — nothing is
 * lost when forwarding fails. Asserted by feedback.assert.ts.
 */

export const FEEDBACK_KINDS = ['bug', 'confusing', 'idea', 'praise'] as const
export type FeedbackKind = (typeof FEEDBACK_KINDS)[number]
export const FEEDBACK_STATUSES = ['new', 'sent', 'triaged'] as const
export type FeedbackStatus = (typeof FEEDBACK_STATUSES)[number]

export const FEEDBACK_KIND_LABEL: Record<FeedbackKind, string> = {
  bug: 'Something is broken',
  confusing: 'This is confusing',
  idea: 'An idea',
  praise: 'I like this',
}

/** Size caps (the route also caps the request body). */
export const NOTE_MAX = 2000
export const UNIT_REF_MAX = 200
export const ROUTE_MAX = 300
/** Whole request body, bytes. */
export const FEEDBACK_BODY_MAX = 8 * 1024

/**
 * A part of the screen, as pick mode / the assistant's selection names it —
 * by WHAT it is (its role) and WHERE (a structural selector), never by the
 * words on it: a row's text can be a donor's name and amount (F-1).
 */
export interface FeedbackUnit {
  /** Its role ("Row", "Button", "Heading block") — one of UNIT_ROLES; anything else is dropped. */
  role?: string
  /** A structural selector ([data-ui="…"], #id, tag paths, a block id) — see safeSelector. */
  selector?: string
  /** The unit is (or sits inside) [data-ade-private]: its marker, or true. */
  private?: string | boolean
  /** Accepted for old clients and ignored: the text label never gets stored. */
  label?: string
}

/** The roles pick mode names (lib/ade/ui/view-units ROLE_NAMES) — the only words of a unit that are stored. */
export const UNIT_ROLES = ['Section', 'Card', 'Form', 'Dialog', 'Table', 'Row', 'Tabs', 'Tab', 'Menu', 'Option', 'Button', 'Link', 'Field', 'Block', 'Embedded view', 'Element'] as const
const ROLE_SET = new Set<string>(UNIT_ROLES)

// One selector segment: [attr="value"] / #id / tag(:nth-of-type(n)) — values are code-ish words, never sentences.
const SEGMENT = /^(?:\[[\w-]+="[\w.:-]{1,80}"\]|#[\w-]{1,80}|[a-z][a-z0-9]{0,15}(?::nth-of-type\(\d{1,3}\))?)$/
const CONTROL_KEY = /^[\w-]{1,40}=[\w.:-]{1,80}$/
const BLOCK_ID = /^[\w-]{1,80}$/

/** A selector only if it is structural (pick mode's cssPath / control key / block id); null otherwise. */
export function safeSelector(sel: string): string | null {
  const s = sel.trim()
  if (!s || s.length > UNIT_REF_MAX || s.includes('@')) return null
  if (CONTROL_KEY.test(s) || BLOCK_ID.test(s)) return s
  return s.split(/\s*>\s*/).every((seg) => SEGMENT.test(seg)) ? s : null
}

export interface FeedbackInput {
  /** The sender's own idempotency key (the offline queue item id): a retry returns the first row (F-6). */
  clientKey: string | null
  route: string
  unitRef: string | null
  note: string
  kind: FeedbackKind
  screenshotMediaId: string | null
}

export type FeedbackParse = { ok: true; value: FeedbackInput } | { ok: false; error: string }

// Control characters (except newlines/tabs in the note) never get stored.
const CONTROL = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g
const oneLine = (s: string) => s.replace(CONTROL, '').replace(/\s+/g, ' ').trim()
const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s)
const ID = /^[A-Za-z0-9_-]{1,64}$/
const DEDUPE_KEY = /^[A-Za-z0-9_:-]{1,100}$/

/**
 * The reference stored for a part: its name or selector — and for a private
 * one ([data-ade-private]) only that it is private and which kind, never its
 * text. A private part also never gets a screenshot (screenshotAllowed).
 */
export function unitRefFor(u: FeedbackUnit | null | undefined): string | null {
  if (!u) return null
  if (u.private) {
    const marker = typeof u.private === 'string' ? oneLine(u.private).replace(/[^\w-]/g, '').slice(0, 40) : ''
    return marker ? `A private field (${marker})` : 'A private field'
  }
  const role = typeof u.role === 'string' && ROLE_SET.has(oneLine(u.role)) ? oneLine(u.role) : null
  const selector = typeof u.selector === 'string' ? safeSelector(oneLine(u.selector)) : null
  if (role && selector) return clip(`${role} (${selector})`, UNIT_REF_MAX)
  return role ?? selector
}

/** F-7: a unit's fields are strings (or absent) — anything else is a bad request, not a 500. */
function unitShapeOk(u: Record<string, unknown>): boolean {
  return (['role', 'selector', 'label'] as const).every((k) => u[k] === undefined || typeof u[k] === 'string') && (u.private === undefined || typeof u.private === 'string' || typeof u.private === 'boolean')
}

export function screenshotAllowed(u: FeedbackUnit | null | undefined): boolean {
  return !u?.private
}

/** Validate a request body (button or tool) into what is stored. */
export function parseFeedback(body: unknown): FeedbackParse {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return { ok: false, error: 'Feedback is required.' }
  const b = body as Record<string, unknown>
  const kind = typeof b.kind === 'string' && (FEEDBACK_KINDS as readonly string[]).includes(b.kind) ? (b.kind as FeedbackKind) : null
  if (!kind) return { ok: false, error: 'Choose what kind of feedback it is.' }
  const note = typeof b.note === 'string' ? b.note.replace(CONTROL, '').trim() : ''
  if (!note) return { ok: false, error: 'Write (or say) what you noticed.' }
  if (note.length > NOTE_MAX) return { ok: false, error: `Keep it under ${NOTE_MAX} characters.` }
  // The path only: a query can carry search words or record details (?q=ama@…), so it is dropped.
  const route = typeof b.route === 'string' ? oneLine(b.route).split(/[?#]/)[0] : ''
  if (!route.startsWith('/') || route.startsWith('//') || route.length > ROUTE_MAX) return { ok: false, error: 'Which screen was it on?' }
  if (b.unit !== undefined && b.unit !== null && (typeof b.unit !== 'object' || Array.isArray(b.unit) || !unitShapeOk(b.unit as Record<string, unknown>))) {
    return { ok: false, error: 'That part of the screen can’t be attached.' }
  }
  const unit = b.unit ? (b.unit as FeedbackUnit) : null
  if (b.dedupeKey !== undefined && (typeof b.dedupeKey !== 'string' || !DEDUPE_KEY.test(b.dedupeKey))) return { ok: false, error: 'Feedback is required.' }
  const clientKey = typeof b.dedupeKey === 'string' ? b.dedupeKey : null
  // A screenshot of a private part is refused, not quietly dropped.
  const shot = typeof b.screenshotMediaId === 'string' && b.screenshotMediaId ? b.screenshotMediaId : null
  if (shot && !ID.test(shot)) return { ok: false, error: 'That screenshot can’t be attached.' }
  if (shot && !screenshotAllowed(unit)) return { ok: false, error: 'Private fields can’t be sent as a screenshot.' }
  return { ok: true, value: { clientKey, route, unitRef: unitRefFor(unit), note, kind, screenshotMediaId: shot } }
}

/** The assistant's confirmation: one line. */
export function feedbackConfirmation(kind: FeedbackKind, ownerName: string | null): string {
  const to = ownerName?.trim() || 'the site’s builder'
  return kind === 'praise' ? `Sent your note to ${to}.` : `Sent to ${to} — they’ll see which screen it was about.`
}

/** A picked part (pick mode's ElementRef, structurally) → what feedback stores about it. */
export function unitFromPick(ref: { key: string; label: string; private?: boolean } | null | undefined): FeedbackUnit | null {
  if (!ref) return null
  if (ref.private) return { private: true }
  // "Row · Ama Mensah · GHS 400" → "Row": only the role prefix of the hover name leaves the browser.
  const role = ref.label.split(' · ')[0]?.trim() ?? ''
  return { ...(ROLE_SET.has(role) ? { role } : {}), selector: ref.key }
}

/** What the person sees for the picked part in the form (exactly what will be stored). */
export function pickedPartLabel(unit: FeedbackUnit | null): string | null {
  return unitRefFor(unit)
}

/** The request body the button queues (the screenshot's media id is filled in when its upload is done). */
export function feedbackBody(input: { kind: FeedbackKind; note: string; route: string; unit: FeedbackUnit | null; dedupeKey?: string }, screenshotMediaId?: string | null) {
  return {
    ...(input.dedupeKey ? { dedupeKey: input.dedupeKey } : {}),
    kind: input.kind,
    note: input.note,
    route: input.route,
    ...(input.unit ? { unit: input.unit } : {}),
    ...(screenshotMediaId && screenshotAllowed(input.unit) ? { screenshotMediaId } : {}),
  }
}

/**
 * F-3: the assistant may file feedback only when the person's latest message
 * asks for it in their own words ("tell Bubune…", "send feedback…", "report
 * this to the developer"). Text from pages, forms or tool results never
 * counts — only the person's own last message is passed in.
 */
export function asksToSendFeedback(text: string, ownerName: string | null): boolean {
  const t = text.toLowerCase()
  if (!t.trim()) return false
  if (/\bfeedback\b/.test(t)) return true
  const who = ['owner', 'builder', 'developer', 'dev', 'the team who built', ...(ownerName ? [ownerName.toLowerCase()] : [])]
  const verb = /\b(tell|let|send|pass|report|forward|flag|share|notify|message)\b/
  return verb.test(t) && who.some((w) => t.includes(w))
}

/** F-2: the assistant's per-sender cap, and the window an identical note counts as a repeat. */
export const TOOL_FEEDBACK_PER_HOUR = 5
export const DUPLICATE_NOTE_WINDOW_MS = 10 * 60_000
