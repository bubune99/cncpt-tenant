// Moved to @far-cms/core (far-cms packages/core/src/lib/ade/history/index.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/ade/history/index'
