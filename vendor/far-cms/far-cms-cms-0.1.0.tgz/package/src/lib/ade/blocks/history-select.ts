/**
 * Undo / redo keep the selection (F2): the editor clears it on every history step, which hid the
 * panel's footer right after "Undo". The block stays selected when it exists in the restored tree.
 */
interface Node {
  id: string
  children?: ReadonlyArray<Node>
}

const has = (blocks: ReadonlyArray<Node>, id: string): boolean => blocks.some((b) => b.id === id || (!!b.children && has(b.children, id)))

/** The id to re-select after moving history from `index` by `step` (-1 undo, +1 redo); null = none. */
export function selectionAfterStep(history: ReadonlyArray<ReadonlyArray<Node>>, index: number, step: -1 | 1, selectedId: string | null): string | null {
  const target = history[index + step]
  if (!selectedId || !target) return null
  return has(target, selectedId) ? selectedId : null
}
