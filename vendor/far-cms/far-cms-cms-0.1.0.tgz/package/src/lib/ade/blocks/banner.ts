/**
 * Banner extras for builder v2 (owner-reviewed mock, 2026-10-18): a container's background
 * image + focal point, an overlay colour (a design token by name, or a hex) with its
 * opacity, and where the words sit (3×3). They live on the real Block: block.background
 * (url, position "x% y%", overlay CSS) and flex classes. Pure; asserted by banner.assert.ts.
 */

export interface Focal {
  x: number
  y: number
}

const KEYWORD: Readonly<Record<string, Focal>> = { center: { x: 50, y: 50 }, top: { x: 50, y: 0 }, bottom: { x: 50, y: 100 }, left: { x: 0, y: 50 }, right: { x: 100, y: 50 } }

/** A background-position as a focal point ("30% 60%", or a keyword). */
export function focalOf(position: string | undefined): Focal {
  if (!position) return { x: 50, y: 50 }
  if (KEYWORD[position]) return KEYWORD[position]
  const m = /^(\d{1,3}(?:\.\d+)?)%\s+(\d{1,3}(?:\.\d+)?)%$/.exec(position.trim())
  return m ? { x: Math.min(100, Number(m[1])), y: Math.min(100, Number(m[2])) } : { x: 50, y: 50 }
}

export function positionOf(f: Focal): string {
  const r = (n: number) => Math.round(Math.min(100, Math.max(0, n)))
  return `${r(f.x)}% ${r(f.y)}%`
}

/**
 * The overlay CSS for a colour value + opacity: a token by name (var(--primary)) or a hex,
 * mixed with transparency so the picture shows through.
 */
export function overlayCss(color: string, opacity: number): string {
  const o = Math.round(Math.min(100, Math.max(0, opacity)))
  const c = /^#[0-9a-f]{6}$/i.test(color) ? color.toLowerCase() : `var(--${color})`
  return `color-mix(in srgb, ${c} ${o}%, transparent)`
}

/** An overlay written by overlayCss, read back (anything else → null: shown as custom, left alone). */
export function parseOverlay(css: string | undefined): { color: string; opacity: number } | null {
  if (!css) return null
  const m = /^color-mix\(in srgb, (?:var\(--([a-z][a-z0-9-]*)\)|(#[0-9a-f]{6})) (\d{1,3})%, transparent\)$/i.exec(css.trim())
  if (!m) return null
  return { color: m[1] ?? m[2].toLowerCase(), opacity: Number(m[3]) }
}

/** The 3×3 text position as flex-column classes: vertical = justify-*, horizontal = items-*. */
export const PLACE_CELLS = ['top-left', 'top-center', 'top-right', 'middle-left', 'middle-center', 'middle-right', 'bottom-left', 'bottom-center', 'bottom-right'] as const
export type PlaceCell = (typeof PLACE_CELLS)[number]
const V: Readonly<Record<string, string>> = { top: 'justify-start', middle: 'justify-center', bottom: 'justify-end' }
const H: Readonly<Record<string, string>> = { left: 'items-start', center: 'items-center', right: 'items-end' }
const OWNED = new Set([...Object.values(V), ...Object.values(H)])

export function readPlace(className: string): PlaceCell | undefined {
  const cls = className.split(/\s+/)
  if (!cls.includes('flex-col')) return undefined
  const v = Object.entries(V).find(([, c]) => cls.includes(c))?.[0]
  const h = Object.entries(H).find(([, c]) => cls.includes(c))?.[0]
  return v && h ? (`${v}-${h}` as PlaceCell) : undefined
}

/** Write a position: the container becomes a flex column; only our justify-/items- classes are replaced. */
export function writePlace(className: string, cell: PlaceCell | undefined): string {
  const kept = className.split(/\s+/).filter((c) => c && !OWNED.has(c))
  if (!cell) return kept.join(' ')
  const [v, h] = cell.split('-')
  const out = [...kept]
  if (!out.includes('flex')) out.push('flex')
  if (!out.includes('flex-col')) out.push('flex-col')
  return [...out, V[v], H[h]].join(' ')
}

export function placeLabel(cell: string): string {
  const [v, h] = cell.split('-')
  const vv = v === 'middle' ? 'Middle' : v[0].toUpperCase() + v.slice(1)
  return h === 'center' ? (v === 'middle' ? 'Center' : `${vv} center`) : `${vv} ${h}`
}
