/**
 * The Blocks tab (owner 2026-10-19): the building pieces — container, row, column, bento grid, heading,
 * button, image, form… — drawn as live mini renders you drag onto the page or click to add. Curated
 * groups first (clean defaults in the site's style); every other template follows in "More blocks"
 * groups, so the old developer-only "Advanced building blocks" list is folded in.
 *
 * Each block has `build` (what goes on the page, fresh ids) and `preview` (a small sample of it, a real
 * block tree drawn by the mini render). Pure; asserted by basic-blocks.assert.ts.
 */

import type { Block } from '../../block-editor/types'
import { BLOCK_TEMPLATES, BLOCK_CATEGORIES } from '../../block-editor/block-templates'
import { generateId } from '../../block-editor/tree-utils'

/** Drag payload prefix on 'application/template-id' (the canvas resolves it: canvas-block resolveTemplateDrop). */
export const BASIC_DRAG_PREFIX = 'basic:'

export interface BasicBlock {
  id: string
  name: string
  /** Extra words people might search for. */
  keywords?: string
  build: () => Block
  preview: () => Block
}

export interface BasicGroup {
  id: string
  label: string
  items: BasicBlock[]
}

const NAVY = 'text-[#022b39]'
const ACCENT_BG = 'bg-[#b45309]'

function b(tag: string, className: string, text?: string | null, children?: Block[], attrs?: Record<string, string>, extra?: Partial<Block>): Block {
  return {
    id: generateId(),
    tag,
    className,
    ...(text ? { textContent: text } : {}),
    ...(children ? { children } : {}),
    ...(attrs ? { attrs } : {}),
    ...(extra ?? {}),
  } as Block
}

const empty = (className: string) => b('div', className, null, [])
const tile = (className = '') => b('div', `rounded-lg bg-slate-200 ${className}`.trim(), null, [])
const bar = (w: string) => b('div', `h-3 ${w} rounded bg-slate-300`, null, [])

const IMG = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80'
const AVATAR = 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&q=80'

const item = (id: string, name: string, build: () => Block, preview: () => Block = build, keywords?: string): BasicBlock => ({ id, name, build, preview, keywords })

export const BASIC_GROUPS: ReadonlyArray<BasicGroup> = [
  {
    id: 'layout',
    label: 'Layout',
    items: [
      item('container', 'Container', () => ({ ...empty('mx-auto w-full max-w-5xl px-4 py-8'), label: 'Container' }), () => b('div', 'w-[420px] rounded-xl border-2 border-dashed border-slate-400 p-5 space-y-3', null, [bar('w-3/5'), bar('w-2/5')]), 'box wrapper'),
      item('row', 'Row', () => ({ ...b('div', 'flex flex-col gap-6 md:flex-row', null, [empty('min-h-24 flex-1'), empty('min-h-24 flex-1'), empty('min-h-24 flex-1')]), label: 'Row' }), () => b('div', 'flex w-[420px] gap-3', null, [tile('h-36 flex-1'), tile('h-36 flex-1'), tile('h-36 flex-1')]), 'horizontal side by side'),
      item('column', 'Column', () => ({ ...b('div', 'flex flex-col gap-4', null, [empty('min-h-16'), empty('min-h-16')]), label: 'Column' }), () => b('div', 'flex w-[220px] flex-col gap-3', null, [tile('h-12'), tile('h-12'), tile('h-12')]), 'vertical stack'),
      item('two-columns', 'Two columns', () => ({ ...b('div', 'grid grid-cols-1 gap-6 md:grid-cols-2', null, [empty('min-h-24'), empty('min-h-24')]), label: 'Two columns' }), () => b('div', 'grid w-[420px] grid-cols-2 gap-3', null, [tile('h-36'), tile('h-36')]), 'grid 2'),
      item('three-columns', 'Three columns', () => ({ ...b('div', 'grid grid-cols-1 gap-6 md:grid-cols-3', null, [empty('min-h-24'), empty('min-h-24'), empty('min-h-24')]), label: 'Three columns' }), () => b('div', 'grid w-[420px] grid-cols-3 gap-3', null, [tile('h-36'), tile('h-36'), tile('h-36')]), 'grid 3'),
      item(
        'bento',
        'Bento grid',
        () => ({ ...b('div', 'grid grid-cols-1 gap-4 md:grid-cols-4 md:grid-rows-2', null, [empty('min-h-48 rounded-2xl bg-slate-100 p-6 md:col-span-2 md:row-span-2'), empty('min-h-24 rounded-2xl bg-slate-100 p-6 md:col-span-2'), empty('min-h-24 rounded-2xl bg-slate-100 p-6'), empty('min-h-24 rounded-2xl bg-slate-100 p-6')]), label: 'Bento grid' }),
        () => b('div', 'grid h-40 w-[420px] grid-cols-4 grid-rows-2 gap-3', null, [tile('col-span-2 row-span-2 bg-indigo-200'), tile('col-span-2 bg-amber-200'), tile(), tile()]),
        'mosaic tiles'
      ),
      item('card', 'Card', () => ({ ...b('div', 'rounded-2xl border border-slate-200 bg-white p-6 shadow-sm', null, [b('h3', `text-xl font-semibold ${NAVY}`, 'Card title'), b('p', 'mt-2 text-slate-600', 'A sentence about this card.')]), label: 'Card' }), () => b('div', 'w-[300px] rounded-2xl bg-white p-5 shadow-lg ring-1 ring-slate-200 space-y-3', null, [tile('h-20'), bar('w-3/4'), bar('w-1/2')])),
      item('section', 'Section', () => ({ ...b('section', 'w-full px-4 py-16', null, [b('div', 'mx-auto max-w-5xl', null, [b('h2', `text-3xl font-bold ${NAVY}`, 'Section title'), b('p', 'mt-3 text-lg text-slate-600', 'Say what this part of the page is about.')])]), label: 'Section' }), () => b('div', 'w-[440px] rounded-lg bg-slate-100 p-6 space-y-3', null, [b('h3', `text-2xl font-bold ${NAVY}`, 'Section'), bar('w-4/5'), bar('w-3/5')])),
    ],
  },
  {
    id: 'text',
    label: 'Text',
    items: [
      item('heading', 'Heading', () => b('h2', `text-4xl font-bold tracking-tight ${NAVY}`, 'Heading'), () => b('h2', `text-5xl font-extrabold ${NAVY}`, 'Heading'), 'title h1 h2'),
      item('subheading', 'Subheading', () => b('h3', `text-2xl font-semibold ${NAVY}`, 'Subheading'), () => b('h3', `text-4xl font-bold ${NAVY}`, 'Subheading'), 'h3'),
      item('paragraph', 'Paragraph', () => b('p', 'text-lg leading-relaxed text-slate-600', 'Tell people what this part of the page is about, in a sentence or two.'), () => b('p', 'w-[380px] text-xl leading-relaxed text-slate-600', 'Tell people what this part of the page is about, in a sentence or two.'), 'text body'),
      item('small-text', 'Small text', () => b('p', 'text-sm text-slate-500', 'Small print and captions'), () => b('p', 'text-lg text-slate-500', 'Small print and captions'), 'caption'),
      item('quote', 'Quote', () => b('blockquote', `border-l-4 border-[#b45309] pl-6 text-xl italic ${NAVY}`, 'A short quote from someone you helped.'), () => b('blockquote', `w-[380px] border-l-8 border-[#b45309] pl-6 text-2xl italic ${NAVY}`, 'A short quote from someone you helped.'), 'testimonial blockquote'),
      item('badge', 'Badge', () => b('span', 'inline-block rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800', 'New'), () => b('span', 'inline-block rounded-full bg-amber-100 px-6 py-2 text-xl font-semibold text-amber-800', 'New'), 'tag label pill'),
      item('link', 'Link', () => b('a', 'font-semibold text-[#088cbc] underline', 'Read the full story', undefined, { href: '#' }), () => b('a', 'text-2xl font-semibold text-[#088cbc] underline', 'Read the full story', undefined, { href: '#' })),
    ],
  },
  {
    id: 'media',
    label: 'Media',
    items: [
      item('image', 'Image', () => b('img', 'h-auto w-full rounded-lg object-cover', null, undefined, { src: IMG, alt: '' }), () => b('img', 'h-[200px] w-[340px] rounded-lg object-cover', null, undefined, { src: IMG, alt: '' }), 'photo picture'),
      item('video', 'Video', () => b('video', 'w-full rounded-lg', null, undefined, { src: '', controls: '' }), () => b('div', 'grid h-[200px] w-[340px] place-items-center rounded-lg bg-slate-900', null, [b('div', 'h-0 w-0 border-y-[22px] border-l-[38px] border-y-transparent border-l-white', null, [])]), 'movie clip'),
      item('avatar', 'Avatar', () => b('img', 'h-16 w-16 rounded-full object-cover', null, undefined, { src: AVATAR, alt: '' }), () => b('img', 'h-28 w-28 rounded-full object-cover', null, undefined, { src: AVATAR, alt: '' }), 'person profile photo'),
      item('icon-box', 'Icon box', () => b('div', 'flex flex-col gap-3', null, [b('div', 'h-12 w-12 rounded-xl bg-sky-100', null, []), b('h3', `text-lg font-semibold ${NAVY}`, 'Clean water'), b('p', 'text-slate-600', 'One line about it.')]), () => b('div', 'w-[260px] space-y-3', null, [b('div', 'h-14 w-14 rounded-xl bg-sky-100', null, []), b('h3', `text-2xl font-bold ${NAVY}`, 'Clean water'), bar('w-3/4')]), 'feature'),
      item('divider', 'Divider', () => b('hr', 'my-8 border-t border-slate-200'), () => b('div', 'h-1 w-[380px] rounded bg-slate-300', null, []), 'line rule hr'),
      item('spacer', 'Spacer', () => ({ ...empty('h-12'), label: 'Spacer' }), () => b('span', 'grid h-28 w-[340px] place-items-center rounded-lg border-2 border-dashed border-slate-300 text-lg text-slate-400', 'space'), 'gap'),
    ],
  },
  {
    id: 'actions',
    label: 'Buttons & lists',
    items: [
      item('button', 'Button', () => b('a', `inline-block rounded-md ${ACCENT_BG} px-6 py-3 font-semibold text-white hover:opacity-90`, 'Learn more', undefined, { href: '#' }), () => b('span', `inline-block rounded-lg ${ACCENT_BG} px-10 py-4 text-2xl font-bold text-white`, 'Learn more'), 'cta call to action'),
      item('outline-button', 'Outline button', () => b('a', `inline-block rounded-md border-2 border-[#022b39] px-6 py-3 font-semibold ${NAVY} hover:bg-slate-50`, 'Learn more', undefined, { href: '#' }), () => b('span', `inline-block rounded-lg border-4 border-[#022b39] px-10 py-4 text-2xl font-bold ${NAVY}`, 'Learn more')),
      item('text-button', 'Text button', () => b('a', 'font-semibold text-[#b45309] underline', 'Learn more', undefined, { href: '#' }), () => b('span', 'text-2xl font-bold text-[#b45309] underline', 'Learn more'), 'ghost'),
      item('list', 'List', () => b('ul', 'list-disc space-y-1 pl-6 text-slate-700', null, [b('li', '', 'First point'), b('li', '', 'Second point'), b('li', '', 'Third point')]), () => b('ul', 'list-disc space-y-1 pl-8 text-2xl text-slate-700', null, [b('li', '', 'Food parcels'), b('li', '', 'School fees'), b('li', '', 'Clean water')]), 'bullets ul'),
    ],
  },
  {
    id: 'forms',
    label: 'Forms',
    items: [
      item(
        'form',
        'Form',
        () => b('div', 'w-full max-w-xl mx-auto py-8', null, undefined, { 'data-form-slug': '' }, { componentName: 'FormBlock', label: 'Form' }),
        () => b('div', 'w-[320px] space-y-3', null, [b('p', `text-2xl font-bold ${NAVY}`, 'Stay in touch'), b('div', 'h-10 rounded-md border-2 border-slate-300', null, []), b('div', 'h-10 rounded-md border-2 border-slate-300', null, []), b('span', `inline-block rounded-md ${ACCENT_BG} px-6 py-2 text-lg font-bold text-white`, 'Sign up')]),
        'contact newsletter signup popup'
      ),
    ],
  },
]

/** Templates the curated groups already cover (by template label). */
const COVERED = new Set([
  'Section', 'Flex Row', 'Flex Column', 'Grid 2-Col', 'Grid 3-Col', 'Container', 'Card',
  'Heading 1', 'Heading 2', 'Heading 3', 'Paragraph', 'Small Text', 'Link', 'Blockquote', 'Badge',
  'Image', 'Avatar', 'Video', 'Divider', 'Spacer', 'Icon Box',
  'Button', 'Outline Button', 'Ghost Button', 'List (UL)', 'Form',
])

const COMMERCE_CATS = new Set(['commerce', 'smart-commerce'])
const MORE_LABEL: Record<string, string> = { layout: 'More layout', typography: 'More text', media: 'More media', interactive: 'More interactive', form: 'Form fields', initiative: 'Initiatives', commerce: 'Shop', 'smart-commerce': 'Shop (live data)', 'smart-dashboard': 'Account pages' }

/** A template as a fresh block (the editor's own addBlockFromTemplate shape). */
export function blockFromTemplate(label: string): Block | null {
  const t = BLOCK_TEMPLATES.find((x) => x.label === label)
  if (!t) return null
  return {
    id: generateId(),
    tag: t.tag,
    className: t.defaultClassName,
    ...(t.defaultTextContent ? { textContent: t.defaultTextContent } : {}),
    ...(t.defaultAttrs ? { attrs: { ...t.defaultAttrs } } : {}),
    ...(t.isContainer ? { children: [] } : {}),
    ...(t.componentName ? { componentName: t.componentName } : {}),
    ...(t.defaultCommerce ? { commerce: { ...t.defaultCommerce } } : {}),
  } as Block
}

/** Live-data blocks (smart blocks) show a named card, not a render. */
export const previewIsCard = (blk: Block) => !!blk.componentName

/** Every template the curated groups don't cover, in its category ("More blocks"); shop ones only with the shop on. */
export function moreGroups(commerce: boolean): BasicGroup[] {
  return BLOCK_CATEGORIES.filter((c) => commerce || !COMMERCE_CATS.has(c.id))
    .map((c) => ({
      id: `more-${c.id}`,
      label: MORE_LABEL[c.id] ?? c.label,
      items: BLOCK_TEMPLATES.filter((t) => t.category === c.id && !COVERED.has(t.label)).map((t) =>
        item(`tpl:${t.label}`, t.label, () => blockFromTemplate(t.label)!, () => blockFromTemplate(t.label)!, t.description)
      ),
    }))
    .filter((g) => g.items.length > 0)
}

/** All groups for the Blocks tab. */
export function blockGroups(commerce: boolean): BasicGroup[] {
  return [...BASIC_GROUPS, ...moreGroups(commerce)]
}

/** Search by name or keywords (case-insensitive); empty groups drop out. */
export function searchBlocks(groups: readonly BasicGroup[], q: string): BasicGroup[] {
  const s = q.trim().toLowerCase()
  if (!s) return [...groups]
  return groups
    .map((g) => ({ ...g, items: g.items.filter((i) => `${i.name} ${i.keywords ?? ''} ${g.label}`.toLowerCase().includes(s)) }))
    .filter((g) => g.items.length > 0)
}

/** A dragged or clicked block id → the block to put on the page (fresh ids), or null. */
export function buildBasic(id: string): Block | null {
  if (id.startsWith('tpl:')) return blockFromTemplate(id.slice(4))
  for (const g of BASIC_GROUPS) {
    const it = g.items.find((i) => i.id === id)
    if (it) return it.build()
  }
  return null
}

/**
 * Where a clicked block goes, "where you're working": into the selected container (at its end), right
 * after a selected piece, or at the end of the page when nothing is selected.
 */
export function whereToAdd(blocks: readonly Block[], selectedId: string | null): { parentId: string | null; index: number } {
  if (selectedId) {
    const walk = (list: readonly Block[], parentId: string | null): { parentId: string | null; index: number } | null => {
      for (let i = 0; i < list.length; i++) {
        const blk = list[i]
        if (blk.id === selectedId) {
          const container = Array.isArray(blk.children) && !blk.componentName && !blk.partialId && !blk.locked
          return container ? { parentId: blk.id, index: blk.children!.length } : { parentId, index: i + 1 }
        }
        if (blk.children?.length) {
          const hit = walk(blk.children, blk.id)
          if (hit) return hit
        }
      }
      return null
    }
    const hit = walk(blocks, null)
    if (hit) return hit
  }
  return { parentId: null, index: blocks.length }
}
