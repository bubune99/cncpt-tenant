/**
 * The v2 design panel's fields (v0 Design Mode inventory, owner 2026-10-18),
 * as data: label, control, scale (Tailwind tokens), device-aware, maps-to.
 * readField / writeField turn a block's className / text into the panel's
 * values and back through lib/ade/blocks/class-map — so a field change is a
 * className edit on the real Block, and Kofi can use the same table later.
 * Slice 1: Content + Typography. Pure; asserted by design-fields.assert.ts.
 */

import { colorScale, cornerScale, LAYOUT_SCALES, OPACITY_SCALE, readScale, SCALES, setDevice, sizeScale, spacingScale, writeScale, effective, type DeviceValues, type Scale, type ScaleToken } from './class-map'
import { DESIGN_COLORS } from '../../ade-bindings/design-colors'
import { focalOf, overlayCss, parseOverlay, positionOf, readPlace, writePlace, type PlaceCell } from './banner'

export type DesignDevice = 'desktop' | 'tablet' | 'mobile'

export type DesignControl = 'textarea' | 'select' | 'segmented' | 'color' | 'scrub' | 'link' | 'media' | 'focal' | 'align-grid' | 'text'

export interface DesignField {
  key: string
  label: string
  control: DesignControl
  /** class-backed fields name their scale; text fields write the block's textContent. */
  /** `fallback`: shorthand scales the value comes from when this one isn't set (pt → py → p). */
  source: { kind: 'class'; scale: string; fallback?: ReadonlyArray<string> } | { kind: 'text' } | { kind: 'attr'; name: string; options?: ReadonlyArray<ScaleToken> } | { kind: 'visibility' } | { kind: 'bg'; part: 'url' | 'position' | 'overlayColor' | 'overlayOpacity' } | { kind: 'place' }
  /** Rendered together as a small grid (margin / padding sides, corners). */
  group?: 'size' | 'margin' | 'padding' | 'corners'
  /** Its short label inside a group ("Top"). */
  short?: string
  /** px unit shown beside scrub inputs. */
  unit?: string
  deviceAware: boolean
  /** Allow a typed custom value (an arbitrary class) beside the scale's tokens. */
  custom?: boolean
  hint?: string
}

export interface DesignSection {
  id: string
  label: string
  fields: ReadonlyArray<DesignField>
  /** Only for some blocks (Content: text elements only). */
  when?: (b: BlockLike) => boolean
}

export interface BlockLike {
  tag: string
  className: string
  textContent?: string
  attrs?: Readonly<Record<string, string>>
  background?: { url?: string; position?: string; overlay?: string; size?: string; attachment?: string }
}

/** Elements whose words are edited in Content. */
const TEXT_TAGS = new Set(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'a', 'button', 'li', 'label', 'blockquote', 'figcaption', 'small', 'strong', 'em'])
export const isTextBlock = (b: BlockLike) => TEXT_TAGS.has(b.tag)
/** Containers that can carry a background image (the Banner extras). */
const CONTAINER_TAGS = new Set(['section', 'header', 'footer', 'main', 'div', 'article', 'aside'])
export const isContainerBlock = (b: BlockLike) => CONTAINER_TAGS.has(b.tag)
export const isImageBlock = (b: BlockLike) => b.tag === 'img'

/** Elements that can link somewhere. */
export const isLinkBlock = (b: BlockLike) => b.tag === 'a' || b.tag === 'button'

export const FONT_FAMILY: Scale = {
  id: 'font-family',
  tokens: [
    { value: 'sans', cls: 'font-sans', label: 'Sans' },
    { value: 'serif', cls: 'font-serif', label: 'Serif' },
  ],
}

const COLOR_TOKENS = DESIGN_COLORS.map((c) => c.token)
const SIDES = [
  ['t', 'Top', ['y']],
  ['b', 'Bottom', ['y']],
  ['l', 'Left', ['x']],
  ['r', 'Right', ['x']],
] as const
const spacingScales = (k: 'p' | 'm') =>
  Object.fromEntries([k, `${k}x`, `${k}y`, ...SIDES.map(([s]) => `${k}${s}`)].map((pre) => [pre, spacingScale(pre, pre, { auto: k === 'm' })]))

const ALL_SCALES: Readonly<Record<string, Scale>> = {
  ...SCALES,
  ...LAYOUT_SCALES,
  ...spacingScales('p'),
  ...spacingScales('m'),
  width: sizeScale('width', 'w'),
  'min-height': sizeScale('min-height', 'min-h'),
  height: sizeScale('height', 'h'),
  opacity: OPACITY_SCALE,
  'border-color': colorScale('border-color', 'border', DESIGN_COLORS.map((c) => c.token)),
  'radius-tl': cornerScale('tl'),
  'radius-tr': cornerScale('tr'),
  'radius-br': cornerScale('br'),
  'radius-bl': cornerScale('bl'),
  'font-family': FONT_FAMILY,
  'text-color': colorScale('text-color', 'text', COLOR_TOKENS),
  'bg-color': colorScale('bg-color', 'bg', COLOR_TOKENS),
}
export const scaleOf = (id: string): Scale => {
  const s = ALL_SCALES[id]
  if (!s) throw new Error(`Unknown scale ${id}`)
  return s
}

export const DESIGN_SECTIONS: ReadonlyArray<DesignSection> = [
  // Block extras first (the mock): Banner / Image / Link sit above the generic sections.
  {
    id: 'banner',
    label: 'Banner',
    when: isContainerBlock,
    fields: [
      { key: 'bgImage', label: 'Background image', control: 'media', source: { kind: 'bg', part: 'url' }, deviceAware: false },
      { key: 'bgFocal', label: 'Focal point', control: 'focal', source: { kind: 'bg', part: 'position' }, deviceAware: false, hint: 'Drag the dot to the part of the picture that must always show.' },
      { key: 'overlayColor', label: 'Overlay', control: 'color', source: { kind: 'bg', part: 'overlayColor' }, deviceAware: false, hint: 'Darkens the picture so the words stay readable.' },
      { key: 'overlayOpacity', label: 'Overlay opacity', control: 'scrub', source: { kind: 'bg', part: 'overlayOpacity' }, deviceAware: false, unit: '%' },
      { key: 'textPosition', label: 'Text position', control: 'align-grid', source: { kind: 'place' }, deviceAware: false },
      { key: 'minHeight', label: 'Minimum height', control: 'scrub', source: { kind: 'class', scale: 'min-height' }, deviceAware: true, unit: 'px' },
    ],
  },
  {
    id: 'image',
    label: 'Image',
    when: isImageBlock,
    fields: [
      { key: 'src', label: 'Picture', control: 'media', source: { kind: 'attr', name: 'src' }, deviceAware: false },
      { key: 'alt', label: 'Describe the picture', control: 'text', source: { kind: 'attr', name: 'alt' }, deviceAware: false, hint: 'Alt text: read aloud to people who can’t see it.' },
    ],
  },
  {
    id: 'link',
    label: 'Link',
    when: isLinkBlock,
    fields: [
      { key: 'href', label: 'Goes to', control: 'link', source: { kind: 'attr', name: 'href' }, deviceAware: false, hint: 'A page on this site, or a full web address.' },
      {
        key: 'target',
        label: 'Opens in',
        control: 'segmented',
        source: { kind: 'attr', name: 'target', options: [{ value: '_self', cls: '', label: 'Same tab' }, { value: '_blank', cls: '', label: 'New tab' }] },
        deviceAware: false,
      },
    ],
  },
  {
    id: 'content',
    label: 'Content',
    when: isTextBlock,
    fields: [{ key: 'text', label: 'Text', control: 'textarea', source: { kind: 'text' }, deviceAware: false }],
  },
  {
    id: 'typography',
    label: 'Typography',
    fields: [
      { key: 'fontFamily', label: 'Font', control: 'select', source: { kind: 'class', scale: 'font-family' }, deviceAware: false },
      { key: 'fontSize', label: 'Size', control: 'select', source: { kind: 'class', scale: 'font-size' }, deviceAware: true, custom: true },
      { key: 'fontWeight', label: 'Weight', control: 'select', source: { kind: 'class', scale: 'font-weight' }, deviceAware: false },
      { key: 'fontStyle', label: 'Style', control: 'segmented', source: { kind: 'class', scale: 'font-style' }, deviceAware: false },
      { key: 'lineHeight', label: 'Line height', control: 'select', source: { kind: 'class', scale: 'line-height' }, deviceAware: true, custom: true },
      { key: 'letterSpacing', label: 'Letter spacing', control: 'select', source: { kind: 'class', scale: 'letter-spacing' }, deviceAware: false, custom: true },
      { key: 'textAlign', label: 'Alignment', control: 'segmented', source: { kind: 'class', scale: 'text-align' }, deviceAware: true },
      { key: 'textTransform', label: 'Case', control: 'segmented', source: { kind: 'class', scale: 'text-transform' }, deviceAware: false },
      { key: 'textDecoration', label: 'Decoration', control: 'segmented', source: { kind: 'class', scale: 'text-decoration' }, deviceAware: false },
    ],
  },
  {
    id: 'color',
    label: 'Color',
    fields: [{ key: 'textColor', label: 'Text', control: 'color', source: { kind: 'class', scale: 'text-color' }, deviceAware: false }],
  },
  {
    id: 'background',
    label: 'Background',
    fields: [{ key: 'bgColor', label: 'Background', control: 'color', source: { kind: 'class', scale: 'bg-color' }, deviceAware: false }],
  },
  {
    id: 'layout',
    label: 'Layout',
    fields: [
      { key: 'display', label: 'Display', control: 'select', source: { kind: 'class', scale: 'display' }, deviceAware: true },
      { key: 'width', label: 'Width', short: 'Width', group: 'size', control: 'scrub', source: { kind: 'class', scale: 'width' }, deviceAware: true, unit: 'px', hint: 'Pixels, or auto, full, fit, 1/2, 50%.' },
      { key: 'height', label: 'Height', short: 'Height', group: 'size', control: 'scrub', source: { kind: 'class', scale: 'height' }, deviceAware: true, unit: 'px' },
      ...sideFields('m', 'margin', 'Margin'),
      ...sideFields('p', 'padding', 'Padding'),
    ],
  },
  {
    id: 'border',
    label: 'Border',
    fields: [
      { key: 'borderColor', label: 'Color', control: 'color', source: { kind: 'class', scale: 'border-color' }, deviceAware: false },
      { key: 'borderStyle', label: 'Style', control: 'select', source: { kind: 'class', scale: 'border-style' }, deviceAware: false },
      { key: 'borderWidth', label: 'Width', control: 'select', source: { kind: 'class', scale: 'border-width' }, deviceAware: false, custom: true },
    ],
  },
  {
    id: 'appearance',
    label: 'Appearance',
    fields: [
      { key: 'opacity', label: 'Opacity', control: 'scrub', source: { kind: 'class', scale: 'opacity' }, deviceAware: false, unit: '%' },
      { key: 'radius', label: 'Corner radius', control: 'select', source: { kind: 'class', scale: 'radius' }, deviceAware: false, custom: true },
      { key: 'radiusTL', label: 'Top left radius', short: 'Top left', group: 'corners', control: 'select', source: { kind: 'class', scale: 'radius-tl', fallback: ['radius'] }, deviceAware: false },
      { key: 'radiusTR', label: 'Top right radius', short: 'Top right', group: 'corners', control: 'select', source: { kind: 'class', scale: 'radius-tr', fallback: ['radius'] }, deviceAware: false },
      { key: 'radiusBL', label: 'Bottom left radius', short: 'Bottom left', group: 'corners', control: 'select', source: { kind: 'class', scale: 'radius-bl', fallback: ['radius'] }, deviceAware: false },
      { key: 'radiusBR', label: 'Bottom right radius', short: 'Bottom right', group: 'corners', control: 'select', source: { kind: 'class', scale: 'radius-br', fallback: ['radius'] }, deviceAware: false },
    ],
  },
  {
    id: 'shadow',
    label: 'Shadow',
    fields: [{ key: 'shadow', label: 'Preset', control: 'select', source: { kind: 'class', scale: 'shadow' }, deviceAware: false }],
  },
  {
    id: 'visibility',
    label: 'Visibility',
    fields: [{ key: 'showOn', label: 'Show on', control: 'select', source: { kind: 'visibility' }, deviceAware: false }],
  },
]

/** "Show on" choices; each maps to display classes per device (hidden where it shouldn't show). */
export const SHOW_ON_CHOICES: ReadonlyArray<ScaleToken> = [
  { value: 'all', cls: '', label: 'All devices' },
  { value: 'hide-mobile', cls: '', label: 'Hide on phones' },
  { value: 'hide-tablet', cls: '', label: 'Hide on tablets' },
  { value: 'hide-desktop', cls: '', label: 'Hide on desktop' },
  { value: 'desktop-only', cls: '', label: 'Desktop only' },
  { value: 'mobile-only', cls: '', label: 'Phones only' },
]
const HIDDEN_BY: Readonly<Record<string, ReadonlyArray<DesignDevice>>> = {
  all: [],
  'hide-mobile': ['mobile'],
  'hide-tablet': ['tablet'],
  'hide-desktop': ['desktop'],
  'desktop-only': ['tablet', 'mobile'],
  'mobile-only': ['desktop', 'tablet'],
}

/** Which "Show on" choice a block's display classes amount to (a mix that matches none reads as "all"). */
export function visibilityOf(d: DeviceValues): string {
  const hidden = (['desktop', 'tablet', 'mobile'] as const).filter((dev) => effective(d, dev) === 'none')
  const hit = Object.entries(HIDDEN_BY).find(([, devs]) => devs.length === hidden.length && devs.every((x) => hidden.includes(x)))
  return hit ? hit[0] : 'all'
}

/** Display device values that show a choice: hidden = `none`; a shown device keeps its own display, or `block` if it must undo a hide. */
export function withVisibility(d: DeviceValues, choice: string): DeviceValues {
  const hide = HIDDEN_BY[choice] ?? []
  const visible = (dev: DesignDevice) => {
    const cur = effective(d, dev)
    return cur !== undefined && cur !== 'none' ? cur : undefined
  }
  const want = (dev: DesignDevice) => (hide.includes(dev) ? 'none' : visible(dev))
  const desktop = want('desktop')
  let tablet = want('tablet')
  let mobile = want('mobile')
  // A shown device below a hidden one needs its own value to undo the hide.
  if (tablet === undefined && desktop === 'none') tablet = 'block'
  if (mobile === undefined && (tablet ?? desktop) === 'none') mobile = 'block'
  const out: DeviceValues = {}
  if (desktop !== undefined) out.base = desktop
  if (tablet !== undefined && tablet !== desktop) out.tablet = tablet
  if (mobile !== undefined && mobile !== (tablet ?? desktop)) out.mobile = mobile
  return out
}

/** Spacing presets under padding / margin fields (S/M/L/XL, px). */
export const SPACING_PRESETS: ReadonlyArray<{ id: 'S' | 'M' | 'L' | 'XL'; value: string }> = [
  { id: 'S', value: '8' },
  { id: 'M', value: '16' },
  { id: 'L', value: '32' },
  { id: 'XL', value: '64' },
]

/** The badge beside a field's label: All, or the devices with their own value (M, T, MT). */
export function deviceBadge(b: BlockLike, field: DesignField): 'All' | 'M' | 'T' | 'MT' {
  const o = overriddenOn(b, field)
  return o.includes('tablet') && o.includes('mobile') ? 'MT' : o.includes('mobile') ? 'M' : o.includes('tablet') ? 'T' : 'All'
}

/** "was: 48px" — a field's value at the last Apply, in words (token label, or the raw value). */
export function wasLabel(before: BlockLike, field: DesignField, device: DesignDevice): string {
  const v = readField(before, field, device)
  if (v === undefined || v === '') return 'was: default'
  const tok = tokensOf(field).find((t) => t.value === v)
  const shown = tok ? tok.label : /^\d+(\.\d+)?$/.test(v) && field.unit ? `${v}${field.unit}` : v
  return `was: ${shown.length > 40 ? `${shown.slice(0, 39)}…` : shown}`
}

/**
 * The "was:" note under a changed field, for the device on screen (F3). This device changed →
 * "was: 18px". Only another device changed → named: "Mobile was: 18px". Nothing changed → null.
 */
export function wasNote(before: BlockLike, now: BlockLike, field: DesignField, device: DesignDevice): string | null {
  if (readField(before, field, device) !== readField(now, field, device)) return wasLabel(before, field, device)
  if (!field.deviceAware) return null
  const names = { desktop: 'Desktop', tablet: 'Tablet', mobile: 'Mobile' } as const
  const other = (['desktop', 'tablet', 'mobile'] as const).find((d) => d !== device && readField(before, field, d) !== readField(now, field, d))
  return other ? `${names[other]} ${wasLabel(before, field, other)}` : null
}

/** Margin / padding: one field per side; each reads through its shorthands (mt → my → m) and writes only its side. */
function sideFields(k: 'p' | 'm', group: 'margin' | 'padding', name: string): DesignField[] {
  return SIDES.map(([side, short, axis]) => ({
    key: `${group}${short}`,
    label: `${name} ${short.toLowerCase()}`,
    short,
    group,
    control: 'scrub' as const,
    source: { kind: 'class' as const, scale: `${k}${side}`, fallback: [`${k}${axis[0]}`, k] },
    deviceAware: true,
    unit: 'px',
  }))
}

export function sectionsFor(b: BlockLike): DesignSection[] {
  return DESIGN_SECTIONS.filter((s) => !s.when || s.when(b))
}

export function designField(key: string): DesignField | undefined {
  return DESIGN_SECTIONS.flatMap((s) => s.fields).find((f) => f.key === key)
}

export function tokensOf(field: DesignField): ReadonlyArray<ScaleToken> {
  if (field.source.kind === 'visibility') return SHOW_ON_CHOICES
  if (field.source.kind === 'attr') return field.source.options ?? []
  return field.source.kind === 'class' ? scaleOf(field.source.scale).tokens : []
}

/** A field's device values on a block. */
export function readDevices(b: BlockLike, field: DesignField): DeviceValues {
  if (field.source.kind === 'text') return b.textContent === undefined ? {} : { base: b.textContent }
  if (field.source.kind === 'place') {
    const v = readPlace(b.className ?? '')
    return v ? { base: v } : {}
  }
  if (field.source.kind === 'bg') {
    const bg = b.background
    const ov = parseOverlay(bg?.overlay)
    const v =
      field.source.part === 'url' ? bg?.url : field.source.part === 'position' ? (bg?.url ? positionOf(focalOf(bg.position)) : undefined) : field.source.part === 'overlayColor' ? ov?.color : ov ? String(ov.opacity) : undefined
    return v ? { base: v } : {}
  }
  if (field.source.kind === 'visibility') {
    const v = visibilityOf(readScale(b.className ?? '', scaleOf('display')))
    return v === 'all' ? {} : { base: v }
  }
  if (field.source.kind === 'attr') {
    const v = b.attrs?.[field.source.name]
    return v === undefined || v === '' ? {} : { base: v }
  }
  return readScale(b.className ?? '', scaleOf(field.source.scale))
}

/** What the panel shows for a field on a device. */
export function readField(b: BlockLike, field: DesignField, device: DesignDevice): string | undefined {
  const pick = (d: DeviceValues) => (field.deviceAware ? effective(d, device) : d.base ?? d.tablet ?? d.mobile)
  const own = pick(readDevices(b, field))
  if (own !== undefined || field.source.kind !== 'class' || !field.source.fallback) return own
  // Not set on its own: what the shorthand gives it (padding-top from py-*, then p-*).
  for (const fb of field.source.fallback) {
    const v = pick(readScale(b.className ?? '', scaleOf(fb)))
    if (v !== undefined) return v
  }
  return undefined
}

/** The block change a field edit makes (className or textContent). Undefined value clears that device. */
export function writeField(b: BlockLike, field: DesignField, value: string | undefined, device: DesignDevice): Partial<BlockLike> {
  if (field.source.kind === 'text') return { textContent: value ?? '' }
  if (field.source.kind === 'place') return { className: writePlace(b.className ?? '', value as PlaceCell | undefined) }
  if (field.source.kind === 'bg') return { background: writeBackground(b.background, field.source.part, value) }
  if (field.source.kind === 'visibility') {
    const display = scaleOf('display')
    return { className: writeScale(b.className ?? '', display, withVisibility(readScale(b.className ?? '', display), value ?? 'all')) }
  }
  if (field.source.kind === 'attr') {
    const attrs = { ...(b.attrs ?? {}) }
    // "Same tab" is the default: no attribute at all.
    if (value === undefined || value === '' || (field.source.name === 'target' && value === '_self')) delete attrs[field.source.name]
    else attrs[field.source.name] = value
    return { attrs }
  }
  const scale = scaleOf(field.source.scale)
  const cur = readScale(b.className ?? '', scale)
  const next = field.deviceAware ? setDevice(cur, device, value) : value === undefined ? {} : { base: value }
  return { className: writeScale(b.className ?? '', scale, next) }
}

/** Devices with their own value for a field (badges). */
export function overriddenOn(b: BlockLike, field: DesignField): Array<'tablet' | 'mobile'> {
  if (!field.deviceAware) return []
  const d = readDevices(b, field)
  return (['tablet', 'mobile'] as const).filter((k) => d[k] !== undefined)
}

const same = (a: DeviceValues, b: DeviceValues) => a.base === b.base && a.tablet === b.tablet && a.mobile === b.mobile

/** Fields that differ between the snapshot (last Apply) and now — the dots; the count is its length. */
export function changedFields(before: BlockLike, now: BlockLike): string[] {
  return sectionsFor(now)
    .flatMap((s) => s.fields)
    .filter((f) => !same(readDevices(before, f), readDevices(now, f)))
    .map((f) => f.key)
}

/**
 * A link that won't work: a path that isn't one of the site's pages, or a malformed web
 * address. Null when it's fine (or empty). `pagePaths` are the site's page paths ("/about").
 */
/**
 * What the Link field checks (F4): while "Another website…" is open, the address being TYPED
 * (so "abc" gets the bad-address message, not the old link's missing-page one); otherwise the
 * stored link.
 */
export function linkFieldWarning(stored: string | undefined, typed: string | null, pagePaths: ReadonlyArray<string> | null): string | null {
  return typed !== null ? hrefWarning(typed, pagePaths) : hrefWarning(stored, pagePaths)
}

export function hrefWarning(href: string | undefined, pagePaths: ReadonlyArray<string> | null): string | null {
  const h = (href ?? '').trim()
  if (!h || /^(#|mailto:|tel:)/i.test(h)) return null
  if (h.startsWith('/')) {
    if (!pagePaths) return null
    const path = h.split(/[?#]/)[0].replace(/\/+$/, '') || '/'
    // The home page is always there, even when the page list names it "home".
    return path === '/' || pagePaths.includes(path) ? null : 'That page isn’t on this site any more — pick another.'
  }
  try {
    const u = new URL(h)
    return u.protocol === 'https:' || u.protocol === 'http:' ? null : 'Use a web address that starts with https://.'
  } catch {
    return 'That doesn’t look like a web address — try https://…'
  }
}

/** The overlay a new colour or opacity starts from (55% — readable over most pictures). */
export const DEFAULT_OVERLAY_OPACITY = 55

/** block.background after one Banner field changes. No picture → no background at all. */
export function writeBackground(bg: BlockLike['background'], part: 'url' | 'position' | 'overlayColor' | 'overlayOpacity', value: string | undefined): BlockLike['background'] {
  const cur = { ...(bg ?? {}) }
  if (part === 'url') {
    if (!value) return undefined
    return { size: 'cover', ...cur, url: value }
  }
  if (!cur.url) return bg
  if (part === 'position') return { ...cur, position: value ?? 'center' }
  const ov = parseOverlay(cur.overlay)
  if (part === 'overlayColor') {
    if (!value) {
      const { overlay: _drop, ...rest } = cur
      return rest
    }
    return { ...cur, overlay: overlayCss(value, ov?.opacity ?? DEFAULT_OVERLAY_OPACITY) }
  }
  const n = value === undefined ? DEFAULT_OVERLAY_OPACITY : Number(value)
  return { ...cur, overlay: overlayCss(ov?.color ?? 'foreground', Number.isFinite(n) ? n : DEFAULT_OVERLAY_OPACITY) }
}

/** An image without alt text (accessibility): flagged under the field. */
export function altMissing(b: BlockLike): boolean {
  return b.tag === 'img' && !!b.attrs?.src && !(b.attrs?.alt ?? '').trim()
}
