/**
 * Group, ungroup and lock (owner 2026-10-19): select several elements (Shift+click on the page or in the
 * Outline), group them into one element you can drag and move as a unit, ungroup it again, and lock an
 * element (and everything inside it) so it cannot be moved, resized or restyled by accident.
 *
 * A group is a plain container (div, named "Group") put where the first selected element was. It takes
 * its parent's flow (a row stays a row, a stack a stack, with the same gap) so the page looks the same
 * once grouped. How rows, columns and containers should really work is a later, separate model.
 *
 * Pure; asserted by grouping.assert.ts. The editor applies the new tree as ONE undo step.
 */

import type { Block } from '../../block-editor/types'

export const GROUP_LABEL = 'Group'

/** Every block in document order, with its parent and index. */
function walk(blocks: Block[], parent: Block | null = null, out: Array<{ block: Block; parent: Block | null; index: number }> = []) {
  blocks.forEach((block, index) => {
    out.push({ block, parent, index })
    if (block.children?.length) walk(block.children, block, out)
  })
  return out
}

/** The chain of blocks from the top of the page down to `id` (inclusive), or [] when absent. */
export function pathTo(blocks: Block[], id: string): Block[] {
  for (const b of blocks) {
    if (b.id === id) return [b]
    if (b.children?.length) {
      const rest = pathTo(b.children, id)
      if (rest.length) return [b, ...rest]
    }
  }
  return []
}

/** Locked itself or inside a locked element. */
export function isLockedAt(blocks: Block[], id: string): boolean {
  return pathTo(blocks, id).some((b) => b.locked === true)
}

/** The selection to act on: existing ids, none inside another selected one, in page order. */
export function topLevel(blocks: Block[], ids: readonly string[]): string[] {
  const want = new Set(ids)
  return walk(blocks)
    .filter(({ block }) => want.has(block.id))
    .map(({ block }) => block.id)
    .filter((id) => !pathTo(blocks, id).slice(0, -1).some((a) => want.has(a.id)))
}

const GAP = /^(?:[a-z0-9-]+:)*gap(?:-[xy])?-\S+$/

/** A group's classes: the parent's flow (row or stack) and gap, so grouping doesn't change the look. */
export function groupClassFor(parentClassName: string | undefined): string {
  const tokens = (parentClassName ?? '').split(/\s+/).filter(Boolean)
  const has = (t: string) => tokens.includes(t)
  const gaps = tokens.filter((t) => GAP.test(t))
  if (has('grid')) return ['flex', 'flex-col', ...gaps].join(' ')
  if (has('flex') || has('inline-flex')) {
    const row = !has('flex-col')
    return [
      'flex',
      ...(row ? ['flex-wrap', 'items-center'] : ['flex-col']),
      ...gaps,
      // A responsive stack-to-row parent: keep the same switch.
      ...tokens.filter((t) => /^(?:sm|md|lg|xl):flex-(?:row|col)$/.test(t)),
    ].join(' ')
  }
  return ''
}

export type GroupResult = { ok: true; blocks: Block[]; groupId: string } | { ok: false; reason: string }

/** Put the selected elements into one new group, where the first of them was. */
export function groupBlocks(blocks: Block[], ids: readonly string[], newId: string): GroupResult {
  const picked = topLevel(blocks, ids)
  if (picked.length === 0) return { ok: false, reason: 'Select the elements to group first.' }
  if (picked.some((id) => isLockedAt(blocks, id))) return { ok: false, reason: 'Unlock the locked elements first.' }
  const all = walk(blocks)
  const first = all.find((w) => w.block.id === picked[0])!
  const parentId = first.parent?.id ?? null
  const members = picked.map((id) => all.find((w) => w.block.id === id)!.block)
  const group: Block = {
    id: newId,
    tag: 'div',
    className: groupClassFor(first.parent?.className),
    label: GROUP_LABEL,
    parentId,
    children: members.map((m) => ({ ...m, parentId: newId })),
  }
  const out = without(blocks, new Set(picked.slice(1)))
  return { ok: true, blocks: replace(out, picked[0], group), groupId: newId }
}

/** Can this element be ungrouped: a plain container (div) with something inside, not locked. */
export function canUngroup(blocks: Block[], id: string): boolean {
  const b = pathTo(blocks, id).at(-1)
  return !!b && String(b.tag) === 'div' && (b.children?.length ?? 0) > 0 && !b.componentName && !b.partialId && !isLockedAt(blocks, id)
}

export type UngroupResult = { ok: true; blocks: Block[]; childIds: string[] } | { ok: false; reason: string }

/** Take a group apart: its elements go back where the group was, in the same order. */
export function ungroupBlock(blocks: Block[], id: string): UngroupResult {
  if (!canUngroup(blocks, id)) return { ok: false, reason: isLockedAt(blocks, id) ? 'Unlock it first.' : 'Only a group (a plain container with elements in it) can be ungrouped.' }
  const path = pathTo(blocks, id)
  const group = path.at(-1)!
  const parentId = path.at(-2)?.id ?? null
  const kids = (group.children ?? []).map((c) => ({ ...c, parentId }))
  return { ok: true, blocks: splice(blocks, id, kids), childIds: kids.map((k) => k.id) }
}

/** Lock all (or, when all are already locked, unlock all). */
export function toggleLock(blocks: Block[], ids: readonly string[]): { blocks: Block[]; locked: boolean } {
  const picked = topLevel(blocks, ids)
  const lock = !picked.every((id) => pathTo(blocks, id).at(-1)?.locked === true)
  const set = new Set(picked)
  const apply = (list: Block[]): Block[] =>
    list.map((b) => {
      const kids = b.children?.length ? apply(b.children) : b.children
      if (!set.has(b.id)) return kids === b.children ? b : { ...b, children: kids }
      const { locked: _l, ...rest } = b
      void _l
      return lock ? { ...rest, children: kids, locked: true } : { ...rest, children: kids }
    })
  return { blocks: apply(blocks), locked: lock }
}

// ── tree helpers (immutable) ──

function without(list: Block[], drop: Set<string>): Block[] {
  return list
    .filter((b) => !drop.has(b.id))
    .map((b) => (b.children?.length ? { ...b, children: without(b.children, drop) } : b))
}

function replace(list: Block[], id: string, next: Block): Block[] {
  return splice(list, id, [next])
}

function splice(list: Block[], id: string, nexts: Block[]): Block[] {
  const at = list.findIndex((b) => b.id === id)
  if (at >= 0) return [...list.slice(0, at), ...nexts, ...list.slice(at + 1)]
  return list.map((b) => (b.children?.length ? { ...b, children: splice(b.children, id, nexts) } : b))
}

// ── several selected at once ──

/** The selection: the main one (the Style tab shows it) plus the others picked with Shift. */
export interface MultiSelection {
  primary: string | null
  also: readonly string[]
}

/** Shift+click: add an element to the selection, or take it out again. */
export function shiftToggle(sel: MultiSelection, id: string): MultiSelection {
  if (!sel.primary) return { primary: id, also: [] }
  if (id === sel.primary) return sel.also.length ? { primary: sel.also[0], also: sel.also.slice(1) } : sel
  if (sel.also.includes(id)) return { primary: sel.primary, also: sel.also.filter((x) => x !== id) }
  return { primary: sel.primary, also: [...sel.also, id] }
}

/** Every selected id, main first. */
export const selectedIds = (sel: MultiSelection): string[] => (sel.primary ? [sel.primary, ...sel.also.filter((x) => x !== sel.primary)] : [])

/** The keys: Ctrl+G groups, Ctrl+Shift+G ungroups, Ctrl+Shift+L locks or unlocks (the Command key on a Mac). */
export function groupShortcut(e: { key: string; metaKey: boolean; ctrlKey: boolean; shiftKey: boolean; altKey: boolean }): 'group' | 'ungroup' | 'lock' | null {
  if (!(e.metaKey || e.ctrlKey) || e.altKey) return null
  const k = e.key.toLowerCase()
  if (k === 'g') return e.shiftKey ? 'ungroup' : 'group'
  if (k === 'l' && e.shiftKey) return 'lock'
  return null
}
