/**
 * What builder v2 puts in the REAL assistant's composer (owner 2026-10-18): the "Ask" entry on a
 * panel section and the panel's prompt box only FILL the composer — the selected block
 * attached as context — and never send. The person finishes and sends it themselves.
 * Pure; asserted by ask-assistant.assert.ts.
 */

export interface AskInput {
  /** The selected block's plain name ("Hero"). */
  blockName: string
  /** The panel section it was asked from ("Typography"); none for the footer prompt. */
  section?: string
  /** What the person typed in the panel's prompt box. */
  prompt?: string
  /** The design direction picked in the footer ("Calm"). */
  direction?: string
}

const clean = (s: string | undefined, max: number) => (s ?? '').replace(/\s+/g, ' ').trim().slice(0, max)

/**
 * The composer text: a section ask is an opening the person completes; a typed prompt is
 * kept as written. Both name the block (the reference chip carries the exact element).
 */
export function askText(a: AskInput): string {
  const name = clean(a.blockName, 60) || 'this block'
  const prompt = clean(a.prompt, 2000)
  const dir = clean(a.direction, 30)
  const tail = dir ? ` Keep it ${dir.toLowerCase()}.` : ''
  if (prompt) return `${prompt}${/[.!?]$/.test(prompt) ? '' : '.'} (On “${name}”.)${tail}`
  const where = clean(a.section, 40)
  return where ? `Change the ${where.toLowerCase()} of “${name}”: ` : `Change “${name}”: `
}
