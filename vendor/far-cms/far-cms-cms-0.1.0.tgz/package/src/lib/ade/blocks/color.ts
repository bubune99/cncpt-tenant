/**
 * Colour maths for the design panel's picker (v0's: saturation/brightness
 * square, hue bar, alpha bar). HSV ⇄ hex, alpha as a percentage, and what a
 * colour value means (a design token by name, or a custom hex).
 * Pure; asserted by color.assert.ts.
 */

export interface Hsva {
  /** 0–360 */
  h: number
  /** 0–100 */
  s: number
  /** 0–100 */
  v: number
  /** 0–100 */
  a: number
}

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n))
const hex2 = (n: number) => Math.round(clamp(n, 0, 255)).toString(16).padStart(2, '0')

export function hsvaToHex(c: Hsva): string {
  const s = clamp(c.s, 0, 100) / 100
  const v = clamp(c.v, 0, 100) / 100
  const h = (((c.h % 360) + 360) % 360) / 60
  const i = Math.floor(h)
  const f = h - i
  const p = v * (1 - s)
  const q = v * (1 - s * f)
  const t = v * (1 - s * (1 - f))
  const [r, g, b] = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6]
  const a = clamp(c.a, 0, 100)
  return `#${hex2(r * 255)}${hex2(g * 255)}${hex2(b * 255)}${a >= 100 ? '' : hex2((a / 100) * 255)}`
}

export function hexToHsva(hex: string): Hsva | null {
  const m = /^#?([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(hex.trim())
  if (!m) return null
  const n = parseInt(m[1], 16)
  const r = ((n >> 16) & 255) / 255
  const g = ((n >> 8) & 255) / 255
  const b = (n & 255) / 255
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  const d = max - min
  let h = 0
  if (d) {
    if (max === r) h = ((g - b) / d) % 6
    else if (max === g) h = (b - r) / d + 2
    else h = (r - g) / d + 4
    h *= 60
    if (h < 0) h += 360
  }
  // Two decimals keep hex → HSV → hex exact (whole numbers drift by one step).
  const r2 = (x: number) => Math.round(x * 100) / 100
  return { h: r2(h), s: r2(max ? (d / max) * 100 : 0), v: r2(max * 100), a: m[2] ? Math.round((parseInt(m[2], 16) / 255) * 100) : 100 }
}

/** A colour value: a design token ("primary", "primary/80") or a custom hex. */
export type ColorRef = { kind: 'token'; name: string; alpha: number } | { kind: 'custom'; hex: string }

export function parseColorValue(v: string | undefined): ColorRef | null {
  if (!v) return null
  if (/^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(v)) return { kind: 'custom', hex: v.toLowerCase() }
  const m = /^([a-z][a-z0-9-]*?)(?:\/(\d{1,3}))?$/.exec(v)
  return m ? { kind: 'token', name: m[1], alpha: m[2] === undefined ? 100 : Number(m[2]) } : null
}

export function formatColorRef(c: ColorRef): string {
  return c.kind === 'custom' ? c.hex.toLowerCase() : c.alpha >= 100 ? c.name : `${c.name}/${Math.round(c.alpha)}`
}

/** What the value field shows: "Brand / Primary · 80%" for a token, the hex for a custom colour. */
export function colorLabel(c: ColorRef | null, tokenLabel: (name: string) => string): string {
  if (!c) return 'Default'
  if (c.kind === 'custom') return c.hex
  return c.alpha >= 100 ? tokenLabel(c.name) : `${tokenLabel(c.name)} · ${c.alpha}%`
}

/** Square / bar keyboard moves (arrows, Shift = 10×). */
export function nudge(n: number, key: string, shift: boolean, lo: number, hi: number, up: string[], down: string[]): number {
  const step = shift ? 10 : 1
  if (up.includes(key)) return clamp(n + step, lo, hi)
  if (down.includes(key)) return clamp(n - step, lo, hi)
  return n
}
