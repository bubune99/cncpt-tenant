/**
 * Field ⇄ className, for the v2 design panel (owner 2026-10-18: the schema's
 * mapsTo is APPLIED). Every class-backed field names a SCALE: the Tailwind
 * tokens it may write (with an arbitrary `[…]` value as the escape hatch).
 *
 * Devices map onto Tailwind's mobile-first prefixes:
 *   unprefixed = mobile, md: = tablet, lg: = desktop.
 * The panel's model is desktop-first (Desktop is the base; Tablet / Mobile
 * override), so writing emits the fewest classes that show the right value on
 * each device, and reading turns the prefixes back into base + overrides.
 * Round trips are asserted (class-map.assert.ts).
 * Pure; no React, no DOM.
 */

export interface ScaleToken {
  value: string
  cls: string
  label: string
}

export interface Scale {
  id: string
  tokens: ReadonlyArray<ScaleToken>
  /** An arbitrary value class for this scale (`text-[17px]`), if custom values are allowed. */
  arbitrary?: { prefix: string; pattern: RegExp }
  /** Open-ended scales (colours: any design token, with /alpha): read and write by rule instead of a token list. */
  dynamic?: { parse: (util: string) => string | null; format: (value: string) => string | null }
}

const t = (value: string, cls: string, label = value): ScaleToken => ({ value, cls, label })

/** Tailwind's type scale (px) — what v0's Size select lists. */
const FONT_SIZE: ReadonlyArray<ScaleToken> = [
  t('12', 'text-xs', '12px'), t('14', 'text-sm', '14px'), t('16', 'text-base', '16px'), t('18', 'text-lg', '18px'), t('20', 'text-xl', '20px'),
  t('24', 'text-2xl', '24px'), t('30', 'text-3xl', '30px'), t('36', 'text-4xl', '36px'), t('48', 'text-5xl', '48px'), t('60', 'text-6xl', '60px'),
  t('72', 'text-7xl', '72px'), t('96', 'text-8xl', '96px'), t('128', 'text-9xl', '128px'),
]

export const SCALES: Readonly<Record<string, Scale>> = {
  'font-size': { id: 'font-size', tokens: FONT_SIZE, arbitrary: { prefix: 'text-', pattern: /^text-\[(\d+(?:\.\d+)?(?:px|rem|em))\]$/ } },
  'font-weight': {
    id: 'font-weight',
    tokens: [t('100', 'font-thin', 'Thin'), t('200', 'font-extralight', 'Extra light'), t('300', 'font-light', 'Light'), t('400', 'font-normal', 'Regular'), t('500', 'font-medium', 'Medium'), t('600', 'font-semibold', 'Semibold'), t('700', 'font-bold', 'Bold'), t('800', 'font-extrabold', 'Extra bold'), t('900', 'font-black', 'Black')],
  },
  'font-style': { id: 'font-style', tokens: [t('normal', 'not-italic', 'Normal'), t('italic', 'italic', 'Italic')] },
  'line-height': {
    id: 'line-height',
    tokens: [t('1', 'leading-none', 'None'), t('1.25', 'leading-tight', 'Tight'), t('1.375', 'leading-snug', 'Snug'), t('1.5', 'leading-normal', 'Normal'), t('1.625', 'leading-relaxed', 'Relaxed'), t('2', 'leading-loose', 'Loose')],
    arbitrary: { prefix: 'leading-', pattern: /^leading-\[(\d+(?:\.\d+)?(?:px|rem|em)?)\]$/ },
  },
  'letter-spacing': {
    id: 'letter-spacing',
    tokens: [t('-0.05em', 'tracking-tighter', 'Tighter'), t('-0.025em', 'tracking-tight', 'Tight'), t('0', 'tracking-normal', 'Normal'), t('0.025em', 'tracking-wide', 'Wide'), t('0.05em', 'tracking-wider', 'Wider'), t('0.1em', 'tracking-widest', 'Widest')],
    arbitrary: { prefix: 'tracking-', pattern: /^tracking-\[(-?\d+(?:\.\d+)?(?:px|rem|em))\]$/ },
  },
  'text-align': { id: 'text-align', tokens: [t('left', 'text-left', 'Left'), t('center', 'text-center', 'Center'), t('right', 'text-right', 'Right'), t('justify', 'text-justify', 'Justify')] },
  'text-transform': { id: 'text-transform', tokens: [t('none', 'normal-case', 'None'), t('capitalize', 'capitalize', 'Aa'), t('uppercase', 'uppercase', 'AA'), t('lowercase', 'lowercase', 'aa')] },
  'text-decoration': { id: 'text-decoration', tokens: [t('none', 'no-underline', 'None'), t('underline', 'underline', 'Underline'), t('line-through', 'line-through', 'Strikethrough'), t('overline', 'overline', 'Overline')] },
}

/**
 * '' / md: / lg: carry a value with a base. With NO base (nothing set for desktop), an override
 * uses a range so it can't leak to other devices: max-md: (phone), md:max-lg: (tablet),
 * max-lg: (phone + tablet).
 */
export type Prefix = '' | 'md:' | 'lg:' | 'max-md:' | 'md:max-lg:' | 'max-lg:'
const PREFIXES: ReadonlyArray<Prefix> = ['', 'md:', 'lg:', 'max-lg:', 'md:max-lg:', 'max-md:']

/** Split a class into its breakpoint prefix (only md:/lg: are ours) and the utility. */
function splitPrefix(cls: string): { prefix: Prefix | null; util: string } {
  if (cls.startsWith('md:max-lg:')) return { prefix: 'md:max-lg:', util: cls.slice(10) }
  if (cls.startsWith('max-md:')) return { prefix: 'max-md:', util: cls.slice(7) }
  if (cls.startsWith('max-lg:')) return { prefix: 'max-lg:', util: cls.slice(7) }
  if (cls.startsWith('md:')) return { prefix: 'md:', util: cls.slice(3) }
  if (cls.startsWith('lg:')) return { prefix: 'lg:', util: cls.slice(3) }
  // Any other variant (hover:, sm:, dark:…) is not ours to read or rewrite.
  if (cls.includes(':')) return { prefix: null, util: cls }
  return { prefix: '', util: cls }
}

/** The scale value a utility class stands for, or null if it isn't one of this scale's. */
export function valueOfClass(scale: Scale, util: string): string | null {
  if (scale.dynamic) return scale.dynamic.parse(util)
  const tok = scale.tokens.find((x) => x.cls === util)
  if (tok) return tok.value
  const m = scale.arbitrary?.pattern.exec(util)
  return m ? `[${m[1]}]` : null
}

/** The class that writes a value (a token, or an arbitrary `[…]` value). */
export function classOfValue(scale: Scale, value: string): string | null {
  if (scale.dynamic) return scale.dynamic.format(value)
  const tok = scale.tokens.find((x) => x.value === value)
  if (tok) return tok.cls
  if (scale.arbitrary && /^\[.+\]$/.test(value)) {
    const cls = `${scale.arbitrary.prefix}${value}`
    return scale.arbitrary.pattern.test(cls) ? cls : null
  }
  return null
}

/** This scale's values by prefix, as found in a className (the last one wins, like CSS). */
export function readPrefixed(className: string, scale: Scale): Partial<Record<Prefix, string>> {
  const out: Partial<Record<Prefix, string>> = {}
  for (const cls of className.split(/\s+/).filter(Boolean)) {
    const { prefix, util } = splitPrefix(cls)
    if (prefix === null) continue
    const v = valueOfClass(scale, util)
    if (v !== null) out[prefix] = v
  }
  return out
}

/** Device values (desktop-first) for a field. `base` undefined = nothing set. */
export interface DeviceValues {
  base?: string
  tablet?: string
  mobile?: string
}

/** Prefixes → desktop-first values: base = lg ?? md ?? plain; overrides only where they differ. */
export function toDeviceValues(p: Partial<Record<Prefix, string>>): DeviceValues {
  const un = p['']
  const md = p['md:'] ?? un
  const lg = p['lg:'] ?? md
  // Ranges (no base): what phone and tablet see on top of the plain/md:/lg: values.
  const tabletRange = p['md:max-lg:'] ?? p['max-lg:']
  const phoneRange = p['max-md:'] ?? p['max-lg:']
  const desktop = lg
  const tablet = tabletRange ?? md
  const phone = phoneRange ?? un ?? tabletRange
  const out: DeviceValues = {}
  if (desktop !== undefined) out.base = desktop
  if (tablet !== undefined && tablet !== desktop) out.tablet = tablet
  if (phone !== undefined && phone !== (tablet ?? desktop)) out.mobile = phone
  return out
}

/** Desktop-first values → the fewest prefixed values that show them. */
export function toPrefixed(d: DeviceValues): Partial<Record<Prefix, string>> {
  if (d.base === undefined && d.tablet === undefined && d.mobile === undefined) return {}
  if (d.base === undefined) {
    // No desktop value: ranges only, so nothing leaks to the other devices.
    const phone = d.mobile ?? d.tablet
    if (d.tablet !== undefined && phone === d.tablet) return { 'max-lg:': d.tablet }
    const out: Partial<Record<Prefix, string>> = {}
    if (d.tablet !== undefined) out['md:max-lg:'] = d.tablet
    if (d.mobile !== undefined) out['max-md:'] = d.mobile
    return out
  }
  const desktop = d.base
  const tablet = d.tablet ?? desktop
  const mobile = d.mobile ?? tablet
  const out: Partial<Record<Prefix, string>> = {}
  if (mobile !== undefined) out[''] = mobile
  if (tablet !== undefined && tablet !== mobile) out['md:'] = tablet
  if (desktop !== undefined && desktop !== tablet) out['lg:'] = desktop
  return out
}

/** Remove this scale's classes (every prefix we own) and write the new ones; other classes keep their order. */
export function writeScale(className: string, scale: Scale, d: DeviceValues): string {
  const kept = className.split(/\s+/).filter(Boolean).filter((cls) => {
    const { prefix, util } = splitPrefix(cls)
    return prefix === null || valueOfClass(scale, util) === null
  })
  const p = toPrefixed(d)
  const added = PREFIXES.flatMap((pre) => {
    const v = p[pre]
    const cls = v === undefined ? null : classOfValue(scale, v)
    return cls ? [`${pre}${cls}`] : []
  })
  return [...kept, ...added].join(' ')
}

/** Read a scale's device values from a className. */
export function readScale(className: string, scale: Scale): DeviceValues {
  return toDeviceValues(readPrefixed(className, scale))
}

/** What a device sees: mobile → tablet → base. */
export function effective(d: DeviceValues, device: 'desktop' | 'tablet' | 'mobile'): string | undefined {
  if (device === 'mobile') return d.mobile ?? d.tablet ?? d.base
  if (device === 'tablet') return d.tablet ?? d.base
  return d.base
}

/** Set one device's value; setting desktop changes the base (overrides stay). Undefined clears that device. */
export function setDevice(d: DeviceValues, device: 'desktop' | 'tablet' | 'mobile', value: string | undefined): DeviceValues {
  const key = device === 'desktop' ? 'base' : device
  const next = { ...d, [key]: value }
  if (value === undefined) delete next[key]
  // An override equal to what it would inherit is no override.
  if (next.tablet !== undefined && next.tablet === next.base) delete next.tablet
  if (next.mobile !== undefined && next.mobile === (next.tablet ?? next.base)) delete next.mobile
  return next
}

/**
 * A colour scale for a utility prefix (`text`, `bg`, `border`): values are a design-system
 * token name with an optional alpha ("primary", "primary/80") or a custom hex ("#1f6f6b",
 * "#1f6f6bcc"). Tokens are stored by NAME (text-primary/80), customs as arbitrary classes
 * (text-[#1f6f6b]). Only the given token names are read as colours, so text-center or
 * bg-cover never are.
 */
export function colorScale(id: string, prefix: string, tokens: ReadonlyArray<string>): Scale {
  // Design tokens, plus Tailwind's own palette (text-white, bg-gray-100…): read so a new colour REPLACES
  // them instead of fighting them in the cascade; shown by their own name.
  const palette = /^(white|black|transparent|current|inherit|(slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-(50|[1-9]00|950))$/
  const known = (n: string) => tokens.includes(n) || palette.test(n)
  const hex = /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i
  return {
    id,
    tokens: tokens.map((name) => ({ value: name, cls: `${prefix}-${name}`, label: name })),
    dynamic: {
      parse: (util) => {
        if (!util.startsWith(`${prefix}-`)) return null
        const rest = util.slice(prefix.length + 1)
        const arb = /^\[(#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?)\]$/.exec(rest)
        if (arb) return arb[1].toLowerCase()
        const m = /^([a-z][a-z0-9-]*?)(?:\/(\d{1,3}))?$/.exec(rest)
        if (!m || !known(m[1])) return null
        const a = m[2] === undefined ? null : Number(m[2])
        if (a !== null && (a < 0 || a > 100)) return null
        return a === null || a === 100 ? m[1] : `${m[1]}/${a}`
      },
      format: (value) => {
        if (hex.test(value)) return `${prefix}-[${value.toLowerCase()}]`
        const m = /^([a-z][a-z0-9-]*?)(?:\/(\d{1,3}))?$/.exec(value)
        if (!m || !known(m[1])) return null
        const a = m[2] === undefined ? 100 : Number(m[2])
        if (a < 0 || a > 100) return null
        return a === 100 ? `${prefix}-${m[1]}` : `${prefix}-${m[1]}/${a}`
      },
    },
  }
}

/** Numbers as the panel shows them ("16", "0.5"): no trailing zeros. */
const num = (n: number) => String(Math.round(n * 100) / 100)

/**
 * A spacing scale for one utility prefix (`pt`, `px`, `p`, `mt`, `m`…): values are px
 * ("16"), "auto" (margins), or a custom "[1.5rem]". Tailwind v4 spacing is any multiple
 * of 0.25rem: p-4 = 16px, p-0.5 = 2px, p-px = 1px; other px values become p-[13px].
 */
export function spacingScale(id: string, prefix: string, opts: { auto?: boolean } = {}): Scale {
  const tokens: ScaleToken[] = [0, 2, 4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128].map((px) => ({ value: String(px), cls: `${prefix}-${num(px / 4)}`, label: `${px}px` }))
  if (opts.auto) tokens.push({ value: 'auto', cls: `${prefix}-auto`, label: 'Auto' })
  return {
    id,
    tokens,
    dynamic: {
      parse: (util) => {
        if (!util.startsWith(`${prefix}-`)) return null
        const rest = util.slice(prefix.length + 1)
        if (rest === 'px') return '1'
        if (rest === 'auto') return opts.auto ? 'auto' : null
        if (/^\d+(\.\d+)?$/.test(rest)) return num(Number(rest) * 4)
        const arb = /^\[(\d+(?:\.\d+)?)px\]$/.exec(rest)
        if (arb) return num(Number(arb[1]))
        const other = /^\[(\d+(?:\.\d+)?(?:rem|em|%|vh|vw))\]$/.exec(rest)
        return other ? `[${other[1]}]` : null
      },
      format: (value) => {
        if (value === 'auto') return opts.auto ? `${prefix}-auto` : null
        if (/^\[\d+(?:\.\d+)?(?:rem|em|%|vh|vw)\]$/.test(value)) return `${prefix}-${value}`
        if (!/^\d+(\.\d+)?$/.test(value)) return null
        const px = Number(value)
        if (px === 1) return `${prefix}-px`
        const n = px / 4
        return Number.isInteger(n * 2) ? `${prefix}-${num(n)}` : `${prefix}-[${num(px)}px]`
      },
    },
  }
}

/** Width / height: "auto" | "full" | "fit" | "screen" | a fraction "1/2" | px "320" | custom "[50%]". */
export function sizeScale(id: string, prefix: 'w' | 'h' | 'min-h'): Scale {
  const words = ['auto', 'full', 'fit', 'screen', 'min', 'max']
  return {
    id,
    tokens: [...words.map((w) => ({ value: w, cls: `${prefix}-${w}`, label: w[0].toUpperCase() + w.slice(1) }))],
    dynamic: {
      parse: (util) => {
        if (!util.startsWith(`${prefix}-`)) return null
        const rest = util.slice(prefix.length + 1)
        if (words.includes(rest)) return rest
        if (/^\d+\/\d+$/.test(rest)) return rest
        if (/^\d+(\.\d+)?$/.test(rest)) return num(Number(rest) * 4)
        const px = /^\[(\d+(?:\.\d+)?)px\]$/.exec(rest)
        if (px) return num(Number(px[1]))
        const other = /^\[(\d+(?:\.\d+)?(?:rem|em|%|vh|vw|dvh|svh))\]$/.exec(rest)
        return other ? `[${other[1]}]` : null
      },
      format: (value) => {
        if (words.includes(value) || /^\d+\/\d+$/.test(value)) return `${prefix}-${value}`
        if (/^\[\d+(?:\.\d+)?(?:rem|em|%|vh|vw|dvh|svh)\]$/.test(value)) return `${prefix}-${value}`
        if (!/^\d+(\.\d+)?$/.test(value)) return null
        const n = Number(value) / 4
        return Number.isInteger(n * 4) && Number.isInteger(n) ? `${prefix}-${num(n)}` : `${prefix}-[${num(Number(value))}px]`
      },
    },
  }
}

/** Opacity 0–100 (any whole percent in Tailwind v4). */
export const OPACITY_SCALE: Scale = {
  id: 'opacity',
  tokens: [0, 10, 25, 50, 75, 90, 100].map((n) => ({ value: String(n), cls: `opacity-${n}`, label: `${n}%` })),
  dynamic: {
    parse: (util) => {
      const m = /^opacity-(\d{1,3})$/.exec(util)
      return m && Number(m[1]) <= 100 ? m[1] : null
    },
    format: (value) => (/^\d{1,3}$/.test(value) && Number(value) <= 100 ? `opacity-${value}` : null),
  },
}

const tok = (value: string, cls: string, label: string): ScaleToken => ({ value, cls, label })

export const LAYOUT_SCALES: Readonly<Record<string, Scale>> = {
  display: { id: 'display', tokens: [tok('block', 'block', 'Block'), tok('flex', 'flex', 'Flex'), tok('grid', 'grid', 'Grid'), tok('inline-block', 'inline-block', 'Inline block'), tok('inline', 'inline', 'Inline'), tok('inline-flex', 'inline-flex', 'Inline flex'), tok('none', 'hidden', 'Hidden')] },
  'border-style': { id: 'border-style', tokens: [tok('none', 'border-none', 'None'), tok('solid', 'border-solid', 'Solid'), tok('dashed', 'border-dashed', 'Dashed'), tok('dotted', 'border-dotted', 'Dotted'), tok('double', 'border-double', 'Double')] },
  'border-width': {
    id: 'border-width',
    tokens: [tok('0', 'border-0', '0px'), tok('1', 'border', '1px'), tok('2', 'border-2', '2px'), tok('4', 'border-4', '4px'), tok('8', 'border-8', '8px')],
    arbitrary: { prefix: 'border-', pattern: /^border-\[(\d+px)\]$/ },
  },
  radius: {
    id: 'radius',
    tokens: [tok('0', 'rounded-none', 'None'), tok('2', 'rounded-xs', '2px'), tok('4', 'rounded-sm', '4px'), tok('6', 'rounded-md', '6px'), tok('8', 'rounded-lg', '8px'), tok('12', 'rounded-xl', '12px'), tok('16', 'rounded-2xl', '16px'), tok('24', 'rounded-3xl', '24px'), tok('32', 'rounded-4xl', '32px'), tok('full', 'rounded-full', 'Full')],
    arbitrary: { prefix: 'rounded-', pattern: /^rounded-\[(\d+px)\]$/ },
  },
  shadow: {
    id: 'shadow',
    tokens: [tok('none', 'shadow-none', 'None'), tok('2xs', 'shadow-2xs', '2XS'), tok('xs', 'shadow-xs', 'XS'), tok('sm', 'shadow-sm', 'S'), tok('md', 'shadow-md', 'M'), tok('lg', 'shadow-lg', 'L'), tok('xl', 'shadow-xl', 'XL'), tok('2xl', 'shadow-2xl', '2XL'), tok('inner', 'inset-shadow-sm', 'Inner')],
  },
}

/** One corner's radius (rounded-tl-lg…): same steps as the whole radius. */
export function cornerScale(corner: 'tl' | 'tr' | 'br' | 'bl'): Scale {
  const all = LAYOUT_SCALES.radius
  return {
    id: `radius-${corner}`,
    tokens: all.tokens.map((x) => ({ ...x, cls: x.cls.replace('rounded-', `rounded-${corner}-`) })),
    arbitrary: { prefix: `rounded-${corner}-`, pattern: new RegExp(`^rounded-${corner}-\\[(\\d+px)\\]$`) },
  }
}
