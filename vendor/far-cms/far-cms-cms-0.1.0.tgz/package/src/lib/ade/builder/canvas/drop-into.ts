/**
 * Where a block dragged from the Blocks / Templates tabs lands on the canvas (owner 2026-10-20: "I can't
 * drag a block onto the page"). From the block under the pointer and where in it the pointer is:
 * before it, after it, or inside it (a container, middle half), along the axis its parent lays out
 * (a row → left / right, a stack → above / below). Pure; asserted by drop-into.assert.ts.
 */

import type { Block } from '../../../block-editor/types'

export type DropPlace = 'before' | 'after' | 'inside'

export interface DropRect { left: number; top: number; width: number; height: number }

/** Before / after / inside from the pointer's spot in the target's box. */
export function dropPlace(rect: DropRect, x: number, y: number, opts: { horizontal: boolean; container: boolean }): DropPlace {
  const along = opts.horizontal ? (x - rect.left) / Math.max(1, rect.width) : (y - rect.top) / Math.max(1, rect.height)
  if (opts.container && along > 0.25 && along < 0.75) return 'inside'
  return along < 0.5 ? 'before' : 'after'
}

/** The parent and index for a drop on `targetId` (null target = the end of the page). */
export function dropSpot(blocks: readonly Block[], targetId: string | null, place: DropPlace): { parentId: string | null; index: number } {
  if (!targetId) return { parentId: null, index: blocks.length }
  const find = (list: readonly Block[], parentId: string | null): { parentId: string | null; index: number } | null => {
    for (let i = 0; i < list.length; i++) {
      const b = list[i]
      if (b.id === targetId) {
        if (place === 'inside') return { parentId: b.id, index: b.children?.length ?? 0 }
        return { parentId, index: place === 'before' ? i : i + 1 }
      }
      if (b.children?.length) {
        const hit = find(b.children, b.id)
        if (hit) return hit
      }
    }
    return null
  }
  return find(blocks, null) ?? { parentId: null, index: blocks.length }
}

/** Can this block take a drop inside it: a real container, not a live-data block, not locked. */
export function acceptsDropInside(b: Pick<Block, 'children' | 'componentName' | 'partialId' | 'locked'> | null | undefined): boolean {
  return !!b && Array.isArray(b.children) && !b.componentName && !b.partialId && !b.locked
}

/** The drag types this canvas drop takes (the Blocks and Templates tabs). */
export const BLOCK_DRAG_TYPES = ['application/template-id', 'application/custom-template-id'] as const
export const isBlockDrag = (types: readonly string[]) => BLOCK_DRAG_TYPES.some((t) => types.includes(t))
