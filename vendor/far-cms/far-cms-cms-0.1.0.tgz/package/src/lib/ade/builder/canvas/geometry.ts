/**
 * Canvas geometry for the page builder: the hatched padding / margin bands
 * around a selection, and where the floating inline toolbar goes. Pure — the
 * canvas feeds it getBoundingClientRect + getComputedStyle numbers, so drawing
 * the bands never touches the block's own layout (no jumps).
 *
 * Run: npx -y tsx@4.23.15 src/lib/ade/builder/canvas/canvas.assert.ts
 */

export interface Box {
  left: number
  top: number
  width: number
  height: number
}

export interface Sides {
  top: number
  right: number
  bottom: number
  left: number
}

export type Side = keyof Sides

export interface Band extends Box {
  kind: 'padding' | 'margin'
  side: Side
  /** The value shown on the band (px). */
  px: number
}

const SIDES: readonly Side[] = ['top', 'right', 'bottom', 'left']

/** A CSS length from getComputedStyle ("16px", "0px", "auto") → px; anything else → 0. */
export function px(v: string | null | undefined): number {
  const n = typeof v === 'string' ? Number.parseFloat(v) : Number.NaN
  return Number.isFinite(n) ? n : 0
}

/** Computed padding / margin / border → numbers. */
export function sidesFrom(get: (prop: string) => string, prefix: 'padding' | 'margin' | 'border'): Sides {
  const suffix = prefix === 'border' ? '-width' : ''
  return {
    top: px(get(`${prefix}-top${suffix}`)),
    right: px(get(`${prefix}-right${suffix}`)),
    bottom: px(get(`${prefix}-bottom${suffix}`)),
    left: px(get(`${prefix}-left${suffix}`)),
  }
}

/**
 * The bands for one element. `rect` is its border box. Padding sits inside
 * the border; margin outside it. Negative margins are drawn as 0 (nothing to
 * hatch). Zero-size bands are left out.
 */
export function spacingBands(rect: Box, padding: Sides, margin: Sides, border: Sides = { top: 0, right: 0, bottom: 0, left: 0 }): Band[] {
  const out: Band[] = []
  // Padding: inside the border edge.
  const inner = { left: rect.left + border.left, top: rect.top + border.top, width: Math.max(0, rect.width - border.left - border.right), height: Math.max(0, rect.height - border.top - border.bottom) }
  const p = clampSides(padding)
  const pad: Record<Side, Box> = {
    top: { left: inner.left, top: inner.top, width: inner.width, height: Math.min(p.top, inner.height) },
    bottom: { left: inner.left, top: inner.top + inner.height - Math.min(p.bottom, inner.height), width: inner.width, height: Math.min(p.bottom, inner.height) },
    left: { left: inner.left, top: inner.top + p.top, width: Math.min(p.left, inner.width), height: Math.max(0, inner.height - p.top - p.bottom) },
    right: { left: inner.left + inner.width - Math.min(p.right, inner.width), top: inner.top + p.top, width: Math.min(p.right, inner.width), height: Math.max(0, inner.height - p.top - p.bottom) },
  }
  const m = clampSides(margin)
  const mar: Record<Side, Box> = {
    top: { left: rect.left - m.left, top: rect.top - m.top, width: rect.width + m.left + m.right, height: m.top },
    bottom: { left: rect.left - m.left, top: rect.top + rect.height, width: rect.width + m.left + m.right, height: m.bottom },
    left: { left: rect.left - m.left, top: rect.top, width: m.left, height: rect.height },
    right: { left: rect.left + rect.width, top: rect.top, width: m.right, height: rect.height },
  }
  for (const side of SIDES) {
    if (p[side] > 0 && pad[side].width > 0 && pad[side].height > 0) out.push({ kind: 'padding', side, px: padding[side], ...round(pad[side]) })
  }
  for (const side of SIDES) {
    if (m[side] > 0) out.push({ kind: 'margin', side, px: margin[side], ...round(mar[side]) })
  }
  return out
}

const clampSides = (s: Sides): Sides => ({ top: Math.max(0, s.top), right: Math.max(0, s.right), bottom: Math.max(0, s.bottom), left: Math.max(0, s.left) })
const round = (b: Box): Box => ({ left: Math.round(b.left * 2) / 2, top: Math.round(b.top * 2) / 2, width: Math.round(b.width * 2) / 2, height: Math.round(b.height * 2) / 2 })

export interface ToolbarPlace {
  left: number
  top: number
  side: 'above' | 'below' | 'inside'
}

/** Space between the selection (and its margin band) and the toolbar. */
export const TOOLBAR_GAP = 8

/**
 * Where the floating toolbar goes: centred over the selection, ABOVE it when
 * there is room inside the canvas area, else BELOW it (a header at the very
 * top — v0 shot 03), never covering it. Only when the selection fills the
 * whole area height does it sit inside, pinned to the area's top edge.
 * Horizontally it stays inside the area. `avoid` (e.g. the margin band) is
 * kept clear as well as the selection.
 */
export function placeToolbar(sel: Box, bar: { width: number; height: number }, area: Box, avoid?: Box): ToolbarPlace {
  const keep = avoid ? union(sel, avoid) : sel
  const roomAbove = keep.top - area.top
  const roomBelow = area.top + area.height - (keep.top + keep.height)
  const need = bar.height + TOOLBAR_GAP
  let side: ToolbarPlace['side']
  let top: number
  if (roomAbove >= need) {
    side = 'above'
    top = keep.top - TOOLBAR_GAP - bar.height
  } else if (roomBelow >= need) {
    side = 'below'
    top = keep.top + keep.height + TOOLBAR_GAP
  } else {
    side = 'inside'
    top = Math.max(area.top, keep.top) + TOOLBAR_GAP
  }
  const centre = sel.left + sel.width / 2 - bar.width / 2
  const left = Math.min(Math.max(centre, area.left + TOOLBAR_GAP), area.left + area.width - bar.width - TOOLBAR_GAP)
  return { left: Math.round(Math.max(area.left, left)), top: Math.round(top), side }
}

function union(a: Box, b: Box): Box {
  const left = Math.min(a.left, b.left)
  const top = Math.min(a.top, b.top)
  return { left, top, width: Math.max(a.left + a.width, b.left + b.width) - left, height: Math.max(a.top + a.height, b.top + b.height) - top }
}

/** Do two boxes overlap (positive area)? */
export const overlaps = (a: Box, b: Box): boolean => a.left < b.left + b.width && b.left < a.left + a.width && a.top < b.top + b.height && b.top < a.top + a.height

/** The block under the margin bands (border box grown by its margins) — what the toolbar keeps clear of. */
export const marginBox = (rect: Box, margin: Sides): Box => {
  const m = clampSides(margin)
  return { left: rect.left - m.left, top: rect.top - m.top, width: rect.width + m.left + m.right, height: rect.height + m.top + m.bottom }
}

/** The name chip's height (px). */
export const TAG_HEIGHT = 18

/**
 * Where a block's name chip goes: on the block's top-left edge, sitting just
 * above it; inside the top-left corner when there is no room above (a block at
 * the top of the canvas). Kept inside the area horizontally.
 */
export function tagPlace(box: Box, area: Box, width: number): { left: number; top: number; inside: boolean } {
  const inside = box.top - TAG_HEIGHT < area.top
  const left = Math.min(Math.max(box.left, area.left), area.left + area.width - width)
  return { left: Math.round(Math.max(area.left, left)), top: Math.round(inside ? box.top : box.top - TAG_HEIGHT), inside }
}

/** The cursor each handle shows. */
export const HANDLE_CURSOR: Record<string, string> = { n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize', ne: 'nesw-resize', sw: 'nesw-resize', nw: 'nwse-resize', se: 'nwse-resize' }

/** The 8 handles on a selection outline: corners and edge midpoints. Dragging one resizes (direct-resize). */
export function handlePoints(box: Box): Array<{ x: number; y: number; at: string }> {
  const xs = [box.left, box.left + box.width / 2, box.left + box.width]
  const ys = [box.top, box.top + box.height / 2, box.top + box.height]
  const names = [['nw', 'n', 'ne'], ['w', '', 'e'], ['sw', 's', 'se']]
  const out: Array<{ x: number; y: number; at: string }> = []
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) if (names[r][c]) out.push({ x: Math.round(xs[c]), y: Math.round(ys[r]), at: names[r][c] })
  return out
}
