/**
 * Where "Move up" / "Move down" put a block, in the terms of the editor's moveBlock(id, parentId,
 * index), which removes the block first and then inserts it at index among what is left. Check:
 * arrange.assert.ts (runs the real moveBlockInTree). Used by the inline toolbar and the right-click
 * menu, so both move exactly one place (the menu's Move Down used to skip one).
 */
import type { Block } from '../../../block-editor/types'

function locate(blocks: Block[], id: string, parentId: string | null = null): { parentId: string | null; index: number; count: number } | null {
  const i = blocks.findIndex((b) => b.id === id)
  if (i >= 0) return { parentId, index: i, count: blocks.length }
  for (const b of blocks) {
    const found = b.children?.length ? locate(b.children, id, b.id) : null
    if (found) return found
  }
  return null
}

export function nudgeTarget(blocks: Block[], id: string, dir: 'up' | 'down'): { parentId: string | null; index: number } | null {
  const at = locate(blocks, id)
  if (!at) return null
  if (dir === 'up') return at.index > 0 ? { parentId: at.parentId, index: at.index - 1 } : null
  // After removal the next sibling sits at `index`, so inserting at index + 1 puts the block after it.
  return at.index < at.count - 1 ? { parentId: at.parentId, index: at.index + 1 } : null
}
