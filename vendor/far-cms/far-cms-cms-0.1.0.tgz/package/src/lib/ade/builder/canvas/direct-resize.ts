/**
 * Direct resize on the builder canvas (owner 2026-10-19): you handle a block as if it were absolutely
 * positioned — the edge you drag goes exactly where the pointer goes, the opposite edge stays put — and
 * the result is translated into normal flow layout: width, height / min-height and margins.
 *
 * How an edge drag translates depends on how the block sits in its parent:
 *   start-aligned (the usual): right edge → width; left edge → width + margin-left, so the right edge stays.
 *   centred (mx-auto, justify-center, text-center…): either side edge → width, mirrored, so it stays centred.
 *   end-aligned: the mirror of start — left edge → width; right edge → width + margin-right.
 *   bottom edge → height; top edge → height + margin-top, so the bottom stays.
 * Snaps (unless free): full width, half width, the 4px grid; with guide lines for the overlay to draw.
 *
 * Pure: all sizes are canvas pixels (the caller divides screen deltas by any preview scale).
 * Run: npx -y tsx@4.23.15 src/lib/ade/builder/canvas/canvas.assert.ts
 */

export type Align = 'start' | 'center' | 'end'

export interface ResizeStart {
  /** The block's border box size. */
  width: number
  height: number
  /** Its margins (px). */
  margin: { top: number; right: number; bottom: number; left: number }
  /** The parent's content box width (the room it has). */
  room: number
  /** How it sits horizontally in its parent. */
  align: Align
}

export interface ResizeOpts {
  keepRatio?: boolean
  /** Alt: no snapping. */
  free?: boolean
  min?: number
}

export interface ResizeResult {
  width: number | null
  height: number | null
  marginLeft: number | null
  marginRight: number | null
  marginTop: number | null
  /** A named width it snapped to: 'full' | '1/2' (written as those tokens, not pixels). */
  widthToken: 'full' | '1/2' | null
  /** Where to draw snap guides, relative to the parent content box's left (x) — for the overlay. */
  guides: Array<{ axis: 'x'; at: number; label: string }>
}

export const SNAP_PX = 6
export const GRID_PX = 4
export const MIN_SIZE_PX = 16

const round = (v: number) => Math.round(v)
const grid = (v: number) => Math.round(v / GRID_PX) * GRID_PX

/** How the overlay should read alignment from computed styles (passed in as plain strings). */
export function alignFrom(s: {
  display: string
  marginLeft: number
  marginRight: number
  parentDisplay: string
  parentDirection?: string
  parentJustify?: string
  parentAlignItems?: string
  alignSelf?: string
  parentTextAlign?: string
}): Align {
  const pick = (v: string | undefined): Align | null =>
    !v ? null : /center/.test(v) ? 'center' : /(^|-)end$|right/.test(v) ? 'end' : /start|left|normal|stretch|flex-start|baseline/.test(v) ? 'start' : null
  if (/flex/.test(s.parentDisplay)) {
    const column = /column/.test(s.parentDirection ?? '')
    const v = column ? (s.alignSelf && s.alignSelf !== 'auto' ? s.alignSelf : s.parentAlignItems) : s.parentJustify
    return pick(v) ?? 'start'
  }
  if (/grid/.test(s.parentDisplay)) return pick(s.alignSelf && s.alignSelf !== 'auto' ? s.alignSelf : s.parentAlignItems) ?? 'start'
  if (/^inline/.test(s.display)) return pick(s.parentTextAlign) ?? 'start'
  if (s.marginLeft > 0.5 && Math.abs(s.marginLeft - s.marginRight) <= 1) return 'center'
  if (s.marginLeft > 0.5 && s.marginRight <= 0.5) return 'end'
  return 'start'
}

/** One pointer position during a drag from handle `at` (n, s, e, w, ne, nw, se, sw) by (dx, dy). */
export function directResize(start: ResizeStart, at: string, dx: number, dy: number, opts: ResizeOpts = {}): ResizeResult {
  const min = opts.min ?? MIN_SIZE_PX
  const east = at.includes('e')
  const west = at.includes('w')
  const south = at.includes('s')
  const north = at.includes('n')
  const out: ResizeResult = { width: null, height: null, marginLeft: null, marginRight: null, marginTop: null, widthToken: null, guides: [] }

  // ── width ──
  if (east || west) {
    const m = start.margin
    // How far the dragged edge moved outward (positive = grows).
    const out1 = east ? dx : -dx
    let w = start.align === 'center' ? start.width + 2 * out1 : start.width + out1
    // The room it can use: centred → the whole content box; otherwise everything but the far margin.
    const far = start.align === 'center' ? 0 : start.align === 'start' ? (west ? 0 : m.left) : east ? 0 : m.right
    const maxW = Math.max(min, start.room - far)
    w = Math.min(Math.max(w, min), maxW)
    // Snaps.
    if (!opts.free) {
      if (Math.abs(w - maxW) <= SNAP_PX) {
        // Fill: the whole room when nothing is in the way ('full'), else everything up to the far margin.
        w = maxW
        if (far === 0) out.widthToken = 'full'
        out.guides.push({ axis: 'x', at: far && start.align === 'start' ? far : 0, label: far ? 'Fill' : 'Full width' }, { axis: 'x', at: start.room - (far && start.align === 'end' ? far : 0), label: '' })
      } else if (Math.abs(w - start.room / 2) <= SNAP_PX) {
        w = start.room / 2
        out.widthToken = '1/2'
        out.guides.push({ axis: 'x', at: start.room / 2, label: 'Half' })
      } else w = grid(w)
    }
    out.width = round(w)
    const grew = out.width - start.width
    // Keep the opposite edge still by moving the margin on the dragged side.
    if (start.align === 'start' && west) out.marginLeft = round(Math.max(0, m.left - grew))
    if (start.align === 'end' && east) out.marginRight = round(Math.max(0, m.right - grew))
    if (out.widthToken === 'full') {
      if (out.marginLeft !== null) out.marginLeft = 0
      if (out.marginRight !== null) out.marginRight = 0
    }
  }

  // ── height ──
  if (north || south) {
    let h = start.height + (south ? dy : -dy)
    h = Math.max(h, min)
    if (!opts.free) h = grid(h)
    out.height = round(h)
    if (north) out.marginTop = round(Math.max(0, start.margin.top - (out.height - start.height)))
  }

  // ── Shift on a corner: keep the shape ──
  if (opts.keepRatio && out.width !== null && out.height !== null && start.width > 0 && start.height > 0) {
    const k = Math.max(out.width / start.width, out.height / start.height)
    out.width = round(start.width * k)
    out.height = round(start.height * k)
    out.widthToken = null
  }
  return out
}

/** The badge while dragging: "W 448 · H 320 · 56%" (or "Full width" / "Half"). */
export function resizeLabel(r: ResizeResult, room: number): string {
  const parts: string[] = []
  if (r.width !== null) parts.push(r.widthToken === 'full' ? 'Full width' : r.widthToken === '1/2' ? 'Half width' : `W ${r.width}`)
  if (r.height !== null) parts.push(`H ${r.height}`)
  if (r.width !== null && !r.widthToken && room > 0) parts.push(`${Math.round((r.width / room) * 100)}%`)
  return parts.join(' · ')
}

/** The design-field writes for a finished drag (one undo step: the caller folds them into one className). */
export function resizeWrites(r: ResizeResult, opts: { container: boolean; inline: boolean }): Array<[key: string, value: string]> {
  const w: Array<[string, string]> = []
  if (r.width !== null) w.push(['width', r.widthToken ?? String(r.width)])
  if (r.height !== null) w.push([opts.container ? 'minHeight' : 'height', String(r.height)])
  if (r.marginLeft !== null) w.push(['marginLeft', String(r.marginLeft)])
  if (r.marginRight !== null) w.push(['marginRight', String(r.marginRight)])
  if (r.marginTop !== null) w.push(['marginTop', String(r.marginTop)])
  // An inline element ignores width/height: make it inline-block so the size sticks.
  if (opts.inline && (r.width !== null || r.height !== null)) w.push(['display', 'inline-block'])
  return w
}
