/**
 * Presses code makes on the person's behalf (opening a menu so a spot can
 * show it: components/ade/shell-spots press) are marked, so the spotlight's
 * press host never takes them for the person pressing outside the spotlight.
 * Only these are skipped: any other synthetic click (tests, other tools)
 * is handled as before.
 *
 * Pure (no DOM types needed). Asserted by code-press.assert.ts.
 */

const marked = new WeakSet<object>()

/** Mark an event code is about to dispatch for a reveal. Returns the event. */
export function markCodePress<E extends object>(e: E): E {
  marked.add(e)
  return e
}

/** Was this event dispatched by code opening something for a spot? */
export const isCodePress = (e: object | null | undefined): boolean => !!e && marked.has(e)
