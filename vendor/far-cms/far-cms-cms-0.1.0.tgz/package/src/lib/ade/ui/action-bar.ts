/**
 * Action bar priority + overflow (owner, smaller screens). Always visible:
 * the menu, the breadcrumb (truncated), the screen's own tools (Undo/Redo/
 * Revisions — icons only when tight; their dialogs can't live in a menu)
 * and the primary action. The shell's controls tuck into "More" in priority
 * order: Full view → Live/Your draft → devices. Driven by the bar's measured
 * width so nothing clips or overlaps. Light/dark lives in the avatar menu and
 * the color scheme in Settings › Appearance (owner 2026-10-17), so neither is
 * in the bar. Pure; asserted.
 */

export interface BarPlan {
  /** Text labels on tool buttons (else icons only). */
  labels: boolean
  devices: boolean
  deviceLabels: boolean
  compare: boolean
  fullView: boolean
  /** Something is tucked away → show "More". */
  more: boolean
}

/** What tucks into "More" first when the bar still overflows (least important first). */
export const SQUEEZE_ORDER = ['fullView', 'compare', 'devices'] as const
export const MAX_SQUEEZE = SQUEEZE_ORDER.length

/**
 * `squeeze` tucks away that many more controls, in SQUEEZE_ORDER, on top of
 * the width rules — for screens whose own tools (the slots: a builder's tabs,
 * device switch, Submit) take more room than the width rules assume. The bar
 * raises it while its content overflows (see nextSqueeze).
 */
export function barPlan(width: number, squeeze = 0, shows?: BarShows): BarPlan {
  const w = Math.max(0, width)
  const plan: BarPlan = {
    labels: w >= 1180,
    devices: w >= 560,
    deviceLabels: w >= 1400,
    compare: w >= 640,
    fullView: w >= 900,
    more: false,
  }
  // Each squeeze step tucks the next control the screen actually HAS: a step spent on an absent
  // control (the forms builder has no Full view) changed nothing on screen.
  const order = shows ? SQUEEZE_ORDER.filter((k) => shows[k]) : SQUEEZE_ORDER
  for (const k of order.slice(0, Math.max(0, Math.min(order.length, Math.floor(squeeze))))) plan[k] = false
  if (!plan.devices) plan.deviceLabels = false
  plan.more = !(plan.devices && plan.compare && plan.fullView)
  return plan
}

/**
 * The measured step: the bar's content (its slots included) is wider than the
 * bar → tuck one more control away; it fits → keep the current squeeze. A new
 * bar width starts again from 0 (the bar resets it), so widening gives the
 * controls back.
 */
export function nextSqueeze(squeeze: number, contentWidth: number | BarMeasure, barWidth?: number): number {
  const m: BarMeasure = typeof contentWidth === 'number' ? { contentWidth, barWidth: barWidth ?? contentWidth } : contentWidth
  return barCrowded(m) && squeeze < MAX_SQUEEZE ? squeeze + 1 : squeeze
}

/** The breadcrumb's floor before the shell's controls give way to it (the open item's name stays readable). */
export const CRUMB_ROOM = 160

/** What the bar measures after paint. */
export interface BarMeasure {
  /** The bar's content width (scrollWidth) and its own width (clientWidth). */
  contentWidth: number
  barWidth: number
  /** The breadcrumb's natural width (scrollWidth) and what it was given (clientWidth). */
  crumbNeeded?: number
  crumbShown?: number
}

/**
 * Too crowded → tuck one more control: the content overflows the bar, OR the
 * breadcrumb (which shrinks first and so hides the squeeze from the overflow
 * check — batched pass, forms builder at 1068: nothing tucked, no More) is
 * cut below CRUMB_ROOM while it needs more.
 */
export function barCrowded(m: BarMeasure): boolean {
  if (m.contentWidth > m.barWidth + 1) return true
  const needed = m.crumbNeeded ?? 0
  const shown = m.crumbShown ?? needed
  return needed > shown + 1 && shown < CRUMB_ROOM
}

/** Which of the shell's controls this screen has at all. */
export interface BarShows {
  devices: boolean
  compare: boolean
  fullView: boolean
}

export type MoreItem = 'devices' | 'compare' | 'fullView'

/**
 * What "More" must hold: every control the screen has that the plan tucked
 * away — so nothing tucked is ever unreachable. More renders whenever this is
 * non-empty (and the bar also keeps it whenever squeeze > 0).
 */
export function tuckedItems(plan: BarPlan, shows: BarShows): MoreItem[] {
  const out: MoreItem[] = []
  if (shows.devices && !plan.devices) out.push('devices')
  if (shows.compare && !plan.compare) out.push('compare')
  if (shows.fullView && !plan.fullView) out.push('fullView')
  return out
}
