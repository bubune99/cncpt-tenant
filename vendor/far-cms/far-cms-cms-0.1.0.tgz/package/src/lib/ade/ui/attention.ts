/**
 * The attention controller (owner 2026-10-18): one owner for both ways the
 * assistant draws the eye, so they never clash.
 *
 *   SPOTLIGHT — teaching: dims the rest, ONE target, a card with Got it.
 *               Tutorials, walk-throughs, tours, a commit control the person
 *               asked to be shown.
 *   HIGHLIGHT — work and review: a ring (and a one-line tag), no scrim, no
 *               card, many at once. Kofi typing (working ring), "where is X"
 *               with one visible answer, things to check.
 *
 * One state per screen: idle | highlight | spotlight (read from
 * `data-attention` on the root). A fill/edit run never spotlights (except a
 * commit-control pointer the person asked for); a fill starting under a
 * spotlight closes it first; a new run closes any spotlight; a run's end
 * closes it unless the run is teaching. Host-agnostic. Pure; asserted by
 * attention.assert.ts.
 */

export type AttentionMode = 'idle' | 'highlight' | 'spotlight'
/** Why the eye is drawn: teach → spotlight; the rest → highlight. */
export type AttentionIntent = 'teach' | 'locate' | 'work' | 'review'
export type Channel = 'spotlight' | 'highlight'
/** What the current run is doing, learnt from its first attention call (or the person's words). */
export type RunKind = 'none' | 'work' | 'teach' | 'locate'
/** 'flash': a brief UI cue the app raises itself (the Style tab after a canvas click) — no run, never reported. */
export type RingKind = 'working' | 'locate' | 'review' | 'flash'

export interface Ring {
  target: string
  kind: RingKind
  /** One-line tag beside the ring (locate / review); none for the working ring. */
  tag?: string
  /** The request that asked for it (a spot set's id): one report per ring per request. */
  from?: string
}

export interface AttentionState {
  run: RunKind
  /** What the person's words asked for this run (intentFromAsk). */
  ask: AttentionIntent | null
  /** `waitId`: a blocking step waiting for the person's acknowledgment (brief 1c/1e) — kept until ack or a new run. */
  spotlight: { id: string; teach: boolean; waitId?: string } | null
  rings: ReadonlyArray<Ring>
}

export const IDLE: AttentionState = { run: 'none', ask: null, spotlight: null, rings: [] }

export const ATTENTION = {
  /** A working ring stays at least this long before the next field starts (brief 1c.5). */
  minDwellMs: 600,
  /** Longest tag beside a ring. */
  tagMax: 60,
  /** Longest one-line reason under a spotlight caption. */
  reasonMax: 90,
} as const

/** The one state the root shows. */
export function attentionMode(s: AttentionState): AttentionMode {
  if (s.spotlight) return 'spotlight'
  return s.rings.length > 0 ? 'highlight' : 'idle'
}

const TEACH = /\b(walk me through|walk through|show me how|how do i|how can i|teach me|tour|step by step|guide me|onboard)/i
const LOCATE = /\b(where(?:'s| is| are| do i find| can i find)|find the|point (?:at|to)|show me (?:the|where))/i

/** What the person's words ask for: teaching beats locating ("show me how" is a lesson). */
export function intentFromAsk(text: string | null | undefined): AttentionIntent | null {
  const t = (text ?? '').trim()
  if (!t) return null
  if (TEACH.test(t)) return 'teach'
  if (LOCATE.test(t)) return 'locate'
  return null
}

const COMMIT = /(^|[._-])(propose|publish|unpublish|approve|draft_approve|reject|draft_reject|delete|send|send_confirm|submit|submit_review)(?=$|[._-])/i

/** The data-ui name inside a selector like [data-ui="record.propose"] (or a bare name). */
export function uiName(target: string): string | null {
  const m = /data-ui\s*=\s*["']?([^"'\]]+)/.exec(target)
  if (m) return m[1]
  return /^[a-z][\w.-]*$/i.test(target) ? target : null
}

/** A control only the person presses (Propose, Publish, Approve, Delete, Send, Submit). */
export function isCommitTarget(target: string): boolean {
  const name = uiName(target)
  return !!name && COMMIT.test(name)
}

/**
 * Spotlight or highlight (brief 1b, first match wins):
 * teaching → spotlight; inside a fill/edit run → highlight (a commit pointer
 * only if the person asked to be shown); a commit control → highlight unless
 * asked; one target to find → highlight; several steps → a walk → spotlight.
 */
export function chooseChannel(c: { intent: AttentionIntent | null; run: RunKind; steps: number; commit: boolean; askedToBeShown?: boolean }): Channel {
  if (c.run === 'work') return c.commit && c.askedToBeShown ? 'spotlight' : 'highlight'
  if (c.intent === 'teach' || c.run === 'teach') return 'spotlight'
  if (c.intent === 'work' || c.intent === 'review') return 'highlight'
  if (c.commit) return c.askedToBeShown ? 'spotlight' : 'highlight'
  return c.steps > 1 ? 'spotlight' : 'highlight'
}

export type AttentionEvent =
  | { type: 'run.start'; ask?: string | null }
  | { type: 'run.end' }
  | { type: 'work.start'; target: string }
  | { type: 'work.done'; target: string }
  | { type: 'spotlight.request'; id: string; steps: ReadonlyArray<{ target: string; title?: string; label?: string }>; intent?: AttentionIntent | null; commit?: boolean; waitId?: string }
  | { type: 'spotlight.closed' }
  | { type: 'flash'; targets: ReadonlyArray<string> }
  | { type: 'rings.clear'; kind?: RingKind }

/** What the store must do after a step: close the spotlight it shows, or open one. */
export interface AttentionResult {
  state: AttentionState
  channel?: Channel
  closeSpotlight?: boolean
}

const withoutRing = (rings: ReadonlyArray<Ring>, target: string, kind?: RingKind) => rings.filter((r) => !(r.target === target && (!kind || r.kind === kind)))

/** One clipped line. */
export function oneLine(s: string | null | undefined, max: number): string {
  const t = (s ?? '').replace(/\s+/g, ' ').trim()
  return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t
}

export function reduceAttention(s: AttentionState, e: AttentionEvent): AttentionResult {
  switch (e.type) {
    case 'run.start': {
      // A new run: no spotlight survives it; finding/review rings go too (work marks are the page's, not here).
      const ask = intentFromAsk(e.ask)
      return { state: { run: ask === 'teach' ? 'teach' : 'none', ask, spotlight: null, rings: [] }, closeSpotlight: !!s.spotlight }
    }
    case 'run.end': {
      // Teaching waits for the person's Got it; anything else leaves no spotlight behind (C28).
      const keep = s.spotlight?.teach || s.spotlight?.waitId ? s.spotlight : null
      return { state: { ...s, run: 'none', spotlight: keep, rings: s.rings.filter((r) => r.kind !== 'working') }, closeSpotlight: !!s.spotlight && !keep }
    }
    case 'work.start': {
      // Never dim a field Kofi is typing into: close the spotlight first (C33).
      const rings = [...withoutRing(s.rings, e.target), { target: e.target, kind: 'working' as const }]
      return { state: { ...s, run: 'work', spotlight: null, rings }, closeSpotlight: !!s.spotlight }
    }
    case 'work.done':
      return { state: { ...s, rings: withoutRing(s.rings, e.target, 'working') } }
    case 'spotlight.request': {
      const commit = e.commit ?? e.steps.some((st) => isCommitTarget(st.target))
      const intent = e.intent ?? s.ask
      const channel = chooseChannel({ intent, run: s.run, steps: e.steps.length, commit, askedToBeShown: s.ask === 'teach' })
      if (channel === 'spotlight') {
        // A spotlight replaces finding rings (one place to look); working rings stay, muted under the scrim.
        return { state: { ...s, run: s.run === 'none' ? (intent === 'teach' ? 'teach' : 'locate') : s.run, spotlight: { id: e.id, teach: intent === 'teach' || s.run === 'teach' || e.steps.length > 1, ...(e.waitId ? { waitId: e.waitId } : {}) }, rings: s.rings.filter((r) => r.kind === 'working') }, channel }
      }
      const kind: RingKind = s.run === 'work' || intent === 'review' || commit ? 'review' : 'locate'
      // A field Kofi is typing into already has its working ring (its KOFI mark follows): no second ring on it.
      const busy = new Set(s.rings.filter((r) => r.kind === 'working').map((r) => r.target))
      const added = e.steps.filter((st) => !busy.has(st.target)).map((st) => ({ target: st.target, kind, tag: oneLine(st.title ?? st.label, ATTENTION.tagMax) || undefined, from: e.id }))
      const rings = [...s.rings.filter((r) => !added.some((a) => a.target === r.target)), ...added]
      return { state: { ...s, run: s.run === 'none' ? 'locate' : s.run, rings }, channel, closeSpotlight: !!s.spotlight }
    }
    case 'spotlight.closed':
      return { state: { ...s, spotlight: null } }
    case 'flash': {
      // Never over a spotlight (a lesson stays as it is); never touches the run or the other rings.
      if (s.spotlight) return { state: s }
      const added = e.targets.map((target) => ({ target, kind: 'flash' as const }))
      return { state: { ...s, rings: [...s.rings.filter((r) => !e.targets.includes(r.target)), ...added] } }
    }
    case 'rings.clear':
      return { state: { ...s, rings: e.kind ? s.rings.filter((r) => r.kind !== e.kind) : [] } }
  }
}

/**
 * A spotlight's caption comes from its OWN target (the app's caption for that
 * unit); the model's sentence is only a one-line reason, used when the unit
 * has no caption. A caption never travels to another target.
 */
export function spotCaption(target: string, captions: Readonly<Record<string, string>>, modelSentence?: string | null): string | undefined {
  const name = uiName(target)
  const own = name ? captions[name] : undefined
  if (own) return own
  const reason = oneLine(modelSentence, ATTENTION.reasonMax)
  return reason || undefined
}

/**
 * Has the reply really finished (C28 closes a non-teaching spotlight then)? Not while a browser-run
 * spotlight_steps call is still waiting for the screen: the stream stops AT that call, before the page has
 * answered, and the run goes on once it has — ending the run there closed the very spot it was waiting on.
 */
export function replyFinished(c: { wasStreaming: boolean; streaming: boolean; active: boolean; spotPending: boolean }): boolean {
  return c.wasStreaming && !c.streaming && c.active && !c.spotPending
}

/** How long a highlight's target may take to appear (a revealed drawer, a screen still loading). */
export const RING_FIND_MS = 4000

/**
 * What the model's next turn hears about a highlight — the same [UI check]
 * line a spotlight writes, so it never claims a highlight that isn't on
 * screen (C12). Finding / review rings only (a working ring is the fill's,
 * which reports its own read-back); one entry per ring per request (`key`).
 */
export function ringReport(ring: Ring, found: boolean): { key: string; capability: 'spotlight'; ok: boolean; message: string } | null {
  if (ring.kind === 'working' || ring.kind === 'flash') return null
  const name = ring.tag || 'it'
  return {
    key: `${ring.from ?? 'ring'}|${ring.target}`,
    capability: 'spotlight',
    ok: found,
    message: found ? `Showed “${name}” on the screen.` : `Couldn’t find “${name}” on the screen; nothing was highlighted.`,
  }
}
