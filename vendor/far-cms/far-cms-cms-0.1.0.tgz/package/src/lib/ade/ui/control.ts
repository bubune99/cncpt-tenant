// Moved to @far-cms/core (far-cms packages/core/src/lib/ade/ui/control.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/ade/ui/control'
