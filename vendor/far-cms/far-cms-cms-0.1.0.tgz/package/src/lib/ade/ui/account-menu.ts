/**
 * The top bar's avatar menu (owner 2026-10-17): who you are, Profile,
 * Settings, light / dark, Sign out. The color scheme lives in Settings ›
 * Appearance only — never in the bar or this menu. Host-agnostic (the
 * profile link comes from the app's config). Pure; asserted by account-menu.assert.ts.
 */

export type AccountItemId = 'profile' | 'settings' | 'theme' | 'signout'

export interface AccountItem {
  id: AccountItemId
  label: string
  href?: string
}

/** The admin's Settings screen (Settings › Appearance holds the color scheme). */
export const SETTINGS_HREF = '/admin/settings'

export const THEME_CHOICES = [
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
  { value: 'system', label: 'System' },
] as const

/**
 * The rows, in order. Profile only when the app names a page for it;
 * Settings only for people whose menu has Settings (same access rules).
 */
export function accountMenuItems(c: { profileHref?: string | null; canSettings: boolean }): AccountItem[] {
  const out: AccountItem[] = []
  if (c.profileHref) out.push({ id: 'profile', label: 'Profile', href: c.profileHref })
  if (c.canSettings) out.push({ id: 'settings', label: 'Settings', href: SETTINGS_HREF })
  out.push({ id: 'theme', label: 'Light or dark' })
  out.push({ id: 'signout', label: 'Sign out' })
  return out
}

/** Two letters for the avatar: first + last word of the name, else the email's local part. */
export function avatarInitials(name?: string | null, email?: string | null): string {
  const words = (name ?? '').trim().split(/\s+/).filter(Boolean)
  if (words.length >= 2) return (words[0][0] + words[words.length - 1][0]).toUpperCase()
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase()
  const local = (email ?? '').split('@')[0].split(/[._-]+/).filter(Boolean)
  if (local.length >= 2) return (local[0][0] + local[1][0]).toUpperCase()
  return (local[0] ?? '').slice(0, 2).toUpperCase() || '?'
}

/** Whether this person's menu (already access-filtered) includes Settings. */
export function menuHasSettings(groups: ReadonlyArray<{ items: ReadonlyArray<{ href: string }> }>): boolean {
  return groups.some((g) => g.items.some((i) => i.href === SETTINGS_HREF))
}
