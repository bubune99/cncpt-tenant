/**
 * Where the way into the assistant sits once the floating button is gone
 * (owner 2026-10-17): a tab in the sidebar; when the sidebar AND the chat
 * are both closed, a row in the ☰ menu instead. Opening it gives the
 * agent-first column — the sidebar is not touched, and nothing about it is
 * remembered (only the person's own close of the sidebar is). Closing the
 * chat again brings the sidebar back. Pure; asserted by assistant-entry.assert.ts.
 */

export type AssistantEntry = 'sidebar' | 'menu' | 'none'

/** The chat mode opening from the entry sets: the agent-first column. */
export const OPEN_FROM_ENTRY = 'split' as const

export function assistantEntry(s: {
  /** The host shows an assistant at all. */
  chatEnabled: boolean
  /** The assistant is working (resting → the CMS by hand, no way in). */
  assistantAvailable: boolean
  /** The chat is open (column, side panel or full page). */
  assistantOpen: boolean
  /** The sidebar is showing (Classic). */
  sidebarShown: boolean
  /** Phones have the Ask tab instead. */
  phone?: boolean
}): AssistantEntry {
  if (!s.chatEnabled || !s.assistantAvailable || s.phone || s.assistantOpen) return 'none'
  return s.sidebarShown ? 'sidebar' : 'menu'
}
