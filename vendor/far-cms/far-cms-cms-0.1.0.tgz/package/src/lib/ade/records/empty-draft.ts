/**
 * "Add an <item>" opens an EMPTY draft record on its record page (owner
 * rule R2, 2026-10-17): no "new" form step. The draft starts with the type's
 * defaults and a placeholder web address; it is never public (status DRAFT)
 * and publishing still goes through the page's own checklist and review.
 *
 * Pure and app-agnostic. Asserted by empty-draft.assert.ts.
 */

import type { RecordData, RecordTypeDef } from './types'
import { slugify } from './logic'

export const PLACEHOLDER_SLUG_PREFIX = 'untitled-'

/** Where an empty draft came from (AdeRecord.legacyRef), so the same person's untouched one is reused. */
export const emptyDraftRef = (userId: string) => `empty-draft:${userId}`

/** "untitled-3f9a1c": unique enough with the record id; replaced by the name's address once it has one. */
export function placeholderSlug(recordId: string): string {
  const tail = recordId.replace(/[^a-z0-9]/gi, '').slice(-6).toLowerCase() || '0'
  return `${PLACEHOLDER_SLUG_PREFIX}${tail}`
}

export function isPlaceholderSlug(slug: string | null | undefined): boolean {
  return typeof slug === 'string' && slug.startsWith(PLACEHOLDER_SLUG_PREFIX)
}

/** The type's defaults: nothing else filled in. */
export function emptyDraftData(def: Pick<RecordTypeDef, 'fields'>): RecordData {
  return Object.fromEntries(def.fields.filter((f) => f.default !== undefined).map((f) => [f.key, f.default]))
}

/** Nothing was filled in beyond the defaults (so opening "Add" again reuses it instead of making another). */
export function isUntouched(def: Pick<RecordTypeDef, 'fields'>, data: RecordData): boolean {
  const defaults = emptyDraftData(def)
  const keys = new Set([...Object.keys(defaults), ...Object.keys(data ?? {})])
  for (const k of keys) {
    const v = (data ?? {})[k]
    const empty = v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0)
    if (k in defaults ? JSON.stringify(v ?? null) !== JSON.stringify(defaults[k]) : !empty) return false
  }
  return true
}

/**
 * The web address after an update: the one the person set; else, while it is
 * still the placeholder and the record now has a name, the name's address;
 * else unchanged.
 */
export function slugAfterUpdate(def: Pick<RecordTypeDef, 'slugField' | 'titleField'>, currentSlug: string, data: RecordData): string {
  const set = data[def.slugField]
  if (typeof set === 'string' && set.trim()) return set.trim()
  const name = data[def.titleField]
  if (isPlaceholderSlug(currentSlug) && typeof name === 'string' && slugify(name)) return slugify(name)
  return currentSlug
}

/**
 * Whether a record shows in its list. A person's untouched blank draft (placeholder address,
 * nothing filled in, no change waiting on it in To-do) is their scratch page from "New …",
 * not a record yet, so it is left out of the list and its counts.
 */
export function listsAsRecord(def: Pick<RecordTypeDef, 'fields'>, row: { slug: string | null; data: RecordData }, waitingChanges: number): boolean {
  if (waitingChanges > 0) return true
  return !(isPlaceholderSlug(row.slug) && isUntouched(def, row.data ?? {}))
}
