/**
 * How the assistant describes a record type's records — the same "live" as
 * Today, the Initiatives list and the site (status PUBLISHED; drafts never
 * show; archived ones are gone). Pure.
 */

export interface ListingRow {
  id: string
  slug: string
  status: string
  data: unknown
}

/** Live on the site: published. */
export const isLiveRecord = (status: string): boolean => status === 'PUBLISHED'

const text = (v: unknown): string | null => (typeof v === 'string' && v.trim() ? v.trim() : null)

/** Where a record opens in the admin — what the assistant links a named record to. */
export const recordAdminHref = (type: string, id: string): string => `/admin/records/${encodeURIComponent(type)}/${encodeURIComponent(id)}`

/** Counts plus one line per record (archived left out), newest first as given; each with its admin link. */
/** The pill and place fields the listing reads (a type's own names; defaults = the first type's). */
export interface ListingFields {
  badge: string
  place: string
}

export function recordListing(rows: readonly ListingRow[], titleField = 'name', type = 'initiative', fields: ListingFields = { badge: 'stage', place: 'location' }) {
  const shown = rows.filter((r) => r.status !== 'ARCHIVED')
  const items = shown.map((r) => {
    const d = (r.data && typeof r.data === 'object' ? r.data : {}) as Record<string, unknown>
    return {
      id: r.id,
      slug: r.slug,
      title: text(d[titleField]) ?? r.slug,
      state: isLiveRecord(r.status) ? ('live' as const) : ('draft' as const),
      stage: text(d[fields.badge]),
      location: text(d[fields.place]),
      adminHref: recordAdminHref(type, r.id),
    }
  })
  const live = items.filter((i) => i.state === 'live').length
  return { count: items.length, live, drafts: items.length - live, items }
}
