// Moved to @far-cms/core (far-cms packages/core/src/lib/ade/records/details-tab.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/ade/records/details-tab'
