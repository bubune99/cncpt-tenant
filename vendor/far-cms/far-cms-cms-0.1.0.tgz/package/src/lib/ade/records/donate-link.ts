/**
 * A record page's "/donate" buttons follow the record's own donation link, at render
 * time (pages are made from the template once; stored content is never edited).
 * Pure; checked by donate-link.assert.ts.
 */

interface LinkBlock {
  attrs?: Record<string, unknown>
  children?: LinkBlock[]
}

const SITE_DONATE = /^\/donate\/?(?:[?#].*)?$/

/** A web address or a path on this site; anything else (javascript:, //host, bare words) is refused. */
export function safeDonateUrl(v: unknown): string | null {
  if (typeof v !== 'string') return null
  const s = v.trim()
  if (/^https?:\/\/[^\s]+$/i.test(s)) return s
  if (/^\/(?!\/)[^\s]*$/.test(s)) return s
  return null
}

/** New blocks with every link to the site's /donate pointed at `url`; the same array when there is nothing to change. */
export function withDonateLink<T extends LinkBlock>(blocks: T[], url: unknown): T[] {
  const to = safeDonateUrl(url)
  if (!to) return blocks
  const walk = (bs: LinkBlock[]): LinkBlock[] =>
    bs.map((b) => {
      const href = b.attrs?.href
      const attrs = typeof href === 'string' && SITE_DONATE.test(href.trim()) ? { ...b.attrs, href: to } : b.attrs
      const children = b.children ? walk(b.children) : b.children
      return attrs === b.attrs && children === b.children ? b : { ...b, attrs, children }
    })
  return walk(blocks) as T[]
}
