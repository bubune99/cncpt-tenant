/**
 * A record page's parts as units the assistant can reveal and point at (and
 * fill — lane B), from the record type itself: the fields drawn on the page
 * (name, summary, photo, story…) and the rest behind the Details drawer, plus
 * the drawer's tabs. Selectors are the page's stable data-ui names.
 *
 * Pure and app-agnostic; the app says which fields its page draws and the
 * capability that opens the drawer. Asserted by field-units.assert.ts.
 */

import type { RecordTypeDef } from './types'
import type { ScreenUnit } from '../ui/screen-context'
import type { RevealStep } from '../ui/control'

export const fieldSelector = (key: string) => `[data-ui="record.field.${key}"]`

export interface RecordPageLayout {
  /** Fields drawn on the page, with a selector when it isn't record.field.<key> (the photo, the stage pill). */
  onPage: Readonly<Record<string, string | true>>
  /** Fields shown under the drawer's Details tab (others aren't drawn anywhere, so they aren't units). */
  inDrawer: ReadonlyArray<string>
  /** The drawer tabs: id → { label, selector }. */
  tabs: ReadonlyArray<{ id: string; label: string; selector: string }>
  /** The screen's capability that opens the drawer on a tab ({ open: true, tab }). */
  openDrawer: string
}

export function recordFieldUnits(def: Pick<RecordTypeDef, 'fields'>, layout: RecordPageLayout): ScreenUnit[] {
  const tabLabel = (tab: string) => layout.tabs.find((t) => t.id === tab)?.label ?? tab
  // Opening the drawer on a tab, as data: what it should make true, and the manual way (lib/ade/ui/control).
  const openOn = (tab: string, expectSelector: string): RevealStep[] => [
    {
      capability: layout.openDrawer,
      args: { open: true, tab },
      what: `open the ${tabLabel(tab)} tab`,
      // Mounted: a field below the drawer's fold is open and reachable (lane B, 2026-10-18).
      expect: { kind: 'mounted', selector: expectSelector },
      manual: `You can open it with the Details button at the top right, then “${tabLabel(tab)}”.`,
    },
  ]
  const fields: ScreenUnit[] = def.fields.flatMap((f): ScreenUnit[] => {
    const page = layout.onPage[f.key]
    const aliases = f.aliases?.length ? { aliases: f.aliases } : {}
    if (page) return [{ key: f.key, label: f.label, selector: page === true ? fieldSelector(f.key) : page, where: 'page', ...aliases }]
    if (layout.inDrawer.includes(f.key)) return [{ key: f.key, label: f.label, selector: fieldSelector(f.key), where: 'drawer', tab: 'details', revealPath: openOn('details', fieldSelector(f.key)), ...aliases }]
    return []
  })
  const tabs: ScreenUnit[] = layout.tabs.map((t) => ({ key: `tab:${t.id}`, label: t.label, selector: t.selector, where: 'drawer' as const, tab: t.id, revealPath: openOn(t.id, t.selector) }))
  return [...fields, ...tabs]
}
