/**
 * Archive and restore a record (initiatives first). Owner approved 2026-11-17 (card 1a67b175).
 * Nothing is deleted: archiving takes the record and its page off the site and out of the lists;
 * restoring brings it back as a draft. Taking a live one off the site waits for approval in To-do,
 * as unpublishing does; a draft is archived at once. Pure; asserted by archive.assert.ts.
 */
export type ArchiveAction = 'archive' | 'restore'
type Status = { status: string; pageStatus: string | null }
type After = { status: 'ARCHIVED' | 'DRAFT'; pageStatus: 'ARCHIVED' | 'DRAFT' | null }

export function archiveAfter(action: ArchiveAction, live: Status): After | { error: string } {
  if (action === 'archive') {
    if (live.status === 'ARCHIVED') return { error: 'It is already archived' }
    return { status: 'ARCHIVED', pageStatus: live.pageStatus === null ? null : 'ARCHIVED' }
  }
  if (live.status !== 'ARCHIVED') return { error: 'It is not archived' }
  return { status: 'DRAFT', pageStatus: live.pageStatus === null ? null : 'DRAFT' }
}

export function archiveNeedsApproval(action: ArchiveAction, status: string): boolean {
  return action === 'archive' && status === 'PUBLISHED'
}

export function archiveSummary(action: ArchiveAction, typeLabel: string, title: string, live: boolean): string {
  const kind = typeLabel.toLowerCase()
  if (action === 'restore') return `Restore ${kind} “${title}” as a draft`
  return live ? `Archive ${kind} “${title}”: take it and its page off the site` : `Archive ${kind} “${title}”`
}
