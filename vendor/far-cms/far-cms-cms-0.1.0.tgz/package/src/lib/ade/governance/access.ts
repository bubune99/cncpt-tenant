// Moved to @far-cms/core (far-cms packages/core/src/lib/ade/governance/access.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/ade/governance/access'
