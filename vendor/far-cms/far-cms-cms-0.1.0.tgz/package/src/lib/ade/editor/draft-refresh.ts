/**
 * What the open editor does when To-do changes (an assistant's draft made, approved or rejected).
 * Unsaved edits by the person are never replaced. Check: draft-refresh.assert.ts.
 */
export type DraftRefreshAction = 'load-draft' | 'load-live' | 'clear-note' | 'note' | 'none'

export const DRAFT_WAITING_NOTE = 'A new draft for this page is waiting in To-do. Save or discard your edits to see it here.'

/** Blocks compared as content: the canvas adds parentId and may order keys differently. */
function canon(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(canon)
  if (v && typeof v === 'object') {
    const out: Record<string, unknown> = {}
    for (const k of Object.keys(v as object).sort()) {
      const x = (v as Record<string, unknown>)[k]
      if (k === 'parentId' || x === undefined) continue
      out[k] = canon(x)
    }
    return out
  }
  return v
}
const same = (a: unknown, b: unknown) => JSON.stringify(canon(a ?? null)) === JSON.stringify(canon(b ?? null))

export function draftRefreshAction(s: {
  hasUnsaved: boolean
  /** The blocks on the canvas now. */
  shown: unknown
  /** The stacked pending draft, or null when none is waiting. */
  draft: unknown | null
  /** The live (published-to-database) blocks. */
  live: unknown
  /** Whether the canvas is showing a draft (the draft note is up). */
  showingDraft: boolean
}): DraftRefreshAction {
  if (s.draft) {
    if (same(s.draft, s.shown)) return 'none'
    return s.hasUnsaved ? 'note' : 'load-draft'
  }
  if (!s.showingDraft || s.hasUnsaved) return 'none'
  return same(s.live, s.shown) ? 'clear-note' : 'load-live'
}
