/**
 * Settings › Connectors, as people read it: each person's own mailbox
 * connection (Gmail or Outlook) — whether it's set up on this site, which
 * account, what it lets the assistant do in plain words, when it was last
 * used. Pure (the screen fetches; this decides what it says). Asserted by
 * connectors.assert.ts.
 */

export type ConnectorProvider = 'google' | 'microsoft'

/** What it lets the assistant do (the connectors API's `can`). */
export type ConnectorAbility = 'read' | 'draft' | 'send'

/** What the connectors API (GET /api/connectors) says about one provider for the signed-in person. */
export interface ConnectorStatus {
  provider: ConnectorProvider
  /** The site has this provider's OAuth app keys (env). */
  configured: boolean
  connected: boolean
  /** 'needs-reconnect': the provider stopped accepting the stored sign-in. */
  status?: 'active' | 'needs-reconnect' | null
  /** The connected account's address. */
  account?: string | null
  can?: ReadonlyArray<ConnectorAbility>
  /** Granted scopes, as the provider names them (when the API sends them instead of `can`). */
  scopes?: ReadonlyArray<string>
  connectedAt?: string | null
  lastUsedAt?: string | null
}

const ABILITY_WORDS: Record<ConnectorAbility, string> = {
  read: 'Read your email',
  draft: 'Write drafts in your mailbox',
  send: 'Send email as you (only after you approve each one)',
}

/** `can` in plain words, in a stable order. */
export function abilityWords(can: ReadonlyArray<string> | null | undefined): string[] {
  return (['read', 'draft', 'send'] as const).filter((a) => (can ?? []).includes(a)).map((a) => ABILITY_WORDS[a])
}

export const CONNECTOR_PROVIDERS: Record<ConnectorProvider, { name: string; product: string; connectLabel: string }> = {
  google: { name: 'Google', product: 'Gmail', connectLabel: 'Connect Google' },
  microsoft: { name: 'Microsoft', product: 'Outlook', connectLabel: 'Connect Microsoft' },
}

/** Provider scope → what it lets the assistant do. Unknown scopes are listed as "Other access". */
const SCOPE_WORDS: ReadonlyArray<{ re: RegExp; words: string }> = [
  // The scopes the connector core requests (settings-n): Google gmail.readonly + gmail.compose (which
  // also sends); Microsoft Mail.ReadWrite + Mail.Send + offline_access; openid / email / User.Read.
  { re: /^(gmail\.readonly|gmail\.metadata|mail\.read|mail\.readwrite)$/i, words: 'Read your email' },
  { re: /^(gmail\.compose|gmail\.modify|mail\.readwrite)$/i, words: 'Write drafts in your mailbox' },
  { re: /^(gmail\.compose|gmail\.send|mail\.send)$/i, words: 'Send email as you (only after you approve each one)' },
  { re: /^gmail\.labels$/i, words: 'Organise your labels' },
  { re: /^offline_access$/i, words: 'Stay connected without signing in again' },
  { re: /^(openid|email|profile|user\.read)$|userinfo\.(email|profile)$/i, words: 'Know which account it is' },
]


/** Granted scopes in plain words, each once, in a stable order. */
export function scopeWords(scopes: ReadonlyArray<string> | null | undefined): string[] {
  const out: string[] = []
  let other = false
  for (const raw of scopes ?? []) {
    const scope = raw.trim().replace(/^https:\/\/(www\.)?googleapis\.com\/auth\//, '').replace(/^https:\/\/graph\.microsoft\.com\//i, '')
    if (!scope) continue
    const hits = SCOPE_WORDS.filter((s) => s.re.test(scope)).map((s) => s.words)
    if (!hits.length) other = true
    for (const h of hits) if (!out.includes(h)) out.push(h)
  }
  const order = SCOPE_WORDS.map((s) => s.words)
  out.sort((a, b) => order.indexOf(a) - order.indexOf(b))
  if (other) out.push('Other access')
  return out
}

/** "just now", "5 minutes ago", "3 days ago", "Never". */
export function lastUsedWords(iso: string | null | undefined, now: Date): string {
  if (!iso) return 'Never'
  const t = Date.parse(iso)
  if (Number.isNaN(t)) return 'Never'
  const s = Math.max(0, Math.round((now.getTime() - t) / 1000))
  if (s < 60) return 'Just now'
  const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'} ago`
  if (s < 3600) return plural(Math.floor(s / 60), 'minute')
  if (s < 86_400) return plural(Math.floor(s / 3600), 'hour')
  if (s < 86_400 * 30) return plural(Math.floor(s / 86_400), 'day')
  return new Date(t).toLocaleDateString('en', { day: 'numeric', month: 'short', year: 'numeric' })
}

export type ConnectorCardState = 'not-set-up' | 'not-connected' | 'connected' | 'needs-reconnect'

export interface ConnectorCard {
  provider: ConnectorProvider
  title: string
  state: ConnectorCardState
  /** One line under the title. */
  status: string
  account?: string
  permissions: string[]
  lastUsed?: string
  /** The one action the card offers (a card that needs reconnecting also offers Disconnect). */
  action: { kind: 'connect'; label: string } | { kind: 'disconnect'; label: string } | null
  /** A second action (Disconnect next to Reconnect). */
  secondary?: { kind: 'disconnect'; label: string }
}

export const NOT_SET_UP = 'Not set up yet: ask the site owner.'

export function connectorCard(s: ConnectorStatus, now: Date): ConnectorCard {
  const meta = CONNECTOR_PROVIDERS[s.provider]
  const title = `${meta.name} (${meta.product})`
  const permissions = s.can ? abilityWords(s.can) : scopeWords(s.scopes)
  if (s.connected && s.status === 'needs-reconnect') {
    return {
      provider: s.provider,
      title,
      state: 'needs-reconnect',
      status: `${s.account ? `${s.account}: ` : ''}${meta.name} stopped accepting the connection. Reconnect to keep using it.`,
      ...(s.account ? { account: s.account } : {}),
      permissions,
      action: s.configured ? { kind: 'connect', label: 'Reconnect' } : null,
      secondary: { kind: 'disconnect', label: 'Disconnect' },
    }
  }
  if (s.connected) {
    return {
      provider: s.provider,
      title,
      state: 'connected',
      status: s.account ? `Connected as ${s.account}` : 'Connected',
      ...(s.account ? { account: s.account } : {}),
      permissions,
      // The API may not track use yet: then say when it was connected.
      lastUsed: s.lastUsedAt !== undefined ? lastUsedWords(s.lastUsedAt, now) : s.connectedAt ? `Not tracked yet (connected ${lastUsedWords(s.connectedAt, now).toLowerCase()})` : 'Not tracked yet',
      action: { kind: 'disconnect', label: 'Disconnect' },
    }
  }
  // Keys missing: nobody here can connect until the owner adds them (a connected account still shows above).
  if (!s.configured) return { provider: s.provider, title, state: 'not-set-up', status: NOT_SET_UP, permissions: [], action: null }
  return { provider: s.provider, title, state: 'not-connected', status: 'Not connected', permissions: [], action: { kind: 'connect', label: meta.connectLabel } }
}

/** The confirm dialog before disconnecting. */
export function disconnectConfirm(card: ConnectorCard): { title: string; body: string; confirmLabel: string; destructive: true } {
  return {
    title: `Disconnect ${CONNECTOR_PROVIDERS[card.provider].product}?`,
    body: `The assistant will stop reading${card.account ? ` ${card.account}` : ' this mailbox'} and can’t send email as you. Your email itself isn’t touched. You can connect again any time.`,
    confirmLabel: 'Disconnect',
    destructive: true,
  }
}

/**
 * The connector core's ?connector_error= codes (CONNECTOR_ERROR_CODES in
 * lib/ade/connectors/oauth — not imported: it pulls in node:crypto and this
 * runs in the browser; the assert keeps the two lists equal), in our words.
 * unknown_provider, and anything else, gets the one generic line.
 */
export const CONNECTOR_ERROR_TEXT: Record<string, string> = {
  denied: 'You didn’t allow access, so nothing was connected.',
  not_configured: NOT_SET_UP,
  state_expired: 'That connect link expired or was changed. Try connecting again.',
  sign_in_expired: 'You were signed out partway through. Sign in and try again.',
  not_yours: 'That connect link was started by someone else. Try connecting again yourself.',
  cross_site: 'That request didn’t come from this site. Try again from Settings.',
  no_code: 'Google or Microsoft didn’t finish the sign-in. Try again.',
  provider_error: 'Google or Microsoft didn’t finish the sign-in. Try again.',
  exchange_failed: 'Google or Microsoft didn’t finish the sign-in. Try again.',
}
/** Codes that deliberately get the generic line. */
export const CONNECTOR_ERROR_GENERIC_CODES = ['unknown_provider'] as const
export const RETURN_ERROR_GENERIC = 'Couldn’t connect. Try again, or ask the site owner.'

/**
 * What to tell the person when the provider sends them back
 * (?connector=google&connected=1, or &connector_error=<code>). The address
 * is attacker-controllable, so nothing from it is shown: known codes get
 * fixed text, anything else one generic line; lookups are own-property only.
 */
export function returnMessage(params: { get(name: string): string | null }): { ok: boolean; text: string } | null {
  const p = params.get('connector') ?? params.get('connected')
  const provider = p && Object.hasOwn(CONNECTOR_PROVIDERS, p) ? CONNECTOR_PROVIDERS[p as ConnectorProvider] : null
  const err = params.get('connector_error')
  if (provider && !err && params.get('connected')) return { ok: true, text: `${provider.product} is connected.` }
  if (!err) return null
  return { ok: false, text: Object.hasOwn(CONNECTOR_ERROR_TEXT, err) ? CONNECTOR_ERROR_TEXT[err] : RETURN_ERROR_GENERIC }
}

/** Microsoft has no per-app revoke: where the person removes the access themselves (only Microsoft's own pages). */
export function microsoftManageUrl(url: unknown): string | null {
  if (typeof url !== 'string') return null
  try {
    const u = new URL(url)
    return u.protocol === 'https:' && /(^|\.)(microsoft\.com|live\.com|microsoftonline\.com|office\.com)$/i.test(u.hostname) ? u.toString() : null
  } catch {
    return null
  }
}
