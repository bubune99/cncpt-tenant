/**
 * The brand on the server (metadata, sign-in, email defaults): Settings ›
 * Identity & brand through the shared settings cache. A failed read gives the
 * unset brand — never another site's name.
 */

import { getSettings } from './index'
import { resolveBrand, type Brand } from './brand'

export async function getBrand(): Promise<Brand> {
  try {
    return resolveBrand(await getSettings<Record<string, unknown>>('branding', {}))
  } catch (error) {
    console.error('[brand] could not read branding settings:', error)
    return resolveBrand(null)
  }
}
