// Moved to @far-cms/core (far-cms packages/core/src/lib/settings/ai-update.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/settings/ai-update'
