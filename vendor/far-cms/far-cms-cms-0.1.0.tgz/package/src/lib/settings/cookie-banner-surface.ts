/**
 * The cookie banner's surface: always OPAQUE, whatever the browser supports.
 *
 * It used to be bg-background/80 with a backdrop blur. That is
 * `color-mix(… transparent)`, which older mobile Safari (and DOM capture
 * tools) don't support, so the banner's text sat straight over the page
 * copy, unreadable (Akuse page at 390 px). The surface is now the solid
 * page background, with literal fallbacks in case a theme doesn't define
 * the tokens. Client-safe; asserted (cookie-banner-surface.assert.ts).
 */

import type { CSSProperties } from 'react'

export const BANNER_BG_FALLBACK = '#ffffff'
export const BANNER_FG_FALLBACK = '#171717'

export const BANNER_SURFACE: CSSProperties = {
  backgroundColor: `var(--background, ${BANNER_BG_FALLBACK})`,
  color: `var(--foreground, ${BANNER_FG_FALLBACK})`,
}
