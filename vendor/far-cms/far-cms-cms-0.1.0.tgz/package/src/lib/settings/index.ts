/**
 * Settings Library
 *
 * Centralized settings management with database storage and encryption
 */

import { cleanApiKey } from '../email/api-key'
import { normalizeAdminThemeId, normalizeChoice } from '../ade/ui/admin-theme'
import { APP_ADE_DEFAULTS } from '../ade-bindings/app-config'
import { normalizeModeSettings } from '../ai/governance/agent-modes'
import { prisma } from '../db'
import { normalizeWorkspaceRoles } from '../ade/admin-mode'
import { sanitizePace } from '../ade/ui/autoplay'
import { sanitizeAdvanceRule } from '../ade/ui/advance'
import { encrypt, safeDecrypt, isEncrypted } from '../encryption'
import type {
  SettingGroup,
  BrandingSettings,
  GeneralSettings,
  EmailSettings,
  StorageSettings,
  AiSettings,
  SecuritySettings,
  CaptchaSettings,
  NavigationSettings,
  InitiativesSettings,
  AdeSettings,
  EnvVarStatus,
} from './types'
import type { AgentSettings } from '../ai/governance/types'
import { resolvePrivacy, type PrivacySettings } from './privacy'
import { resolveOrganization, type OrganizationSettings } from './organization'
import { DEFAULT_AGENT_SETTINGS } from '../ai/governance/types'
import {
  REQUIRED_ENV_VARS,
  DEFAULT_BRANDING_SETTINGS,
  DEFAULT_GENERAL_SETTINGS,
  DEFAULT_EMAIL_SETTINGS,
  DEFAULT_STORAGE_SETTINGS,
  DEFAULT_AI_SETTINGS,
  DEFAULT_SECURITY_SETTINGS,
  DEFAULT_CAPTCHA_SETTINGS,
  DEFAULT_NAVIGATION_SETTINGS,
  DEFAULT_INITIATIVES_SETTINGS,
  DEFAULT_ADE_SETTINGS,
} from './types'
import { moduleCacheAllowed } from '../db/host-client'

// Keys that should be encrypted in the database
const SENSITIVE_KEYS: Record<SettingGroup, string[]> = {
  email: ['smtpPass', 'sendgridApiKey', 'resendApiKey', 'mailgunApiKey', 'sesAccessKeyId', 'sesSecretAccessKey'],
  storage: ['accessKeyId', 'secretAccessKey'],
  ai: ['apiKey'],
  payments: ['stripeSecretKey', 'stripeWebhookSecret', 'paypalClientSecret'],
  branding: [],
  general: [],
  store: [],
  shipping: [],
  analytics: [],
  seo: [],
  security: [],
  captcha: ['secretKey'],
  dashboard: [],
  agent: [],
  ade: [],
  navigation: [],
  initiatives: [],
  privacy: [],
  organization: [],
}

// Cache for settings
const settingsCache: Map<SettingGroup, { data: any; timestamp: number }> = new Map()
const CACHE_TTL = 60 * 1000 // 1 minute

/**
 * Get settings for a specific group
 */
export async function getSettings<T>(
  group: SettingGroup,
  defaults: T
): Promise<T> {
  // Check cache
  const cached = settingsCache.get(group)
  if (moduleCacheAllowed() && cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data as T
  }

  const records = await prisma.setting.findMany({
    where: { group },
  })

  const settings = { ...defaults } as any
  const sensitiveKeys = SENSITIVE_KEYS[group] || []

  for (const record of records) {
    const key = record.key.replace(`${group}.`, '')
    let value = record.value

    // Decrypt if this is a sensitive key and the value is encrypted
    if (sensitiveKeys.includes(key) && record.encrypted && isEncrypted(value)) {
      value = safeDecrypt(value)
    }

    try {
      // Try to parse JSON values
      settings[key] = JSON.parse(value)
    } catch {
      // Use raw value if not JSON
      settings[key] = value
    }
  }

  // Update cache
  settingsCache.set(group, { data: settings, timestamp: Date.now() })

  return settings as T
}

/**
 * Update settings for a group
 */
export async function updateSettings(
  group: SettingGroup,
  settings: Record<string, any>,
  /** Who and why, for the version history (lib/settings/history). Defaults to the chat run or an unknown user. */
  history?: import('./history').SettingsWriteContext
): Promise<void> {
  const sensitiveKeys = SENSITIVE_KEYS[group] || []
  // Every save of a settings section is a version (loaded lazily: history → visibility → settings).
  const h = await import('./history')
  const before = await h.readGroupValues(group)

  for (const [key, value] of Object.entries(settings)) {
    if (value === undefined) continue

    // Skip if value is masked (unchanged)
    if (value === '********') continue

    const fullKey = `${group}.${key}`
    const isSensitive = sensitiveKeys.includes(key)

    // Encrypt sensitive values before storing
    let stringValue = typeof value === 'string' ? value : JSON.stringify(value)
    if (isSensitive && stringValue && stringValue !== '') {
      stringValue = encrypt(stringValue)
    }

    await prisma.setting.upsert({
      where: { key: fullKey },
      create: {
        key: fullKey,
        value: stringValue,
        group,
        encrypted: isSensitive,
      },
      update: {
        value: stringValue,
        encrypted: isSensitive,
      },
    })
  }

  // Clear cache for this group
  settingsCache.delete(group)
  await h.recordSettingsChange(group, before, await h.readGroupValues(group), history)
}

/**
 * Clear settings cache
 */
export function clearSettingsCache(group?: SettingGroup): void {
  if (group) {
    settingsCache.delete(group)
  } else {
    settingsCache.clear()
  }
}

// Convenience functions for each settings group
export async function getBrandingSettings(): Promise<BrandingSettings> {
  return getSettings('branding', DEFAULT_BRANDING_SETTINGS)
}

export async function getNavigationSettings(): Promise<NavigationSettings> {
  return getSettings('navigation', DEFAULT_NAVIGATION_SETTINGS)
}

export async function getInitiativesSettings(): Promise<InitiativesSettings> {
  return getSettings('initiatives', DEFAULT_INITIATIVES_SETTINGS)
}

export async function getGeneralSettings(): Promise<GeneralSettings> {
  return getSettings('general', DEFAULT_GENERAL_SETTINGS)
}

export async function getEmailSettings(): Promise<EmailSettings> {
  const settings = await getSettings('email', DEFAULT_EMAIL_SETTINGS)

  // Fallback to environment variables
  if (!settings.smtpHost) settings.smtpHost = process.env.SMTP_HOST
  if (!settings.smtpPort) settings.smtpPort = parseInt(process.env.SMTP_PORT || '587')
  if (!settings.smtpUser) settings.smtpUser = process.env.SMTP_USER
  if (!settings.smtpPass) settings.smtpPass = process.env.SMTP_PASS
  if (!settings.sendgridApiKey) settings.sendgridApiKey = process.env.SENDGRID_API_KEY
  if (!settings.resendApiKey) settings.resendApiKey = process.env.RESEND_API_KEY
  // Keys are pasted by hand (a trailing space/newline or quotes make a good key "invalid" at the provider).
  settings.resendApiKey = cleanApiKey(settings.resendApiKey)
  settings.sendgridApiKey = cleanApiKey(settings.sendgridApiKey)
  // Sender name: the site's name from Identity & brand unless set here.
  if (!settings.fromName) settings.fromName = (await getBrandingSettings()).siteName

  return settings
}

export async function getStorageSettings(): Promise<StorageSettings> {
  const settings = await getSettings('storage', DEFAULT_STORAGE_SETTINGS)

  // Helper: read env var with whitespace trimmed (prevents %0A in URLs from trailing newlines)
  const env = (key: string) => process.env[key]?.trim() || undefined

  // Fallback to environment variables (S3 or R2)
  if (!settings.bucket) settings.bucket = env('S3_BUCKET') || env('R2_BUCKET')
  if (!settings.region) settings.region = env('S3_REGION') || 'auto'
  if (!settings.accessKeyId) settings.accessKeyId = env('S3_ACCESS_KEY_ID') || env('R2_ACCESS_KEY_ID')
  if (!settings.secretAccessKey) settings.secretAccessKey = env('S3_SECRET_ACCESS_KEY') || env('R2_SECRET_ACCESS_KEY')

  // Build R2 endpoint from account ID if not explicitly set
  if (!settings.endpoint) {
    const s3Endpoint = env('S3_ENDPOINT')
    const r2AccountId = env('R2_ACCOUNT_ID')
    if (s3Endpoint) {
      settings.endpoint = s3Endpoint
    } else if (r2AccountId) {
      settings.endpoint = `https://${r2AccountId}.r2.cloudflarestorage.com`
    }
  }

  // Public URL for R2
  if (!settings.publicUrl) settings.publicUrl = env('R2_PUBLIC_URL')

  // Auto-detect R2 provider when R2 env vars are used
  if (env('R2_BUCKET') || env('R2_ACCOUNT_ID')) {
    settings.provider = 'r2'
  }

  // Trim all string settings to prevent whitespace issues
  for (const key of Object.keys(settings) as (keyof StorageSettings)[]) {
    const val = settings[key]
    if (typeof val === 'string') {
      (settings as any)[key] = val.trim()
    }
  }

  return settings
}

export async function getAiSettings(): Promise<AiSettings> {
  const settings = await getSettings('ai', DEFAULT_AI_SETTINGS)
  // Uses Vercel AI Gateway - no API key handling needed
  return settings
}

export async function getSecuritySettings(): Promise<SecuritySettings> {
  return getSettings('security', DEFAULT_SECURITY_SETTINGS)
}

/** AI agent governance policy (what the chat agent is allowed to do). */
export async function getAgentSettings(): Promise<AgentSettings> {
  return getSettings('agent', DEFAULT_AGENT_SETTINGS)
}

/** ADE settings, normalised: anything unrecognised falls back to the safe default. */
export async function getAdeSettings(): Promise<AdeSettings> {
  const s = await getSettings('ade', DEFAULT_ADE_SETTINGS)
  const days = Number(s.staleDraftDays)
  return {
    changeMode: s.changeMode === 'direct' ? 'direct' : 'draft',
    allowDbCodeExecution: s.allowDbCodeExecution === true,
    staleDraftDays: Number.isFinite(days) && days >= 1 && days <= 365 ? Math.floor(days) : DEFAULT_ADE_SETTINGS.staleDraftDays,
    workspaceRoles: normalizeWorkspaceRoles(s.workspaceRoles),
    adminTheme: normalizeAdminThemeId(s.adminTheme, APP_ADE_DEFAULTS.adminTheme),
    defaultScheme: normalizeChoice(s.defaultScheme),
    feedbackDigest: s.feedbackDigest === true,
    agentModes: normalizeModeSettings(s.agentModes),
    // A tampered or out-of-range stored value is clamped here, on every read.
    walkthroughPace: sanitizePace(s.walkthroughPace),
    walkthroughAdvance: sanitizeAdvanceRule(s.walkthroughAdvance),
  }
}

/** Cookie & privacy banner — never saved reads as today's banner (lib/settings/privacy). */
export async function getPrivacySettings(): Promise<PrivacySettings> {
  return resolvePrivacy(await getSettings<Record<string, unknown>>('privacy', {}))
}

/** Donations & social links — never saved reads as today's hard-wired links (lib/settings/organization). */
export async function getOrganizationSettings(): Promise<OrganizationSettings> {
  return resolveOrganization(await getSettings<Record<string, unknown>>('organization', {}))
}

export async function getCaptchaSettings(): Promise<CaptchaSettings> {
  const settings = await getSettings('captcha', DEFAULT_CAPTCHA_SETTINGS)

  // Fallback to environment variables
  if (!settings.siteKey) settings.siteKey = process.env.TURNSTILE_SITE_KEY || ''
  if (!settings.secretKey) settings.secretKey = process.env.TURNSTILE_SECRET_KEY || ''

  // Auto-detect provider if keys are configured
  if (settings.provider === 'none' && settings.siteKey && settings.secretKey) {
    settings.provider = 'turnstile'
  }

  return settings
}

/**
 * Check environment variable status
 */
export function getEnvVarStatus(): EnvVarStatus[] {
  return REQUIRED_ENV_VARS.map((envVar) => ({
    ...envVar,
    configured: !!process.env[envVar.name],
  }))
}

/**
 * Get all settings for admin dashboard
 */
export async function getAllSettings(): Promise<{
  branding: BrandingSettings
  general: GeneralSettings
  email: EmailSettings
  storage: StorageSettings
  ai: AiSettings
  security: SecuritySettings
  envVars: EnvVarStatus[]
}> {
  const [branding, general, email, storage, ai, security] = await Promise.all([
    getBrandingSettings(),
    getGeneralSettings(),
    getEmailSettings(),
    getStorageSettings(),
    getAiSettings(),
    getSecuritySettings(),
  ])

  return {
    branding,
    general,
    email: {
      ...email,
      // Mask sensitive values
      smtpPass: email.smtpPass ? '********' : undefined,
      sendgridApiKey: email.sendgridApiKey ? '********' : undefined,
      resendApiKey: email.resendApiKey ? '********' : undefined,
      mailgunApiKey: email.mailgunApiKey ? '********' : undefined,
      sesSecretAccessKey: email.sesSecretAccessKey ? '********' : undefined,
    },
    storage: {
      ...storage,
      secretAccessKey: storage.secretAccessKey ? '********' : undefined,
    },
    ai,
    security,
    envVars: getEnvVarStatus(),
  }
}

export * from './types'
