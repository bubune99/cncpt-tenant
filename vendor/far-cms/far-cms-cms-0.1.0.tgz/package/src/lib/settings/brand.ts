/**
 * The site's brand as every surface shows it — admin header, sidebar, menu,
 * sign-in, email defaults, tab title and icon — resolved from Settings ›
 * Identity & brand and nothing else. No product name is ever hard-coded:
 * an unset name reads "Your site" with a "Set your brand" link.
 *
 * Pure; the server reads it with getBrand() (brand-server.ts), the browser
 * with useBrand() (components/brand/use-brand). Asserted by brand.assert.ts.
 */

export interface Brand {
  /** The site name, or "Your site" when none is set. */
  name: string
  /** False when Identity & brand has no name yet — show the setup link. */
  nameSet: boolean
  /** True only in the browser before the first load finishes: show neither a name nor the setup link. */
  loading?: boolean
  tagline: string | null
  /** The full logo (light background), any shape. */
  logoUrl: string | null
  logoDarkUrl: string | null
  logoAlt: string
  /**
   * The square tile (assistant header, sidebar, menu, sign-in): the square
   * icon, else the full logo — shown FIT (object-contain), never cropped.
   * null → initials.
   */
  markUrl: string | null
  /** Where markUrl came from. */
  markSource: 'icon' | 'logo' | 'none'
  /** Two letters from the name ("Hope Clinic" → "HC"). */
  initials: string
  /** Browser tab icon: the tab icon, else the square icon. null → the framework default. */
  faviconUrl: string | null
  appleTouchIconUrl: string | null
  primaryColor: string | null
  accentColor: string | null
}

export const UNSET_BRAND_NAME = 'Your site'
/** Where "Set your brand" goes. */
export const BRAND_SETUP_HREF = '/admin/settings?section=identity'
/** Same-tab window event and cross-tab BroadcastChannel name for "the brand changed". */
export const BRAND_CHANGED_EVENT = 'cms:brand-changed'

const text = (v: unknown): string | null => (typeof v === 'string' && v.trim() ? v.trim() : null)
const HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i

/** "Hope Clinic Ghana" → "HC", "Acme" → "AC", "" → "". Letters and digits only. */
export function initialsOf(name: string): string {
  const words = name.split(/\s+/).map((w) => w.replace(/[^\p{L}\p{N}]/gu, '')).filter(Boolean)
  if (!words.length) return ''
  return (words.length > 1 ? words[0][0] + words[1][0] : words[0].slice(0, 2)).toUpperCase()
}

/** The brand from the stored `branding` settings group (any shape; unknown keys ignored). */
export function resolveBrand(branding: Record<string, unknown> | null | undefined): Brand {
  const b = branding ?? {}
  const siteName = text(b.siteName)
  const name = siteName ?? UNSET_BRAND_NAME
  const iconUrl = text(b.iconUrl)
  const logoUrl = text(b.logoUrl)
  const markUrl = iconUrl ?? logoUrl
  const colour = (v: unknown) => (text(v) && HEX.test(text(v)!) ? text(v) : null)
  return {
    name,
    nameSet: siteName !== null,
    loading: false,
    tagline: text(b.siteTagline),
    logoUrl,
    logoDarkUrl: text(b.logoDarkUrl),
    logoAlt: text(b.logoAlt) ?? (siteName ? `${siteName} logo` : ''),
    markUrl,
    markSource: iconUrl ? 'icon' : logoUrl ? 'logo' : 'none',
    initials: initialsOf(name),
    faviconUrl: text(b.faviconUrl) ?? iconUrl,
    appleTouchIconUrl: text(b.appleTouchIconUrl) ?? iconUrl,
    primaryColor: colour(b.primaryColor),
    accentColor: colour(b.accentColor),
  }
}

/** The admin tab title: "Hope Clinic admin", or "Admin" with no name. */
export function adminTitle(brand: Brand): string {
  return brand.nameSet ? `${brand.name} admin` : 'Admin'
}
