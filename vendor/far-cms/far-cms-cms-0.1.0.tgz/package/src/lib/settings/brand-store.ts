/**
 * The browser's copy of the brand, kept live: one fetch per page load, then
 * any "brand changed" announcement (this tab: a window event; other tabs: a
 * BroadcastChannel) replaces it and tells every subscriber — no reload.
 *
 * No React and no DOM globals at import: the host passes fetch, the event
 * target and the channel factory, so asserts drive it in Node.
 */

import { BRAND_CHANGED_EVENT, resolveBrand, type Brand } from './brand'

export interface BrandChannel {
  postMessage(data: unknown): void
  addEventListener(type: 'message', fn: (e: { data: unknown }) => void): void
  close?(): void
}

export interface BrandStoreDeps {
  /** Loads the stored `branding` group (raw). */
  load: () => Promise<Record<string, unknown> | null>
  /** Same-tab events (window). */
  target?: EventTarget | null
  /** Cross-tab channel (new BroadcastChannel(BRAND_CHANGED_EVENT)). */
  channel?: BrandChannel | null
}

export interface BrandStore {
  get(): Brand
  /** True once the first load finished (or failed). */
  ready(): boolean
  subscribe(fn: (b: Brand) => void): () => void
  /** Load once (later calls reuse the first). */
  ensure(): Promise<Brand>
  /** Re-read from the server and notify. */
  refresh(): Promise<Brand>
  /**
   * After a save: apply the saved branding here at once (when given), tell
   * other tabs, and re-read from the server.
   */
  announce(branding?: Record<string, unknown> | null): Promise<Brand>
}

type Msg = { type: typeof BRAND_CHANGED_EVENT; branding?: Record<string, unknown> | null }
const isMsg = (d: unknown): d is Msg => !!d && typeof d === 'object' && (d as Msg).type === BRAND_CHANGED_EVENT

export function createBrandStore(deps: BrandStoreDeps): BrandStore {
  // Not 'unset' yet: until the first load ends the shell shows no name and no setup link.
  let brand: Brand = { ...resolveBrand(null), name: '', initials: '', loading: true }
  let loaded = false
  let first: Promise<Brand> | null = null
  const subs = new Set<(b: Brand) => void>()
  const set = (b: Brand) => {
    brand = b
    loaded = true
    subs.forEach((fn) => fn(b))
  }
  const refresh = async () => {
    try {
      const raw = await deps.load()
      if (raw) set(resolveBrand(raw))
      else if (brand.loading) set(resolveBrand(null))
      else loaded = true
    } catch {
      // Keep what we have; the shell must render without it.
      if (brand.loading) set(resolveBrand(null))
      else loaded = true
    }
    return brand
  }
  const apply = (branding?: Record<string, unknown> | null) => {
    if (branding) set(resolveBrand(branding))
    return refresh()
  }

  deps.target?.addEventListener(BRAND_CHANGED_EVENT, (e) => {
    void apply((e as CustomEvent<Msg>).detail?.branding)
  })
  deps.channel?.addEventListener('message', (e) => {
    if (isMsg(e.data)) void apply(e.data.branding)
  })

  return {
    get: () => brand,
    ready: () => loaded,
    subscribe(fn) {
      subs.add(fn)
      return () => subs.delete(fn)
    },
    ensure() {
      first ??= refresh()
      return first
    },
    refresh,
    async announce(branding) {
      deps.channel?.postMessage({ type: BRAND_CHANGED_EVENT, branding: branding ?? null } satisfies Msg)
      return apply(branding)
    },
  }
}
