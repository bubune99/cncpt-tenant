/**
 * Version history for settings (one entity per group: entityType 'settings',
 * entityId = the group). Every writer of the Setting table goes through
 * updateSettings or withSettingsHistory, so each save of a settings section
 * — brand/theme, navigation, the assistant's visibility policy and private
 * areas, email, payments… — is a version that can be restored. Encrypted
 * values are secrets: only "changed" is recorded.
 */

import { prisma } from '../db'
import type { Actor, RestorePolicy } from '../ade/history'
import { actorFor, recordRevision, registerHistory } from '../ade-bindings/history'
import { HistoryRefusal } from '../ade/history'
import { OWNER_ONLY_SETTING_GROUPS, settingGroupPermission, SETTINGS_NEVER_RESTORE } from './group-access'

export interface SettingsWriteContext {
  actor?: Actor
  reason?: string
  changeSetId?: string | null
}

/** A group's stored values by key (no defaults), and which keys are encrypted. */
export async function readGroupValues(group: string): Promise<{ values: Record<string, unknown>; encrypted: string[] }> {
  const rows = await prisma.setting.findMany({ where: { group }, select: { key: true, value: true, encrypted: true } })
  const values: Record<string, unknown> = {}
  const encrypted: string[] = []
  for (const r of rows) {
    const key = r.key.startsWith(`${group}.`) ? r.key.slice(group.length + 1) : r.key
    if (r.encrypted) encrypted.push(key)
    try {
      values[key] = r.encrypted ? r.value : JSON.parse(r.value)
    } catch {
      values[key] = r.value
    }
  }
  return { values, encrypted }
}

/** Record a group's change between two reads. Never throws. */
export async function recordSettingsChange(group: string, before: Awaited<ReturnType<typeof readGroupValues>>, after: Awaited<ReturnType<typeof readGroupValues>>, ctx: SettingsWriteContext = {}) {
  return recordRevision({
    entityType: 'settings',
    entityId: group,
    before: before.values,
    after: after.values,
    actor: ctx.actor ?? actorFor(null),
    changeSetId: ctx.changeSetId,
    reason: ctx.reason ?? 'save',
    secretFields: [...new Set([...before.encrypted, ...after.encrypted])],
  })
}

/** Run a write to one settings group and record it as a version. */
export async function withSettingsHistory<T>(group: string, ctx: SettingsWriteContext, write: () => Promise<T>): Promise<T> {
  const before = await readGroupValues(group)
  const out = await write()
  await recordSettingsChange(group, before, await readGroupValues(group), ctx)
  return out
}

/** Groups whose restore would bypass their own handling (env vars carry categories + encryption flags). */
const NO_RESTORE = new Set(['env'])

/** The permission each group's own screen requires. */
/** What the Settings screen calls each group. */
const GROUP_NAME: Record<string, string> = {
  branding: 'Identity & brand',
  general: 'Contact details',
  navigation: 'Admin menu',
  email: 'Sending email',
  ai: 'Assistant & limits',
  agent: 'What the assistant can see and do',
  ade: 'Admin appearance & assistant layout',
  initiatives: 'Initiatives',
  privacy: 'Cookie & privacy banner',
  payments: 'Payments',
  shipping: 'Shipping',
  analytics: 'Analytics',
  dashboard: 'Dashboard',
  security: 'Security',
  storage: 'Storage',
}


/** Settings keys are open-ended: each is restorable config (secrets are never stored, so never offered). */
export const SETTINGS_POLICY: RestorePolicy = {
  schemaVersion: 1,
  // Gated fields are never restored (R2-9): their own screen holds the super-admin / confirm-loosen check.
  fields: Object.fromEntries(Object.entries(SETTINGS_NEVER_RESTORE).map(([f, reason]) => [f, { class: 'never' as const, reason }])),
  defaultField: { class: 'restorable', type: 'json' },
}

registerHistory({
  entityType: 'settings',
  policy: SETTINGS_POLICY,
  // The same rule as the settings APIs (group-access): who may change a group may restore it.
  editPermission: settingGroupPermission,
  ownerOnly: (group) => OWNER_ONLY_SETTING_GROUPS.has(group),
  ignore: new Set(),
  nameOf: async (group) => GROUP_NAME[group] ?? `${group[0]?.toUpperCase() ?? ''}${group.slice(1)} settings`,
  load: async (group) => (await readGroupValues(group)).values,
  async save(group, patch, actor, reason) {
    if (NO_RESTORE.has(group)) throw new HistoryRefusal('These settings can’t be restored from history — change them in Settings › Environment')
    // Back to each value's own row (some keys aren't '<group>.<key>'); secrets are never in a patch.
    await withSettingsHistory(group, { actor, reason }, async () => {
      const rows = await prisma.setting.findMany({ where: { group }, select: { key: true } })
      for (const [field, value] of Object.entries(patch)) {
        const key = rows.some((r) => r.key === `${group}.${field}`) ? `${group}.${field}` : rows.some((r) => r.key === field) ? field : `${group}.${field}`
        if (value === null || value === undefined) {
          await prisma.setting.deleteMany({ where: { key } })
          continue
        }
        const stored = typeof value === 'string' ? value : JSON.stringify(value)
        await prisma.setting.upsert({ where: { key }, create: { key, value: stored, group, encrypted: false }, update: { value: stored } })
      }
      const { clearSettingsCache } = await import('./index')
      clearSettingsCache(group as never)
    })
  },
})
