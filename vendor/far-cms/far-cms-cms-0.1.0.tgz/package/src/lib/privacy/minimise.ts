/**
 * What Dzidzor stores about a visitor's connection: never the raw IP (a keyed
 * hash, lib/ade/privacy/ip-hash) and never the full user agent (browser
 * family + major version). Every writer of ipAddress / userAgent / consentIp
 * goes through these.
 *
 * The hash key is derived from ENCRYPTION_KEY (already required). Rotation:
 * set ENCRYPTION_KEY_PREVIOUS to the old value when changing ENCRYPTION_KEY,
 * so hashes made before still match (each hash names its key id).
 * Without a secret in production, nothing is stored (never a raw address).
 */

import { deriveKey, ipForStorage, ipMatches, type HashKey } from '../ade/privacy/ip-hash'
import { uaFamily } from '../ade/privacy/ua'

const LABEL = 'ip-hash:v1'
let cached: { master: string; prev: string; keys: HashKey[] } | null = null

export function ipKeys(): HashKey[] {
  const master = process.env.ENCRYPTION_KEY ?? ''
  const prev = process.env.ENCRYPTION_KEY_PREVIOUS ?? ''
  if (cached && cached.master === master && cached.prev === prev) return cached.keys
  const keys: HashKey[] = []
  if (master) keys.push(deriveKey(master, LABEL))
  else if (process.env.NODE_ENV !== 'production') keys.push(deriveKey('dev-only-ip-hash-secret', LABEL))
  if (prev) keys.push(deriveKey(prev, LABEL))
  cached = { master, prev, keys }
  return keys
}

/** The value to store for an IP: its keyed hash, or null. */
export function storeIp(raw: string | null | undefined): string | null {
  const [key] = ipKeys()
  return key ? ipForStorage(raw ?? null, key) : null
}

/** The value to store for a user agent: "Chrome 129" style, or null. */
export function storeUa(raw: string | null | undefined): string | null {
  return uaFamily(raw)
}

/** Is this stored hash that address (current or previous key)? */
export function storedIpIs(stored: string | null | undefined, raw: string): boolean {
  return ipMatches(stored, raw, ipKeys())
}
