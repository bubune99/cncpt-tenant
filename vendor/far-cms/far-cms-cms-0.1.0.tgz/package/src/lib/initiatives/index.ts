/**
 * Initiatives — client-safe barrel.
 *
 * Only types and HTML composition are re-exported here so client components can
 * import from './' without pulling prisma into the browser
 * bundle. Server code imports './initiatives/server' explicitly.
 */

export * from './types'
export * from './compose'
