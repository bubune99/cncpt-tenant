/**
 * Initiatives — HTML composition.
 *
 * Turns the wizard's structured answers into the semantic `contentHtml` the
 * storefront renders at /posts/[slug].
 *
 * Two constraints shape this file:
 *  1. `sanitizeRichHtml` (src/lib/sanitize-html.ts) strips any tag outside its
 *     allowlist, so only div/p/h2/h3/span/ul/li/blockquote/img/figure/hr are
 *     used here — no <section>, <article> or <aside>.
 *  2. This project has no @tailwindcss/typography plugin and no `.prose`
 *     styles, so the storefront applies no default styling to this markup.
 *     Every element therefore carries its own Tailwind classes. Those class
 *     names must stay as literal strings in this file for the Tailwind v4
 *     scanner to emit them.
 *
 * Browser-safe: no server-only imports.
 */

import {
  type InitiativeData,
  type InitiativeStage,
  type InitiativeContentJson,
  STAGE_LABELS,
} from './types'

const STAGE_BADGE_CLASSES: Record<InitiativeStage, string> = {
  active:
    'inline-flex items-center rounded-full bg-emerald-100 px-3 py-1 text-sm font-semibold text-emerald-800',
  ongoing:
    'inline-flex items-center rounded-full bg-amber-100 px-3 py-1 text-sm font-semibold text-amber-800',
  completed:
    'inline-flex items-center rounded-full bg-slate-200 px-3 py-1 text-sm font-semibold text-slate-700',
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/** Split plain-language input into paragraphs, preserving single line breaks. */
function toParagraphs(text: string, className: string): string {
  return text
    .split(/\r?\n\s*\r?\n/)
    .map((block) => block.trim())
    .filter(Boolean)
    .map((block) => {
      const body = escapeHtml(block).replace(/\r?\n/g, '<br />')
      return `<p class="${className}">${body}</p>`
    })
    .join('\n')
}

function heading(text: string): string {
  return `<h2 class="mt-10 mb-3 text-2xl font-bold tracking-tight text-slate-900">${escapeHtml(text)}</h2>`
}

export interface ComposeOptions {
  /**
   * Embed the hero image in the body. Callers pass false when the image was
   * resolved to a Media record and set as the post's featuredImage, which the
   * storefront already renders above the content.
   */
  includeHeroImage?: boolean
}

export function composeInitiativeHtml(
  data: InitiativeData,
  options: ComposeOptions = {}
): string {
  const { includeHeroImage = true } = options
  const parts: string[] = []

  // Meta row — stage badge + location.
  const metaItems: string[] = [
    `<span class="${STAGE_BADGE_CLASSES[data.stage]}">${escapeHtml(STAGE_LABELS[data.stage])}</span>`,
  ]
  if (data.location.trim()) {
    metaItems.push(
      `<span class="text-sm font-medium text-slate-600">${escapeHtml(data.location.trim())}</span>`
    )
  }
  parts.push(
    `<div class="not-prose mb-6 flex flex-wrap items-center gap-3">\n${metaItems.join('\n')}\n</div>`
  )

  if (includeHeroImage && data.heroImageUrl.trim()) {
    parts.push(
      `<figure class="mb-8">\n<img src="${escapeHtml(data.heroImageUrl.trim())}" alt="${escapeHtml(data.name)}" class="w-full rounded-xl object-cover shadow-md" />\n</figure>`
    )
  }

  if (data.summary.trim()) {
    parts.push(
      `<p class="mb-8 text-lg leading-relaxed text-slate-700">${escapeHtml(data.summary.trim())}</p>`
    )
  }

  if (data.goal.trim()) {
    parts.push(
      [
        `<div class="not-prose my-8 rounded-xl border border-slate-200 bg-slate-50 p-6">`,
        `<p class="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Our goal</p>`,
        toParagraphs(data.goal, 'text-base leading-relaxed text-slate-800'),
        `</div>`,
      ].join('\n')
    )
  }

  if (data.progress.trim()) {
    parts.push(heading('What we have done so far'))
    parts.push(toParagraphs(data.progress, 'mb-4 text-base leading-relaxed text-slate-700'))
  }

  if (data.beneficiaries.trim()) {
    parts.push(heading('Who this helps'))
    parts.push(
      toParagraphs(data.beneficiaries, 'mb-4 text-base leading-relaxed text-slate-700')
    )
  }

  const stats = data.stats.filter((stat) => stat.value.trim() || stat.label.trim())
  if (stats.length > 0) {
    const cards = stats
      .map((stat) =>
        [
          `<div class="rounded-xl border border-slate-200 bg-white p-5 text-center shadow-sm">`,
          `<p class="text-3xl font-bold tracking-tight text-slate-900">${escapeHtml(stat.value.trim())}</p>`,
          `<p class="mt-1 text-sm text-slate-600">${escapeHtml(stat.label.trim())}</p>`,
          `</div>`,
        ].join('\n')
      )
      .join('\n')

    parts.push(heading('Impact so far'))
    parts.push(
      `<div class="not-prose my-6 grid grid-cols-2 gap-4 md:grid-cols-4">\n${cards}\n</div>`
    )
  }

  return parts.join('\n')
}

/** Build the JSON stored in BlogPost.content. */
export function buildInitiativeContentJson(
  data: InitiativeData
): InitiativeContentJson {
  return { initiativeData: data, tiptap: null }
}

/** Excerpt shown in listings — the one-line summary, trimmed to a sane length. */
export function composeInitiativeExcerpt(data: InitiativeData): string {
  const summary = data.summary.trim()
  if (summary.length <= 300) return summary
  return `${summary.slice(0, 297).trimEnd()}...`
}
