/**
 * API Rate Limiter
 *
 * Two layers:
 *   1. an in-memory sliding window per server instance (cheap first refusal,
 *      and the fallback when the database is unreachable), then
 *   2. a durable session-window counter in the app's own Postgres
 *      (`usage_counters`, see ./store.ts) shared by every instance.
 *
 * Returns standardized 429 responses with Retry-After, resetAt and a human
 * "resets in …" text.
 *
 * If the durable layer errors (DB down, table missing) the limiter falls back
 * to the memory layer alone — unless the config says `failClosed`, which AI
 * and money paths set: those refuse with 503 instead.
 */

import { NextRequest, NextResponse } from 'next/server';
import { prismaCounterStore } from './store';
import { formatResetText, retryAfterSeconds } from './window';
import type { ResetRequest } from './reset-plan';
import {
  SlidingWindowLimiter,
  createConsumeRateLimit,
  resetLimitsWith,
  type RateLimitResult,
} from './limiter-core';

export { planReset } from './reset-plan';
export type { ResetRequest, CounterKind } from './reset-plan';
export type { RateLimitResult } from './limiter-core';

// In-memory layer (per instance) + the durable Postgres layer.
const limiter = new SlidingWindowLimiter();
const consume = createConsumeRateLimit(prismaCounterStore, limiter);

// ---------------------------------------------------------------------------
// IP extraction helper
// ---------------------------------------------------------------------------

export function getClientIp(request: NextRequest): string {
  return (
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown'
  );
}

// ---------------------------------------------------------------------------
// Preset configurations
// ---------------------------------------------------------------------------

export interface RateLimitConfig {
  /** Maximum number of requests allowed in the window */
  maxRequests: number;
  /** Time window in milliseconds */
  windowMs: number;
  /** Optional prefix for the rate limit key (defaults to route path) */
  keyPrefix?: string;
  /**
   * Refuse (503) when the durable counter can't be read or written, instead
   * of falling back to the per-instance memory layer. Set on AI and money
   * paths, where an unverifiable limit must not mean no limit.
   */
  failClosed?: boolean;
}

/** Common presets matching the task specification */
export const RATE_LIMIT_PRESETS = {
  /** Auth endpoints: 10 req / 60s */
  auth: { maxRequests: 10, windowMs: 60_000 } satisfies RateLimitConfig,
  /** Checkout: 5 req / 60s — a money path, so it fails closed */
  checkout: { maxRequests: 5, windowMs: 60_000, failClosed: true } satisfies RateLimitConfig,
  /** Cart operations: 30 req / 60s */
  cart: { maxRequests: 30, windowMs: 60_000 } satisfies RateLimitConfig,
  /** Email subscribe: 5 req / 60s */
  emailSubscribe: { maxRequests: 5, windowMs: 60_000 } satisfies RateLimitConfig,
  /** Forms / contact: 10 req / 60s */
  forms: { maxRequests: 10, windowMs: 60_000 } satisfies RateLimitConfig,
  /** Data export: 1 req / 24h */
  dataExport: { maxRequests: 1, windowMs: 86_400_000 } satisfies RateLimitConfig,
} as const;

// ---------------------------------------------------------------------------
// Main helper — call at the top of any route handler
// ---------------------------------------------------------------------------

/**
 * Check rate limit for the current request (keyed by route prefix + IP).
 *
 * Resolves to `null` if the request is within limits, or a `NextResponse`
 * (429, or 503 for a fail-closed config whose counter is unavailable).
 *
 * Usage:
 * ```ts
 * export async function POST(request: NextRequest) {
 *   const limited = await rateLimitCheck(request, RATE_LIMIT_PRESETS.auth);
 *   if (limited) return limited;
 *   // ... rest of handler
 * }
 * ```
 */
export async function rateLimitCheck(
  request: NextRequest,
  config: RateLimitConfig,
): Promise<NextResponse | null> {
  const ip = getClientIp(request);
  const prefix = config.keyPrefix ?? new URL(request.url).pathname;
  return rateLimitByKey(`${prefix}:${ip}`, config);
}

/**
 * Count `units` against `identity` in both layers and return the decision —
 * for callers that format their own refusal (e.g. the AI routes).
 */
export async function consumeRateLimit(
  identity: string,
  config: Pick<RateLimitConfig, 'maxRequests' | 'windowMs' | 'failClosed'>,
  units: number = 1,
): Promise<RateLimitResult> {
  return consume(identity, config, units);
}

/**
 * Same limiter, keyed by an arbitrary identity instead of the client IP —
 * e.g. an API key id, so one credential is capped across every IP it uses.
 * `units` charges several requests at once (an MCP batch of N costs N).
 */
export async function rateLimitByKey(
  identity: string,
  config: Pick<RateLimitConfig, 'maxRequests' | 'windowMs' | 'failClosed'>,
  units: number = 1,
): Promise<NextResponse | null> {
  const result = await consumeRateLimit(identity, config, units);
  if (result.allowed) return null;
  return limitResponse(result, config.maxRequests);
}

/** The standard refusal for a limiter decision (429, or 503 if degraded). */
export function limitResponse(result: RateLimitResult, limit: number): NextResponse {
  const now = Date.now();
  const retryAfterSec = retryAfterSeconds(result.resetAt, now);
  const resetAt = new Date(result.resetAt).toISOString();
  const resetText = formatResetText(result.resetAt, now);
  const unavailable = result.degraded;
  return NextResponse.json(
    {
      error: unavailable
        ? 'Usage limits could not be verified right now, so the request was refused. Please try again shortly.'
        : `Too many requests. The limit resets ${resetText}.`,
      retryAfter: retryAfterSec,
      resetAt,
      resetText,
    },
    {
      status: unavailable ? 503 : 429,
      headers: {
        'Retry-After': String(retryAfterSec),
        'X-RateLimit-Limit': String(limit),
        'X-RateLimit-Remaining': '0',
        'X-RateLimit-Reset': String(Math.ceil(result.resetAt / 1000)),
      },
    },
  );
}

// ---------------------------------------------------------------------------
// Reset (admin)
// ---------------------------------------------------------------------------

/**
 * Delete the durable counter rows `req` selects (see planReset) and clear
 * matching keys from THIS instance's memory layer. Other instances' memory
 * windows are short (minutes) and expire on their own.
 */
export async function resetLimits(
  req: ResetRequest,
): Promise<{ ok: true; deleted: number; description: string } | { ok: false; error: string }> {
  return resetLimitsWith(prismaCounterStore, limiter, req);
}
