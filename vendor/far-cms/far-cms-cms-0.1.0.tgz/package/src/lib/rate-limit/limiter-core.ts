/**
 * Limiter core — the two-layer decision (per-instance memory window + durable
 * shared counter) with the store injected. No Next.js or Prisma imports, so
 * the AI cost test kit runs the exact production logic against an in-memory
 * store. ./index.ts binds it to the Postgres store and one module-level
 * memory layer.
 */

import type { CounterStore } from './counter-store'
import { combineDecisions, type WindowDecision } from './window'
import { planMatches, planReset, type ResetRequest } from './reset-plan'

// ---------------------------------------------------------------------------
// In-memory layer (per instance)
// ---------------------------------------------------------------------------

export class SlidingWindowLimiter {
  private windows: Map<string, number[]> = new Map()
  private cleanupInterval: ReturnType<typeof setInterval> | null = null

  constructor(options: { cleanup?: boolean } = {}) {
    if (options.cleanup !== false) {
      // Periodically prune stale keys to prevent memory leaks
      this.cleanupInterval = setInterval(() => this.cleanup(), 60_000)
    }
  }

  check(key: string, windowMs: number, maxRequests: number, units: number = 1): WindowDecision {
    const now = Date.now()
    const windowStart = now - windowMs

    let timestamps = this.windows.get(key) ?? []
    timestamps = timestamps.filter((t) => t > windowStart)

    if (timestamps.length + units > maxRequests) {
      const oldest = timestamps[0] ?? now
      this.windows.set(key, timestamps)
      return { allowed: false, remaining: 0, resetAt: oldest + windowMs }
    }

    for (let i = 0; i < units; i++) timestamps.push(now)
    this.windows.set(key, timestamps)
    return {
      allowed: true,
      remaining: maxRequests - timestamps.length,
      resetAt: timestamps[0] + windowMs,
    }
  }

  /** Drop every key the predicate selects (used by resetLimits). */
  clear(predicate: (key: string) => boolean): number {
    let n = 0
    for (const key of [...this.windows.keys()]) {
      if (predicate(key)) {
        this.windows.delete(key)
        n++
      }
    }
    return n
  }

  private cleanup() {
    const now = Date.now()
    // Remove keys where all timestamps are older than 24 hours
    const cutoff = now - 86_400_000
    for (const [key, timestamps] of this.windows) {
      const recent = timestamps.filter((t) => t > cutoff)
      if (recent.length === 0) {
        this.windows.delete(key)
      } else {
        this.windows.set(key, recent)
      }
    }
  }
}

export interface LimitConfig {
  maxRequests: number
  windowMs: number
  failClosed?: boolean
}

export type RateLimitResult = WindowDecision & {
  /** The durable layer was unavailable for this decision. */
  degraded: boolean
}

export type ConsumeRateLimit = (identity: string, config: LimitConfig, units?: number) => Promise<RateLimitResult>

/** Bind the two-layer limiter to a store and a memory layer. */
export function createConsumeRateLimit(store: CounterStore, limiter: SlidingWindowLimiter): ConsumeRateLimit {
  return async (identity, config, units = 1) => {
    const now = Date.now()
    const memory = limiter.check(`rl:${identity}`, config.windowMs, config.maxRequests, units)
    if (!memory.allowed) return { ...memory, degraded: false }

    let durable: WindowDecision | 'unavailable'
    try {
      const state = await store.bump('requests', identity, config.windowMs, units, now)
      durable = {
        allowed: state.amount <= config.maxRequests,
        remaining: Math.max(0, config.maxRequests - state.amount),
        resetAt: state.windowStart + state.windowMs,
      }
    } catch (error) {
      console.error(
        `[rate-limit] durable counter unavailable for '${identity}' — ${
          config.failClosed ? 'refusing (fail closed)' : 'using the in-memory layer only'
        }:`,
        error instanceof Error ? error.message : error,
      )
      durable = 'unavailable'
    }
    return combineDecisions(memory, durable, config.failClosed ?? false, now)
  }
}

/**
 * Delete the durable counter rows `req` selects (see planReset) and clear
 * matching keys from this memory layer.
 */
export async function resetLimitsWith(
  store: CounterStore,
  limiter: SlidingWindowLimiter,
  req: ResetRequest,
): Promise<{ ok: true; deleted: number; description: string } | { ok: false; error: string }> {
  const planned = planReset(req)
  if (!planned.ok) return planned
  const { plan } = planned
  const deleted = await store.deleteWhere(plan)
  limiter.clear((key) => key.startsWith('rl:') && planMatches(plan, 'requests', key.slice(3)))
  return { ok: true, deleted, description: plan.description }
}
