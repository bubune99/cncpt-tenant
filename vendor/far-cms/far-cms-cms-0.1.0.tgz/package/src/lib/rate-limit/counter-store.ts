/**
 * The counter-store interface the limiter and AI spend meter run against.
 * Production binds it to Postgres (`prismaCounterStore` in ./store.ts); the
 * AI cost test kit binds it to an in-memory store
 * (src/lib/ai/testing/memory-counter-store.ts). Type-only — no I/O here.
 *
 * Every method THROWS when the store is unavailable; callers decide whether
 * that fails open or closed.
 */

import type { CounterState } from './window'
import type { ResetPlan } from './reset-plan'

export type ReserveResult =
  | { ok: true; state: CounterState }
  /** Refused: the add would have crossed the limit. Nothing was changed. */
  | { ok: false; amount: number; resetAt: number }

export interface CounterStore {
  /** Atomically add `add` units; returns the row after the add. */
  bump(kind: string, identity: string, windowMs: number, add: number, nowMs?: number): Promise<CounterState>
  /**
   * Atomically add `add` units ONLY if the window's amount afterwards stays
   * within `limit` — one guarded statement, never read-then-write, so
   * concurrent reservations can't jointly cross the limit. Mirrors
   * `reserveWindow` in ./window.ts.
   */
  reserve(
    kind: string,
    identity: string,
    windowMs: number,
    add: number,
    limit: number,
    nowMs?: number,
  ): Promise<ReserveResult>
  /**
   * Atomically give back up to `amount` units to the window that started at
   * `windowStart` (never below 0). Returns false when that window is gone
   * (rolled over, or the row was reset). Mirrors `releaseWindow`.
   */
  release(kind: string, identity: string, amount: number, windowStart: number): Promise<boolean>
  /** Read without changing. Missing/expired reads as amount 0. */
  read(kind: string, identity: string, nowMs?: number): Promise<{ amount: number; resetAt: number }>
  /** Delete the rows a reset plan selects; returns how many. */
  deleteWhere(plan: ResetPlan): Promise<number>
}
