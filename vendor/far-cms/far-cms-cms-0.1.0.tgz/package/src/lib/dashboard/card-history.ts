/**
 * Undo for Customize on the Dashboard: the layouts before each change, newest last. null is the
 * default layout. Pure; checked by card-history.assert.ts.
 */
import type { CardLayout } from './cards'

export const UNDO_LIMIT = 20
export type CardHistory = ReadonlyArray<CardLayout | null>

/** The history with `before` (the layout just replaced) added; only the last UNDO_LIMIT are kept. */
export function remember(history: CardHistory, before: CardLayout | null): CardHistory {
  return [...history, before].slice(-UNDO_LIMIT)
}

/** The layout to restore and the history without it; null when there is nothing to undo. */
export function undoStep(history: CardHistory): { restore: CardLayout | null; history: CardHistory } | null {
  if (!history.length) return null
  return { restore: history[history.length - 1], history: history.slice(0, -1) }
}
