/**
 * The Dashboard's Initiatives card: counts by stage and the latest change, worked out with the
 * Initiatives screen's own rule (record-list tabCounts) so the two never disagree.
 * Pure; checked by initiatives-glance.assert.ts.
 */
import { tabCounts, type RecordListRow } from '../ade-bindings/record-list'

export interface InitiativesGlance {
  active: number
  ongoing: number
  completed: number
  total: number
  latest: RecordListRow | null
}

export function initiativesGlance(rows: readonly RecordListRow[]): InitiativesGlance {
  const t = tabCounts(rows)
  const listed = rows.filter((r) => r.status !== 'ARCHIVED')
  const latest = listed.slice().sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0] ?? null
  return { active: t.active, ongoing: t.ongoing, completed: t.completed, total: t.all, latest }
}
