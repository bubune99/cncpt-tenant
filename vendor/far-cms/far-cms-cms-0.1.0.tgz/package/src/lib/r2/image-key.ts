/**
 * The storage key for an uploaded image, made by the server: `<folder>/<random id>.<ext>`. The folder is a plain
 * word (anything else becomes "uploads") and the extension comes from the checked image type, never from the
 * uploader's filename. null for a type that is not an image we accept. Pure; check: image-key.assert.ts.
 */
const EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg' }

export function imageObjectKey(category: string, contentType: string, id: string): string | null {
  const ext = EXT[contentType]
  if (!ext) return null
  const folder = /^[a-z0-9][a-z0-9-]{0,39}$/i.test(category) ? category.toLowerCase() : 'uploads'
  return `${folder}/${id}.${ext}`
}
