/**
 * Cloudflare R2 Client Configuration
 *
 * R2 is S3-compatible, so we use the AWS SDK with R2's endpoint.
 *
 * IMPORTANT: This module historically read R2 env vars directly. It now
 * delegates to `getStorageSettings()` so the storage provider is the single
 * source of truth (DB-stored settings, with env-var fallbacks). This avoids
 * split-brain bucket/credential resolution between this module and
 * `src/lib/media/upload.ts`.
 *
 * Public exports preserved for backward compatibility:
 *   - r2Client (S3Client instance, lazy)
 *   - R2_CONFIG (Promise-based; legacy callers awaited synchronously now read async)
 *   - listImages, uploadImage, deleteImage, getCategories
 *   - R2Image type
 *
 * Transitional behavior:
 *   - Reads `R2_BUCKET ?? R2_BUCKET_NAME` so we can deprecate the legacy
 *     `R2_BUCKET_NAME` env var without breaking running deploys.
 *   - Hardcoded "cms-images" default bucket REMOVED — calls now fail loud
 *     when no bucket is configured.
 */

import { randomUUID } from "node:crypto";
import { imageObjectKey } from "./image-key";
import {
  S3Client,
  ListObjectsV2Command,
  PutObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { getStorageSettings } from "../settings";

export interface R2Image {
  key: string;
  url: string;
  name: string;
  category: string;
  size?: number;
  lastModified?: Date;
}

interface ResolvedR2Config {
  bucketName: string;
  publicUrl: string;
  endpoint: string;
  accessKeyId: string;
  secretAccessKey: string;
  isConfigured: boolean;
}

/**
 * Resolve R2 config from getStorageSettings() with transitional env-var
 * support. Returns isConfigured=false (and empty strings) when required
 * fields are missing — callers must check before issuing requests.
 */
async function resolveR2Config(): Promise<ResolvedR2Config> {
  const settings = await getStorageSettings();

  // Transitional bucket fallback: prefer canonical R2_BUCKET, fall back to
  // legacy R2_BUCKET_NAME. getStorageSettings() already reads R2_BUCKET via
  // S3_BUCKET/R2_BUCKET, so settings.bucket should be populated; this picks
  // up legacy R2_BUCKET_NAME if neither was set.
  const bucketName =
    settings.bucket ||
    process.env.R2_BUCKET?.trim() ||
    process.env.R2_BUCKET_NAME?.trim() ||
    "";

  // Endpoint: settings already builds R2 endpoint from R2_ACCOUNT_ID if needed.
  const endpoint = settings.endpoint || "";
  const accessKeyId = settings.accessKeyId || "";
  const secretAccessKey = settings.secretAccessKey || "";
  const publicUrl = settings.publicUrl || "";

  const isConfigured = Boolean(
    bucketName && endpoint && accessKeyId && secretAccessKey
  );

  return {
    bucketName,
    publicUrl,
    endpoint,
    accessKeyId,
    secretAccessKey,
    isConfigured,
  };
}

/**
 * Build an S3Client for R2 using the resolved config. Throws if not
 * configured — callers using r2Client directly must guard with R2_CONFIG.
 */
async function buildR2Client(): Promise<S3Client> {
  const cfg = await resolveR2Config();
  if (!cfg.isConfigured) {
    throw new Error(
      "R2 is not configured. Set bucket, endpoint, accessKeyId, and " +
        "secretAccessKey in Storage settings (or R2_BUCKET / R2_ACCOUNT_ID / " +
        "R2_ACCESS_KEY_ID / R2_SECRET_ACCESS_KEY env vars)."
    );
  }
  return new S3Client({
    region: "auto",
    endpoint: cfg.endpoint,
    credentials: {
      accessKeyId: cfg.accessKeyId,
      secretAccessKey: cfg.secretAccessKey,
    },
    forcePathStyle: true, // R2 requires path style
  });
}

/**
 * Lazy R2 client. Backward-compatible export — exposes a `.send()` that
 * resolves the underlying S3Client on first use. Older code that destructured
 * methods off `r2Client` will still receive a working object.
 */
export const r2Client = {
  send: async (command: any) => {
    const client = await buildR2Client();
    return client.send(command);
  },
};

/**
 * Resolved config snapshot. Promise-based because resolution requires a DB
 * read via getStorageSettings(). Callers that previously did
 * `R2_CONFIG.isConfigured` should now `await R2_CONFIG` first.
 *
 * Existing call sites in this codebase (api/images/*) check
 * `R2_CONFIG.isConfigured` synchronously. To preserve that contract we expose
 * a Proxy that lazily awaits — but Promises are simpler and correct, so this
 * is exposed as a Promise. Callers using sync .isConfigured must be updated.
 */
export const R2_CONFIG = {
  /** Async — awaitable resolved config. */
  resolve: resolveR2Config,
  /**
   * Synchronous accessors that throw if not yet primed. Reserved for legacy
   * callers; prefer `await R2_CONFIG.resolve()`. We deliberately do NOT cache
   * because storage settings can change at runtime (admin UI).
   */
  get bucketName(): Promise<string> {
    return resolveR2Config().then((c) => c.bucketName);
  },
  get publicUrl(): Promise<string> {
    return resolveR2Config().then((c) => c.publicUrl);
  },
  get isConfigured(): Promise<boolean> {
    return resolveR2Config().then((c) => c.isConfigured);
  },
};

/**
 * List media files from R2 bucket (images and videos)
 * Files are organized by prefix/folder (e.g., "heroes/", "features/", "team/")
 */
export async function listImages(prefix?: string): Promise<R2Image[]> {
  const cfg = await resolveR2Config();
  if (!cfg.isConfigured) {
    console.warn(
      "R2 is not configured. Provide bucket/endpoint/credentials via Storage settings or R2 env vars."
    );
    return [];
  }

  try {
    const client = await buildR2Client();
    const command = new ListObjectsV2Command({
      Bucket: cfg.bucketName,
      Prefix: prefix || "",
      MaxKeys: 100,
    });

    const response = await client.send(command);
    const images: R2Image[] = [];

    for (const obj of response.Contents || []) {
      if (!obj.Key) continue;

      // Skip if not a media file (image or video)
      const isMedia = /\.(jpg|jpeg|png|gif|webp|svg|mp4|webm|ogg|mov|avi|mkv)$/i.test(
        obj.Key
      );
      if (!isMedia) continue;

      // Extract category from path (e.g., "heroes/image.jpg" -> "heroes")
      const parts = obj.Key.split("/");
      const category = parts.length > 1 ? parts[0] : "uncategorized";
      const name = parts[parts.length - 1];

      images.push({
        key: obj.Key,
        url: `${cfg.publicUrl}/${obj.Key}`,
        name,
        category,
        size: obj.Size,
        lastModified: obj.LastModified,
      });
    }

    return images;
  } catch (error) {
    console.error("Error listing R2 images:", error);
    return [];
  }
}

/**
 * Upload an image to R2
 */
export async function uploadImage(
  file: Buffer,
  filename: string,
  category: string = "uploads",
  contentType: string = "image/jpeg"
): Promise<R2Image | null> {
  const cfg = await resolveR2Config();
  if (!cfg.isConfigured) {
    console.warn("R2 is not configured");
    return null;
  }

  try {
    const client = await buildR2Client();
    // Made by the server: a plain folder word and a random id (lib/r2/image-key).
    const key = imageObjectKey(category, contentType, randomUUID());
    if (!key) return null;

    const command = new PutObjectCommand({
      Bucket: cfg.bucketName,
      Key: key,
      Body: file,
      ContentType: contentType,
    });

    await client.send(command);

    return {
      key,
      url: `${cfg.publicUrl}/${key}`,
      name: filename,
      category,
    };
  } catch (error) {
    console.error("Error uploading to R2:", error);
    return null;
  }
}

/**
 * Delete an image from R2
 */
export async function deleteImage(key: string): Promise<boolean> {
  const cfg = await resolveR2Config();
  if (!cfg.isConfigured) {
    return false;
  }

  try {
    const client = await buildR2Client();
    const command = new DeleteObjectCommand({
      Bucket: cfg.bucketName,
      Key: key,
    });

    await client.send(command);
    return true;
  } catch (error) {
    console.error("Error deleting from R2:", error);
    return false;
  }
}

/**
 * Get image categories (top-level folders)
 */
export async function getCategories(): Promise<string[]> {
  const cfg = await resolveR2Config();
  if (!cfg.isConfigured) {
    return [];
  }

  try {
    const client = await buildR2Client();
    const command = new ListObjectsV2Command({
      Bucket: cfg.bucketName,
      Delimiter: "/",
    });

    const response = await client.send(command);
    const categories: string[] = [];

    for (const prefix of response.CommonPrefixes || []) {
      if (prefix.Prefix) {
        categories.push(prefix.Prefix.replace("/", ""));
      }
    }

    return categories;
  } catch (error) {
    console.error("Error getting R2 categories:", error);
    return [];
  }
}
