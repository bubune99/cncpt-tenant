/**
 * v0 Import Agent
 *
 * Uses Claude (via the Vercel AI Gateway, same stack as every other AI
 * surface) to intelligently convert v0.dev components into Block templates.
 *
 * The output is Block[] format with native HTML tags + Tailwind classes.
 *
 * Implementation note: this used to hand-roll a tool loop over a dynamically
 * imported `@anthropic-ai/sdk` — which was never installed, so every v0
 * import path threw at runtime. It now runs on the AI SDK's tool loop
 * (`generateText` + `stopWhen`) through the gateway, sharing the app's model
 * routing and observability.
 */

import {
  generateText,
  jsonSchema,
  stepCountIs,
  tool,
  type ToolSet,
} from "ai"
import { getLanguageModel } from "../ai/providers"
import { stackServerApp } from "../stack"
import { prisma } from "../db"
import { getAiSettings } from "../settings"
import {
  admitAiRequest,
  admissionMessage,
  chargeCountedAction,
  getSpendConfig,
  recordAiTokens,
} from "../ai/spend"
import { tokensFromUsage } from "../ai/spend-policy"
import { MODEL_ROUTES } from "../ai/models"
import { V0_IMPORT_SYSTEM_PROMPT, V0_IMPORT_EXAMPLES } from "./prompts/system"
import { fetchV0Tool } from "./tools/fetch-v0"
import { listPrimitivesTool, getPrimitiveTool } from "./tools/primitives"
import { uploadAssetTool, uploadMultipleAssetsTool } from "./tools/upload-asset"
import { saveTemplateTool, updateTemplateTool } from "./tools/save-template"
import { validateBlocksTool } from "./tools/validate"
import type {
  V0ImportRequest,
  V0ImportResult,
  BlockTemplate,
  AgentToolResult,
} from "./types"

/** Legacy tool shape shared by all files under ./tools */
interface LegacyToolDef {
  name: string
  description: string
  inputSchema: Record<string, unknown>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  execute: (input: any) => Promise<AgentToolResult>
}

const LEGACY_TOOLS: LegacyToolDef[] = [
  fetchV0Tool as LegacyToolDef,
  listPrimitivesTool as LegacyToolDef,
  getPrimitiveTool as LegacyToolDef,
  uploadAssetTool as LegacyToolDef,
  uploadMultipleAssetsTool as LegacyToolDef,
  saveTemplateTool as LegacyToolDef,
  updateTemplateTool as LegacyToolDef,
  validateBlocksTool as LegacyToolDef,
]

export interface V0ImportAgentConfig {
  /** Gateway model ID override (defaults to the central routing table). */
  model?: string
  maxIterations?: number
  verbose?: boolean
  /** @deprecated unused — auth goes through the Vercel AI Gateway now. */
  apiKey?: string
  /**
   * Local user id the run is metered against. When omitted, the signed-in
   * user of the current request is used; with neither, the run is refused.
   */
  userId?: string
}

/** Token ceiling for one import run (all tool-loop steps combined). */
const V0_RUN_TOKEN_CAP = 200_000
/** Per-user token budget fallback (same default as chat / Kofi). */
const DEFAULT_USER_TOKEN_BUDGET = 500_000

async function resolveCurrentUserId(): Promise<string | null> {
  try {
    const user = await stackServerApp.getUser()
    if (!user) return null
    const dbUser = await prisma.user.findFirst({
      where: { stackAuthId: user.id },
      select: { id: true },
    })
    return dbUser?.id ?? null
  } catch {
    return null
  }
}

interface RunState {
  finalResult: V0ImportResult | null
}

export class V0ImportAgent {
  private model: string
  private maxIterations: number
  private verbose: boolean
  private userId: string | undefined

  constructor(config: V0ImportAgentConfig = {}) {
    this.model = config.model || MODEL_ROUTES.v0Import
    this.maxIterations = config.maxIterations || 20
    this.verbose = config.verbose || false
    this.userId = config.userId
  }

  /**
   * Build the AI SDK tool set from the legacy tool definitions. `overrides`
   * lets a run replace a tool's executor (used to stub fetch_v0_component for
   * code-based imports); `state` captures the save_template result.
   */
  private buildTools(
    state: RunState,
    overrides?: Record<string, (input: unknown) => Promise<AgentToolResult>>
  ): ToolSet {
    const tools: ToolSet = {}

    for (const def of LEGACY_TOOLS) {
      const executor = overrides?.[def.name] ?? def.execute
      tools[def.name] = tool({
        description: def.description,
        inputSchema: jsonSchema(def.inputSchema),
        execute: async (input: unknown) => {
          if (this.verbose) {
            console.log(`[V0Agent] Tool call: ${def.name}`)
          }
          try {
            const result = await executor(input)
            if (def.name === saveTemplateTool.name && result.success) {
              state.finalResult = {
                success: true,
                template: result.data as unknown as BlockTemplate,
              }
            }
            return result
          } catch (error) {
            return {
              success: false,
              error: (error as Error).message,
            }
          }
        },
      })
    }

    return tools
  }

  private async run(
    userPrompt: string,
    overrides?: Record<string, (input: unknown) => Promise<AgentToolResult>>
  ): Promise<V0ImportResult> {
    const state: RunState = { finalResult: null }
    const tools = this.buildTools(state, overrides)

    // --- Spend gates (all fail closed) ---
    const userId = this.userId ?? (await resolveCurrentUserId())
    if (!userId) {
      return { success: false, errors: ["Sign in required: v0 imports are metered per user."] }
    }
    const cfg = getSpendConfig()
    const userBudget = await getAiSettings()
      .then((settings) => settings.dailyTokenBudget ?? DEFAULT_USER_TOKEN_BUDGET)
      .catch(() => DEFAULT_USER_TOKEN_BUDGET)
    const admission = await admitAiRequest(userId, userBudget)
    if (!admission.ok) {
      return { success: false, errors: [admissionMessage(admission)] }
    }
    const run = await chargeCountedAction("v0-runs", userId, cfg.v0RunsPerUser, "v0 import")
    if (!run.ok) {
      return { success: false, errors: [run.message] }
    }
    const tokenCap = Math.max(1, Math.min(V0_RUN_TOKEN_CAP, admission.remainingTokens))
    let budgetStop = false

    try {
      const result = await generateText({
        model: getLanguageModel(this.model),
        system: V0_IMPORT_SYSTEM_PROMPT + "\n\n" + V0_IMPORT_EXAMPLES,
        prompt: userPrompt,
        tools,
        stopWhen: [
          stepCountIs(this.maxIterations),
          // Token budget for the whole tool loop (checked between steps).
          ({ steps }) => {
            const spent = steps.reduce((sum, step) => sum + tokensFromUsage(step.usage), 0)
            if (spent >= tokenCap) budgetStop = true
            return budgetStop
          },
        ],
        // Meter per step, so a run that throws midway is still counted.
        onStepFinish: async (step) => {
          await recordAiTokens(userId, tokensFromUsage(step.usage), "v0-import")
        },
        maxOutputTokens: 8192,
        maxRetries: 1,
      })

      if (this.verbose) {
        console.log(
          `[V0Agent] Finished after ${result.steps.length} step(s), reason: ${result.finishReason}`
        )
      }

      if (state.finalResult) {
        return state.finalResult
      }

      if (result.finishReason === "stop") {
        return {
          success: false,
          errors: [result.text || "Agent finished without creating a template"],
        }
      }

      if (budgetStop) {
        return {
          success: false,
          errors: [
            `Import stopped: it reached its ${tokenCap.toLocaleString()}-token budget after ${result.steps.length} step(s) without saving a template — simplify the component and try again`,
          ],
        }
      }

      return {
        success: false,
        errors: [
          `Import stopped (${result.finishReason || "unknown"}) after ${result.steps.length} step(s) without completing — try again or simplify the component`,
        ],
      }
    } catch (error) {
      return {
        success: false,
        errors: [(error as Error).message],
      }
    }
  }

  /**
   * Import a v0 component and convert it to a Block template
   */
  async importComponent(request: V0ImportRequest): Promise<V0ImportResult> {
    return this.run(this.buildUserPrompt(request))
  }

  /**
   * Import from raw code instead of URL
   */
  async importFromCode(
    code: string,
    options: Omit<V0ImportRequest, "url"> = {}
  ): Promise<V0ImportResult> {
    return this.run(this.buildCodePrompt(code, options), {
      // Code-based import: the fetch tool just returns the provided code
      [fetchV0Tool.name]: async () => ({
        success: true,
        data: { code, name: options.name },
      }),
    })
  }

  /**
   * Build the user prompt for the import request
   */
  private buildUserPrompt(request: V0ImportRequest): string {
    let prompt = `Import this v0.dev component and convert it to Block format.\n\n`

    prompt += `**v0 URL:** ${request.url}\n\n`

    if (request.name) {
      prompt += `**Preferred Name:** ${request.name}\n`
    }

    if (request.category) {
      prompt += `**Category:** ${request.category}\n`
    }

    if (request.description) {
      prompt += `**Description:** ${request.description}\n`
    }

    prompt += `\n## Instructions\n`
    prompt += `1. First, fetch the component code using the fetch_v0_component tool\n`
    prompt += `2. List the block schema to understand valid tags with list_block_schema\n`
    prompt += `3. Analyze the component and plan the conversion\n`
    prompt += `4. Upload any images/assets found\n`
    prompt += `5. Build the Block[] array mapping JSX to native HTML tags + Tailwind classes\n`
    prompt += `6. Validate the result with validate_blocks\n`
    prompt += `7. Save the template with save_template\n`
    prompt += `\n## CRITICAL: Output Format\n`
    prompt += `You MUST output Block format with native HTML tags (div, section, h1, p, button, etc.)\n`
    prompt += `Preserve Tailwind classes EXACTLY as they appear in the original v0 code.\n`

    return prompt
  }

  private buildCodePrompt(
    code: string,
    options: Omit<V0ImportRequest, "url">
  ): string {
    let prompt = `Convert this React component code to Block format.\n\n`

    prompt += `**Component Code:**\n\`\`\`tsx\n${code}\n\`\`\`\n\n`

    if (options.name) {
      prompt += `**Preferred Name:** ${options.name}\n`
    }

    if (options.category) {
      prompt += `**Category:** ${options.category}\n`
    }

    if (options.description) {
      prompt += `**Description:** ${options.description}\n`
    }

    prompt += `\n## Instructions\n`
    prompt += `1. List the block schema to understand valid tags with list_block_schema\n`
    prompt += `2. Analyze the component structure\n`
    prompt += `3. Upload any images/assets found in the code\n`
    prompt += `4. Build the Block[] array mapping JSX to native HTML tags + Tailwind classes\n`
    prompt += `5. Validate the result with validate_blocks\n`
    prompt += `6. Save the template with save_template\n`
    prompt += `\n## CRITICAL: Output Format\n`
    prompt += `You MUST output Block format with native HTML tags (div, section, h1, p, button, etc.)\n`
    prompt += `Preserve Tailwind classes EXACTLY as they appear in the original code.\n`

    return prompt
  }
}

// Export singleton instance
let defaultAgent: V0ImportAgent | null = null

export function getV0ImportAgent(config?: V0ImportAgentConfig): V0ImportAgent {
  if (!defaultAgent || config) {
    defaultAgent = new V0ImportAgent(config)
  }
  return defaultAgent
}

export default V0ImportAgent
