/**
 * v0 Import Agent
 *
 * Exports for the v0-to-Block conversion agent.
 */

export { V0ImportAgent, getV0ImportAgent } from "./agent"
export type { V0ImportAgentConfig } from "./agent"

export * from "./types"

// Export tools for direct use if needed
export { fetchV0Tool } from "./tools/fetch-v0"
export { listPrimitivesTool, getPrimitiveTool } from "./tools/primitives"
export { uploadAssetTool, uploadMultipleAssetsTool } from "./tools/upload-asset"
export { saveTemplateTool, updateTemplateTool } from "./tools/save-template"
export { validateBlocksTool, validateBlocks } from "./tools/validate"

// Export prompts for customization
export { V0_IMPORT_SYSTEM_PROMPT, V0_IMPORT_EXAMPLES } from "./prompts/system"

// Re-export Block types for convenience
export type {
  Block,
  BlockTag,
  BlockAnimation,
  BlockBackground,
  PageDocument,
} from "../block-editor/types"
