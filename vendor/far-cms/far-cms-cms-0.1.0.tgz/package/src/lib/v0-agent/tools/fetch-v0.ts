// Moved to @far-cms/core (far-cms packages/core/src/lib/v0-agent/tools/fetch-v0.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/v0-agent/tools/fetch-v0'
export { default } from '@far-cms/core/lib/v0-agent/tools/fetch-v0'
