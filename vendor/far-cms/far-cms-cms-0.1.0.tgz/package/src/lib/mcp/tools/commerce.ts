/**
 * MCP tools for products and orders, registered on the external MCP server (src/app/mcp/route.ts).
 * Moved verbatim from the route on 2026-11-22 to bring it under 800 lines; behavior, permissions and texts unchanged.
 * Every tool still checks the key user's RBAC permission (requireMcpPermission) before reading.
 */
import { z } from "zod"
import { prisma } from "../../db"
import { requireMcpPermission } from "../permissions"
import { mcpResponse, mcpError, truncate, normalizePagination } from "../utils"
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js"

export function registerCommerceTools(server: Pick<McpServer, "tool">): void {
    // ==========================================
    // Products
    // ==========================================
    server.tool(
      "list_products",
      "List products in the CMS. Supports pagination and filtering.",
      {
        status: z.enum(["DRAFT", "ACTIVE", "ARCHIVED"]).optional().describe("Filter by status"),
        limit: z.number().optional().describe("Max results (default 20, max 100)"),
        offset: z.number().optional().describe("Skip N results"),
        brief: z.boolean().optional().describe("Return minimal fields only")
      },
      async ({ status, limit, offset, brief }) => {
        try {
          await requireMcpPermission("products.view")
          const { limit: l, offset: o } = normalizePagination(limit, offset)

          const products = await prisma.product.findMany({
            where: status ? { status } : undefined,
            take: l,
            skip: o,
            orderBy: { createdAt: "desc" },
            include: brief ? undefined : {
              variants: { take: 5 },
              _count: { select: { variants: true } }
            }
          })

          const count = await prisma.product.count({
            where: status ? { status } : undefined
          })

          const data = brief
            ? products.map(p => ({
                id: p.id,
                title: p.title,
                status: p.status,
                price: p.basePrice
              }))
            : products.map(p => ({
                ...p,
                description: truncate(p.description, 200)
              }))

          return mcpResponse({ products: data, total: count, limit: l, offset: o })
        } catch (error: unknown) {
          return mcpError(error instanceof Error ? error.message : "Unknown error")
        }
      }
    )

    server.tool(
      "get_product",
      "Get a single product by ID with full details",
      {
        id: z.string().describe("Product ID")
      },
      async ({ id }) => {
        try {
          await requireMcpPermission("products.view")
          const product = await prisma.product.findUnique({
            where: { id },
            include: {
              variants: true,
              categories: true,
              images: true,
              reviews: { take: 5, orderBy: { createdAt: "desc" } }
            }
          })

          if (!product) return mcpError("Product not found")

          return mcpResponse({ product })
        } catch (error: unknown) {
          return mcpError(error instanceof Error ? error.message : "Unknown error")
        }
      }
    )

    // ==========================================
    // Orders
    // ==========================================
    server.tool(
      "list_orders",
      "List orders with pagination and status filtering",
      {
        status: z.enum(["PENDING", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED", "REFUNDED"]).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
        brief: z.boolean().optional()
      },
      async ({ status, limit, offset, brief }) => {
        try {
          await requireMcpPermission("orders.view")
          const { limit: l, offset: o } = normalizePagination(limit, offset)

          const orders = await prisma.order.findMany({
            where: status ? { status } : undefined,
            take: l,
            skip: o,
            orderBy: { createdAt: "desc" },
            include: brief ? undefined : {
              items: { take: 3 },
              customer: { select: { email: true, firstName: true, lastName: true } }
            }
          })

          const count = await prisma.order.count({
            where: status ? { status } : undefined
          })

          const data = brief
            ? orders.map(o => ({
                id: o.id,
                orderNumber: o.orderNumber,
                status: o.status,
                total: o.total
              }))
            : orders

          return mcpResponse({ orders: data, total: count, limit: l, offset: o })
        } catch (error: unknown) {
          return mcpError(error instanceof Error ? error.message : "Unknown error")
        }
      }
    )

    server.tool(
      "get_order",
      "Get a single order by ID or order number",
      {
        id: z.string().optional().describe("Order ID"),
        orderNumber: z.string().optional().describe("Order number (alternative)")
      },
      async ({ id, orderNumber }) => {
        try {
          await requireMcpPermission("orders.view")
          if (!id && !orderNumber) {
            return mcpError("Provide either id or orderNumber")
          }

          const order = await prisma.order.findFirst({
            where: id ? { id } : { orderNumber },
            include: {
              items: { include: { variant: true } },
              customer: true,
              shippingAddress: true,
              billingAddress: true,
              shipments: true
            }
          })

          if (!order) return mcpError("Order not found")

          return mcpResponse({ order })
        } catch (error: unknown) {
          return mcpError(error instanceof Error ? error.message : "Unknown error")
        }
      }
    )
}
