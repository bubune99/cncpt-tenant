/**
 * MCP Media Tools
 *
 * search_media          — search the media library (name/alt, type, folder, tags)
 * upload_media_from_url — upload-by-reference: the server fetches a remote
 *                         image (SSRF-guarded) and stores it through the
 *                         existing media pipeline (R2/S3 via presigned PUT).
 *
 * AI clients can't emit raw image bytes, so URL is the practical upload path.
 */

import { z } from "zod"
import { lookup as dnsLookup } from "node:dns/promises"
import { listMedia } from "../../media"
import { generatePresignedUrl, processUpload } from "../../media/upload"
import { logAuditEvent, getUserPermissions, checkPermission } from "../../permissions"
import { getMcpUserId, hasMcpScope } from "../context"
import { requireMcpPermission } from "../permissions"
import { mcpResponse, mcpError } from "../utils"
import { toolRegistrar, type McpServerLike } from "../registry-adapter"
import { UPLOAD_KEY_RE } from "../../media/upload-key"

const MAX_UPLOAD_BYTES = 10 * 1024 * 1024 // 10MB
const MAX_REDIRECTS = 3
const FETCH_TIMEOUT_MS = 15_000
const MAX_PREVIEWS = 4
const MAX_PREVIEW_BYTES = 300 * 1024

// ---------------------------------------------------------------------------
// SSRF guard
// ---------------------------------------------------------------------------

function isPrivateIp(ip: string): boolean {
  if (ip.includes(":")) {
    const lower = ip.toLowerCase()
    return (
      lower === "::1" ||
      lower.startsWith("fc") ||
      lower.startsWith("fd") ||
      lower.startsWith("fe80") ||
      lower.startsWith("::ffff:") // v4-mapped — re-checked below via the mapped part
    )
  }
  const parts = ip.split(".").map(Number)
  if (parts.length !== 4 || parts.some((p) => Number.isNaN(p))) return true
  const [a, b] = parts
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) || // CGNAT
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168)
  )
}

/** Throws unless the URL is a public https endpoint. */
async function assertPublicHttpsUrl(raw: string): Promise<URL> {
  let url: URL
  try {
    url = new URL(raw)
  } catch {
    throw new Error("Invalid URL")
  }
  if (url.protocol !== "https:") throw new Error("Only https:// URLs are allowed")
  const host = url.hostname.toLowerCase()
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) {
    throw new Error("URL host is not allowed")
  }
  // Literal IP or DNS resolution must land on a public address.
  const addresses = await dnsLookup(host, { all: true }).catch(() => {
    throw new Error("Could not resolve URL host")
  })
  for (const addr of addresses) {
    if (isPrivateIp(addr.address)) throw new Error("URL resolves to a private address")
  }
  return url
}

/** Fetch with manual redirect following so every hop is SSRF-guarded. */
async function guardedFetch(rawUrl: string): Promise<Response> {
  let current = rawUrl
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    await assertPublicHttpsUrl(current)
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS)
    try {
      const res = await fetch(current, { redirect: "manual", signal: controller.signal })
      if (res.status >= 300 && res.status < 400) {
        const loc = res.headers.get("location")
        if (!loc) throw new Error("Redirect without location")
        current = new URL(loc, current).toString()
        continue
      }
      return res
    } finally {
      clearTimeout(timer)
    }
  }
  throw new Error(`Too many redirects (max ${MAX_REDIRECTS})`)
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------

// Keys we hand out live in a dated uploads/ namespace — confirm must match (shared with REST complete).

async function requireMediaUpload(): Promise<string | { error: string }> {
  if (!hasMcpScope("write")) return { error: "Requires an API key with the 'write' scope." }
  const userId = getMcpUserId()
  const perms = await getUserPermissions(userId).catch(() => null)
  if (!perms || !checkPermission(perms, "media.upload").allowed) {
    return { error: 'Permission denied: requires the "media.upload" permission.' }
  }
  return userId
}

export function registerMediaTools(server: McpServerLike): void {
  const register = toolRegistrar(server)

  register(
    "request_media_upload",
    "Step 1 of a direct file upload (for clients that can make HTTP requests, e.g. agentic CLIs): returns a presigned PUT URL for the file. Upload the raw bytes to uploadUrl with the matching Content-Type header, then call confirm_media_upload. Chat-only clients should use upload_media_from_url with a public link instead.",
    {
      filename: z.string().max(200).describe("Original filename, e.g. 'team-photo.jpg'"),
      mimeType: z.string().regex(/^image\//).describe("Image MIME type, e.g. image/jpeg"),
      size: z.number().int().min(1).max(MAX_UPLOAD_BYTES).describe(`File size in bytes (max ${MAX_UPLOAD_BYTES})`),
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (async (input: any) => {
      try {
        const auth = await requireMediaUpload()
        if (typeof auth !== "string") return mcpError(auth.error)
        const { filename, mimeType, size } = input
        const presigned = await generatePresignedUrl(filename, mimeType, size)
        return mcpResponse({
          uploadUrl: presigned.uploadUrl,
          key: presigned.key,
          publicUrl: presigned.publicUrl,
          next: `PUT the raw file bytes to uploadUrl with header Content-Type: ${mimeType}, then call confirm_media_upload with { key, originalName, mimeType, size } (plus title/alt).`,
        })
      } catch (error: unknown) {
        return mcpError(error instanceof Error ? error.message : "Unknown error")
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }) as any
  )

  register(
    "confirm_media_upload",
    "Step 2 of a direct file upload: after PUTting the bytes to the presigned uploadUrl, register the file in the media library. Returns the media record with its public URL (use it in img blocks via updateBlock).",
    {
      key: z.string().max(300).describe("The key returned by request_media_upload"),
      originalName: z.string().max(200),
      mimeType: z.string().regex(/^image\//),
      size: z.number().int().min(1).max(MAX_UPLOAD_BYTES),
      title: z.string().max(200).optional(),
      alt: z.string().max(500).optional(),
      caption: z.string().max(500).optional(),
      folderId: z.string().optional(),
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (async (input: any) => {
      try {
        const auth = await requireMediaUpload()
        if (typeof auth !== "string") return mcpError(auth.error)
        const { key, originalName, mimeType, size, title, alt, caption, folderId } = input
        if (!UPLOAD_KEY_RE.test(key)) return mcpError("Invalid upload key (must come from request_media_upload)")

        // Re-derive the canonical public URL for this key instead of trusting input.
        const presignedProbe = await generatePresignedUrl(originalName, mimeType, size)
        const publicUrl = presignedProbe.publicUrl.replace(presignedProbe.key, key)

        const media = await processUpload(
          key.split("/").pop() || originalName,
          originalName,
          mimeType,
          size,
          publicUrl,
          key,
          presignedProbe.bucket,
          presignedProbe.provider,
          { title, alt, caption, folderId },
          auth
        )
        try {
          await logAuditEvent({
            userId: auth,
            action: "agent.tool_execute",
            targetType: "media",
            targetId: media.id,
            details: { tool: "confirm_media_upload", via: "mcp", key },
          })
        } catch {
          /* swallow audit errors */
        }
        return mcpResponse({
          uploaded: true,
          media: { id: media.id, url: media.url, filename: media.filename, mimeType: media.mimeType, size: media.size },
        })
      } catch (error: unknown) {
        return mcpError(error instanceof Error ? error.message : "Unknown error")
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }) as any
  )
  register(
    "search_media",
    "Search the site's media library by name/alt text, type, and folder. Set include_previews to see thumbnails of the first few image results inline.",
    {
      query: z.string().optional().describe("Search in filename, title, and alt text"),
      type: z.enum(["image", "video", "audio", "document", "other"]).optional(),
      folderId: z.string().optional(),
      limit: z.number().int().min(1).max(50).optional().describe("Max results (default 20)"),
      include_previews: z
        .boolean()
        .optional()
        .describe(`Embed up to ${MAX_PREVIEWS} small image previews in the response`),
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (async (input: any) => {
      try {
        await requireMcpPermission("media.view")
        const { query, type, folderId, limit, include_previews } = input
        const result = await listMedia({
          search: query,
          type,
          folderId,
          limit: limit || 20,
        })

        const items = result.media.map((m) => ({
          id: m.id,
          filename: m.filename,
          title: m.title,
          alt: m.alt,
          mimeType: m.mimeType,
          size: m.size,
          width: m.width,
          height: m.height,
          url: m.url,
          folderId: m.folderId,
          createdAt: m.createdAt,
        }))

        const content: Array<Record<string, unknown>> = [
          { type: "text", text: JSON.stringify({ media: items, total: result.total }) },
        ]

        if (include_previews) {
          const previewables = items.filter((m) => m.mimeType.startsWith("image/")).slice(0, MAX_PREVIEWS)
          for (const m of previewables) {
            try {
              const res = await guardedFetch(m.url)
              if (!res.ok) continue
              const buf = Buffer.from(await res.arrayBuffer())
              if (buf.byteLength > MAX_PREVIEW_BYTES) continue
              content.push({
                type: "image",
                data: buf.toString("base64"),
                mimeType: m.mimeType,
              })
              content.push({ type: "text", text: `^ preview of ${m.filename} (${m.id})` })
            } catch {
              /* previews are best-effort */
            }
          }
        }

        return { content }
      } catch (error: unknown) {
        return mcpError(error instanceof Error ? error.message : "Unknown error")
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }) as any
  )

  register(
    "upload_media_from_url",
    'Download an image from a public https URL and add it to the media library (requires a write-scoped API key and the "media.upload" permission). Use for images the user linked or ones found via stock search. Max 10MB, images only.',
    {
      url: z.string().describe("Public https URL of the image"),
      title: z.string().optional(),
      alt: z.string().optional().describe("Alt text — include attribution for stock images"),
      caption: z.string().optional(),
      folderId: z.string().optional(),
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (async (input: any) => {
      try {
        const { url, title, alt, caption, folderId } = input
        if (!hasMcpScope("write")) {
          return mcpError("upload_media_from_url requires an API key with the 'write' scope.")
        }
        const userId = getMcpUserId()
        const perms = await getUserPermissions(userId).catch(() => null)
        if (!perms || !checkPermission(perms, "media.upload").allowed) {
          return mcpError('Permission denied: requires the "media.upload" permission.')
        }

        const res = await guardedFetch(url)
        if (!res.ok) return mcpError(`Fetch failed: HTTP ${res.status}`)

        const mimeType = (res.headers.get("content-type") || "").split(";")[0].trim()
        if (!mimeType.startsWith("image/")) {
          return mcpError(`Not an image (content-type: ${mimeType || "unknown"})`)
        }

        const buf = Buffer.from(await res.arrayBuffer())
        if (buf.byteLength > MAX_UPLOAD_BYTES) {
          return mcpError(`Image too large (${buf.byteLength} bytes, max ${MAX_UPLOAD_BYTES})`)
        }
        if (buf.byteLength === 0) return mcpError("Empty response body")

        const ext = mimeType.split("/")[1]?.replace("jpeg", "jpg") || "img"
        const urlName = new URL(url).pathname.split("/").pop() || ""
        const originalName = /\.[a-z0-9]{2,5}$/i.test(urlName) ? urlName : `upload.${ext}`

        // Store through the existing pipeline: presigned PUT, then record.
        const presigned = await generatePresignedUrl(originalName, mimeType, buf.byteLength)
        const putRes = await fetch(presigned.uploadUrl, {
          method: "PUT",
          headers: { "Content-Type": mimeType },
          body: new Uint8Array(buf),
        })
        if (!putRes.ok) {
          return mcpError(`Storage upload failed: HTTP ${putRes.status} (${presigned.provider})`)
        }

        const media = await processUpload(
          presigned.key.split("/").pop() || originalName,
          originalName,
          mimeType,
          buf.byteLength,
          presigned.publicUrl,
          presigned.key,
          presigned.bucket,
          presigned.provider,
          { title, alt, caption, folderId },
          userId
        )

        try {
          await logAuditEvent({
            userId,
            action: "agent.tool_execute",
            targetType: "media",
            targetId: media.id,
            details: { tool: "upload_media_from_url", via: "mcp", sourceUrl: url.slice(0, 500) },
          })
        } catch {
          /* swallow audit errors */
        }

        return mcpResponse({
          uploaded: true,
          media: {
            id: media.id,
            url: media.url,
            filename: media.filename,
            mimeType: media.mimeType,
            size: media.size,
            width: media.width,
            height: media.height,
          },
        })
      } catch (error: unknown) {
        return mcpError(error instanceof Error ? error.message : "Unknown error")
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }) as any
  )
}
