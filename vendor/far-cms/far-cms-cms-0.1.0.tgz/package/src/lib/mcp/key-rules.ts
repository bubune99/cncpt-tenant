/**
 * MCP keys (Settings › MCP › Keys): the request rules, a key's status, and who a key may belong
 * to. Owner, 2026-11-17 (decision 2a8d59ea). Check: key-rules.assert.ts.
 */
export const EXPIRY_DAYS = [30, 90, 365] as const
export type KeyAccess = 'read' | 'read-write'

export type KeyRequest = { name: string; scopes: string[]; expiresAt: Date; userId: string }

export function keyRequest(input: Record<string, unknown>, now: Date): { ok: true; value: KeyRequest } | { ok: false; error: string } {
  const name = typeof input.name === 'string' ? input.name.trim() : ''
  if (!name) return { ok: false, error: 'Give the key a name, for example the tool it is for.' }
  if (name.length > 80) return { ok: false, error: 'Keep the name to 80 characters.' }
  if (input.access !== 'read' && input.access !== 'read-write') return { ok: false, error: 'Choose read only, or read and write.' }
  const days = input.days
  if (typeof days !== 'number' || !(EXPIRY_DAYS as readonly number[]).includes(days)) return { ok: false, error: 'Choose an expiry of 30, 90 or 365 days.' }
  const userId = typeof input.userId === 'string' ? input.userId.trim() : ''
  if (!userId) return { ok: false, error: 'Choose who the key belongs to.' }
  return {
    ok: true,
    value: { name, scopes: input.access === 'read' ? ['read'] : ['read', 'write'], expiresAt: new Date(now.getTime() + days * 86_400_000), userId },
  }
}

export function keyStatus(k: { expiresAt: Date | null; revokedAt: Date | null }, now: Date): 'active' | 'expired' | 'revoked' {
  if (k.revokedAt) return 'revoked'
  if (k.expiresAt && k.expiresAt.getTime() <= now.getTime()) return 'expired'
  return 'active'
}

/** Staff only: an admin or editor, or anyone holding a staff role; never a customer. */
export function staffForKey(u: { role: string; isActive?: boolean; staffRoles?: number } | null): boolean {
  if (!u || u.isActive === false) return false
  if (u.role === 'CUSTOMER') return false
  if (u.role === 'ADMIN' || u.role === 'EDITOR') return true
  return (u.staffRoles ?? 0) > 0
}
