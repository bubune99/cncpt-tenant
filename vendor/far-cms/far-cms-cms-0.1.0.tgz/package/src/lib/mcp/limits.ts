// Moved to @far-cms/core (far-cms packages/core/src/lib/mcp/limits.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/mcp/limits'
