/**
 * The admin's event forms in the API's own field names (the Event model): one place, so a screen
 * cannot save under a name the database ignores. Pure; asserted by form-fields.assert.ts.
 */

export type EventKind = 'IN_PERSON' | 'VIRTUAL' | 'HYBRID'

export interface VenueForm {
  venueName: string
  address: string
  city: string
  state: string
  country: string
  zip: string
  virtualUrl: string
  platform: string
}

type Stored = Partial<Record<'venueName' | 'venueAddress' | 'venueCity' | 'venueState' | 'venueCountry' | 'venueZip' | 'virtualUrl' | 'virtualPlatform', string | null>>

const keep = (v: string) => v.trim() || undefined

/** The venue and online fields, under the API's names; blanks are left out. */
export function venuePayload(f: VenueForm): Record<string, string> {
  const out: Record<string, string | undefined> = {
    venueName: keep(f.venueName),
    venueAddress: keep(f.address),
    venueCity: keep(f.city),
    venueState: keep(f.state),
    venueCountry: keep(f.country),
    venueZip: keep(f.zip),
    virtualUrl: keep(f.virtualUrl),
    virtualPlatform: keep(f.platform),
  }
  return Object.fromEntries(Object.entries(out).filter(([, v]) => v !== undefined)) as Record<string, string>
}

/** A stored event's venue and online fields, for the form. */
export function venueForm(e: Stored): VenueForm {
  return {
    venueName: e.venueName ?? '',
    address: e.venueAddress ?? '',
    city: e.venueCity ?? '',
    state: e.venueState ?? '',
    country: e.venueCountry ?? '',
    zip: e.venueZip ?? '',
    virtualUrl: e.virtualUrl ?? '',
    platform: e.virtualPlatform ?? '',
  }
}

/** The event's kind (the database default is In-Person). */
export function eventTypeOf(e: { eventType?: string | null } | null | undefined): EventKind {
  const t = e?.eventType
  return t === 'VIRTUAL' || t === 'HYBRID' ? t : 'IN_PERSON'
}
