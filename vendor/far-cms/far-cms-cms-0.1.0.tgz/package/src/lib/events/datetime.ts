/**
 * Event dates in the admin's date-and-time fields. New Event (and the event page) save
 * new Date(typed).toISOString(): the moment on the person's own clock. So a field shows the
 * browser's local parts back. The event's time zone is kept beside it. Pure; datetime.assert.ts.
 */

const pad = (n: number) => String(n).padStart(2, '0')

/** A stored date (ISO text) as a datetime-local value; '' when there is none or it isn't a date. */
export function toDateTimeInput(stored: string | null | undefined): string {
  if (!stored) return ''
  const d = new Date(stored)
  if (Number.isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

/** The time zones an event can be in (one list for New Event and the event page). */
export const EVENT_TIMEZONES: ReadonlyArray<{ value: string; label: string }> = [
  { value: 'UTC', label: 'UTC' },
  { value: 'Africa/Accra', label: 'Accra (GMT)' },
  { value: 'America/New_York', label: 'Eastern Time (US)' },
  { value: 'America/Chicago', label: 'Central Time (US)' },
  { value: 'America/Denver', label: 'Mountain Time (US)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (US)' },
  { value: 'Europe/London', label: 'London (GMT/BST)' },
  { value: 'Europe/Paris', label: 'Paris (CET/CEST)' },
  { value: 'Asia/Tokyo', label: 'Tokyo (JST)' },
]
