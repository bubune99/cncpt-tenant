/**
 * Which database client the CMS uses. A host app that needs its own (CNCPT: one that adds the site to every query,
 * from @far-cms/db scoped()) calls setHostClient() once at startup, before any CMS module runs a query. A host that
 * calls nothing (Dzidzor, BYB) gets the CMS's own client, exactly as before. Pure. Checked in host-client.assert.ts.
 */

/** Where the host's client is kept on globalThis. */
export const HOST_KEY = "__farCms"

type Holder = Record<string, unknown>

/** The host's client when it set one; otherwise the CMS's own, built only when needed. */
export function pickClient<T>(holder: Holder, buildOwn: () => T): T {
  const hosted = (holder[HOST_KEY] as { prisma?: T } | undefined)?.prisma
  return hosted ?? buildOwn()
}

/** Called by the host app at startup. */
export function setHostClient(client: unknown, holder: Holder = globalThis as unknown as Holder): void {
  holder[HOST_KEY] = { ...((holder[HOST_KEY] as object | undefined) ?? {}), prisma: client }
}
