/**
 * Which database client the CMS uses. A host app that needs its own (CNCPT: one that adds the site to every query,
 * from @far-cms/db scoped()) calls setHostClient() once at startup, before any CMS module runs a query. A host that
 * calls nothing (Dzidzor, BYB) gets the CMS's own client, exactly as before. Pure. Checked in host-client.assert.ts.
 */

/** Where the host's client is kept on globalThis. */
export const HOST_KEY = "__farCms"

type Holder = Record<string, unknown>

/** The host's client when it set one; otherwise the CMS's own, built only when needed. */
export function pickClient<T>(holder: Holder, buildOwn: () => T): T {
  const hosted = (holder[HOST_KEY] as { prisma?: T } | undefined)?.prisma
  return hosted ?? buildOwn()
}

/**
 * The client every CMS module imports. It asks pickClient on each use rather than once at load, because a module that
 * loads the CMS's db before the host has called setHostClient would otherwise keep the CMS's own (unscoped) client for
 * the life of the server (CNCPT staging, 2026-11-23: the mounted Customers API queried without the site). The CMS's
 * own client is built once, on first use, and kept.
 */
export function lateClient<T extends object>(holder: Holder, buildOwn: () => T): T {
  let own: T | undefined
  const current = (): any => pickClient<T>(holder, () => (own ??= buildOwn()))
  return new Proxy({} as T, {
    get(_t, prop) {
      const c = current()
      const v = c[prop]
      return typeof v === "function" ? v.bind(c) : v
    },
    has(_t, prop) { return prop in current() },
  })
}

/** Called by the host app at startup. */
export function setHostClient(client: unknown, holder: Holder = globalThis as unknown as Holder): void {
  holder[HOST_KEY] = { ...((holder[HOST_KEY] as object | undefined) ?? {}), prisma: client }
}

/** Called by a host app that serves several sites from one server (CNCPT). */
export function setHostMultiSite(holder: Holder = globalThis as unknown as Holder): void {
  holder[HOST_KEY] = { ...((holder[HOST_KEY] as object | undefined) ?? {}), multiSite: true }
}

/**
 * Whether a module may answer site data (settings, the commerce switch, provider credentials) from a cache shared by
 * the whole server. Not on a host that serves several sites: one site's answer would be served to another (found on
 * CNCPT staging, 2026-11-23). There each request reads its own site's data.
 */
export function moduleCacheAllowed(holder: Holder = globalThis as unknown as Holder): boolean {
  return !(holder[HOST_KEY] as { multiSite?: boolean } | undefined)?.multiSite
}
