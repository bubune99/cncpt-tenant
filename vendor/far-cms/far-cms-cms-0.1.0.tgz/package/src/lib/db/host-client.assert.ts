/**
 * The CMS uses the database client its host app hands it (CNCPT: a client that adds the site to every query),
 * and its own client when the host hands none (Dzidzor, BYB: unchanged). Card 10 (c645e053), step 1.
 * Run: node_modules/.bin/tsx packages/cms/src/lib/db/host-client.assert.ts
 */
import assert from "node:assert/strict"
import { readFileSync } from "node:fs"
import { pickClient, setHostClient, HOST_KEY } from "./host-client"

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const own = { name: "own" }
const host = { name: "host" }

ok("with no host client, the CMS uses its own", () => {
  assert.equal(pickClient({}, () => own), own)
})
ok("with a host client, the CMS uses the host's and never builds its own", () => {
  let built = 0
  assert.equal(pickClient({ [HOST_KEY]: { prisma: host } }, () => { built++; return own }), host)
  assert.equal(built, 0)
})
ok("setHostClient puts the client where pickClient looks", () => {
  const g: Record<string, unknown> = {}
  setHostClient(host, g)
  assert.equal(pickClient(g, () => own), host)
})
ok("lib/db/index exports the picked client, so every importer gets the host's", () => {
  const src = readFileSync(new URL("./index.ts", import.meta.url), "utf8")
  assert.match(src, /pickClient\(globalThis/)
})
console.log(`${n} checks passed`)
