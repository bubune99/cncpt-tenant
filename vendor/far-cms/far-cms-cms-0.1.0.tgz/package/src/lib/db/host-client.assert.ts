/**
 * The CMS uses the database client its host app hands it (CNCPT: a client that adds the site to every query),
 * and its own client when the host hands none (Dzidzor, BYB: unchanged). Card 10 (c645e053), step 1.
 * Run: node_modules/.bin/tsx packages/cms/src/lib/db/host-client.assert.ts
 */
import assert from "node:assert/strict"
import { readFileSync } from "node:fs"
import { pickClient, setHostClient, lateClient, setHostMultiSite, moduleCacheAllowed, HOST_KEY } from "./host-client"

let n = 0
const ok = (name: string, fn: () => void) => { fn(); n++; console.log(`ok ${n} - ${name}`) }

const own = { name: "own" }
const host = { name: "host" }

ok("with no host client, the CMS uses its own", () => {
  assert.equal(pickClient({}, () => own), own)
})
ok("with a host client, the CMS uses the host's and never builds its own", () => {
  let built = 0
  assert.equal(pickClient({ [HOST_KEY]: { prisma: host } }, () => { built++; return own }), host)
  assert.equal(built, 0)
})
ok("setHostClient puts the client where pickClient looks", () => {
  const g: Record<string, unknown> = {}
  setHostClient(host, g)
  assert.equal(pickClient(g, () => own), host)
})
ok("a host client set AFTER the CMS's db module loaded is still the one used (CNCPT staging, 2026-11-23)", () => {
  const g: Record<string, unknown> = {}
  const db = lateClient(g, () => ({ who: () => "own" }))
  setHostClient({ who: () => "host" }, g)
  assert.equal((db as any).who(), "host")
})
ok("with no host client, the CMS's own client is built once and kept", () => {
  let built = 0
  const db: any = lateClient({}, () => { built++; return { n: 1, who() { return this.n } } })
  assert.equal(db.who(), 1)
  assert.equal(db.n, 1)
  assert.equal(built, 1)
})
ok("methods run against the real client, not the stand-in (this is kept)", () => {
  const real = { name: "real", self() { return this } }
  const db: any = lateClient({ [HOST_KEY]: { prisma: real } }, () => ({}))
  assert.equal(db.self(), real)
  assert.equal("name" in db, true)
})
ok("lib/db/index exports the late-bound client, so import order cannot leave a host on the CMS's own client", () => {
  const src = readFileSync(new URL("./index.ts", import.meta.url), "utf8")
  assert.match(src, /lateClient\(globalThis/)
})
ok("a single-site app may keep site data in module caches; a host serving several sites may not", () => {
  const g: Record<string, unknown> = {}
  assert.equal(moduleCacheAllowed(g), true)
  setHostClient({}, g)
  setHostMultiSite(g)
  assert.equal(moduleCacheAllowed(g), false)
  assert.ok((g[HOST_KEY] as { prisma?: unknown }).prisma, "setting multi-site keeps the host client")
})
ok("every module cache of site data checks moduleCacheAllowed before it answers from memory (CNCPT staging, 2026-11-23)", () => {
  const files = ["../features.ts", "../env/index.ts", "../settings/index.ts", "../stripe/index.ts", "../analytics/index.ts", "../shippo/index.ts", "../seo/index.ts", "../ade-bindings/view-policy-source.ts", "../modules/registry.ts", "../ade-bindings/mobile/review-count.ts", "../commerce/index.ts"]
  for (const f of files) assert.match(readFileSync(new URL(f, import.meta.url), "utf8"), /moduleCacheAllowed\(\)/, f)
})
console.log(`${n} checks passed`)
