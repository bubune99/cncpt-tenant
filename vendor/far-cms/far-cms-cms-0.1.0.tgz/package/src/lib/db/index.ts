// Database client using PrismaNeon adapter for Vercel serverless
import { PrismaClient } from "@prisma/client"
import { PrismaNeon } from "@prisma/adapter-neon"
import { pickClient } from "./host-client"

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/**
 * Runtime queries go through Neon's pooler (DATABASE_URL); the direct
 * endpoint (DATABASE_URL_UNPOOLED) is for migrations (prisma.config.ts).
 *
 * Why: suspended serverless instances can't run idle timers, so sockets they
 * opened to the DIRECT endpoint stay open; every deploy brings a fresh set of
 * instances, and on 2026-10-09 staging hit Postgres' connection limit
 * (99/112 idle) — page lookups failed and public pages answered 404.
 * A small pool with a short idle timeout keeps each instance's share low.
 */
function createPrismaClient(): PrismaClient {
  const connectionString = process.env.DATABASE_URL || process.env.DATABASE_URL_UNPOOLED

  const adapter = new PrismaNeon({ connectionString, max: 4, idleTimeoutMillis: 5_000 })

  return new PrismaClient({
    adapter,
    log:
      process.env.NODE_ENV === "development"
        ? ["error", "warn"]
        : ["error"],
  })
}

// A host app may hand the CMS its own client (CNCPT: site-scoped); otherwise the CMS uses its own (./host-client).
export const prisma: PrismaClient = pickClient(globalThis as unknown as Record<string, unknown>, () => globalForPrisma.prisma ?? createPrismaClient())

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma

export default prisma
