// Moved to @far-cms/core (far-cms packages/core/src/lib/account/account-home.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/account/account-home'
