/**
 * Feature flags.
 *
 * commerce.enabled — shop/merch/cart/checkout/orders/shipping on or off.
 *   Source of truth: the `settings` row with key "commerce.enabled"
 *   (value "true"/"false"); if that row is absent, env COMMERCE_ENABLED;
 *   if neither is set, the app default (APP_ADE_DEFAULTS.commerceEnabled in
 *   lib/ade-bindings/app-config — Dzidzor: OFF). A database error also reads
 *   as the app default (Dzidzor: fail closed).
 *   Rules for what "off" hides live in ./commerce-paths.ts.
 *
 * Toggle without a deploy:
 *   INSERT INTO settings (id, key, value, "group", encrypted, "createdAt", "updatedAt")
 *   VALUES (gen_random_uuid()::text, 'commerce.enabled', 'true', 'store', false, now(), now())
 *   ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, "updatedAt" = now();
 * (cached for up to 60 s per server instance; ISR pages refresh within 5 min)
 */

import { NextResponse } from 'next/server'
import { prisma } from './db'
import { resolveCommerceEnabled } from './commerce-paths'
import { APP_ADE_DEFAULTS } from './ade-bindings/app-config'

export const COMMERCE_FLAG_KEY = 'commerce.enabled'

const TTL_MS = 60_000
let cached: { value: boolean; expiresAt: number } | null = null

export async function isCommerceEnabled(): Promise<boolean> {
  if (cached && cached.expiresAt > Date.now()) return cached.value

  let dbValue: unknown = null
  try {
    const row = await prisma.setting.findUnique({
      where: { key: COMMERCE_FLAG_KEY },
      select: { value: true },
    })
    dbValue = row?.value ?? null
  } catch (error) {
    console.error(`[features] could not read commerce.enabled — using the app default (${APP_ADE_DEFAULTS.commerceEnabled ? 'on' : 'off'}):`, error)
    return APP_ADE_DEFAULTS.commerceEnabled // don't cache a transient failure
  }

  const value = resolveCommerceEnabled(dbValue, process.env.COMMERCE_ENABLED, APP_ADE_DEFAULTS.commerceEnabled)
  cached = { value, expiresAt: Date.now() + TTL_MS }
  return value
}

/**
 * For commerce API handlers: returns a 404 response when commerce is off,
 * otherwise null. Usage at the top of a handler:
 *   const off = await commerceDisabledResponse(); if (off) return off;
 */
export async function commerceDisabledResponse(): Promise<NextResponse | null> {
  if (await isCommerceEnabled()) return null
  return NextResponse.json({ error: 'Not found' }, { status: 404 })
}

/**
 * Wrap a route handler so it 404s while commerce is off:
 *   export const POST = withCommerce(withPermission('orders.create', handler))
 */
export function withCommerce<A extends unknown[], R extends Response>(
  handler: (...args: A) => Promise<R>
): (...args: A) => Promise<R | NextResponse> {
  return async (...args: A) => {
    const off = await commerceDisabledResponse()
    if (off) return off
    return handler(...args)
  }
}
