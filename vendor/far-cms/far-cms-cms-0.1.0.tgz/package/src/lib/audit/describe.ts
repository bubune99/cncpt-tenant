/**
 * The Audit log in words: an action label, the kind of item, and a one-line summary,
 * all from what each audit row already stores. Never shows a raw code like
 * "agent.tool_execute". Pure; checked by describe.assert.ts.
 */

type Details = Record<string, unknown> | null | undefined

export const ACTION_LABELS: Readonly<Record<string, string>> = {
  'role.create': 'Role Created',
  'role.update': 'Role Updated',
  'role.delete': 'Role Deleted',
  'role.assign': 'Role Assigned',
  'role.remove': 'Role Removed',
  'permission.grant': 'Permission Granted',
  'permission.deny': 'Permission Denied',
  'permission.remove': 'Permission Removed',
  'user.create': 'User Created',
  'user.update': 'User Updated',
  // The route takes away roles, exceptions and keys; the person stays (walk 2026-11-19).
  'user.delete': 'Access Removed',
  'page.create': 'Page Created',
  'page.update': 'Page Updated',
  'page.delete': 'Page Deleted',
  'route.create': 'Route Created',
  'route.update': 'Route Updated',
  'route.delete': 'Route Deleted',
  'puck_template.create': 'Template Created',
  'puck_template.update': 'Template Updated',
  'puck_template.delete': 'Template Deleted',
  'template.create': 'Template Created',
  'template.update': 'Template Updated',
  'template.delete': 'Template Deleted',
  'product.create': 'Product Created',
  'product.update': 'Product Updated',
  'product.delete': 'Product Deleted',
  'product.archive': 'Product Archived',
  'order.update': 'Order Updated',
  'order.delete': 'Order Deleted',
  'settings.update': 'Settings Updated',
  'site_settings.update': 'Site Settings Updated',
  'canva.connect': 'Canva Connected',
  'canva.disconnect': 'Canva Disconnected',
  'canva.import': 'Canva Import',
  'blog.create': 'Post Created',
  'blog.update': 'Post Updated',
  'blog.delete': 'Post Deleted',
  'customer.create': 'Customer Created',
  'form.submission_reply': 'Form Reply Sent',
  'privacy.subject_delete': 'Personal Data Deleted',
  'privacy.subject_export': 'Personal Data Exported',
  'ai.read_blocked': 'Assistant Kept From Reading',
  'agent.tool_execute': 'Assistant Action',
}

const REVIEW_LABELS: Readonly<Record<string, string>> = {
  approve: 'Change Approved',
  reject: 'Change Rejected',
  'approve-publish': 'Approved and Published',
}

const ITEM_LABELS: Readonly<Record<string, string>> = {
  'ade-change-set': 'Change',
  agent: 'Assistant',
  blog: 'Post',
  pages: 'Page',
  form_submission: 'Form message',
  'data-subject': 'Personal data',
  site_settings: 'Site settings',
  puck_template: 'Template',
}

/** "updateBlock" / "upload_media" / "frobnicate-all" → "Update block". */
function words(code: string): string {
  const spaced = code
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[._-]+/g, ' ')
    .trim()
    .toLowerCase()
  return spaced ? spaced.charAt(0).toUpperCase() + spaced.slice(1) : ''
}

const str = (v: unknown): string => (typeof v === 'string' ? v.trim() : '')

export function actionLabel(action: string, details: Details): string {
  const d = details ?? {}
  const review = str(d.review)
  if (review && REVIEW_LABELS[review]) return REVIEW_LABELS[review]
  const tool = str(d.tool)
  if (action === 'agent.tool_execute' && tool) return `Assistant: ${words(tool)}`
  if (ACTION_LABELS[action]) return ACTION_LABELS[action]
  const dot = action.indexOf('.')
  if (dot > 0) return `${words(action.slice(0, dot))}: ${words(action.slice(dot + 1))}`
  return words(action) || 'Action'
}

export function itemLabel(entityType: string | null | undefined): string {
  if (!entityType) return '—'
  return ITEM_LABELS[entityType] ?? words(entityType)
}

const MAX_SUMMARY = 140

// What a page update changed, in words (page route's updateData keys). Others are bookkeeping.
const PAGE_FIELDS: ReadonlyArray<readonly [string, string]> = [
  ['title', 'title'],
  ['slug', 'address'],
  ['content', 'content'],
  ['status', 'status'],
  ['metaTitle', 'SEO title'],
  ['metaDescription', 'SEO description'],
  ['featuredImageId', 'picture'],
  ['parentId', 'parent page'],
  ['headerMode', 'header'],
  ['customHeader', 'header'],
  ['footerMode', 'footer'],
  ['customFooter', 'footer'],
  ['showAnnouncement', 'announcement'],
  ['customAnnouncement', 'announcement'],
]

const obj = (v: unknown): Record<string, unknown> | null => (v && typeof v === 'object' ? (v as Record<string, unknown>) : null)

export function auditSummary(details: Details): string {
  const d = details ?? {}
  const clip = (s: string) => (s.length > MAX_SUMMARY ? `${s.slice(0, MAX_SUMMARY - 1)}…` : s)
  const restored = str(d.restoredFromRevision)
  const prev = obj(d.previous)
  const title = str(d.title) || str(d.name) || str(prev?.title)
  const slug = str(d.slug) || str(prev?.slug)
  if (restored) return title ? clip(`${title}: restored an earlier version`) : 'Restored an earlier version'
  const updated = obj(d.updated)
  if (prev && updated && title) {
    // title / address / status are compared with what they were (the editor re-sends them unchanged).
    const norm = (k: string, v: unknown) => (k === 'slug' ? str(v).replace(/^\/+/, '') : k === 'status' ? str(v).toUpperCase() : str(v))
    const same = (k: string) => (k === 'title' || k === 'slug' || k === 'status') && norm(k, updated[k]) === norm(k, prev[k])
    const changed = Array.from(new Set(PAGE_FIELDS.filter(([k]) => k in updated && !same(k)).map(([, w]) => w)))
    const name = slug ? `${title} (${slug})` : title
    return clip(changed.length ? `${name}: ${changed.join(', ')}` : name)
  }
  if (title) return clip(slug ? `${title} (${slug})` : title)
  const input = d.input && typeof d.input === 'object' ? (d.input as Record<string, unknown>) : null
  const why = str(input?.why) || str(d.why)
  if (why) return clip(why)
  if (Array.isArray(d.outcomes) && d.outcomes.length && str(d.review)) {
    const count = d.outcomes.length
    const verb = str(d.review) === 'reject' ? 'rejected' : 'approved'
    return `${count} item${count === 1 ? '' : 's'} ${verb}`
  }
  return slug ? clip(slug) : ''
}

/** What a review approved or rejected, from its items' own summaries (walk 2026-11-19: not '1 item approved'). */
export function reviewTitle(summaries: ReadonlyArray<string | null | undefined>): string {
  const seen = Array.from(new Set(summaries.map((s) => (typeof s === 'string' ? s.trim() : '')).filter(Boolean)))
  if (seen.length <= 2) return seen.join('; ')
  return `${seen.slice(0, 2).join('; ')} and ${seen.length - 2} more`
}
