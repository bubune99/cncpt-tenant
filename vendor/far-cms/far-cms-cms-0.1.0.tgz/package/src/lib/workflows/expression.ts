/**
 * Workflow expression evaluator — parses, never executes.
 *
 * Workflow conditions and expression input mappings used to be compiled with
 * new Function, which made "can edit or run a workflow" the same as "can run
 * code on the server". This module parses the expression into a small AST and
 * walks it, so an expression can only:
 *
 * - read names from the scope it is given (data) and call the helper functions
 *   it is given (functions) — no globals, no `this`, no `new`, no assignment;
 * - read OWN properties of objects and arrays (plus `length` of strings and
 *   arrays) — never inherited ones, so `x.constructor`, `__proto__` and
 *   prototype methods are unreachable;
 * - call a short list of string/array methods (includes, startsWith, …).
 *
 * Supported: literals (numbers, 'strings', true/false/null/undefined, [arrays]),
 * names, a.b / a[b], calls, ! - + typeof, * / %, + -, < <= > >=,
 * == != === !==, &&, ||, ??, and c ? a : b.
 *
 * Pure: no imports, no I/O.
 */

export class ExpressionError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ExpressionError'
  }
}

export interface ExpressionScope {
  /** Names the expression may read. */
  data: Record<string, unknown>
  /** Names the expression may call. */
  functions?: Record<string, (...args: unknown[]) => unknown>
}

export const MAX_EXPRESSION_LENGTH = 2000
const MAX_DEPTH = 64

const BLOCKED_KEYS = new Set(['__proto__', 'prototype', 'constructor', '__defineGetter__', '__defineSetter__', '__lookupGetter__', '__lookupSetter__'])

/** Methods callable on a string or array receiver. */
const STRING_METHODS = new Set(['includes', 'startsWith', 'endsWith', 'toLowerCase', 'toUpperCase', 'trim', 'indexOf'])
const ARRAY_METHODS = new Set(['includes', 'indexOf'])

// --- tokenizer ---------------------------------------------------------------

type Token =
  | { kind: 'num'; value: number }
  | { kind: 'str'; value: string }
  | { kind: 'name'; value: string }
  | { kind: 'op'; value: string }

const OPERATORS = ['===', '!==', '==', '!=', '<=', '>=', '&&', '||', '??', '<', '>', '+', '-', '*', '/', '%', '!', '?', ':', '.', ',', '(', ')', '[', ']']

const ESCAPES: Record<string, string> = { n: '\n', t: '\t', r: '\r', b: '\b', f: '\f', v: '\v', '0': '\0' }

function tokenize(src: string): Token[] {
  const tokens: Token[] = []
  let i = 0
  while (i < src.length) {
    const ch = src[i]
    if (/\s/.test(ch)) { i++; continue }

    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(src[i + 1] ?? ''))) {
      const m = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(src.slice(i))!
      tokens.push({ kind: 'num', value: Number(m[0]) })
      i += m[0].length
      continue
    }

    if (ch === '"' || ch === "'") {
      let value = ''
      i++
      while (i < src.length && src[i] !== ch) {
        if (src[i] === '\\') {
          const next = src[i + 1]
          if (next === 'u' && /^[0-9a-fA-F]{4}$/.test(src.slice(i + 2, i + 6))) {
            value += String.fromCharCode(parseInt(src.slice(i + 2, i + 6), 16))
            i += 6
            continue
          }
          if (next === undefined) break
          value += ESCAPES[next] ?? next
          i += 2
          continue
        }
        value += src[i++]
      }
      if (src[i] !== ch) throw new ExpressionError('Unterminated string')
      i++
      tokens.push({ kind: 'str', value })
      continue
    }

    if (/[A-Za-z_$]/.test(ch)) {
      const m = /^[A-Za-z_$][\w$]*/.exec(src.slice(i))!
      tokens.push({ kind: 'name', value: m[0] })
      i += m[0].length
      continue
    }

    const op = OPERATORS.find((o) => src.startsWith(o, i))
    if (!op) throw new ExpressionError(`Unexpected character "${ch}"`)
    tokens.push({ kind: 'op', value: op })
    i += op.length
  }
  return tokens
}

// --- parser ------------------------------------------------------------------

export type Node =
  | { type: 'lit'; value: unknown }
  | { type: 'name'; name: string }
  | { type: 'array'; items: Node[] }
  | { type: 'member'; object: Node; key: Node }
  | { type: 'call'; callee: Node; args: Node[] }
  | { type: 'unary'; op: string; arg: Node }
  | { type: 'binary'; op: string; left: Node; right: Node }
  | { type: 'cond'; test: Node; then: Node; else: Node }

const KEYWORDS: Record<string, unknown> = { true: true, false: false, null: null, undefined: undefined }

const BINARY_LEVELS: string[][] = [
  ['??'],
  ['||'],
  ['&&'],
  ['==', '!=', '===', '!=='],
  ['<', '<=', '>', '>='],
  ['+', '-'],
  ['*', '/', '%'],
]

export function parseExpression(src: string): Node {
  if (typeof src !== 'string') throw new ExpressionError('Expression must be a string')
  if (src.length > MAX_EXPRESSION_LENGTH) throw new ExpressionError(`Expression is longer than ${MAX_EXPRESSION_LENGTH} characters`)
  const tokens = tokenize(src)
  let pos = 0
  let depth = 0

  const peek = () => tokens[pos]
  const isOp = (value: string) => peek()?.kind === 'op' && peek()!.value === value
  const expect = (value: string) => {
    if (!isOp(value)) throw new ExpressionError(`Expected "${value}"`)
    pos++
  }
  const enter = () => {
    if (++depth > MAX_DEPTH) throw new ExpressionError('Expression is nested too deeply')
  }

  function conditional(): Node {
    enter()
    const test = binary(0)
    let node = test
    if (isOp('?')) {
      pos++
      const then = conditional()
      expect(':')
      node = { type: 'cond', test, then, else: conditional() }
    }
    depth--
    return node
  }

  function binary(level: number): Node {
    if (level === BINARY_LEVELS.length) return unary()
    let left = binary(level + 1)
    for (let t = peek(); t?.kind === 'op' && BINARY_LEVELS[level].includes(t.value); t = peek()) {
      const op = t.value
      pos++
      left = { type: 'binary', op, left, right: binary(level + 1) }
    }
    return left
  }

  function unary(): Node {
    const t = peek()
    if (t && ((t.kind === 'op' && ['!', '-', '+'].includes(t.value)) || (t.kind === 'name' && t.value === 'typeof'))) {
      pos++
      enter()
      const node: Node = { type: 'unary', op: t.value, arg: unary() }
      depth--
      return node
    }
    return postfix()
  }

  function postfix(): Node {
    let node = primary()
    for (;;) {
      if (isOp('.')) {
        pos++
        const t = tokens[pos++]
        if (t?.kind !== 'name') throw new ExpressionError('Expected a property name after "."')
        node = { type: 'member', object: node, key: { type: 'lit', value: t.value } }
      } else if (isOp('[')) {
        pos++
        const key = conditional()
        expect(']')
        node = { type: 'member', object: node, key }
      } else if (isOp('(')) {
        pos++
        node = { type: 'call', callee: node, args: list(')') }
      } else {
        return node
      }
    }
  }

  function list(close: string): Node[] {
    const items: Node[] = []
    if (isOp(close)) { pos++; return items }
    for (;;) {
      items.push(conditional())
      if (isOp(',')) { pos++; continue }
      expect(close)
      return items
    }
  }

  function primary(): Node {
    const t = tokens[pos++]
    if (!t) throw new ExpressionError('Unexpected end of expression')
    if (t.kind === 'num' || t.kind === 'str') return { type: 'lit', value: t.value }
    if (t.kind === 'name') {
      if (t.value in KEYWORDS) return { type: 'lit', value: KEYWORDS[t.value] }
      return { type: 'name', name: t.value }
    }
    if (t.value === '(') {
      const node = conditional()
      expect(')')
      return node
    }
    if (t.value === '[') return { type: 'array', items: list(']') }
    throw new ExpressionError(`Unexpected "${t.value}"`)
  }

  const node = conditional()
  if (pos < tokens.length) throw new ExpressionError(`Unexpected "${String(tokens[pos].value)}"`)
  return node
}

// --- evaluator ---------------------------------------------------------------

const own = (obj: object, key: string) => Object.prototype.hasOwnProperty.call(obj, key)

function readProperty(object: unknown, key: unknown): unknown {
  if (object === null || object === undefined) return undefined
  const k = typeof key === 'number' ? String(key) : key
  if (typeof k !== 'string') throw new ExpressionError('Property names must be strings or numbers')
  if (BLOCKED_KEYS.has(k)) throw new ExpressionError(`Property "${k}" is not allowed`)
  if (k === 'length' && (typeof object === 'string' || Array.isArray(object))) return object.length
  if (typeof object === 'string') return /^\d+$/.test(k) ? object[Number(k)] : undefined
  if (typeof object !== 'object') return undefined
  if (!own(object, k)) return undefined
  const value = (object as Record<string, unknown>)[k]
  if (typeof value === 'function') throw new ExpressionError(`Property "${k}" is a function`)
  return value
}

function callMethod(receiver: unknown, name: string, args: unknown[]): unknown {
  if (typeof receiver === 'string' && STRING_METHODS.has(name)) {
    if (args.some((a) => a !== null && typeof a === 'object')) throw new ExpressionError(`${name}() takes plain values`)
    return (String.prototype as unknown as Record<string, (...a: unknown[]) => unknown>)[name].apply(receiver, args)
  }
  if (Array.isArray(receiver) && ARRAY_METHODS.has(name)) {
    return (Array.prototype as unknown as Record<string, (...a: unknown[]) => unknown>)[name].apply(receiver, args)
  }
  throw new ExpressionError(`Method "${name}" is not allowed`)
}

function binaryOp(op: string, l: unknown, r: unknown): unknown {
  /* eslint-disable eqeqeq */
  switch (op) {
    case '==': return l == r
    case '!=': return l != r
    case '===': return l === r
    case '!==': return l !== r
    case '<': return (l as number) < (r as number)
    case '<=': return (l as number) <= (r as number)
    case '>': return (l as number) > (r as number)
    case '>=': return (l as number) >= (r as number)
    case '+': return (l as number) + (r as number)
    case '-': return (l as number) - (r as number)
    case '*': return (l as number) * (r as number)
    case '/': return (l as number) / (r as number)
    case '%': return (l as number) % (r as number)
  }
  /* eslint-enable eqeqeq */
  throw new ExpressionError(`Unknown operator "${op}"`)
}

export function evaluateNode(node: Node, scope: ExpressionScope): unknown {
  const ev = (n: Node) => evaluateNode(n, scope)
  switch (node.type) {
    case 'lit':
      return node.value
    case 'name':
      if (own(scope.data, node.name)) return scope.data[node.name]
      throw new ExpressionError(`Unknown name "${node.name}"`)
    case 'array':
      return node.items.map(ev)
    case 'member':
      return readProperty(ev(node.object), ev(node.key))
    case 'call': {
      const args = node.args.map(ev)
      if (node.callee.type === 'name') {
        const fn = scope.functions && own(scope.functions, node.callee.name) ? scope.functions[node.callee.name] : undefined
        if (typeof fn !== 'function') throw new ExpressionError(`"${node.callee.name}" is not a function you can call`)
        return fn(...args)
      }
      if (node.callee.type === 'member') {
        const name = ev(node.callee.key)
        if (typeof name !== 'string') throw new ExpressionError('Method names must be strings')
        return callMethod(ev(node.callee.object), name, args)
      }
      throw new ExpressionError('Only named functions and allowed methods can be called')
    }
    case 'unary': {
      const v = ev(node.arg)
      if (node.op === '!') return !v
      if (node.op !== 'typeof' && v !== null && typeof v === 'object') throw new ExpressionError(`"${node.op}" needs a plain value, not an object`)
      if (node.op === '-') return -(v as number)
      if (node.op === '+') return +(v as number)
      return v === null ? 'object' : typeof v
    }
    case 'binary': {
      if (node.op === '&&') return ev(node.left) && ev(node.right)
      if (node.op === '||') return ev(node.left) || ev(node.right)
      if (node.op === '??') return ev(node.left) ?? ev(node.right)
      const l = ev(node.left)
      const r = ev(node.right)
      if ((l !== null && typeof l === 'object') || (r !== null && typeof r === 'object')) {
        if (!['===', '!==', '==', '!='].includes(node.op)) throw new ExpressionError(`"${node.op}" needs plain values, not objects`)
        // Loose equality against an object would call its valueOf/toString.
        return node.op === '==' || node.op === '===' ? l === r : l !== r
      }
      return binaryOp(node.op, l, r)
    }
    case 'cond':
      return ev(node.test) ? ev(node.then) : ev(node.else)
  }
}

/** Parse and evaluate. Throws ExpressionError for anything outside the grammar. */
export function evaluateSafeExpression(expression: string, scope: ExpressionScope): unknown {
  return evaluateNode(parseExpression(expression), scope)
}

/** Helpers every workflow expression may call. All take and return plain values. */
export const EXPRESSION_HELPERS: Record<string, (...args: unknown[]) => unknown> = {
  $len: (v) => (Array.isArray(v) ? v.length : 0),
  $empty: (v) => v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0),
  $now: () => new Date().toISOString(),
  $lower: (v) => (typeof v === 'string' ? v.toLowerCase() : v),
  $upper: (v) => (typeof v === 'string' ? v.toUpperCase() : v),
  $trim: (v) => (typeof v === 'string' ? v.trim() : v),
  $number: (v) => Number(v),
  $string: (v) => String(v),
  $json: (v) => JSON.stringify(v),
  $parse: (v) => (typeof v === 'string' ? JSON.parse(v) : v),
}
