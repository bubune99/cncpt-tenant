/**
 * Where a list stands while it loads from the server. Pure; asserted by list-load.assert.ts.
 */
export type ListLoad = 'loading' | 'ready' | 'failed'
export type ListView = 'loading' | 'failed' | 'empty' | 'items'

/** What to show: rows when there are any; otherwise loading, failed, or (only once the server answered) empty. */
export function listView(load: ListLoad, count: number): ListView {
  if (count > 0) return 'items'
  if (load === 'ready') return 'empty'
  return load
}

/** The state after a response came back: ok means ready, anything else failed. */
export function loadDone(ok: boolean): ListLoad {
  return ok ? 'ready' : 'failed'
}
