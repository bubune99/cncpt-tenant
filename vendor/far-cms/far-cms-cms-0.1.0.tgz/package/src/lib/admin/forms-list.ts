/**
 * Rules of the Forms list. Pure; asserted by forms-list.assert.ts.
 */

export interface FormToCopy {
  name: string
  description?: string | null
  fields?: unknown
  submitButtonText?: string | null
  successMessage?: string | null
  redirectUrl?: string | null
  notifyEmails?: unknown
}

/**
 * What is sent to create a copy: the whole form (questions, button, thank-you,
 * where it goes next, who is told), always a draft. Automations are not copied:
 * they are made per form.
 */
export function duplicateFormPayload(form: FormToCopy): Record<string, unknown> {
  const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v)) as T
  const out: Record<string, unknown> = { name: `${form.name} (Copy)`, status: 'DRAFT' }
  if (form.description) out.description = form.description
  if (Array.isArray(form.fields) && form.fields.length > 0) out.fields = clone(form.fields)
  if (form.submitButtonText) out.submitButtonText = form.submitButtonText
  if (form.successMessage) out.successMessage = form.successMessage
  if (form.redirectUrl) out.redirectUrl = form.redirectUrl
  if (Array.isArray(form.notifyEmails) && form.notifyEmails.length > 0) out.notifyEmails = clone(form.notifyEmails)
  return out
}

export interface EmptyFormsMessage {
  title: string
  hint: string
  /** Offer Create Form (a first form) or Clear search (nothing matched). */
  canCreate: boolean
}

/** What the list says when it has no rows: nothing made yet, or nothing matching the search. */
export function emptyFormsMessage(search: string): EmptyFormsMessage {
  const term = search.trim()
  if (!term) return { title: 'No forms yet', hint: 'Get started by creating your first form.', canCreate: true }
  return { title: `No forms match “${term}”`, hint: 'Try another word, or clear the search to see every form.', canCreate: false }
}

export interface FormRow {
  name: string
  description?: string | null
  slug?: string | null
  status: string
  _count: { submissions: number }
}

/** The rows a search shows: name, description or address contains the words, any case. */
export function matchForms<T extends FormRow>(all: readonly T[], search: string): T[] {
  const term = search.trim().toLowerCase()
  if (!term) return [...all]
  return all.filter((f) => [f.name, f.description ?? '', f.slug ?? ''].some((v) => v.toLowerCase().includes(term)))
}

export interface FormStats {
  total: number
  active: number
  draft: number
  submissions: number
}

/** The four counts, always from every form: a search narrows the rows, not the counts. */
export function formStats(all: readonly FormRow[]): FormStats {
  return {
    total: all.length,
    active: all.filter((f) => f.status === 'ACTIVE').length,
    draft: all.filter((f) => f.status === 'DRAFT').length,
    submissions: all.reduce((sum, f) => sum + f._count.submissions, 0),
  }
}
