/**
 * The admin header's Search box: the screens this person sees in the sidebar and the
 * Settings sections they can open, matched with the assistant's words for them
 * (findPlatformEntries over the app vocabulary). Only what is passed in can be found,
 * so a hidden screen never shows. Pure; checked by header-search.assert.ts.
 */

import { findPlatformEntries, type PlatformEntry, type PlatformVocabulary } from '../ade/platform-map'
import { sectionHref, type SettingsSection } from '../settings/sections'

export interface HeaderSearchResult {
  name: string
  href: string
  kind: 'screen' | 'setting'
  about: string
}

export const HEADER_SEARCH_MAX = 6
const SETTINGS_HREF = '/admin/settings'

export function headerSearch(
  query: string,
  input: { nav: ReadonlyArray<{ name: string; href: string }>; sections: ReadonlyArray<SettingsSection>; vocabulary: PlatformVocabulary },
  limit = HEADER_SEARCH_MAX,
): HeaderSearchResult[] {
  const q = query.trim()
  if (q.length < 2) return []
  const words = (key: string) => input.vocabulary[key]
  const screens: PlatformEntry[] = input.nav.map((i) => ({
    id: i.href,
    name: i.name,
    kind: 'area',
    href: i.href,
    about: words(i.href)?.about ?? '',
    tools: [],
    synonyms: [...(words(i.href)?.synonyms ?? [])],
  }))
  const canOpenSettings = input.nav.some((i) => i.href === SETTINGS_HREF)
  const settings: PlatformEntry[] = canOpenSettings
    ? input.sections.map((s) => ({
        id: `settings:${s.id}`,
        name: `${s.label} (Settings)`,
        kind: 'settings',
        href: sectionHref(s),
        about: words(`settings:${s.id}`)?.about ?? s.description,
        tools: [],
        synonyms: [...(words(`settings:${s.id}`)?.synonyms ?? []), ...(s.keywords ? s.keywords.split(/[,\s]+/).filter(Boolean) : [])],
      }))
    : []
  const seen = new Set<string>()
  return findPlatformEntries([...screens, ...settings], q, limit + 4)
    .filter((m) => (seen.has(m.entry.href) ? false : (seen.add(m.entry.href), true)))
    .slice(0, limit)
    .map((m) => ({ name: m.entry.name, href: m.entry.href, kind: m.entry.kind === 'settings' ? 'setting' : 'screen', about: m.entry.about }))
}
