/**
 * The admin Import tool (ZIP / GitHub project import) was deleted on
 * 2026-11-16 at the owner's word (inbox c2b8e734): "delete it and it always
 * lives in a past commit". Its last version is in git history before that
 * commit. Module manifests stored in the database can still list its address,
 * so menus built from them leave it out. Pure; asserted by import-retired.assert.ts.
 */

/** Admin screens that no longer exist but may still be listed by stored module manifests. */
export const RETIRED_ADMIN_PATHS: ReadonlyArray<string> = ['/admin/import']
