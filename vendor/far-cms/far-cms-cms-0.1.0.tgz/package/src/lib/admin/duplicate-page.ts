/**
 * Duplicating a page from the Pages list: the copy is the whole page (content, search text,
 * picture, parent, header and footer choice), always a draft, at an address nobody has.
 * Pure; asserted by duplicate-page.assert.ts.
 */

export interface PageToCopy {
  title: string
  slug: string
  status?: string
  content?: unknown
  metaTitle?: string | null
  metaDescription?: string | null
  featuredImageId?: string | null
  parentId?: string | null
  headerMode?: string | null
  footerMode?: string | null
  showAnnouncement?: boolean | null
}

/** How many addresses are tried before saying it could not be copied. */
export const MAX_COPY_TRIES = 8

const suffix = (attempt: number): string => (attempt <= 1 ? '' : ` ${attempt}`)

/** "/about" becomes "/about-copy", then "/about-copy-2". The home page ("/") copies to "/home-copy". */
export function copyAddress(slug: string, attempt: number): string {
  const clean = slug.replace(/\/+$/, '')
  const base = clean === '' ? '/home' : clean
  return `${base}-copy${attempt <= 1 ? '' : `-${attempt}`}`
}

/** "About (Copy)", then "About (Copy 2)". */
export function copyTitle(title: string, attempt: number): string {
  return `${title} (Copy${suffix(attempt)})`
}

/** What is sent to create the copy. Header and footer choices are sent only when the page has them. */
export function duplicatePayload(page: PageToCopy, attempt: number): Record<string, unknown> {
  const content = page.content == null ? null : (JSON.parse(JSON.stringify(page.content)) as unknown)
  return {
    title: copyTitle(page.title, attempt),
    slug: copyAddress(page.slug, attempt),
    status: 'draft',
    content,
    metaTitle: page.metaTitle ?? null,
    metaDescription: page.metaDescription ?? null,
    featuredImageId: page.featuredImageId ?? null,
    parentId: page.parentId ?? null,
    ...(page.headerMode ? { headerMode: page.headerMode } : {}),
    ...(page.footerMode ? { footerMode: page.footerMode } : {}),
    showAnnouncement: page.showAnnouncement ?? true,
  }
}
