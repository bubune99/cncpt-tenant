/**
 * What stored per-page CSS is keyed on besides its classes: the output format and the
 * theme + compiler it was made with. Light on purpose (no compiler import), so the
 * storefront's render path can check stored CSS without loading Tailwind.
 *
 * Neutral (no app imports): shared with BYB.
 */
import { classSetHash } from './collect'
import { TAILWIND_VERSION } from './tailwind-version.generated'

/** Bumped when the output format changes (stored CSS from another version is ignored). */
export const PAGE_CSS_FORMAT = 2 // 2: signed (sign.ts); unsigned format-1 CSS is ignored

/** Identifies theme + compiler: stored CSS made with another one is stale. */
export function themeKey(appTheme: string): string {
  return classSetHash([TAILWIND_VERSION, String(PAGE_CSS_FORMAT), appTheme])
}
