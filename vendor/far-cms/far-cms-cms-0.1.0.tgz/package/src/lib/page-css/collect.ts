/**
 * The class names a page renders with, for its per-page CSS: every block's className
 * (children and interaction overlays included), each reference's per-page overrides,
 * the blocks of the partials it embeds (with those overrides applied), and the few
 * classes the block renderer adds itself (visibility, background overlay). The set is
 * hashed; stored CSS is used only while the hash matches what the page renders now.
 *
 * Neutral (no app imports): shared with BYB.
 */

export interface CssBlock {
  id: string
  className?: string
  componentName?: string
  partialId?: string
  partialOverrides?: Record<string, { className?: string } | undefined>
  children?: ReadonlyArray<CssBlock>
  interaction?: { content?: ReadonlyArray<CssBlock> }
}

/** The component name of a partial reference block. */
export const PARTIAL_REFERENCE = 'PartialReference'

/** Classes BlockRenderer adds on its own (responsive visibility, the background overlay, inline wrappers). */
export const RENDERER_CLASSES: ReadonlyArray<string> = [
  'relative', 'absolute', 'inset-0', 'z-0', 'z-10', 'inline-block',
  'hidden', 'block', 'md:block', 'lg:block', 'md:hidden', 'lg:hidden', 'max-md:block', 'max-md:hidden',
]

const split = (className: string | undefined) => (className ?? '').split(/\s+/).filter(Boolean)

/**
 * All classes of `blocks`, plus those of embedded partials (`partials`: id → that partial's blocks;
 * a missing or unpublished partial renders nothing, so contributes nothing). Sorted, unique.
 */
export function collectPageClasses(
  blocks: ReadonlyArray<CssBlock>,
  partials: Readonly<Record<string, ReadonlyArray<CssBlock> | undefined>> = {},
  opts: { renderer?: boolean } = {},
): string[] {
  // The editor canvas leaves the renderer's own classes out (its chrome uses them too).
  const out = new Set<string>(opts.renderer === false ? [] : RENDERER_CLASSES)
  const walk = (list: ReadonlyArray<CssBlock>, overrides?: CssBlock['partialOverrides']) => {
    for (const b of list) {
      const own = overrides?.[b.id]?.className
      for (const c of split(own !== undefined ? own : b.className)) out.add(c)
      if (b.componentName === PARTIAL_REFERENCE && b.partialId) {
        const body = partials[b.partialId]
        if (body) walk(body, b.partialOverrides)
      }
      if (b.children) walk(b.children, overrides)
      if (b.interaction?.content) walk(b.interaction.content, overrides)
    }
  }
  walk(blocks)
  return [...out].sort()
}

/** The partials a page embeds (ids, unique). */
export function referencedPartialIds(blocks: ReadonlyArray<CssBlock>): string[] {
  const out = new Set<string>()
  const walk = (list: ReadonlyArray<CssBlock>) => {
    for (const b of list) {
      if (b.componentName === PARTIAL_REFERENCE && b.partialId) out.add(b.partialId)
      if (b.children) walk(b.children)
      if (b.interaction?.content) walk(b.interaction.content)
    }
  }
  walk(blocks)
  return [...out]
}

/** FNV-1a (32-bit, two lanes) over the sorted class list: a short, stable, isomorphic id. */
export function classSetHash(classes: ReadonlyArray<string>): string {
  const text = classes.join(' ')
  let a = 0x811c9dc5
  let b = 0x01000193 ^ text.length
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i)
    a = Math.imul(a ^ c, 0x01000193) >>> 0
    b = Math.imul(b ^ c, 0x5bd1e995) >>> 0
  }
  return a.toString(36).padStart(7, '0') + b.toString(36).padStart(7, '0')
}
