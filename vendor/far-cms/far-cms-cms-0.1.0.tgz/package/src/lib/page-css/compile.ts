/**
 * Per-page CSS compiler (server): Tailwind's own compiler over one page's classes, with
 * the site's theme as REFERENCE (its variables already live in the site stylesheet, so
 * none are re-emitted), then scoped to the page wrapper (./scope).
 *
 * A fresh compiler per call: Tailwind's build() accumulates candidates across calls.
 * ~20–30 ms per page (measured in the report). Never throws to a caller that saves:
 * see compileStored.
 *
 * Neutral: the app's theme text comes in as an argument (bindings supply it).
 */
import { createHash } from 'node:crypto'
import { compile } from 'tailwindcss'
import { TAILWIND_THEME_CSS } from './tailwind-theme.generated'
import { filterSafeClasses } from './safe-classes'
import { hasScopedShape, scopeCss, styleSafe } from './scope'
import { classSetHash } from './collect'

import { themeKey } from './key'
export { PAGE_CSS_FORMAT, themeKey } from './key'

/** Theme text as reference-only (`@theme … reference`): variables resolve, nothing is emitted. */
export function referenceTheme(themeCss: string): string {
  return themeCss.replace(/@theme(\s+(?:default|inline|static))*\s*\{/g, (m, mods: string | undefined) => `@theme${mods ?? ''} reference {`)
}

/** The compiler input for an app theme (custom variants + @theme blocks). */
export function compilerInput(appTheme: string): string {
  return `${referenceTheme(TAILWIND_THEME_CSS)}\n${referenceTheme(appTheme)}\n@tailwind utilities;\n`
}

/** A page with more classes than this isn't compiled (the save keeps its last CSS, with a warning). */
export const MAX_PAGE_CLASSES = 2000

/**
 * Results by class set + theme. Tailwind's compiler can't be reused across pages (build()
 * accumulates every candidate it has seen, so one page's CSS would carry the last page's
 * classes), so identical requests are answered from here instead of compiling again.
 */
const CACHE_MAX = 200
const cache = new Map<string, CompiledCss>()

export interface CompiledCss {
  /** Scoped CSS, safe to inline in <style>. */
  css: string
  /** Hash of the class set (also the scope value). */
  hash: string
  /** Classes dropped by the allow-list. */
  rejected: string[]
  ms: number
}

/** Compile one class set. Throws on a compiler failure (callers decide: see compileStored). */
export async function compileClasses(classes: ReadonlyArray<string>, appTheme: string): Promise<CompiledCss> {
  const t0 = Date.now()
  if (classes.length > MAX_PAGE_CLASSES) throw new Error(`Too many classes to compile (${classes.length} > ${MAX_PAGE_CLASSES})`)
  const hash = classSetHash(classes)
  // A crypto hash of the exact input, so two class sets can never share a cache entry.
  const cacheKey = createHash('sha256').update(`${themeKey(appTheme)}\n${classes.join('\n')}`).digest('hex').slice(0, 32)
  const hit = cache.get(cacheKey)
  if (hit) {
    cache.delete(cacheKey) // refresh its place (least recently used goes first)
    cache.set(cacheKey, hit)
    return { ...hit, ms: Date.now() - t0 }
  }
  const { safe, rejected } = filterSafeClasses(classes)
  const compiler = await compile(compilerInput(appTheme), { base: '/' })
  const built = compiler.build(safe)
  const css = styleSafe(scopeCss(built, hash))
  // Our own output must pass the same strict check render applies, or it would never show.
  if (css === null || !hasScopedShape(css, hash)) throw new Error('Compiled CSS failed the page-CSS shape check')
  const out = { css, hash, rejected, ms: Date.now() - t0 }
  cache.set(cacheKey, out)
  if (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value!)
  return out
}
