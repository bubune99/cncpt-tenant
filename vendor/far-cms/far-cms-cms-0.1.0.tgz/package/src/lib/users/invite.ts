/**
 * How a newly added person gets in: the site's sign-in page, and an invitation the owner
 * sends from their own mail app (the site sends nothing itself). A person added in Users is
 * matched on first sign-in by the same email (api/auth/sync). Pure. Check: invite.assert.ts.
 */

export const SIGN_IN_PATH = '/handler/sign-in'

export function signInLink(origin: string): string {
  return `${origin.replace(/\/+$/, '')}${SIGN_IN_PATH}`
}

export interface Invitation {
  to: string
  name?: string | null
  inviter?: string | null
  site: string
  link: string
}

const enc = (s: string) => encodeURIComponent(s)

export function invitationMailto({ to, name, inviter, site, link }: Invitation): string {
  const who = name?.trim()
  const by = inviter?.trim()
  const subject = `You’re invited to the ${site} admin`
  const body = [
    who ? `Hi ${who},` : 'Hello,',
    '',
    by ? `${by} has added you to the ${site} admin.` : `You’ve been added to the ${site} admin.`,
    '',
    `Sign in here with this email address (${to}):`,
    link,
    '',
    'If it asks you to confirm your email, use the link it sends you, then sign in again.',
  ].join('\n')
  return `mailto:${enc(to)}?subject=${enc(subject)}&body=${enc(body)}`
}
