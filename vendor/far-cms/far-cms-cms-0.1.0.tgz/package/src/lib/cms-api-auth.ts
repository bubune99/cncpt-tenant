/**
 * CMS Content API Authentication
 *
 * Bearer token auth for the public Content API.
 * API keys are stored encrypted in the Setting table under key "cms_api_keys".
 */

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from './db'
import { safeDecrypt, isEncrypted } from './encryption'
import { timingSafeEqual } from 'crypto'
import { rateLimitByKey, rateLimitCheck } from './rate-limit'

/** Constant-time key comparison (a plain === leaks how much of a guess matched). */
function sameKey(a: string, b: string): boolean {
  const x = Buffer.from(a)
  const y = Buffer.from(b)
  return x.length === y.length && timingSafeEqual(x, y)
}

export interface ApiKeyEntry {
  id: string
  key: string
  name: string
  scope: 'read' | 'readwrite'
  createdAt: string
}

export interface ApiKeyValidation {
  valid: boolean
  keyId?: string
  scope?: 'read' | 'readwrite'
}

/**
 * Extract bearer token from request headers.
 * Checks Authorization: Bearer <key> first, then x-api-key header as fallback.
 */
function extractToken(request: NextRequest): string | null {
  const authHeader = request.headers.get('authorization')
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.slice(7).trim()
  }

  const apiKeyHeader = request.headers.get('x-api-key')
  if (apiKeyHeader) {
    return apiKeyHeader.trim()
  }

  return null
}

/**
 * Load and decrypt API keys from the Setting table.
 */
async function loadApiKeys(): Promise<ApiKeyEntry[]> {
  try {
    const record = await prisma.setting.findUnique({
      where: { key: 'cms_api_keys' },
    })

    if (!record) return []

    let value = record.value

    // Decrypt if encrypted
    if (record.encrypted && isEncrypted(value)) {
      value = safeDecrypt(value)
    }

    const parsed = JSON.parse(value)
    if (!Array.isArray(parsed)) return []

    return parsed as ApiKeyEntry[]
  } catch (error) {
    console.error('Failed to load CMS API keys:', error)
    return []
  }
}

/**
 * Validate an API key from the request.
 */
export async function validateApiKey(request: NextRequest): Promise<ApiKeyValidation> {
  const token = extractToken(request)
  if (!token) {
    return { valid: false }
  }

  const keys = await loadApiKeys()
  const match = keys.find((k) => typeof k.key === 'string' && sameKey(k.key, token))

  if (!match) {
    return { valid: false }
  }

  return {
    valid: true,
    keyId: match.id,
    scope: match.scope,
  }
}

/**
 * Require a valid API key. Returns a 401 NextResponse if invalid.
 * If `requiredScope` is "readwrite", only readwrite keys pass.
 * If `requiredScope` is "read", both read and readwrite keys pass.
 */
export async function requireApiKey(
  request: NextRequest,
  requiredScope: 'read' | 'readwrite' = 'read'
): Promise<ApiKeyValidation | NextResponse> {
  // Throttle key guessing per IP, and cap each key's writes (the Content API
  // writes pages and partials directly — same limiter as the admin APIs).
  const perIp = await rateLimitCheck(request, { maxRequests: 120, windowMs: 60_000, keyPrefix: 'cms-content-api' })
  if (perIp) return perIp
  const result = await validateApiKey(request)

  if (!result.valid) {
    return NextResponse.json(
      { error: 'Unauthorized. Provide a valid API key via Authorization: Bearer <key> or x-api-key header.' },
      { status: 401 }
    )
  }

  if (requiredScope === 'readwrite' && result.scope !== 'readwrite') {
    return NextResponse.json(
      { error: 'Forbidden. This action requires a readwrite API key.' },
      { status: 403 }
    )
  }

  if (requiredScope === 'readwrite' && result.keyId) {
    const perKey = await rateLimitByKey(`cms-content-key:${result.keyId}`, { maxRequests: 60, windowMs: 60_000 })
    if (perKey) return perKey
  }

  return result
}

/**
 * Helper to check if requireApiKey returned an error response.
 */
export function isErrorResponse(result: ApiKeyValidation | NextResponse): result is NextResponse {
  return result instanceof NextResponse
}
