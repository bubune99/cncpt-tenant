/**
 * v0 to Block Converter
 *
 * Converts parsed v0 components to Block[] format for the page builder.
 * Uses regex-based JSX parsing to extract structure and Tailwind classes.
 */

import type { Block, BlockTag } from "../block-editor/types";
import { CONTAINER_TAGS, LEAF_TAGS } from "../block-editor/types";
import type { ParsedV0Component, BlockConversionResult, ValidationResult } from "./types";

let blockIdCounter = 0;

function generateId(): string {
  return `v0-${++blockIdCounter}`;
}

/**
 * Reset the ID counter (call before processing a new component)
 */
export function resetIdCounter(): void {
  blockIdCounter = 0;
}

/**
 * Valid HTML tags that map to BlockTag
 */
const VALID_TAGS = new Set<string>([
  "div", "section", "header", "footer", "main", "nav", "aside", "article",
  "h1", "h2", "h3", "h4", "h5", "h6", "p", "span", "a", "img", "button",
  "ul", "ol", "li", "hr", "blockquote", "figure", "figcaption",
  "form", "input", "textarea", "label", "video", "svg"
]);

/**
 * Map common React/Next.js components to HTML tags
 */
const COMPONENT_TAG_MAP: Record<string, BlockTag> = {
  "Image": "img",
  "NextImage": "img",
  "Link": "a",
  "NextLink": "a",
  "Button": "button",
  "Heading": "h2",
  "Text": "p",
  "Container": "div",
  "Box": "div",
  "Flex": "div",
  "Grid": "div",
  "Stack": "div",
  "Card": "div",
  "CardContent": "div",
  "CardHeader": "div",
  "CardTitle": "h3",
  "CardDescription": "p",
};

/**
 * Convert parsed v0 component to Block[] format
 */
export function convertToBlocks(parsed: ParsedV0Component): BlockConversionResult {
  resetIdCounter();

  const warnings: string[] = [];
  const blocks: Block[] = [];

  // Extract JSX from the source code
  const jsxContent = extractJsxReturn(parsed.sourceCode);

  if (!jsxContent) {
    warnings.push("Could not find JSX return statement in component");
    return {
      blocks: [],
      metadata: {
        componentName: parsed.name,
        displayName: parsed.displayName,
        description: parsed.description,
        dependencies: parsed.dependencies,
        warnings,
      },
    };
  }

  // Parse JSX into blocks
  const parsedBlocks = parseJsxToBlocks(jsxContent, null, warnings);
  blocks.push(...parsedBlocks);

  // Check for unsupported dependencies
  const unsupportedDeps = parsed.dependencies.filter((dep) =>
    ["next/image", "next/link", "next/router", "framer-motion"].includes(dep)
  );
  if (unsupportedDeps.length > 0) {
    warnings.push(
      `Uses Next.js/Framer imports that were auto-mapped: ${unsupportedDeps.join(", ")}`
    );
  }

  return {
    blocks,
    metadata: {
      componentName: parsed.name,
      displayName: parsed.displayName,
      description: parsed.description,
      dependencies: parsed.dependencies,
      warnings,
    },
  };
}

/**
 * Extract the JSX return content from component source code
 */
function extractJsxReturn(code: string): string | null {
  // Match return ( ... ) or return <...>
  const returnMatch = code.match(/return\s*\(\s*([\s\S]*?)\s*\)\s*;?\s*\}|return\s+(<[\s\S]*?>)\s*;?\s*\}/);

  if (returnMatch) {
    return returnMatch[1] || returnMatch[2];
  }

  // Try arrow function implicit return: () => ( ... ) or () => <...>
  const arrowMatch = code.match(/=>\s*\(\s*([\s\S]*?)\s*\)\s*$|=>\s*(<[\s\S]*?>)\s*$/m);

  if (arrowMatch) {
    return arrowMatch[1] || arrowMatch[2];
  }

  // Try to find the main JSX block
  const jsxMatch = code.match(/<([A-Za-z][A-Za-z0-9]*)[^>]*>[\s\S]*<\/\1>/);
  if (jsxMatch) {
    return jsxMatch[0];
  }

  return null;
}

/**
 * Parse JSX string into Block[] array
 */
function parseJsxToBlocks(
  jsx: string,
  parentId: string | null,
  warnings: string[]
): Block[] {
  const blocks: Block[] = [];

  // Clean up the JSX
  const cleanJsx = jsx.trim();

  // Handle fragments
  if (cleanJsx.startsWith("<>") || cleanJsx.startsWith("<React.Fragment>")) {
    const innerContent = cleanJsx
      .replace(/^<>|^<React\.Fragment>/, "")
      .replace(/<\/>$|<\/React\.Fragment>$/, "");
    return parseChildElements(innerContent, parentId, warnings);
  }

  // Parse the root element
  const rootBlock = parseJsxElement(cleanJsx, parentId, warnings);
  if (rootBlock) {
    blocks.push(rootBlock);
  }

  return blocks;
}

/**
 * Parse a single JSX element into a Block
 */
function parseJsxElement(
  jsx: string,
  parentId: string | null,
  warnings: string[]
): Block | null {
  const trimmed = jsx.trim();

  if (!trimmed || !trimmed.startsWith("<")) {
    return null;
  }

  // Extract tag name
  const tagMatch = trimmed.match(/^<([A-Za-z][A-Za-z0-9.]*)/);
  if (!tagMatch) {
    return null;
  }

  let rawTag = tagMatch[1];

  // Handle namespaced tags like motion.div
  if (rawTag.includes(".")) {
    const parts = rawTag.split(".");
    rawTag = parts[parts.length - 1]; // Use the last part (e.g., "div" from "motion.div")
  }

  // Map React components to HTML tags
  let tag: BlockTag;
  if (VALID_TAGS.has(rawTag.toLowerCase())) {
    tag = rawTag.toLowerCase() as BlockTag;
  } else if (COMPONENT_TAG_MAP[rawTag]) {
    tag = COMPONENT_TAG_MAP[rawTag];
  } else {
    // Unknown component - default to div
    tag = "div";
    if (/^[A-Z]/.test(rawTag)) {
      warnings.push(`Unknown component "${rawTag}" mapped to div`);
    }
  }

  const id = generateId();

  // Extract className
  const classMatch = trimmed.match(/className=["'{`]([^"'{`}]+)["'{`}]/);
  const className = classMatch ? cleanClassName(classMatch[1]) : "";

  // Extract common attributes
  const attrs: Record<string, string> = {};

  // href
  const hrefMatch = trimmed.match(/href=["'{]([^"'}]+)["'}]/);
  if (hrefMatch) attrs.href = hrefMatch[1];

  // src
  const srcMatch = trimmed.match(/src=["'{]([^"'}]+)["'}]/);
  if (srcMatch) attrs.src = srcMatch[1];

  // alt
  const altMatch = trimmed.match(/alt=["'{]([^"'}]+)["'}]/);
  if (altMatch) attrs.alt = altMatch[1];

  // placeholder
  const placeholderMatch = trimmed.match(/placeholder=["'{]([^"'}]+)["'}]/);
  if (placeholderMatch) attrs.placeholder = placeholderMatch[1];

  // type (for inputs/buttons)
  const typeMatch = trimmed.match(/type=["'{]([^"'}]+)["'}]/);
  if (typeMatch) attrs.type = typeMatch[1];

  // Check if self-closing
  const isSelfClosing = trimmed.match(/\/>$/);

  let textContent: string | undefined;
  let children: Block[] | undefined;

  if (!isSelfClosing) {
    // Extract inner content
    const closingTagRegex = new RegExp(`</${rawTag.replace(".", "\\.")}>`);
    const closingMatch = trimmed.match(closingTagRegex);

    if (closingMatch) {
      // Find the opening tag end
      const openingEnd = trimmed.indexOf(">") + 1;
      const closingStart = trimmed.lastIndexOf(`</${rawTag}`);

      if (openingEnd > 0 && closingStart > openingEnd) {
        const innerContent = trimmed.slice(openingEnd, closingStart).trim();

        if (innerContent) {
          // Check if it's a container or leaf tag
          if (LEAF_TAGS.includes(tag)) {
            // Leaf tags get text content
            textContent = extractTextContent(innerContent);
          } else {
            // Container tags get children
            const parsedChildren = parseChildElements(innerContent, id, warnings);
            if (parsedChildren.length > 0) {
              children = parsedChildren;
            } else {
              // If no child elements, treat as text
              const text = extractTextContent(innerContent);
              if (text) {
                textContent = text;
              }
            }
          }
        }
      }
    }
  }

  const block: Block = {
    id,
    tag,
    className,
    parentId,
  };

  if (textContent) block.textContent = textContent;
  if (children && children.length > 0) block.children = children;
  if (Object.keys(attrs).length > 0) block.attrs = attrs;

  return block;
}

/**
 * Parse child elements from inner JSX content
 */
function parseChildElements(
  content: string,
  parentId: string | null,
  warnings: string[]
): Block[] {
  const blocks: Block[] = [];

  // Match JSX elements (both self-closing and regular)
  const elementRegex = /<([A-Za-z][A-Za-z0-9.]*)(?:\s[^>]*)?\s*(?:\/>|>[\s\S]*?<\/\1>)/g;

  let match;
  while ((match = elementRegex.exec(content)) !== null) {
    const block = parseJsxElement(match[0], parentId, warnings);
    if (block) {
      blocks.push(block);
    }
  }

  return blocks;
}

/**
 * Extract text content from JSX, removing expressions and nested tags
 */
function extractTextContent(content: string): string {
  // Remove JSX expressions like {variable}
  let text = content.replace(/\{[^}]+\}/g, "");

  // Remove nested JSX tags
  text = text.replace(/<[^>]+>[^<]*<\/[^>]+>/g, "");
  text = text.replace(/<[^>]+\/>/g, "");

  // Clean up whitespace
  text = text.replace(/\s+/g, " ").trim();

  return text;
}

/**
 * Clean up className string (remove template literals, cn() calls, etc.)
 */
function cleanClassName(className: string): string {
  // Remove template literal expressions
  let clean = className.replace(/\$\{[^}]+\}/g, "");

  // If it looks like a cn() or clsx() result, extract the string parts
  clean = clean.replace(/cn\(|clsx\(|twMerge\(/g, "");

  // Remove quotes and commas from function-style classes
  clean = clean.replace(/["',()]/g, " ");

  // Clean up whitespace
  clean = clean.replace(/\s+/g, " ").trim();

  return clean;
}

/**
 * Validate converted blocks
 */
export function validateBlocks(blocks: Block[]): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const suggestions: string[] = [];
  const seenIds = new Set<string>();

  function validateBlock(block: Block, path: string): void {
    // Check for duplicate IDs
    if (seenIds.has(block.id)) {
      errors.push(`Duplicate block ID "${block.id}" at ${path}`);
    }
    seenIds.add(block.id);

    // Check tag is valid
    if (!VALID_TAGS.has(block.tag)) {
      errors.push(`Invalid tag "${block.tag}" at ${path}`);
    }

    // Check leaf tags don't have children
    if (LEAF_TAGS.includes(block.tag) && block.children && block.children.length > 0) {
      warnings.push(`Leaf tag "${block.tag}" at ${path} has children - children will be ignored`);
    }

    // Check container tags with text content
    if (CONTAINER_TAGS.includes(block.tag) && block.textContent && !block.children) {
      suggestions.push(`Container tag "${block.tag}" at ${path} has only text - consider using a <p> or <span> instead`);
    }

    // Check links have href
    if (block.tag === "a" && (!block.attrs?.href)) {
      warnings.push(`Link at ${path} is missing href attribute`);
    }

    // Check images have src and alt
    if (block.tag === "img") {
      if (!block.attrs?.src) {
        warnings.push(`Image at ${path} is missing src attribute`);
      }
      if (!block.attrs?.alt) {
        suggestions.push(`Image at ${path} should have alt text for accessibility`);
      }
    }

    // Validate children
    if (block.children) {
      block.children.forEach((child, i) => {
        validateBlock(child, `${path}.children[${i}]`);
      });
    }
  }

  blocks.forEach((block, i) => {
    validateBlock(block, `blocks[${i}]`);
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    suggestions,
  };
}

/**
 * Analyze component for conversion complexity
 */
export function analyzeComponent(parsed: ParsedV0Component): {
  complexity: "simple" | "moderate" | "complex";
  suggestions: string[];
  requiredSetup: string[];
} {
  const suggestions: string[] = [];
  const requiredSetup: string[] = [];

  // Check dependencies
  const needsInstall = parsed.dependencies.filter(
    (dep) => !isBuiltInDependency(dep)
  );
  if (needsInstall.length > 0) {
    requiredSetup.push(`Install dependencies: npm install ${needsInstall.join(" ")}`);
  }

  // Check for relative imports
  const relativeImports = parsed.imports.filter((imp) => imp.isRelative);
  if (relativeImports.length > 0) {
    suggestions.push(
      "Component has relative imports that may need to be inlined or updated"
    );
  }

  // Check Tailwind classes
  const customClasses = parsed.tailwindClasses.filter(
    (cls) => cls.includes("[") // Arbitrary values
  );
  if (customClasses.length > 0) {
    suggestions.push(
      "Component uses arbitrary Tailwind values - ensure your config supports them"
    );
  }

  // Check for state/hooks
  if (parsed.sourceCode.includes("useState") || parsed.sourceCode.includes("useEffect")) {
    suggestions.push(
      "Component uses React hooks - interactive behavior may need manual implementation"
    );
  }

  // Determine complexity
  let complexity: "simple" | "moderate" | "complex" = "simple";
  if (parsed.props.length > 5 || parsed.dependencies.length > 3) {
    complexity = "moderate";
  }
  if (
    parsed.props.some((p) => p.type === "function" || p.type === "object") ||
    relativeImports.length > 2 ||
    parsed.sourceCode.includes("useEffect")
  ) {
    complexity = "complex";
  }

  return { complexity, suggestions, requiredSetup };
}

/**
 * Check if dependency is built-in (doesn't need installation)
 */
function isBuiltInDependency(dep: string): boolean {
  const builtIn = [
    "react",
    "react-dom",
    "next",
    "next/image",
    "next/link",
    "next/router",
    "next/navigation",
  ];
  return builtIn.includes(dep);
}
