/**
 * Pages in the shared History API, bridged to PageRevision (no second copy
 * of page content): versions come from the page's own snapshots
 * (lib/pages/history-bridge), and a restore goes the same way as the page's
 * Revisions list — snapshot the current page, then put the title and blocks
 * back (address and published status unchanged).
 */

import { safeContent } from '../block-editor/content-safety'
import { prisma } from '../db'
import { registerHistory, registerHistorySource, type SourceRevision } from '../ade-bindings/history'
import type { RestorePolicy } from '../ade/history'
import { HistoryRefusal } from '../ade/history'
import { pageVersions } from './history-bridge'
import { recordPageRevision } from './revisions'

const PAGE_FIELDS = { title: true, slug: true, status: true, content: true } as const

/** What a page restore may write: its title and blocks. Its address and published state stay (publish from the editor). */
export const PAGE_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    title: { class: 'restorable', type: 'string' },
    content: { class: 'restorable', type: 'json' },
    slug: { class: 'never', reason: 'The page keeps its address' },
    status: { class: 'never', reason: 'The page keeps its published state — publish from the editor' },
  },
}

/** Media-library pictures a page's blocks point at that were deleted since. */
export async function missingMediaIn(content: unknown): Promise<string[]> {
  const urls = new Set<string>()
  const walk = (v: unknown) => {
    if (Array.isArray(v)) return v.forEach(walk)
    if (!v || typeof v !== 'object') return
    for (const [k, x] of Object.entries(v as Record<string, unknown>)) {
      if ((k === 'src' || k === 'poster' || k === 'url') && typeof x === 'string' && /^https?:\/\//.test(x)) urls.add(x)
      else walk(x)
    }
  }
  walk(content)
  if (!urls.size) return []
  const known = await prisma.media.findMany({ where: { url: { in: [...urls] } }, select: { url: true, deletedAt: true } })
  // Only pictures that came from Media and were deleted (bin or gone); outside links aren't ours to check.
  return known.filter((m) => m.deletedAt).map((m) => m.url)
}

async function loadPage(id: string) {
  return prisma.page.findUnique({ where: { id }, select: { id: true, ...PAGE_FIELDS } })
}

async function versionsOf(pageId: string) {
  const [page, snaps] = await Promise.all([
    loadPage(pageId),
    prisma.pageRevision.findMany({ where: { pageId }, select: { id: true, reason: true, createdById: true, createdAt: true, ...PAGE_FIELDS } }),
  ])
  return page ? { page, versions: pageVersions(snaps, page) } : null
}

registerHistory({
  entityType: 'page',
  editPermission: 'pages.edit',
  ignore: new Set(['id', 'createdAt', 'updatedAt']),
  load: async (id) => {
    const p = await loadPage(id)
    return p ? { title: p.title, slug: p.slug, status: p.status, content: p.content } : null
  },
  nameOf: async (id) => (await prisma.page.findUnique({ where: { id }, select: { title: true } }))?.title ?? null,
  fieldLabels: { title: 'Title', slug: 'Web address', status: 'Published', content: 'Blocks' },
  policy: PAGE_POLICY,
  missingRefs: async (target) => {
    const gone = await missingMediaIn(target.content)
    return gone.length ? { content: `${gone.length === 1 ? 'A picture' : `${gone.length} pictures`} in that version ${gone.length === 1 ? 'was' : 'were'} deleted from Media` } : {}
  },
  // Restores go through the source below; this adapter only names the page and its permission.
  async save() {
    throw new HistoryRefusal('Pages restore through their own revisions')
  },
})

registerHistorySource({
  entityType: 'page',
  async list(pageId): Promise<SourceRevision[]> {
    const v = await versionsOf(pageId)
    if (!v) return []
    return v.versions.map((x) => ({
      id: x.id,
      version: x.version,
      at: x.at,
      // Pages record the person (an assistant edit says so in its reason).
      actor: { kind: x.reason === 'ai-edit' ? 'agent' : 'user', userId: x.userId },
      reason: x.reason,
      changed: x.changed,
      before: x.before,
      after: x.after,
    }))
  },
  async find(id) {
    const r = await prisma.pageRevision.findUnique({ where: { id }, select: { pageId: true } })
    return r ? { entityId: r.pageId } : null
  },
  async restoreState(id, viewerId) {
    const snap = await prisma.pageRevision.findUnique({ where: { id }, select: { pageId: true } })
    if (!snap) return null
    const v = await versionsOf(snap.pageId)
    const target = v?.versions.find((x) => x.id === id)
    if (!v || !target) return null
    // The state right after that change: the next snapshot, or the page now.
    const asc = [...v.versions].reverse()
    const i = asc.findIndex((x) => x.id === id)
    const next = asc[i + 1] ? await prisma.pageRevision.findUnique({ where: { id: asc[i + 1].id }, select: PAGE_FIELDS }) : null
    const now = { title: v.page.title, slug: v.page.slug, status: v.page.status, content: v.page.content }
    const after = next ? { title: next.title, slug: next.slug, status: next.status, content: next.content } : now
    const changedSince = asc.slice(i + 1).filter((x) => !viewerId || x.userId !== viewerId).flatMap((x) => x.changed)
    return { version: target.version, current: now, target: after, targetSchemaVersion: PAGE_POLICY.schemaVersion, changedSince }
  },
  async write(pageId, patch, actor, _reason, meta) {
    const page = await loadPage(pageId)
    if (!page) throw new HistoryRefusal('It no longer exists')
    const user = actor.userId ? await prisma.user.findUnique({ where: { id: actor.userId }, select: { id: true, email: true } }) : null
    // Snapshot first (the page's own rule), recording what this restore does.
    const snapId = await recordPageRevision(page, 'restore', user ?? undefined, meta)
    await prisma.page.update({
      where: { id: pageId },
      data: {
        ...('title' in patch ? { title: String(patch.title) } : {}),
        ...('content' in patch ? { content: (patch.content ? safeContent(patch.content) : undefined) as object | undefined } : {}),
      },
    })
    // Per-page CSS for the restored content (only its pageCss key is written; failures logged).
    if ('content' in patch) await (await import('../ade-bindings/page-css')).refreshPageCss(pageId)
    if (page.status === 'PUBLISHED') {
      const { revalidateStorefront } = await import('../revalidate')
      revalidateStorefront()
    }
    const after = await versionsOf(pageId)
    return { revisionId: snapId, version: after?.versions.find((x) => x.id === snapId)?.version ?? null }
  },
})
