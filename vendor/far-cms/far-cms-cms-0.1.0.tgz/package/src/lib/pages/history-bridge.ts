// Moved to @far-cms/core (far-cms packages/core/src/lib/pages/history-bridge.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/pages/history-bridge'
