/**
 * The admin assistant request: cost limits, the request schema, message-text helpers, the chat title and
 * the attachment check. Moved verbatim from api/chat/route.ts on 2026-11-22 (size check).
 */
import { generateText } from 'ai';
import { z } from 'zod';
import { prisma } from '../db';
import { getAiSettings, getStorageSettings } from '../settings';
import { getTitleModel } from '../ai/providers';
import { admissionPayload, admitAiRequest, recordAiTokens } from '../ai/spend';
import { ChatSDKError } from './errors';
import { tokensFromUsage } from '../ai/spend-policy';
import { checkAttachmentParts } from '../ade/chat/attachments';
import { LEGACY_MEDIA_HOSTS, MEDIA_ORIGIN, toMediaDomain } from '../media/public-url';
import { chooseTitle } from '../ade/chat/history';

// ---------------------------------------------------------------------------
// Cost guardrails
//
// One prompt can trigger a multi-step tool loop; each step resends the full
// system prompt + history + tool schemas. These caps bound the worst case so a
// single request can't run away (observed: one prompt burning ~$20 of tokens).
// ---------------------------------------------------------------------------

/** Max model round-trips per user message (tool loop bound). */
export const MAX_AGENT_STEPS = 8;
/** Only the most recent messages are sent to the model; older turns drop off. */
export const MAX_HISTORY_MESSAGES = 30;
/** Reject requests whose combined text exceeds this many characters. */
export const MAX_INPUT_CHARS = 32_000;
/** Fallback per-user daily token ceiling when settings don't define one. */
export const DEFAULT_DAILY_TOKEN_BUDGET = 500_000;
/**
 * Hard token ceiling for a single request's tool loop (all steps combined).
 * The daily budget is only checked pre-flight, so without this a single
 * long agentic run could blow far past it before the next check.
 */
export const PER_REQUEST_TOKEN_CAP = 150_000;
/**
 * Hard ceiling on per-step output tokens; the settings value is clamped to it.
 * 16k so max effort (which thinks inside this cap) still has room to answer;
 * spend stays bounded by PER_REQUEST_TOKEN_CAP and the daily budget.
 */
export const MAX_OUTPUT_TOKENS_CEILING = 16_384;

// Role mapping for rate limit lookup
export type RateLimitRole = 'guest' | 'customer' | 'editor' | 'admin';
export function mapUserRole(role?: string): RateLimitRole {
  if (!role) return 'guest';
  switch (role.toUpperCase()) {
    case 'ADMIN': return 'admin';
    case 'EDITOR': return 'editor';
    case 'CUSTOMER': return 'customer';
    default: return 'guest';
  }
}

// Message part schema for AI SDK v6
export const messagePartSchema = z.union([
  z.object({ type: z.literal('text'), text: z.string() }),
  z.object({ type: z.literal('tool-invocation'), toolInvocation: z.any() }),
  z.object({ type: z.string(), text: z.string().optional() }).passthrough(),
]);

// Entity context schema (matches EntityContext from socket types)
// Using passthrough to allow extra fields and handle type coercion
export const entityContextSchema = z.object({
  route: z.string().optional(),
  section: z.string().optional(),
  entityType: z.string().nullable().optional(),
  entityId: z.string().nullable().optional(),
  parentContext: z.object({
    entityType: z.string(),
    entityId: z.string(),
  }).optional(),
  selectedIds: z.array(z.string()).optional(),
  filters: z.record(z.string(), z.unknown()).optional(),
  searchQuery: z.string().optional(),
  modalOpen: z.string().optional(),
  tabActive: z.string().optional(),
  timestamp: z.number().optional(),
  sessionId: z.string().optional(),
  availableHelpKeys: z.array(z.string()).optional(),
  // ADE split pane: storefront path shown in the live preview beside the agent.
  previewPath: z.string().max(300).optional(),
  // Workspace: what the person is editing on the right side, and what's selected.
  editing: z.object({
    pageId: z.string().max(100).optional(),
    title: z.string().max(200).optional(),
    selectedBlockId: z.string().max(100).nullable().optional(),
    selectedName: z.string().max(200).nullable().optional(),
    unsaved: z.boolean().optional(),
  }).optional(),
}).passthrough();

// Help click context (for help mode integration)
export const helpClickSchema = z.object({
  helpKey: z.string(),
  context: entityContextSchema.optional(),
});

// Request schema for AI SDK v6
export const requestSchema = z.object({
  id: z.string().optional(),
  messages: z.array(
    z.object({
      id: z.string(),
      role: z.enum(['user', 'assistant', 'system']),
      // AI SDK v6 uses parts instead of content
      parts: z.array(messagePartSchema).optional(),
      content: z.string().optional(), // Fallback for simpler format
      // A restored reply's saved metadata (its change refs): read only for this person's own drafts (loadDraftOutcomes).
      metadata: z.unknown().optional(),
    })
  ),
  selectedChatModel: z.string().optional(), // Model selected in chat UI
  // Legacy context format (for backwards compatibility)
  context: z
    .object({
      type: z.enum(['general', 'product', 'order', 'page', 'user', 'blog']),
      id: z.string().optional(),
      title: z.string().optional(),
      data: z.record(z.string(), z.unknown()).optional(),
    })
    .optional(),
  // New entity context format (from EntityContextProvider)
  entityContext: entityContextSchema.optional(),
  // Last help click (from help mode)
  lastHelpClick: helpClickSchema.optional(),
  // The workspace screen the person is on (lib/ade/screens key) — scopes operate_ui.
  uiScreen: z.string().max(40).regex(/^[a-z-]+$/).optional(),
  // The path the person is on when they send (view tools: never describe another screen's read).
  uiRoute: z.string().max(300).regex(/^\/[^\s]*$/).optional(),
  /** 'phone': the person is on the phone admin (bottom tabs, no sidebar). */
  uiLayout: z.enum(['phone']).optional(),
  // The chrome around the screen (mode, chat state, menu layout, sections): the context card. Checked, never fatal.
  uiShell: z.unknown().optional(),
  // The working screen's facts (lib/ade/ui/screen-context): checked when used, never fatal.
  uiScreenCtx: z.unknown().optional(),
  // The composer's Look only / Accept changes / Auto pick for this conversation: only a CHOICE, clamped on the server
  // to the person's ceiling (lib/ai/governance/agent-modes); anything unrecognised is ignored.
  agentMode: z.string().max(16).optional(),
  // The person's saved walk-through choice from their browser ('timer' | 'manual'); anything else is ignored, never fatal.
  walkAdvance: z.unknown().optional(),
  // What the assistant's previous UI steps actually did in the browser.
  uiReport: z.array(z.object({ capability: z.string().max(60), ok: z.boolean(), message: z.string().max(200) })).max(10).optional(),
  // Verified outcome of the agent's previous navigation (from nav-feedback).
  lastNavigation: z
    .object({
      requested: z.string(),
      actual: z.string(),
      success: z.boolean(),
    })
    .optional(),
});

// Helper to extract text from message parts
export function extractTextFromParts(parts?: Array<{ type: string; text?: string }>): string {
  if (!parts) return '';
  return parts
    .filter((p) => p.type === 'text' && p.text)
    .map((p) => p.text)
    .join('');
}

// Helper to get content from message (v6 format or fallback)
export function getMessageContent(message: { parts?: Array<{ type: string; text?: string }>; content?: string }): string {
  if (message.content) return message.content;
  return extractTextFromParts(message.parts);
}


// Generate a title from the first user message. Always uses the cheap title
// model — a 6-word title never needs the full conversation model.
export async function generateChatTitle(userMessage: string, userId: string): Promise<string> {
  try {
    const { text, usage } = await generateText({
      model: getTitleModel(),
      system: `Generate a very short (3-6 words) title summarizing this message. Do not use quotes or punctuation. Just output the title.`,
      prompt: userMessage.slice(0, 500),
      maxOutputTokens: 32,
    });
    await recordAiTokens(userId, tokensFromUsage(usage), 'chat-title');
    // The title model sometimes answers the message instead ("TWO", "I don't
    // have access…"): keep it only if it reads like a title.
    return chooseTitle(text, userMessage);
  } catch (error) {
    console.warn('[Chat] Failed to generate title:', error);
    return chooseTitle(null, userMessage);
  }
}

/**
 * File parts must be media-library files (known host AND a Media record) or
 * small inline screenshots. Returns a plain error, or null when all is well.
 */
export async function checkAttachments(messages: Array<{ role: string; parts?: Array<{ type: string; [k: string]: unknown }> }>): Promise<string | null> {
  if (!messages.some((m) => m.parts?.some((p) => p.type === 'file'))) return null;
  const storage = await getStorageSettings().catch(() => null);
  const hostOf = (u?: string) => {
    try {
      return u ? new URL(u).host : null;
    } catch {
      return null;
    }
  };
  const allowedHosts = [hostOf(MEDIA_ORIGIN), ...LEGACY_MEDIA_HOSTS, hostOf(storage?.publicUrl)].filter((h): h is string => !!h);
  const checked = checkAttachmentParts(messages, { allowedHosts });
  if (!checked.ok) return checked.error;
  if (checked.urls.length === 0) return null;
  // Stored URLs may be on the bucket's legacy host; match either form.
  const legacy = (u: string) => LEGACY_MEDIA_HOSTS.map((h) => u.replace(new URL(MEDIA_ORIGIN).host, h));
  const rows = await prisma.media.findMany({
    where: { url: { in: checked.urls.flatMap((u) => [u, ...legacy(u)]) }, deletedAt: null },
    select: { url: true },
  });
  const known = new Set(rows.map((r) => toMediaDomain(r.url)));
  return checked.urls.every((u) => known.has(toMediaDomain(u))) ? null : 'An attachment isn’t in the media library — attach it again.';
}

/**
 * May this person send a message now? The daily message limit for their role, then the spend ceiling
 * (fails closed). Moved from POST on 2026-11-22 (size check); same checks, same answers.
 */
export async function chatAllowance(
  userId: string,
  role: string | undefined,
  settings: Awaited<ReturnType<typeof getAiSettings>>,
): Promise<{ refusal: Response } | { remainingDailyTokens: number; dailyTokenBudget: number }> {
  const userRole = mapUserRole(role);
  const dailyLimit = settings.rateLimits?.[userRole] ?? settings.rateLimits?.customer ?? 200;

  // Guest with 0 limit = AI disabled for guests
  if (dailyLimit === 0 && userRole === 'guest') {
    return { refusal: ChatSDKError.unauthorized('Authentication required to use AI chat').toResponse() };
  }

  // 0 = unlimited (for admin)
  if (dailyLimit > 0) {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const messageCount = await prisma.aiMessage.count({
      where: {
        conversation: { userId: userId },
        createdAt: { gte: oneDayAgo },
      },
    });

    if (messageCount >= dailyLimit) {
      return { refusal: ChatSDKError.rateLimit(
        `Daily message limit reached (${dailyLimit} messages/day for ${userRole} role). Please try again tomorrow.`
      ).toResponse() };
    }
  }

  // Spend ceiling: message counts don't bound cost (one message can run a
  // full tool loop), so enforce a token budget for every role — including
  // admin — per AI_BUDGET_WINDOW_HOURS session window, plus the site-wide
  // ceiling. 0 disables the per-user budget. Fails CLOSED for everyone:
  // unverifiable spend must not mean unlimited spend.
  const dailyTokenBudget = settings.dailyTokenBudget ?? DEFAULT_DAILY_TOKEN_BUDGET;
  const admission = await admitAiRequest(userId, dailyTokenBudget);
  if (!admission.ok) {
    const payload = admissionPayload(admission, dailyTokenBudget);
    // ChatSDKError body shape ({ error: code, message }) plus reset info.
    return {
      refusal: Response.json(
        { ...payload, error: admission.status === 429 ? 'rate_limit:chat' : 'offline:chat', message: payload.error },
        { status: admission.status }
      ),
    };
  }
  return { remainingDailyTokens: admission.remainingTokens, dailyTokenBudget };
}

/** A new conversation's title, from the person's first message (the cheap title model). */
export async function saveChatTitle(conversationId: string, userContent: string, userId: string): Promise<void> {
  const title = await generateChatTitle(userContent, userId);
  await prisma.aiConversation.update({ where: { id: conversationId }, data: { title } });
}
