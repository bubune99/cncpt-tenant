/**
 * Chat State Store (Zustand)
 *
 * Global state management for the admin chat panel.
 * Persists across route changes within the admin panel.
 */

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { browserLocal, browserSession, splitStorage } from '../ade/chat/tab-storage';
import type { ChatMessage } from './types';
import { retireDrawerMode } from '../ade/ui/dock-side';

// 'split' = the ADE studio layout: agent pane beside a live page preview.
export type ChatPanelMode = 'collapsed' | 'minimized' | 'side' | 'full' | 'split';

export interface ChatContext {
  type: 'general' | 'product' | 'order' | 'page' | 'user' | 'blog';
  id?: string;
  title?: string;
  data?: Record<string, unknown>;
}

interface ChatState {
  // Panel state
  mode: ChatPanelMode;
  /** The assistant was opened during this page's life (never saved; lib/ade/ui/split closesOnFloating). */
  openedThisPage: boolean;
  setMode: (mode: ChatPanelMode) => void;
  togglePanel: () => void;
  minimizePanel: () => void;
  expandPanel: () => void;

  // Current conversation
  conversationId: string | null;
  messages: ChatMessage[];
  isLoading: boolean;
  error: string | null;

  // Context awareness
  context: ChatContext;
  setContext: (context: ChatContext) => void;

  // Message actions
  addMessage: (message: ChatMessage) => void;
  updateMessage: (id: string, updates: Partial<ChatMessage>) => void;
  setMessages: (messages: ChatMessage[]) => void;
  clearMessages: () => void;

  // Conversation actions
  setConversationId: (id: string | null) => void;
  startNewConversation: () => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;

  // History
  conversationHistory: Array<{
    id: string;
    title: string;
    lastMessage: string;
    updatedAt: Date;
    context?: ChatContext;
  }>;
  addToHistory: (conversation: { id: string; title: string; lastMessage: string; context?: ChatContext }) => void;
  removeFromHistory: (id: string) => void;
  loadConversation: (id: string) => void;
  clearHistory: () => void;
}

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      // Panel state
      // One assistant layout: open = the agent-first column on the person's side
      // (lib/ade/ui/dock-side retireDrawerMode — the old drawer modes map to it).
      mode: 'collapsed',
      openedThisPage: false,
      setMode: (mode) => {
        const next = retireDrawerMode(mode);
        set(next === 'collapsed' ? { mode: next } : { mode: next, openedThisPage: true });
      },
      togglePanel: () => {
        const open = get().mode === 'collapsed';
        set(open ? { mode: 'split', openedThisPage: true } : { mode: 'collapsed' });
      },
      minimizePanel: () => {
        set({ mode: 'collapsed' });
      },
      expandPanel: () => {
        set({ mode: 'split', openedThisPage: true });
      },

      // Current conversation
      conversationId: null,
      messages: [],
      isLoading: false,
      error: null,

      // Context
      context: { type: 'general' },
      setContext: (context) => set({ context }),

      // Message actions
      addMessage: (message) =>
        set((state) => ({
          messages: [...state.messages, message],
        })),
      updateMessage: (id, updates) =>
        set((state) => ({
          messages: state.messages.map((msg) =>
            msg.id === id ? { ...msg, ...updates } : msg
          ),
        })),
      setMessages: (messages) => set({ messages }),
      clearMessages: () => set({ messages: [] }),

      // Conversation actions
      setConversationId: (id) => set({ conversationId: id }),
      startNewConversation: () => {
        const newId = crypto.randomUUID();
        set({
          conversationId: newId,
          messages: [],
          error: null,
        });
      },
      setLoading: (isLoading) => set({ isLoading }),
      setError: (error) => set({ error }),

      // History
      conversationHistory: [],
      addToHistory: (conversation) =>
        set((state) => {
          // Remove existing entry if present, add to top
          const filtered = state.conversationHistory.filter(
            (c) => c.id !== conversation.id
          );
          return {
            conversationHistory: [
              { ...conversation, updatedAt: new Date() },
              ...filtered,
            ].slice(0, 50), // Keep last 50 conversations
          };
        }),
      removeFromHistory: (id) =>
        set((state) => ({
          conversationHistory: state.conversationHistory.filter(
            (c) => c.id !== id
          ),
        })),
      loadConversation: (id) => {
        const history = get().conversationHistory.find((c) => c.id === id);
        if (history) {
          set({
            conversationId: id,
            messages: [], // Messages will be loaded from the useChat hook via transport
            error: null,
            context: history.context || { type: 'general' },
          });
        }
      },
      clearHistory: () => set({ conversationHistory: [] }),
    }),
    {
      name: 'admin-chat-storage',
      // The active conversation is per browser tab (sessionStorage); panel
      // mode and the history list are shared (localStorage). A new tab starts
      // its own conversation instead of posting into another tab's.
      storage: createJSONStorage(() => splitStorage(browserLocal, browserSession, ['conversationId'])),
      // SECURITY: Do not persist messages or full conversation data in
      // localStorage. Messages may contain sensitive admin/user/order data
      // and localStorage is accessible to any JS on the same origin.
      // Only UI-state and conversation metadata (titles, IDs) are stored.
      // Stored 'side' / 'full' / 'minimized' from before the drawer was retired.
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<ChatState>;
        return { ...current, ...p, mode: retireDrawerMode((p.mode ?? current.mode) as ChatPanelMode) };
      },
      partialize: (state) => ({
        mode: state.mode,
        conversationId: state.conversationId,
        // Messages are intentionally excluded — they are reloaded from the
        // server via the useChat transport when a conversation is opened.
        conversationHistory: state.conversationHistory.map(({ id, title, updatedAt, context }) => ({
          id,
          title,
          lastMessage: '', // strip message preview from storage
          updatedAt,
          context,
        })),
      }),
    }
  )
);

// Selector hooks for common patterns
export const useChatPanel = () => {
  const mode = useChatStore((s) => s.mode);
  const setMode = useChatStore((s) => s.setMode);
  const togglePanel = useChatStore((s) => s.togglePanel);
  const minimizePanel = useChatStore((s) => s.minimizePanel);
  const expandPanel = useChatStore((s) => s.expandPanel);
  return { mode, setMode, togglePanel, minimizePanel, expandPanel };
};

export const useChatMessages = () => {
  const messages = useChatStore((s) => s.messages);
  const addMessage = useChatStore((s) => s.addMessage);
  const updateMessage = useChatStore((s) => s.updateMessage);
  const setMessages = useChatStore((s) => s.setMessages);
  const clearMessages = useChatStore((s) => s.clearMessages);
  return { messages, addMessage, updateMessage, setMessages, clearMessages };
};

export const useChatContext = () => {
  const context = useChatStore((s) => s.context);
  const setContext = useChatStore((s) => s.setContext);
  return { context, setContext };
};
