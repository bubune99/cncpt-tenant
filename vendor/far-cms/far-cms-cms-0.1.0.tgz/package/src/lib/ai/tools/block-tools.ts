/**
 * Block Tools — block-granular page editing for AI agents
 *
 * The pages are className-driven Block[] JSON, so agents edit them the way
 * the builder does: address ONE block by its stable id and patch className /
 * textContent / attrs — never replace whole page content (the failure mode
 * this design exists to prevent).
 *
 * Every mutation purges the storefront cache (revalidateStorefront), so an
 * edit to a PUBLISHED page is visible immediately — an external MCP client
 * can edit, then verify with screenshot_page in the same conversation.
 *
 * Shared by the admin chat agent (Kofi) and the MCP registry adapter —
 * single source of truth per the platform-MCP design decision.
 */

import { safeContent } from '../../block-editor/content-safety';
import { tool } from 'ai';
import { z } from 'zod';
import { KNOWN_TAGS } from '../../block-editor/types';
import { revalidateStorefront } from '../../revalidate';
import { recordPageRevision } from '../../pages/revisions';
import { noteVersionMissing, versionRequired } from '../../ade-bindings/revision-capture';
import { applyBlockInsert, applyBlockMove, applyBlockRemove, applyBlockUpdate, type BlockNode, type PageContent } from './block-ops';

const MAX_OUTLINE_BLOCKS = 400;
const MAX_CLASSNAME_LENGTH = 2000;
const MAX_TEXT_LENGTH = 5000;

async function getDb() {
  const { prisma } = await import('../../db');
  return prisma;
}

/** Resolve a page by id, or by slug with/without the leading slash. */
export async function resolvePage(idOrSlug: string) {
  const prisma = await getDb();
  const bySlugVariants = [idOrSlug, `/${idOrSlug}`.replace(/^\/\//, '/')];
  return prisma.page.findFirst({
    where: {
      OR: [{ id: idOrSlug }, { slug: { in: bySlugVariants } }],
    },
    select: { id: true, slug: true, title: true, status: true, content: true },
  });
}

function outline(blocks: BlockNode[] | undefined, depth: number, out: unknown[]): void {
  for (const b of blocks || []) {
    if (out.length >= MAX_OUTLINE_BLOCKS) return;
    out.push({
      id: b.id,
      depth,
      tag: b.tag,
      label: b.label || undefined,
      className: b.className || '',
      text: b.textContent ? b.textContent.slice(0, 80) : undefined,
      hidden: b.hidden || undefined,
      locked: b.locked || undefined,
      componentName: b.componentName || undefined,
      partialId: b.partialId || undefined,
      childCount: b.children?.length || 0,
    });
    outline(b.children, depth + 1, out);
  }
}

function countBlocks(blocks: BlockNode[] | undefined): number {
  return (blocks || []).reduce((n, b) => n + 1 + countBlocks(b.children), 0);
}

async function savePageContent(pageId: string, content: PageContent, status: string) {
  const prisma = await getDb();
  // Snapshot before the AI edit so a person can restore it (Revisions).
  const before = await prisma.page.findUnique({
    where: { id: pageId },
    select: { id: true, title: true, slug: true, status: true, content: true },
  });
  const snap = before ? await recordPageRevision(before, 'ai-edit') : null;
  // An Auto edit must leave a version Undo can restore: no snapshot, no live write (it falls back to a draft).
  if (before && !snap && versionRequired()) {
    noteVersionMissing();
    throw new Error('No version could be saved for this page, so the change was not made live.');
  }
  await prisma.page.update({
    where: { id: pageId },
    data: { content: safeContent(content) as object },
  });
  // Per-page CSS for the edited content (only its pageCss key is written; failures logged).
  await (await import('../../ade-bindings/page-css')).refreshPageCss(pageId);
  // Published pages serve from ISR cache — purge so the edit is live now,
  // not after the 5-minute revalidate window.
  if (status === 'PUBLISHED') revalidateStorefront();
}

export const getPageBlocks = tool({
  description:
    "Read a page's block tree as a flat outline (id, depth, tag, className, trimmed text, label, child count). Use it to locate the block to edit, then call updateBlock with the block's id. Pages are addressed by id or slug.",
  inputSchema: z.object({
    page: z.string().describe("Page id or slug (e.g. '/home' or 'home')"),
  }),
  execute: async ({ page: idOrSlug }) => {
    try {
      const page = await resolvePage(idOrSlug);
      if (!page) return { success: false, error: `Page not found: ${idOrSlug}` };
      const content = (page.content || {}) as PageContent;
      const blocks: unknown[] = [];
      outline(content.blocks, 0, blocks);
      const total = countBlocks(content.blocks);
      return {
        success: true,
        page: { id: page.id, slug: page.slug, title: page.title, status: page.status },
        blocks,
        total,
        truncated: total > blocks.length || undefined,
      };
    } catch (error) {
      console.error('[BlockTools] getPageBlocks error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to read blocks' };
    }
  },
});

const attrsSchema = z
  .record(z.string().max(64), z.string().max(2000).nullable())
  .optional()
  .describe('HTML attributes to merge; a null value removes that attribute');

export const updateBlock = tool({
  description:
    'Patch ONE block on a page by its block id (from getPageBlocks): className (full Tailwind string replaces the old one), textContent, attrs (merged; null removes), label, hidden. Only provided fields change. The result says whether the edit went live or was held for review (drafted: true, approved by a person in Admin → To-do) — verify with screenshot_page (version "draft" for a held edit). Locked blocks are refused. A block BOUND to a record field (data-record + data-field) edits the RECORD instead, so every page showing it updates.',
  inputSchema: z.object({
    page: z.string().describe('Page id or slug'),
    blockId: z.string().describe('The block id from getPageBlocks'),
    className: z.string().max(MAX_CLASSNAME_LENGTH).optional().describe('New full className (replaces existing)'),
    textContent: z.string().max(MAX_TEXT_LENGTH).optional(),
    attrs: attrsSchema,
    label: z.string().max(120).optional().describe('Editor-only display name'),
    hidden: z.boolean().optional().describe('Hide/show the block without deleting it'),
  }),
  execute: async ({ page: idOrSlug, blockId, className, textContent, attrs, label, hidden }) => {
    try {
      const page = await resolvePage(idOrSlug);
      if (!page) return { success: false, error: `Page not found: ${idOrSlug}` };
      const result = applyBlockUpdate(page.content, { blockId, className, textContent, attrs, label, hidden });
      if ('error' in result) return { success: false, error: result.error };
      const { content, changed } = result;

      await savePageContent(page.id, content, page.status);
      return {
        success: true,
        blockId,
        changed,
        pageStatus: page.status,
        message:
          page.status === 'PUBLISHED'
            ? `Block updated and live at ${page.slug} (cache purged). Verify with screenshot_page.`
            : `Block updated on ${page.status} page ${page.slug}.`,
      };
    } catch (error) {
      console.error('[BlockTools] updateBlock error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to update block' };
    }
  },
});

export const insertBlock = tool({
  description:
    'Insert a NEW block into a page: under a parent block (from getPageBlocks) or at page root, at an optional index (default: append). One block per call — nest by inserting into the new block next. Undo by updateBlock hidden:true.',
  inputSchema: z.object({
    page: z.string().describe('Page id or slug'),
    parentBlockId: z.string().optional().describe('Parent block id; omit for page root'),
    index: z.number().int().min(0).optional().describe('Position among siblings (default: append)'),
    tag: z.enum(KNOWN_TAGS).describe('HTML element for the block'),
    className: z.string().max(MAX_CLASSNAME_LENGTH).optional().describe('Tailwind classes'),
    textContent: z.string().max(MAX_TEXT_LENGTH).optional(),
    attrs: attrsSchema,
    label: z.string().max(120).optional(),
  }),
  execute: async ({ page: idOrSlug, parentBlockId, index, tag, className, textContent, attrs, label }) => {
    try {
      const page = await resolvePage(idOrSlug);
      if (!page) return { success: false, error: `Page not found: ${idOrSlug}` };
      const result = applyBlockInsert(page.content, { parentBlockId, index, tag, className, textContent, attrs, label });
      if ('error' in result) return { success: false, error: result.error };
      const { content, newBlock, at } = result;

      await savePageContent(page.id, content, page.status);
      return {
        success: true,
        blockId: newBlock.id,
        insertedAt: at,
        parent: parentBlockId || 'root',
        pageStatus: page.status,
        message:
          page.status === 'PUBLISHED'
            ? `Block inserted and live at ${page.slug} (cache purged). Verify with screenshot_page.`
            : `Block inserted on ${page.status} page ${page.slug}.`,
      };
    } catch (error) {
      console.error('[BlockTools] insertBlock error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to insert block' };
    }
  },
});

export const removeBlock = tool({
  description:
    'Remove ONE block (and everything inside it) from a page, by its block id (from getPageBlocks). Locked blocks are refused. To hide a block without deleting it, use updateBlock hidden:true instead.',
  inputSchema: z.object({
    page: z.string().describe('Page id or slug'),
    blockId: z.string().describe('The block id from getPageBlocks'),
  }),
  execute: async ({ page: idOrSlug, blockId }) => {
    try {
      const page = await resolvePage(idOrSlug);
      if (!page) return { success: false, error: `Page not found: ${idOrSlug}` };
      const result = applyBlockRemove(page.content, { blockId });
      if ('error' in result) return { success: false, error: result.error };
      await savePageContent(page.id, result.content, page.status);
      return { success: true, blockId, pageStatus: page.status, message: `Block removed from ${page.slug}.` };
    } catch (error) {
      console.error('[BlockTools] removeBlock error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to remove block' };
    }
  },
});

export const moveBlock = tool({
  description:
    'Move ONE block (with its children) to another place on the same page: under a parent block (from getPageBlocks) or to the page root, at an optional index among the new siblings (counted after the block is taken out; default: append). A block cannot be moved inside itself.',
  inputSchema: z.object({
    page: z.string().describe('Page id or slug'),
    blockId: z.string().describe('The block id to move'),
    parentBlockId: z.string().optional().describe('New parent block id; omit for page root'),
    index: z.number().int().min(0).optional().describe('Position among the new siblings (default: append)'),
  }),
  execute: async ({ page: idOrSlug, blockId, parentBlockId, index }) => {
    try {
      const page = await resolvePage(idOrSlug);
      if (!page) return { success: false, error: `Page not found: ${idOrSlug}` };
      const result = applyBlockMove(page.content, { blockId, parentBlockId, index });
      if ('error' in result) return { success: false, error: result.error };
      await savePageContent(page.id, result.content, page.status);
      return { success: true, blockId, parent: parentBlockId || 'root', at: result.at, pageStatus: page.status, message: `Block moved on ${page.slug}.` };
    } catch (error) {
      console.error('[BlockTools] moveBlock error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to move block' };
    }
  },
});

// ---------------------------------------------------------------------------
// Site header / footer (site-wide block documents in SiteSettings)
// ---------------------------------------------------------------------------

const layoutPartSchema = z.enum(['header', 'footer']).describe('Which site-wide part: header or footer');

async function readLayout(part: 'header' | 'footer') {
  const { getOrCreateSiteSettings } = await import('../../site-settings');
  const settings = await getOrCreateSiteSettings();
  return (settings[part] ?? null) as PageContent | null;
}

async function saveLayout(part: 'header' | 'footer', content: PageContent) {
  const { updateSiteSettings } = await import('../../site-settings');
  await updateSiteSettings({ [part]: content as Record<string, unknown> });
  revalidateStorefront();
}

export const getSiteLayoutBlocks = tool({
  description:
    "Read the SITE-WIDE header or footer as a flat block outline (same shape as getPageBlocks). Use it to locate a block, then updateSiteLayoutBlock / insertSiteLayoutBlock. Changes affect every page.",
  inputSchema: z.object({ part: layoutPartSchema }),
  execute: async ({ part }) => {
    try {
      const content = await readLayout(part);
      const blocks: unknown[] = [];
      outline(content?.blocks, 0, blocks);
      return { success: true, part, blocks, total: countBlocks(content?.blocks) };
    } catch (error) {
      console.error('[BlockTools] getSiteLayoutBlocks error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to read layout' };
    }
  },
});

export const updateSiteLayoutBlock = tool({
  description:
    'Patch ONE block in the SITE-WIDE header or footer (same fields as updateBlock). Affects every page. Usually held for review first.',
  inputSchema: z.object({
    part: layoutPartSchema,
    blockId: z.string(),
    className: z.string().max(MAX_CLASSNAME_LENGTH).optional(),
    textContent: z.string().max(MAX_TEXT_LENGTH).optional(),
    attrs: attrsSchema,
    label: z.string().max(120).optional(),
    hidden: z.boolean().optional(),
  }),
  execute: async ({ part, blockId, className, textContent, attrs, label, hidden }) => {
    try {
      const result = applyBlockUpdate(await readLayout(part), { blockId, className, textContent, attrs, label, hidden });
      if ('error' in result) return { success: false, error: result.error };
      await saveLayout(part, result.content);
      return { success: true, part, blockId, changed: result.changed, message: `Site ${part} updated (live on every page).` };
    } catch (error) {
      console.error('[BlockTools] updateSiteLayoutBlock error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to update layout' };
    }
  },
});

export const insertSiteLayoutBlock = tool({
  description:
    'Insert a NEW block into the SITE-WIDE header or footer (same fields as insertBlock). Affects every page. Usually held for review first.',
  inputSchema: z.object({
    part: layoutPartSchema,
    parentBlockId: z.string().optional(),
    index: z.number().int().min(0).optional(),
    tag: z.enum(KNOWN_TAGS),
    className: z.string().max(MAX_CLASSNAME_LENGTH).optional(),
    textContent: z.string().max(MAX_TEXT_LENGTH).optional(),
    attrs: attrsSchema,
    label: z.string().max(120).optional(),
  }),
  execute: async ({ part, parentBlockId, index, tag, className, textContent, attrs, label }) => {
    try {
      const result = applyBlockInsert(await readLayout(part), { parentBlockId, index, tag, className, textContent, attrs, label });
      if ('error' in result) return { success: false, error: result.error };
      await saveLayout(part, result.content);
      return { success: true, part, blockId: result.newBlock.id, insertedAt: result.at };
    } catch (error) {
      console.error('[BlockTools] insertSiteLayoutBlock error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Failed to insert into layout' };
    }
  },
});

export const blockTools = {
  getPageBlocks,
  updateBlock,
  insertBlock,
  removeBlock,
  moveBlock,
  getSiteLayoutBlocks,
  updateSiteLayoutBlock,
  insertSiteLayoutBlock,
};
