/**
 * generateImage for the main assistant: makes a picture and saves it to the media library
 * (media.upload), charged against the per-person daily image cap (lib/ai/image-gate). It does not
 * touch any page: placing it is a separate insertBlock, which is drafted to To-do like any edit.
 * The generator is injected so checks never spend. Check: lib/ai/image-gate.assert.ts.
 */
import { tool } from 'ai'
import { z } from 'zod'
import type { ImageGate } from '../image-gate'

export type ImageGenerator = (p: { prompt: string; style?: string; aspectRatio?: string }) => Promise<{ url: string; mediaId: string }>

export function makeAssistantImageTool(gate: ImageGate, generate: ImageGenerator) {
  return tool({
    description:
      'Generate a new picture with AI and save it to the media library. Each one counts against a daily limit per person, so first check the library (search_media) when an existing picture could do. ' +
      'Be specific: subject, composition, lighting, mood, colors, style. It does NOT place the picture on a page: to show it, call insertBlock with tag "img" and attrs { src: <url>, alt: <alt> } (that is drafted for approval).',
    inputSchema: z.object({
      prompt: z.string().min(3).max(2000).describe('What the picture shows, in detail'),
      style: z.string().optional().describe('photo, illustration, 3d-render, abstract, flat-design, watercolor, cinematic'),
      aspectRatio: z.enum(['16:9', '1:1', '4:3', '3:4', '9:16']).optional().describe('Default 16:9'),
      alt: z.string().max(300).optional().describe('Words that describe the picture for people who cannot see it'),
    }),
    execute: async ({ prompt, style, aspectRatio, alt }) => {
      const admitted = await gate()
      if (!admitted.ok) {
        return { success: false, error: `No picture was made: ${admitted.message} Tell the person, and do not try again in this reply.` }
      }
      try {
        const made = await generate({ prompt, style, aspectRatio: aspectRatio ?? '16:9' })
        return {
          success: true,
          url: made.url,
          mediaId: made.mediaId,
          alt: alt ?? prompt.slice(0, 200),
          message: 'Saved to the media library. To show it on a page, insertBlock an img with this url as src.',
        }
      } catch (e) {
        console.error('[Assistant] generateImage failed:', e instanceof Error ? e.message : e)
        return { success: false, error: 'The picture could not be made right now. Tell the person; do not retry in this reply.' }
      }
    },
  })
}
