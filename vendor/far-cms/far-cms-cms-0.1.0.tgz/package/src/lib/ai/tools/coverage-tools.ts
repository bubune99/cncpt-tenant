/**
 * coverage_check — "what on this screen can the assistant do, and what's
 * hidden?" Runs in the browser (no server execute, like read_view): walks the
 * screen read-only (opens tabs, sections and menus — never saves), maps it to
 * the platform and the assistant's tools, stores one coverage row + To-do
 * item for the route, and returns the three lists.
 */
import { tool } from 'ai'
import { z } from 'zod'

export const coverageCheckTool = tool({
  description:
    'Coverage check of the admin screen the person has open: opens every tab, section and menu (view-only, never saves), then reports three lists — things on screen the assistant has no tool for, things the assistant can do here that the screen shows no way to do, and things only reachable through hidden UI (good tour material) — plus a short walk-through of one hidden control. Use when the owner asks what you can or can\'t do on this screen, or to "check coverage". Stores the result as a To-do item for the route.',
  inputSchema: z.object({}),
})

export const coverageTools = { coverage_check: coverageCheckTool }
