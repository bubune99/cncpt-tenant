/**
 * load_tools — the assistant's way to turn on more tool groups mid-task.
 *
 * It has no side effects: it only reveals tools governance already let
 * through for this user (the route's prepareStep reads these calls and widens
 * activeTools). Its description is static, so it is part of the cached prefix.
 */
import { tool } from 'ai'
import { z } from 'zod'
import { GROUP_ORDER, groupCatalogue, type ToolGroupKey } from '../toolsets'

export function loadToolsTool(available: (groups: ToolGroupKey[]) => Record<string, string[]>) {
  return tool({
    description:
      'Turn on more tools. You start with the core tools (navigate, search, read the screen, spotlight). ' +
      'Before creating, editing or publishing anything, load the group that does it — loaded groups stay on for the rest of the conversation. ' +
      'Load several at once if the task spans them. Groups:\n' +
      groupCatalogue(),
    inputSchema: z.object({
      groups: z.array(z.enum(GROUP_ORDER as unknown as [ToolGroupKey, ...ToolGroupKey[]])).min(1).max(GROUP_ORDER.length),
    }),
    execute: async ({ groups }) => {
      const tools = available(groups)
      const missing = groups.filter((g) => !tools[g]?.length)
      return {
        loaded: groups.filter((g) => tools[g]?.length),
        tools,
        ...(missing.length ? { unavailable: missing, note: 'Not available to this person (policy or permissions) — say so rather than trying another way.' } : {}),
      }
    },
  })
}

/** load_tools calls recorded in UI-message history (parts typed "tool-load_tools"). */
export function loadCallsFromHistory(
  messages: ReadonlyArray<{ parts?: ReadonlyArray<{ type: string; input?: unknown }> }>,
): Array<{ toolName: string; input: unknown }> {
  const out: Array<{ toolName: string; input: unknown }> = []
  for (const m of messages) for (const p of m.parts ?? []) if (p.type === 'tool-load_tools') out.push({ toolName: 'load_tools', input: p.input })
  return out
}
