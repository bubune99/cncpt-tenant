/**
 * Google's official Gmail MCP server as the person's own tools
 * (https://gmailmcp.googleapis.com/mcp/v1, streamable HTTP, OAuth bearer —
 * developers.google.com/workspace/guides/configure-mcp-servers). A
 * Developer Preview: on only with GOOGLE_GMAIL_MCP=1, once the owner's
 * Google Cloud project is in the preview and the Gmail MCP API is enabled.
 *
 * The server's own schemas are used as-is (we don't guess its arguments);
 * only the tools in GMAIL_MCP_TOOLS pass through, under email_gmail_* names,
 * with our labels, untrusted marking, recipient check and sealing. It has
 * no send: sending stays email_send_draft (Gmail API) behind approval.
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js'
import { dynamicTool, jsonSchema, type ToolSet } from 'ai'
import { GMAIL_MCP_TOOLS, UNTRUSTED_NOTICE, gmailMcpToolName } from '../../ade/connectors'

export const GMAIL_MCP_URL = 'https://gmailmcp.googleapis.com/mcp/v1'

type ServerTool = { name: string; inputSchema?: Record<string, unknown> }
// Input schemas only (never mailbox data, never the server's descriptions), per granted-scope set, for an hour.
const schemaCache = new Map<string, { at: number; tools: ServerTool[] }>()

async function withClient<T>(token: string, fn: (c: Client) => Promise<T>): Promise<T> {
  const client = new Client({ name: 'dzidzor-cms', version: '1.0.0' })
  const transport = new StreamableHTTPClientTransport(new URL(GMAIL_MCP_URL), { requestInit: { headers: { Authorization: `Bearer ${token}` } } })
  await client.connect(transport)
  try {
    return await fn(client)
  } finally {
    await client.close().catch(() => {})
  }
}

export const gmailMcpEnabled = () => process.env.GOOGLE_GMAIL_MCP === '1'

/**
 * The read-only pass-through tools for this person, or {} when the server
 * can't be reached (the Gmail API tools still work). Descriptions are ours
 * (GMAIL_MCP_TOOLS); only the input schema comes from the server.
 */
export async function gmailMcpTools(accessToken: () => Promise<string>, grantedScopes: readonly string[]): Promise<ToolSet> {
  const cacheKey = [...grantedScopes].sort().join(' ')
  let tools: ServerTool[]
  try {
    const hit = schemaCache.get(cacheKey)
    if (hit && Date.now() - hit.at < 3_600_000) tools = hit.tools
    else {
      const listed = await withClient(await accessToken(), (c) => c.listTools())
      tools = (listed.tools as Array<ServerTool & { description?: string }>).map((t) => ({ name: t.name, inputSchema: t.inputSchema }))
      schemaCache.set(cacheKey, { at: Date.now(), tools })
    }
  } catch (e) {
    console.warn('[email-mcp] Gmail MCP unavailable:', e instanceof Error ? e.name : 'error')
    return {}
  }
  const out: ToolSet = {}
  for (const t of tools) {
    if (!Object.hasOwn(GMAIL_MCP_TOOLS, t.name)) continue
    out[gmailMcpToolName(t.name)] = dynamicTool({
      description: `${GMAIL_MCP_TOOLS[t.name as keyof typeof GMAIL_MCP_TOOLS]} Read-only. ${UNTRUSTED_NOTICE}`,
      inputSchema: jsonSchema((t.inputSchema ?? { type: 'object' }) as Parameters<typeof jsonSchema>[0]),
      execute: async (input) => {
        try {
          const result = await withClient(await accessToken(), (c) => c.callTool({ name: t.name, arguments: (input ?? {}) as Record<string, unknown> }))
          return { success: !result.isError, untrusted: true, notice: UNTRUSTED_NOTICE, content: result.content }
        } catch {
          return { success: false, error: 'Gmail didn’t answer. Try again.' }
        }
      },
    })
  }
  return out
}
