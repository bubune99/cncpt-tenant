/**
 * The block library as the assistant's building blocks (R23, playbook 19a).
 *   find_blocks      look up Saved blocks, starting layouts (Sections) and Ideas
 *   suggest_layouts  4–6 idea layouts for a goal (placeholder words, never stored)
 *   add_block        place one on a page — DRAFTED (lib/ade-bindings/block-drafters)
 *   save_block       keep a section as a saved block — DRAFTED, managers only
 * Preference: Saved → Sections → Ideas → new markup. add_block / save_block run
 * only through the drafting hook (the governance layer drafts them); their own
 * execute refuses, so they can never write directly.
 */

import { tool } from 'ai'
import { z } from 'zod'
import { findBlocks, ideasFor, LIBRARY_LIMITS, pickBlock } from '../../ade/blocks/library'
import { generateId } from '../../block-editor/tree-utils'
import { IDEA_THEME } from '../../ade-bindings/block-library'
import { libraryCatalog } from '../../ade-bindings/block-library-server'

const DRAFT_ONLY = { success: false, error: 'Blocks are added and saved as drafts for review — this runs through the review queue.' }

export const findBlocksTool = tool({
  description:
    'Find blocks to build with, BEFORE writing any markup. Order of preference: the site owner’s Saved blocks, then Sections (starting layouts), then Ideas (suggest_layouts). Returns ids for add_block, with usage (pages using a saved block) and its mode (linked/copy).',
  inputSchema: z.object({
    query: z.string().max(120).optional().describe('What it is for, e.g. "call to action", "hero", "newsletter"'),
    shelf: z.enum(['saved', 'sections', 'ideas']).optional(),
    category: z.string().max(40).optional(),
    limit: z.number().int().min(1).max(LIBRARY_LIMITS.findMax).optional(),
  }),
  execute: async ({ query, shelf, category, limit }) => {
    const catalog = await libraryCatalog()
    const blocks = findBlocks(catalog, { query, shelf, category, limit })
    const pick = query ? pickBlock(catalog, query) : null
    return {
      blocks,
      ...(pick?.kind === 'use' ? { suggested: pick.block.id, note: pick.note } : {}),
      ...(pick?.kind === 'ask' ? { ask: pick.question, options: pick.options.map((o) => ({ id: o.id, name: o.name })) } : {}),
      ...(pick?.kind === 'none' ? { note: pick.note } : {}),
    }
  },
})

export const suggestLayoutsTool = tool({
  description: 'Ideas for a goal (e.g. "a call to action for the winter appeal"): 4–6 layouts in the site’s style with placeholder words. Nothing is saved; add one with add_block({ ideaId }).',
  inputSchema: z.object({
    goal: z.string().min(2).max(120),
    count: z.number().int().min(1).max(LIBRARY_LIMITS.ideasMax).optional(),
  }),
  execute: async ({ goal, count }) => ({
    ideas: ideasFor(goal, count ?? LIBRARY_LIMITS.ideasDefault, IDEA_THEME, generateId).map((i) => ({ ideaId: i.id, name: i.name, summary: i.summary })),
    note: 'Ideas use placeholder words — fill them from what the person told you after adding.',
  }),
})

export const addBlockTool = tool({
  description:
    'Add a block from the library to a page, as a DRAFT. blockId from find_blocks or ideaId from suggest_layouts. A saved block is linked (stays in step with the saved design) unless mode is "copy". overrides change THIS copy’s words, picture and link only — never the saved block. Say in one line which block you used and whether it is linked or a copy.',
  inputSchema: z.object({
    page: z.string().describe('Page id or slug'),
    blockId: z.string().max(120).optional(),
    ideaId: z.string().max(120).optional(),
    position: z.object({ after: z.string().max(120).optional(), at: z.number().int().min(0).optional() }).optional().describe('After a section (block id) or at an index; default the end'),
    mode: z.enum(['linked', 'copy']).optional(),
    overrides: z
      .object({ text: z.string().max(200).optional(), body: z.string().max(600).optional(), image: z.string().max(2000).optional(), link: z.string().max(2000).optional(), linkText: z.string().max(60).optional() })
      .optional()
      .describe('Only facts the person gave. text = the headline, body = the first paragraph.'),
  }),
  execute: async () => DRAFT_ONLY,
})

export const saveBlockTool = tool({
  description:
    'Save a section of a page as a reusable saved block (managers only), as a DRAFT. To change an existing saved block everywhere, pass updates: <saved block id> — ONLY when the person asked for that; the draft lists every page it changes.',
  inputSchema: z.object({
    page: z.string().describe('Page id or slug the section is on'),
    fromBlockId: z.string().max(120),
    name: z.string().min(1).max(80),
    category: z.string().max(40).optional(),
    mode: z.enum(['linked', 'copy']).optional(),
    updates: z.string().max(120).optional(),
  }),
  execute: async () => DRAFT_ONLY,
})

export const libraryTools = {
  find_blocks: findBlocksTool,
  suggest_layouts: suggestLayoutsTool,
  add_block: addBlockTool,
  save_block: saveBlockTool,
}
