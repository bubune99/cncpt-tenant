/**
 * ask_user — show the person a small question form in the chat (a display
 * tool, like the spotlight). It changes nothing: no database writes, no
 * screen. The form is checked here (lib/ade/chat/ask-form parseAskInput) and
 * returned for the chat to render; the person's answers come back as their
 * own next message, so this call is finished the moment it returns and
 * nothing waits on the browser.
 *
 * App-agnostic: the host passes how to look up media ids in its library.
 */

import { tool } from 'ai'
import { z } from 'zod'
import { ASK_LIMITS, ASK_TOOL, mediaIdsIn, parseAskInput, type AskMediaInfo } from '../../ade/chat/ask-form'

const option = z.object({
  value: z.string().min(1).max(ASK_LIMITS.value),
  label: z.string().min(1).max(ASK_LIMITS.label),
  description: z.string().max(ASK_LIMITS.description).optional(),
  mediaId: z.string().max(64).optional().describe('image questions: a media-library id (from the media tools).'),
  swatch: z.array(z.string().regex(/^#[0-9a-fA-F]{6}$/)).max(ASK_LIMITS.swatchColors).optional().describe('image questions without media: one or two #rrggbb colors.'),
})

const question = z.object({
  id: z.string().max(24).optional(),
  prompt: z.string().min(1).max(ASK_LIMITS.prompt),
  hint: z.string().max(ASK_LIMITS.hint).optional(),
  tag: z.string().max(ASK_LIMITS.tag).optional().describe('A one- or two-word label for the answer summary ("Background").'),
  type: z.enum(['single', 'multi', 'image', 'text']),
  options: z.array(option).max(ASK_LIMITS.maxOptions).default([]),
})

export const askInputSchema = z.object({
  title: z.string().max(ASK_LIMITS.title).optional(),
  questions: z.array(question).min(1).max(ASK_LIMITS.maxQuestions),
})

export interface AskToolDeps {
  /** The ids found in this site's media library that this person may see (images only), with their picture. */
  resolveMedia: (ids: string[]) => Promise<ReadonlyMap<string, AskMediaInfo>>
}

export function askUserTool(deps: AskToolDeps) {
  return tool({
    description: [
      'Show the person a short question form in the chat when you need choices only they can make (look, wording, which item) — not for facts you can look up.',
      `Up to ${ASK_LIMITS.maxQuestions} questions (single, multi, image or text), up to ${ASK_LIMITS.maxOptions} plain-word options each; image options carry a media-library id or a #rrggbb swatch. They can always type their own answer.`,
      'At most one form per turn. Write one short line first, then stop: their answers arrive as their next message ("My answers: …").',
    ].join(' '),
    inputSchema: askInputSchema,
    execute: async (input) => {
      const ids = mediaIdsIn(input)
      const media = ids.length ? await deps.resolveMedia(ids).catch(() => new Map<string, AskMediaInfo>()) : new Map<string, AskMediaInfo>()
      const parsed = parseAskInput(input, media)
      if (!parsed.ok) return { shown: false, error: parsed.error }
      return {
        shown: true,
        form: parsed.form,
        ...(parsed.notes.length ? { notes: parsed.notes } : {}),
        message: 'The form was shown to the person. Their answers are their next message ("My answers: …"); do not answer for them.',
      }
    },
  })
}

export const ASK_TOOL_NAME = ASK_TOOL
