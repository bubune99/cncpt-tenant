/**
 * The assistant helps the owner set up who may see private areas
 * (lib/ade/governance/access): explain what a person or role — and their
 * assistant — can see, and PROPOSE changes as a change set the owner
 * approves in To-do. Owner only; nothing here applies a change directly.
 */

import { tool } from 'ai'
import { z } from 'zod'
import { prisma } from '../../db'
import { requireAuth } from '../../permissions/middleware'
import { getUserPermissions } from '../../permissions'
import { changeSets } from '../../ade-bindings'
import { findSubject } from '../../ade-bindings/access-drafters'
import { privacyAreas, viewerRole } from '../../ade-bindings/visibility'
import { areaAccess, explainAccess, type PermissionView } from '../../ade/governance/access'

async function ownerOnly(): Promise<{ userId: string } | { error: string }> {
  try {
    const ctx = await requireAuth()
    return viewerRole(ctx.permissions) === 'owner' ? { userId: ctx.user.id } : { error: 'Only the site owner can look at or change who may see private areas.' }
  } catch {
    return { error: 'Only the site owner can look at or change who may see private areas.' }
  }
}

const subjectShape = {
  user: z.string().max(200).optional().describe('The person: their email, name or id'),
  role: z.string().max(100).optional().describe('Or a role: its name, e.g. "Support Staff"'),
}

const AREA_KEYS = 'privacy.<area>.see (the person sees the area while it is confidential) or privacy.<area>.agent (their assistant may read it). Areas: contact, people, customers, submissions, orders.'

export const explain_access = tool({
  description:
    'Explain in plain words what a person or a role — and their assistant — can see in the private areas (contact details, admin people, customers, form submissions, orders). Use it when the owner asks "what can X see?" or is onboarding someone. Owner only.',
  inputSchema: z.object(subjectShape),
  execute: async (input) => {
    const gate = await ownerOnly()
    if ('error' in gate) return { success: false, error: gate.error }
    const subject = await findSubject(input)
    if ('error' in subject) return { success: false, error: subject.error }
    let view: PermissionView
    if (subject.kind === 'user') {
      const perms = await getUserPermissions(subject.id)
      view = perms ? { permissions: perms.permissions, overrides: perms.overrides.map((o) => ({ permission: o.permission, type: o.type })) } : { permissions: [], overrides: [] }
    } else {
      const r = await prisma.role.findUnique({ where: { id: subject.id }, select: { permissions: true } })
      view = { permissions: (r?.permissions as string[]) ?? [], overrides: [] }
    }
    const areas = await privacyAreas()
    return {
      success: true,
      subject: subject.label,
      kind: subject.kind,
      summary: explainAccess(areas, view, subject.label),
      areas: areas.map((a) => {
        const r = areaAccess(a, view)
        return { area: a.id, label: a.label, confidential: a.confidential, person: r.user, assistant: r.agent }
      }),
      howToChange: `Propose a change with draft_access_change (${AREA_KEYS}). It goes to To-do for the owner to approve.`,
    }
  },
})

export const draft_access_change = tool({
  description:
    `Propose who may see a private area, for one person (an exception) or a role. ${AREA_KEYS} ` +
    'grant = allow, deny = don’t allow (for a person, this overrides their role), clear = back to the role’s setting. ' +
    'It is ALWAYS drafted for the owner to approve in To-do — never applied directly. Explain the effect in plain words when you propose it. Owner only.',
  inputSchema: z.object({
    ...subjectShape,
    grant: z.array(z.string()).max(10).optional(),
    deny: z.array(z.string()).max(10).optional(),
    clear: z.array(z.string()).max(10).optional(),
    reason: z.string().max(300).optional().describe('Why — shown to the owner on the review card'),
  }),
  execute: async (input) => {
    const gate = await ownerOnly()
    if ('error' in gate) return { success: false, error: gate.error }
    // Always a draft, whatever the review mode: the owner approves in To-do.
    const r = await changeSets.propose({ ownerId: gate.userId, source: 'chat', toolName: 'draft_access_change', input: input as Record<string, unknown> })
    if (!r.ok) return { success: false, error: r.error }
    return {
      success: true,
      drafted: true,
      changeSetId: r.changeSetId,
      reviewUrl: `/admin/todo?view=all&item=${r.changeSetId}`,
      message: `Drafted for the owner's approval — NOT applied yet: ${r.change.summary}. Approve it in To-do.`,
    }
  },
})

export const accessTools = { explain_access, draft_access_change }
