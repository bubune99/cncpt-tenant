/**
 * In-memory CounterStore for the AI cost test kit. Same window semantics as
 * the Postgres upsert (it uses `rollWindow`, the function store.ts's SQL
 * mirrors), plus switches to simulate the failure modes that matter:
 *
 *   down          every call throws (DB unreachable / table missing)
 *   writesDown    reads work, bumps throw (spend can't be recorded)
 *   ioDelayMs     every call yields for this long first, so concurrent
 *                 requests interleave the way they do against a real DB
 *
 * A bump, reserve or release is atomic (read-modify-write happens in one
 * synchronous block after the delay), like the single SQL statement each is
 * in production. A read followed later by a bump is NOT atomic — exactly as
 * in production.
 */

import type { CounterStore } from '../../rate-limit/counter-store'
import {
  currentAmount,
  releaseWindow,
  reserveWindow,
  resetAtFor,
  rollWindow,
  type CounterState,
} from '../../rate-limit/window'
import { planMatches, type ResetPlan } from '../../rate-limit/reset-plan'

export interface MemoryCounterStore extends CounterStore {
  down: boolean
  writesDown: boolean
  ioDelayMs: number
  /** Current amount of one counter (0 when absent/expired). */
  peek(kind: string, identity: string): number
  /** Seed a counter, e.g. a user whose window is already used up. */
  seed(kind: string, identity: string, amount: number, windowMs: number): void
  /** Every live row, for debugging a failing scenario. */
  dump(): Array<{ kind: string; identity: string } & CounterState>
}

export function createMemoryCounterStore(now: () => number = Date.now): MemoryCounterStore {
  const rows = new Map<string, { kind: string; identity: string; state: CounterState }>()
  const key = (kind: string, identity: string) => `${kind}\u0000${identity}`

  const store: MemoryCounterStore = {
    down: false,
    writesDown: false,
    ioDelayMs: 0,

    async bump(kind, identity, windowMs, add, nowMs = now()) {
      await io()
      if (store.down || store.writesDown) throw new Error('usage_counters unavailable (simulated)')
      const k = key(kind, identity)
      const next = rollWindow(rows.get(k)?.state ?? null, nowMs, windowMs, Math.max(0, Math.floor(add)))
      rows.set(k, { kind, identity, state: next })
      return { ...next }
    },

    async reserve(kind, identity, windowMs, add, limit, nowMs = now()) {
      await io()
      if (store.down || store.writesDown) throw new Error('usage_counters unavailable (simulated)')
      const k = key(kind, identity)
      const prev = rows.get(k)?.state ?? null
      const next = reserveWindow(prev, nowMs, windowMs, Math.max(0, Math.floor(add)), Math.max(0, Math.floor(limit)))
      if (!next) return { ok: false, amount: currentAmount(prev, nowMs), resetAt: resetAtFor(prev, nowMs) }
      rows.set(k, { kind, identity, state: next })
      return { ok: true, state: { ...next } }
    },

    async release(kind, identity, amount, windowStart) {
      await io()
      if (store.down || store.writesDown) throw new Error('usage_counters unavailable (simulated)')
      const k = key(kind, identity)
      const next = releaseWindow(rows.get(k)?.state ?? null, windowStart, Math.max(0, Math.floor(amount)))
      if (!next) return false
      rows.set(k, { kind, identity, state: next })
      return true
    },

    async read(kind, identity, nowMs = now()) {
      await io()
      if (store.down) throw new Error('usage_counters unavailable (simulated)')
      const state = rows.get(key(kind, identity))?.state ?? null
      return { amount: currentAmount(state, nowMs), resetAt: resetAtFor(state, nowMs) }
    },

    async deleteWhere(plan: ResetPlan) {
      await io()
      if (store.down) throw new Error('usage_counters unavailable (simulated)')
      let n = 0
      for (const [k, row] of [...rows]) {
        if (planMatches(plan, row.kind, row.identity)) {
          rows.delete(k)
          n++
        }
      }
      return n
    },

    peek(kind, identity) {
      return currentAmount(rows.get(key(kind, identity))?.state ?? null, now())
    },

    seed(kind, identity, amount, windowMs) {
      rows.set(key(kind, identity), { kind, identity, state: { windowStart: now(), windowMs, amount } })
    },

    dump() {
      return [...rows.values()].map((r) => ({ kind: r.kind, identity: r.identity, ...r.state }))
    },
  }

  async function io() {
    if (store.ioDelayMs > 0) await new Promise((r) => setTimeout(r, store.ioDelayMs))
    else await Promise.resolve()
  }

  return store
}
