/**
 * Agent activity for the admin chat — binds the generic run recorder
 * (lib/ade/observability) to this app: tool labels for effects, the audit
 * redaction (guard-tools redactInput, then personal details masked), pricing,
 * and ONE batched write when the turn ends. Nothing is written per step, and
 * nothing at all unless a chat turn runs (the CMS works without AI).
 */

import { SEALED_ERROR, isEmailTool, sealedInput, sealedSummary } from '../ade/connectors/governance'
import { AsyncLocalStorage } from 'node:async_hooks'
import { randomUUID } from 'node:crypto'
import { prisma } from '../db'
import { blockedDetail, blockedFromOutput, clientToolResults, matchScreenReports, type ScreenReport, createRunRecorder, type BlockedRead, type ClientToolResult, type ResumeState, type RunRecorder, type RunStatus, type SpanRow, type StepUsage, type ToolCallInfo, countsAsBlockedRead } from '../ade/observability'
import { redactText, redactValue } from '../ade/privacy/redact'
import { labelsOf, redactInput } from './governance'
import { logAuditEvent } from '../permissions'
import { groupsFromLoadCalls } from './toolsets'
import { PLUMBING_TOOLS } from '../ade/chat/chain-constants'
import { ABANDONED_ERROR, abandonedRun } from '../ade/chat/client-timeouts'
import { estimateCost } from './pricing'
import type { RunTaint } from '../ade/governance/taint'

const REQUEST_CAP = 200
/** Audit rows a tool wrote land a moment after the tool span ends. */
const AUDIT_SLACK_MS = 3_000

/** The same redaction the audit log gets, plus personal details masked. */
export function redactForTrace(input: unknown): unknown {
  return redactValue(redactInput(input))
}

/** A run id, made before the tools are guarded so audit rows can carry it (details.runId). */
export const newRunId = (): string => randomUUID()

/**
 * Server backstop (staging 49b9da13): a run still waiting on the SCREEN long
 * after (the browser never posted a result) is closed — status 'error', its
 * waiting spans too — so nothing stays "waiting" forever. Runs waiting on the
 * person (a walk-through step, a form) are left alone. Scoped to one
 * conversation at the start of a chat request; across all with null (cron).
 * Never throws.
 */
export async function closeAbandonedRuns(conversationId: string | null, keepRunId: string | null, now: number = Date.now()): Promise<number> {
  try {
    const runs = await prisma.agentRun.findMany({
      where: { status: 'waiting', ...(conversationId ? { conversationId } : {}), ...(keepRunId ? { id: { not: keepRunId } } : {}) },
      select: { id: true, startedAt: true, spans: { where: { status: 'waiting' }, select: { label: true, startMs: true } } },
      orderBy: { startedAt: 'asc' },
      take: conversationId ? 10 : 200,
    })
    let closed = 0
    for (const r of runs) {
      const since = r.startedAt.getTime() + Math.max(0, ...r.spans.map((sp) => sp.startMs))
      if (!abandonedRun({ waitingLabels: r.spans.map((sp) => sp.label), waitingSince: since, now })) continue
      await prisma.$transaction([
        prisma.agentSpan.updateMany({ where: { runId: r.id, status: 'waiting' }, data: { status: 'error', detail: ABANDONED_ERROR } }),
        prisma.agentRun.update({ where: { id: r.id }, data: { status: 'error', error: ABANDONED_ERROR } }),
      ])
      closed++
    }
    return closed
  } catch (e) {
    console.error('[agent-runs] could not close abandoned runs:', e instanceof Error ? e.message : e)
    return 0
  }
}

/** A run paused on browser-answered calls whose results this request carries. */
export interface WaitingRun {
  runId: string
  state: ResumeState
  results: ClientToolResult[]
}

/**
 * Is this request the continuation of a run waiting for the screen? Yes when
 * its last message is the assistant's with tool results for calls a
 * 'waiting' run in this conversation recorded. One indexed query, and only
 * when such results are present.
 */
export async function findWaitingRun(conversationId: string, messages: ReadonlyArray<unknown>): Promise<WaitingRun | null> {
  const results = clientToolResults(messages)
  if (!results.length) return null
  try {
    const hit = await prisma.agentSpan.findFirst({
      where: { callId: { in: results.map((r) => r.callId) }, status: 'waiting', run: { conversationId, status: 'waiting' } },
      select: { runId: true },
    })
    if (!hit) return null
    const run = await prisma.agentRun.findUnique({
      where: { id: hit.runId },
      include: { spans: { select: { id: true, seq: true, kind: true, parentId: true, status: true, callId: true, label: true, startMs: true } } },
    })
    if (!run) return null
    const root = run.spans.find((s) => s.parentId === null && s.kind === 'agent')
    if (!root) return null
    return {
      runId: run.id,
      results,
      state: {
        startedAt: run.startedAt.getTime(),
        rootId: root.id,
        nextSeq: Math.max(...run.spans.map((s) => s.seq)) + 1,
        steps: run.steps,
        spanCount: run.spans.length,
        droppedSpans: run.droppedSpans,
        totals: { tokensIn: run.tokensIn, tokensOut: run.tokensOut, cacheRead: run.cacheRead, cacheWrite: run.cacheWrite },
        groups: run.toolGroupsLoaded,
        waiting: run.spans
          .filter((s) => s.status === 'waiting' && s.callId)
          .map((s) => ({ spanId: s.id, callId: s.callId!, label: s.label, startMs: s.startMs })),
      },
    }
  } catch (e) {
    // Can't tell: record a new run rather than break the chat.
    console.error('[agent-runs] could not look up a waiting run:', e instanceof Error ? e.message : e)
    return null
  }
}

export interface ChatRunMeta {
  /** From newRunId() or a WaitingRun; generated when absent. */
  runId?: string
  /** The waiting run this request continues (findWaitingRun). */
  resume?: WaitingRun | null
  userId: string
  conversationId: string
  area: string | null
  route: string | null
  model: string
  effort: string | null
  request: string
  preloadedGroups: readonly string[]
  /** The browser's results for screen actions (operate_ui) it ran since the last request. */
  uiReport?: ReadonlyArray<ScreenReport>
  /** This run's taint (outside text read → changes need approval); recorded on the run and its spans. */
  taint?: RunTaint
}

/**
 * Where a request's taint comes from (owner, 2026-10-13: for the REST OF THE
 * CONVERSATION): this conversation's own run records on the server — the
 * waiting run it resumes, or any earlier run in the conversation that read
 * outside text. Nothing the client says can clear it; another conversation's
 * (or person's) never applies; a new chat starts clean. A failed lookup
 * counts as tainted.
 */
export async function taintSeedFor(conversationId: string, userId: string, resume: WaitingRun | null): Promise<{ source: string } | null> {
  try {
    const run = await prisma.agentRun.findFirst({
      where: { conversationId, userId, tainted: true },
      orderBy: { startedAt: 'asc' },
      select: { taintedBy: true },
    })
    if (run) return { source: run.taintedBy ?? 'an earlier step' }
    if (resume) {
      const own = await prisma.agentRun.findUnique({ where: { id: resume.runId }, select: { tainted: true, taintedBy: true, conversationId: true } })
      if (own?.tainted && own.conversationId === conversationId) return { source: own.taintedBy ?? 'an earlier step' }
    }
    return null
  } catch {
    // Can't tell: treat the conversation as tainted (fail closed).
    return { source: 'unknown (could not check)' }
  }
}

/** Run + span fields for a taint (spans: the call that tainted it, and every change after). */
function taintFields(taint: RunTaint | undefined, spans: ReadonlyArray<SpanRow>, startedAt: Date) {
  if (!taint?.tainted) return { run: { tainted: false, taintedBy: null }, spans: spans.map((s) => ({ ...s, tainted: false })) }
  const at = taint.at ?? 0
  return {
    run: { tainted: true, taintedBy: taint.source },
    spans: spans.map((s) => ({
      ...s,
      tainted: s.kind === 'tool' && (s.label === taint.source || (!!s.effect && s.effect !== 'read' && startedAt.getTime() + s.startMs >= at)),
    })),
  }
}

/** The subset of AI SDK usage a step reports. */
interface SdkUsage {
  inputTokens?: number
  outputTokens?: number
  inputTokenDetails?: { cacheReadTokens?: number; cacheWriteTokens?: number }
}

export interface ChatRun {
  readonly runId: string
  readonly userId: string
  /** A read the visibility policy blocked or masked (see reportReadBlocked). */
  blocked(b: BlockedRead): void
  wrapTools<T extends Record<string, unknown>>(tools: T): T
  /** `calls` = the step's tool calls (browser-answered ones become waiting spans). */
  step(usage: SdkUsage | undefined, calls?: ReadonlyArray<ToolCallInfo>): void
  /** Close and persist (once). Never throws. */
  finish(status: RunStatus, opts?: { error?: string; messageId?: string }): Promise<void>
}

/** "anthropic/claude-haiku-5.5" → "claude-haiku-5.5" for step labels. */
export const modelLabel = (model: string): string => model.split('/').pop() || model

export function startChatRun(meta: ChatRunMeta): ChatRun {
  const resume = meta.resume ?? null
  const recorder: RunRecorder = createRunRecorder({
    now: Date.now,
    newId: randomUUID,
    redact: redactForTrace,
    // A person's own mailbox: tool, timing and counts only (lib/ade/connectors).
    sealed: { is: isEmailTool, input: sealedInput, summary: sealedSummary, error: SEALED_ERROR },
    effectOf: (name) => labelsOf(name).effect,
    // Plumbing, not actions: loading tools and the plan the chat shows (lib/ade/chat/chain-constants).
    ioTools: PLUMBING_TOOLS,
    groupsFromIo: (name, input) => groupsFromLoadCalls([{ toolName: name, input }]),
    modelLabel: modelLabel(meta.model),
  }, resume?.runId ?? meta.runId ?? newRunId(), resume?.state)
  const run: ChatRun = {
    runId: recorder.runId,
    userId: meta.userId,
    blocked: (b) => recorder.blocked(b),
    wrapTools: (tools) => recorder.wrapTools(tools),
    step: (u, calls) =>
      recorder.step({
        input: u?.inputTokens ?? 0,
        output: u?.outputTokens ?? 0,
        cacheRead: u?.inputTokenDetails?.cacheReadTokens ?? 0,
        cacheWrite: u?.inputTokenDetails?.cacheWriteTokens ?? 0,
      } satisfies StepUsage, undefined, calls),
    async finish(status, opts = {}) {
      const out = recorder.finish(status, opts.error ? redactText(opts.error) : undefined)
      if (!out) return
      try {
        const taint = taintFields(meta.taint, await linkAudit(out.spans, meta.userId, out.run.startedAt, out.run.id), out.run.startedAt)
        const spans = taint.spans
        const groups = [...new Set([...meta.preloadedGroups, ...out.run.toolGroupsLoaded])]
        const cost = estimateCost(out.run.tokensIn + out.run.tokensOut, meta.model)
        const newSpans = prisma.agentSpan.createMany({ data: spans.map((s) => ({ ...s, inputRedacted: (s.inputRedacted ?? undefined) as never })) })
        const spanUpdates = out.updates.map((u) =>
          prisma.agentSpan.update({
            where: { id: u.id },
            data: { endMs: u.endMs, status: u.status, ...(u.detail !== undefined ? { detail: u.detail } : {}), ...(u.outputSummary !== undefined ? { outputSummary: u.outputSummary } : {}), ...(u.tokens !== undefined ? { tokens: u.tokens } : {}) },
          }),
        )
        const screen = await screenReportUpdates(meta.conversationId, meta.uiReport)
        if (out.resumed) {
          // One turn, one run: the continuation extends the waiting run.
          const { id, startedAt: _startedAt, ...rest } = out.run
          void _startedAt
          await prisma.$transaction([
            prisma.agentRun.update({ where: { id }, data: { ...rest, ...taint.run, toolGroupsLoaded: groups, costEstimate: cost, ...(opts.messageId ? { messageId: opts.messageId } : {}) } }),
            ...spanUpdates,
            ...screen,
            newSpans,
          ])
        } else {
          await prisma.$transaction([
            prisma.agentRun.create({
              data: {
                ...out.run,
                ...taint.run,
                toolGroupsLoaded: groups,
                conversationId: meta.conversationId,
                messageId: opts.messageId ?? null,
                userId: meta.userId,
                area: meta.area,
                route: meta.route,
                request: redactText(meta.request).slice(0, REQUEST_CAP) || null,
                model: meta.model,
                effort: meta.effort,
                costEstimate: cost,
              },
            }),
            newSpans,
            ...spanUpdates,
            ...screen,
          ])
        }
      } catch (e) {
        // Recording must never break the chat.
        console.error('[agent-runs] could not save run:', e instanceof Error ? e.message : e)
      }
    },
  }
  // Everything this turn runs (tools, the visibility policy) can find its run.
  currentRun.enterWith(run)
  // The browser's answers arrived with this request: close those spans, and
  // report what the policy refused or masked on the screen (output.blocked).
  for (const r of resume?.results ?? []) {
    recorder.resolveClientCall(r.callId, r.error !== undefined ? { error: r.error } : { output: r.output })
    for (const b of blockedFromOutput(r.output)) reportReadBlocked({ ...b, tool: r.toolName })
  }
  return run
}

const currentRun = new AsyncLocalStorage<ChatRun>()

/** The chat run this code is running inside, if any (MCP, UI and scripts have none). */
export function activeChatRun(): ChatRun | undefined {
  return currentRun.getStore()
}

/**
 * The visibility policy refused or masked a read the agent tried. Records a
 * 'blocked'/'masked' span on the current run (if any) and writes an
 * "ai.read_blocked" audit row with details.runId, so the owner sees what the
 * agent tried to read. Labels only — never the value. Never throws; the
 * audit write is fire-and-forget.
 */
export function reportReadBlocked(b: BlockedRead, opts: { userId?: string } = {}): void {
  try {
    const run = activeChatRun()
    const clean: BlockedRead = {
      mode: b.mode,
      target: redactText(String(b.target ?? '')).slice(0, 120),
      fields: (b.fields ?? []).map((f) => String(f).slice(0, 60)).slice(0, 20),
      reason: b.reason ? String(b.reason).slice(0, 80) : undefined,
      tool: b.tool ? String(b.tool).slice(0, 80) : undefined,
    }
    run?.blocked(clean)
    // Plain redaction is shown in the trace, but it isn't a policy refusal: no audit row.
    if (!countsAsBlockedRead(clean.reason)) return
    const userId = opts.userId ?? run?.userId
    void logAuditEvent({
      userId,
      action: 'ai.read_blocked',
      targetType: 'visibility',
      targetId: clean.target,
      details: { runId: run?.runId ?? null, via: 'ai-agent', mode: clean.mode, target: clean.target, fields: clean.fields, reason: clean.reason ?? null, tool: clean.tool ?? null, detail: blockedDetail(clean) },
    }).catch((e: unknown) => console.error('[agent-runs] could not audit a blocked read:', e instanceof Error ? e.message : e))
  } catch (e) {
    console.error('[agent-runs] reportReadBlocked failed:', e instanceof Error ? e.message : e)
  }
}

/**
 * Close the screen actions (operate_ui spans still 'waiting') that this
 * request's uiReport answers — the oldest pending one per capability, in
 * this conversation. Returns the span updates for the run transaction.
 */
async function screenReportUpdates(conversationId: string, reports: ReadonlyArray<ScreenReport> | undefined) {
  if (!reports?.length) return []
  const pending = await prisma.agentSpan.findMany({
    where: { kind: 'tool', status: 'waiting', callId: { not: null }, label: 'operate_ui', run: { conversationId } },
    orderBy: [{ run: { startedAt: 'asc' } }, { seq: 'asc' }],
    select: { id: true, inputRedacted: true },
    take: 50,
  })
  const matched = matchScreenReports(
    pending.map((p) => ({ spanId: p.id, capability: typeof (p.inputRedacted as { capability?: unknown } | null)?.capability === 'string' ? (p.inputRedacted as { capability: string }).capability : null })),
    reports,
  )
  return matched.map((m) =>
    prisma.agentSpan.update({
      where: { id: m.spanId },
      data: { status: m.ok ? 'ok' : 'error', outputSummary: redactText(`${m.ok ? 'Done on the screen' : 'Didn’t work on the screen'}: ${m.message}`).slice(0, 160), detail: redactText(m.message).slice(0, 160) },
    }),
  )
}

/**
 * Give each tool span the audit row it wrote: rows carrying this run's id
 * (guard-tools writes details.runId), matched by tool name and time.
 */
async function linkAudit(spans: SpanRow[], userId: string, startedAt: Date, runId: string): Promise<SpanRow[]> {
  const tools = spans.filter((s) => s.kind === 'tool' && s.effect && s.effect !== 'read')
  if (!tools.length) return spans
  const t0 = startedAt.getTime()
  const rows = await prisma.auditLog.findMany({
    // The tool's own audit entry — not the visibility policy's ai.read_blocked rows.
    where: { userId, createdAt: { gte: startedAt }, action: { not: 'ai.read_blocked' }, details: { path: ['runId'], equals: runId } },
    select: { id: true, createdAt: true, details: true },
    orderBy: { createdAt: 'asc' },
    take: 200,
  })
  const used = new Set<string>()
  return spans.map((s) => {
    if (s.kind !== 'tool' || !s.effect || s.effect === 'read') return s
    const hit = rows.find((r) => {
      if (used.has(r.id)) return false
      const tool = (r.details as { tool?: unknown } | null)?.tool
      const at = r.createdAt.getTime() - t0
      return tool === s.label && at >= s.startMs - 50 && at <= s.endMs + AUDIT_SLACK_MS
    })
    if (!hit) return s
    used.add(hit.id)
    return { ...s, auditLogId: hit.id }
  })
}
