/**
 * The AI Gateway model used for every generated picture. AI_IMAGE_MODEL ("provider/model")
 * overrides it. Owner, 2026-11-16: "Use a new Gemini model then". Check: image-model.assert.ts.
 */
export const DEFAULT_IMAGE_MODEL = 'google/gemini-3.1-flash-image'

export function imageModelId(env: Record<string, string | undefined>): string {
  const v = env.AI_IMAGE_MODEL?.trim()
  return v && /^[a-z0-9-]+\/[A-Za-z0-9._-]+$/.test(v) ? v : DEFAULT_IMAGE_MODEL
}

/**
 * How a model makes a picture: Gemini image models are language models that answer with an image
 * file ('text'); dedicated image models (FLUX, Recraft, ...) take the image call ('image').
 */
export function imageCallKind(modelId: string): 'text' | 'image' {
  return /^google\/gemini-/.test(modelId) ? 'text' : 'image'
}

type FileLike = { mediaType?: string; base64?: string }

/** The first image file in a text reply, or null. */
export function pickImageFile<T extends FileLike>(files: ReadonlyArray<T> | undefined): T | null {
  return (files ?? []).find((f) => typeof f.mediaType === 'string' && f.mediaType.startsWith('image/') && !!f.base64) ?? null
}
