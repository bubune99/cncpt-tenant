// Moved to @far-cms/core (far-cms packages/core/src/lib/ai/governance/agent-modes.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/ai/governance/agent-modes'
