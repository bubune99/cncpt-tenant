/**
 * The per-call gates the modes add on top of the dispatcher — pure (no Prisma, React or Next; everything is
 * passed in), asserted by agent-mode-gates.assert.ts, so another host (the Payload console) can take it as is.
 * guardTools (./guard-tools) is the thin adapter that calls these.
 *
 *   lookOnlyOffers     — the tool list in Look only: registered reads only; nothing that can change data.
 *   lookOnlyRefuses    — a "read" that writes for some inputs (explainElement saveAsHelp) refuses those calls.
 *   callAsks           — one call's approval: its own rule, input risk, Auto's undo rule, and the taint
 *                        fallback (after outside text, every change asks — so Auto behaves as Accept changes).
 *   autoAllowance      — maxAutoChanges: a change applied without asking spends the allowance; past it, pause.
 *   autoVersionFallback — Auto needs Undo: a change that could not record its version is not left live; that
 *                        call falls back to Accept changes (a draft where the tool can draft, else it asks).
 */

import { pausedSentence, type AgentMode, type AutoBudget } from './agent-modes'

/** What the gate needs to know about a tool (from the host's registry; undefined = unregistered). */
export interface GateToolFacts {
  mutation: boolean
  /** A read that writes for some inputs. */
  writesWhen?: (input: unknown) => boolean
}

/** Look only: is this tool offered at all? Unregistered tools may change anything, so they are not. */
export function lookOnlyOffers(facts: GateToolFacts | undefined): boolean {
  return facts !== undefined && facts.mutation === false
}

export const LOOK_ONLY_REFUSAL = 'The assistant is set to Look only, so it can explain this but not save anything.'

/** Look only: the refusal for a call of an offered read that would write, or null to let it run. */
export function lookOnlyRefuses(facts: GateToolFacts, input: unknown): { success: false; refused: true; error: string } | null {
  return facts.writesWhen?.(input) ? { success: false, refused: true, error: LOOK_ONLY_REFUSAL } : null
}

export interface CallFacts {
  /** The dispatcher's answer for the tool (irreversible, high-risk, Accept changes for a write…). */
  base: boolean
  /** Input-dependent risk (money, a cancel), if any. */
  risk?: boolean
  /** Auto only: this call cannot be undone (autoCallAsks). */
  autoAsks?: boolean
  /** The conversation read outside text, or a read issued earlier in this step is still out. */
  tainted?: boolean
}

/** Does this call need the person's approval? Any reason is enough; taint overrides every mode. */
export function callAsks(f: CallFacts): boolean {
  return f.base || f.risk === true || f.autoAsks === true || f.tainted === true
}

/**
 * maxAutoChanges at execute time. Only a change that ran under Auto WITHOUT asking spends the allowance
 * (an approved change is the person's, not Auto's). Null = go ahead; otherwise the one-sentence pause.
 */
export function autoAllowance(mode: AgentMode | undefined, appliedWithoutAsking: boolean, budget: AutoBudget | undefined): { success: false; paused: true; error: string } | null {
  if (mode !== 'auto' || !appliedWithoutAsking || !budget) return null
  return budget.take() ? null : { success: false, paused: true, error: pausedSentence(budget.limit) }
}

/** What the person is told when an Auto change could not record a version (one sentence). */
export const AUTO_NO_VERSION_NOTE = 'I couldn’t save a version to undo this from, so I didn’t apply it live — it’s waiting for you as a draft in the review queue.'
export const AUTO_NO_VERSION_ASK = 'I couldn’t save a version to undo this from, so I didn’t apply it — ask me again in Accept changes and approve it.'

/**
 * Auto needs Undo. `missing` = the write could not record its version (and was not left live).
 * Draft it where the tool can be drafted (Accept changes for that call), otherwise refuse with the sentence.
 */
export function autoVersionFallback(missing: boolean, canDraft: boolean): 'keep' | 'draft' | 'refuse' {
  if (!missing) return 'keep'
  return canDraft ? 'draft' : 'refuse'
}
