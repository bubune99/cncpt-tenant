/**
 * Agent Governance — Tool guard
 *
 * Wraps the assembled AI tool set with the resolved policy + per-user RBAC.
 * This is the single server-side choke point that makes the agent safe:
 *
 *   1. Master switch off            -> no tools at all.
 *   2. Navigation disabled          -> nav tools removed.
 *   3. Domain not in allowlist      -> that domain's tools removed.
 *   4. User lacks the RBAC perm     -> tool removed (model never sees it).
 *      Input-dependent permission   -> checked per call (polymorphic reads).
 *   5. readonly mode                -> every mutating tool removed.
 *   6. Surviving mutating tools     -> the ADE dispatcher (decideDispatch,
 *                                      src/lib/ade) decides per its labels:
 *        - draft effect + draft mode   -> held as a ChangeSet for review
 *        - irreversible                -> always needs explicit approval
 *        - write                       -> approval per execution mode
 *      and the wrapper adds a defense-in-depth perm re-check + audit logging.
 *   0. exposure                       -> `internal` tools never reach chat.
 *   Modes (ctx.modes)                 -> Look only / Accept changes / Auto
 *      (./agent-modes) decide the (executionMode, changeMode) PER TOOL before
 *      step 5; decideDispatch itself is unchanged.
 *
 * Tools not in the registry (DB-defined vMCP tools, external MCP tools) get
 * DYNAMIC_TOOL_LABELS: approval on every call, audited.
 */

import { DYNAMIC_TOOL_PERMISSION } from '../../security/staff-gate'
import { SAME_STEP_REFUSAL, callMayTaint, callTaints, type RunTaint, type UntrustedLabel } from '../../ade/governance/taint'
import type { ToolSet, Tool } from 'ai'
import type { ResolvedAgentPolicy } from './types'
import { z } from 'zod'
import {
  DYNAMIC_TOOL_LABELS,
  DYNAMIC_TOOL_META,
  TOOL_REGISTRY,
  isAllowlistGatedDomain,
  labelsOf,
  type ToolMeta,
} from './tool-registry'
import { decideDispatch, exposedOn, type ChangeMode, type DispatchDecision } from '../../ade'
import { hasPermission, checkPermission, logAuditEvent } from '../../permissions'
import type { UserWithPermissions } from '../../permissions/types'
import { captureRevisions, peekRevisions, withVersionRequired } from '../../ade-bindings/revision-capture'
import { autoCallAsks, toolRuntime, type AgentMode, type AgentModeSettings, type AutoBudget, type ToolRuntime } from './agent-modes'
import { AUTO_NO_VERSION_ASK, AUTO_NO_VERSION_NOTE, autoAllowance, autoVersionFallback, callAsks, lookOnlyRefuses } from './agent-mode-gates'
import { withRecordedChanges } from '../../ade/chat/change-widgets'

// Loose view of a tool used only for reading/overriding `execute` while wrapping.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type ExecutableTool = Tool & { execute?: (...args: any[]) => any }

/** Holds draftable agent edits as ChangeSet items (src/lib/ade-bindings). */
export interface DraftingHook {
  mode: ChangeMode
  canDraft(toolName: string): boolean
  /** Refusal text when someone else is editing the tool's target (optional for older hosts). */
  checkLock?(toolName: string, input: Record<string, unknown>): Promise<string | null>
  propose(toolName: string, input: Record<string, unknown>, opts?: { why?: string }): Promise<Record<string, unknown>>
}

export interface AgentToolGuardContext {
  userId: string
  policy: ResolvedAgentPolicy
  /** Pre-fetched permission set, so filtering needs zero extra DB calls. */
  userPerms: UserWithPermissions | null
  /** Absent → no drafting: draftable edits are applied directly (pre-ADE behaviour). */
  drafting?: DraftingHook
  /** The agent-activity run (lib/ai/agent-runs): written into every audit row as details.runId. */
  runId?: string
  /**
   * What the agent may see (lib/ade/governance/visibility): every data tool's
   * RESULT is passed through `filter` before the model gets it — blocked
   * targets become { blocked, reason, canGuide }, private fields are masked.
   */
  visibility?: { filter: (tool: string, input: unknown, output: unknown) => unknown }
  /** Names of database-stored (vMCP) tools: always governed as dynamic, even if named like a built-in. */
  dynamicTools?: ReadonlySet<string>
  /**
   * This run's taint (lib/ade/governance/taint): reads of outside text mark
   * it, and from then on every change needs approval. Absent → no taint rule.
   */
  taint?: RunTaint
  /** The host's screens that show outside text (for screen reads). */
  outsideTextScreens?: readonly string[]
  /**
   * The Look only / Accept changes / Auto switch (./agent-modes), resolved on the server for this request.
   * Absent → the pre-modes behaviour: `policy.executionMode` and `drafting.mode` apply as they are.
   */
  modes?: {
    settings: AgentModeSettings
    /** The person's mode, already clamped to their ceiling. */
    person: AgentMode
    /** Changes Auto has applied without asking in this run. */
    budget: AutoBudget
  }
}

/** Per run: what approval decided for each change call (by toolCallId), to catch same-step reads. */
const decisions = new WeakMap<RunTaint, Map<string, boolean>>()
const decisionsOf = (taint: RunTaint) => {
  let m = decisions.get(taint)
  if (!m) decisions.set(taint, (m = new Map()))
  return m
}
type CallOptions = { toolCallId?: string } | undefined

/**
 * needsApproval for a change, decided per call: its own rule, the tool's
 * input-dependent risk (meta.highRiskWhen, e.g. a cancel), or the run read
 * outside text — including a read issued earlier in this same step whose
 * result isn't in yet (ctx.taint.pending). A plain boolean when nothing can
 * change it.
 */
function approvalFor(base: boolean, ctx: AgentToolGuardContext, highRiskWhen?: (input: unknown) => boolean): boolean | ((input: unknown, options?: CallOptions) => boolean) {
  const taint = ctx.taint
  if (base || (!highRiskWhen && !taint)) return base
  return (input: unknown, options?: CallOptions) => {
    const need = (highRiskWhen ? highRiskWhen(input) : false) || taint?.tainted === true || taint?.pending === true
    if (taint && options?.toolCallId) decisionsOf(taint).set(options.toolCallId, need)
    return need
  }
}

/**
 * At execute time: a change that was let through WITHOUT approval while a
 * read of outside text was issued in the same step after it was decided is
 * refused (it can be asked again — then the card shows). Null = go ahead.
 */
function sameStepRefusal(ctx: AgentToolGuardContext, options: CallOptions): { success: false; refused: true; error: string } | null {
  const taint = ctx.taint
  if (!taint || !options?.toolCallId) return null
  const decided = decisionsOf(taint).get(options.toolCallId)
  if (decided === false && (taint.pending || taint.tainted)) return { success: false, refused: true, error: SAME_STEP_REFUSAL }
  return null
}

/**
 * A tool that may bring outside text: issuing the call marks the step
 * pending (so the same step's writes ask), and its result taints the run.
 * Wraps tools with no server execute too (screen reads answered in the
 * browser) — their call still holds the step's writes.
 */
function wrapTaintSource(name: string, tool: Tool, label: UntrustedLabel | undefined, ctx: AgentToolGuardContext): Tool {
  const taint = ctx.taint
  if (!taint || label === undefined) return tool
  const t = tool as ExecutableTool & { needsApproval?: boolean | ((input: unknown, options?: unknown) => boolean | PromiseLike<boolean>) }
  const before = t.needsApproval
  const wrapped: ExecutableTool & { needsApproval?: unknown } = {
    ...tool,
    needsApproval: (input: unknown, options?: unknown) => {
      if (callMayTaint(label, input)) taint.markPending(name)
      return typeof before === 'function' ? before(input, options) : before === true
    },
  }
  const originalExecute = t.execute
  if (typeof originalExecute === 'function') {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wrapped.execute = async (input: any, options: any) => {
      const output = await originalExecute(input, options)
      if (!taint.tainted && callTaints({ label, input, output, screenPatterns: ctx.outsideTextScreens ?? [] })) taint.mark(name, Date.now())
      return output
    }
  }
  return wrapped as Tool
}

/**
 * A "read" tool that writes for some inputs (explainElement saveAsHelp):
 * those calls ask once the run is tainted; other reads stay free.
 */
function wrapReadThatWrites(tool: Tool, writesWhen: (input: unknown) => boolean, ctx: AgentToolGuardContext): Tool {
  const taint = ctx.taint
  if (!taint) return tool
  const t = tool as ExecutableTool
  const needsApproval = (input: unknown, options?: CallOptions) => {
    const need = writesWhen(input) && (taint.tainted || taint.pending)
    if (options?.toolCallId && writesWhen(input)) decisionsOf(taint).set(options.toolCallId, need)
    return need
  }
  const wrapped: ExecutableTool = { ...t, needsApproval } as ExecutableTool
  const originalExecute = t.execute
  if (typeof originalExecute === 'function') {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wrapped.execute = async (input: any, options: any) => sameStepRefusal(ctx, options) ?? originalExecute(input, options)
  }
  return wrapped
}

/**
 * Look only (or read-only mode): a "read" tool that writes for some inputs keeps its reads and refuses
 * the writing calls — the assistant reads and points, and never changes anything.
 */
function wrapReadOnlyRefusal(tool: Tool, writesWhen: (input: unknown) => boolean): Tool {
  const t = tool as ExecutableTool
  const originalExecute = t.execute
  if (typeof originalExecute !== 'function') return tool
  const wrapped: ExecutableTool = { ...t }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  wrapped.execute = async (input: any, options: any) => lookOnlyRefuses({ mutation: false, writesWhen }, input) ?? originalExecute(input, options)
  return wrapped
}

/**
 * Registry entry for a tool, or undefined for a database-stored / unknown one.
 * Stored tools are checked first: one named like a built-in must never
 * inherit the built-in's (possibly permissionless) rules.
 */
function metaFor(name: string, ctx: Pick<AgentToolGuardContext, 'dynamicTools'>): ToolMeta | undefined {
  return ctx.dynamicTools?.has(name) || !Object.hasOwn(TOOL_REGISTRY, name) ? undefined : TOOL_REGISTRY[name]
}

/** The ADE dispatcher's decision for a tool already past the RBAC pre-filter. */
export function chatDecision(name: string, ctx: AgentToolGuardContext): DispatchDecision {
  const meta: ToolMeta | undefined = metaFor(name, ctx)
  return decideDispatch({
    labels: meta ? labelsOf(name) : DYNAMIC_TOOL_LABELS,
    surface: 'chat',
    changeMode: ctx.drafting?.mode ?? 'direct',
    executionMode: ctx.policy.executionMode,
    permitted: true,
    budgetOk: true,
    canDraft: ctx.drafting?.canDraft(name) ?? false,
    forceConfirm: Boolean(meta?.highRisk) || ctx.policy.alwaysConfirm.has(name),
  })
}

export interface GuardResult {
  tools: ToolSet
  /** Names removed by policy/RBAC — useful for logging + telemetry. */
  removed: string[]
}

export function guardTools(
  tools: ToolSet,
  ctx: AgentToolGuardContext
): GuardResult {
  const { policy, userPerms } = ctx
  const removed: string[] = []

  // 1. Master switch.
  if (!policy.enabled) {
    return { tools: {}, removed: Object.keys(tools) }
  }

  const guarded: ToolSet = {}

  for (const [name, tool] of Object.entries(tools)) {
    const meta = metaFor(name, ctx)

    // Unknown/dynamic tools (VMCP + external MCP) can't be classified, so
    // treat them as potential mutations: blocked in readonly mode, approval
    // required in ask mode, and audited. They used to pass through entirely
    // unguarded, which let an externally-added MCP tool bypass the policy.
    if (!meta) {
      if (policy.executionMode === 'readonly' || ctx.modes?.person === 'readonly') {
        removed.push(name)
        continue
      }
      // RBAC like the rest: an unregistered tool may run stored code, so only owner-level people get it.
      if (policy.respectRbac && userPerms && !checkPermission(userPerms, DYNAMIC_TOOL_PERMISSION).allowed) {
        removed.push(name)
        continue
      }
      // DYNAMIC_TOOL_META: its output is never trusted, so running one taints the run too.
      guarded[name] = wrapTaintSource(name, wrapDynamicTool(name, tool, ctx), DYNAMIC_TOOL_META.untrustedSource, ctx)
      continue
    }

    // 0. Exposure: internal (server-only) capabilities never reach the model.
    if (!exposedOn(meta.exposure, 'chat')) {
      removed.push(name)
      continue
    }

    // 2. Navigation gate.
    if (meta.navigation && !policy.navigationEnabled) {
      removed.push(name)
      continue
    }

    // 3. Domain allowlist (business domains only).
    if (isAllowlistGatedDomain(meta.domain) && !policy.allowedDomains.has(meta.domain)) {
      removed.push(name)
      continue
    }

    // 4. RBAC pre-filter (reads and writes).
    if (policy.respectRbac && meta.permission && userPerms) {
      if (!checkPermission(userPerms, meta.permission).allowed) {
        removed.push(name)
        continue
      }
    }

    // Non-mutating tools: no approval, no audit (outside text taints the run).
    if (!meta.mutation) {
      const gated = meta.permissionFor ? wrapInputGatedTool(tool, meta.permissionFor, ctx) : tool
      const writing = meta.writesWhen
        ? policy.executionMode === 'readonly' || ctx.modes?.person === 'readonly'
          ? wrapReadOnlyRefusal(gated, meta.writesWhen)
          : wrapReadThatWrites(gated, meta.writesWhen, ctx)
        : gated
      guarded[name] = wrapTaintSource(name, writing, meta.untrustedSource, ctx)
      continue
    }

    // The modes switch decides per tool (the person's mode, the target's ceiling, undo); without it the policy applies as it is.
    const runtime = ctx.modes
      ? toolRuntime({ settings: ctx.modes.settings, person: ctx.modes.person, toolName: name, target: meta.domain, effect: meta.effect, canDraft: ctx.drafting?.canDraft(name) ?? false })
      : null
    const tctx: AgentToolGuardContext = runtime
      ? { ...ctx, policy: { ...policy, executionMode: runtime.executionMode }, drafting: ctx.drafting ? { ...ctx.drafting, mode: runtime.changeMode } : ctx.drafting }
      : ctx

    // 5. readonly mode (Look only) removes mutations.
    if (tctx.policy.executionMode === 'readonly') {
      removed.push(name)
      continue
    }

    // 6. The dispatcher decides: hold as a draft, or execute (with or
    //    without an approval prompt).
    const decision = chatDecision(name, tctx)
    if (decision.kind === 'deny') {
      removed.push(name)
      continue
    }
    guarded[name] =
      decision.kind === 'draft'
        ? wrapDraftingTool(name, tool, meta, tctx, runtime)
        : wrapMutatingTool(name, tool, meta, tctx, decision.needsApproval, runtime)
  }

  // 7. What each call saved: the revisions it recorded ride on its result
  //    (`changes`), so the chat's change cards come from the records.
  for (const [name, tool] of Object.entries(guarded)) guarded[name] = wrapRevisionCapture(tool)

  // 8. Visibility: data results never reach the model unfiltered. Navigation
  //    and on-screen tools are left alone — guiding someone TO a private
  //    screen is allowed; reading it is not (the client checks read_view).
  if (ctx.visibility) {
    for (const [name, tool] of Object.entries(guarded)) {
      const meta = metaFor(name, ctx)
      // On-screen tools (read_view, capture_view, spotlight…) run in the browser, where the client applies the policy.
      if (meta?.navigation || meta?.domain === 'meta') continue
      // The person's OWN mailbox: theirs to read (the site's people-data rules are for site records). Sealed in agent activity instead.
      if (meta?.domain === 'email') continue
      guarded[name] = wrapVisibility(name, tool, ctx.visibility.filter)
    }
  }

  return { tools: guarded, removed }
}

function wrapRevisionCapture(tool: Tool): Tool {
  const originalExecute = (tool as ExecutableTool).execute
  if (typeof originalExecute !== 'function') return tool
  const wrapped: ExecutableTool = { ...tool }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  wrapped.execute = async (input: any, options: any) => {
    const { result, revisions } = await captureRevisions(() => Promise.resolve(originalExecute(input, options)))
    // A streaming tool's iterable passes through as is.
    if (result && typeof result === 'object' && Symbol.asyncIterator in result) return result
    return withRecordedChanges(result, revisions)
  }
  return wrapped
}

function wrapVisibility(name: string, tool: Tool, filter: (tool: string, input: unknown, output: unknown) => unknown): Tool {
  const originalExecute = (tool as ExecutableTool).execute
  if (typeof originalExecute !== 'function') return tool
  const wrapped: ExecutableTool = { ...tool }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  wrapped.execute = async (input: any, options: any) => filter(name, input, await originalExecute(input, options))
  return wrapped
}

/**
 * Wrap a read tool whose required permission depends on its input (the
 * entity tools take an `entityType`). The static pre-filter can't decide
 * these, so the check runs on every call and fails closed: an input that maps
 * to no permission, or a missing permission set, is denied.
 */
function wrapInputGatedTool(
  tool: Tool,
  permissionFor: (input: unknown) => string | undefined,
  ctx: AgentToolGuardContext
): Tool {
  const { policy, userPerms } = ctx
  const originalExecute = (tool as ExecutableTool).execute
  if (!policy.respectRbac || typeof originalExecute !== 'function') return tool

  const wrapped: ExecutableTool = { ...tool }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  wrapped.execute = async (input: any, options: any) => {
    const permission = permissionFor(input)
    if (!permission) {
      return { success: false, error: 'Permission denied: unsupported entity type.' }
    }
    if (!userPerms || !checkPermission(userPerms, permission).allowed) {
      return {
        success: false,
        error: `Permission denied: this requires the "${permission}" permission, which your account does not have.`,
      }
    }
    return originalExecute(input, options)
  }
  return wrapped
}

/**
 * Wrap an unregistered (dynamic VMCP/MCP) tool. We can't know its domain,
 * permission, or whether it mutates, so: honor an existing needsApproval,
 * force approval in 'ask' mode and for anything in alwaysConfirm, and write
 * a generic audit event on every execution.
 */
function wrapDynamicTool(
  name: string,
  tool: Tool,
  ctx: AgentToolGuardContext
): Tool {
  const { userId, policy } = ctx
  const originalExecute = (tool as ExecutableTool).execute
  // Unknown effect → DYNAMIC_TOOL_LABELS (irreversible) → always approval.
  const decision = chatDecision(name, ctx)
  const needsApproval = decision.kind === 'execute' ? decision.needsApproval : true

  const wrapped: ExecutableTool = { ...tool, needsApproval: approvalFor(needsApproval, ctx) }

  if (typeof originalExecute === 'function') {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wrapped.execute = async (input: any, options: any) => {
      const sameStep = sameStepRefusal(ctx, options)
      if (sameStep) return sameStep
      // Defense in depth: re-check at call time, as for registered mutations.
      if (policy.respectRbac) {
        const check = await hasPermission(userId, DYNAMIC_TOOL_PERMISSION)
        if (!check.allowed) return { success: false, error: `Permission denied: this tool requires the "${DYNAMIC_TOOL_PERMISSION}" permission.` }
      }
      const result = await originalExecute(input, options)

      if (policy.auditEnabled) {
        try {
          await logAuditEvent({
            userId,
            action: 'agent.tool_execute',
            targetType: 'dynamic-tool',
            targetId: name,
            details: { tool: name, via: 'ai-agent', ...(ctx.runId ? { runId: ctx.runId } : {}), input: redactInput(input) },
          })
        } catch {
          /* swallow audit errors */
        }
      }

      return result
    }
  }

  return wrapped
}

/** What the model is told the `why` field is for. */
export const WHY_DESCRIPTION = 'One short sentence: why you propose this change, in the person\'s terms (e.g. "You asked for the new opening hours"). Shown on the review card.'

/** The tool's input schema plus an optional `why` (zod objects only; anything else is left as it is). */
export function withWhy<S>(schema: S): S {
  const s = schema as unknown as { shape?: Record<string, unknown>; extend?: (shape: Record<string, unknown>) => unknown }
  if (!s || typeof s.extend !== 'function' || !s.shape || 'why' in s.shape) return schema
  try {
    return s.extend({ why: z.string().max(240).optional().describe(WHY_DESCRIPTION) }) as S
  } catch {
    return schema
  }
}

/**
 * Wrap a draftable edit so it is proposed as a ChangeSet item instead of
 * written. No approval prompt: the review queue is the approval.
 */
function wrapDraftingTool(
  name: string,
  tool: Tool,
  meta: ToolMeta,
  ctx: AgentToolGuardContext,
  runtime: ToolRuntime | null = null
): Tool {
  const { userId, policy, drafting } = ctx
  // The review queue is the approval — unless the run read outside text (then the card too).
  // Every draft says why, on its review card (owner 2026-10-17): an optional `why` on the tool's input.
  const wrapped: ExecutableTool = { ...tool, inputSchema: withWhy(tool.inputSchema), needsApproval: approvalFor(false, ctx) }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  wrapped.execute = async (input: any, options: any) => {
    const sameStep = sameStepRefusal(ctx, options)
    if (sameStep) return sameStep
    if (policy.respectRbac && meta.permission) {
      const check = await hasPermission(userId, meta.permission)
      if (!check.allowed) {
        return {
          success: false,
          error: `Permission denied: this action requires the "${meta.permission}" permission, which your account does not have.`,
        }
      }
    }
    const { why, ...fields } = (input ?? {}) as Record<string, unknown>
    const result = await drafting!.propose(name, fields, { why: typeof why === 'string' ? why : undefined })
    if (policy.auditEnabled && result.success) {
      try {
        await logAuditEvent({
          userId,
          action: 'agent.tool_execute',
          targetType: meta.domain,
          targetId: typeof result.itemId === 'string' ? result.itemId : undefined,
          details: { tool: name, via: 'ai-agent', ...(ctx.runId ? { runId: ctx.runId } : {}), drafted: true, changeSetId: result.changeSetId, ...modeDetails(ctx, runtime, false), input: redactInput(input) },
        })
      } catch {
        /* swallow audit errors */
      }
    }
    return result
  }
  return wrapped
}

function wrapMutatingTool(
  name: string,
  tool: Tool,
  meta: ToolMeta,
  ctx: AgentToolGuardContext,
  needsApproval: boolean,
  runtime: ToolRuntime | null = null
): Tool {
  const { userId, policy } = ctx
  const originalExecute = (tool as ExecutableTool).execute

  // Input-dependent risk (e.g. a status write that cancels) and run taint: approval for that call.
  // In Auto, a call this tool cannot undo asks too (./agent-modes autoCallAsks).
  const own = meta.highRiskWhen
  const autoGate = runtime?.mode === 'auto' ? (input: unknown) => autoCallAsks(name, input) : undefined
  const perInput = own || autoGate ? (input: unknown) => callAsks({ base: false, risk: own?.(input), autoAsks: autoGate?.(input) }) : undefined
  const asking = approvalFor(needsApproval, ctx, perInput)
  const wrapped: ExecutableTool = { ...tool, needsApproval: asking }

  if (typeof originalExecute === 'function') {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wrapped.execute = async (input: any, options: any) => {
      const sameStep = sameStepRefusal(ctx, options)
      if (sameStep) return sameStep
      // Someone else editing this page/record? The assistant leaves it alone.
      if (ctx.drafting?.checkLock && ctx.drafting.canDraft(name)) {
        const refusal = await ctx.drafting.checkLock(name, (input ?? {}) as Record<string, unknown>)
        if (refusal) return { success: false, error: refusal, locked: true }
      }
      // Defense-in-depth: re-check the permission at call time even though the
      // tool was only exposed because the pre-filter allowed it.
      if (policy.respectRbac && meta.permission) {
        const check = await hasPermission(userId, meta.permission)
        if (!check.allowed) {
          return {
            success: false,
            error: `Permission denied: this action requires the "${meta.permission}" permission, which your account does not have.`,
          }
        }
      }
      const extra = meta.extraPermission?.(input)
      if (policy.respectRbac && extra) {
        const check = await hasPermission(userId, extra)
        if (!check.allowed) {
          return {
            success: false,
            error: `Permission denied: this action requires the "${extra}" permission, which your account does not have.`,
          }
        }
      }

      // Auto is bounded: past the limit the run stops and asks (one plain sentence), and nothing more is applied.
      // A call that was approved (a later request resumes it) would still have asked: the rule is re-read, not remembered.
      const appliedWithoutAsking = !(typeof asking === 'boolean' ? asking : asking(input, options))
      const paused = autoAllowance(runtime?.mode, appliedWithoutAsking, ctx.modes?.budget)
      if (paused) return paused

      // Auto needs Undo: an unprompted Auto change must leave a version behind, or it is not left live.
      const autoLive = runtime?.mode === 'auto' && appliedWithoutAsking
      const ran = autoLive ? await withVersionRequired(() => Promise.resolve(originalExecute(input, options))) : { result: await originalExecute(input, options), missing: false }
      const fallback = autoVersionFallback(ran.missing, !!ctx.drafting?.canDraft(name))
      if (fallback === 'draft') {
        const { why, ...fields } = (input ?? {}) as Record<string, unknown>
        const drafted = await ctx.drafting!.propose(name, fields, { why: typeof why === 'string' ? why : undefined })
        return { ...drafted, note: AUTO_NO_VERSION_NOTE, heldBack: 'no-version' }
      }
      if (fallback === 'refuse') return { success: false, error: AUTO_NO_VERSION_ASK, heldBack: 'no-version' }
      const result = ran.result

      // Audit successful mutations. Never let audit failure break the call.
      if (policy.auditEnabled && meta.audit) {
        try {
          await logAuditEvent({
            userId,
            action: meta.audit,
            targetType: meta.domain,
            targetId: extractTargetId(input, result),
            details: { tool: name, via: 'ai-agent', ...(ctx.runId ? { runId: ctx.runId } : {}), ...modeDetails(ctx, runtime, appliedWithoutAsking), input: redactInput(input) },
          })
        } catch {
          /* swallow audit errors */
        }
      }

      return result
    }
  }

  return wrapped
}

/**
 * What the audit row says about the mode: the mode this change ran under, whether it applied without asking,
 * both identities (the person it acted for and the assistant) and the versions it recorded — the ones Undo
 * restores. Nothing is added when the modes switch is off, so those rows read as they always did.
 */
function modeDetails(ctx: AgentToolGuardContext, runtime: ToolRuntime | null, appliedWithoutAsking: boolean): Record<string, unknown> {
  if (!ctx.modes || !runtime) return {}
  const revisionIds = peekRevisions().map((r) => r.revisionId)
  return {
    mode: runtime.mode,
    personMode: ctx.modes.person,
    ...(runtime.heldBack ? { heldBack: runtime.heldBack } : {}),
    autoApplied: runtime.mode === 'auto' && appliedWithoutAsking,
    actedFor: ctx.userId,
    agent: 'assistant',
    ...(revisionIds.length ? { revisionIds } : {}),
  }
}

/** Best-effort extraction of the affected entity id for the audit trail. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function extractTargetId(input: any, result: any): string | undefined {
  if (input && typeof input === 'object' && typeof input.id === 'string') return input.id
  if (result && typeof result === 'object') {
    for (const key of ['page', 'product', 'order', 'post', 'blogPost']) {
      const v = result[key]
      if (v && typeof v === 'object' && typeof v.id === 'string') return v.id
    }
    if (typeof result.id === 'string') return result.id
  }
  return undefined
}

/**
 * Strip bulky/sensitive fields so audit details stay small and safe. Also
 * used for agent-activity span inputs (lib/ai/agent-runs).
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function redactInput(input: any): Record<string, unknown> | unknown {
  if (!input || typeof input !== 'object') return input
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(input)) {
    if (['content', 'blocks', 'html', 'body'].includes(k)) {
      out[k] = '[omitted]'
    } else if (typeof v === 'string' && v.length > 500) {
      out[k] = `${v.slice(0, 500)}…`
    } else {
      out[k] = v
    }
  }
  return out
}
