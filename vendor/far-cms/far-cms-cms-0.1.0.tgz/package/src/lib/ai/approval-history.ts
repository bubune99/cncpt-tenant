/**
 * Approval cards and the conversation history. Pure; asserted by
 * approval-history.assert.ts.
 *
 * A tool call that asked for approval is only "finished" once it has an
 * outcome (output, error, or denied). One left as `approval-requested` or
 * `approval-responded` in an EARLIER message — the person typed something
 * else instead of answering, or the continuation never arrived — becomes a
 * tool call with no result, which the model provider refuses ("tool_use ids
 * were found without tool_result blocks"), so every later turn in that chat
 * fails silently. Settling them as denied keeps the chat usable.
 */

interface PartLike {
  type: string
  state?: unknown
  approval?: { id?: unknown; approved?: unknown; reason?: unknown } | null
  [k: string]: unknown
}
interface MessageLike {
  role: string
  parts?: readonly unknown[]
}

const PENDING = new Set(['approval-requested', 'approval-responded'])
const isTool = (p: PartLike) => p.type.startsWith('tool-') || p.type === 'dynamic-tool'

/** Earlier messages' unanswered or unfinished approvals → denied; the last message is left as it is (it may be the continuation). */
export function settleStaleApprovals<M extends MessageLike>(messages: readonly M[]): M[] {
  return messages.map((m, i) => {
    const parts = (m.parts ?? []) as PartLike[]
    if (i === messages.length - 1 || m.role !== 'assistant' || !parts.some((p) => isTool(p) && PENDING.has(String(p.state)))) return m
    return {
      ...m,
      parts: parts.map((p) => {
        if (!isTool(p) || !PENDING.has(String(p.state))) return p
        const id = typeof p.approval?.id === 'string' ? p.approval.id : `stale-${String(p.toolCallId ?? i)}`
        const reason = p.state === 'approval-requested' ? 'Not approved — the person moved on without answering.' : p.approval?.approved === true ? 'Approved, but it did not run.' : DECLINE_REASON
        return { ...p, state: 'output-denied', approval: { id, approved: false, reason } }
      }),
    }
  })
}

/** The short line after a declined approval card, in the person's words. */
export function declinedLine(toolName: string): string {
  if (/send|reply|email|campaign|feedback/i.test(toolName)) return 'OK — not sent.'
  if (/^publish|unpublish/i.test(toolName)) return 'OK — nothing was published.'
  if (/delete|remove|archive/i.test(toolName)) return 'OK — nothing was deleted.'
  if (/refund|charge|cancel/i.test(toolName)) return 'OK — nothing was charged or changed.'
  return 'OK — I didn’t do that.'
}

/**
 * The auto-resend guard. useChat re-sends once every approval card in the
 * last step is answered — and asks again after EVERY finished request. If a
 * continuation comes back without settling the cards (an error, an empty
 * reply), the same answered cards trigger the same re-send again: a loop
 * (seen: ~31 empty assistant messages after one "Don't send"). The key names
 * the answered cards; each key is sent exactly once.
 */
export function approvalResendKey(messages: readonly MessageLike[]): string | null {
  const last = messages[messages.length - 1]
  if (!last || last.role !== 'assistant') return null
  const parts = (last.parts ?? []) as PartLike[]
  let start = -1
  parts.forEach((p, i) => {
    if (p.type === 'step-start') start = i
  })
  const answered = parts
    .slice(start + 1)
    .filter((p) => isTool(p) && p.state === 'approval-responded')
    .map((p) => `${String(p.approval?.id ?? p.toolCallId ?? '')}:${p.approval?.approved === true ? 'y' : 'n'}`)
  return answered.length ? answered.sort().join('|') : null
}

/** Should this finished request trigger the one continuation for its answered cards? Marks the key as sent. */
export function takeApprovalResend(messages: readonly MessageLike[], sent: Set<string>, complete: boolean): boolean {
  if (!complete) return false
  const key = approvalResendKey(messages)
  if (!key || sent.has(key)) return false
  sent.add(key)
  return true
}

/**
 * Is there anything to store for this assistant turn? An empty one (no
 * words, no tool call — a dead or idle continuation) is not saved: it
 * would only fill the history with blank rows. Its tokens are metered per
 * step regardless.
 */
export function worthSaving(text: string, parts: readonly unknown[]): boolean {
  if (text.trim()) return true
  return (parts as PartLike[]).some((p) => p && typeof p.type === 'string' && isTool(p))
}

/**
 * What the model is told when the person says no to a card. A decline is
 * the person's decision, not a failure: never retried, never routed around
 * through another tool or channel (seen: "should I send it through the site
 * owner message instead?").
 */
export const DECLINE_REASON =
  'The person chose not to do this. Acknowledge in one short line and do not retry or suggest alternatives.'

/** The system rule that goes with it. */
export const DECLINE_GUIDANCE =
  'When the person declines an approval card ("Don\'t send", "Reject", "Not now"), that is their decision, not an error. Reply with one short acknowledgement (e.g. "OK — not sent."). Do not call the tool again, do not offer to retry, and never suggest another tool, channel or workaround to achieve the same thing unless the person asks for it in a new message. A decline in an earlier turn stays settled: do not bring it up again or treat it as a failure on later turns. Some tools are offered only on the turn the person asks for them (sending feedback to the site\'s builder is one): when such a tool is not in your tools, that is normal — never comment on its absence, never "correct" an earlier reply about it, and never offer another person, channel or tool to reach the same result.'

/** Every declined card (answered "no", or settled as denied) carries DECLINE_REASON to the model — whatever the browser sent. */
export function withDeclineReason<M extends MessageLike>(messages: readonly M[]): M[] {
  return messages.map((m) => {
    const parts = (m.parts ?? []) as PartLike[]
    const declined = (p: PartLike) => isTool(p) && p.approval?.approved === false && (p.state === 'approval-responded' || p.state === 'output-denied')
    if (m.role !== 'assistant' || !parts.some(declined)) return m
    return { ...m, parts: parts.map((p) => (declined(p) ? { ...p, approval: { ...p.approval, reason: DECLINE_REASON } } : p)) }
  })
}

const toolNameOf = (p: PartLike): string =>
  p.type === 'dynamic-tool' ? String(p.toolName ?? '') : p.type.startsWith('tool-') ? p.type.slice(5) : ''

/** What the person's "no" on a card said, in their words. */
export function declineSaid(toolName: string): string {
  if (/send|reply|email|campaign|feedback/i.test(toolName)) return 'Don’t send it.'
  if (/^publish|unpublish/i.test(toolName)) return 'Don’t publish it.'
  if (/delete|remove|archive/i.test(toolName)) return 'Don’t delete it.'
  return 'No, don’t do that.'
}

/** The assistant's line that stands where the card was. */
export const CARD_OFFERED_LINE = 'I’ve put that on a card for you to confirm.'

/**
 * A card declined in an EARLIER turn is replayed to the model as the exchange
 * the person actually had — "I've put that on a card for you to confirm." →
 * the person: "Don't send it." → "OK — not sent." — with no tool call or
 * denied result left in its context. With the call kept, the model read the
 * denied result as a tool error and offered to retry, or "corrected" itself
 * against a toolset that no longer had the tool (staging 09731aeb, 5e074a5f).
 * The last message is left alone: it may be the continuation that carries
 * the approval answer. Only what the model sees changes — the card stays in
 * the UI (originalMessages).
 */
export function replayEarlierDeclines<M extends MessageLike & { id?: unknown }>(messages: readonly M[]): M[] {
  return messages.flatMap((m, i) => {
    const parts = (m.parts ?? []) as PartLike[]
    const declined = (p: PartLike) => isTool(p) && p.approval?.approved === false && (p.state === 'approval-responded' || p.state === 'output-denied')
    if (i === messages.length - 1 || m.role !== 'assistant' || !parts.some(declined)) return [m]
    const out: M[] = []
    let seg: PartLike[] = []
    let k = 0
    const said = (ps: PartLike[]) => ps.some((p) => p.type === 'text' && typeof p.text === 'string' && p.text.trim() !== '')
    const push = (role: string, ps: PartLike[]) => out.push({ ...m, id: `${String(m.id ?? 'm')}-r${k++}`, role, parts: ps } as M)
    let lastTool = ''
    for (const p of parts) {
      if (!declined(p)) { seg.push(p); continue }
      lastTool = toolNameOf(p)
      push('assistant', [...seg, { type: 'text', text: CARD_OFFERED_LINE }])
      push('user', [{ type: 'text', text: declineSaid(lastTool) }])
      seg = []
    }
    push('assistant', said(seg) ? seg : [...seg, { type: 'text', text: declinedLine(lastTool) }])
    return out
  })
}

/**
 * A declined card whose tool is NOT in this turn's toolset (tools offered
 * only when the person asks, like sending feedback) reads to the model as a
 * call to a tool that no longer exists: it called the decline a system error
 * and offered a workaround (staging 3e4fe5dc), and a replacement note was
 * taken as its own claim and "corrected" against the current tools
 * (1fbbe9ae). So those parts are DROPPED — no call, no result, no note. The
 * assistant's own words in that message stay; if it said nothing, the line
 * the person saw on the card ("OK — not sent.") stands in, so the message is
 * never empty. Declines of tools still offered are untouched.
 */
export function settleAbsentToolDeclines<M extends MessageLike>(messages: readonly M[], offered: (toolName: string) => boolean): M[] {
  return messages.map((m) => {
    const parts = (m.parts ?? []) as PartLike[]
    const absentDecline = (p: PartLike) =>
      isTool(p) && p.approval?.approved === false && (p.state === 'approval-responded' || p.state === 'output-denied') && !offered(toolNameOf(p))
    const dropped = parts.filter(absentDecline)
    if (m.role !== 'assistant' || !dropped.length) return m
    const kept = parts.filter((p) => !absentDecline(p))
    const said = kept.some((p) => p.type === 'text' && typeof p.text === 'string' && p.text.trim() !== '')
    return { ...m, parts: said ? kept : [...kept, { type: 'text', text: declinedLine(toolNameOf(dropped[dropped.length - 1])) }] }
  })
}
