/**
 * The admin assistant's extra tools, added after the built-in ones: database-stored (VMCP) tools while
 * DB code execution is on, the person's own email tools, client feedback, and external MCP tools.
 * Moved from api/chat/route.ts on 2026-11-22 (size check); same order, same rules — the route passes
 * in what the block used to read from the request.
 */
import { getMcpTools } from '../mcp'
import { getAllVmcpTools } from '../vmcp'
import { codeExecGate } from '../ade-bindings'
import { emailToolsForUser } from './tools/email-tools'
import { feedbackToolsFor } from './tools/feedback-tools'

export interface ExtraToolsInput {
  userId: string
  userName: string | null
  /** The conversation as sent; only the person's own words are read from it (recipients must come from there). */
  messages: ReadonlyArray<{ role: string; parts?: ReadonlyArray<{ type: string }> }>
  currentRoute: string | null
  selectedBlockId?: string | null
  /** The person's latest message text ('' when none). */
  lastUserText: string
}

export async function loadExtraTools<T extends Record<string, unknown>>(base: T, input: ExtraToolsInput): Promise<{ tools: T; vmcpToolCount: number; mcpToolCount: number; storedToolNames: Set<string> }> {
  let allTools: T = base
  let vmcpToolCount = 0;
  let mcpToolCount = 0;
  // Database-stored tools: governed as dynamic (owner only, approval, audit) whatever their name.
  const storedToolNames = new Set<string>();

  // Load VMCP tools (database-driven dynamic tools) — only while a super
  // admin has enabled DB code execution; otherwise the agent never sees them.
  if (await codeExecGate.isEnabled()) {
    try {
      const vmcpTools = await getAllVmcpTools();
      // A stored tool never replaces a tool already loaded (it would inherit that tool's rules).
      const fresh = Object.fromEntries(Object.entries(vmcpTools).filter(([name]) => {
        if (!(name in allTools)) return true;
        console.warn(`[Chat] Skipping VMCP tool "${name}": the name is taken by another tool`);
        return false;
      }));
      for (const name of Object.keys(fresh)) if (!name.startsWith('vmcp_')) storedToolNames.add(name);
      vmcpToolCount = Object.keys(fresh).length;
      allTools = { ...allTools, ...fresh };
      console.log(`[Chat] Loaded ${vmcpToolCount} VMCP tools`);
    } catch (vmcpError) {
      console.warn('[Chat] Failed to load VMCP tools:', vmcpError);
    }
  }

  // ── Personal email (lib/ade/connectors) ─────────────────────────────────────
  // The person's OWN mailbox, only once they connected it. Recipients must be
  // addresses they typed here (or the sender of the message replied to), so
  // the person's own words are passed in — never text from tool results.
  // Never put mail text into a USER part (e.g. a "reply to this" prefill):
  // its addresses would count as typed.
  // At rest: agent-activity spans and audit rows are sealed, but the
  // assistant's own reply text (which may summarise mail) is saved in the
  // person's own conversation like any chat — readable only by them, in
  // their account export, and removed by the chat retention purge.
  try {
    allTools = { ...allTools, ...(await emailToolsForUser(input.userId, () =>
      input.messages
        .filter((m) => m.role === 'user')
        .flatMap((m) => (m.parts ?? []).map((p) => (p.type === 'text' ? (p as { text?: string }).text ?? '' : '')))
        .join('\n'))) };
  } catch (emailError) {
    console.warn('[Chat] Email tools unavailable:', emailError instanceof Error ? emailError.message : emailError);
  }
  // ── end personal email ────────────────────────────────────────────────────

  // Client feedback to the site's builder ("tell Bubune this is confusing"): the screen and selection go with it.
  allTools = {
    ...allTools,
    ...feedbackToolsFor(
      { id: input.userId, name: input.userName },
      input.currentRoute,
      // The selected block by role + id only — never its name (F-1).
      input.selectedBlockId ? { role: 'Block', selector: input.selectedBlockId } : null,
      // Only the person's own latest message can ask for it (F-3).
      input.lastUserText,
    ),
  };

  // Load MCP tools (external MCP servers)
  try {
    const mcpTools = await getMcpTools();
    mcpToolCount = Object.keys(mcpTools).length;
    allTools = { ...allTools, ...mcpTools };
    console.log(`[Chat] Loaded ${mcpToolCount} MCP tools`);
  } catch (mcpError) {
    console.warn('[Chat] Failed to load MCP tools:', mcpError);
  }

  return { tools: allTools, vmcpToolCount, mcpToolCount, storedToolNames }
}
