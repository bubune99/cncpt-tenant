/**
 * Client Tool Handlers Registry
 *
 * Tools that have to run in the user's browser (read_view, capture_view,
 * scan_page) have no server execute. The chat's onToolCall looks the tool
 * up here, runs it, and adds the output; the turn then resumes with the
 * real result (lib/ade/ui/view-tools resumeAfterViewTools).
 *
 * spotlight_steps runs here too: its result is what actually showed (on
 * screen / not found / never came into view / not a real spot), so the model
 * never says it pointed when nothing showed.
 *
 * Fire-and-forget effects (navigate_to_route, operate_ui) still come back as
 * sentinels and are driven by the interceptors.
 */
import { runScanPage } from './tools/scan-page-client'
import { stagingToolsEnabled } from '../ade/staging-tools'
import type { ScanPageInput, ScanPageItem } from './tools/scan-page'
import { UNIT_ATTR, captureView, elementAccess, readViewFresh, revealUnit, setViewPolicySource } from '../ade/ui/view-dom'
import { isSecretField, type RevealAction } from '../ade/ui/view-units'
import { blockedScreen, markerLevel, screenLevel } from '../ade/ui/view-policy'
import { VIEW_MARKERS } from '../ade-bindings/view-markers'
import { loadViewPolicy } from '../ade-bindings/view-policy-source'
import { useSpotlightStore } from '../../stores/spotlight-store'
import { clientTimeoutFor, timeoutOutput, withTimeout } from '../ade/chat/client-timeouts'

// Every screen read (tools, coverage check) passes the visibility policy before it leaves the page.
setViewPolicySource(loadViewPolicy)

/**
 * scan_page under the visibility policy: nothing from a private screen;
 * landmarks inside private markers (and secret inputs) are left out; on a
 * layout-only screen, link labels (often record names) are blanked.
 */
async function scanPageWithPolicy(args: ScanPageInput) {
  const policy = await loadViewPolicy()
  const url = window.location.pathname + window.location.search
  const res = screenLevel(policy, url)
  if (res.level === 'blocked') return blockedScreen(res, document.title || window.location.pathname, window.location.pathname)
  const level = markerLevel(policy)
  const scan = await runScanPage(args)
  const items = scan.items.flatMap((item) => {
    let el: Element | null = null
    try {
      el = document.querySelector(item.selector)
    } catch {
      el = null
    }
    const marker = el?.closest('[data-ade-private]')?.getAttribute('data-ade-private')
    if (marker != null && level(marker) !== 'readable') return []
    if (el && isSecretField(el, elementAccess)) return []
    return res.level === 'metadata-only' && item.kind === 'link' ? [{ ...item, label: '' }] : [item]
  })
  return { ...scan, items, total: items.length, ...(res.level === 'metadata-only' ? { visibility: 'metadata-only', blocked: [{ mode: 'metadata-only', target: url, ...(res.rule ? { reason: res.rule.id } : {}) }] } : {}) }
}

/**
 * Shape of a sentinel returned by the server for client-executed tools.
 */
export interface ClientToolSentinel {
  __requires_client_execution: true
  name: string
  arguments: unknown
}

/**
 * Type-guard for the client-execution sentinel.
 */
export function isClientToolSentinel(value: unknown): value is ClientToolSentinel {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as Record<string, unknown>).__requires_client_execution === true &&
    typeof (value as Record<string, unknown>).name === 'string'
  )
}

/**
 * Result returned by `runScanPage`.
 */
export interface ScanPageResult {
  items: ScanPageItem[]
  total: number
  surface: string
}

/**
 * A client tool handler runs a sentinel's arguments in the browser and
 * returns the value the model should see on its next turn.
 */
export type ClientToolHandler = (args: unknown, call?: { toolCallId: string }) => Promise<unknown>

/**
 * A navigation tool: act (view-only, re-checked on the live element), take
 * a fresh snapshot, then spotlight what was touched so the person sees it.
 * Exported for runners that walk the screen without the model (Coverage check).
 */
export async function runRevealAction(action: RevealAction, unit: string, opts: { spotlight?: boolean } = {}) {
  const r = await revealUnit(action, unit, VIEW_MARKERS)
  const view = await readViewFresh(VIEW_MARKERS)
  // The fresh snapshot re-stamped ids; point at the element by its new one.
  const id = r.ok ? r.el?.getAttribute(UNIT_ATTR) : null
  // The card is titled with the unit's name; the agent's own spotlight_steps adds the sentence.
  if (id && r.did && opts.spotlight !== false) useSpotlightStore.getState().enqueueAll([{ target: `[${UNIT_ATTR}="${id}"]`, title: r.name, label: r.name }])
  return { ok: r.ok, ...(r.did ? { did: r.did } : {}), ...(r.error ? { error: r.error } : {}), view }
}

const reveal = (action: RevealAction): ClientToolHandler => (args: unknown) => runRevealAction(action, String((args as { unit?: unknown } | null)?.unit ?? ''))

/** Browser-run tools, keyed by tool name. */
export const clientToolHandlers: Record<string, ClientToolHandler> = {
  scan_page: (args: unknown) => scanPageWithPolicy(args as ScanPageInput),
  // Always the screen as it is now (settled, route-checked) — never a cached read.
  // Only focus: the size cap is not the model's to lift.
  read_view: (args: unknown) => readViewFresh(VIEW_MARKERS, { focus: ((args ?? {}) as { focus?: string }).focus }),
  capture_view: () => captureView(),
  open_tab: reveal('open_tab'),
  expand: reveal('expand'),
  collapse: reveal('collapse'),
  scroll_to: reveal('scroll_to'),
  open_menu: reveal('open_menu'),
  // Point at one part of this screen: resolve, reveal step by step with read-back, answer now (components/ade/control-runner).
  show_unit: async (args: unknown) => (await import('../../components/ade/control-runner')).showUnit(args),
  // Point at things: shown by the chat as the call arrives; answers with what showed (components/spotlight/spot-outcome).
  spotlight_steps: async (args: unknown, call?: { toolCallId: string }) => (await import('../../components/spotlight/use-spotlight-tool-interceptor')).runSpotCall(args, call),
  // One walk-through step: shown, then held until the person answers it (components/ade/wait-client; lib/ade/chat/waits).
  spotlight_step: async (args: unknown, call?: { toolCallId: string }) => (await import('../../components/ade/wait-client')).runWaitStep(args, call),
  // Coverage check: read-only walk of this screen → three lists + a stored row (components/ade/coverage).
  coverage_check: async () => {
    // Staging only (lib/ade/staging-tools): refused even if a model asked for it.
    if (!stagingToolsEnabled()) return { error: 'The coverage check is only available on staging.' }
    const { runCoverageHere, coverageForModel } = await import('../../components/ade/coverage/coverage-runner')
    return coverageForModel(await runCoverageHere())
  },
}

interface ToolCallLike {
  toolName: string
  toolCallId: string
  input: unknown
  dynamic?: boolean
}
type AddOutput = (o: { tool: string; toolCallId: string; output?: unknown; state?: 'output-error'; errorText?: string }) => unknown

/**
 * useChat onToolCall: run a browser tool and hand its output back. Not
 * awaited by the caller's addToolOutput (the SDK warns that deadlocks).
 * Returns false when the tool isn't a browser tool.
 */
export function handleClientToolCall(toolCall: ToolCallLike, addToolOutput: AddOutput): boolean {
  const handler = toolCall.dynamic ? undefined : clientToolHandlers[toolCall.toolName]
  if (!handler) return false
  // No screen tool waits forever: past its limit it answers with a plain reason (lib/ade/chat/client-timeouts).
  // A person's own wait (walk-through step, form) is never timed out.
  const limit = clientTimeoutFor(toolCall.toolName, toolCall.input)
  const run = handler(toolCall.input, { toolCallId: toolCall.toolCallId })
  void (limit === null ? run : withTimeout(run, limit, () => timeoutOutput(toolCall.toolName, toolCall.input)))
    .then((output) => addToolOutput({ tool: toolCall.toolName, toolCallId: toolCall.toolCallId, output }))
    .catch((err: unknown) =>
      addToolOutput({ state: 'output-error', tool: toolCall.toolName, toolCallId: toolCall.toolCallId, errorText: err instanceof Error ? err.message : 'The browser could not run this.' })
    )
  return true
}

/**
 * Convenience wrapper: given a sentinel, run the matching handler.
 * Returns `null` if no handler is registered (the sentinel is then a
 * harmless no-op rather than a runtime error).
 */
export async function runClientTool(
  sentinel: ClientToolSentinel
): Promise<unknown | null> {
  const handler = clientToolHandlers[sentinel.name]
  if (!handler) return null
  return handler(sentinel.arguments)
}
