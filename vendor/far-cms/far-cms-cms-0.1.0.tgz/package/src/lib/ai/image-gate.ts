/**
 * The image cap, shared by the main assistant and the page builder's chat: at most
 * imagesPerRequest per message (not charged) and imagesPerUser per person per day
 * (AI_IMAGES_PER_USER_DAY, default 20; owner kept it 2026-11-16). Check: image-gate.assert.ts.
 */
import { decideImageForRequest } from './spend-policy'
import type { SpendMeter } from './spend-meter'

export type ImageGate = () => Promise<{ ok: true } | { ok: false; message: string }>

/** One gate per request: it counts the images made in this message. */
export function makeImageGate(spend: Pick<SpendMeter, 'getSpendConfig' | 'chargeCountedAction'>, userId: string): ImageGate {
  let madeThisRequest = 0
  return async () => {
    const cfg = spend.getSpendConfig()
    if (!decideImageForRequest(madeThisRequest, cfg.imagesPerRequest)) {
      return { ok: false, message: `At most ${cfg.imagesPerRequest} images can be generated per message.` }
    }
    madeThisRequest += 1
    const charged = await spend.chargeCountedAction('images', userId, cfg.imagesPerUser, 'Image generation')
    return charged.ok ? { ok: true } : { ok: false, message: charged.message }
  }
}
