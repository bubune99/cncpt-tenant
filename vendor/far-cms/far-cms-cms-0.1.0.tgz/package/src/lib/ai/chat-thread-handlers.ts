/**
 * The admin assistant thread endpoints: GET a conversation (or the list), DELETE one, PATCH rename/pin,
 * and loadDraftOutcomes (shared with POST). Moved verbatim from api/chat/route.ts on 2026-11-22 (size
 * check). The route checks who is signed in (its own GET, DELETE and PATCH) and passes them in here.
 */
import type { User } from '@prisma/client';
import type { Prisma } from '@prisma/client';
import { prisma } from '../db';
import { createScopedClient } from '../db/scoped-client';
import { ChatSDKError } from '../ai/errors';
import { PREVIEW_LOOKBACK, chatConversationStore } from '../ade-bindings/chat-history-server';
import { type OutcomeSet } from '../ade/chat/change-outcomes';
import { checkRename, deleteConversationFor, lastPreview, sortWithPins, togglePin } from '../ade/chat/history';

// Get conversation history
export async function threadsGET(request: Request, dbUser: User) {
  try {

    // Use scoped client for conversation queries
    const scopedDb = createScopedClient(dbUser.id);
    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get('id');

    if (conversationId) {
      // Get specific conversation with messages (scoped to user)
      const conversation = await scopedDb.aiConversation.findFirst({
        where: { id: conversationId },
        include: {
          messages: {
            orderBy: { createdAt: 'asc' },
          },
        },
      });

      if (!conversation) {
        return ChatSDKError.notFound().toResponse();
      }

      return Response.json(conversation);
    }

    // Get conversation list (scoped to user): pinned ones first, even if older.
    const pins = await chatPins(dbUser.id);
    const listSelect = {
        id: true,
        title: true,
        contextType: true,
        updatedAt: true,
        // A few newest, so the preview can skip empty / tool-only turns.
        messages: {
          orderBy: { createdAt: 'desc' },
          take: PREVIEW_LOOKBACK,
          select: { content: true },
        },
    } as const;
    const [recent, pinnedRows] = await Promise.all([
      scopedDb.aiConversation.findMany({ where: { status: 'ACTIVE' }, orderBy: { updatedAt: 'desc' }, take: 50, select: listSelect }),
      pins.length
        ? scopedDb.aiConversation.findMany({ where: { status: 'ACTIVE', id: { in: pins } }, select: listSelect })
        : Promise.resolve([]),
    ]);
    const conversations = sortWithPins([...pinnedRows, ...recent.filter((c) => !pins.includes(c.id))], pins);

    return Response.json({
      conversations: conversations.map((c) => ({
        id: c.id,
        title: c.title,
        contextType: c.contextType,
        updatedAt: c.updatedAt,
        pinned: c.pinned,
        lastMessage: lastPreview(c.messages.map((m) => m.content)),
      })),
    });
  } catch (error) {
    console.error('[Chat API] GET Error:', error);
    return ChatSDKError.internal().toResponse();
  }
}

// Delete conversation
export async function threadsDELETE(request: Request, dbUser: User) {
  try {

    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get('id');

    if (!conversationId) {
      return ChatSDKError.badRequest('Missing conversation ID').toResponse();
    }

    // Your own only: another person's id answers 404 like a missing one. Messages, votes,
    // streams and the thread's agent runs (and their spans) go with it.
    const outcome = await deleteConversationFor(chatConversationStore, dbUser.id, conversationId);
    if (outcome === 'not-found') return ChatSDKError.notFound().toResponse();
    // A pin for a thread that no longer exists is dropped.
    const pins = await chatPins(dbUser.id);
    if (pins.includes(conversationId)) {
      const pref = await prisma.adeUserPref.findUnique({ where: { userId: dbUser.id }, select: { prefs: true } });
      const prefs = (pref?.prefs && typeof pref.prefs === 'object' ? pref.prefs : {}) as Record<string, unknown>;
      const next = { ...prefs, pinnedChats: pins.filter((p) => p !== conversationId) } as unknown as Prisma.InputJsonValue;
      await prisma.adeUserPref.update({ where: { userId: dbUser.id }, data: { prefs: next } });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('[Chat API] DELETE Error:', error);
    return ChatSDKError.internal().toResponse();
  }
}

// ---------------------------------------------------------------------------
// Rename / pin a conversation (your own only)
// ---------------------------------------------------------------------------

/** Pinned conversation ids live with the person's ADE prefs (no schema change). */
async function chatPins(userId: string): Promise<string[]> {
  const pref = await prisma.adeUserPref.findUnique({ where: { userId }, select: { prefs: true } });
  const pins = (pref?.prefs as { pinnedChats?: unknown } | null)?.pinnedChats;
  return Array.isArray(pins) ? pins.filter((p): p is string => typeof p === 'string') : [];
}

// PATCH /api/chat  { id, title?, pinned? }
export async function threadsPATCH(request: Request, dbUser: User) {
  try {

    const body = (await request.json().catch(() => null)) as { id?: unknown; title?: unknown; pinned?: unknown } | null;
    const id = typeof body?.id === 'string' ? body.id.slice(0, 100) : '';
    if (!id) return ChatSDKError.badRequest('Missing conversation ID').toResponse();
    if (body?.title === undefined && typeof body?.pinned !== 'boolean') {
      return ChatSDKError.badRequest('Nothing to change').toResponse();
    }

    // Only your own conversations (the scoped client filters by user).
    const scopedDb = createScopedClient(dbUser.id);
    const conversation = await scopedDb.aiConversation.findFirst({ where: { id }, select: { id: true, title: true } });
    if (!conversation) return ChatSDKError.notFound().toResponse();

    let title = conversation.title;
    if (body?.title !== undefined) {
      const checked = checkRename(body.title);
      if (!checked.ok) return ChatSDKError.badRequest(checked.error).toResponse();
      title = checked.title;
      await scopedDb.aiConversation.update({ where: { id }, data: { title } });
    }

    let pinned: boolean | undefined;
    if (typeof body?.pinned === 'boolean') {
      pinned = body.pinned;
      const pref = await prisma.adeUserPref.findUnique({ where: { userId: dbUser.id }, select: { prefs: true } });
      const prefs = (pref?.prefs && typeof pref.prefs === 'object' ? pref.prefs : {}) as Record<string, unknown>;
      const next = { ...prefs, pinnedChats: togglePin(await chatPins(dbUser.id), id, pinned) } as unknown as Prisma.InputJsonValue;
      await prisma.adeUserPref.upsert({ where: { userId: dbUser.id }, create: { userId: dbUser.id, prefs: next }, update: { prefs: next } });
    }

    return Response.json({ success: true, id, title, ...(pinned !== undefined ? { pinned } : {}) });
  } catch (error) {
    console.error('[Chat API] PATCH Error:', error);
    return ChatSDKError.internal().toResponse();
  }
}

/** This person's change sets among `ids`, with each item's status and the fields it changes (lib/ade/chat/change-outcomes). */
export async function loadDraftOutcomes(ids: string[], userId: string): Promise<OutcomeSet[]> {
  if (!ids.length) return [];
  try {
    const sets = await prisma.adeChangeSet.findMany({
      where: { id: { in: ids.slice(0, 50) }, ownerId: userId },
      select: { id: true, title: true, items: { select: { status: true, after: true, input: true }, orderBy: { createdAt: 'asc' } } },
    });
    const keys = (v: unknown) => (v && typeof v === 'object' && !Array.isArray(v) ? Object.keys(v as object) : []);
    return sets.map((s) => ({
      id: s.id,
      title: s.title,
      items: s.items.map((i) => {
        const data = (i.input as { data?: unknown } | null)?.data;
        return { status: i.status, fields: keys(i.after).length ? keys(i.after) : keys(data) };
      }),
    }));
  } catch (e) {
    console.warn('[Chat] Draft outcomes unavailable:', e instanceof Error ? e.message : e);
    return [];
  }
}
