/**
 * Agent activity reads for /api/admin/agent-activity — list, one run, and the
 * report summary. Filters, cursors and shapes are the pure ones in
 * lib/ade/observability/query.
 */

import { prisma } from '../db'
import { getAiSettings } from '../settings'
import {
  FAILURE_STATUSES,
  PLAIN_REDACTION,
  changesOf,
  isFailure,
  errorRate,
  nextCursor,
  requestPreview,
  runsOrderBy,
  runAuditWhere,
  runsWhere,
  startOfDayUtc,
  type RunFilters,
} from '../ade/observability'

const TOP_TOOLS = 5
const MAX_FAILURES = 10

async function userNames(ids: ReadonlyArray<string | null>): Promise<Map<string, string | null>> {
  const list = [...new Set(ids.filter((x): x is string => !!x))]
  if (!list.length) return new Map()
  const rows = await prisma.user.findMany({ where: { id: { in: list } }, select: { id: true, name: true, email: true } })
  // A name, else the part of the address before @ (never the full address in a list).
  return new Map(rows.map((u) => [u.id, u.name || u.email.split('@')[0]]))
}

export async function listRuns(f: RunFilters, now = Date.now()) {
  const rows = await prisma.agentRun.findMany({
    where: runsWhere(f) as never,
    orderBy: runsOrderBy(f.sort) as never,
    take: f.limit + 1,
    select: { id: true, startedAt: true, userId: true, area: true, request: true, model: true, steps: true, durationMs: true, tokens: true, status: true },
  })
  const page = rows.slice(0, f.limit)
  const [names, spans] = await Promise.all([
    userNames(page.map((r) => r.userId)),
    page.length
      ? prisma.agentSpan.findMany({ where: { runId: { in: page.map((r) => r.id) }, kind: 'tool' }, select: { runId: true, kind: true, effect: true, status: true } })
      : Promise.resolve([]),
  ])
  const byRun = new Map<string, typeof spans>()
  for (const s of spans) (byRun.get(s.runId) ?? byRun.set(s.runId, []).get(s.runId)!).push(s)

  return {
    runs: page.map((r) => ({
      id: r.id,
      at: r.startedAt.toISOString(),
      user: { id: r.userId, name: r.userId ? names.get(r.userId) ?? null : null },
      area: r.area,
      request: requestPreview(r.request),
      model: r.model,
      steps: r.steps,
      durationMs: r.durationMs,
      tokens: r.tokens,
      status: r.status,
      changes: changesOf(byRun.get(r.id) ?? []),
    })),
    stats: await todayStats(now),
    filters: await filterOptions(now),
    nextCursor: nextCursor(rows, f.sort, f.limit),
  }
}

/** Who and which areas appear in the kept window (runs are purged after 90 days), for the filter selects. */
async function filterOptions(now: number) {
  const since = new Date(now - 90 * 86_400_000)
  const [people, areas] = await Promise.all([
    prisma.agentRun.findMany({ where: { startedAt: { gte: since }, userId: { not: null } }, select: { userId: true }, distinct: ['userId'], take: 200 }),
    prisma.agentRun.findMany({ where: { startedAt: { gte: since }, area: { not: null } }, select: { area: true }, distinct: ['area'], take: 100 }),
  ])
  const names = await userNames(people.map((p) => p.userId))
  return {
    people: people.map((p) => ({ id: p.userId!, name: names.get(p.userId!) ?? null })).sort((a, b) => (a.name ?? '').localeCompare(b.name ?? '')),
    areas: areas.map((a) => a.area!).sort(),
  }
}

async function todayStats(now: number) {
  const since = startOfDayUtc(now)
  const [runs, tools, draftsPending, blockedReads] = await Promise.all([
    prisma.agentRun.findMany({ where: { startedAt: { gte: since } }, select: { status: true, tokens: true, costEstimate: true }, take: 5000 }),
    prisma.agentSpan.groupBy({
      by: ['label'],
      where: { kind: 'tool', run: { startedAt: { gte: since } } },
      _count: { _all: true },
      orderBy: { _count: { label: 'desc' } },
      take: TOP_TOOLS,
    }),
    prisma.adeChangeSet.count({ where: { status: { in: ['pending', 'partial'] }, source: 'chat' } }),
    countBlockedReads(since),
  ])
  return {
    runsToday: runs.length,
    errorRate: errorRate(runs.map((r) => r.status)),
    tokens: runs.reduce((n, r) => n + r.tokens, 0),
    cost: Math.round(runs.reduce((n, r) => n + r.costEstimate, 0) * 10_000) / 10_000,
    topTools: tools.map((t) => ({ name: t.label, count: t._count._all })),
    draftsPending,
    blockedReads,
  }
}

/** Reads the visibility policy blocked or masked since then (span status blocked|masked). */
function countBlockedReads(since: Date): Promise<number> {
  // Plain redaction (reason 'redaction') is in the trace but isn't a blocked read.
  return prisma.agentSpan.count({ where: { status: { in: ['blocked', 'masked'] }, run: { startedAt: { gte: since } }, NOT: { inputRedacted: { path: ['reason'], equals: PLAIN_REDACTION } } } })
}

export async function getRun(id: string) {
  const run = await prisma.agentRun.findUnique({ where: { id }, include: { spans: { orderBy: { seq: 'asc' } } } })
  if (!run) return null
  const csIds = [...new Set(run.spans.map((s) => s.changeSetId).filter((x): x is string => !!x))]
  const auditIds = run.spans.map((s) => s.auditLogId).filter((x): x is string => !!x)
  const [names, changeSets, audit] = await Promise.all([
    userNames([run.userId]),
    csIds.length
      ? prisma.adeChangeSet.findMany({ where: { id: { in: csIds } }, select: { id: true, title: true, status: true, _count: { select: { items: true } } } })
      : Promise.resolve([]),
    prisma.auditLog.findMany({ where: runAuditWhere(run.id, auditIds), select: { id: true, action: true, targetType: true, targetId: true, createdAt: true }, orderBy: { createdAt: 'asc' }, take: 100 }),
  ])
  return {
    run: {
      id: run.id,
      at: run.startedAt.toISOString(),
      endedAt: run.endedAt?.toISOString() ?? null,
      user: { id: run.userId, name: run.userId ? names.get(run.userId) ?? null : null },
      area: run.area,
      route: run.route,
      request: run.request,
      model: run.model,
      effort: run.effort,
      status: run.status,
      error: run.error,
      steps: run.steps,
      durationMs: run.durationMs,
      tokensIn: run.tokensIn,
      tokensOut: run.tokensOut,
      cacheRead: run.cacheRead,
      cacheWrite: run.cacheWrite,
      cost: run.costEstimate,
      toolGroupsLoaded: run.toolGroupsLoaded,
      conversationId: run.conversationId,
      droppedSpans: run.droppedSpans,
    },
    spans: run.spans.map((s) => ({
      id: s.id,
      parentId: s.parentId,
      seq: s.seq,
      kind: s.kind,
      label: s.label,
      startMs: s.startMs,
      endMs: s.endMs,
      status: s.status,
      attempt: s.attempt,
      tokens: s.tokens,
      detail: s.detail,
      effect: s.effect,
      changeSetId: s.changeSetId,
      auditLogId: s.auditLogId,
      input: s.inputRedacted,
      output: s.outputSummary,
    })),
    changeSets: changeSets.map((c) => ({ id: c.id, title: c.title, status: c.status, items: c._count.items, href: `/admin/review?set=${encodeURIComponent(c.id)}` })),
    audit: audit.map((a) => ({ id: a.id, action: a.action, targetType: a.targetType, targetId: a.targetId, at: a.createdAt.toISOString() })),
  }
}

export async function activitySummary(since: Date) {
  const [runs, failures, writes, drafts, settings, blockedReads] = await Promise.all([
    prisma.agentRun.findMany({ where: { startedAt: { gte: since } }, select: { tokens: true, costEstimate: true, userId: true, status: true }, take: 10_000 }),
    prisma.agentRun.findMany({
      // Real failures only: not a pause for the screen (waiting), not a budget stop.
      where: { startedAt: { gte: since }, status: { in: [...FAILURE_STATUSES] } },
      orderBy: { startedAt: 'desc' },
      take: MAX_FAILURES,
      select: { id: true, request: true, startedAt: true, status: true },
    }),
    prisma.agentSpan.count({ where: { kind: 'tool', effect: { in: ['write', 'irreversible'] }, status: { not: 'error' }, run: { startedAt: { gte: since } } } }),
    prisma.agentSpan.findMany({ where: { changeSetId: { not: null }, run: { startedAt: { gte: since } } }, select: { changeSetId: true }, distinct: ['changeSetId'] }),
    getAiSettings(),
    countBlockedReads(since),
  ])
  const csIds = drafts.map((d) => d.changeSetId!).filter(Boolean)
  const draftsAwaiting = csIds.length ? await prisma.adeChangeSet.count({ where: { id: { in: csIds }, status: { in: ['pending', 'partial'] } } }) : 0
  return {
    since: since.toISOString(),
    runs: runs.length,
    failures: failures.map((r) => ({ id: r.id, request: requestPreview(r.request), at: r.startedAt.toISOString(), status: r.status })),
    /** All real failures (error/aborted) in the window — `failures` lists at most 10. */
    failedCount: runs.filter((r) => isFailure(r.status)).length,
    writes,
    draftsAwaiting,
    /** Reads the visibility policy blocked or masked ("2 reads blocked"). */
    blockedReads,
    spend: {
      tokens: runs.reduce((n, r) => n + r.tokens, 0),
      cost: Math.round(runs.reduce((n, r) => n + r.costEstimate, 0) * 10_000) / 10_000,
      budgetTokens: settings.dailyTokenBudget ?? 0,
      people: new Set(runs.map((r) => r.userId).filter(Boolean)).size,
    },
  }
}
