/**
 * What the assistant may read of a form's submissions (owner 2026-11-16: careful with
 * personal details, otherwise helpful). Names, message, status and date, a few at a time;
 * emails hidden unless contact details were asked for; nothing else a submission holds.
 * Pure; checked by assistant-submissions.assert.ts.
 */

export const ASSISTANT_SUBMISSIONS_MAX = 25

export interface SummaryRow {
  name: string | null
  email: string | null
  message: string
  status: string
  starred: boolean
  createdAt: Date | string
}

export interface AssistantSubmissionRow {
  name: string | null
  email: string | null
  message: string
  status: string
  starred: boolean
  date: string
}

/** A flag or count as the model sends it: true / "true", 10 / "10" (Haiku sends text, walk 2026-11-16). */
export function asFlag(v: unknown): unknown {
  if (v === 'true') return true
  if (v === 'false') return false
  return v
}
export function asCount(v: unknown): unknown {
  return typeof v === 'string' && /^\d+$/.test(v.trim()) ? Number(v.trim()) : v
}

const EMAIL = /^([^\s@]+)@([^\s@]+\.[^\s@]+)$/

/** "jane.doe@gmail.com" → "j…@gmail.com"; a confidential mask is kept; anything else is "hidden". */
export function maskEmail(email: string | null | undefined): string | null {
  if (email == null || email === '') return null
  if (email === '[private]') return email
  const m = EMAIL.exec(email.trim())
  return m ? `${m[1][0]}…@${m[2]}` : 'hidden'
}

export function assistantSubmissions(
  rows: readonly SummaryRow[],
  opts: { total: number; contact: boolean; limit?: number },
): { rows: AssistantSubmissionRow[]; total: number; more: number; note: string } {
  const limit = Math.max(1, Math.min(ASSISTANT_SUBMISSIONS_MAX, Math.floor(opts.limit ?? 10)))
  const shown = rows.slice(0, limit).map((r) => ({
    name: r.name,
    email: opts.contact ? r.email : maskEmail(r.email),
    message: r.message,
    status: r.status,
    starred: r.starred,
    date: new Date(r.createdAt).toISOString().slice(0, 10),
  }))
  const note = opts.contact
    ? 'Contact details are shown because they were asked for. Share contact details only with the person asking; do not copy them into pages, posts or emails to anyone else.'
    : 'Email addresses are hidden. Give them only if the person asks for contact details (call again with contact: true).'
  return { rows: shown, total: opts.total, more: Math.max(0, opts.total - shown.length), note }
}
