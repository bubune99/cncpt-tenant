/**
 * Pure block-tree rewrites used by scripts/upgrade-live-forms.ts to turn the
 * plain-markup volunteer form and footer newsletter (imported from the
 * original site) into the real FormBlock / NewsletterSignup smart blocks.
 *
 * Idempotent: a tree that already contains the smart block is left alone.
 * Asserted by live-upgrade.assert.ts.
 */

export interface TreeBlock {
  id: string
  tag: string
  className?: string
  textContent?: string
  attrs?: Record<string, string>
  children?: TreeBlock[]
  componentName?: string
  [key: string]: unknown
}

type Marker = (b: TreeBlock) => boolean

function containsComponent(blocks: TreeBlock[], name: string): boolean {
  return blocks.some((b) => b.componentName === name || containsComponent(b.children ?? [], name))
}

function textOf(b: TreeBlock): string {
  return [b.textContent ?? '', ...(b.children ?? []).map(textOf)].join(' ').trim()
}

/**
 * Replace the SMALLEST subtree that contains every marker with `make(old)`.
 * Returns the new tree and whether anything changed. Input is not mutated.
 */
export function replaceSmallestContaining(
  blocks: TreeBlock[],
  markers: Marker[],
  make: (old: TreeBlock) => TreeBlock
): { blocks: TreeBlock[]; changed: boolean } {
  let changed = false

  const hits = (b: TreeBlock): boolean[] => {
    const own = markers.map((m) => m(b))
    for (const c of b.children ?? []) {
      hits(c).forEach((h, i) => { if (h) own[i] = true })
    }
    return own
  }

  const walk = (list: TreeBlock[]): TreeBlock[] =>
    list.map((b) => {
      if (changed) return b
      if (!hits(b).every(Boolean)) return b
      const childWithAll = (b.children ?? []).some((c) => hits(c).every(Boolean))
      if (childWithAll) return { ...b, children: walk(b.children ?? []) }
      changed = true
      return make(b)
    })

  const out = walk(blocks)
  return { blocks: changed ? out : blocks, changed }
}

export function upgradeVolunteerForm(blocks: TreeBlock[]): { blocks: TreeBlock[]; changed: boolean } {
  if (containsComponent(blocks, 'FormBlock')) return { blocks, changed: false }
  return replaceSmallestContaining(
    blocks,
    [
      (b) => b.tag === 'input' && b.attrs?.name === 'firstName',
      (b) => b.tag === 'textarea',
      (b) => b.tag === 'button' && /send/i.test(textOf(b)),
    ],
    (old) => ({
      id: old.id,
      tag: 'div',
      className: 'bg-white border border-gray-200 p-8 md:p-12 max-w-[800px] mx-auto',
      componentName: 'FormBlock',
      label: 'Volunteer form',
      attrs: { 'data-form-slug': 'volunteer', 'data-show-title': 'false' },
    })
  )
}

export function upgradeNewsletter(blocks: TreeBlock[]): { blocks: TreeBlock[]; changed: boolean } {
  if (containsComponent(blocks, 'NewsletterSignup')) return { blocks, changed: false }
  return replaceSmallestContaining(
    blocks,
    [
      (b) => b.tag === 'input' && b.attrs?.type === 'email',
      (b) => b.tag === 'button' && /sign\s*up/i.test(textOf(b)),
    ],
    (old) => ({
      id: old.id,
      tag: 'div',
      className: 'max-w-md mx-auto',
      componentName: 'NewsletterSignup',
      label: 'Newsletter signup',
      attrs: { 'data-placeholder': 'Email address', 'data-button-text': 'Sign Up' },
    })
  )
}
