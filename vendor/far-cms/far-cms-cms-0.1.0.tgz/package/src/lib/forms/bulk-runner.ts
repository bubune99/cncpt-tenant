/**
 * Bulk runs — ONE engine for both entry points: "this rule changed, run it
 * for past submissions too?" and "select submissions → Run an action / a
 * rule". Always previewed first (planBulk, pure), then run as a job in small
 * steps the browser drives (so it shows progress and can stop part-way;
 * emails stay under the per-minute cap). Each action goes through the same
 * runAction as automatic runs: idempotent per (submission, action), consent
 * checked, money → To-do approval, recorded on the submission's timeline.
 */

import { prisma } from '../db'
import { isCommerceEnabled } from '../features'
import { actionSpec, normalizeRules, ruleMatches, type Answers, type FormRule, type RuleAction } from './automations'
import { normalizeFormDoc, type FormDoc } from './doc'
import { BULK_STEP, inboxStatus, planBulk, type BulkRowPlan } from './inbox'
import { loadRunContext, runAction } from './automation-runner'

export type BulkSpecInput =
  | { kind: 'rule'; rule: unknown; scope: 'all' | string[] }
  | { kind: 'action'; action: unknown; scope: string[] }

export interface CleanSpec {
  title: string
  ruleId: string | null
  ruleName: string | null
  conditions: FormRule['conditions']
  actions: RuleAction[]
  scope: 'all' | string[]
}

const ID = /^[A-Za-z0-9_-]{1,80}$/
const MAX_SCOPE = 2000

/** Validate what the browser asked for; only registered actions survive. */
export function cleanSpec(raw: unknown): CleanSpec | { error: string } {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const scope = o.scope === 'all' ? 'all' : Array.isArray(o.scope) ? o.scope.filter((x): x is string => typeof x === 'string' && ID.test(x)).slice(0, MAX_SCOPE) : null
  if (!scope || (Array.isArray(scope) && !scope.length)) return { error: 'Choose some submissions first' }
  if (o.kind === 'rule') {
    const [rule] = normalizeRules([o.rule])
    if (!rule || !rule.actions.length) return { error: 'That rule has no actions' }
    return { title: `Run “${rule.name}”`, ruleId: rule.id, ruleName: rule.name, conditions: rule.conditions, actions: rule.actions, scope }
  }
  if (o.kind === 'action') {
    if (scope === 'all') return { error: 'Choose some submissions first' }
    const [rule] = normalizeRules([{ name: 'one-off', actions: [{ id: 'bulk', ...((o.action ?? {}) as object) }] }])
    if (!rule?.actions.length) return { error: 'Fill in the action’s details first' }
    return { title: actionSpec(rule.actions[0].type)!.label, ruleId: null, ruleName: null, conditions: [], actions: rule.actions, scope }
  }
  return { error: 'Unknown bulk run' }
}

interface Loaded {
  doc: FormDoc
  subs: Array<{ id: string; data: Answers; done: Set<string> }>
}

async function load(formId: string, spec: CleanSpec): Promise<Loaded | null> {
  const form = await prisma.form.findUnique({ where: { id: formId }, select: { name: true, description: true, status: true, submitButtonText: true, successMessage: true, notifyEmails: true, fields: true, display: true, automations: true } })
  if (!form) return null
  const doc = normalizeFormDoc(form as unknown as Record<string, unknown>)
  const rows = await prisma.formSubmission.findMany({
    where: { formId, ...(spec.scope === 'all' ? {} : { id: { in: spec.scope } }) },
    orderBy: { createdAt: 'desc' },
    take: MAX_SCOPE,
    select: { id: true, data: true, status: true, read: true },
  })
  // "Past submissions" never include archived ones.
  const live = spec.scope === 'all' ? rows.filter((r) => inboxStatus(r) !== 'archived') : rows
  const runs = await prisma.formRuleRun.findMany({ where: { submissionId: { in: live.map((r) => r.id) }, dedupeKey: { not: null } }, select: { submissionId: true, actionKey: true } })
  const done = new Map<string, Set<string>>()
  for (const r of runs) done.set(r.submissionId, (done.get(r.submissionId) ?? new Set()).add(r.actionKey))
  return { doc, subs: live.map((r) => ({ id: r.id, data: (r.data ?? {}) as Answers, done: done.get(r.id) ?? new Set() })) }
}

export interface BulkPreview {
  title: string
  actions: RuleAction[]
  rows: BulkRowPlan[]
  willRun: number
  approvals: number
  skipped: number
  emails: number
  /** Submissions a run would actually touch. */
  runIds: string[]
}

/**
 * Sending answers off-site (webhook) or to addresses typed just now (alert
 * with its own recipients) only runs exactly as an APPROVED automation has
 * it — a bulk run must not become a way around review.
 */
export function outsideApproved(spec: CleanSpec, live: FormDoc): string | null {
  const approved = live.automations.flatMap((r) => r.actions)
  for (const a of spec.actions) {
    const risky = a.type === 'webhook' || (a.type === 'alert_owner' && !!a.params.to)
    if (!risky) continue
    const same = approved.some((x) => x.type === a.type && JSON.stringify(x.params) === JSON.stringify(a.params))
    if (!same) return 'Sending answers to another service or to new addresses only runs from an approved automation. Save the rule, get it approved, then run it for past submissions.'
  }
  return null
}

export async function previewBulk(formId: string, spec: CleanSpec): Promise<BulkPreview | null | { error: string }> {
  const loaded = await load(formId, spec)
  if (!loaded) return null
  const blocked = outsideApproved(spec, loaded.doc)
  if (blocked) return { error: blocked }
  const rule = { id: spec.ruleId ?? 'bulk', name: spec.title, enabled: true, conditions: spec.conditions, actions: spec.actions }
  const matching = loaded.subs.filter((s) => ruleMatches(rule, s.data))
  const plan = planBulk(loaded.doc.fields, matching, spec.actions, { commerceEnabled: await isCommerceEnabled(), sendsEmail: (t) => !!actionSpec(t)?.sendsEmail })
  // Selected rows the rule's conditions leave out are shown, not hidden.
  const outside = spec.scope === 'all' ? [] : loaded.subs.filter((s) => !matching.includes(s))
  const outsideRows: BulkRowPlan[] = planBulk(loaded.doc.fields, outside, [], { commerceEnabled: false, sendsEmail: () => false }).rows.map((r) => ({ ...r, verdict: { kind: 'skip', label: 'Skipped — doesn’t match this rule' } }))
  return {
    title: spec.title,
    actions: spec.actions,
    rows: [...plan.rows, ...outsideRows],
    willRun: plan.willRun,
    approvals: plan.approvals,
    skipped: plan.skipped + outsideRows.length,
    emails: plan.emails,
    runIds: plan.rows.filter((r) => r.verdict.kind !== 'skip').map((r) => r.id),
  }
}

export interface JobProgress {
  id: string
  status: string
  total: number
  cursor: number
  ran: number
  skipped: number
  failed: number
  /** Emails sent in the last step (the browser waits accordingly). */
  emails?: number
}

function progressOf(j: { id: string; status: string; total: number; cursor: number; ran: number; skipped: number; failed: number }): JobProgress {
  return { id: j.id, status: j.status, total: j.total, cursor: j.cursor, ran: j.ran, skipped: j.skipped, failed: j.failed }
}

/** Create the job from a fresh preview (never from the browser's idea of who matches). */
export async function startBulk(formId: string, spec: CleanSpec, userId: string): Promise<JobProgress | { error: string }> {
  const preview = await previewBulk(formId, spec)
  if (!preview) return { error: 'Form not found' }
  if ('error' in preview) return preview
  if (!preview.runIds.length) return { error: 'Nothing would run — every submission is skipped' }
  const job = await prisma.formBulkJob.create({
    data: {
      formId,
      title: spec.title,
      spec: { submissionIds: preview.runIds, actions: spec.actions, ruleId: spec.ruleId, ruleName: spec.ruleName } as object,
      total: preview.runIds.length,
      createdById: userId,
    },
  })
  return progressOf(job)
}

interface StoredSpec {
  submissionIds: string[]
  actions: RuleAction[]
  ruleId: string | null
  ruleName: string | null
}

/** Run one window of submissions; counts what happened. */
async function runWindow(ids: string[], actions: RuleAction[], meta: { ruleId: string | null; ruleName: string; jobId: string }) {
  const out = { ran: 0, skipped: 0, failed: 0, emails: 0 }
  for (const sid of ids) {
    const loaded = await loadRunContext(sid)
    if (!loaded) {
      out.skipped++
      continue
    }
    let any = false
    for (const a of actions) {
      const r = await runAction(a, loaded.ctx, { source: 'bulk', ruleId: meta.ruleId, ruleName: meta.ruleName, jobId: meta.jobId })
      if (r.status === 'done' || r.status === 'needs_approval') {
        any = true
        if (r.status === 'done' && actionSpec(a.type)?.sendsEmail) out.emails++
      }
      if (r.status === 'failed') out.failed++
    }
    if (any) out.ran++
    else out.skipped++
  }
  return out
}

/** Run the next few submissions. The cursor is claimed atomically, so two tabs can't double-step. */
export async function stepBulk(formId: string, jobId: string): Promise<JobProgress | { error: string }> {
  const job = await prisma.formBulkJob.findFirst({ where: { id: jobId, formId } })
  if (!job) return { error: 'Job not found' }
  if (job.status !== 'running') return progressOf(job)
  const spec = job.spec as unknown as StoredSpec
  const ids = spec.submissionIds.slice(job.cursor, job.cursor + BULK_STEP)
  const end = job.cursor + ids.length
  const claimed = await prisma.formBulkJob.updateMany({ where: { id: jobId, cursor: job.cursor, status: 'running' }, data: { cursor: end } })
  if (!claimed.count) return progressOf((await prisma.formBulkJob.findUnique({ where: { id: jobId } }))!)
  // Re-validate the stored actions (data, never code).
  const [rule] = normalizeRules([{ name: 'bulk', actions: spec.actions }])
  let counts: Awaited<ReturnType<typeof runWindow>>
  try {
    counts = await runWindow(ids, rule?.actions ?? [], { ruleId: spec.ruleId, ruleName: spec.ruleName ?? job.title, jobId })
  } catch (e) {
    // Give the window back so the next step retries it (actions that already
    // ran are deduplicated per submission, so nothing runs twice).
    await prisma.formBulkJob.updateMany({ where: { id: jobId, cursor: end }, data: { cursor: job.cursor } })
    throw e
  }
  await prisma.formBulkJob.update({ where: { id: jobId }, data: { ran: { increment: counts.ran }, skipped: { increment: counts.skipped }, failed: { increment: counts.failed } } })
  // Finished — unless a Stop landed while this window ran (a stop wins).
  if (end >= job.total) await prisma.formBulkJob.updateMany({ where: { id: jobId, status: 'running' }, data: { status: 'done' } })
  const next = (await prisma.formBulkJob.findUnique({ where: { id: jobId } }))!
  return { ...progressOf(next), emails: counts.emails }
}

export async function stopBulk(formId: string, jobId: string): Promise<JobProgress | { error: string }> {
  await prisma.formBulkJob.updateMany({ where: { id: jobId, formId, status: 'running' }, data: { status: 'stopped' } })
  const job = await prisma.formBulkJob.findFirst({ where: { id: jobId, formId } })
  return job ? progressOf(job) : { error: 'Job not found' }
}

export async function jobProgress(formId: string, jobId: string): Promise<JobProgress | null> {
  const job = await prisma.formBulkJob.findFirst({ where: { id: jobId, formId } })
  return job ? progressOf(job) : null
}
