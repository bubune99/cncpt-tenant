/**
 * Server side of the submissions inbox: load a form's rows once and apply the
 * pure filters (lib/forms/inbox) — tab, search, filter by answer.
 */

import { prisma } from '../db'
import { normalizeFormDoc, type FormDoc } from './doc'
import { contactOf, type Answers, type ConditionOp, type RuleCondition } from './automations'
import { inTab, inboxStatus, matchesAnswer, matchesSearch, messageOf, tabCounts, type InboxRow, type InboxTab } from './inbox'
import { answersById } from './answers'

/** Newest first; enough for a non-profit's inbox, and bounded. */
export const INBOX_LIMIT = 2000

export interface InboxQuery {
  tab: InboxTab
  q: string
  filter: RuleCondition | null
  ids?: string[] | null
}

const TABS: InboxTab[] = ['all', 'new', 'starred', 'replied', 'archived']
const OPS: ConditionOp[] = ['contains', 'is', 'checked', 'not_checked']

export function inboxQueryFrom(sp: URLSearchParams): InboxQuery {
  const tab = TABS.includes(sp.get('tab') as InboxTab) ? (sp.get('tab') as InboxTab) : 'all'
  const field = sp.get('field')
  const op = sp.get('op') as ConditionOp | null
  const filter = field && op && OPS.includes(op) ? { fieldId: field.slice(0, 80), op, value: (sp.get('value') ?? '').slice(0, 200) } : null
  const ids = sp.get('ids')
  return { tab, q: (sp.get('q') ?? '').slice(0, 200), filter, ids: ids ? ids.split(',').filter((x) => /^[A-Za-z0-9_-]{1,80}$/.test(x)).slice(0, INBOX_LIMIT) : null }
}

export interface LoadedInbox {
  doc: FormDoc
  all: InboxRow[]
  rows: InboxRow[]
  counts: Record<InboxTab, number>
}

export async function loadInbox(formId: string, query: InboxQuery): Promise<LoadedInbox | null> {
  const form = await prisma.form.findUnique({ where: { id: formId }, select: { id: true, name: true, description: true, status: true, submitButtonText: true, successMessage: true, notifyEmails: true, fields: true, display: true, automations: true } })
  if (!form) return null
  const doc = normalizeFormDoc(form as unknown as Record<string, unknown>)
  const raw = await prisma.formSubmission.findMany({
    where: { formId, ...(query.ids ? { id: { in: query.ids } } : {}) },
    orderBy: { createdAt: 'desc' },
    take: INBOX_LIMIT,
    select: { id: true, data: true, status: true, read: true, starred: true, createdAt: true },
  })
  const all: InboxRow[] = raw.map((r) => ({ ...r, data: answersById(doc.fields, (r.data ?? {}) as Answers) as Answers }))
  const rows = query.ids ? all : all.filter((r) => inTab(r, query.tab) && matchesSearch(r, query.q) && matchesAnswer(r, query.filter))
  return { doc, all, rows, counts: tabCounts(all) }
}

export function rowSummary(doc: FormDoc, r: InboxRow) {
  const c = contactOf(doc.fields, r.data)
  return { id: r.id, name: c.name, email: c.email, message: messageOf(doc.fields, r.data).slice(0, 200), status: inboxStatus(r), starred: r.starred, createdAt: r.createdAt }
}
