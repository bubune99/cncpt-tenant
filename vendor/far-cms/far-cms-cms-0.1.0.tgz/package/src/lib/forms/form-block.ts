/**
 * The Form block in the page builder (owner 2026-10-19): pick WHICH form in the block's settings; how it
 * appears (on the page, pop-up, slide-in — when it opens, how often) is the form's own setting, made on
 * the form's page. So a form that shows as a pop-up or slide-in sends you there to set it up.
 * Pure; asserted by form-block.assert.ts.
 */

import { placementFrom, type FormPlacement } from './doc'

export interface FormOptionLike {
  id: string
  name: string
  slug: string
  status: string
  display?: unknown
}

export type FormBlockState =
  | { kind: 'none' }
  | { kind: 'missing'; slug: string }
  | { kind: 'page'; form: FormOptionLike; editHref: string }
  | { kind: 'overlay'; form: FormOptionLike; placement: FormPlacement; note: string; editHref: string; settingsHref: string }

export const formEditHref = (id: string) => `/admin/forms/${encodeURIComponent(id)}`
export const formSettingsHref = (id: string) => `/admin/forms/${encodeURIComponent(id)}?tab=settings`

const OPENS_WORDS: Record<FormPlacement['opens'], (p: FormPlacement) => string> = {
  click: () => 'when a button is clicked',
  delay: (p) => `${p.delaySeconds} second${p.delaySeconds === 1 ? '' : 's'} after the page opens`,
  scroll: () => 'when the visitor scrolls halfway down',
  exit: () => 'when the visitor is about to leave',
}

/** What the block's settings should say for the chosen form. */
export function formBlockState(slug: string | undefined | null, forms: readonly FormOptionLike[]): FormBlockState {
  const s = (slug ?? '').trim()
  if (!s) return { kind: 'none' }
  const form = forms.find((f) => f.slug === s)
  if (!form) return { kind: 'missing', slug: s }
  const placement = placementFrom(form.display)
  if (placement.showAs === 'page') return { kind: 'page', form, editHref: formEditHref(form.id) }
  const as = placement.showAs === 'popup' ? 'a pop-up' : 'a slide-in'
  return {
    kind: 'overlay',
    form,
    placement,
    note: `This form shows as ${as}, ${OPENS_WORDS[placement.opens](placement)}. When and how often it opens is set on the form’s page.`,
    editHref: formEditHref(form.id),
    settingsHref: formSettingsHref(form.id),
  }
}

/** The canvas placeholder's line for a Form block. */
export function formBlockSummary(slug: string | undefined | null, forms: readonly FormOptionLike[]): string {
  const st = formBlockState(slug, forms)
  if (st.kind === 'none') return 'Choose which form to show in this block’s settings'
  if (st.kind === 'missing') return `Form “${st.slug}” isn’t found — choose another in this block’s settings`
  if (st.kind === 'page') return st.form.name
  return `${st.form.name} · ${st.placement.showAs === 'popup' ? 'pop-up' : 'slide-in'} (set up on the form’s page)`
}
