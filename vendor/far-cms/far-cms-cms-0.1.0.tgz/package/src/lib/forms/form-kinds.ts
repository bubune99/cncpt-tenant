/**
 * The kinds of form the Forms list offers to start from, and the fields each
 * starts with. Owner, 2026-11-16: "Each starts a new form of that kind."
 * Pure; asserted by form-kinds.assert.ts.
 */
import type { FormField } from './types'

export type FormKindKey = 'contact' | 'survey' | 'registration'

export interface FormKind {
  key: FormKindKey
  label: string
  description: string
  /** The name New form suggests; the person can change it. */
  startName: string
  fields: FormField[]
}

const required = (label: string) => [{ type: 'required' as const, message: `${label} is required` }]

export const FORM_KINDS: readonly FormKind[] = [
  {
    key: 'contact',
    label: 'Contact Forms',
    description: 'Collect inquiries with name, email, and message fields',
    startName: 'Contact form',
    fields: [
      { id: 'contact-name', name: 'name', type: 'text', label: 'Name', width: 'half', validation: required('Name') },
      { id: 'contact-email', name: 'email', type: 'email', label: 'Email', width: 'half', validation: required('Email') },
      { id: 'contact-message', name: 'message', type: 'textarea', label: 'Message', rows: 5, validation: required('Message') },
    ],
  },
  {
    key: 'survey',
    label: 'Surveys',
    description: 'Gather feedback with multiple choice and rating fields',
    startName: 'Survey',
    fields: [
      {
        id: 'survey-rating', name: 'rating', type: 'radio', label: 'How would you rate your experience?',
        description: '1 is poor, 5 is excellent',
        options: ['1', '2', '3', '4', '5'].map((v) => ({ value: v, label: v })),
        validation: required('A rating'),
      },
      {
        id: 'survey-heard', name: 'heard_from', type: 'select', label: 'How did you hear about us?',
        options: [
          { value: 'friend', label: 'A friend or family member' },
          { value: 'social', label: 'Social media' },
          { value: 'event', label: 'An event' },
          { value: 'other', label: 'Somewhere else' },
        ],
      },
      { id: 'survey-comments', name: 'comments', type: 'textarea', label: 'Anything else you would like to tell us?', rows: 4 },
    ],
  },
  {
    key: 'registration',
    label: 'Registration Forms',
    description: 'Sign up forms for events, newsletters, and more',
    startName: 'Registration form',
    fields: [
      { id: 'reg-name', name: 'full_name', type: 'text', label: 'Full name', validation: required('Full name') },
      { id: 'reg-email', name: 'email', type: 'email', label: 'Email', width: 'half', validation: required('Email') },
      { id: 'reg-phone', name: 'phone', type: 'phone', label: 'Phone', width: 'half' },
      { id: 'reg-updates', name: 'updates', type: 'checkbox', label: 'Send me news and updates' },
    ],
  },
]

export function formKind(key: string | null | undefined): FormKind | null {
  return FORM_KINDS.find((k) => k.key === key) ?? null
}

export function kindHref(key: FormKindKey): string {
  return `/admin/forms/new?kind=${key}`
}
