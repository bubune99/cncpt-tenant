/**
 * Runs form automations (server only). The decisions — which rules match,
 * consent, money, "already got it" — are the pure ones in automations.ts;
 * this file performs the actions and records each one as a FormRuleRun (the
 * submission's "What happened" timeline).
 *
 * Idempotency: before an action runs, its run row is inserted with
 * dedupeKey = (submission, action key). The unique index makes a second
 * attempt — a re-run, a bulk run, a double-fired event — fail the insert and
 * be recorded as "Already got it" instead of acting twice. A failed action
 * releases its key so it can be tried again.
 */

import { postJsonPinned } from './webhook-post'
import { prisma } from '../db'
import { isCommerceEnabled } from '../features'
import { sendEmail } from '../email'
import { subscribeEmail } from '../email/subscriptions'
import { renderEmailTemplateBySlug } from '../email/templates/render'
import { sendFormNotification } from './notifications'
import { normalizeFormDoc, type FormDoc } from './doc'
import {
  actionKey,
  actionSpec,
  contactOf,
  dedupeKeyFor,
  marketingConsent,
  planAction,
  ruleMatches,
  safeWebhookUrl,
  type Answers,
  type FormRule,
  type Outcome,
  type RuleAction,
} from './automations'
import { answersById } from './answers'

export type RunSource = 'auto' | 'bulk' | 'test'
export type RunStatus = 'done' | 'skipped' | 'failed' | 'needs_approval' | 'running'

export interface ActionResult {
  actionId: string
  type: string
  status: RunStatus | 'would_run' | 'would_skip' | 'would_need_approval'
  detail: string
}

interface Ctx {
  formId: string
  doc: FormDoc
  slug: string
  submissionId: string
  answers: Answers
  commerceEnabled: boolean
  /** The submission's IP, already hashed at submit time (consent record for newsletter signups). */
  ipHash: string | null
}

const WEBHOOK_TIMEOUT_MS = 5000
/** A claim still "running" after this long died with its process — it may be taken again. */
const STALE_RUNNING_MS = 5 * 60_000

function isUnique(e: unknown): boolean {
  return !!e && typeof e === 'object' && (e as { code?: string }).code === 'P2002'
}

/** actionKeys this submission already got (done or waiting for approval). */
export async function doneKeys(submissionId: string): Promise<Set<string>> {
  const rows = await prisma.formRuleRun.findMany({ where: { submissionId, dedupeKey: { not: null } }, select: { actionKey: true, status: true, createdAt: true } })
  const stale = Date.now() - STALE_RUNNING_MS
  return new Set(rows.filter((r) => !(r.status === 'running' && r.createdAt.getTime() < stale)).map((r) => r.actionKey))
}

/** Release a claim whose process died mid-action, so the action can run again. */
async function releaseStaleClaim(dedupeKey: string): Promise<boolean> {
  const r = await prisma.formRuleRun.updateMany({
    where: { dedupeKey, status: 'running', createdAt: { lt: new Date(Date.now() - STALE_RUNNING_MS) } },
    data: { status: 'failed', detail: 'Interrupted — tried again', dedupeKey: null },
  })
  return r.count > 0
}

function adminLink(ctx: Ctx): string {
  return `/admin/forms/${ctx.formId}?tab=submissions&s=${ctx.submissionId}`
}

/** Perform one action for real. Throws on failure (the caller records it). */
async function perform(a: RuleAction, ctx: Ctx): Promise<string> {
  const who = contactOf(ctx.doc.fields, ctx.answers)
  switch (a.type) {
    case 'newsletter': {
      const r = await subscribeEmail(who.email!, { name: who.name || undefined, source: `form:${ctx.slug}`, tags: [a.params.list || 'Newsletter'], channel: 'public', consentIp: ctx.ipHash ?? undefined })
      if (!r.success) throw new Error(r.error || 'Could not add them to the newsletter')
      return r.error === 'Already subscribed' ? 'Already on the newsletter' : 'Asked them to confirm by email'
    }
    case 'tag': {
      const tag = a.params.tag
      const sub = await prisma.formSubmission.findUnique({ where: { id: ctx.submissionId }, select: { tags: true } })
      if (sub && !sub.tags.includes(tag)) await prisma.formSubmission.update({ where: { id: ctx.submissionId }, data: { tags: { push: tag } } })
      if (who.email) {
        const s = await prisma.emailSubscriber.findUnique({ where: { email: who.email }, select: { tags: true } })
        if (s && !s.tags.includes(tag)) await prisma.emailSubscriber.update({ where: { email: who.email }, data: { tags: { push: tag } } })
      }
      return `Tagged ${tag}`
    }
    case 'email':
    case 'promo_email': {
      // A promotional email is marketing: only to a confirmed (ACTIVE) subscriber, with
      // suppression, footer and unsubscribe from the send path. A plain reply is transactional.
      let subscriberId: string | undefined
      if (a.type === 'promo_email') {
        const sub = await prisma.emailSubscriber.findUnique({ where: { email: who.email! }, select: { id: true, status: true } })
        if (!sub || sub.status !== 'ACTIVE') throw new Error('Not sent: they haven’t confirmed a newsletter sign-up, so they can’t get promotional email')
        subscriberId = sub.id
      }
      const rendered = await renderEmailTemplateBySlug(a.params.template, { name: who.name, email: who.email, form: ctx.doc.name, answers: ctx.answers })
      if (!rendered) throw new Error(`There is no email template “${a.params.template}”`)
      const r = await sendEmail({
        to: { email: who.email!, name: who.name || undefined },
        subject: rendered.subject ?? ctx.doc.name,
        html: rendered.html,
        tags: ['form-automation', a.type],
        category: a.type === 'promo_email' ? 'marketing' : 'transactional',
        subscriberId,
      })
      if (!r.success) throw new Error(r.error || 'The email could not be sent')
      return `Sent “${rendered.subject ?? a.params.template}” to ${who.email}`
    }
    case 'alert_owner': {
      const to = a.params.to ? a.params.to.split(/,\s*/) : ctx.doc.notifyEmails
      if (!to.length) throw new Error('No one to alert — add an address in Settings or on this action')
      await sendFormNotification({ formId: ctx.formId, formName: ctx.doc.name, submissionId: ctx.submissionId, submissionData: ctx.answers, notifyEmails: to, fields: ctx.doc.fields })
      return `Emailed ${to.join(', ')}`
    }
    case 'todo': {
      const title = `${a.params.title}${who.name ? ` — ${who.name}` : ''}`.slice(0, 200)
      await prisma.adeTask.upsert({
        where: { dedupeKey: `form-todo:${dedupeKeyFor(ctx.submissionId, a)}` },
        create: {
          source: 'automation',
          title,
          detail: `${a.params.for ? `For ${a.params.for}. ` : ''}From the “${ctx.doc.name}” form.`,
          href: adminLink(ctx),
          targetType: 'form-submission',
          targetId: ctx.submissionId,
          dedupeKey: `form-todo:${dedupeKeyFor(ctx.submissionId, a)}`,
          permission: 'forms.submissions',
        },
        update: {},
      })
      return `To-do: ${title}`
    }
    case 'webhook': {
      const url = safeWebhookUrl(a.params.url)
      if (!url) throw new Error('That web address isn’t allowed')
      // Resolved once, checked public, and connected to that address (no re-resolution, no redirects).
      const res = await postJsonPinned(url, { event: 'form.submitted', form: { id: ctx.formId, name: ctx.doc.name }, submissionId: ctx.submissionId, answers: ctx.answers }, {
        timeoutMs: WEBHOOK_TIMEOUT_MS,
        headers: { 'User-Agent': 'ProjectDzidzor-Forms/1' },
      })
      if (res.status < 200 || res.status >= 300) throw new Error(`The other service answered ${res.status}`)
      return `Sent to ${new URL(url).hostname}`
    }
    case 'store_credit':
      // Money never runs on its own — see requestApproval.
      throw new Error('Store credit needs approval')
  }
}

/** Money: record the request and put it in To-do for a person to approve. */
async function requestApproval(a: RuleAction, ctx: Ctx, runId: string): Promise<string> {
  const who = contactOf(ctx.doc.fields, ctx.answers)
  await prisma.adeTask.upsert({
    where: { dedupeKey: `form-approval:${runId}` },
    create: {
      source: 'approval',
      title: `Approve $${a.params.amount} store credit for ${who.name || who.email}`,
      detail: `From the “${ctx.doc.name}” form. Money needs your approval each time.`,
      href: adminLink(ctx),
      targetType: 'form-rule-run',
      targetId: runId,
      dedupeKey: `form-approval:${runId}`,
      permission: 'forms.submissions',
      priority: 1,
    },
    update: {},
  })
  return `Waiting for approval in To-do`
}

export interface RunMeta {
  source: RunSource
  ruleId?: string | null
  ruleName?: string | null
  jobId?: string | null
  /** Done keys already loaded by the caller (refreshed as actions run). */
  done?: Set<string>
}

/** Plan and (unless dry) perform one action for one submission, recording the run. */
export async function runAction(a: RuleAction, ctx: Ctx, meta: RunMeta, dryRun = false): Promise<ActionResult> {
  const done = meta.done ?? (await doneKeys(ctx.submissionId))
  const who = contactOf(ctx.doc.fields, ctx.answers)
  const outcome: Outcome = planAction(a, { email: who.email, consent: marketingConsent(ctx.doc.fields, ctx.answers), commerceEnabled: ctx.commerceEnabled, done })
  if (dryRun) {
    const status = outcome.kind === 'run' ? 'would_run' : outcome.kind === 'approval' ? 'would_need_approval' : 'would_skip'
    return { actionId: a.id, type: a.type, status, detail: outcome.kind === 'run' ? 'Would run' : outcome.reason }
  }
  const base = { formId: ctx.formId, submissionId: ctx.submissionId, ruleId: meta.ruleId ?? null, ruleName: meta.ruleName ?? null, actionType: a.type, actionKey: actionKey(a), source: meta.source, jobId: meta.jobId ?? null }
  if (outcome.kind === 'skip') {
    await prisma.formRuleRun.create({ data: { ...base, status: 'skipped', detail: outcome.reason } })
    return { actionId: a.id, type: a.type, status: 'skipped', detail: outcome.reason }
  }
  // Claim (submission, action) first — the unique key is the guarantee.
  const key = dedupeKeyFor(ctx.submissionId, a)
  const claim = () =>
    prisma.formRuleRun.create({
      data: { ...base, status: outcome.kind === 'approval' ? 'needs_approval' : 'running', dedupeKey: key, detail: outcome.kind === 'approval' ? JSON.stringify(a.params) : null },
    })
  let runId: string
  try {
    runId = (await claim()).id
  } catch (e) {
    if (!isUnique(e)) throw e
    // Held by a run that died mid-action? Take it over once; otherwise it's done.
    const retried = (await releaseStaleClaim(key)) ? await claim().catch(() => null) : null
    if (!retried) {
      await prisma.formRuleRun.create({ data: { ...base, status: 'skipped', detail: 'Already got it' } })
      return { actionId: a.id, type: a.type, status: 'skipped', detail: 'Already got it' }
    }
    runId = retried.id
  }
  done.add(actionKey(a))
  if (outcome.kind === 'approval') {
    const detail = await requestApproval(a, ctx, runId)
    return { actionId: a.id, type: a.type, status: 'needs_approval', detail }
  }
  try {
    const detail = await perform(a, ctx)
    await prisma.formRuleRun.update({ where: { id: runId }, data: { status: 'done', detail } })
    return { actionId: a.id, type: a.type, status: 'done', detail }
  } catch (e) {
    const detail = e instanceof Error ? e.message.slice(0, 300) : 'It didn’t work'
    // Release the key so it can be tried again.
    await prisma.formRuleRun.update({ where: { id: runId }, data: { status: 'failed', detail, dedupeKey: null } })
    done.delete(actionKey(a))
    return { actionId: a.id, type: a.type, status: 'failed', detail }
  }
}

export async function loadRunContext(submissionId: string, overrideDoc?: FormDoc): Promise<{ ctx: Ctx; rules: FormRule[] } | null> {
  const sub = await prisma.formSubmission.findUnique({
    where: { id: submissionId },
    select: { id: true, data: true, ipAddress: true, form: { select: { id: true, slug: true, name: true, description: true, status: true, submitButtonText: true, successMessage: true, notifyEmails: true, fields: true, display: true, automations: true } } },
  })
  if (!sub) return null
  const doc = overrideDoc ?? normalizeFormDoc(sub.form as unknown as Record<string, unknown>)
  return {
    ctx: { formId: sub.form.id, doc, slug: sub.form.slug, submissionId: sub.id, answers: answersById(doc.fields, (sub.data ?? {}) as Answers) as Answers, commerceEnabled: await isCommerceEnabled(), ipHash: sub.ipAddress },
    rules: doc.automations,
  }
}

/** After a submission: every matching rule, actions in order. Never throws. */
export async function runRulesForSubmission(submissionId: string): Promise<ActionResult[]> {
  const out: ActionResult[] = []
  try {
    const loaded = await loadRunContext(submissionId)
    if (!loaded) return out
    const { ctx, rules } = loaded
    const done = await doneKeys(submissionId)
    for (const rule of rules) {
      if (!ruleMatches(rule, ctx.answers)) continue
      for (const a of rule.actions) {
        try {
          out.push(await runAction(a, ctx, { source: 'auto', ruleId: rule.id, ruleName: rule.name, done }))
        } catch (e) {
          console.error('[forms] automation action failed:', e)
        }
      }
    }
  } catch (e) {
    console.error('[forms] automations failed:', e)
  }
  return out
}

/** "Test with a sample": what the rule would do for a submission — nothing is sent or saved. */
export async function testRule(rule: FormRule, doc: FormDoc, formId: string, sample: { id: string; data: Answers } | null): Promise<{ matched: boolean; results: ActionResult[]; sample: Answers }> {
  const answers: Answers = sample?.data ?? sampleAnswers(doc)
  const commerceEnabled = await isCommerceEnabled()
  const ctx: Ctx = { formId, doc, slug: '', submissionId: sample?.id ?? 'sample', answers, commerceEnabled, ipHash: null }
  const matched = ruleMatches({ ...rule, enabled: true }, answers)
  const done = sample ? await doneKeys(sample.id) : new Set<string>()
  const results = matched ? await Promise.all(rule.actions.map((a) => runAction(a, ctx, { source: 'test', done }, true))) : []
  return { matched, results, sample: answers }
}

/** Plausible answers for a form with no submissions yet (example.com, never a real person). */
export function sampleAnswers(doc: FormDoc): Answers {
  const out: Answers = {}
  for (const f of doc.fields) {
    if (f.type === 'email') out[f.id] = 'sam.sample@example.com'
    else if (f.type === 'phone') out[f.id] = '+1 555 0100'
    else if (f.type === 'checkbox') out[f.id] = true
    else if (f.type === 'number') out[f.id] = 1
    else if (f.type === 'date') out[f.id] = '2026-10-10'
    else if (f.options?.length) out[f.id] = f.type === 'multiselect' ? [f.options[0]] : f.options[0]
    else if (/first/i.test(f.label)) out[f.id] = 'Sam'
    else if (/last|sur/i.test(f.label)) out[f.id] = 'Sample'
    else if (/name/i.test(f.label)) out[f.id] = 'Sam Sample'
    else out[f.id] = 'A sample answer about the next trip'
  }
  return out
}

/** How many times each rule has run on this form (actions that really ran). */
export async function ruleRunCounts(formId: string): Promise<Record<string, number>> {
  const rows = await prisma.formRuleRun.groupBy({ by: ['ruleId', 'submissionId'], where: { formId, ruleId: { not: null }, status: { in: ['done', 'needs_approval', 'approved'] } } })
  const out: Record<string, number> = {}
  for (const r of rows) if (r.ruleId) out[r.ruleId] = (out[r.ruleId] ?? 0) + 1
  return out
}

export { actionSpec }
