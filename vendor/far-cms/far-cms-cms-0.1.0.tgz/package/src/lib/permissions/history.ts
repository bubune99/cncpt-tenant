/**
 * Version history for access: roles ('role': what a role allows) and each
 * person's access ('user-access': their roles and their per-person grants
 * and denials). Restoring either changes who can do what, so it is
 * owner-only (like the screens' riskiest switches); reading follows the
 * screens' own permissions.
 */

import { prisma } from '../db'
import { historyRecorder, registerHistory } from '../ade-bindings/history'
import type { RestorePolicy } from '../ade/history'
import { invalidateUserPermissions } from './index'

type Obj = Record<string, unknown>

const sortedStrings = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []).sort()

async function loadRole(id: string): Promise<Obj | null> {
  const r = await prisma.role.findUnique({ where: { id }, select: { name: true, displayName: true, description: true, permissions: true, position: true } })
  return r ? { ...r, permissions: sortedStrings(r.permissions) } : null
}

async function loadUserAccess(userId: string): Promise<Obj | null> {
  const u = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      roleAssignments: { select: { roleId: true } },
      permissions: { select: { permission: true, type: true, expiresAt: true } },
    },
  })
  if (!u) return null
  return {
    roleIds: u.roleAssignments.map((r) => r.roleId).sort(),
    overrides: u.permissions
      .map((o) => ({ permission: o.permission, type: o.type, expiresAt: o.expiresAt ? o.expiresAt.toISOString() : null }))
      .sort((a, b) => a.permission.localeCompare(b.permission)),
  }
}

export const roleHistory = historyRecorder('role', loadRole)
export const userAccessHistory = historyRecorder('user-access', loadUserAccess)

/** Access changes are all guarded: they change who can do what. */
export const ROLE_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    displayName: { class: 'restorable', type: 'string' },
    description: { class: 'restorable', type: 'string' },
    position: { class: 'restorable', type: 'number' },
    name: { class: 'guarded', type: 'string', consequence: 'The role’s short name changes — scripts that use it by name break' },
    permissions: { class: 'guarded', type: 'string[]', consequence: 'What everyone with this role can do changes' },
  },
}

export const USER_ACCESS_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    roleIds: { class: 'guarded', type: 'string[]', consequence: 'This person’s roles change' },
    overrides: { class: 'guarded', type: 'json', consequence: 'This person’s own exceptions change' },
  },
}

registerHistory({
  entityType: 'role',
  policy: ROLE_POLICY,
  editPermission: 'roles.edit',
  ownerOnly: () => true,
  ignore: new Set(['id', 'createdAt', 'updatedAt', 'isSystem']),
  load: loadRole,
  nameOf: async (id) => (await prisma.role.findUnique({ where: { id }, select: { displayName: true } }))?.displayName ?? null,
  fieldLabels: { name: 'Short name', displayName: 'Name', description: 'Description', permissions: 'What it allows', position: 'Order' },
  async save(id, patch, actor, reason) {
    await roleHistory.update(id, { actor, reason }, () => prisma.role.update({ where: { id }, data: patch as Parameters<typeof prisma.role.update>[0]['data'] }))
    invalidateUserPermissions()
  },
})

registerHistory({
  entityType: 'user-access',
  policy: USER_ACCESS_POLICY,
  missingRefs: async (t) => {
    const ids = Array.isArray(t.roleIds) ? (t.roleIds as string[]) : []
    return ids.length && (await prisma.role.count({ where: { id: { in: ids } } })) < ids.length ? { roleIds: 'A role in that version was deleted' } : {}
  },
  editPermission: 'users.roles',
  ownerOnly: () => true,
  ignore: new Set(),
  load: loadUserAccess,
  nameOf: async (id) => {
    const u = await prisma.user.findUnique({ where: { id }, select: { name: true, email: true } })
    return u ? `Access for ${u.name?.trim() || u.email}` : null
  },
  fieldLabels: { roleIds: 'Roles', overrides: 'Exceptions for this person' },
  async save(userId, patch, actor, reason) {
    await userAccessHistory.update(userId, { actor, reason }, async () => {
      await prisma.$transaction(async (tx) => {
        if (Array.isArray(patch.roleIds)) {
          // Roles deleted since are skipped.
          const ids = sortedStrings(patch.roleIds)
          const exist = (await tx.role.findMany({ where: { id: { in: ids } }, select: { id: true } })).map((r) => r.id)
          await tx.roleAssignment.deleteMany({ where: { userId } })
          if (exist.length) await tx.roleAssignment.createMany({ data: exist.map((roleId) => ({ userId, roleId, assignedBy: actor.userId ?? undefined })) })
        }
        if (Array.isArray(patch.overrides)) {
          await tx.userPermission.deleteMany({ where: { userId } })
          const rows = (patch.overrides as Obj[])
            .filter((o) => typeof o.permission === 'string' && (o.type === 'GRANT' || o.type === 'DENY'))
            .map((o) => ({
              userId,
              permission: o.permission as string,
              type: o.type as 'GRANT' | 'DENY',
              expiresAt: typeof o.expiresAt === 'string' ? new Date(o.expiresAt) : null,
              grantedBy: actor.userId ?? undefined,
              reason: 'Restored an earlier version',
            }))
          if (rows.length) await tx.userPermission.createMany({ data: rows })
        }
      })
    })
    invalidateUserPermissions(userId)
  },
})
