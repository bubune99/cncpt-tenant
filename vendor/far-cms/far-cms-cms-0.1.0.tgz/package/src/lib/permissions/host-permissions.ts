/**
 * Who may do what, answered by the host app when it has its own access rules. CNCPT decides access by site ownership
 * and team membership, so it answers for the request's site; Dzidzor and BYB answer nothing and the CMS reads its own
 * roles, as before. A host's set is explicit: it may not hand out the everything wildcard, because some CMS screens
 * read platform-wide tables. Checked in host-permissions.assert.ts.
 */
import type { UserWithPermissions } from "./types"

const KEY = "__farCms"
type Holder = Record<string, unknown>
export type HostPermissions = (userId: string) => Promise<UserWithPermissions | null>

/** The host's answer when it gave one; otherwise the CMS's own roles. */
export async function permissionsFor(userId: string, holder: Holder, own: (userId: string) => Promise<UserWithPermissions | null>): Promise<UserWithPermissions | null> {
  const host = (holder[KEY] as { permissions?: HostPermissions } | undefined)?.permissions
  return host ? host(userId) : own(userId)
}

/** Called by the host app at startup. */
export function setHostPermissions(fn: HostPermissions, holder: Holder = globalThis as unknown as Holder): void {
  holder[KEY] = { ...((holder[KEY] as object | undefined) ?? {}), permissions: fn }
}

/** A permission set for one person, built by the host. */
export function permissionSet(id: string, email: string, permissions: readonly string[], name: string | null = null): UserWithPermissions {
  if (permissions.includes("*")) throw new Error("a host permission set may not use the everything wildcard; list what the person may do")
  return { id, email, name, permissions: new Set(permissions), roles: [], overrides: [] }
}
