/**
 * Permission Checking Utilities
 * Core RBAC logic for checking user permissions
 */

import { prisma } from '../db'
import { PERMISSIONS, BUILT_IN_ROLES } from './constants'
import type {
  UserWithPermissions,
  RoleData,
  PermissionOverride,
  PermissionCheckResult,
  AuditAction,
} from './types'
import { storeIp, storeUa } from '../privacy/minimise'

export { PERMISSIONS, PERMISSION_GROUPS, BUILT_IN_ROLES, ANY_STAFF_PERMISSION } from './constants'
export type { Permission, BuiltInRoleName } from './constants'
export type * from './types'

// ---------------------------------------------------------------------------
// Permission cache
//
// Every permission check used to re-run the full user+roles+overrides fetch
// (~3 Neon HTTP round-trips) on every request — the same pattern the settings
// TTL cache (src/lib/settings/index.ts) was added to fix. Permissions get the
// same treatment: a short TTL memo keyed by userId, invalidated by every
// role/override write below. TTL is deliberately short so an un-invalidated
// change (e.g. a write from another server instance) converges quickly.
// ---------------------------------------------------------------------------

const PERMISSIONS_CACHE_TTL_MS = 60_000

interface PermCacheEntry {
  value: UserWithPermissions
  expiresAt: number
}

const permissionsCache = new Map<string, PermCacheEntry>()

/** Drop cached permissions for one user (or everyone when omitted). */
export function invalidateUserPermissions(userId?: string): void {
  if (userId) {
    permissionsCache.delete(userId)
  } else {
    permissionsCache.clear()
  }
}

/**
 * Get a user's complete permission set (roles + overrides)
 */
export async function getUserPermissions(userId: string): Promise<UserWithPermissions | null> {
  const cached = permissionsCache.get(userId)
  if (cached && cached.expiresAt > Date.now()) {
    return cached.value
  }

  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      roleAssignments: {
        include: {
          role: true,
        },
      },
      permissions: {
        where: {
          OR: [
            { expiresAt: null },
            { expiresAt: { gt: new Date() } },
          ],
        },
      },
    },
  })

  if (!user) return null

  // Extract roles
  const roles: RoleData[] = user.roleAssignments.map((ra) => ({
    id: ra.role.id,
    name: ra.role.name,
    displayName: ra.role.displayName,
    description: ra.role.description,
    permissions: ra.role.permissions as string[],
    isSystem: ra.role.isSystem,
  }))

  // Extract overrides
  const overrides: PermissionOverride[] = user.permissions.map((p) => ({
    id: p.id,
    permission: p.permission,
    type: p.type as 'GRANT' | 'DENY',
    expiresAt: p.expiresAt,
    reason: p.reason,
  }))

  // Compute effective permissions
  const permissions = computeEffectivePermissions(roles, overrides)

  const result: UserWithPermissions = {
    id: user.id,
    email: user.email,
    name: user.name,
    permissions,
    roles,
    overrides,
  }

  permissionsCache.set(userId, {
    value: result,
    expiresAt: Date.now() + PERMISSIONS_CACHE_TTL_MS,
  })

  return result
}

/**
 * Compute effective permissions from roles and overrides
 * Order: Collect from roles → Apply DENY overrides → Apply GRANT overrides
 */
function computeEffectivePermissions(
  roles: RoleData[],
  overrides: PermissionOverride[]
): Set<string> {
  const permissions = new Set<string>()

  // 1. Collect all permissions from roles
  for (const role of roles) {
    for (const perm of role.permissions) {
      permissions.add(perm)
    }
  }

  // 2. Apply DENY overrides (remove permissions)
  for (const override of overrides) {
    if (override.type === 'DENY') {
      permissions.delete(override.permission)
    }
  }

  // 3. Apply GRANT overrides (add permissions)
  for (const override of overrides) {
    if (override.type === 'GRANT') {
      permissions.add(override.permission)
    }
  }

  return permissions
}

/**
 * Check if a permission matches (including wildcards)
 * Examples:
 * - "products.view" matches "products.view" exactly
 * - "products.*" matches "products.view", "products.edit", etc.
 * - "*" matches everything
 */
function permissionMatches(userPermission: string, requiredPermission: string): boolean {
  // Exact match
  if (userPermission === requiredPermission) return true

  // Super admin wildcard
  if (userPermission === '*') return true

  // Resource wildcard (e.g., "products.*" matches "products.view")
  if (userPermission.endsWith('.*')) {
    const resource = userPermission.slice(0, -2) // Remove ".*"
    return requiredPermission.startsWith(resource + '.')
  }

  return false
}

/**
 * Check if user has a specific permission
 */
export async function hasPermission(
  userId: string,
  permission: string
): Promise<PermissionCheckResult> {
  const userPerms = await getUserPermissions(userId)

  if (!userPerms) {
    return { allowed: false, reason: 'User not found' }
  }

  return checkPermission(userPerms, permission)
}

/**
 * Check permission against a pre-loaded user permission set
 * (Use this in loops to avoid repeated DB queries)
 */
export function checkPermission(
  userPerms: UserWithPermissions,
  requiredPermission: string
): PermissionCheckResult {
  // Check for super admin first
  if (userPerms.permissions.has('*')) {
    return {
      allowed: true,
      source: { type: 'super_admin' },
    }
  }

  // Check each user permission for a match
  for (const userPerm of userPerms.permissions) {
    if (permissionMatches(userPerm, requiredPermission)) {
      // Determine source (role or override)
      const grantOverride = userPerms.overrides.find(
        (o) => o.type === 'GRANT' && o.permission === userPerm
      )

      if (grantOverride) {
        return {
          allowed: true,
          source: {
            type: 'override',
            id: grantOverride.id,
          },
        }
      }

      // Find which role grants this
      for (const role of userPerms.roles) {
        if (role.permissions.some((p) => permissionMatches(p, requiredPermission))) {
          return {
            allowed: true,
            source: {
              type: 'role',
              id: role.id,
              name: role.displayName,
            },
          }
        }
      }

      return { allowed: true }
    }
  }

  // Check if explicitly denied
  const denyOverride = userPerms.overrides.find(
    (o) => o.type === 'DENY' && o.permission === requiredPermission
  )

  if (denyOverride) {
    return {
      allowed: false,
      reason: denyOverride.reason || 'Permission explicitly denied',
      source: {
        type: 'override',
        id: denyOverride.id,
      },
    }
  }

  // Distinguish "you have roles but not this permission" from the far more
  // confusing "your account has no roles at all" — the latter looks like a
  // broken/blank admin to the user and must say exactly what's wrong.
  if (userPerms.roles.length === 0 && userPerms.permissions.size === 0) {
    return {
      allowed: false,
      reason:
        'No roles are assigned to this account. An administrator must assign a role under Admin → Users before you can access this.',
    }
  }

  return {
    allowed: false,
    reason: 'Permission not granted by any role',
  }
}

/**
 * Check multiple permissions at once
 * Returns true only if ALL permissions are granted
 */
export async function hasAllPermissions(
  userId: string,
  permissions: string[]
): Promise<boolean> {
  const userPerms = await getUserPermissions(userId)
  if (!userPerms) return false

  return permissions.every((p) => checkPermission(userPerms, p).allowed)
}

/**
 * Check multiple permissions at once
 * Returns true if ANY permission is granted
 */
export async function hasAnyPermission(
  userId: string,
  permissions: string[]
): Promise<boolean> {
  const userPerms = await getUserPermissions(userId)
  if (!userPerms) return false

  return permissions.some((p) => checkPermission(userPerms, p).allowed)
}

/**
 * Check if user is a super admin
 */
export async function isSuperAdmin(userId: string): Promise<boolean> {
  const userPerms = await getUserPermissions(userId)
  return userPerms?.permissions.has('*') ?? false
}

/**
 * Log an audit event
 */
export async function logAuditEvent(params: {
  userId?: string
  userEmail?: string
  action: AuditAction
  targetType?: string
  targetId?: string
  details?: Record<string, unknown>
  ipAddress?: string
  userAgent?: string
}): Promise<void> {
  await prisma.auditLog.create({
    data: {
      userId: params.userId,
      userEmail: params.userEmail,
      action: params.action,
      targetType: params.targetType,
      targetId: params.targetId,
      details: (params.details || {}) as any,
      // Never the raw address or full user agent (lib/privacy/minimise).
      ipAddress: storeIp(params.ipAddress),
      userAgent: storeUa(params.userAgent),
    },
  })
}

/**
 * Seed built-in roles (run on app startup or migration)
 */
export async function seedBuiltInRoles(): Promise<void> {
  const { roleHistory } = await import('./history')
  for (const [, roleData] of Object.entries(BUILT_IN_ROLES)) {
    const existing = await prisma.role.findUnique({ where: { name: roleData.name }, select: { id: true } })
    const write = () => prisma.role.upsert({
      where: { name: roleData.name },
      update: {
        displayName: roleData.displayName,
        description: roleData.description,
        permissions: roleData.permissions,
        position: roleData.position,
      },
      create: {
        name: roleData.name,
        displayName: roleData.displayName,
        description: roleData.description,
        permissions: roleData.permissions,
        isSystem: roleData.isSystem,
        position: roleData.position,
      },
    })
    // Built-in roles are written by the system; each change is still a version.
    const SEED = { actor: { kind: 'system' as const }, reason: 'built-in role' }
    if (existing) await roleHistory.update(existing.id, SEED, write)
    else await roleHistory.created((await write()).id, SEED)
  }
}

/** Each change to someone's access is a version (lib/permissions/history); the person making it is the author. */
async function accessHistory(by: string | undefined) {
  const [{ userAccessHistory }, { actorFor }] = await Promise.all([import('./history'), import('../ade-bindings/history')])
  return { h: userAccessHistory, ctx: { actor: actorFor(by ?? null) } }
}

/**
 * Assign a role to a user
 */
export async function assignRole(params: {
  userId: string
  roleId: string
  assignedBy?: string
}): Promise<void> {
  const { h, ctx } = await accessHistory(params.assignedBy)
  await h.update(params.userId, ctx, () =>
    prisma.roleAssignment.create({
      data: {
        userId: params.userId,
        roleId: params.roleId,
        assignedBy: params.assignedBy,
      },
    })
  )
  // Given a role again: no longer an account whose access was removed, so the purge leaves it alone.
  await prisma.user.updateMany({ where: { id: params.userId, accessRemovedAt: { not: null } }, data: { accessRemovedAt: null } })

  invalidateUserPermissions(params.userId)

  // Log the action
  if (params.assignedBy) {
    const assigner = await prisma.user.findUnique({
      where: { id: params.assignedBy },
      select: { email: true },
    })

    const role = await prisma.role.findUnique({
      where: { id: params.roleId },
      select: { name: true },
    })

    await logAuditEvent({
      userId: params.assignedBy,
      userEmail: assigner?.email,
      action: 'role.assign',
      targetType: 'user',
      targetId: params.userId,
      details: {
        roleId: params.roleId,
        roleName: role?.name,
      },
    })
  }
}

/**
 * Remove a role from a user
 */
export async function removeRole(params: {
  userId: string
  roleId: string
  removedBy?: string
}): Promise<void> {
  const { h, ctx } = await accessHistory(params.removedBy)
  await h.update(params.userId, ctx, () =>
    prisma.roleAssignment.delete({
      where: {
        userId_roleId: {
          userId: params.userId,
          roleId: params.roleId,
        },
      },
    })
  )

  invalidateUserPermissions(params.userId)

  // Log the action
  if (params.removedBy) {
    const remover = await prisma.user.findUnique({
      where: { id: params.removedBy },
      select: { email: true },
    })

    const role = await prisma.role.findUnique({
      where: { id: params.roleId },
      select: { name: true },
    })

    await logAuditEvent({
      userId: params.removedBy,
      userEmail: remover?.email,
      action: 'role.remove',
      targetType: 'user',
      targetId: params.userId,
      details: {
        roleId: params.roleId,
        roleName: role?.name,
      },
    })
  }
}

/**
 * Grant a permission override to a user
 */
export async function grantPermission(params: {
  userId: string
  permission: string
  expiresAt?: Date
  reason?: string
  grantedBy?: string
}): Promise<void> {
  const granted = await accessHistory(params.grantedBy)
  await granted.h.update(params.userId, granted.ctx, () => prisma.userPermission.upsert({
    where: {
      userId_permission: {
        userId: params.userId,
        permission: params.permission,
      },
    },
    update: {
      type: 'GRANT',
      expiresAt: params.expiresAt,
      reason: params.reason,
      grantedBy: params.grantedBy,
    },
    create: {
      userId: params.userId,
      permission: params.permission,
      type: 'GRANT',
      expiresAt: params.expiresAt,
      reason: params.reason,
      grantedBy: params.grantedBy,
    },
  }))

  invalidateUserPermissions(params.userId)

  // Log the action
  if (params.grantedBy) {
    const granter = await prisma.user.findUnique({
      where: { id: params.grantedBy },
      select: { email: true },
    })

    await logAuditEvent({
      userId: params.grantedBy,
      userEmail: granter?.email,
      action: 'permission.grant',
      targetType: 'user',
      targetId: params.userId,
      details: {
        permission: params.permission,
        expiresAt: params.expiresAt?.toISOString(),
        reason: params.reason,
      },
    })
  }
}

/**
 * Deny a permission override to a user
 */
export async function denyPermission(params: {
  userId: string
  permission: string
  expiresAt?: Date
  reason?: string
  deniedBy?: string
}): Promise<void> {
  const denied = await accessHistory(params.deniedBy)
  await denied.h.update(params.userId, denied.ctx, () => prisma.userPermission.upsert({
    where: {
      userId_permission: {
        userId: params.userId,
        permission: params.permission,
      },
    },
    update: {
      type: 'DENY',
      expiresAt: params.expiresAt,
      reason: params.reason,
      grantedBy: params.deniedBy,
    },
    create: {
      userId: params.userId,
      permission: params.permission,
      type: 'DENY',
      expiresAt: params.expiresAt,
      reason: params.reason,
      grantedBy: params.deniedBy,
    },
  }))

  invalidateUserPermissions(params.userId)

  // Log the action
  if (params.deniedBy) {
    const denier = await prisma.user.findUnique({
      where: { id: params.deniedBy },
      select: { email: true },
    })

    await logAuditEvent({
      userId: params.deniedBy,
      userEmail: denier?.email,
      action: 'permission.deny',
      targetType: 'user',
      targetId: params.userId,
      details: {
        permission: params.permission,
        expiresAt: params.expiresAt?.toISOString(),
        reason: params.reason,
      },
    })
  }
}

/**
 * Remove a permission override from a user
 */
export async function removePermissionOverride(params: {
  userId: string
  permission: string
  removedBy?: string
}): Promise<void> {
  const existing = await prisma.userPermission.findUnique({
    where: {
      userId_permission: {
        userId: params.userId,
        permission: params.permission,
      },
    },
  })

  if (!existing) return

  const { h, ctx } = await accessHistory(params.removedBy)
  await h.update(params.userId, ctx, () =>
    prisma.userPermission.delete({
      where: {
        userId_permission: {
          userId: params.userId,
          permission: params.permission,
        },
      },
    })
  )

  invalidateUserPermissions(params.userId)

  // Log the action
  if (params.removedBy) {
    const remover = await prisma.user.findUnique({
      where: { id: params.removedBy },
      select: { email: true },
    })

    await logAuditEvent({
      userId: params.removedBy,
      userEmail: remover?.email,
      action: 'permission.remove',
      targetType: 'user',
      targetId: params.userId,
      details: {
        permission: params.permission,
        previousType: existing.type,
      },
    })
  }
}
