/**
 * A host app may answer "what may this person do here" itself (CNCPT: the site's owner or team gets the site-admin
 * set it decides); otherwise the CMS reads its own roles. Card 10 (c645e053), step 3.
 * Run: node_modules/.bin/tsx packages/cms/src/lib/permissions/host-permissions.assert.ts
 */
import assert from "node:assert/strict"
import { readFileSync } from "node:fs"
import { permissionsFor, setHostPermissions, permissionSet } from "./host-permissions"

let n = 0
const ok = async (name: string, fn: () => Promise<void> | void) => { await fn(); n++; console.log(`ok ${n} - ${name}`) }

async function main() {
  const own = async (id: string) => ({ id, email: "a@b.c", name: null, permissions: new Set(["own"]), roles: [], overrides: [] })
  await ok("with no host answer, the CMS reads its own roles", async () => {
    const r = await permissionsFor("u1", {}, own)
    assert.deepEqual([...r!.permissions], ["own"])
  })
  await ok("a host answer replaces the CMS's own, and the CMS's roles are not read", async () => {
    let read = 0
    const holder: Record<string, unknown> = {}
    setHostPermissions(async (id) => permissionSet(id, "x@y.z", ["customers.view", "customers.edit"]), holder)
    const r = await permissionsFor("u2", holder, async (id) => { read++; return own(id) })
    assert.deepEqual([...r!.permissions].sort(), ["customers.edit", "customers.view"])
    assert.equal(read, 0)
  })
  await ok("a host that says no (null) means no access, not the CMS's own roles", async () => {
    const holder: Record<string, unknown> = {}
    setHostPermissions(async () => null, holder)
    assert.equal(await permissionsFor("u3", holder, own), null)
  })
  await ok("a host permission set never contains the everything wildcard", () => {
    assert.throws(() => permissionSet("u", "e", ["*"]), /wildcard/)
  })
  await ok("the auth context reads permissions through permissionsFor", () => {
    const src = readFileSync(new URL("./middleware.ts", import.meta.url), "utf8")
    assert.match(src, /permissionsFor\(user\.id, globalThis/)
  })
  console.log(`${n} checks passed`)
}
main()
