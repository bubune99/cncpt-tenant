// Moved to @far-cms/core (far-cms packages/core/src/lib/permissions/client-cache.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/permissions/client-cache'
