/**
 * Permission Middleware
 * Protect API routes and server actions with permission checks
 */

import { cache } from 'react'
import { NextRequest, NextResponse } from 'next/server'
import { stackServerApp } from '../stack'
import { ownEmail } from '../auth/session-email'
import { prisma } from '../db'
import { getUserPermissions, checkPermission, type UserWithPermissions } from './index'
import { permissionsFor } from './host-permissions'

export interface AuthContext {
  user: {
    id: string
    email: string
    name: string | null
    stackAuthId: string
    /** `email` is the session's VERIFIED address (lib/auth/session-email) — required before matching anything by email. */
    emailVerified: boolean
  }
  permissions: UserWithPermissions
}

// Short-lived memo of the stackAuthId → local user row lookup. The row rarely
// changes and every authenticated request needs it, so this trims one Neon
// round-trip per request. Kept intentionally shorter than the permissions TTL.
const USER_ROW_TTL_MS = 60_000
type LocalUser = { id: string; email: string; name: string | null }
const userRowCache = new Map<string, { value: LocalUser; expiresAt: number }>()

async function getLocalUser(stackAuthId: string): Promise<LocalUser | null> {
  const cached = userRowCache.get(stackAuthId)
  if (cached && cached.expiresAt > Date.now()) return cached.value

  const user = await prisma.user.findUnique({
    where: { stackAuthId },
    select: { id: true, email: true, name: true },
  })
  if (!user) return null

  userRowCache.set(stackAuthId, { value: user, expiresAt: Date.now() + USER_ROW_TTL_MS })
  return user
}

/**
 * Get current authenticated user with permissions.
 *
 * Wrapped in React cache() so multiple guards within one request (e.g.
 * requireAuth + requirePermission in the same handler tree) resolve the
 * chain once instead of re-running Stack Auth + Neon per call.
 *
 * A transient failure anywhere in the chain used to silently become a 401
 * ("sometimes I can't edit pages"); now the chain retries once before
 * giving up, and only a genuine missing user/session returns null cheaply.
 */
const resolveAuthStatus = cache(async (): Promise<{ context: AuthContext | null; failed: boolean }> => {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return { context: await resolveAuthContext(), failed: false }
    } catch (error) {
      if (attempt === 0) {
        console.warn('[Auth] transient failure resolving auth context, retrying:', error)
        continue
      }
      console.error('[Auth] failed to resolve auth context after retry:', error)
      return { context: null, failed: true }
    }
  }
  return { context: null, failed: true }
})

export const getAuthContext = cache(async (): Promise<AuthContext | null> => (await resolveAuthStatus()).context)

async function resolveAuthContext(): Promise<AuthContext | null> {
  const stackUser = await stackServerApp.getUser()
  if (!stackUser) return null

  // Find user in our database (TTL-memoized)
  const user = await getLocalUser(stackUser.id)
  if (!user) return null

  // Get user permissions from RBAC system (TTL-cached in ./index)
  // A host app with its own access rules (CNCPT: site owner or team) answers here; otherwise the CMS's own roles.
  const permissions = await permissionsFor(user.id, globalThis as unknown as Record<string, unknown>, getUserPermissions)
  if (!permissions) return null

  // An authenticated account with ZERO roles fails every permission check —
  // to the user this looks like a broken, empty admin. Log it loudly so the
  // misconfiguration is traceable in server logs instead of silent.
  if (permissions.roles.length === 0 && permissions.permissions.size === 0) {
    console.error(
      `[Auth] MISCONFIGURED ACCOUNT: ${user.email} is authenticated but has no RBAC role assignments — every permission check will fail. Assign a role (e.g. super_admin) in Admin → Users or via 'npm run cms permissions doctor'.`
    )
  }

  // RBAC is the single source of truth — there is no email-list fallback.
  // Grant access with `npx tsx scripts/grant-role.ts <email> <role>` or in
  // Admin → Admin Users.

  return {
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      stackAuthId: stackUser.id,
      emailVerified: ownEmail(stackUser, user.email) !== null,
    },
    permissions,
  }
}

/**
 * Require authentication - returns 401 if not logged in
 */
export async function requireAuth(): Promise<AuthContext> {
  const { context, failed } = await resolveAuthStatus()
  // The lookup itself failed (e.g. the database is busy): say so, rather than
  // telling a signed-in person they're unauthorized.
  if (!context && failed) throw new AuthError('The site is busy — please try again in a moment.', 503)
  if (!context) {
    throw new AuthError('Unauthorized', 401)
  }
  return context
}

/**
 * Require specific permission - returns 403 if not allowed
 */
export async function requirePermission(permission: string): Promise<AuthContext> {
  const context = await requireAuth()
  const result = checkPermission(context.permissions, permission)

  if (!result.allowed) {
    throw new AuthError(result.reason || 'Forbidden', 403)
  }

  return context
}

/**
 * Require any of the specified permissions
 */
export async function requireAnyPermission(permissions: string[]): Promise<AuthContext> {
  const context = await requireAuth()

  const hasAny = permissions.some((p) => checkPermission(context.permissions, p).allowed)

  if (!hasAny) {
    throw new AuthError('Forbidden', 403)
  }

  return context
}

/**
 * Require all of the specified permissions
 */
export async function requireAllPermissions(permissions: string[]): Promise<AuthContext> {
  const context = await requireAuth()

  const hasAll = permissions.every((p) => checkPermission(context.permissions, p).allowed)

  if (!hasAll) {
    throw new AuthError('Forbidden', 403)
  }

  return context
}

/**
 * Require super admin access
 */
export async function requireSuperAdmin(): Promise<AuthContext> {
  const context = await requireAuth()

  if (!context.permissions.permissions.has('*')) {
    throw new AuthError('Super admin access required', 403)
  }

  return context
}

/**
 * Custom auth error class
 */
export class AuthError extends Error {
  status: number

  constructor(message: string, status: number = 401) {
    super(message)
    this.name = 'AuthError'
    this.status = status
  }
}

/**
 * Handle auth errors in API routes
 */
export function handleAuthError(error: unknown): NextResponse {
  if (error instanceof AuthError) {
    return NextResponse.json(
      { error: error.message },
      { status: error.status }
    )
  }

  console.error('Unexpected auth error:', error)
  return NextResponse.json(
    { error: 'Internal server error' },
    { status: 500 }
  )
}

/**
 * Higher-order function to wrap API route handlers with permission check
 *
 * Usage:
 * ```ts
 * export const GET = withPermission('products.view', async (req, context) => {
 *   // context.user is available here
 *   return NextResponse.json({ products: [] })
 * })
 * ```
 */
export function withPermission<T extends unknown[]>(
  permission: string,
  handler: (
    request: NextRequest,
    context: AuthContext,
    ...args: T
  ) => Promise<NextResponse>
) {
  return async (request: NextRequest, ...args: T): Promise<NextResponse> => {
    try {
      const authContext = await requirePermission(permission)
      return await handler(request, authContext, ...args)
    } catch (error) {
      return handleAuthError(error)
    }
  }
}

/**
 * Wrap with any permission check
 */
export function withAnyPermission<T extends unknown[]>(
  permissions: string[],
  handler: (
    request: NextRequest,
    context: AuthContext,
    ...args: T
  ) => Promise<NextResponse>
) {
  return async (request: NextRequest, ...args: T): Promise<NextResponse> => {
    try {
      const authContext = await requireAnyPermission(permissions)
      return await handler(request, authContext, ...args)
    } catch (error) {
      return handleAuthError(error)
    }
  }
}

/**
 * Wrap with auth only (no specific permission required)
 */
export function withAuth<T extends unknown[]>(
  handler: (
    request: NextRequest,
    context: AuthContext,
    ...args: T
  ) => Promise<NextResponse>
) {
  return async (request: NextRequest, ...args: T): Promise<NextResponse> => {
    try {
      const authContext = await requireAuth()
      return await handler(request, authContext, ...args)
    } catch (error) {
      return handleAuthError(error)
    }
  }
}

/**
 * Wrap with super admin check
 */
export function withSuperAdmin<T extends unknown[]>(
  handler: (
    request: NextRequest,
    context: AuthContext,
    ...args: T
  ) => Promise<NextResponse>
) {
  return async (request: NextRequest, ...args: T): Promise<NextResponse> => {
    try {
      const authContext = await requireSuperAdmin()
      return await handler(request, authContext, ...args)
    } catch (error) {
      return handleAuthError(error)
    }
  }
}

/**
 * Client-side hook helper - check if current user has permission
 * Returns a function to check permissions against cached user data
 */
export function createPermissionChecker(permissions: UserWithPermissions) {
  return (permission: string): boolean => {
    return checkPermission(permissions, permission).allowed
  }
}
