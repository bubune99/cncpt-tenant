/**
 * Email Service Core
 *
 * Core email sending functionality without queue/subscription dependencies.
 * This file exists to break circular dependencies between index.ts, queue.ts, and subscriptions.ts.
 */

import type {
  EmailProvider,
  IEmailProvider,
  EmailMessage,
  EmailSendResult,
  BulkEmailMessage,
  BulkEmailResult,
  EmailServiceConfig,
  SmtpConfig,
  SendGridConfig,
  ResendConfig,
  MailgunConfig,
  SesConfig,
  EmailAddress,
  GuardErrorCode,
} from './types'
import { SmtpProvider, SendGridProvider, ResendProvider, MailgunProvider, SesProvider } from './providers'
import { parseMergeTags, type MergeTagData } from './merge-tags'
import { getEmailSettings, getSettings, type EmailSettings } from '../settings'
import { decide, MarketingFooterError, marketingRefusal, parseAllowList, suppressionBlocks, unsubscribeHeaders, providerSandbox, withFooter, withPlainText, type GuardEnv } from './send-guard'
import { hashForLog, isSuppressed } from './suppression'
import { htmlToPlainText } from './templates/renderer'
import { preferencesUrl, unsubscribeUrl } from './tokens'

const guardEnv = (): GuardEnv => ({ NODE_ENV: process.env.NODE_ENV, VERCEL_ENV: process.env.VERCEL_ENV })
const isProd = () => !providerSandbox(guardEnv())

// Singleton provider instance
let providerInstance: IEmailProvider | null = null
let currentProviderName: EmailProvider | null = null

/**
 * Create a provider instance based on configuration
 */
function createProvider(settings: EmailSettings): IEmailProvider {
  switch (settings.provider) {
    case 'smtp':
      return new SmtpProvider({
        host: settings.smtpHost!,
        port: settings.smtpPort!,
        secure: settings.smtpSecure,
        user: settings.smtpUser,
        pass: settings.smtpPass,
      })

    case 'sendgrid':
      return new SendGridProvider({
        apiKey: settings.sendgridApiKey!,
        // Accepted but never delivered anywhere except production.
        sandboxMode: providerSandbox(guardEnv()),
      })

    case 'resend':
      return new ResendProvider({
        apiKey: settings.resendApiKey!,
      })

    case 'mailgun':
      return new MailgunProvider({
        apiKey: settings.mailgunApiKey!,
        domain: settings.mailgunDomain!,
      })

    case 'ses':
      return new SesProvider({
        region: settings.sesRegion!,
        accessKeyId: settings.sesAccessKeyId!,
        secretAccessKey: settings.sesSecretAccessKey!,
      })

    default:
      throw new Error(`Unknown email provider: ${settings.provider}`)
  }
}

/**
 * Get the email provider instance
 */
async function getProvider(): Promise<IEmailProvider> {
  const settings = await getEmailSettings()

  // If provider changed, recreate instance
  if (currentProviderName !== settings.provider) {
    if (providerInstance?.close) {
      await providerInstance.close()
    }
    providerInstance = null
    currentProviderName = null
  }

  if (!providerInstance) {
    providerInstance = createProvider(settings)
    currentProviderName = settings.provider
  }

  return providerInstance
}

/**
 * Get default from address from settings
 */
async function getDefaultFrom(): Promise<EmailAddress> {
  const settings = await getEmailSettings()
  return {
    email: settings.fromEmail || 'noreply@projectdzidzor.org',
    name: settings.fromName,
  }
}

/**
 * Get default reply-to from settings
 */
async function getDefaultReplyTo(): Promise<EmailAddress | undefined> {
  const settings = await getEmailSettings()
  return settings.replyTo ? { email: settings.replyTo } : undefined
}

function addresses(v: EmailAddress | EmailAddress[] | undefined): string[] {
  if (!v) return []
  return (Array.isArray(v) ? v : [v]).map((a) => a.email).filter(Boolean)
}

function refused(provider: EmailProvider, errorCode: GuardErrorCode, error: string): EmailSendResult {
  return { success: false, provider, errorCode, error, timestamp: new Date() }
}

/** The organisation's postal address (Settings › Contact details › Address). */
async function postalAddress(): Promise<string | null> {
  const general = await getSettings<Record<string, unknown>>('general', {})
  return typeof general.address === 'string' && general.address.trim() ? general.address : null
}

function safeTokenUrl(make: (id: string) => string, subscriberId: string | undefined): string | null {
  if (!subscriberId) return null
  try {
    return make(subscriberId)
  } catch {
    return null
  }
}

/** The campaign as a web page (app/email/view/[id]). */
function viewInBrowserUrl(campaignId: string): string {
  return `${(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000').replace(/\/+$/, '')}/email/view/${encodeURIComponent(campaignId)}`
}

function safeUnsubscribeUrl(subscriberId: string | undefined): string | null {
  if (!subscriberId) return null
  try {
    return unsubscribeUrl(subscriberId)
  } catch {
    return null // no signing key: refuse rather than send a dead link
  }
}

/**
 * Every rule in send-guard.ts applied to one message, before a provider sees
 * it: staging allow-list, suppression (marketing), footer (marketing),
 * plain-text part. A refusal comes back as a failed result with a guard
 * code — never thrown, never retried.
 */
async function guardMessage(
  message: EmailMessage,
  providerName: EmailProvider
): Promise<{ ok: true; message: EmailMessage } | { ok: false; result: EmailSendResult }> {
  // Required by the type; anything untyped (old queue rows, eval'd plugins) is treated as the strictest kind.
  const category = message.category === 'transactional' ? 'transactional' : 'marketing'
  const settings = await getEmailSettings()
  const recipients = [...addresses(message.to), ...addresses(message.cc), ...addresses(message.bcc)]
  const allowList = parseAllowList(process.env.EMAIL_TEST_ALLOWLIST, settings.testAllowList)

  if (decide({ env: guardEnv(), to: recipients, category, allowList, liveSend: process.env.EMAIL_LIVE_SEND === 'true' }) === 'drop') {
    console.warn('[email] dropped: outside production only allow-listed addresses get email', { to: recipients.map(hashForLog), category })
    return { ok: false, result: refused(providerName, 'GUARD_DROPPED', category === 'marketing' && isProd() ? 'Not sent: marketing email to real people needs EMAIL_LIVE_SEND=true on the live site; until then it only goes to the test allow-list.' : 'Not sent: outside production, email only goes to the test allow-list (EMAIL_TEST_ALLOWLIST).') }
  }

  let body: { html?: string; text?: string } = { html: message.html, text: message.text }
  let headers = message.headers
  if (category === 'marketing') {
    const address = await postalAddress()
    const refusal = marketingRefusal({ category, subscriberId: message.subscriberId, postalAddress: address })
    if (refusal) return { ok: false, result: refused(providerName, 'FOOTER_MISSING', refusal) }
    for (const r of recipients) {
      if (suppressionBlocks(category, await isSuppressed(r))) {
        console.warn('[email] not sent: address is on the suppression list', { to: hashForLog(r) })
        return { ok: false, result: refused(providerName, 'SUPPRESSED', 'Not sent: this address unsubscribed, bounced or complained.') }
      }
    }
    const unsub = safeUnsubscribeUrl(message.subscriberId)
    try {
      body = withFooter(body, category, {
        postalAddress: address,
        unsubscribeUrl: unsub,
        preferencesUrl: safeTokenUrl(preferencesUrl, message.subscriberId),
        viewUrl: message.campaignId ? viewInBrowserUrl(message.campaignId) : null,
      })
      // The same signed URL in the List-Unsubscribe header (one-click POST).
      headers = { ...headers, ...unsubscribeHeaders(unsub!) }
    } catch (e) {
      if (e instanceof MarketingFooterError) return { ok: false, result: refused(providerName, 'FOOTER_MISSING', e.message) }
      throw e
    }
  }
  body = withPlainText(body, htmlToPlainText)
  return { ok: true, message: { ...message, ...body, headers } }
}

/**
 * Email Service Class
 */
export class EmailService {
  private provider: IEmailProvider | null = null
  private config: EmailServiceConfig | null = null

  /**
   * Initialize with explicit configuration (for testing)
   */
  initWithConfig(
    providerType: EmailProvider,
    providerConfig: SmtpConfig | SendGridConfig | ResendConfig | MailgunConfig | SesConfig,
    serviceConfig: Partial<EmailServiceConfig>
  ): void {
    switch (providerType) {
      case 'smtp':
        this.provider = new SmtpProvider(providerConfig as SmtpConfig)
        break
      case 'sendgrid':
        this.provider = new SendGridProvider(providerConfig as SendGridConfig)
        break
      case 'resend':
        this.provider = new ResendProvider(providerConfig as ResendConfig)
        break
      case 'mailgun':
        this.provider = new MailgunProvider(providerConfig as MailgunConfig)
        break
      case 'ses':
        this.provider = new SesProvider(providerConfig as SesConfig)
        break
    }

    this.config = {
      provider: providerType,
      defaultFrom: serviceConfig.defaultFrom || { email: 'noreply@projectdzidzor.org' },
      ...serviceConfig,
    }
  }

  /**
   * Get provider (lazy load from settings if not initialized)
   */
  private async getProvider(): Promise<IEmailProvider> {
    if (this.provider) {
      return this.provider
    }
    return getProvider()
  }

  /**
   * Send a single email
   */
  async send(message: EmailMessage): Promise<EmailSendResult> {
    const provider = await this.getProvider()

    // The one way out: every message passes the send guard first.
    const guarded = await guardMessage(message, provider.name)
    if (!guarded.ok) return guarded.result
    const out = guarded.message

    // Apply defaults
    if (!out.from) {
      out.from = this.config?.defaultFrom || (await getDefaultFrom())
    }
    if (!out.replyTo) {
      out.replyTo = this.config?.defaultReplyTo || (await getDefaultReplyTo())
    }

    return provider.send(out)
  }

  /**
   * Send email with merge tags
   */
  async sendWithMergeTags(
    message: Omit<EmailMessage, 'subject' | 'html' | 'text'> & {
      subjectTemplate: string
      htmlTemplate?: string
      textTemplate?: string
    },
    data: MergeTagData
  ): Promise<EmailSendResult> {
    const subject = parseMergeTags(message.subjectTemplate, data)
    const html = message.htmlTemplate ? parseMergeTags(message.htmlTemplate, data) : undefined
    const text = message.textTemplate ? parseMergeTags(message.textTemplate, data) : undefined

    return this.send({
      ...message,
      subject,
      html,
      text,
    })
  }

  /**
   * Send bulk emails
   */
  async sendBulk(message: BulkEmailMessage): Promise<BulkEmailResult> {
    const provider = await this.getProvider()

    // Apply defaults
    if (!message.from) {
      message.from = this.config?.defaultFrom || (await getDefaultFrom())
    }
    if (!message.replyTo) {
      message.replyTo = this.config?.defaultReplyTo || (await getDefaultReplyTo())
    }

    // Provider bulk only where the guard has nothing per-recipient to decide
    // (production, transactional); otherwise each recipient goes through send().
    // Required by the type; anything untyped (old queue rows, eval'd plugins) is treated as the strictest kind.
  const category = message.category === 'transactional' ? 'transactional' : 'marketing'
    if (provider.sendBulk && category === 'transactional' && !providerSandbox(guardEnv())) {
      return provider.sendBulk({ ...message, ...withPlainText({ html: message.html, text: message.text }, htmlToPlainText) })
    }

    // Individual sends (guarded)
    const results: BulkEmailResult['results'] = []
    let totalSent = 0
    let totalFailed = 0

    for (const recipient of message.recipients) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { recipients: _all, ...rest } = message
      const result = await this.send({
        ...rest,
        to: recipient.to,
        subscriberId: recipient.subscriberId ?? rest.subscriberId,
        metadata: { ...message.metadata, ...recipient.metadata },
      })

      results.push({
        email: recipient.to.email,
        success: result.success,
        messageId: result.messageId,
        error: result.error,
      })

      if (result.success) {
        totalSent++
      } else {
        totalFailed++
      }
    }

    return {
      success: totalFailed === 0,
      provider: provider.name,
      totalSent,
      totalFailed,
      results,
      timestamp: new Date(),
    }
  }

  /**
   * Send bulk emails with per-recipient merge tags
   */
  async sendBulkWithMergeTags(
    message: Omit<BulkEmailMessage, 'subject' | 'html' | 'text'> & {
      subjectTemplate: string
      htmlTemplate?: string
      textTemplate?: string
    },
    recipientData: Map<string, MergeTagData>
  ): Promise<BulkEmailResult> {
    const provider = await this.getProvider()

    // Apply defaults
    if (!message.from) {
      message.from = this.config?.defaultFrom || (await getDefaultFrom())
    }

    // For bulk with merge tags, we need to send individually to process templates
    const results: BulkEmailResult['results'] = []
    let totalSent = 0
    let totalFailed = 0

    for (const recipient of message.recipients) {
      const data = recipientData.get(recipient.to.email) || {}

      const subject = parseMergeTags(message.subjectTemplate, data)
      const html = message.htmlTemplate ? parseMergeTags(message.htmlTemplate, data) : undefined
      const text = message.textTemplate ? parseMergeTags(message.textTemplate, data) : undefined

      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { recipients: _all, subjectTemplate: _s, htmlTemplate: _h, textTemplate: _t, ...rest } = message
      const result = await this.send({
        ...rest,
        to: recipient.to,
        subscriberId: recipient.subscriberId ?? rest.subscriberId,
        subject,
        html,
        text,
        metadata: { ...message.metadata, ...recipient.metadata },
      })

      results.push({
        email: recipient.to.email,
        success: result.success,
        messageId: result.messageId,
        error: result.error,
      })

      if (result.success) {
        totalSent++
      } else {
        totalFailed++
      }
    }

    return {
      success: totalFailed === 0,
      provider: provider.name,
      totalSent,
      totalFailed,
      results,
      timestamp: new Date(),
    }
  }

  /**
   * Verify provider configuration
   */
  async verify(): Promise<boolean> {
    const provider = await this.getProvider()
    return provider.verify()
  }

  /**
   * Get current provider name
   */
  async getProviderName(): Promise<EmailProvider> {
    const provider = await this.getProvider()
    return provider.name
  }

  /**
   * Close provider connections
   */
  async close(): Promise<void> {
    if (this.provider?.close) {
      await this.provider.close()
    }
    this.provider = null

    // Also close singleton
    if (providerInstance?.close) {
      await providerInstance.close()
    }
    providerInstance = null
    currentProviderName = null
  }
}

// Export singleton instance
export const emailService = new EmailService()

// Convenience functions
export async function sendEmail(message: EmailMessage): Promise<EmailSendResult> {
  return emailService.send(message)
}

export async function sendBulkEmail(message: BulkEmailMessage): Promise<BulkEmailResult> {
  return emailService.sendBulk(message)
}

export async function sendEmailWithMergeTags(
  message: Omit<EmailMessage, 'subject' | 'html' | 'text'> & {
    subjectTemplate: string
    htmlTemplate?: string
    textTemplate?: string
  },
  data: MergeTagData
): Promise<EmailSendResult> {
  return emailService.sendWithMergeTags(message, data)
}
