/**
 * Campaign audience — who a campaign goes to. Pure: turns the stored
 * audience + segment definitions into a Prisma `where` for EmailSubscriber.
 * audience-server.ts runs it (count, paging). Asserted by
 * campaign-pipeline.assert.ts.
 *
 * Rules:
 *   - Only ACTIVE subscribers, ever (PENDING never confirmed; the rest opted
 *     out or can't receive). Suppressed addresses are removed after the
 *     query (the suppression list is keyed hashes, not addresses).
 *   - An EMPTY audience is nobody. Mailing the whole list needs an explicit
 *     `everyone: true` — a blank form must never mean "everyone".
 *   - Included = everyone, OR in any chosen segment, OR has any chosen tag.
 *     Excluded segments always win.
 *   - A segment is either static (its member rows) or dynamic (its
 *     conditions, evaluated here). A condition we don't understand makes
 *     the segment match NOBODY (never everybody).
 */

export interface Audience {
  everyone: boolean
  segmentIds: string[]
  tags: string[]
  excludeSegmentIds: string[]
}

export interface SegmentDef {
  id: string
  isDynamic: boolean
  conditions: unknown
}

type Where = Record<string, unknown>

const ID = /^[A-Za-z0-9_-]{1,80}$/
const MAX_ITEMS = 50

const ids = (v: unknown): string[] =>
  Array.isArray(v) ? [...new Set(v.filter((x): x is string => typeof x === 'string' && ID.test(x)))].slice(0, MAX_ITEMS) : []

const tagList = (v: unknown): string[] =>
  Array.isArray(v)
    ? [...new Set(v.filter((x): x is string => typeof x === 'string').map((t) => t.trim()).filter((t) => t && t.length <= 100))].slice(0, MAX_ITEMS)
    : []

/** Validate whatever was stored or sent. Unknown shapes → the empty audience (nobody). */
export function normalizeAudience(raw: unknown): Audience {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  return { everyone: o.everyone === true, segmentIds: ids(o.segmentIds), tags: tagList(o.tags), excludeSegmentIds: ids(o.excludeSegmentIds) }
}

export function isEmptyAudience(a: Audience): boolean {
  return !a.everyone && a.segmentIds.length === 0 && a.tags.length === 0
}

/** What a recipient-facing summary says ("All subscribers", "2 segments, tag “vip”"). */
export function describeAudience(a: Audience): string {
  if (a.everyone) return a.excludeSegmentIds.length ? `All subscribers, minus ${a.excludeSegmentIds.length} segment${a.excludeSegmentIds.length === 1 ? '' : 's'}` : 'All subscribers'
  const parts: string[] = []
  if (a.segmentIds.length) parts.push(`${a.segmentIds.length} segment${a.segmentIds.length === 1 ? '' : 's'}`)
  if (a.tags.length) parts.push(`tag${a.tags.length === 1 ? '' : 's'} ${a.tags.map((t) => `“${t}”`).join(', ')}`)
  return parts.length ? parts.join(' + ') : 'Nobody yet'
}

// ---------------------------------------------------------------------------
// Dynamic segment conditions → Prisma where
//   { and: [cond | group] } | { or: [cond | group] } | cond
//   cond = { field, op, value }
// ---------------------------------------------------------------------------

const NUMBER_FIELDS = new Set(['engagementScore', 'totalOpens', 'totalClicks', 'totalPurchases', 'lifetimeValue'])
const DATE_FIELDS = new Set(['subscribedAt', 'lastEngagedAt', 'confirmedAt'])
const TEXT_FIELDS = new Set(['source', 'consentSource'])
const NUM_OPS: Record<string, string> = { eq: 'equals', gt: 'gt', gte: 'gte', lt: 'lt', lte: 'lte' }
const MAX_DEPTH = 4

/** A condition we can't evaluate. The segment then matches nobody. */
export class SegmentRuleError extends Error {}

function condition(c: Record<string, unknown>): Where {
  const { field, op, value } = c
  if (typeof field !== 'string' || typeof op !== 'string') throw new SegmentRuleError('Incomplete condition')
  if (field === 'tags') {
    if (typeof value !== 'string' || !value.trim()) throw new SegmentRuleError('Tag condition needs a tag')
    if (op === 'contains' || op === 'has') return { tags: { has: value.trim() } }
    if (op === 'not_contains' || op === 'not_has') return { NOT: { tags: { has: value.trim() } } }
    throw new SegmentRuleError(`Unknown tag operator “${op}”`)
  }
  if (NUMBER_FIELDS.has(field)) {
    const n = typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN
    if (!Number.isFinite(n) || !NUM_OPS[op]) throw new SegmentRuleError(`Bad number condition on ${field}`)
    return { [field]: { [NUM_OPS[op]]: n } }
  }
  if (DATE_FIELDS.has(field)) {
    const d = typeof value === 'string' || typeof value === 'number' ? new Date(value) : null
    if (!d || Number.isNaN(d.getTime())) throw new SegmentRuleError(`Bad date on ${field}`)
    if (op === 'after' || op === 'gt') return { [field]: { gt: d } }
    if (op === 'before' || op === 'lt') return { [field]: { lt: d } }
    throw new SegmentRuleError(`Unknown date operator “${op}”`)
  }
  if (TEXT_FIELDS.has(field)) {
    if (typeof value !== 'string') throw new SegmentRuleError(`Bad text condition on ${field}`)
    if (op === 'eq' || op === 'equals') return { [field]: value }
    if (op === 'neq' || op === 'not_equals') return { NOT: { [field]: value } }
    throw new SegmentRuleError(`Unknown text operator “${op}”`)
  }
  throw new SegmentRuleError(`Unknown field “${field}”`)
}

function group(node: unknown, depth: number): Where {
  if (depth > MAX_DEPTH) throw new SegmentRuleError('Conditions nested too deeply')
  if (!node || typeof node !== 'object' || Array.isArray(node)) throw new SegmentRuleError('Bad conditions')
  const o = node as Record<string, unknown>
  for (const key of ['and', 'or'] as const) {
    if (key in o) {
      const list = o[key]
      if (!Array.isArray(list) || list.length === 0) throw new SegmentRuleError('Empty condition group')
      return { [key === 'and' ? 'AND' : 'OR']: list.map((x) => group(x, depth + 1)) }
    }
  }
  return condition(o)
}

/** One segment as a where on EmailSubscriber. Throws SegmentRuleError if it can't be evaluated. */
export function segmentWhere(seg: SegmentDef): Where {
  if (!seg.isDynamic) return { segmentMemberships: { some: { segmentId: seg.id } } }
  return group(seg.conditions, 0)
}

const NOBODY: Where = { id: { in: [] } }

/** A segment that can't be evaluated (or no longer exists) matches nobody. */
function safeSegmentWhere(id: string, segs: Map<string, SegmentDef>): Where {
  const seg = segs.get(id)
  if (!seg) return NOBODY
  try {
    return segmentWhere(seg)
  } catch (e) {
    if (e instanceof SegmentRuleError) return NOBODY
    throw e
  }
}

/**
 * The full subscriber filter. `segments` must contain every id the audience
 * names. A missing or broken INCLUDED segment matches nobody; a missing or
 * broken EXCLUDED one throws SegmentRuleError — never a wider list.
 */
export function audienceWhere(a: Audience, segments: readonly SegmentDef[]): Where {
  if (isEmptyAudience(a)) return { AND: [{ status: 'ACTIVE' }, NOBODY] }
  const segs = new Map(segments.map((s) => [s.id, s]))
  const and: Where[] = [{ status: 'ACTIVE' }]
  if (!a.everyone) {
    const any: Where[] = [...a.segmentIds.map((id) => safeSegmentWhere(id, segs))]
    if (a.tags.length) any.push({ tags: { hasSome: a.tags } })
    and.push({ OR: any })
  }
  for (const id of a.excludeSegmentIds) {
    const seg = segs.get(id)
    // An exclusion we can't evaluate would silently mail the people it was
    // meant to leave out — so it is an error (the "audience" check fails).
    if (!seg) throw new SegmentRuleError('An excluded segment no longer exists')
    and.push({ NOT: segmentWhere(seg) })
  }
  return { AND: and }
}

/** Every segment id an audience refers to (to load their definitions). */
export function audienceSegmentIds(a: Audience): string[] {
  return [...new Set([...a.segmentIds, ...a.excludeSegmentIds])]
}
