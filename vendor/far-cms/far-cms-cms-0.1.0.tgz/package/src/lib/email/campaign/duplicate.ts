/**
 * Duplicate a campaign: a new DRAFT holding the source's email and settings, and nothing about its sending
 * (no schedule, send job, test stamp or statistics). Pure; asserted by duplicate.assert.ts.
 */

export interface CampaignSource {
  name: string
  subject: string
  preheader: string | null
  fromName: string | null
  fromEmail: string | null
  replyTo: string | null
  type: 'REGULAR' | 'AUTOMATED' | 'TRANSACTIONAL'
  content: unknown
  html: string | null
  templateId: string | null
  segmentId: string | null
  audience: unknown
}

export function duplicateCampaignData(src: CampaignSource) {
  return {
    name: `Copy of ${src.name}`.slice(0, 200),
    subject: src.subject,
    preheader: src.preheader ?? undefined,
    fromName: src.fromName,
    fromEmail: src.fromEmail,
    replyTo: src.replyTo,
    type: src.type,
    status: 'DRAFT' as const,
    content: (src.content ?? {}) as object,
    html: src.html ?? undefined,
    templateId: src.templateId,
    segmentId: src.segmentId,
    audience: src.audience == null ? undefined : (src.audience as object),
  }
}
