/**
 * Gathers what lib/email/checks needs for one campaign and runs it. Send
 * and Schedule call `sendGate` and refuse unless it passes.
 */

import { prisma } from '../../db'
import { getEmailSettings, getSettings } from '../../settings'
import { campaignChecks, maySendCampaign, pickedLiveIds, providerConfigured, requiredChecksPass, type CampaignCheck } from '../checks'
import { normalizeEmailDoc, type EmailDoc } from '../editor/doc'
import { campaignAudience, countAudience } from './audience-server'
import type { AuthContext } from '../../permissions/middleware'

/** Owner = the super-admin grant ('*'). */
export function isOwner(auth: AuthContext): boolean {
  return auth.permissions.permissions.has('*')
}

/** Picked initiatives/events that are no longer published (left out of the email when sent). */
async function unpublishedPicks(doc: EmailDoc | null): Promise<number> {
  const { initiativeIds, eventIds } = pickedLiveIds(doc)
  const [inits, events] = await Promise.all([
    initiativeIds.length ? prisma.adeRecord.count({ where: { id: { in: initiativeIds }, type: 'initiative', status: 'PUBLISHED' } }) : 0,
    eventIds.length ? prisma.event.count({ where: { id: { in: eventIds }, status: 'PUBLISHED' } }) : 0,
  ])
  return initiativeIds.length - inits + (eventIds.length - events)
}

export async function checksForCampaign(id: string): Promise<{ checks: CampaignCheck[]; audienceCount: number } | null> {
  const c = await prisma.emailCampaign.findUnique({
    where: { id },
    select: { subject: true, preheader: true, html: true, content: true, fromEmail: true, testSentAt: true, audience: true, segmentId: true },
  })
  if (!c) return null
  const doc = c.content && typeof c.content === 'object' && Array.isArray((c.content as { content?: unknown }).content) ? normalizeEmailDoc(c.content) : null
  const [email, general, audience, unpublished] = await Promise.all([
    getEmailSettings(),
    getSettings<Record<string, unknown>>('general', {}),
    countAudience(campaignAudience(c)),
    unpublishedPicks(doc),
  ])
  const checks = campaignChecks({
    subject: c.subject,
    preheader: c.preheader,
    html: c.html,
    doc,
    unpublishedPicks: unpublished,
    postalAddress: typeof general.address === 'string' ? general.address : null,
    sender: { email: c.fromEmail || email.fromEmail || null, providerConfigured: providerConfigured(email) },
    testSentAt: c.testSentAt,
    audience,
  })
  return { checks, audienceCount: audience.count }
}

export type SendGate = { ok: true; checks: CampaignCheck[] } | { ok: false; status: 403 | 404 | 422; error: string; checks?: CampaignCheck[] }

/** Allowed to send AND every required check passes. */
export async function sendGate(id: string, auth: AuthContext): Promise<SendGate> {
  if (!maySendCampaign({ isOwner: isOwner(auth) })) return { ok: false, status: 403, error: 'Only the site owner can send campaigns for now.' }
  const r = await checksForCampaign(id)
  if (!r) return { ok: false, status: 404, error: 'Campaign not found' }
  if (!requiredChecksPass(r.checks)) return { ok: false, status: 422, error: 'Some checks haven’t passed yet.', checks: r.checks }
  return { ok: true, checks: r.checks }
}
