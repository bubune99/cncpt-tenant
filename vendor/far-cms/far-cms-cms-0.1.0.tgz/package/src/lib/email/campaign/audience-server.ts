/**
 * Runs a campaign audience (lib/email/campaign/audience) against the
 * database: the live count for the editor, and pages of recipients for the
 * send job. Suppressed addresses are removed here (keyed hashes, so not in
 * SQL).
 */

import { prisma } from '../../db'
import { suppressedAmong } from '../suppression'
import { audienceSegmentIds, audienceWhere, isEmptyAudience, normalizeAudience, SegmentRuleError, type Audience, type SegmentDef } from './audience'

const COUNT_PAGE = 1000

/** The campaign's audience; a legacy campaign with only `segmentId` uses that segment. */
export function campaignAudience(c: { audience: unknown; segmentId: string | null }): Audience {
  if (c.audience) return normalizeAudience(c.audience)
  return normalizeAudience({ segmentIds: c.segmentId ? [c.segmentId] : [] })
}

async function loadSegments(a: Audience): Promise<SegmentDef[]> {
  const ids = audienceSegmentIds(a)
  if (!ids.length) return []
  return prisma.emailSegment.findMany({ where: { id: { in: ids } }, select: { id: true, isDynamic: true, conditions: true } })
}

/** The subscriber filter, or the reason it can't be built. */
export async function audienceFilter(a: Audience): Promise<{ where: Record<string, unknown> } | { error: string }> {
  try {
    return { where: audienceWhere(a, await loadSegments(a)) }
  } catch (e) {
    if (e instanceof SegmentRuleError) return { error: `This audience can’t be worked out: ${e.message}.` }
    throw e
  }
}

export interface AudienceRow {
  id: string
  email: string
  name: string | null
  firstName: string | null
  lastName: string | null
}

/** One page of matching, non-suppressed subscribers after `afterId` (id order). `scanned` drives the cursor. */
export async function audiencePage(where: Record<string, unknown>, afterId: string | null, take: number): Promise<{ rows: AudienceRow[]; lastId: string | null; scanned: number }> {
  const page = await prisma.emailSubscriber.findMany({
    where: (afterId ? { AND: [where, { id: { gt: afterId } }] } : where) as never,
    select: { id: true, email: true, name: true, firstName: true, lastName: true },
    orderBy: { id: 'asc' },
    take,
  })
  const blocked = await suppressedAmong(page.map((r) => r.email))
  return { rows: page.filter((r) => !blocked.has(r.email)), lastId: page.at(-1)?.id ?? null, scanned: page.length }
}

/** Live count of who would get it right now. */
export async function countAudience(a: Audience): Promise<{ count: number; error?: string }> {
  if (isEmptyAudience(a)) return { count: 0 }
  const f = await audienceFilter(a)
  if ('error' in f) return { count: 0, error: f.error }
  let count = 0
  let after: string | null = null
  for (;;) {
    const p = await audiencePage(f.where, after, COUNT_PAGE)
    count += p.rows.length
    if (p.scanned < COUNT_PAGE) break
    after = p.lastId
  }
  return { count }
}
