// Moved to @far-cms/core (far-cms packages/core/src/lib/email/campaign/click-meta.ts). Change it there; this file only re-exports it.
export * from '@far-cms/core/lib/email/campaign/click-meta'
