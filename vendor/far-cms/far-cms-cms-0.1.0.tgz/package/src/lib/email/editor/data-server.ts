/**
 * What the email blocks show from the site, read when an email is rendered
 * (editor preview and the stored campaign HTML): published initiatives,
 * blog posts and upcoming events, the organisation's name/tagline/postal
 * address, and the site's address for links. Only published things. An
 * initiative card shows its numeric goal ("Goal: $3,000"); a progress bar
 * needs a real raised amount, which nothing records yet — so no bar (never
 * an invented one).
 */

import { prisma } from '../../db'
import { goalProgress } from '../../ade/records/goal'
import { getSettings } from '../../settings'
import { UNSET_BRAND_NAME } from '../../settings/brand'
import { contactFromStored, identityFromStored } from '../../settings/site-identity'
import type { EmailRenderContext, EmailRenderData, EventData, InitiativeData, PostData } from './render'

export interface EmailEditorSources {
  data: EmailRenderData
  org: EmailRenderContext['org']
  siteUrl: string
  /** For the Style panel pickers. */
  choices: {
    initiatives: Array<{ id: string; title: string }>
    posts: Array<{ id: string; title: string }>
    events: Array<{ id: string; title: string; dateLabel: string }>
  }
  /** The site logo for the header block's default. */
  logoUrl: string
}

const str = (v: unknown) => (typeof v === 'string' ? v : '')

function dateLabel(d: Date, tz: string): string {
  try {
    return new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: tz || 'UTC' }).format(d)
  } catch {
    return d.toUTCString()
  }
}

export async function loadEmailEditorSources(): Promise<EmailEditorSources> {
  const [branding, general, records, posts, events] = await Promise.all([
    getSettings<Record<string, unknown>>('branding', {}),
    getSettings<Record<string, unknown>>('general', {}),
    prisma.adeRecord.findMany({ where: { type: 'initiative', status: 'PUBLISHED' }, orderBy: { updatedAt: 'desc' }, take: 50, select: { id: true, slug: true, data: true } }),
    prisma.blogPost.findMany({
      where: { status: 'PUBLISHED', visibility: 'PUBLIC' },
      orderBy: { publishedAt: 'desc' },
      take: 20,
      select: { id: true, title: true, slug: true, excerpt: true, featuredImage: { select: { url: true } } },
    }),
    prisma.event.findMany({
      where: { status: 'PUBLISHED', startDate: { gte: new Date() } },
      orderBy: { startDate: 'asc' },
      take: 20,
      select: { id: true, title: true, slug: true, startDate: true, timezone: true, venueName: true, venueCity: true },
    }),
  ])

  const identity = identityFromStored(branding, general)
  const contact = contactFromStored(general)

  const initiatives: Record<string, InitiativeData> = {}
  for (const r of records) {
    const d = (r.data ?? {}) as Record<string, unknown>
    const goal = goalProgress(d.goalAmount, d.goalCurrency, d.raisedAmount)
    initiatives[r.id] = { title: str(d.name) || r.slug, imageUrl: str(d.heroImageUrl) || null, blurb: str(d.summary) || null, progress: goal?.pct ?? null, progressLabel: goal?.label ?? null, href: `/initiatives/${r.slug}` }
  }
  const postData: Record<string, PostData> = {}
  for (const p of posts) postData[p.id] = { title: p.title, excerpt: p.excerpt, imageUrl: p.featuredImage?.url ?? null, href: `/posts/${p.slug}` }
  const eventData: Record<string, EventData> = {}
  for (const e of events) eventData[e.id] = { title: e.title, dateLabel: dateLabel(e.startDate, e.timezone), location: [e.venueName, e.venueCity].filter(Boolean).join(', ') || null, href: `/events/${e.slug}` }

  return {
    data: { initiatives, posts: postData, latestPostId: posts[0]?.id ?? null, events: eventData },
    org: { name: identity.siteName || UNSET_BRAND_NAME, tagline: identity.siteTagline || undefined, address: contact.address },
    siteUrl: (process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000').replace(/\/+$/, ''),
    choices: {
      initiatives: Object.entries(initiatives).map(([id, d]) => ({ id, title: d.title })),
      posts: posts.map((p) => ({ id: p.id, title: p.title })),
      events: Object.entries(eventData).map(([id, d]) => ({ id, title: d.title, dateLabel: d.dateLabel })),
    },
    logoUrl: identity.logoDarkUrl || identity.logoUrl || '',
  }
}
