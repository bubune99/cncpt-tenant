/**
 * The reference email (owner-approved design, 2026-10-09: "October update")
 * as a document + the live data it shows — the renderer's fixture
 * (render.assert.tsx) and the editor's sample for a new campaign preview.
 * Throwaway content only.
 */

import { newBlock, newColumns, normalizeEmailDoc, type EmailDoc } from './doc'
import type { EmailRenderContext } from './render'

export function referenceEmail(): EmailDoc {
  const header = newBlock('Header', 'hdr')
  header.props.logoUrl = '/images/logo-white.png'
  const hero = newBlock('Image', 'hero')
  Object.assign(hero.props, { src: '/media/akuse-hospital.jpg', alt: 'Akuse Government Hospital entrance', fullBleed: true })
  const h = newBlock('Heading', 'h1')
  h.props.text = 'Your support reached Akuse Hospital'
  const t = newBlock('Text', 'intro')
  t.props.html = 'Hi {{subscriber.firstName|default:"friend"}}, this month your gifts put <strong>1,200 medical supply kits</strong> into the hands of nurses at Akuse Government Hospital. Here’s where things stand.'
  const cards = newColumns(2, (i) => {
    const c = newBlock('Initiative', `card${i}`)
    c.props.initiativeId = i === 0 ? 'init-supply' : 'init-travel'
    return [c]
  })
  cards.props.id = 'cards'
  const btn = newBlock('Button', 'give')
  const footer = newBlock('Footer', 'ftr')
  return normalizeEmailDoc({ content: [header, hero, h, t, cards, btn, footer], root: { props: {} } })
}

export const REFERENCE_CONTEXT: EmailRenderContext = {
  siteUrl: 'https://projectdzidzor.test',
  org: { name: 'Project Dzidzor', tagline: 'Delivering Hope, Healing Lives', address: 'Project Dzidzor\nPO Box 123\nRaleigh, NC 27601' },
  mode: 'send',
  previewText: '1,200 supply kits delivered to Akuse Hospital',
  data: {
    initiatives: {
      'init-supply': { title: 'Hospital Medical Supply Donations', imageUrl: '/media/supply.jpg', progress: 64, progressLabel: '64% of this year’s goal', href: '/initiatives/hospital-medical-supply-donations' },
      'init-travel': { title: 'Travel With Us', imageUrl: '/media/plane.jpg', blurb: 'Join the next mission trip to Ghana this spring.', progress: null, href: '/initiatives/travel-with-us' },
    },
    posts: {},
    events: {},
  },
}
