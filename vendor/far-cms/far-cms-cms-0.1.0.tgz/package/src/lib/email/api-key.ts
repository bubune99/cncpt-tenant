/**
 * Provider API keys arrive from a settings form or an environment variable, pasted by hand (often from a phone):
 * a trailing space or newline, or surrounding quotes, makes a good key "invalid" at the provider. cleanApiKey
 * repairs exactly those. Pure; asserted by api-key.assert.ts. (Ported from BYB e40f815.)
 */

/** Trim, drop one pair of matching surrounding quotes, trim again. Empty -> undefined. */
export function cleanApiKey(raw: string | null | undefined): string | undefined {
  if (typeof raw !== 'string') return undefined
  let v = raw.trim()
  const q = v[0]
  if (v.length >= 2 && (q === '"' || q === "'" || q === '“' || q === '‘') && /["'”’]$/.test(v)) v = v.slice(1, -1).trim()
  return v || undefined
}
