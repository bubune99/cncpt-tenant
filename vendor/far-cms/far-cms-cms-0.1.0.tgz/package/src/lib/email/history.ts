/**
 * Version history for email: campaigns ('email-campaign') and templates
 * ('email-template'). Versioned: what the email says and who it goes to —
 * not its send state (status, schedule, send job, counters), which the send
 * pipeline owns. Only a draft campaign can be restored, and a restore drops
 * the last test (it showed different content). Built-in templates never
 * change.
 */

import { Prisma } from '@prisma/client'
import { prisma } from '../db'
import { historyRecorder, registerHistory } from '../ade-bindings/history'
import type { RestorePolicy } from '../ade/history'
import { HistoryRefusal } from '../ade/history'
import { campaignRestoreBlock, templateRestoreBlock } from './restore-rules'

const CAMPAIGN = {
  name: true,
  subject: true,
  preheader: true,
  templateId: true,
  content: true,
  html: true,
  fromName: true,
  fromEmail: true,
  replyTo: true,
  type: true,
  segmentId: true,
  audience: true,
} as const

const TEMPLATE = {
  name: true,
  slug: true,
  description: true,
  category: true,
  subject: true,
  preheader: true,
  content: true,
  html: true,
  isActive: true,
} as const

type Obj = Record<string, unknown>

const loadCampaign = (id: string) => prisma.emailCampaign.findUnique({ where: { id }, select: CAMPAIGN }) as Promise<Obj | null>
const loadTemplate = (id: string) => prisma.emailTemplate.findUnique({ where: { id }, select: TEMPLATE }) as Promise<Obj | null>

export const campaignHistory = historyRecorder('email-campaign', loadCampaign)
export const templateHistory = historyRecorder('email-template', loadTemplate)

/** Nullable JSON columns are cleared with DbNull (Prisma refuses a plain null). */
const jsonNulls = (patch: Obj, json: readonly string[]) =>
  Object.fromEntries(Object.entries(patch).map(([k, v]) => [k, v == null && json.includes(k) ? Prisma.DbNull : v]))

/** What a (draft) campaign restore may write. */
export const CAMPAIGN_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    ...Object.fromEntries(['name', 'subject', 'preheader', 'html', 'fromName', 'fromEmail', 'replyTo'].map((f) => [f, { class: 'restorable' as const, type: 'string' as const }])),
    content: { class: 'restorable', type: 'json' },
    templateId: { class: 'restorable', type: 'string' },
    audience: { class: 'guarded', type: 'json', consequence: 'Who gets this email changes' },
    type: { class: 'guarded', type: 'enum', values: ['REGULAR', 'AUTOMATED', 'TRANSACTIONAL'], consequence: 'Whether it counts as marketing mail changes' },
    segmentId: { class: 'never', reason: 'The old segment setting is replaced by the audience' },
  },
}

/** What a template restore may write. */
export const TEMPLATE_POLICY: RestorePolicy = {
  schemaVersion: 1,
  fields: {
    ...Object.fromEntries(['name', 'description', 'subject', 'preheader', 'html'].map((f) => [f, { class: 'restorable' as const, type: 'string' as const }])),
    content: { class: 'restorable', type: 'json' },
    slug: { class: 'guarded', type: 'string', consequence: 'Its short name changes' },
    category: { class: 'guarded', type: 'enum', values: ['TRANSACTIONAL', 'MARKETING', 'AUTOMATION', 'NOTIFICATION'], consequence: 'Which emails can use it changes' },
    isActive: { class: 'guarded', type: 'boolean', consequence: 'Whether it can be picked for new emails changes' },
  },
}

registerHistory({
  entityType: 'email-campaign',
  policy: CAMPAIGN_POLICY,
  missingRefs: async (t) => (typeof t.templateId === 'string' && !(await prisma.emailTemplate.findUnique({ where: { id: t.templateId }, select: { id: true } })) ? { templateId: 'That template was deleted' } : {}),
  editPermission: 'email.edit',
  ignore: new Set(['id', 'createdAt', 'updatedAt']),
  load: loadCampaign,
  async restoreBlocked(id) {
    const c = await prisma.emailCampaign.findUnique({ where: { id }, select: { status: true } })
    return c ? campaignRestoreBlock(c.status) : null
  },
  nameOf: async (id) => (await prisma.emailCampaign.findUnique({ where: { id }, select: { name: true } }))?.name ?? null,
  fieldLabels: {
    name: 'Name',
    subject: 'Subject',
    preheader: 'Preview text',
    templateId: 'Template',
    content: 'Email',
    html: 'Email (as sent)',
    fromName: 'From name',
    fromEmail: 'From address',
    replyTo: 'Replies go to',
    type: 'Kind',
    segmentId: 'Segment (old)',
    audience: 'Who gets it',
  },
  async save(id, patch, actor, reason) {
    await campaignHistory.update(id, { actor, reason }, async () => {
      // Only while it's a draft (checked again here: the status can change between check and write).
      const r = await prisma.emailCampaign.updateMany({
        where: { id, status: 'DRAFT' },
        data: { ...jsonNulls(patch, ['content', 'audience']), testSentAt: null } as Prisma.EmailCampaignUncheckedUpdateManyInput,
      })
      if (r.count === 0) throw new HistoryRefusal('Only a draft campaign can go back to an earlier version')
    })
  },
})

registerHistory({
  entityType: 'email-template',
  policy: TEMPLATE_POLICY,
  editPermission: 'email.edit',
  ignore: new Set(['id', 'createdAt', 'updatedAt', 'isSystem', 'thumbnailUrl']),
  load: loadTemplate,
  async restoreBlocked(id) {
    const t = await prisma.emailTemplate.findUnique({ where: { id }, select: { isSystem: true } })
    return t ? templateRestoreBlock(t) : null
  },
  nameOf: async (id) => (await prisma.emailTemplate.findUnique({ where: { id }, select: { name: true } }))?.name ?? null,
  fieldLabels: {
    name: 'Name',
    slug: 'Short name',
    description: 'Description',
    category: 'Kind',
    subject: 'Subject',
    preheader: 'Preview text',
    content: 'Email',
    html: 'Email (as sent)',
    isActive: 'In use',
  },
  async save(id, patch, actor, reason) {
    await templateHistory.update(id, { actor, reason }, () =>
      prisma.emailTemplate.update({ where: { id }, data: jsonNulls(patch, ['content']) as Prisma.EmailTemplateUncheckedUpdateInput })
    )
  },
})
