/**
 * Pre-send checks for a campaign — pure. checks-server (lib/email/campaign)
 * gathers the inputs; Send and Schedule refuse unless every REQUIRED check
 * passes. Warnings are shown but never block. Asserted by
 * campaign-pipeline.assert.ts.
 */

import { walk, type EmailDoc } from './editor/doc'

export type CheckLevel = 'required' | 'warning'

export interface CampaignCheck {
  id: string
  label: string
  ok: boolean
  level: CheckLevel
  detail?: string
  fixHref?: string
}

export interface CheckInput {
  subject: string
  preheader?: string | null
  html: string | null
  /** The editor's block document (lib/email/editor/doc), when there is one. */
  doc?: EmailDoc | null
  /** Picked Initiative/Event ids that are no longer published (server looks them up). */
  unpublishedPicks?: number
  /** Settings › Contact details › Address (the legal footer needs it). */
  postalAddress: string | null
  /** The address mail is sent from, and whether the provider has its credentials. */
  sender: { email: string | null; providerConfigured: boolean }
  testSentAt: Date | null
  audience: { count: number; error?: string | null }
}

export const SUBJECT_MAX = 60
export const SUBJECT_PHONE = 40
export const PHONE_MAX_WIDTH = 600

export const FIX = {
  contact: '/admin/settings?section=contact',
  sending: '/admin/settings?section=email',
  audience: '?tab=audience',
} as const

const TAG = /<([a-z][a-z0-9]*)\b([^>]*)>/gi

function attr(attrs: string, name: string): string | null {
  const m = new RegExp(`\\b${name}\\s*=\\s*(["'])(.*?)\\1`, 'i').exec(attrs) ?? new RegExp(`\\b${name}\\s*=\\s*([^\\s>"']+)`, 'i').exec(attrs)
  if (!m) return null
  return (m.length === 3 ? m[2] : m[1]) ?? null
}

/** Images (not the 1×1 tracking pixel) with no alt text. */
export function imagesMissingAlt(html: string): number {
  let missing = 0
  for (const m of html.matchAll(TAG)) {
    if (m[1].toLowerCase() !== 'img') continue
    const a = m[2]
    if (attr(a, 'width') === '1' && attr(a, 'height') === '1') continue
    const alt = attr(a, 'alt')
    if (!alt || !alt.trim()) missing++
  }
  return missing
}

/** Fixed widths wider than a phone allows (px), ignoring ones capped by max-width:100%. */
export function tooWideElements(html: string): number[] {
  const wide: number[] = []
  for (const m of html.matchAll(TAG)) {
    const a = m[2]
    const style = attr(a, 'style') ?? ''
    if (/max-width\s*:\s*100%/i.test(style)) continue
    const w = attr(a, 'width')
    const fromAttr = w && /^\d+$/.test(w.trim()) ? Number(w) : 0
    const fromStyle = Number(/(?:^|;)\s*(?:min-)?width\s*:\s*(\d+)px/i.exec(style)?.[1] ?? 0)
    const px = Math.max(fromAttr, fromStyle)
    if (px > PHONE_MAX_WIDTH) wide.push(px)
  }
  return wide
}

/**
 * Side-by-side column cells that won't stack on a phone: a <td> narrower
 * than the email (width under 100%, or 150–599px), unless it is a
 * "stack-column" and a max-width media query stacks those (what the
 * templates emit). Counted per cell — nested tables make "rows" unreliable.
 */
export function unstackedColumnCells(html: string): number {
  const stacks = /@media[^{]*max-width[^{]*\{[^@]*\.stack-column/i.test(html)
  let cells = 0
  for (const m of html.matchAll(TAG)) {
    if (m[1].toLowerCase() !== 'td') continue
    const a = m[2]
    const style = attr(a, 'style') ?? ''
    const w = (attr(a, 'width') ?? '').trim()
    const sw = /(?:^|;)\s*width\s*:\s*(\d+(?:\.\d+)?)(%|px)/i.exec(style)
    const [num, unit] = sw ? [Number(sw[1]), sw[2]] : /^\d+%$/.test(w) ? [parseFloat(w), '%'] : /^\d+$/.test(w) ? [Number(w), 'px'] : [NaN, '']
    const column = (unit === '%' && num < 100) || (unit === 'px' && num >= 150 && num < PHONE_MAX_WIDTH)
    if (!column) continue
    if (!(stacks && /\bstack-column\b/.test(attr(a, 'class') ?? ''))) cells++
  }
  return cells
}

/** Blocks the editor needs filled in: live picks not chosen, links with nowhere to go. */
export function docGaps(doc: EmailDoc | null | undefined): { unpicked: number; emptyLinks: number } {
  let unpicked = 0
  let emptyLinks = 0
  if (!doc) return { unpicked, emptyLinks }
  walk(doc.content, (b) => {
    if ((b.type === 'Initiative' && !b.props.initiativeId) || (b.type === 'Event' && !b.props.eventId)) unpicked++
    if ((b.type === 'Button' || b.type === 'Link') && (!b.props.href?.trim() || b.props.href.trim() === '#')) emptyLinks++
  })
  return { unpicked, emptyLinks }
}

/** The Initiative / Event ids a document picks (to check they are still published). */
export function pickedLiveIds(doc: EmailDoc | null | undefined): { initiativeIds: string[]; eventIds: string[] } {
  const initiativeIds = new Set<string>()
  const eventIds = new Set<string>()
  if (doc)
    walk(doc.content, (b) => {
      if (b.type === 'Initiative' && b.props.initiativeId) initiativeIds.add(b.props.initiativeId)
      if (b.type === 'Event' && b.props.eventId) eventIds.add(b.props.eventId)
    })
  return { initiativeIds: [...initiativeIds], eventIds: [...eventIds] }
}

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`

/**
 * The checks, in the order the editor shows them. Ids are the contract
 * (the editor and the dashboard briefing read them): audience, html,
 * address, images-alt, sender-verified, subject, subject-length, test-sent,
 * phone-width (required); phone-columns, preview-text, links, live-picked
 * (warnings). subject-length is REQUIRED over 60 characters and a warning
 * over 40.
 */
export function campaignChecks(input: CheckInput): CampaignCheck[] {
  const subject = input.subject.trim()
  const html = input.html ?? ''
  const out: CampaignCheck[] = []
  const n = input.audience.count

  out.push(
    input.audience.error
      ? { id: 'audience', label: 'Who gets it can’t be worked out', ok: false, level: 'required', detail: input.audience.error, fixHref: FIX.audience }
      : n > 0
        ? { id: 'audience', label: `Goes to ${plural(n, 'subscriber')}`, ok: true, level: 'required', detail: 'Active subscribers who match, minus anyone who unsubscribed, bounced or complained.' }
        : { id: 'audience', label: 'Nobody would get it', ok: false, level: 'required', detail: 'Choose who gets this campaign — nobody matches yet.', fixHref: FIX.audience },
  )

  out.push(html.trim() ? { id: 'html', label: 'The email has content', ok: true, level: 'required' } : { id: 'html', label: 'The email is empty', ok: false, level: 'required', detail: 'Add some content and save.' })

  out.push(
    input.postalAddress?.trim()
      ? { id: 'address', label: 'Postal address and unsubscribe link', ok: true, level: 'required', detail: 'Added to the footer of every email automatically.' }
      : { id: 'address', label: 'No postal address yet', ok: false, level: 'required', detail: 'The law needs your postal address in every marketing email. Add it in Contact details.', fixHref: FIX.contact },
  )

  const noAlt = imagesMissingAlt(html)
  out.push(
    noAlt === 0
      ? { id: 'images-alt', label: 'Every image has alt text', ok: true, level: 'required' }
      : { id: 'images-alt', label: `${plural(noAlt, 'image')} without alt text`, ok: false, level: 'required', detail: 'Describe what each picture shows, for people using screen readers or with images turned off.' },
  )

  const from = input.sender.email?.trim() ?? ''
  out.push(
    from && input.sender.providerConfigured
      ? { id: 'sender-verified', label: `Sent from ${from}`, ok: true, level: 'required', detail: 'Make sure this address’s domain is verified with your email provider.' }
      : { id: 'sender-verified', label: from ? 'Email provider not connected' : 'No sending address yet', ok: false, level: 'required', detail: from ? 'Connect your email provider in Sending email.' : 'Set the address emails come from in Sending email.', fixHref: FIX.sending },
  )

  out.push(subject ? { id: 'subject', label: 'Has a subject line', ok: true, level: 'required' } : { id: 'subject', label: 'No subject line', ok: false, level: 'required', detail: 'Add a subject line.' })
  if (subject) {
    const len = subject.length
    const label = `Subject is ${len} character${len === 1 ? '' : 's'}`
    out.push(
      len > SUBJECT_MAX
        ? { id: 'subject-length', label, ok: false, level: 'required', detail: `Keep it to ${SUBJECT_MAX} or fewer.` }
        : len > SUBJECT_PHONE
          ? { id: 'subject-length', label, ok: false, level: 'warning', detail: `Phones show about ${SUBJECT_PHONE}; the end may be cut off.` }
          : { id: 'subject-length', label, ok: true, level: 'warning', detail: 'Short enough to show in full on a phone.' },
    )
  }

  out.push(
    input.testSentAt
      ? { id: 'test-sent', label: 'Test email sent', ok: true, level: 'required', detail: `Last test ${input.testSentAt.toISOString().slice(0, 16).replace('T', ' ')} UTC. Changing the email asks for a new one.` }
      : { id: 'test-sent', label: 'No test sent yet', ok: false, level: 'required', detail: 'Send yourself a test of this version and check it on your phone.' },
  )

  const wide = tooWideElements(html)
  out.push(
    wide.length === 0
      ? { id: 'phone-width', label: 'Fits a phone screen', ok: true, level: 'required' }
      : { id: 'phone-width', label: `${plural(wide.length, 'part')} too wide for a phone`, ok: false, level: 'required', detail: `Wider than ${PHONE_MAX_WIDTH}px (up to ${Math.max(...wide)}px) — people would have to scroll sideways.` },
  )
  const unstacked = unstackedColumnCells(html)
  out.push(
    unstacked === 0
      ? { id: 'phone-columns', label: 'Columns work on a phone', ok: true, level: 'warning' }
      : { id: 'phone-columns', label: 'Columns stay side by side on a phone', ok: false, level: 'warning', detail: `${plural(unstacked, 'column')} won’t stack on a small screen and may look squashed. Check the test on your phone.` },
  )

  out.push(
    input.preheader?.trim()
      ? { id: 'preview-text', label: 'Has preview text', ok: true, level: 'warning' }
      : { id: 'preview-text', label: 'No preview text', ok: false, level: 'warning', detail: 'Inboxes show a line of preview after the subject; without it they show the first words of the email.' },
  )

  const gaps = docGaps(input.doc)
  out.push(
    gaps.emptyLinks === 0
      ? { id: 'links', label: 'Every button and link goes somewhere', ok: true, level: 'warning' }
      : { id: 'links', label: `${plural(gaps.emptyLinks, 'button or link', 'buttons or links')} go nowhere`, ok: false, level: 'warning', detail: 'Give each one a web address.' },
  )
  const missing = gaps.unpicked + (input.unpublishedPicks ?? 0)
  out.push(
    missing === 0
      ? { id: 'live-picked', label: 'Initiatives and events are picked', ok: true, level: 'warning' }
      : { id: 'live-picked', label: `${plural(missing, 'initiative or event', 'initiatives or events')} missing`, ok: false, level: 'warning', detail: 'Not picked, or no longer published — left out of the email.' },
  )
  return out
}

/** Every required check passes. */
export function requiredChecksPass(checks: readonly CampaignCheck[]): boolean {
  return checks.every((c) => c.level !== 'required' || c.ok)
}

/** Does the chosen provider have what it needs to send? (Settings › Sending email, or env fallbacks.) */
export function providerConfigured(s: {
  provider?: string
  smtpHost?: string
  sendgridApiKey?: string
  resendApiKey?: string
  mailgunApiKey?: string
  mailgunDomain?: string
  sesRegion?: string
  sesAccessKeyId?: string
  sesSecretAccessKey?: string
}): boolean {
  switch (s.provider) {
    case 'smtp':
      return !!s.smtpHost
    case 'sendgrid':
      return !!s.sendgridApiKey
    case 'resend':
      return !!s.resendApiKey
    case 'mailgun':
      return !!(s.mailgunApiKey && s.mailgunDomain)
    case 'ses':
      return !!(s.sesRegion && s.sesAccessKeyId && s.sesSecretAccessKey)
    default:
      return false
  }
}

/**
 * Who may send or schedule a campaign. Owner only until the owner answers
 * "who may send" — then widen it HERE (one place, asserted).
 */
export function maySendCampaign(p: { isOwner: boolean }): boolean {
  return p.isOwner
}
