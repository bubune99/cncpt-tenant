import type { Metadata } from "next";
import { getBrandingSettings } from './settings';
import { getBrand } from './settings/brand-server';
import type { Brand } from './settings/brand';

/**
 * The tab icon: the tab icon, else the square icon, else the full logo
 * (browsers fit it), else the framework default — all from Identity & brand.
 */
export function brandIcons(brand: Brand): Metadata["icons"] {
  return {
    icon: brand.faviconUrl || brand.logoUrl || "/favicon.ico",
    apple: brand.appleTouchIconUrl ?? undefined,
  };
}

/**
 * Generate dynamic metadata from branding settings (lib/settings/brand).
 */
export async function generateSiteMetadata(): Promise<Metadata> {
  const [brand, branding] = await Promise.all([getBrand(), getBrandingSettings()]);

  const metadata: Metadata = {
    title: {
      default: brand.name,
      template: `%s | ${brand.name}`,
    },
    description: brand.tagline ?? undefined,
    icons: brandIcons(brand),
    openGraph: {
      siteName: brand.name,
      images: branding.ogImageUrl ? [branding.ogImageUrl] : undefined,
    },
    twitter: {
      card: "summary_large_image",
    },
  };

  return metadata;
}

/**
 * Get branding for client-side use (cached)
 */
export async function getBrandingForClient() {
  const branding = await getBrandingSettings();

  return {
    siteName: branding.siteName,
    siteTagline: branding.siteTagline,
    logoUrl: branding.logoUrl,
    logoDarkUrl: branding.logoDarkUrl,
    logoAlt: branding.logoAlt,
    faviconUrl: branding.faviconUrl,
    primaryColor: branding.primaryColor,
    accentColor: branding.accentColor,
  };
}
