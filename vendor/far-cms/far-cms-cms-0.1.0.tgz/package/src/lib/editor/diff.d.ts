// Types for diff.js (plain JavaScript lifted from Dzidzor). TypeScript does not read JavaScript inside node_modules,
// so an app type-checking this package needs these declarations; the bundler uses diff.js itself.
import type { Node as ProseMirrorNode, Schema } from 'prosemirror-model'

export const DiffType: { readonly Unchanged: 0; readonly Deleted: -1; readonly Inserted: 1 }
export function diffEditor(schema: Schema, oldDoc: unknown, newDoc: unknown): ProseMirrorNode
