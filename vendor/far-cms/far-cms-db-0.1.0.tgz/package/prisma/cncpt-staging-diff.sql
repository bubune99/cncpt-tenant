-- CreateEnum
CREATE TYPE "EmailSuppressionReason" AS ENUM ('UNSUBSCRIBED', 'BOUNCED', 'COMPLAINED', 'MANUAL');

-- CreateEnum
CREATE TYPE "PuckTemplateType" AS ENUM ('SECTION', 'PAGE');

-- CreateEnum
CREATE TYPE "TourStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "TourVisibility" AS ENUM ('TENANT', 'PUBLIC', 'DRAFT');

-- CreateEnum
CREATE TYPE "TourRunStatus" AS ENUM ('IN_PROGRESS', 'COMPLETED', 'ABANDONED');

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "EmailCampaignStatus" ADD VALUE 'STOPPED';
ALTER TYPE "EmailCampaignStatus" ADD VALUE 'FAILED';

-- DropForeignKey
ALTER TABLE "ai_credit_balances" DROP CONSTRAINT "ai_credit_balances_subdomain_id_fkey";

-- DropForeignKey
ALTER TABLE "ai_credit_transactions" DROP CONSTRAINT "ai_credit_transactions_subdomain_id_fkey";

-- DropForeignKey
ALTER TABLE "analytics_dashboards" DROP CONSTRAINT "analytics_dashboards_tenant_id_fkey";

-- DropForeignKey
ALTER TABLE "analytics_widgets" DROP CONSTRAINT "analytics_widgets_dashboard_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_contributors" DROP CONSTRAINT "blog_contributors_post_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_contributors" DROP CONSTRAINT "blog_contributors_user_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_post_related" DROP CONSTRAINT "blog_post_related_post_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_post_related" DROP CONSTRAINT "blog_post_related_related_post_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_post_series" DROP CONSTRAINT "blog_post_series_post_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_post_series" DROP CONSTRAINT "blog_post_series_series_id_fkey";

-- DropForeignKey
ALTER TABLE "blog_series" DROP CONSTRAINT "blog_series_tenant_id_fkey";

-- DropForeignKey
ALTER TABLE "customer_notes" DROP CONSTRAINT "customer_notes_customer_id_fkey";

-- DropForeignKey
ALTER TABLE "feedback" DROP CONSTRAINT "feedback_tenant_id_fkey";

-- DropForeignKey
ALTER TABLE "loyalty_activities" DROP CONSTRAINT "loyalty_activities_customer_id_fkey";

-- DropForeignKey
ALTER TABLE "onboarding_checklists" DROP CONSTRAINT "onboarding_checklists_subdomainId_fkey";

-- DropForeignKey
ALTER TABLE "order_item_fulfillment_steps" DROP CONSTRAINT "order_item_fulfillment_steps_order_item_id_fkey";

-- DropForeignKey
ALTER TABLE "page_versions" DROP CONSTRAINT "page_versions_pageId_fkey";

-- DropForeignKey
ALTER TABLE "page_versions" DROP CONSTRAINT "page_versions_tenant_id_fkey";

-- DropForeignKey
ALTER TABLE "post_distribution_channels" DROP CONSTRAINT "post_distribution_channels_post_id_fkey";

-- DropForeignKey
ALTER TABLE "product_pricing_tiers" DROP CONSTRAINT "product_pricing_tiers_product_id_fkey";

-- DropForeignKey
ALTER TABLE "product_sale_schedules" DROP CONSTRAINT "product_sale_schedules_product_id_fkey";

-- DropForeignKey
ALTER TABLE "repository_connections" DROP CONSTRAINT "repository_connections_github_connection_id_fkey";

-- DropForeignKey
ALTER TABLE "repository_connections" DROP CONSTRAINT "repository_connections_subdomain_id_fkey";

-- DropForeignKey
ALTER TABLE "subdomains" DROP CONSTRAINT "subdomains_subscription_tier_id_fkey";

-- DropIndex
DROP INDEX "api_key_usage_apiKeyId_date_key";

-- DropIndex
DROP INDEX "api_key_usage_apiKeyId_idx";

-- DropIndex
DROP INDEX "api_key_usage_date_idx";

-- DropIndex
DROP INDEX "back_in_stock_subscriptions_email_productId_variantId_key";

-- DropIndex
DROP INDEX "cms_modules_slug_key";

-- DropIndex
DROP INDEX "custom_components_name_key";

-- DropIndex
DROP INDEX "help_tours_slug_key";

-- DropIndex
DROP INDEX "license_keys_key_key";

-- DropIndex
DROP INDEX "mcp_servers_name_key";

-- DropIndex
DROP INDEX "order_workflow_stages_workflowId_slug_key";

-- DropIndex
DROP INDEX "pages_system_key_idx";

-- DropIndex
DROP INDEX "pages_tenant_id_system_key_key";

-- DropIndex
DROP INDEX "plugins_name_key";

-- DropIndex
DROP INDEX "plugins_slug_key";

-- DropIndex
DROP INDEX "primitives_name_key";

-- DropIndex
DROP INDEX "product_variants_shopifyVariantId_idx";

-- DropIndex
DROP INDEX "products_shopifyProductId_idx";

-- DropIndex
DROP INDEX "puck_templates_slug_key";

-- DropIndex
DROP INDEX "review_votes_reviewId_email_key";

-- DropIndex
DROP INDEX "site_settings_tenant_id_idx";

-- DropIndex
DROP INDEX "subscription_tiers_name_key";

-- DropIndex
DROP INDEX "team_invitations_team_id_email_key";

-- DropIndex
DROP INDEX "teams_slug_key";

-- DropIndex
DROP INDEX "idx_users_email";

-- DropIndex
DROP INDEX "idx_users_last_login";

-- DropIndex
DROP INDEX "idx_users_status";

-- DropIndex
DROP INDEX "users_email_key";

-- DropIndex
DROP INDEX "users_stack_auth_id_idx";

-- DropIndex
DROP INDEX "users_stack_auth_id_key";

-- DropIndex
DROP INDEX "workflow_templates_slug_key";

-- DropIndex
DROP INDEX "workflows_slug_key";

-- AlterTable
ALTER TABLE "addresses" ADD COLUMN     "tenant_id" INTEGER,
ALTER COLUMN "userId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "admin_users" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "ai_conversations" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "ai_documents" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "ai_messages" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "ai_streams" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "ai_suggestions" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "ai_votes" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "analytics_events" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "api_key_usage" DROP CONSTRAINT "api_key_usage_pkey",
DROP COLUMN "avgResponseTimeMs",
DROP COLUMN "createdAt",
DROP COLUMN "date",
DROP COLUMN "errorCount",
DROP COLUMN "id",
DROP COLUMN "rateLimitCount",
DROP COLUMN "requestCount",
DROP COLUMN "successCount",
DROP COLUMN "toolUsage",
ADD COLUMN     "calls" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "day" DATE NOT NULL,
ADD COLUMN     "tenant_id" INTEGER,
ADD CONSTRAINT "api_key_usage_pkey" PRIMARY KEY ("apiKeyId", "day");

-- AlterTable
ALTER TABLE "api_keys" DROP COLUMN "projectName",
DROP COLUMN "rateLimitTier",
ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "audit_logs" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "blog_categories" ADD COLUMN     "canonicalUrl" TEXT,
ADD COLUMN     "noIndex" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "ogDescription" TEXT,
ADD COLUMN     "ogTitle" TEXT;

-- AlterTable
ALTER TABLE "blog_comments" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "blog_post_categories" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "blog_post_tags" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "blog_posts" DROP COLUMN "shop_product_ids",
ADD COLUMN     "homeOrder" INTEGER;

-- AlterTable
ALTER TABLE "blog_tags" ADD COLUMN     "metaDescription" TEXT,
ADD COLUMN     "metaTitle" TEXT;

-- AlterTable
ALTER TABLE "bundle_assets" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "canva_connections" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "cart_items" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "categories" ADD COLUMN     "metaDescription" TEXT,
ADD COLUMN     "metaTitle" TEXT;

-- AlterTable
ALTER TABLE "cms_modules" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "custom_animations" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "custom_components" DROP COLUMN "editorConfig",
ADD COLUMN     "puckConfig" JSONB NOT NULL,
ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "customer_addresses" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "customers" DROP COLUMN "lifecycle_stage",
DROP COLUMN "lifecycle_updated_at",
DROP COLUMN "loyalty_points",
DROP COLUMN "store_credit";

-- AlterTable
ALTER TABLE "digital_downloads" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "discount_usages" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_ab_tests" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_automation_enrollment_steps" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_automation_enrollments" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_automation_steps" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_automations" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_campaigns" ADD COLUMN     "audience" JSONB,
ADD COLUMN     "audienceDoneAt" TIMESTAMP(3),
ADD COLUMN     "failedCount" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "lastError" TEXT,
ADD COLUMN     "sendCursor" TEXT,
ADD COLUMN     "sendStartedById" TEXT,
ADD COLUMN     "testSentAt" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "email_link_clicks" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_links" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_queue_items" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_recipients" ADD COLUMN     "attempts" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "claimedAt" TIMESTAMP(3),
ADD COLUMN     "nextAttemptAt" TIMESTAMP(3),
ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_segment_members" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "email_segments" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "form_submissions" ADD COLUMN     "notes" TEXT,
ADD COLUMN     "status" TEXT NOT NULL DEFAULT 'new',
ADD COLUMN     "tags" TEXT[] DEFAULT ARRAY[]::TEXT[];

-- AlterTable
ALTER TABLE "forms" ADD COLUMN     "automations" JSONB,
ADD COLUMN     "captchaEnabled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "display" JSONB,
ADD COLUMN     "retentionMonths" INTEGER;

-- AlterTable
ALTER TABLE "help_content" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "help_tours" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "license_keys" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "mcp_servers" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "media" ADD COLUMN     "canvaDesignId" TEXT;

-- AlterTable
ALTER TABLE "media_tags_on_media" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "media_usage" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "order_items" DROP COLUMN "attachments",
DROP COLUMN "config_options",
ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "order_progress" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "order_workflow_stages" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "page_bundles" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "pages" DROP COLUMN "system_key",
ADD COLUMN     "canonicalUrl" TEXT,
ADD COLUMN     "noIndex" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "ogDescription" TEXT,
ADD COLUMN     "ogImageId" TEXT,
ADD COLUMN     "ogTitle" TEXT,
ADD COLUMN     "scheduledAt" TIMESTAMP(3),
ALTER COLUMN "updatedAt" SET DEFAULT CURRENT_TIMESTAMP;

-- AlterTable
ALTER TABLE "payments" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "platform_activity_log" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "plugins" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "primitive_executions" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "primitives" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_categories" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_custom_fields" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_images" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_option_values" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_options" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_variant_option_values" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "product_variants" DROP COLUMN "shopifySyncError",
DROP COLUMN "shopifySyncedAt",
DROP COLUMN "shopifyVariantId",
ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "products" DROP COLUMN "shopifyData",
DROP COLUMN "shopifyProductId",
DROP COLUMN "shopifySyncError",
DROP COLUMN "shopifySyncedAt",
ADD COLUMN     "canonicalUrl" TEXT,
ADD COLUMN     "noIndex" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "ogDescription" TEXT,
ADD COLUMN     "ogImageId" TEXT,
ADD COLUMN     "ogTitle" TEXT;

-- AlterTable
ALTER TABLE "puck_templates" ADD COLUMN     "tenant_id" INTEGER,
DROP COLUMN "type",
ADD COLUMN     "type" "PuckTemplateType" NOT NULL DEFAULT 'SECTION';

-- AlterTable
ALTER TABLE "shipments" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "site_settings" ALTER COLUMN "id" SET DEFAULT 'default';

-- AlterTable
ALTER TABLE "subdomains" DROP COLUMN "contact_email",
DROP COLUMN "custom_domain",
DROP COLUMN "disabled",
DROP COLUMN "disabled_at",
DROP COLUMN "disabled_reason",
DROP COLUMN "feature_config",
DROP COLUMN "industry",
DROP COLUMN "maintenance_message",
DROP COLUMN "maintenance_mode",
DROP COLUMN "onboarding_completed",
DROP COLUMN "onboarding_completed_at",
DROP COLUMN "primary_language",
DROP COLUMN "referral_source",
DROP COLUMN "site_description",
DROP COLUMN "site_name",
DROP COLUMN "subscription_status",
DROP COLUMN "subscription_tier_id",
DROP COLUMN "team_size",
DROP COLUMN "tech_experience",
DROP COLUMN "timezone",
DROP COLUMN "use_case",
ADD COLUMN     "emoji" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "subscription_tiers" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "subscriptions" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "super_admins" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "team_invitations" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "team_members" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "team_subdomains" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "teams" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "tenant_settings" DROP COLUMN "accent_color",
DROP COLUMN "apple_touch_icon_url",
DROP COLUMN "brand_preset",
DROP COLUMN "density",
DROP COLUMN "favicon_svg_url",
DROP COLUMN "favicon_url",
DROP COLUMN "hide_powered_by",
DROP COLUMN "logo_alt",
DROP COLUMN "logo_dark_url",
DROP COLUMN "logo_url",
DROP COLUMN "meta_description",
DROP COLUMN "og_image_url",
DROP COLUMN "primary_color",
DROP COLUMN "site_name",
DROP COLUMN "site_tagline",
DROP COLUMN "title_template";

-- AlterTable
ALTER TABLE "users" DROP COLUMN "avatar_url",
DROP COLUMN "created_at",
DROP COLUMN "deleted_at",
DROP COLUMN "email_verified",
DROP COLUMN "last_login_at",
DROP COLUMN "last_login_ip",
DROP COLUMN "login_count",
DROP COLUMN "stack_auth_id",
DROP COLUMN "status",
DROP COLUMN "subscription_status",
DROP COLUMN "suspended_at",
DROP COLUMN "suspension_reason",
DROP COLUMN "tier_id",
DROP COLUMN "updated_at",
ADD COLUMN     "accessRemovedAt" TIMESTAMP(3),
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "emailVerified" TIMESTAMP(3),
ADD COLUMN     "stackAuthId" TEXT,
ADD COLUMN     "tenant_id" INTEGER,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- AlterTable
ALTER TABLE "variant_custom_field_values" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "wishlist_items" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "workflow_executions" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "workflow_logs" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "workflow_nodes" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "workflow_steps" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "workflow_templates" ADD COLUMN     "tenant_id" INTEGER;

-- AlterTable
ALTER TABLE "workflows" ADD COLUMN     "tenant_id" INTEGER;

-- DropTable
DROP TABLE "ai_credit_balances";

-- DropTable
DROP TABLE "ai_credit_packs";

-- DropTable
DROP TABLE "ai_credit_transactions";

-- DropTable
DROP TABLE "ai_feature_costs";

-- DropTable
DROP TABLE "ai_model_tiers";

-- DropTable
DROP TABLE "analytics_dashboards";

-- DropTable
DROP TABLE "analytics_widget_templates";

-- DropTable
DROP TABLE "analytics_widgets";

-- DropTable
DROP TABLE "blog_contributors";

-- DropTable
DROP TABLE "blog_post_related";

-- DropTable
DROP TABLE "blog_post_series";

-- DropTable
DROP TABLE "blog_series";

-- DropTable
DROP TABLE "credit_grants";

-- DropTable
DROP TABLE "custom_domains";

-- DropTable
DROP TABLE "customer_notes";

-- DropTable
DROP TABLE "feedback";

-- DropTable
DROP TABLE "github_connections";

-- DropTable
DROP TABLE "loyalty_activities";

-- DropTable
DROP TABLE "marketplace_templates";

-- DropTable
DROP TABLE "onboarding_checklists";

-- DropTable
DROP TABLE "order_item_fulfillment_steps";

-- DropTable
DROP TABLE "page_versions";

-- DropTable
DROP TABLE "platform_announcements";

-- DropTable
DROP TABLE "post_distribution_channels";

-- DropTable
DROP TABLE "product_pricing_tiers";

-- DropTable
DROP TABLE "product_sale_schedules";

-- DropTable
DROP TABLE "rate_limit_rules";

-- DropTable
DROP TABLE "rate_limit_settings";

-- DropTable
DROP TABLE "repository_connections";

-- DropTable
DROP TABLE "subdomain_settings";

-- DropTable
DROP TABLE "user_overrides";

-- DropTable
DROP TABLE "webhook_events";

-- DropEnum
DROP TYPE "FeedbackStatus";

-- DropEnum
DROP TYPE "FeedbackType";

-- DropEnum
DROP TYPE "PageTemplateType";

-- DropEnum
DROP TYPE "SystemPageKey";

-- DropEnum
DROP TYPE "channel_publish_status";

-- DropEnum
DROP TYPE "customer_lifecycle_stage";

-- DropEnum
DROP TYPE "distribution_channel";

-- DropEnum
DROP TYPE "loyalty_activity_type";

-- DropEnum
DROP TYPE "pricing_tier_type";

-- CreateTable
CREATE TABLE "api_key_class_usage" (
    "tenant_id" INTEGER,
    "apiKeyId" TEXT NOT NULL,
    "day" DATE NOT NULL,
    "costClass" TEXT NOT NULL,
    "calls" INTEGER NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "api_key_class_usage_pkey" PRIMARY KEY ("apiKeyId","day","costClass")
);

-- CreateTable
CREATE TABLE "usage_counters" (
    "tenant_id" INTEGER,
    "kind" TEXT NOT NULL,
    "identity" TEXT NOT NULL,
    "windowStart" BIGINT NOT NULL,
    "windowMs" BIGINT NOT NULL,
    "amount" BIGINT NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "usage_counters_pkey" PRIMARY KEY ("kind","identity")
);

-- CreateTable
CREATE TABLE "page_revisions" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "pageId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "status" "PageStatus" NOT NULL,
    "content" JSONB,
    "reason" TEXT NOT NULL,
    "meta" JSONB,
    "createdById" TEXT,
    "createdByEmail" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "page_revisions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "email_suppressions" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "emailHash" TEXT NOT NULL,
    "reason" "EmailSuppressionReason" NOT NULL,
    "source" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "email_suppressions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "form_rule_runs" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "formId" TEXT NOT NULL,
    "submissionId" TEXT NOT NULL,
    "ruleId" TEXT,
    "ruleName" TEXT,
    "actionType" TEXT NOT NULL,
    "actionKey" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "detail" TEXT,
    "source" TEXT NOT NULL DEFAULT 'auto',
    "jobId" TEXT,
    "dedupeKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "form_rule_runs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "form_rate_limits" (
    "key" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "formId" TEXT NOT NULL,
    "windowStart" TIMESTAMP(3) NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "form_rate_limits_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "form_bulk_jobs" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "formId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "spec" JSONB NOT NULL,
    "total" INTEGER NOT NULL,
    "cursor" INTEGER NOT NULL DEFAULT 0,
    "ran" INTEGER NOT NULL DEFAULT 0,
    "skipped" INTEGER NOT NULL DEFAULT 0,
    "failed" INTEGER NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'running',
    "createdById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "form_bulk_jobs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tours" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "slug" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "steps" JSONB NOT NULL,
    "status" "TourStatus" NOT NULL DEFAULT 'DRAFT',
    "authorId" TEXT,
    "visibility" "TourVisibility" NOT NULL DEFAULT 'TENANT',
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tours_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tour_runs" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "tourId" TEXT NOT NULL,
    "userId" TEXT,
    "status" "TourRunStatus" NOT NULL,
    "currentStep" INTEGER NOT NULL DEFAULT 0,
    "totalSteps" INTEGER NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),
    "abandonedAt" TIMESTAMP(3),
    "metadata" JSONB,

    CONSTRAINT "tour_runs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_change_sets" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "workspaceId" TEXT NOT NULL DEFAULT 'default',
    "ownerId" TEXT,
    "source" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "rationale" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ade_change_sets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_change_set_items" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "changeSetId" TEXT NOT NULL,
    "targetType" TEXT NOT NULL,
    "targetId" TEXT,
    "operation" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "toolName" TEXT NOT NULL,
    "input" JSONB NOT NULL,
    "before" JSONB,
    "after" JSONB,
    "blockIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "rationale" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "error" TEXT,
    "resultId" TEXT,
    "revisionId" TEXT,
    "decidedById" TEXT,
    "decidedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ade_change_set_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_change_comments" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "changeSetId" TEXT NOT NULL,
    "itemId" TEXT,
    "authorId" TEXT,
    "authorEmail" TEXT,
    "kind" TEXT NOT NULL DEFAULT 'comment',
    "body" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ade_change_comments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_tasks" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "workspaceId" TEXT NOT NULL DEFAULT 'default',
    "userId" TEXT,
    "permission" TEXT,
    "source" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "detail" TEXT,
    "href" TEXT,
    "targetType" TEXT,
    "targetId" TEXT,
    "dedupeKey" TEXT NOT NULL,
    "priority" INTEGER NOT NULL DEFAULT 2,
    "status" TEXT NOT NULL DEFAULT 'open',
    "completedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ade_tasks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_coverage" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "route" TEXT NOT NULL,
    "result" JSONB NOT NULL,
    "units" INTEGER NOT NULL DEFAULT 0,
    "toolGaps" INTEGER NOT NULL DEFAULT 0,
    "uiGaps" INTEGER NOT NULL DEFAULT 0,
    "hidden" INTEGER NOT NULL DEFAULT 0,
    "runBy" TEXT,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ade_coverage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_user_prefs" (
    "userId" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "splitRatio" DOUBLE PRECISION,
    "prefs" JSONB,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ade_user_prefs_pkey" PRIMARY KEY ("userId")
);

-- CreateTable
CREATE TABLE "ade_records" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "workspaceId" TEXT NOT NULL DEFAULT 'default',
    "type" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "scheduledAt" TIMESTAMP(3),
    "data" JSONB NOT NULL,
    "pageId" TEXT,
    "legacyRef" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ade_records_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_edit_locks" (
    "targetKey" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "userId" TEXT NOT NULL,
    "userName" TEXT,
    "tabId" TEXT NOT NULL,
    "acquiredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "heartbeatAt" TIMESTAMP(3) NOT NULL,
    "requestedById" TEXT,
    "requestedByName" TEXT,
    "requestedAt" TIMESTAMP(3),

    CONSTRAINT "ade_edit_locks_pkey" PRIMARY KEY ("targetKey")
);

-- CreateTable
CREATE TABLE "agent_runs" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "conversationId" TEXT,
    "messageId" TEXT,
    "userId" TEXT,
    "area" TEXT,
    "route" TEXT,
    "request" TEXT,
    "model" TEXT,
    "effort" TEXT,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "endedAt" TIMESTAMP(3),
    "status" TEXT NOT NULL,
    "tainted" BOOLEAN NOT NULL DEFAULT false,
    "taintedBy" TEXT,
    "steps" INTEGER NOT NULL DEFAULT 0,
    "tokensIn" INTEGER NOT NULL DEFAULT 0,
    "tokensOut" INTEGER NOT NULL DEFAULT 0,
    "cacheRead" INTEGER NOT NULL DEFAULT 0,
    "cacheWrite" INTEGER NOT NULL DEFAULT 0,
    "tokens" INTEGER NOT NULL DEFAULT 0,
    "durationMs" INTEGER NOT NULL DEFAULT 0,
    "costEstimate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "toolGroupsLoaded" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "droppedSpans" INTEGER NOT NULL DEFAULT 0,
    "error" TEXT,

    CONSTRAINT "agent_runs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_spans" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "runId" TEXT NOT NULL,
    "parentId" TEXT,
    "seq" INTEGER NOT NULL,
    "kind" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "startMs" INTEGER NOT NULL,
    "endMs" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "attempt" INTEGER NOT NULL DEFAULT 1,
    "tokens" INTEGER NOT NULL DEFAULT 0,
    "detail" TEXT,
    "effect" TEXT,
    "tainted" BOOLEAN NOT NULL DEFAULT false,
    "changeSetId" TEXT,
    "auditLogId" TEXT,
    "inputRedacted" JSONB,
    "outputSummary" TEXT,
    "callId" TEXT,

    CONSTRAINT "agent_spans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_waits" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "userId" TEXT NOT NULL,
    "runId" TEXT NOT NULL,
    "conversationId" TEXT,
    "callId" TEXT NOT NULL,
    "stepId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "step" JSONB,
    "tokenHash" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'waiting',
    "action" TEXT,
    "output" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "ackedAt" TIMESTAMP(3),

    CONSTRAINT "ade_waits_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_revisions" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "version" INTEGER NOT NULL,
    "changed" TEXT[],
    "before" JSONB NOT NULL,
    "after" JSONB NOT NULL,
    "actorKind" TEXT NOT NULL,
    "actorUserId" TEXT,
    "runId" TEXT,
    "changeSetId" TEXT,
    "reason" TEXT,
    "schemaVersion" INTEGER NOT NULL DEFAULT 1,
    "meta" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ade_revisions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ade_handoffs" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "userId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "device" TEXT NOT NULL DEFAULT 'phone',
    "changeSetId" TEXT,
    "conversationId" TEXT,
    "href" TEXT,
    "status" TEXT NOT NULL DEFAULT 'open',
    "clientKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ade_handoffs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "connector_accounts" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "userId" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "scope" TEXT NOT NULL DEFAULT 'personal',
    "accountEnc" TEXT,
    "grantedScopes" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "accessTokenEnc" TEXT NOT NULL,
    "refreshTokenEnc" TEXT,
    "expiresAt" TIMESTAMP(3),
    "status" TEXT NOT NULL DEFAULT 'active',
    "connectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "connector_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "client_feedback" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "createdById" TEXT NOT NULL,
    "route" TEXT NOT NULL,
    "screen" TEXT NOT NULL DEFAULT '',
    "senderName" TEXT NOT NULL DEFAULT '',
    "dedupeKey" TEXT,
    "unitRef" TEXT,
    "note" TEXT NOT NULL,
    "screenshotMediaId" TEXT,
    "kind" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'new',
    "forwardedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "client_feedback_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "feedback_deliveries" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "feedbackId" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "nextAttemptAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lockedUntil" TIMESTAMP(3),
    "externalId" TEXT,
    "lastError" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "feedback_deliveries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "feedback_digests" (
    "day" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "count" INTEGER NOT NULL,
    "sentAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "feedback_digests_pkey" PRIMARY KEY ("day")
);

-- CreateTable
CREATE TABLE "feedback_screenshots" (
    "id" TEXT NOT NULL,
    "tenant_id" INTEGER,
    "createdById" TEXT NOT NULL,
    "contentType" TEXT NOT NULL,
    "size" INTEGER NOT NULL,
    "bytes" BYTEA NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "feedback_screenshots_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "api_key_class_usage_day_idx" ON "api_key_class_usage"("day");

-- CreateIndex
CREATE INDEX "api_key_class_usage_tenant_id_idx" ON "api_key_class_usage"("tenant_id");

-- CreateIndex
CREATE INDEX "usage_counters_kind_windowStart_idx" ON "usage_counters"("kind", "windowStart");

-- CreateIndex
CREATE INDEX "usage_counters_tenant_id_idx" ON "usage_counters"("tenant_id");

-- CreateIndex
CREATE INDEX "page_revisions_pageId_createdAt_idx" ON "page_revisions"("pageId", "createdAt");

-- CreateIndex
CREATE INDEX "page_revisions_tenant_id_idx" ON "page_revisions"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "email_suppressions_emailHash_key" ON "email_suppressions"("emailHash");

-- CreateIndex
CREATE INDEX "email_suppressions_tenant_id_idx" ON "email_suppressions"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "form_rule_runs_dedupeKey_key" ON "form_rule_runs"("dedupeKey");

-- CreateIndex
CREATE INDEX "form_rule_runs_submissionId_createdAt_idx" ON "form_rule_runs"("submissionId", "createdAt");

-- CreateIndex
CREATE INDEX "form_rule_runs_formId_ruleId_idx" ON "form_rule_runs"("formId", "ruleId");

-- CreateIndex
CREATE INDEX "form_rule_runs_jobId_idx" ON "form_rule_runs"("jobId");

-- CreateIndex
CREATE INDEX "form_rule_runs_tenant_id_idx" ON "form_rule_runs"("tenant_id");

-- CreateIndex
CREATE INDEX "form_rate_limits_windowStart_idx" ON "form_rate_limits"("windowStart");

-- CreateIndex
CREATE INDEX "form_rate_limits_tenant_id_idx" ON "form_rate_limits"("tenant_id");

-- CreateIndex
CREATE INDEX "form_bulk_jobs_formId_createdAt_idx" ON "form_bulk_jobs"("formId", "createdAt");

-- CreateIndex
CREATE INDEX "form_bulk_jobs_tenant_id_idx" ON "form_bulk_jobs"("tenant_id");

-- CreateIndex
CREATE INDEX "tours_slug_idx" ON "tours"("slug");

-- CreateIndex
CREATE INDEX "tours_status_visibility_idx" ON "tours"("status", "visibility");

-- CreateIndex
CREATE INDEX "tours_tenant_id_idx" ON "tours"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "tours_tenant_id_slug_key" ON "tours"("tenant_id", "slug");

-- CreateIndex
CREATE INDEX "tour_runs_tourId_status_idx" ON "tour_runs"("tourId", "status");

-- CreateIndex
CREATE INDEX "tour_runs_userId_idx" ON "tour_runs"("userId");

-- CreateIndex
CREATE INDEX "tour_runs_tenant_id_idx" ON "tour_runs"("tenant_id");

-- CreateIndex
CREATE INDEX "ade_change_sets_workspaceId_status_createdAt_idx" ON "ade_change_sets"("workspaceId", "status", "createdAt");

-- CreateIndex
CREATE INDEX "ade_change_sets_ownerId_idx" ON "ade_change_sets"("ownerId");

-- CreateIndex
CREATE INDEX "ade_change_sets_tenant_id_idx" ON "ade_change_sets"("tenant_id");

-- CreateIndex
CREATE INDEX "ade_change_set_items_changeSetId_idx" ON "ade_change_set_items"("changeSetId");

-- CreateIndex
CREATE INDEX "ade_change_set_items_status_category_idx" ON "ade_change_set_items"("status", "category");

-- CreateIndex
CREATE INDEX "ade_change_set_items_targetType_targetId_idx" ON "ade_change_set_items"("targetType", "targetId");

-- CreateIndex
CREATE INDEX "ade_change_set_items_revisionId_idx" ON "ade_change_set_items"("revisionId");

-- CreateIndex
CREATE INDEX "ade_change_set_items_tenant_id_idx" ON "ade_change_set_items"("tenant_id");

-- CreateIndex
CREATE INDEX "ade_change_comments_changeSetId_createdAt_idx" ON "ade_change_comments"("changeSetId", "createdAt");

-- CreateIndex
CREATE INDEX "ade_change_comments_tenant_id_idx" ON "ade_change_comments"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "ade_tasks_dedupeKey_key" ON "ade_tasks"("dedupeKey");

-- CreateIndex
CREATE INDEX "ade_tasks_workspaceId_status_priority_idx" ON "ade_tasks"("workspaceId", "status", "priority");

-- CreateIndex
CREATE INDEX "ade_tasks_userId_status_idx" ON "ade_tasks"("userId", "status");

-- CreateIndex
CREATE INDEX "ade_tasks_tenant_id_idx" ON "ade_tasks"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "ade_coverage_route_key" ON "ade_coverage"("route");

-- CreateIndex
CREATE INDEX "ade_coverage_tenant_id_idx" ON "ade_coverage"("tenant_id");

-- CreateIndex
CREATE INDEX "ade_user_prefs_tenant_id_idx" ON "ade_user_prefs"("tenant_id");

-- CreateIndex
CREATE INDEX "ade_records_type_status_idx" ON "ade_records"("type", "status");

-- CreateIndex
CREATE INDEX "ade_records_scheduledAt_idx" ON "ade_records"("scheduledAt");

-- CreateIndex
CREATE INDEX "ade_records_pageId_idx" ON "ade_records"("pageId");

-- CreateIndex
CREATE INDEX "ade_records_legacyRef_idx" ON "ade_records"("legacyRef");

-- CreateIndex
CREATE INDEX "ade_records_tenant_id_idx" ON "ade_records"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "ade_records_tenant_id_workspaceId_type_slug_key" ON "ade_records"("tenant_id", "workspaceId", "type", "slug");

-- CreateIndex
CREATE INDEX "ade_edit_locks_userId_idx" ON "ade_edit_locks"("userId");

-- CreateIndex
CREATE INDEX "ade_edit_locks_tenant_id_idx" ON "ade_edit_locks"("tenant_id");

-- CreateIndex
CREATE INDEX "agent_runs_userId_startedAt_idx" ON "agent_runs"("userId", "startedAt");

-- CreateIndex
CREATE INDEX "agent_runs_status_startedAt_idx" ON "agent_runs"("status", "startedAt");

-- CreateIndex
CREATE INDEX "agent_runs_startedAt_idx" ON "agent_runs"("startedAt");

-- CreateIndex
CREATE INDEX "agent_runs_conversationId_idx" ON "agent_runs"("conversationId");

-- CreateIndex
CREATE INDEX "agent_runs_tenant_id_idx" ON "agent_runs"("tenant_id");

-- CreateIndex
CREATE INDEX "agent_spans_runId_idx" ON "agent_spans"("runId");

-- CreateIndex
CREATE INDEX "agent_spans_callId_idx" ON "agent_spans"("callId");

-- CreateIndex
CREATE INDEX "agent_spans_tenant_id_idx" ON "agent_spans"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "ade_waits_tokenHash_key" ON "ade_waits"("tokenHash");

-- CreateIndex
CREATE INDEX "ade_waits_userId_status_idx" ON "ade_waits"("userId", "status");

-- CreateIndex
CREATE INDEX "ade_waits_userId_callId_idx" ON "ade_waits"("userId", "callId");

-- CreateIndex
CREATE INDEX "ade_waits_conversationId_idx" ON "ade_waits"("conversationId");

-- CreateIndex
CREATE INDEX "ade_waits_createdAt_idx" ON "ade_waits"("createdAt");

-- CreateIndex
CREATE INDEX "ade_waits_tenant_id_idx" ON "ade_waits"("tenant_id");

-- CreateIndex
CREATE INDEX "ade_revisions_entityType_entityId_createdAt_idx" ON "ade_revisions"("entityType", "entityId", "createdAt");

-- CreateIndex
CREATE INDEX "ade_revisions_actorUserId_createdAt_idx" ON "ade_revisions"("actorUserId", "createdAt");

-- CreateIndex
CREATE INDEX "ade_revisions_createdAt_idx" ON "ade_revisions"("createdAt");

-- CreateIndex
CREATE INDEX "ade_revisions_tenant_id_idx" ON "ade_revisions"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "ade_revisions_entityType_entityId_version_key" ON "ade_revisions"("entityType", "entityId", "version");

-- CreateIndex
CREATE INDEX "ade_handoffs_userId_status_createdAt_idx" ON "ade_handoffs"("userId", "status", "createdAt");

-- CreateIndex
CREATE INDEX "ade_handoffs_changeSetId_idx" ON "ade_handoffs"("changeSetId");

-- CreateIndex
CREATE INDEX "ade_handoffs_tenant_id_idx" ON "ade_handoffs"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "ade_handoffs_userId_clientKey_key" ON "ade_handoffs"("userId", "clientKey");

-- CreateIndex
CREATE INDEX "connector_accounts_userId_idx" ON "connector_accounts"("userId");

-- CreateIndex
CREATE INDEX "connector_accounts_tenant_id_idx" ON "connector_accounts"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "connector_accounts_userId_provider_scope_key" ON "connector_accounts"("userId", "provider", "scope");

-- CreateIndex
CREATE UNIQUE INDEX "client_feedback_dedupeKey_key" ON "client_feedback"("dedupeKey");

-- CreateIndex
CREATE INDEX "client_feedback_status_createdAt_idx" ON "client_feedback"("status", "createdAt");

-- CreateIndex
CREATE INDEX "client_feedback_createdById_idx" ON "client_feedback"("createdById");

-- CreateIndex
CREATE INDEX "client_feedback_tenant_id_idx" ON "client_feedback"("tenant_id");

-- CreateIndex
CREATE INDEX "feedback_deliveries_status_nextAttemptAt_idx" ON "feedback_deliveries"("status", "nextAttemptAt");

-- CreateIndex
CREATE INDEX "feedback_deliveries_tenant_id_idx" ON "feedback_deliveries"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "feedback_deliveries_feedbackId_channel_key" ON "feedback_deliveries"("feedbackId", "channel");

-- CreateIndex
CREATE INDEX "feedback_digests_tenant_id_idx" ON "feedback_digests"("tenant_id");

-- CreateIndex
CREATE INDEX "feedback_screenshots_createdById_idx" ON "feedback_screenshots"("createdById");

-- CreateIndex
CREATE INDEX "feedback_screenshots_tenant_id_idx" ON "feedback_screenshots"("tenant_id");

-- CreateIndex
CREATE INDEX "addresses_tenant_id_idx" ON "addresses"("tenant_id");

-- CreateIndex
CREATE INDEX "admin_users_tenant_id_idx" ON "admin_users"("tenant_id");

-- CreateIndex
CREATE INDEX "ai_conversations_tenant_id_idx" ON "ai_conversations"("tenant_id");

-- CreateIndex
CREATE INDEX "ai_documents_tenant_id_idx" ON "ai_documents"("tenant_id");

-- CreateIndex
CREATE INDEX "ai_messages_tenant_id_idx" ON "ai_messages"("tenant_id");

-- CreateIndex
CREATE INDEX "ai_streams_tenant_id_idx" ON "ai_streams"("tenant_id");

-- CreateIndex
CREATE INDEX "ai_suggestions_tenant_id_idx" ON "ai_suggestions"("tenant_id");

-- CreateIndex
CREATE INDEX "ai_votes_tenant_id_idx" ON "ai_votes"("tenant_id");

-- CreateIndex
CREATE INDEX "analytics_events_tenant_id_idx" ON "analytics_events"("tenant_id");

-- CreateIndex
CREATE INDEX "api_key_usage_tenant_id_idx" ON "api_key_usage"("tenant_id");

-- CreateIndex
CREATE INDEX "api_keys_tenant_id_idx" ON "api_keys"("tenant_id");

-- CreateIndex
CREATE INDEX "audit_logs_tenant_id_idx" ON "audit_logs"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "back_in_stock_subscriptions_tenant_id_email_productId_varia_key" ON "back_in_stock_subscriptions"("tenant_id", "email", "productId", "variantId");

-- CreateIndex
CREATE INDEX "blog_comments_tenant_id_idx" ON "blog_comments"("tenant_id");

-- CreateIndex
CREATE INDEX "blog_post_categories_tenant_id_idx" ON "blog_post_categories"("tenant_id");

-- CreateIndex
CREATE INDEX "blog_post_tags_tenant_id_idx" ON "blog_post_tags"("tenant_id");

-- CreateIndex
CREATE INDEX "blog_posts_homeOrder_idx" ON "blog_posts"("homeOrder");

-- CreateIndex
CREATE INDEX "bundle_assets_tenant_id_idx" ON "bundle_assets"("tenant_id");

-- CreateIndex
CREATE INDEX "canva_connections_tenant_id_idx" ON "canva_connections"("tenant_id");

-- CreateIndex
CREATE INDEX "cart_items_tenant_id_idx" ON "cart_items"("tenant_id");

-- CreateIndex
CREATE INDEX "cms_modules_tenant_id_idx" ON "cms_modules"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "cms_modules_tenant_id_slug_key" ON "cms_modules"("tenant_id", "slug");

-- CreateIndex
CREATE INDEX "custom_animations_tenant_id_idx" ON "custom_animations"("tenant_id");

-- CreateIndex
CREATE INDEX "custom_components_tenant_id_idx" ON "custom_components"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "custom_components_tenant_id_name_key" ON "custom_components"("tenant_id", "name");

-- CreateIndex
CREATE INDEX "customer_addresses_tenant_id_idx" ON "customer_addresses"("tenant_id");

-- CreateIndex
CREATE INDEX "digital_downloads_tenant_id_idx" ON "digital_downloads"("tenant_id");

-- CreateIndex
CREATE INDEX "discount_usages_tenant_id_idx" ON "discount_usages"("tenant_id");

-- CreateIndex
CREATE INDEX "email_ab_tests_tenant_id_idx" ON "email_ab_tests"("tenant_id");

-- CreateIndex
CREATE INDEX "email_automation_enrollment_steps_tenant_id_idx" ON "email_automation_enrollment_steps"("tenant_id");

-- CreateIndex
CREATE INDEX "email_automation_enrollments_tenant_id_idx" ON "email_automation_enrollments"("tenant_id");

-- CreateIndex
CREATE INDEX "email_automation_steps_tenant_id_idx" ON "email_automation_steps"("tenant_id");

-- CreateIndex
CREATE INDEX "email_automations_tenant_id_idx" ON "email_automations"("tenant_id");

-- CreateIndex
CREATE INDEX "email_link_clicks_tenant_id_idx" ON "email_link_clicks"("tenant_id");

-- CreateIndex
CREATE INDEX "email_links_tenant_id_idx" ON "email_links"("tenant_id");

-- CreateIndex
CREATE INDEX "email_queue_items_tenant_id_idx" ON "email_queue_items"("tenant_id");

-- CreateIndex
CREATE INDEX "email_recipients_campaignId_status_idx" ON "email_recipients"("campaignId", "status");

-- CreateIndex
CREATE INDEX "email_recipients_tenant_id_idx" ON "email_recipients"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "email_recipients_tenant_id_campaignId_email_key" ON "email_recipients"("tenant_id", "campaignId", "email");

-- CreateIndex
CREATE INDEX "email_segment_members_tenant_id_idx" ON "email_segment_members"("tenant_id");

-- CreateIndex
CREATE INDEX "email_segments_tenant_id_idx" ON "email_segments"("tenant_id");

-- CreateIndex
CREATE INDEX "form_submissions_formId_status_idx" ON "form_submissions"("formId", "status");

-- CreateIndex
CREATE INDEX "help_content_tenant_id_idx" ON "help_content"("tenant_id");

-- CreateIndex
CREATE INDEX "help_tours_tenant_id_idx" ON "help_tours"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "help_tours_tenant_id_slug_key" ON "help_tours"("tenant_id", "slug");

-- CreateIndex
CREATE INDEX "license_keys_tenant_id_idx" ON "license_keys"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "license_keys_tenant_id_key_key" ON "license_keys"("tenant_id", "key");

-- CreateIndex
CREATE INDEX "mcp_servers_tenant_id_idx" ON "mcp_servers"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "mcp_servers_tenant_id_name_key" ON "mcp_servers"("tenant_id", "name");

-- CreateIndex
CREATE INDEX "media_canvaDesignId_idx" ON "media"("canvaDesignId");

-- CreateIndex
CREATE UNIQUE INDEX "media_tenant_id_key_key" ON "media"("tenant_id", "key");

-- CreateIndex
CREATE INDEX "media_tags_on_media_tenant_id_idx" ON "media_tags_on_media"("tenant_id");

-- CreateIndex
CREATE INDEX "media_usage_tenant_id_idx" ON "media_usage"("tenant_id");

-- CreateIndex
CREATE INDEX "order_items_tenant_id_idx" ON "order_items"("tenant_id");

-- CreateIndex
CREATE INDEX "order_progress_tenant_id_idx" ON "order_progress"("tenant_id");

-- CreateIndex
CREATE INDEX "order_workflow_stages_tenant_id_idx" ON "order_workflow_stages"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "order_workflow_stages_tenant_id_workflowId_slug_key" ON "order_workflow_stages"("tenant_id", "workflowId", "slug");

-- CreateIndex
CREATE INDEX "page_bundles_tenant_id_idx" ON "page_bundles"("tenant_id");

-- CreateIndex
CREATE INDEX "pages_scheduledAt_idx" ON "pages"("scheduledAt");

-- CreateIndex
CREATE INDEX "payments_tenant_id_idx" ON "payments"("tenant_id");

-- CreateIndex
CREATE INDEX "platform_activity_log_tenant_id_idx" ON "platform_activity_log"("tenant_id");

-- CreateIndex
CREATE INDEX "plugins_tenant_id_idx" ON "plugins"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "plugins_tenant_id_slug_key" ON "plugins"("tenant_id", "slug");

-- CreateIndex
CREATE UNIQUE INDEX "plugins_tenant_id_name_key" ON "plugins"("tenant_id", "name");

-- CreateIndex
CREATE INDEX "primitive_executions_tenant_id_idx" ON "primitive_executions"("tenant_id");

-- CreateIndex
CREATE INDEX "primitives_tenant_id_idx" ON "primitives"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "primitives_tenant_id_name_key" ON "primitives"("tenant_id", "name");

-- CreateIndex
CREATE INDEX "product_categories_tenant_id_idx" ON "product_categories"("tenant_id");

-- CreateIndex
CREATE INDEX "product_custom_fields_tenant_id_idx" ON "product_custom_fields"("tenant_id");

-- CreateIndex
CREATE INDEX "product_images_tenant_id_idx" ON "product_images"("tenant_id");

-- CreateIndex
CREATE INDEX "product_option_values_tenant_id_idx" ON "product_option_values"("tenant_id");

-- CreateIndex
CREATE INDEX "product_options_tenant_id_idx" ON "product_options"("tenant_id");

-- CreateIndex
CREATE INDEX "product_variant_option_values_tenant_id_idx" ON "product_variant_option_values"("tenant_id");

-- CreateIndex
CREATE INDEX "product_variants_tenant_id_idx" ON "product_variants"("tenant_id");

-- CreateIndex
CREATE INDEX "puck_templates_type_isActive_idx" ON "puck_templates"("type", "isActive");

-- CreateIndex
CREATE INDEX "puck_templates_tenant_id_idx" ON "puck_templates"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "puck_templates_tenant_id_slug_key" ON "puck_templates"("tenant_id", "slug");

-- CreateIndex
CREATE UNIQUE INDEX "review_votes_tenant_id_reviewId_email_key" ON "review_votes"("tenant_id", "reviewId", "email");

-- CreateIndex
CREATE INDEX "shipments_tenant_id_idx" ON "shipments"("tenant_id");

-- CreateIndex
CREATE INDEX "subscription_tiers_tenant_id_idx" ON "subscription_tiers"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "subscription_tiers_tenant_id_name_key" ON "subscription_tiers"("tenant_id", "name");

-- CreateIndex
CREATE INDEX "subscriptions_tenant_id_idx" ON "subscriptions"("tenant_id");

-- CreateIndex
CREATE INDEX "super_admins_tenant_id_idx" ON "super_admins"("tenant_id");

-- CreateIndex
CREATE INDEX "team_invitations_tenant_id_idx" ON "team_invitations"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "team_invitations_tenant_id_team_id_email_key" ON "team_invitations"("tenant_id", "team_id", "email");

-- CreateIndex
CREATE INDEX "team_members_tenant_id_idx" ON "team_members"("tenant_id");

-- CreateIndex
CREATE INDEX "team_subdomains_tenant_id_idx" ON "team_subdomains"("tenant_id");

-- CreateIndex
CREATE INDEX "teams_tenant_id_idx" ON "teams"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "teams_tenant_id_slug_key" ON "teams"("tenant_id", "slug");

-- CreateIndex
CREATE UNIQUE INDEX "users_stackAuthId_key" ON "users"("stackAuthId");

-- CreateIndex
CREATE INDEX "users_stackAuthId_idx" ON "users"("stackAuthId");

-- CreateIndex
CREATE INDEX "users_tenant_id_idx" ON "users"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "users_tenant_id_email_key" ON "users"("tenant_id", "email");

-- CreateIndex
CREATE INDEX "variant_custom_field_values_tenant_id_idx" ON "variant_custom_field_values"("tenant_id");

-- CreateIndex
CREATE INDEX "wishlist_items_tenant_id_idx" ON "wishlist_items"("tenant_id");

-- CreateIndex
CREATE INDEX "workflow_executions_tenant_id_idx" ON "workflow_executions"("tenant_id");

-- CreateIndex
CREATE INDEX "workflow_logs_tenant_id_idx" ON "workflow_logs"("tenant_id");

-- CreateIndex
CREATE INDEX "workflow_nodes_tenant_id_idx" ON "workflow_nodes"("tenant_id");

-- CreateIndex
CREATE INDEX "workflow_steps_tenant_id_idx" ON "workflow_steps"("tenant_id");

-- CreateIndex
CREATE INDEX "workflow_templates_tenant_id_idx" ON "workflow_templates"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "workflow_templates_tenant_id_slug_key" ON "workflow_templates"("tenant_id", "slug");

-- CreateIndex
CREATE INDEX "workflows_tenant_id_idx" ON "workflows"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "workflows_tenant_id_slug_key" ON "workflows"("tenant_id", "slug");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_addresses" ADD CONSTRAINT "customer_addresses_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "api_keys" ADD CONSTRAINT "api_keys_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "api_key_usage" ADD CONSTRAINT "api_key_usage_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "api_key_class_usage" ADD CONSTRAINT "api_key_class_usage_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "usage_counters" ADD CONSTRAINT "usage_counters_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "addresses" ADD CONSTRAINT "addresses_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "mcp_servers" ADD CONSTRAINT "mcp_servers_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_ogImageId_fkey" FOREIGN KEY ("ogImageId") REFERENCES "media"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_images" ADD CONSTRAINT "product_images_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_options" ADD CONSTRAINT "product_options_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_option_values" ADD CONSTRAINT "product_option_values_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_variants" ADD CONSTRAINT "product_variants_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_variant_option_values" ADD CONSTRAINT "product_variant_option_values_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_custom_fields" ADD CONSTRAINT "product_custom_fields_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "variant_custom_field_values" ADD CONSTRAINT "variant_custom_field_values_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "license_keys" ADD CONSTRAINT "license_keys_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "digital_downloads" ADD CONSTRAINT "digital_downloads_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shipments" ADD CONSTRAINT "shipments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "order_workflow_stages" ADD CONSTRAINT "order_workflow_stages_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "order_progress" ADD CONSTRAINT "order_progress_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pages" ADD CONSTRAINT "pages_ogImageId_fkey" FOREIGN KEY ("ogImageId") REFERENCES "media"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "page_revisions" ADD CONSTRAINT "page_revisions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "page_revisions" ADD CONSTRAINT "page_revisions_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "pages"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "media_tags_on_media" ADD CONSTRAINT "media_tags_on_media_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "media_usage" ADD CONSTRAINT "media_usage_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_conversations" ADD CONSTRAINT "ai_conversations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_messages" ADD CONSTRAINT "ai_messages_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_votes" ADD CONSTRAINT "ai_votes_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_streams" ADD CONSTRAINT "ai_streams_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_documents" ADD CONSTRAINT "ai_documents_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_suggestions" ADD CONSTRAINT "ai_suggestions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "primitives" ADD CONSTRAINT "primitives_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "plugins" ADD CONSTRAINT "plugins_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflows" ADD CONSTRAINT "workflows_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflow_nodes" ADD CONSTRAINT "workflow_nodes_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "primitive_executions" ADD CONSTRAINT "primitive_executions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflow_executions" ADD CONSTRAINT "workflow_executions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflow_templates" ADD CONSTRAINT "workflow_templates_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflow_steps" ADD CONSTRAINT "workflow_steps_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflow_logs" ADD CONSTRAINT "workflow_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_recipients" ADD CONSTRAINT "email_recipients_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_suppressions" ADD CONSTRAINT "email_suppressions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "puck_templates" ADD CONSTRAINT "puck_templates_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_automations" ADD CONSTRAINT "email_automations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_automation_steps" ADD CONSTRAINT "email_automation_steps_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_automation_enrollments" ADD CONSTRAINT "email_automation_enrollments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_automation_enrollment_steps" ADD CONSTRAINT "email_automation_enrollment_steps_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_segments" ADD CONSTRAINT "email_segments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_segment_members" ADD CONSTRAINT "email_segment_members_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_links" ADD CONSTRAINT "email_links_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_link_clicks" ADD CONSTRAINT "email_link_clicks_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_ab_tests" ADD CONSTRAINT "email_ab_tests_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "payments" ADD CONSTRAINT "payments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "form_rule_runs" ADD CONSTRAINT "form_rule_runs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "form_rule_runs" ADD CONSTRAINT "form_rule_runs_submissionId_fkey" FOREIGN KEY ("submissionId") REFERENCES "form_submissions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "form_rate_limits" ADD CONSTRAINT "form_rate_limits_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "form_bulk_jobs" ADD CONSTRAINT "form_bulk_jobs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_post_categories" ADD CONSTRAINT "blog_post_categories_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_post_tags" ADD CONSTRAINT "blog_post_tags_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_comments" ADD CONSTRAINT "blog_comments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "analytics_events" ADD CONSTRAINT "analytics_events_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cart_items" ADD CONSTRAINT "cart_items_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "discount_usages" ADD CONSTRAINT "discount_usages_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "wishlist_items" ADD CONSTRAINT "wishlist_items_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "email_queue_items" ADD CONSTRAINT "email_queue_items_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "page_bundles" ADD CONSTRAINT "page_bundles_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bundle_assets" ADD CONSTRAINT "bundle_assets_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "custom_animations" ADD CONSTRAINT "custom_animations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "custom_components" ADD CONSTRAINT "custom_components_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "help_content" ADD CONSTRAINT "help_content_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "help_tours" ADD CONSTRAINT "help_tours_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "admin_users" ADD CONSTRAINT "admin_users_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "subscription_tiers" ADD CONSTRAINT "subscription_tiers_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teams" ADD CONSTRAINT "teams_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "team_members" ADD CONSTRAINT "team_members_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "team_invitations" ADD CONSTRAINT "team_invitations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "team_subdomains" ADD CONSTRAINT "team_subdomains_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "super_admins" ADD CONSTRAINT "super_admins_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "platform_activity_log" ADD CONSTRAINT "platform_activity_log_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "canva_connections" ADD CONSTRAINT "canva_connections_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tours" ADD CONSTRAINT "tours_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_runs" ADD CONSTRAINT "tour_runs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_runs" ADD CONSTRAINT "tour_runs_tourId_fkey" FOREIGN KEY ("tourId") REFERENCES "tours"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cms_modules" ADD CONSTRAINT "cms_modules_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_change_sets" ADD CONSTRAINT "ade_change_sets_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_change_set_items" ADD CONSTRAINT "ade_change_set_items_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_change_set_items" ADD CONSTRAINT "ade_change_set_items_changeSetId_fkey" FOREIGN KEY ("changeSetId") REFERENCES "ade_change_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_change_comments" ADD CONSTRAINT "ade_change_comments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_change_comments" ADD CONSTRAINT "ade_change_comments_changeSetId_fkey" FOREIGN KEY ("changeSetId") REFERENCES "ade_change_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_tasks" ADD CONSTRAINT "ade_tasks_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_coverage" ADD CONSTRAINT "ade_coverage_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_user_prefs" ADD CONSTRAINT "ade_user_prefs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_records" ADD CONSTRAINT "ade_records_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_edit_locks" ADD CONSTRAINT "ade_edit_locks_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_runs" ADD CONSTRAINT "agent_runs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_spans" ADD CONSTRAINT "agent_spans_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_spans" ADD CONSTRAINT "agent_spans_runId_fkey" FOREIGN KEY ("runId") REFERENCES "agent_runs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_waits" ADD CONSTRAINT "ade_waits_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_revisions" ADD CONSTRAINT "ade_revisions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ade_handoffs" ADD CONSTRAINT "ade_handoffs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "connector_accounts" ADD CONSTRAINT "connector_accounts_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "connector_accounts" ADD CONSTRAINT "connector_accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "client_feedback" ADD CONSTRAINT "client_feedback_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "feedback_deliveries" ADD CONSTRAINT "feedback_deliveries_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "feedback_digests" ADD CONSTRAINT "feedback_digests_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "feedback_screenshots" ADD CONSTRAINT "feedback_screenshots_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "subdomains"("id") ON DELETE CASCADE ON UPDATE CASCADE;

