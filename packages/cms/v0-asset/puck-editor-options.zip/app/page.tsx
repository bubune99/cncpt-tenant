import { PageBuilder } from "@/components/builder/page-builder"

export default function Home() {
  return <PageBuilder />
}
